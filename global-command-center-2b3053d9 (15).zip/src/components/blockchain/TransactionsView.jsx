import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Send, QrCode, Copy, Search, ArrowUpRight, ArrowDownRight, Filter } from 'lucide-react';

const getStatusBadge = (status) => {
  switch (status) {
    case "CONFIRMED":
       return <Badge className="bg-green-500/10 text-green-400 border-green-500/20 capitalize">{status.toLowerCase()}</Badge>;
    case "PENDING": 
      return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 capitalize animate-pulse">{status.toLowerCase()}</Badge>;
    case "FAILED": return <Badge className="bg-red-500/10 text-red-400 border-red-500/20 capitalize">{status.toLowerCase()}</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20 capitalize">{status?.toLowerCase()}</Badge>;
  }
};

export default function TransactionsView({ data }) {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [search, setSearch] = useState('');

  const transactions = (data?.transactions || []).filter(tx => tx.transaction_hash.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
       <h1 className="text-3xl font-bold text-white">Transactions</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-pane">
          <CardHeader><CardTitle className="flex items-center"><Send className="mr-2 text-cyan-400"/>Send Tokens</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="recipient" className="text-gray-400 mb-2 block">Recipient Address</Label>
              <Input id="recipient" placeholder="0x..." value={recipient} onChange={e => setRecipient(e.target.value)} className="bg-[#0C0F19] border-gray-600"/>
            </div>
            <div>
              <Label htmlFor="amount" className="text-gray-400 mb-2 block">Amount (GCC)</Label>
              <Input id="amount" type="number" placeholder="0.0" value={amount} onChange={e => setAmount(e.target.value)} className="bg-[#0C0F19] border-gray-600"/>
            </div>
            <Button className="w-full orbital-button-primary mt-2">Sign & Send Transaction</Button>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardHeader><CardTitle className="flex items-center"><ArrowDownRight className="mr-2 text-green-400"/>Receive Tokens</CardTitle></CardHeader>
          <CardContent className="space-y-4 text-center flex flex-col items-center justify-center h-full">
             <div className="bg-white p-2 rounded-lg inline-block">
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=128x128&data=0x4A5CF3a52c5d642c8DE3c1b1dD8fB3b1B3a0f3B1&bgcolor=ffffff`} alt="QR Code" />
             </div>
             <p className="text-gray-400 pt-2">Your Wallet Address:</p>
             <p className="font-mono text-xs text-white break-all">0x4A5CF3a52c5d642c8DE3c1b1dD8fB3b1B3a0f3B1</p>
             <Button variant="outline" className="text-white border-gray-600 bg-[#0C0F19] hover:bg-[#151823]">
                <Copy className="mr-2 h-3 w-3"/>
                Copy Address
             </Button>
          </CardContent>
        </Card>
      </div>
      
      <Card className="glass-pane">
        <CardHeader>
            <div className="flex justify-between items-center">
                <CardTitle>Transaction History</CardTitle>
                <div className="flex items-center space-x-2">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                        <Input placeholder="Search hash..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9 bg-[#0C0F19] border-gray-600 w-48"/>
                    </div>
                </div>
            </div>
        </CardHeader>
        <CardContent>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-transparent">
                            <TableHead className="text-gray-400">Hash</TableHead>
                            <TableHead className="text-gray-400">Type</TableHead>
                            <TableHead className="text-gray-400">From</TableHead>
                            <TableHead className="text-gray-400">To</TableHead>
                            <TableHead className="text-gray-400 text-right">Amount</TableHead>
                            <TableHead className="text-gray-400 text-right">Status</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {transactions.map(tx => (
                            <TableRow key={tx.id} className="border-gray-800 hover:bg-gray-800/30">
                                <TableCell className="font-mono text-xs text-purple-400 truncate max-w-[100px]">{tx.transaction_hash}</TableCell>
                                <TableCell>
                                    <Badge variant="outline" className="text-cyan-400 border-cyan-400/50 capitalize text-xs">{tx.transaction_type.toLowerCase().replace('_', ' ')}</Badge>
                                </TableCell>
                                <TableCell className="font-mono text-xs text-gray-400 truncate max-w-[100px]">{tx.from_address}</TableCell>
                                <TableCell className="font-mono text-xs text-gray-400 truncate max-w-[100px]">{tx.to_address}</TableCell>
                                <TableCell className="text-white text-right font-medium">{tx.amount.toFixed(4)} GCC</TableCell>
                                <TableCell className="text-right">{getStatusBadge(tx.status || "CONFIRMED")}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}