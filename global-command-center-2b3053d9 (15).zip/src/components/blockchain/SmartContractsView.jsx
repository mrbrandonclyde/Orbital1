import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileText, Plus, Search, Code, CheckCircle, Clock } from 'lucide-react';
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const getVerificationBadge = (isVerified) => {
  return isVerified 
    ? <Badge className="bg-green-500/10 text-green-400 border-green-500/20"><CheckCircle className="mr-1 h-3 w-3"/>Verified</Badge>
    : <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20"><Clock className="mr-1 h-3 w-3"/>Unverified</Badge>
};

export default function SmartContractsView({ data }) {
  const [contractCode, setContractCode] = useState('');
  const [showDeploy, setShowDeploy] = useState(false);
  
  const contracts = data?.contracts || [];
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Smart Contracts</h1>
        <Button onClick={() => setShowDeploy(!showDeploy)} className="orbital-button-primary">
            <Plus className="mr-2 h-4 w-4"/>
            {showDeploy ? 'Cancel Deploy' : 'Deploy New Contract'}
        </Button>
      </div>

      {showDeploy && (
        <Card className="glass-pane">
          <CardHeader><CardTitle className="flex items-center"><Plus className="mr-2"/>Deploy New Contract</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="contractName" className="text-gray-400 mb-2 block">Contract Name</Label>
              <Input id="contractName" placeholder="MyAwesomeContract" className="bg-[#0C0F19] border-gray-600"/>
            </div>
            <div>
              <Label htmlFor="contractCode" className="text-gray-400 mb-2 block">Contract Code (Solidity/Vyper)</Label>
              <Textarea
                id="contractCode"
                placeholder="pragma solidity ^0.8.0; ..."
                value={contractCode}
                onChange={e => setContractCode(e.target.value)}
                className="font-mono h-64 bg-[#0C0F19] border-gray-600"
              />
            </div>
            <Button className="w-full orbital-button-primary mt-2">Deploy Contract</Button>
          </CardContent>
        </Card>
      )}

      <Card className="glass-pane">
        <CardHeader>
            <CardTitle>Deployed Contracts</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-transparent">
                            <TableHead className="text-gray-400">Name</TableHead>
                            <TableHead className="text-gray-400">Address</TableHead>
                            <TableHead className="text-gray-400">Type</TableHead>
                            <TableHead className="text-gray-400 text-right">Transactions</TableHead>
                            <TableHead className="text-gray-400 text-right">Status</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {contracts.map(contract => (
                            <TableRow key={contract.id} className="border-gray-800 hover:bg-gray-800/30">
                                <TableCell className="font-semibold text-white">{contract.contract_name}</TableCell>
                                <TableCell className="font-mono text-xs text-purple-400">{contract.contract_address}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="text-cyan-400 border-cyan-400/50 capitalize text-xs">{contract.contract_type?.toLowerCase() || 'UTILITY'}</Badge>
                                </TableCell>
                                <TableCell className="text-white text-right">{contract.total_transactions || 0}</TableCell>
                                <TableCell className="text-right">{getVerificationBadge(contract.is_verified)}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}