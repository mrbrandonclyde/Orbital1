import React from 'react';
import { Badge } from "@/components/ui/badge";
import { User, Database, Eye, Edit, Trash, Lock, AlertCircle } from 'lucide-react';

const getActionIcon = (action) => {
  switch (action) {
    case 'CREATE': return <Edit className="w-4 h-4 text-green-400" />;
    case 'UPDATE': return <Edit className="w-4 h-4 text-blue-400" />;
    case 'DELETE': return <Trash className="w-4 h-4 text-red-400" />;
    case 'VIEW': return <Eye className="w-4 h-4 text-gray-400" />;
    case 'LOGIN': return <User className="w-4 h-4 text-green-400" />;
    case 'LOGOUT': return <User className="w-4 h-4 text-gray-400" />;
    case 'ACCESS_DENIED': return <Lock className="w-4 h-4 text-red-400" />;
    default: return <AlertCircle className="w-4 h-4 text-yellow-400" />;
  }
};

const getRiskBadge = (riskScore) => {
  if (!riskScore) return null;
  
  if (riskScore >= 80) return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Critical Risk</Badge>;
  if (riskScore >= 60) return <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">High Risk</Badge>;
  if (riskScore >= 40) return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Medium Risk</Badge>;
  return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Low Risk</Badge>;
};

export default function AuditEntry({ entry, user }) {
  const actionIcon = getActionIcon(entry.action);
  const riskBadge = getRiskBadge(entry.risk_score);

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-4 hover:border-indigo-500/50 transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          {actionIcon}
          <div>
            <h4 className="text-white font-semibold">
              {entry.action} on {entry.entity_type}
            </h4>
            <p className="text-gray-400 text-sm">
              ID: {entry.entity_id}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {riskBadge}
          <span className="text-xs text-gray-500">
            {new Date(entry.action_timestamp).toLocaleString()}
          </span>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4 text-gray-500" />
          <span className="text-gray-300 text-sm">
            {user?.full_name || 'Unknown User'}
          </span>
          {entry.user_ip_address && (
            <span className="text-gray-500 text-xs">
              from {entry.user_ip_address}
            </span>
          )}
        </div>
        
        {entry.security_classification && (
          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            {entry.security_classification}
          </Badge>
        )}
      </div>

      {entry.changes_made && Object.keys(entry.changes_made).length > 0 && (
        <div className="mt-3 p-2 bg-gray-800/30 rounded text-xs">
          <p className="text-gray-400 mb-1">Changes:</p>
          <pre className="text-gray-300 whitespace-pre-wrap">
            {JSON.stringify(entry.changes_made, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}