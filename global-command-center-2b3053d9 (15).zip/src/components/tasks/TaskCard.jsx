import React from 'react';
import { Gavel, User, Calendar, Target, Edit } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const statusColors = {
  PENDING: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
  IN_PROGRESS: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  COMPLETED: 'text-green-400 bg-green-500/10 border-green-500/20',
  BLOCKED: 'text-red-400 bg-red-500/10 border-red-500/20',
};

export default function TaskCard({ task, onEdit, assignedUser, mission }) {
  const statusStyle = statusColors[task.status] || 'text-gray-400 bg-gray-500/10';

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-5 hover:border-indigo-500/50 transition-all">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-3">
          <Gavel className="w-6 h-6 text-indigo-400" />
          <div>
            <h3 className="text-lg font-semibold text-white">{task.task_name}</h3>
            {mission && (
              <div className="flex items-center space-x-1 text-xs text-gray-500">
                <Target size={12}/>
                <span>{mission.mission_name}</span>
              </div>
            )}
          </div>
        </div>
        <button onClick={() => onEdit(task)} className="orbital-button-secondary text-xs p-2">
          <Edit size={14} />
        </button>
      </div>

      <p className="text-sm text-gray-400 mb-4">{task.description}</p>
      
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-300">{assignedUser?.full_name || 'Unassigned'}</span>
          </div>
          {task.due_date && (
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-300">
                Due {formatDistanceToNow(new Date(task.due_date), { addSuffix: true })}
              </span>
            </div>
          )}
        </div>
        <div className={`px-3 py-1 rounded-full text-xs font-medium border ${statusStyle}`}>
          {task.status.replace('_', ' ')}
        </div>
      </div>
    </div>
  );
}