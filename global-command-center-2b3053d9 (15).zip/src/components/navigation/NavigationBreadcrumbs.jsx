import React from 'react';
import { ChevronRight } from 'lucide-react';

const titleMap = {
  CommandCenter: 'Command Center',
  ZyraCommand: 'Zyra Dashboard',
  SystemStatus: 'System Status',
  Alerts: 'Alerts Monitor',
  Analytics: 'Analytics & Insights',
  Personnel: 'Personnel',
  Reports: 'Reports',
  DataSources: 'Data Sources',
  GlobalMap: 'Global Intelligence Map',
  SupplyChain: 'Supply Chain Risk',
  Missions: 'Mission Control',
};

export default function NavigationBreadcrumbs({ currentPage, userClearance }) {
  const displayed = titleMap[currentPage] || currentPage || 'Dashboard';

  return (
    <nav aria-label="Breadcrumb" className="mb-6">
      <ol className="flex items-center text-sm text-gray-400">
        <li className="flex items-center">
          <span className="text-gray-300">Orbital</span>
          <ChevronRight className="w-4 h-4 mx-2 text-gray-600" />
        </li>
        <li className="flex items-center">
          <span className="text-cyan-400">{displayed}</span>
          {userClearance && (
            <>
              <ChevronRight className="w-4 h-4 mx-2 text-gray-600" />
              <span className="text-xs px-2 py-0.5 rounded-full border border-gray-700 text-gray-300">{userClearance}</span>
            </>
          )}
        </li>
      </ol>
    </nav>
  );
}