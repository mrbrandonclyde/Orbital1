import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Search, ChevronRight } from 'lucide-react';

const navItems = [
  { name: 'Command Center', page: 'CommandCenter' },
  { name: 'Zyra Dashboard', page: 'ZyraCommand' },
  { name: 'System Status', page: 'SystemStatus' },
  { name: 'Alerts Monitor', page: 'Alerts' },
  { name: 'Analytics & Insights', page: 'Analytics' },
  { name: 'Personnel', page: 'Personnel' },
  { name: 'Reports', page: 'Reports' },
  { name: 'Data Sources', page: 'DataSources' },
  { name: 'Global Intelligence Map', page: 'GlobalMap' },
  { name: 'Supply Chain Risk', page: 'SupplyChain' },
  { name: 'Mission Control', page: 'Missions' },
];

export default function QuickNavigation({ currentPage, userClearance }) {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return navItems;
    return navItems.filter(i => i.name.toLowerCase().includes(q) || i.page.toLowerCase().includes(q));
  }, [query]);

  return (
    <div>
      <div className="flex items-center bg-[#0C0F19] border border-gray-700 rounded-lg px-3 py-2 mb-4">
        <Search className="w-4 h-4 text-gray-400 mr-2" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search pages…"
          className="flex-1 bg-transparent outline-none text-gray-200 placeholder:text-gray-500"
        />
      </div>

      <ul className="max-h-[50vh] overflow-y-auto space-y-1">
        {filtered.map(item => (
          <li key={item.page}>
            <Link
              to={createPageUrl(item.page)}
              className={`flex items-center justify-between px-3 py-2 rounded-lg border border-transparent hover:border-cyan-500/30 hover:bg-cyan-500/10 transition ${
                currentPage === item.page ? 'bg-cyan-500/10 border-cyan-500/30' : 'bg-[#0A0D18]/50'
              }`}
            >
              <div className="text-sm text-gray-200">{item.name}</div>
              <ChevronRight className="w-4 h-4 text-gray-500" />
            </Link>
          </li>
        ))}
        {filtered.length === 0 && (
          <li className="text-sm text-gray-500 px-3 py-2">No results</li>
        )}
      </ul>

      {userClearance && (
        <div className="text-[10px] text-gray-500 mt-3">Clearance: {userClearance}</div>
      )}
    </div>
  );
}