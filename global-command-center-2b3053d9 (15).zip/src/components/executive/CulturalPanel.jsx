import React from 'react';
import { BookOpen, Eye, Users, TrendingUp, TrendingDown } from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';

// Sample data
const diversityData = [
  { subject: 'Linguistic', A: 85, fullMark: 100 },
  { subject: 'Religious', A: 78, fullMark: 100 },
  { subject: 'Cultural', A: 92, fullMark: 100 },
  { subject: 'Economic', A: 67, fullMark: 100 },
  { subject: 'Educational', A: 89, fullMark: 100 },
  { subject: 'Digital', A: 73, fullMark: 100 }
];

const biasFilterSummary = [
  { source: "Global News Network", filtered: 847, accuracy: "94.2%", status: "ACTIVE" },
  { source: "Social Media Feeds", filtered: 12534, accuracy: "87.8%", status: "ACTIVE" },
  { source: "Educational Content", filtered: 234, accuracy: "98.1%", status: "ACTIVE" },
  { source: "Political Analysis", filtered: 1023, accuracy: "91.3%", status: "REVIEW" }
];

export default function CulturalPanel({ timeframe, region, sectors }) {
  const knowledgeGrowth = 847.3; // GB per year
  const mediaIntegrity = 91.4; // %
  const culturalHarmony = 83.7; // Index

  return (
    <div className="space-y-6">
      {/* Cultural KPI Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <BookOpen className="w-5 h-5 text-purple-400" />
          </div>
          <div className="text-lg font-bold text-white">{knowledgeGrowth} GB</div>
          <div className="text-xs text-gray-400">Knowledge Vault Growth</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+12.3% YoY</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Eye className="w-5 h-5 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white">{mediaIntegrity}%</div>
          <div className="text-xs text-gray-400">Media Integrity Score</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+2.1% vs Q3</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-2xl font-bold text-white">{culturalHarmony}</div>
          <div className="text-xs text-gray-400">Cultural Harmony</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingDown className="w-3 h-3 text-orange-400 mr-1" />
            <span className="text-xs text-orange-400">-1.2 regional tensions</span>
          </div>
        </div>
      </div>

      {/* Diversity Radar Chart */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">Regional Diversity Metrics</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={diversityData}>
              <PolarGrid stroke="#374151" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#9CA3AF', fontSize: 10 }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#9CA3AF', fontSize: 8 }} />
              <Radar 
                name="Diversity Score" 
                dataKey="A" 
                stroke="#8B5CF6" 
                fill="#8B5CF6" 
                fillOpacity={0.3}
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bias Filter Summary */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">Bias Filter Summary (24h)</h4>
        <div className="space-y-2">
          {biasFilterSummary.map((filter, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-gray-800/30 rounded text-xs">
              <div className="flex-1">
                <div className="text-white font-medium">{filter.source}</div>
                <div className="text-gray-400">{filter.filtered.toLocaleString()} items filtered • {filter.accuracy} accuracy</div>
              </div>
              <span className={`px-2 py-1 rounded text-xs ${
                filter.status === 'ACTIVE' ? 'bg-green-500/20 text-green-400' :
                'bg-yellow-500/20 text-yellow-400'
              }`}>
                {filter.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}