import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Globe, AlertCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Sample data
const economicData = [
  { economy: 'USA', gdp: 23.3, resilience: 89 },
  { economy: 'China', gdp: 17.7, resilience: 76 },
  { economy: 'Japan', gdp: 4.9, resilience: 92 },
  { economy: 'Germany', gdp: 4.2, resilience: 88 },
  { economy: 'India', gdp: 3.7, resilience: 71 },
  { economy: 'UK', gdp: 3.1, resilience: 85 },
  { economy: 'France', gdp: 2.9, resilience: 87 },
  { economy: 'Italy', gdp: 2.1, resilience: 79 },
  { economy: 'Brazil', gdp: 2.1, resilience: 68 },
  { economy: 'Canada', gdp: 2.0, resilience: 91 }
];

const marketStressAlerts = [
  { time: "14:23", type: "INFLATION", message: "EU inflation indicators rising 0.3% above projection", severity: "MEDIUM" },
  { time: "13:47", type: "COMMODITY", message: "Rare earth supply chain disruption detected - Asia Pacific", severity: "HIGH" },
  { time: "12:15", type: "CURRENCY", message: "USD/EUR volatility spike - algorithmic trading detected", severity: "LOW" },
  { time: "11:32", type: "TRADE", message: "Mediterranean shipping delays - 48hr average increase", severity: "MEDIUM" }
];

export default function EconomicPanel({ timeframe, region, assets, metrics }) {
  const gdpGrowth = 3.2;
  const inflationIndex = 2.4;
  const resourceBalance = 78.5;

  return (
    <div className="space-y-6">
      {/* Economic KPI Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-2xl font-bold text-white">{gdpGrowth}%</div>
          <div className="text-xs text-gray-400">Global GDP Growth</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+0.4% vs Q3</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <DollarSign className="w-5 h-5 text-yellow-400" />
          </div>
          <div className="text-2xl font-bold text-white">{inflationIndex}%</div>
          <div className="text-xs text-gray-400">Inflation Index</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingDown className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">-0.2% vs target</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Globe className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{resourceBalance.toFixed(1)}</div>
          <div className="text-xs text-gray-400">Resource Balance</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">Optimal range</span>
          </div>
        </div>
      </div>

      {/* Top 10 Economies Chart */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">Top 10 Economies: GDP vs Resilience Index</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={economicData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="economy" stroke="#9CA3AF" fontSize={10} />
              <YAxis stroke="#9CA3AF" fontSize={10} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }}
                formatter={(value, name) => [
                  name === 'gdp' ? `$${value}T` : `${value}/100`,
                  name === 'gdp' ? 'GDP' : 'Resilience'
                ]}
              />
              <Bar dataKey="gdp" fill="#10B981" />
              <Bar dataKey="resilience" fill="#06B6D4" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Market Stress Alerts */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4 flex items-center">
          <AlertCircle className="w-4 h-4 text-orange-400 mr-2" />
          Market Stress Alerts
        </h4>
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {marketStressAlerts.map((alert, index) => (
            <div key={index} className="flex items-start space-x-3 p-2 bg-gray-800/30 rounded text-xs">
              <span className="text-gray-500 font-mono">{alert.time}</span>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-cyan-400 font-medium">{alert.type}</span>
                  <span className={`px-1 py-0.5 rounded text-xs ${
                    alert.severity === 'HIGH' ? 'bg-red-500/20 text-red-400' :
                    alert.severity === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {alert.severity}
                  </span>
                </div>
                <div className="text-gray-300">{alert.message}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}