import React from 'react';
import { Zap, Building2, Truck, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Sample data
const energyData = Array.from({ length: 24 }, (_, i) => ({
  hour: i,
  demand: 75 + Math.sin(i * 0.5) * 15 + Math.random() * 5,
  supply: 80 + Math.sin(i * 0.3) * 10 + Math.random() * 3
}));

const selfHealingEvents = [
  { time: "15:42", location: "NYC Grid Sector 7", incident: "Power Distribution Fault", resolution: "12s", status: "RESOLVED" },
  { time: "14:18", location: "Tokyo Metro Line 4", incident: "Signal Interference", resolution: "8s", status: "RESOLVED" },
  { time: "13:33", location: "London Traffic Grid", incident: "Route Optimization", resolution: "3s", status: "RESOLVED" },
  { time: "12:47", location: "Singapore Port Hub", incident: "Container Routing Error", resolution: "15s", status: "RESOLVED" },
  { time: "11:29", location: "Berlin Smart Grid", incident: "Load Balancing Issue", resolution: "6s", status: "RESOLVED" }
];

export default function InfrastructurePanel({ timeframe, region, assets, alerts }) {
  const energyStability = 94.7; // %
  const smartCityResilience = 89.2; // Score
  const transportContinuity = 96.1; // %

  return (
    <div className="space-y-6">
      {/* Infrastructure KPI Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Zap className="w-5 h-5 text-yellow-400" />
          </div>
          <div className="text-2xl font-bold text-white">{energyStability}%</div>
          <div className="text-xs text-gray-400">Energy Grid Stability</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+0.3% vs target</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Building2 className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{smartCityResilience}</div>
          <div className="text-xs text-gray-400">Smart City Resilience</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+2.1 vs baseline</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Truck className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-2xl font-bold text-white">{transportContinuity}%</div>
          <div className="text-xs text-gray-400">Transport Continuity</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
            <span className="text-xs text-red-400">-0.2% weather impact</span>
          </div>
        </div>
      </div>

      {/* Energy Demand vs Supply Chart */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">Global Energy Demand vs Supply (24h)</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={energyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={10} />
              <YAxis stroke="#9CA3AF" fontSize={10} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }}
                labelFormatter={(value) => `Hour ${value}:00`}
              />
              <Line type="monotone" dataKey="demand" stroke="#F59E0B" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="supply" stroke="#10B981" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center space-x-4 mt-2 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
            <span className="text-gray-400">Energy Demand</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-gray-400">Energy Supply</span>
          </div>
        </div>
      </div>

      {/* Self-Healing Events Log */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4 flex items-center">
          <Activity className="w-4 h-4 text-cyan-400 mr-2" />
          Self-Healing Events Log (Recent)
        </h4>
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {selfHealingEvents.map((event, index) => (
            <div key={index} className="flex items-start space-x-3 p-2 bg-gray-800/30 rounded text-xs">
              <span className="text-gray-500 font-mono">{event.time}</span>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-cyan-400 font-medium">{event.location}</span>
                  <span className="px-1 py-0.5 bg-green-500/20 text-green-400 rounded text-xs">
                    {event.resolution}
                  </span>
                </div>
                <div className="text-gray-300">{event.incident}</div>
              </div>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs">
                {event.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}