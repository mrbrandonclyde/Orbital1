import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Activity } from "lucide-react";
import { AuditTrail } from "@/api/entities";
import { ToolRunLog } from "@/api/entities";
import { User } from "@/api/entities";

export default function TimelinePanel() {
  const currentYear = new Date().getFullYear();
  const [offset, setOffset] = React.useState(0); // -5 .. +5
  const [confidence, setConfidence] = React.useState(0.7);
  const [assumptions, setAssumptions] = React.useState("Macro stable; moderate adoption; no black swans.");

  const year = currentYear + offset;

  const logProjection = async () => {
    let me = null;
    try { me = await User.me(); } catch {}
    const ts = new Date().toISOString();

    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "timeline",
      action: "CREATE",
      action_timestamp: ts,
      user_id: me?.id || "system",
      changes_made: { year, confidence, assumptions },
      security_classification: "INTERNAL",
      risk_score: 6
    });

    await ToolRunLog.create({
      tool_name: "TimelineProjection",
      run_context: "OrbitalBrowser.timeline",
      status: "success",
      latency_ms: 0,
      metadata: { year, confidence, assumptions },
      started_at: ts,
      finished_at: new Date().toISOString(),
      user_id: me?.id || "system"
    });
  };

  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
      <CardHeader>
        <CardTitle className="text-white text-base flex items-center gap-2">
          <Activity className="w-5 h-5 text-emerald-400" /> Timeline Projection
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-300">Year</div>
          <Badge className="bg-gray-700/40 text-gray-200">{year}</Badge>
        </div>
        <Slider value={[offset + 5]} min={0} max={10} onValueChange={(v) => setOffset(v[0] - 5)} />
        <div>
          <div className="text-xs text-gray-400 mb-1">Assumptions</div>
          <textarea
            className="w-full bg-[#0C0F19] border border-gray-800 rounded-lg p-2 text-sm text-gray-200"
            value={assumptions}
            onChange={(e) => setAssumptions(e.target.value)}
            rows={2}
          />
        </div>
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-300">Confidence</div>
          <Badge className="bg-gray-700/40 text-gray-200">{Math.round(confidence * 100)}%</Badge>
        </div>
        <Slider value={[Math.round(confidence * 100)]} min={0} max={100} onValueChange={(v) => setConfidence(v[0] / 100)} />
        <div className="flex justify-end">
          <button onClick={logProjection} className="px-3 py-2 text-xs rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">
            Log to AuditTrail + Recovery
          </button>
        </div>
      </CardContent>
    </Card>
  );
}