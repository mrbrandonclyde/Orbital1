export async function fusionSearch(query) {
  if (!query || !query.trim()) return [];
  // Mock fused results across engines
  return [
    { source: "Web • Google", title: `Overview for: ${query}`, snippet: "High-level web results fused across engines.", url: "https://www.google.com" },
    { source: "Academic • Scholar", title: `Academic findings on ${query}`, snippet: "Relevant academic references and citations.", url: "https://scholar.google.com" },
    { source: "Private Cloud", title: `Internal insights: ${query}`, snippet: "Secure, tenant-scoped knowledge base references.", url: "#" },
  ];
}