
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Shield, HardDrive, Lock, Unlock, Loader2 } from "lucide-react";
import { AuditTrail } from "@/api/entities";
import { User } from "@/api/entities";
import { ToolRunLog } from "@/api/entities";
import { toast } from "@/components/common/Toast";

function pseudoEncrypt(json) {
  // Placeholder encryption to represent AES-256 + PQC pipeline
  return btoa(unescape(encodeURIComponent(json)));
}
function pseudoDecrypt(text) {
  try { return decodeURIComponent(escape(atob(text))); } catch { return null; }
}

export default function Vault({ settings, onSettings }) {
  const [profile, setProfile] = React.useState({ display_name: "", wallet_address: "" });
  const [locked, setLocked] = React.useState(true);
  const [hasCache, setHasCache] = React.useState(false);
  const [walletConnected, setWalletConnected] = React.useState(false);
  const [scanning, setScanning] = React.useState(false);

  React.useEffect(() => {
    const cache = localStorage.getItem("orbital_vault_cache");
    setHasCache(!!cache);
  }, []);

  const connectWallet = async () => {
    // Placeholder: simulate ZK wallet auth + Kyber/Falcon handshake
    setWalletConnected(true);
    let me = null;
    try { me = await User.me(); } catch {}
    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "vault",
      action: "CREATE",
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: {
        type: "wallet_connect",
        handshake: "kyber_falcon_stub",
        aes256_at_rest: true,
        zero_trust: true
      },
      security_classification: "CONFIDENTIAL",
      risk_score: 4
    });
    toast.success("Wallet connected", { description: "Kyber/Falcon handshake established" });
  };

  const saveLocal = async () => {
    const blob = JSON.stringify(profile);
    const enc = pseudoEncrypt(blob);
    localStorage.setItem("orbital_vault_cache", enc);
    setHasCache(true);

    let me = null;
    try { me = await User.me(); } catch {}
    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "vault",
      action: "CREATE",
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: {
        type: "vault_local_save",
        offline_first: !!settings?.offline_first
      },
      security_classification: "CONFIDENTIAL",
      risk_score: 4
    });
    toast.success("Saved to encrypted cache", { description: "AES-256 local cache updated" });
  };

  const loadLocal = () => {
    const enc = localStorage.getItem("orbital_vault_cache");
    if (!enc) return;
    const json = pseudoDecrypt(enc);
    try {
      setProfile(JSON.parse(json || "{}"));
    } catch {}
    toast.info("Loaded from cache", { description: "Profile restored from encrypted storage" });
  };

  const toggleLock = async () => {
    setLocked((l) => !l);
    let me = null;
    try { me = await User.me(); } catch {}
    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "vault",
      action: "UPDATE",
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: {
        type: "vault_lock_toggle",
        locked: !locked
      },
      security_classification: "CONFIDENTIAL",
      risk_score: 3
    });
    toast.info(locked ? "Vault unlocked" : "Vault locked");
  };

  const runGuardianScan = async () => {
    setScanning(true);
    let me = null;
    try { me = await User.me(); } catch {}
    const ts = new Date().toISOString();
    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "guardian_shield",
      action: "CREATE",
      action_timestamp: ts,
      user_id: me?.id || "system",
      changes_made: {
        type: "guardian_scan",
        trackers_blocked: true,
        malware_blocked: true,
        phishing_blocked: true
      },
      security_classification: "CONFIDENTIAL",
      risk_score: 3
    });
    await ToolRunLog.create({
      tool_name: "GuardianShield",
      run_context: "OrbitalBrowser.vault",
      status: "success",
      latency_ms: 5,
      metadata: { trackers_blocked: true, malware_blocked: true, phishing_blocked: true },
      started_at: ts,
      finished_at: new Date().toISOString(),
      user_id: me?.id || "system"
    });
    setScanning(false);
    toast.success("Guardian Shields active", { description: "Trackers, malware, phishing blocked" });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            Bank Vault Security
            <Badge className="ml-2 bg-blue-500/20 text-blue-400">Unified</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-gray-300">
          <div className="flex items-center gap-2">
            <span>Zero-Knowledge Identity</span>
            <Badge className="bg-purple-500/20 text-purple-300">PQC-ready</Badge>
          </div>
          <div className="text-xs text-gray-400">
            Offline-first: Vault prioritizes local encrypted cache; sync only with explicit consent.
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white text-base">Identity Profile</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button onClick={connectWallet} disabled={walletConnected} className="bg-indigo-600 hover:bg-indigo-700">
              {walletConnected ? <Unlock className="w-4 h-4 mr-2" /> : <Lock className="w-4 h-4 mr-2" />} {walletConnected ? "Wallet Connected" : "Connect Wallet"}
            </Button>
            {walletConnected && (
              <Badge className="bg-purple-500/20 text-purple-300">Kyber/Falcon Handshake</Badge>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
            <div>
              <Label className="text-gray-300">Display Name</Label>
              <Input
                value={profile.display_name}
                onChange={(e) => setProfile(p => ({ ...p, display_name: e.target.value }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
              />
            </div>
            <div>
              <Label className="text-gray-300">Wallet Address</Label>
              <Input
                value={profile.wallet_address}
                onChange={(e) => setProfile(p => ({ ...p, wallet_address: e.target.value }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100 font-mono"
                placeholder="0x..."
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-2">
            <Button onClick={saveLocal} className="bg-[#0D1BFF] hover:bg-[#0B18DE]">
              <HardDrive className="w-4 h-4 mr-2" /> Save to Encrypted Cache
            </Button>
            <Button variant="outline" onClick={loadLocal} className="border-gray-700 text-gray-300">
              Load from Cache
            </Button>
            <Button variant="outline" onClick={toggleLock} className="border-gray-700 text-gray-300">
              {locked ? <Lock className="w-4 h-4 mr-2" /> : <Unlock className="w-4 h-4 mr-2" />} {locked ? "Unlock" : "Lock"}
            </Button>
            <Button onClick={runGuardianScan} disabled={scanning} className="bg-emerald-600 hover:bg-emerald-700">
              {scanning ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Scanning…</> : <><Shield className="w-4 h-4 mr-2" /> Run Guardian Scan</>}
            </Button>
            {hasCache && <Badge className="bg-green-500/20 text-green-400">Local Cache Available</Badge>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
