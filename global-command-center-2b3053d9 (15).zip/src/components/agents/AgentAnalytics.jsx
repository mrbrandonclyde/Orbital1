import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

export default function AgentAnalytics({ agents }) {
  const statusData = agents.reduce((acc, agent) => {
    acc[agent.status] = (acc[agent.status] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(statusData).map(([status, count]) => ({
    name: status,
    value: count,
    color: status === 'Active' ? '#10B981' : status === 'Training' ? '#3B82F6' : status === 'Idle' ? '#F59E0B' : '#EF4444'
  }));

  const functionData = agents.reduce((acc, agent) => {
    acc[agent.function] = (acc[agent.function] || 0) + 1;
    return acc;
  }, {});

  const functionChartData = Object.entries(functionData).map(([func, count]) => ({
    function: func,
    count
  }));

  return (
    <div className="space-y-6">
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Agent Status Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {chartData.map((entry, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
                <span className="text-gray-300">{entry.name}: {entry.value}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Function Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={functionChartData}>
                <XAxis dataKey="function" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip />
                <Bar dataKey="count" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}