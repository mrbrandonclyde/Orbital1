import React from "react";

export default function ConversationHistory() {
  return (
    <div className="p-4 space-y-2">
      {/* 📝 Chat History */}
      <p className="text-sm">[Exec] Show me defense budget...</p>
      <p className="text-sm text-green-400">[AI] $778B, status: CRITICAL</p>
      {/* TODO: Load from backend memory core */}
    </div>
  );
}