
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Globe2, PlusCircle, ZoomIn, RotateCw } from "lucide-react";
import { AuditTrail } from "@/api/entities";
import { User } from "@/api/entities";
import { toast } from "@/components/common/Toast"; // Added import

// Simple AES-like placeholder for demo (matches Vault pseudo-encryption)
function pseudoEncrypt(json) {
  return btoa(unescape(encodeURIComponent(json)));
}
function pseudoDecrypt(text) {
  try { return decodeURIComponent(escape(atob(text))); } catch { return null; }
}

function readVaultCache() {
  const enc = localStorage.getItem("orbital_vault_cache");
  if (!enc) return { markers: [] };
  const json = pseudoDecrypt(enc);
  try {
    const data = JSON.parse(json || "{}");
    if (!Array.isArray(data.markers)) data.markers = [];
    return data;
  } catch {
    return { markers: [] };
  }
}
function writeVaultCache(next) {
  const enc = pseudoEncrypt(JSON.stringify(next || {}));
  localStorage.setItem("orbital_vault_cache", enc);
}

export default function OrbitalGlobe() {
  const [rotation, setRotation] = React.useState(0);
  const [zoom, setZoom] = React.useState(1);
  const [markers, setMarkers] = React.useState([]);
  const [lat, setLat] = React.useState("");
  const [lng, setLng] = React.useState("");
  const [label, setLabel] = React.useState("");

  React.useEffect(() => {
    const cache = readVaultCache();
    setMarkers(cache.markers || []);
  }, []);

  const logEvent = async (type, payload = {}) => {
    let me = null;
    try { me = await User.me(); } catch {}
    await AuditTrail.create({
      entity_type: "OrbitalBrowser",
      entity_id: "orbital_globe",
      action: "CREATE",
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: { event: type, ...payload },
      security_classification: "INTERNAL",
      risk_score: 4
    });
  };

  const addMarker = async () => {
    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);
    if (isNaN(latNum) || isNaN(lngNum)) return;
    const m = { id: `${Date.now()}`, lat: latNum, lng: lngNum, label: label || "Marker" };
    const next = [...markers, m];
    setMarkers(next);
    const cache = readVaultCache();
    cache.markers = next;
    writeVaultCache(cache);
    await logEvent("marker_add", { lat: latNum, lng: lngNum, label: m.label });
    toast.success("Marker added", { description: `${m.label} (${latNum}, ${lngNum})` }); // Added toast
    setLat(""); setLng(""); setLabel("");
  };

  const handleRotate = async (v) => {
    setRotation(v);
    await logEvent("rotate", { rotation: v });
  };
  const handleZoom = async (v) => {
    setZoom(v);
    await logEvent("zoom", { zoom: v });
  };
  const onMarkerClick = async (m) => {
    await logEvent("marker_click", { id: m.id, lat: m.lat, lng: m.lng, label: m.label });
    toast.info("Marker selected", { description: m.label }); // Added toast
  };

  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
      <CardHeader>
        <CardTitle className="text-white text-base flex items-center gap-2">
          <Globe2 className="w-5 h-5 text-[#0D1BFF]" />
          Orbital Globe
          <Badge className="ml-2 bg-blue-500/20 text-blue-300">Interactive</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Globe canvas placeholder */}
        <div
          className="relative w-full h-80 rounded-2xl border border-gray-800 overflow-hidden"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(13,27,255,0.25) 0%, rgba(106,0,255,0.15) 60%, rgba(2,4,9,1) 100%)"
          }}
        >
          <div
            className="absolute inset-10 rounded-full border-2 border-[#0D1BFF]/40 animate-spin-slow"
            style={{ transform: `rotate(${rotation}deg) scale(${zoom})`, transformOrigin: "center" }}
          />
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-3 right-3 text-xs text-gray-400">
              Rot: {rotation}° • Zoom: {zoom.toFixed(2)}
            </div>
          </div>

          {/* Marker pins */}
          <div className="absolute inset-0">
            {markers.map((m) => {
              // very simple projection mock: lat/lng to x/y (not geo-accurate)
              const x = ((m.lng + 180) / 360) * 100;
              const y = ((90 - m.lat) / 180) * 100;
              return (
                <button
                  key={m.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${x}%`, top: `${y}%` }}
                  onClick={() => onMarkerClick(m)}
                  title={`${m.label} (${m.lat}, ${m.lng})`}
                >
                  <span className="w-3 h-3 block rounded-full bg-[#FFD700] shadow glow-effect-cyan" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-[#0C0F19] border border-gray-800">
            <div className="flex items-center gap-2 text-sm text-gray-300 mb-2">
              <RotateCw className="w-4 h-4 text-gray-400" /> Rotation
            </div>
            <input
              type="range"
              min="-180"
              max="180"
              value={rotation}
              onChange={(e) => handleRotate(parseInt(e.target.value, 10))}
              className="w-full"
            />
          </div>
          <div className="p-3 rounded-xl bg-[#0C0F19] border border-gray-800">
            <div className="flex items-center gap-2 text-sm text-gray-300 mb-2">
              <ZoomIn className="w-4 h-4 text-gray-400" /> Zoom
            </div>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.01"
              value={zoom}
              onChange={(e) => handleZoom(parseFloat(e.target.value))}
              className="w-full"
            />
          </div>
        </div>

        {/* Marker form */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Input
            value={lat}
            onChange={(e) => setLat(e.target.value)}
            placeholder="Latitude (-90 to 90)"
            className="bg-[#0C0F19] border-gray-700 text-gray-100"
          />
          <Input
            value={lng}
            onChange={(e) => setLng(e.target.value)}
            placeholder="Longitude (-180 to 180)"
            className="bg-[#0C0F19] border-gray-700 text-gray-100"
          />
          <Input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Label"
            className="bg-[#0C0F19] border-gray-700 text-gray-100"
          />
        </div>
        <div className="flex justify-end">
          <Button onClick={addMarker} className="bg-[#0D1BFF] hover:bg-[#0B18DE]"> {/* Updated button className */}
            <PlusCircle className="w-4 h-4 mr-2" /> Add Marker
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
