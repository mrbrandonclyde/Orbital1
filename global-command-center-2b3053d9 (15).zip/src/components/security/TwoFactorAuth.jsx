import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User } from '@/api/entities';
import { Shield, Smartphone, Key, Check, X, RefreshCw } from 'lucide-react';

export default function TwoFactorAuth({ user, onUpdate }) {
  const [isEnabled, setIsEnabled] = useState(user?.mfa_enabled || false);
  const [setupStep, setSetupStep] = useState('initial'); // initial, setup, verify, complete
  const [verificationCode, setVerificationCode] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [backupCodes, setBackupCodes] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Simulate 2FA setup process
  const handleEnable2FA = async () => {
    setIsProcessing(true);
    setSetupStep('setup');
    
    // Simulate QR code generation
    setTimeout(() => {
      setQrCodeUrl('https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=otpauth://totp/OrbitalBank:' + user.email + '?secret=JBSWY3DPEHPK3PXP&issuer=OrbitalBank');
      setIsProcessing(false);
    }, 1000);
  };

  const handleVerifyCode = async () => {
    if (verificationCode.length !== 6) return;
    
    setIsProcessing(true);
    
    // Simulate verification process
    setTimeout(async () => {
      if (verificationCode === '123456') { // Demo code
        setBackupCodes([
          'ABC123', 'DEF456', 'GHI789', 'JKL012', 'MNO345',
          'PQR678', 'STU901', 'VWX234', 'YZA567', 'BCD890'
        ]);
        setSetupStep('complete');
        setIsEnabled(true);
        
        // Update user in database
        await User.update(user.id, { mfa_enabled: true });
        onUpdate();
      } else {
        alert('Invalid verification code. Please try again.');
      }
      setIsProcessing(false);
    }, 1000);
  };

  const handleDisable2FA = async () => {
    setIsProcessing(true);
    await User.update(user.id, { mfa_enabled: false });
    setIsEnabled(false);
    setSetupStep('initial');
    setVerificationCode('');
    setIsProcessing(false);
    onUpdate();
  };

  return (
    <Card className="bg-[#0A0D18]/50 border-[#151823]">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-white">
          <Shield className="w-5 h-5 text-cyan-400" />
          <span>Two-Factor Authentication</span>
          {isEnabled && <Check className="w-4 h-4 text-green-400" />}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isEnabled ? (
          <>
            <p className="text-gray-400 text-sm">
              Add an extra layer of security to your Orbital Bank account by enabling two-factor authentication.
            </p>
            <div className="flex items-center space-x-3 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <Shield className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 text-sm">Recommended for enhanced security</span>
            </div>
            {setupStep === 'initial' && (
              <Button onClick={handleEnable2FA} disabled={isProcessing} className="orbital-button-primary">
                {isProcessing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Smartphone className="w-4 h-4 mr-2" />}
                Enable 2FA
              </Button>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <Check className="w-5 h-5 text-green-400" />
              <span className="text-green-400 text-sm">Two-factor authentication is enabled</span>
            </div>
            <Button onClick={handleDisable2FA} variant="outline" className="border-red-500/50 text-red-400 hover:bg-red-500/10">
              Disable 2FA
            </Button>
          </div>
        )}

        {setupStep === 'setup' && (
          <div className="space-y-4">
            <h3 className="text-white font-medium">Step 1: Scan QR Code</h3>
            <p className="text-gray-400 text-sm">
              Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
            </p>
            <div className="flex justify-center p-4 bg-white rounded-lg">
              <img src={qrCodeUrl} alt="2FA QR Code" className="w-48 h-48" />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-300">Enter verification code:</label>
              <Input
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="123456"
                className="bg-[#0C0F19] border-gray-600 text-center text-lg tracking-widest"
                maxLength={6}
              />
            </div>
            <Button 
              onClick={handleVerifyCode} 
              disabled={verificationCode.length !== 6 || isProcessing}
              className="orbital-button-primary w-full"
            >
              {isProcessing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : null}
              Verify & Enable
            </Button>
          </div>
        )}

        {setupStep === 'complete' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-green-400">
              <Check className="w-5 h-5" />
              <span className="font-medium">2FA Successfully Enabled!</span>
            </div>
            <div className="bg-gray-800/50 p-4 rounded-lg space-y-2">
              <h4 className="text-white font-medium flex items-center">
                <Key className="w-4 h-4 mr-2" />
                Backup Codes
              </h4>
              <p className="text-xs text-gray-400">
                Save these backup codes in a safe place. You can use them to access your account if you lose your authenticator device.
              </p>
              <div className="grid grid-cols-2 gap-2 font-mono text-sm">
                {backupCodes.map((code, i) => (
                  <span key={i} className="text-cyan-400">{code}</span>
                ))}
              </div>
            </div>
            <Button onClick={() => setSetupStep('initial')} className="orbital-button-secondary">
              Complete Setup
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}