import React from 'react';
import { useGlobalSystemHealth, useSectorThreatLevel } from '../lib/useCorrelatedData';
import { useRealtimeSystemHealth } from '../hooks/useRealtime';
import { Shield, Activity, AlertTriangle, TrendingUp, Globe, CheckCircle } from 'lucide-react';

export default function UnifiedStatusPanel({ selectedSectorId = null }) {
  const { health: globalHealth, loading: globalLoading } = useGlobalSystemHealth();
  const { threatLevel: sectorThreat, loading: threatLoading } = useSectorThreatLevel(selectedSectorId);
  const realtimeHealth = useRealtimeSystemHealth();

  // Combine real-time and calculated data
  const systemStatus = {
    health: realtimeHealth.status || globalHealth?.status || 'UNKNOWN',
    score: globalHealth?.overallScore || 0,
    activeAlerts: realtimeHealth.activeAlerts || globalHealth?.activeAlerts || 0,
    lastUpdate: realtimeHealth.lastCheck || new Date()
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'OPTIMAL': return 'text-green-400 border-green-500/30 bg-green-500/10';
      case 'STABLE': return 'text-blue-400 border-blue-500/30 bg-blue-500/10';
      case 'DEGRADED': return 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10';
      case 'CRITICAL': return 'text-red-400 border-red-500/30 bg-red-500/10';
      default: return 'text-gray-400 border-gray-500/30 bg-gray-500/10';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'OPTIMAL': return <CheckCircle className="w-5 h-5" />;
      case 'STABLE': return <Activity className="w-5 h-5" />;
      case 'DEGRADED': return <AlertTriangle className="w-5 h-5" />;
      case 'CRITICAL': return <Shield className="w-5 h-5" />;
      default: return <Globe className="w-5 h-5" />;
    }
  };

  if (globalLoading) {
    return (
      <div className="glass-pane p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-700/50 rounded"></div>
          <div className="h-4 bg-gray-700/50 rounded w-3/4"></div>
          <div className="h-16 bg-gray-700/50 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Global System Status */}
      <div className={`p-6 rounded-xl border-2 transition-all ${getStatusColor(systemStatus.health)}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            {getStatusIcon(systemStatus.health)}
            <div>
              <h3 className="text-lg font-semibold">Global System Status</h3>
              <p className="text-sm opacity-80">
                Overall Health: {systemStatus.health} ({systemStatus.score}%)
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{systemStatus.score}%</div>
            <div className="text-xs opacity-60">
              {systemStatus.activeAlerts} active alerts
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <div className="opacity-70">Sectors</div>
            <div className="font-semibold">{globalHealth?.sectors || 0}</div>
          </div>
          <div>
            <div className="opacity-70">Metrics</div>
            <div className="font-semibold">{globalHealth?.validatedMetrics || 0}</div>
          </div>
          <div>
            <div className="opacity-70">Last Update</div>
            <div className="font-semibold">
              {new Date(systemStatus.lastUpdate).toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>

      {/* Sector Threat Level (if sector selected) */}
      {selectedSectorId && (
        <div className="glass-pane p-6">
          {threatLoading ? (
            <div className="animate-pulse space-y-2">
              <div className="h-5 bg-gray-700/50 rounded w-1/2"></div>
              <div className="h-8 bg-gray-700/50 rounded w-3/4"></div>
            </div>
          ) : sectorThreat ? (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-white">Sector Threat Assessment</h4>
                <div className={`px-3 py-1 rounded-full text-sm font-medium border ${
                  sectorThreat.level === 'CRITICAL' ? 'border-red-500/30 bg-red-500/10 text-red-400' :
                  sectorThreat.level === 'HIGH' ? 'border-orange-500/30 bg-orange-500/10 text-orange-400' :
                  sectorThreat.level === 'MODERATE' ? 'border-yellow-500/30 bg-yellow-500/10 text-yellow-400' :
                  sectorThreat.level === 'LOW' ? 'border-blue-500/30 bg-blue-500/10 text-blue-400' :
                  'border-green-500/30 bg-green-500/10 text-green-400'
                }`}>
                  {sectorThreat.level}
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className={`text-3xl font-bold ${sectorThreat.color}`}>
                  {sectorThreat.score}
                </div>
                <div className="flex-1">
                  <div className="text-sm text-gray-400 mb-2">Threat Score</div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        sectorThreat.level === 'CRITICAL' ? 'bg-red-500' :
                        sectorThreat.level === 'HIGH' ? 'bg-orange-500' :
                        sectorThreat.level === 'MODERATE' ? 'bg-yellow-500' :
                        sectorThreat.level === 'LOW' ? 'bg-blue-500' :
                        'bg-green-500'
                      }`}
                      style={{ width: `${sectorThreat.score}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-400 py-8">
              <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No threat data available for this sector</p>
            </div>
          )}
        </div>
      )}

      {/* Top Risk Sectors */}
      {globalHealth?.sectorHealth && (
        <div className="glass-pane p-6">
          <h4 className="text-lg font-semibold text-white mb-4">Top Risk Sectors</h4>
          <div className="space-y-3">
            {globalHealth.sectorHealth
              .sort((a, b) => (b.alerts + b.risks) - (a.alerts + a.risks))
              .slice(0, 5)
              .map((sector) => (
                <div key={sector.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                  <div>
                    <div className="font-medium text-white">{sector.name}</div>
                    <div className="text-xs text-gray-400">
                      {sector.alerts} alerts • {sector.risks} risks
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-sm font-semibold ${
                      (sector.alerts + sector.risks) > 5 ? 'text-red-400' :
                      (sector.alerts + sector.risks) > 2 ? 'text-orange-400' :
                      'text-green-400'
                    }`}>
                      {sector.alerts + sector.risks > 0 ? 'MONITORING' : 'STABLE'}
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}