import React from 'react';
import { regions } from '../data/regions';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin } from 'lucide-react';

export default function RegionSelector({ 
  sector, 
  selectedRegion, 
  onRegionChange, 
  className = "" 
}) {
  const handleSelect = (regionCode) => {
    onRegionChange(regionCode);
  };

  const currentRegion = regions.find(r => r.code === selectedRegion);

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center space-x-2 text-sm">
        <MapPin className="w-4 h-4 text-gray-400" />
        <span className="text-gray-400 capitalize">{sector} Region:</span>
      </div>
      <Select value={selectedRegion} onValueChange={handleSelect}>
        <SelectTrigger className="bg-[#0C0F19] border-gray-600 text-white">
          <SelectValue>
            {currentRegion && (
              <div className="flex items-center space-x-2">
                <span className="text-lg">{currentRegion.flag}</span>
                <span>{currentRegion.name}</span>
              </div>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="bg-[#0C0F19] border-gray-600">
          {regions.map((region) => (
            <SelectItem 
              key={region.code} 
              value={region.code}
              className="text-white hover:bg-gray-800 focus:bg-gray-800"
            >
              <div className="flex items-center space-x-3">
                <span className="text-lg">{region.flag}</span>
                <span>{region.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}