import React from 'react';
import { Loader2, Globe, Shield, Zap } from 'lucide-react';

export const LoadingSpinner = ({ size = 'md', variant = 'default', message }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  };

  const SpinnerIcon = variant === 'globe' ? Globe : 
                     variant === 'shield' ? Shield :
                     variant === 'zap' ? Zap : Loader2;

  return (
    <div className="flex flex-col items-center justify-center space-y-3">
      <SpinnerIcon className={`${sizeClasses[size]} text-cyan-400 animate-spin`} />
      {message && (
        <p className="text-sm text-gray-400 animate-pulse">{message}</p>
      )}
    </div>
  );
};

export const PageLoader = ({ message = "Loading command interface..." }) => (
  <div className="min-h-screen bg-[#020409] flex items-center justify-center">
    <div className="text-center space-y-6">
      <div className="relative">
        <Globe className="w-16 h-16 text-cyan-400 mx-auto animate-spin" />
        <div className="absolute inset-0 w-16 h-16 border-2 border-cyan-400/20 rounded-full animate-pulse mx-auto"></div>
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-white">Global Command Center</h2>
        <p className="text-gray-400">{message}</p>
      </div>
      <div className="flex justify-center space-x-1">
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
      </div>
    </div>
  </div>
);

export const CardLoader = ({ lines = 3 }) => (
  <div className="glass-pane p-6 animate-pulse">
    <div className="space-y-4">
      <div className="h-6 bg-gray-700/50 rounded-md w-3/4"></div>
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="h-4 bg-gray-700/30 rounded w-full"></div>
      ))}
      <div className="h-4 bg-gray-700/30 rounded w-1/2"></div>
    </div>
  </div>
);

export const TableLoader = ({ rows = 5, columns = 4 }) => (
  <div className="glass-pane p-6">
    <div className="animate-pulse space-y-4">
      {/* Header */}
      <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
        {Array.from({ length: columns }).map((_, i) => (
          <div key={i} className="h-4 bg-gray-700/50 rounded"></div>
        ))}
      </div>
      
      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
          {Array.from({ length: columns }).map((_, colIndex) => (
            <div key={colIndex} className="h-3 bg-gray-700/30 rounded"></div>
          ))}
        </div>
      ))}
    </div>
  </div>
);

export const MetricsLoader = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    {Array.from({ length: 4 }).map((_, i) => (
      <div key={i} className="glass-pane p-6 animate-pulse">
        <div className="flex items-center justify-between mb-4">
          <div className="w-8 h-8 bg-gray-700/50 rounded-full"></div>
          <div className="w-4 h-4 bg-gray-700/30 rounded"></div>
        </div>
        <div className="h-8 bg-gray-700/50 rounded w-1/2 mb-2"></div>
        <div className="h-3 bg-gray-700/30 rounded w-3/4"></div>
      </div>
    ))}
  </div>
);

export const ChartLoader = ({ height = "h-64" }) => (
  <div className={`glass-pane p-6 animate-pulse ${height}`}>
    <div className="h-6 bg-gray-700/50 rounded w-1/4 mb-6"></div>
    <div className="flex items-end justify-between h-40 space-x-2">
      {Array.from({ length: 8 }).map((_, i) => (
        <div 
          key={i} 
          className="bg-gray-700/30 rounded-t w-full"
          style={{ height: `${Math.random() * 80 + 20}%` }}
        ></div>
      ))}
    </div>
  </div>
);

export default LoadingSpinner;