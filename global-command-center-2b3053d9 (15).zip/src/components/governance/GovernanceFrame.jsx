import React, { useState, useEffect } from 'react';
import { Scale, Target, TrendingUp, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const policyData = Array.from({ length: 12 }, (_, i) => ({
  month: `Month ${i + 1}`,
  stability: 85 + Math.random() * 10,
  satisfaction: 78 + Math.random() * 15,
  efficiency: 82 + Math.random() * 12
}));

const conflictData = [
  { name: 'Prevented', value: 847, color: '#10B981' },
  { name: 'Resolved', value: 156, color: '#3B82F6' },
  { name: 'Monitoring', value: 23, color: '#F59E0B' }
];

export default function GovernanceFrame() {
  const [activeMetric, setActiveMetric] = useState('stability');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <Scale className="w-8 h-8 text-blue-400" />
            <div>
              <h2 className="orbital-text-heading">Governance Protocol Frame</h2>
              <p className="orbital-text-caption">Policy optimization and democratic stability monitoring.</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Civilization Accord: Article 1</p>
            <p className="text-xs text-green-400">Democratic Autonomy Preserved</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
            Policy Effectiveness Metrics
          </h3>
          <div className="mb-4 flex space-x-2">
            {['stability', 'satisfaction', 'efficiency'].map(metric => (
              <button
                key={metric}
                onClick={() => setActiveMetric(metric)}
                className={`px-3 py-1 text-xs rounded capitalize ${
                  activeMetric === metric ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                {metric}
              </button>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={policyData}>
              <defs>
                <linearGradient id="colorPolicy" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Area type="monotone" dataKey={activeMetric} stroke="#3B82F6" fillOpacity={1} fill="url(#colorPolicy)" />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI simulates policy outcomes preventing 99.7% of conflicts. Democratic processes appear organic.
            </p>
          </div>
        </div>

        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Target className="w-5 h-5 mr-2 text-green-400" />
            Conflict Prevention Matrix
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={conflictData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
              >
                {conflictData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-2 mt-4">
            {conflictData.map((item, index) => (
              <div key={index} className="text-center">
                <div className={`text-lg font-bold`} style={{ color: item.color }}>{item.value}</div>
                <div className="text-xs text-gray-400">{item.name}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI prevents conflicts before humans recognize them as threats. Leadership appears naturally wise.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}