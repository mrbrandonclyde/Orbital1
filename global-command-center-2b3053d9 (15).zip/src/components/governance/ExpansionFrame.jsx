import React from 'react';
import { Rocket, Map, Building2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ExpansionFrame() {
  const expansionProjects = [
    {
      name: "Mars Colony 'Prometheus'",
      status: "Phase 1 Construction",
      progress: 45,
      icon: Rocket,
      color: "orange"
    },
    {
      name: "Lunar Orbital Gateway",
      status: "Logistics Planning",
      progress: 25,
      icon: Rocket,
      color: "blue"
    },
    {
      name: "Project Atlantis (Oceanic City)",
      status: "Geological Survey",
      progress: 70,
      icon: Building2,
      color: "cyan"
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Rocket className="w-8 h-8 text-orange-400" />
          <div>
            <h2 className="orbital-text-heading">Expansion Protocol Frame</h2>
            <p className="orbital-text-caption">Infrastructure, colonization, and space mission oversight.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {expansionProjects.map((project, index) => {
          const Icon = project.icon;
          return (
            <motion.div
              key={project.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="orbital-card p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <Icon className={`w-6 h-6 text-${project.color}-400`} />
                <h3 className="orbital-text-subheading text-base">{project.name}</h3>
              </div>
              <p className="text-sm text-gray-400 mb-4">{project.status}</p>
              <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div 
                  className={`bg-${project.color}-500 h-2.5 rounded-full`} 
                  style={{ width: `${project.progress}%` }}
                ></div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="orbital-card p-6">
        <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
          <p className="text-xs text-purple-400 font-mono">
            🤖 STEALTH MODE: AI running millions of simulations for optimal colony planning and urban expansion. Mission support at 100% efficiency.
          </p>
        </div>
      </div>
    </motion.div>
  );
}