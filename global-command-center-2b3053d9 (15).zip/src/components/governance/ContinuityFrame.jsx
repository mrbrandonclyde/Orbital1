
import React from 'react';
import { Repeat, Shield, Network } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ContinuityFrame() {
  const continuitySystems = [
    { 
      name: "Global Supply Chain", 
      status: "Shielded", 
      redundancy: "99.8%", 
      details: "AI rerouting active.",
      icon: Network
    },
    { 
      name: "Command & Control", 
      status: "Active", 
      redundancy: "100%", 
      details: "Decentralized backup online.",
      icon: Shield
    },
    { 
      name: "Mission Execution", 
      status: "Guaranteed", 
      redundancy: "99.9%", 
      details: "AI backup protocols ready.",
      icon: Repeat
    },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Repeat className="w-8 h-8 text-blue-400" />
          <div>
            <h2 className="orbital-text-heading">Continuity Protocol Frame</h2>
            <p className="orbital-text-caption">Crisis resilience, supply chain shielding, and mission backups.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {continuitySystems.map((system, index) => {
          const Icon = system.icon;
          return (
            <motion.div
              key={system.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="orbital-card p-6 text-center"
            >
              <Icon className="w-10 h-10 text-blue-400 mx-auto mb-4" />
              <h3 className="orbital-text-subheading text-base">{system.name}</h3>
              <p className="text-xl font-bold text-green-400 mb-2">{system.status}</p>
              <p className="text-sm text-gray-400">Redundancy: {system.redundancy}</p>
            </motion.div>
          );
        })}
      </div>

      <div className="orbital-card p-6">
        <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
          <p className="text-xs text-purple-400 font-mono">
            🤖 STEALTH MODE: AI Operations Guarantee ensures 100% mission continuity. Crisis resilience models are running constantly to shield all systems from failure.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
