import React, { useState, useEffect } from 'react';
import { Mission } from '@/api/entities';
import { User } from '@/api/entities';
import { logAuditEvent, AUDIT_ACTIONS } from '../lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MultiSelect } from '@/components/ui/multi-select';
import { Slider } from "@/components/ui/slider";
import { sectors } from '../data/regions';

const STATUSES = ['PLANNING', 'ACTIVE', 'COMPLETED', 'ABORTED'];
const PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

export default function MissionForm({ mission, onSuccess, initialCenter }) {
  const [formData, setFormData] = useState({
    mission_name: '',
    description: '',
    status: 'PLANNING',
    priority: 'MEDIUM',
    sector: 'defense',
    assigned_personnel: [],
    areaOfInterest: null,
  });
  const [radius, setRadius] = useState(500); // in km
  const [personnelOptions, setPersonnelOptions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (mission) {
      setFormData({
        mission_name: mission.mission_name || '',
        description: mission.description || '',
        status: mission.status || 'PLANNING',
        priority: mission.priority || 'MEDIUM',
        sector: mission.sector || 'defense',
        assigned_personnel: mission.assigned_personnel || [],
        areaOfInterest: mission.areaOfInterest || null,
      });
      if (mission.areaOfInterest?.type === 'Circle') {
        setRadius(mission.areaOfInterest.radius / 1000); // convert meters to km
      }
    }
  }, [mission]);

  useEffect(() => {
    User.list().then(users => {
      const options = users.map(u => ({ value: u.id, label: u.full_name }));
      setPersonnelOptions(options);
    });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    let aoiData = formData.areaOfInterest;
    if (initialCenter) {
      aoiData = {
        type: 'Circle',
        coordinates: [initialCenter.lat, initialCenter.lng],
        radius: radius * 1000, // store in meters
      };
      
      // Log AOI drawing
      await logAuditEvent(
        AUDIT_ACTIONS.AOI_DRAWN, 
        'AOI', 
        'NEW', 
        { 
          center: [initialCenter.lat, initialCenter.lng], 
          radius: radius,
          sector: formData.sector
        }
      );
    }

    const payload = { ...formData, areaOfInterest: aoiData };

    try {
      if (mission) {
        await Mission.update(mission.id, payload);
        await logAuditEvent(AUDIT_ACTIONS.MISSION_UPDATED, 'Mission', mission.id, {
          changes: payload,
          previousData: mission
        });
      } else {
        const newMission = await Mission.create(payload);
        await logAuditEvent(AUDIT_ACTIONS.MISSION_CREATED, 'Mission', newMission.id, {
          missionData: payload,
          personnelCount: payload.assigned_personnel.length
        });
        
        // Log personnel assignments
        if (payload.assigned_personnel.length > 0) {
          await logAuditEvent(
            AUDIT_ACTIONS.PERSONNEL_ASSIGNED,
            'Mission',
            newMission.id,
            {
              personnelIds: payload.assigned_personnel,
              missionName: payload.mission_name
            }
          );
        }
      }
      onSuccess();
    } catch (error) {
      console.error("Failed to save mission:", error);
      await logAuditEvent(
        `${mission ? 'MISSION_UPDATE' : 'MISSION_CREATE'}_FAILURE`,
        'Mission',
        mission?.id || 'NEW',
        { error: error.message, payload }
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 pt-4">
      <Input
        value={formData.mission_name}
        onChange={(e) => setFormData({ ...formData, mission_name: e.target.value })}
        placeholder="Mission Name / Codename"
        className="bg-[#0C0F19] border-gray-600"
        required
      />
      <Textarea
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
        placeholder="Mission objectives and description"
        className="bg-[#0C0F19] border-gray-600 h-24"
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>{PRIORITIES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={formData.sector} onValueChange={(v) => setFormData({ ...formData, sector: v })}>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Sector" /></SelectTrigger>
          <SelectContent>{sectors.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      
      {initialCenter && !mission && (
        <div className="space-y-3">
            <label className="text-sm font-medium text-gray-400">Area of Interest Radius</label>
            <div className="flex items-center space-x-4">
              <Slider
                value={[radius]}
                onValueChange={(val) => setRadius(val[0])}
                min={10}
                max={2000}
                step={10}
              />
              <span className="text-white font-semibold w-24 text-right">{radius} km</span>
            </div>
        </div>
      )}

      <div>
        <label className="text-sm font-medium text-gray-400">Assigned Personnel</label>
        <MultiSelect 
          options={personnelOptions}
          selected={formData.assigned_personnel}
          onChange={(selected) => setFormData({ ...formData, assigned_personnel: selected })}
          placeholder="Select personnel..."
        />
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onSuccess}>Cancel</Button>
        <Button type="submit" className="orbital-button-primary" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : (mission ? 'Update Mission' : 'Create Mission')}
        </Button>
      </div>
    </form>
  );
}