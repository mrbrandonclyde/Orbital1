import React, { useState, useCallback } from 'react';
import { SecurityAlert, SupplyChainRisk, BusinessSector, Company, GeopoliticalRegion, KnowledgeNode } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { BrainCircuit, Zap, Network } from 'lucide-react';
import { logAuditEvent, AUDIT_ACTIONS } from '../lib/audit';

export default function GlobalImpactQuery() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalysis = useCallback(async () => {
    if (!question.trim()) return;

    setIsAnalyzing(true);
    setAnswer('');

    try {
      // Gather comprehensive knowledge graph context
      const [alerts, risks, sectors, companies, regions, knowledgeNodes] = await Promise.all([
        SecurityAlert.list('-created_date', 20),
        SupplyChainRisk.list('-last_assessment_date', 20), 
        BusinessSector.list(),
        Company.list(),
        GeopoliticalRegion.list(),
        KnowledgeNode.list()
      ]);

      const comprehensiveContext = {
        recent_security_alerts: alerts,
        supply_chain_risks: risks,
        business_sectors: sectors,
        major_companies: companies,
        geopolitical_regions: regions,
        knowledge_graph_nodes: knowledgeNodes,
        query_timestamp: new Date().toISOString()
      };

      const prompt = `You are ORACLE, an advanced AI geopolitical and economic intelligence system with access to a comprehensive Global Knowledge Graph covering all major sectors, companies, regions, and their interdependencies.

SCENARIO ANALYSIS REQUEST:
"${question}"

GLOBAL KNOWLEDGE GRAPH DATA:
${JSON.stringify(comprehensiveContext, null, 2)}

ANALYSIS INSTRUCTIONS:
1. Parse the scenario to identify key entities (companies, sectors, regions)
2. Trace direct and indirect relationships using the knowledge graph data
3. Calculate cascading effects across multiple degrees of separation
4. Assess probability and impact severity based on historical patterns
5. Provide strategic recommendations for mitigation

RESPONSE FORMAT (MANDATORY):

### 🌐 ORACLE GLOBAL IMPACT ANALYSIS

**SCENARIO:** ${question}

**🎯 EXECUTIVE SUMMARY**
[2-3 sentences summarizing the most critical findings]

**⚡ IMMEDIATE IMPACTS (0-30 days)**
• **Primary Effect:** [Direct, first-order impact]
• **Secondary Effect:** [Immediate cascading effect]  
• **Tertiary Effect:** [Unexpected consequence]

**📈 CASCADING EFFECTS (1-12 months)**
• **Economic:** [GDP, market, trade impacts]
• **Geopolitical:** [International relations, policy impacts]
• **Technological:** [Innovation, supply chain, infrastructure impacts]

**🏢 AFFECTED ENTITIES**
• **Companies:** [List top 5 most impacted companies from knowledge graph]
• **Sectors:** [List top 3 most impacted sectors with impact %]
• **Regions:** [List top 3 most impacted regions]

**🔗 CRITICAL DEPENDENCIES IDENTIFIED**  
[Key supply chains, relationships, or infrastructure at risk]

**📊 RISK ASSESSMENT**
• **Probability:** [High/Medium/Low with reasoning]
• **Impact Severity:** [Critical/High/Medium/Low with reasoning] 
• **Recovery Timeline:** [Estimated time to normalize]

**🛡️ STRATEGIC RECOMMENDATIONS**
1. **Immediate Actions:** [0-30 days]
2. **Short-term Strategy:** [1-6 months]
3. **Long-term Resilience:** [6+ months]

**🔍 CONFIDENCE LEVEL:** [High/Medium/Low] - Based on data completeness and relationship clarity

Ensure all analysis is grounded in the provided knowledge graph data and focus on actionable intelligence for decision-makers.`;

      const analysisResult = await InvokeLLM({ prompt });
      setAnswer(analysisResult);
      
      await logAuditEvent(
        AUDIT_ACTIONS.REPORT_GENERATED,
        'ORACLE_ANALYSIS', 
        'KNOWLEDGE_GRAPH_QUERY',
        { 
          question,
          entities_analyzed: {
            companies: companies.length,
            regions: regions.length, 
            knowledge_nodes: knowledgeNodes.length
          }
        }
      );

    } catch (error) {
      console.error("ORACLE analysis failed:", error);
      setAnswer("🚨 ORACLE SYSTEM ERROR: Unable to complete knowledge graph analysis. Please verify system connectivity and try again.");
    } finally {
      setIsAnalyzing(false);
    }
  }, [question]);

  const quickQueries = [
    "What happens if China restricts rare earth mineral exports?",
    "Impact of a major cyberattack on US financial sector?",
    "How would Texas energy grid failure affect semiconductor supply?",
    "What are the cascading effects of a Taiwan Strait conflict?",
    "Impact of California port strike on global supply chains?"
  ];

  return (
    <div className="bg-gray-800/30 border border-gray-700 rounded-lg p-6 space-y-4">
      <div className="flex items-center space-x-3">
        <Network className="w-6 h-6 text-indigo-400" />
        <h3 className="text-lg font-semibold text-white">ORACLE Global Impact Analysis Engine</h3>
        <span className="px-2 py-1 bg-indigo-500/20 text-indigo-300 text-xs rounded border border-indigo-500/30">
          KNOWLEDGE GRAPH ENABLED
        </span>
      </div>
      
      {/* Quick Query Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-4">
        {quickQueries.map((query, index) => (
          <button
            key={index}
            onClick={() => setQuestion(query)}
            className="text-left text-sm p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded border border-gray-600 text-gray-300 transition-colors"
          >
            {query}
          </button>
        ))}
      </div>
      
      <Textarea
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Ask ORACLE a strategic scenario question..."
        className="bg-[#0C0F19] border-gray-600 text-white min-h-[80px]"
        rows={3}
      />
      
      <Button
        onClick={handleAnalysis}
        disabled={isAnalyzing || !question.trim()}
        className="w-full orbital-button-primary"
      >
        {isAnalyzing ? (
          <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />ORACLE ANALYZING...</>
        ) : (
          <><Zap className="w-4 h-4 mr-2" />ENGAGE ORACLE ANALYSIS</>
        )}
      </Button>

      {answer && (
        <div className="prose prose-invert max-w-none text-gray-300 bg-[#060810] p-4 rounded-md border border-gray-700">
          <pre className="whitespace-pre-wrap font-sans text-sm">{answer}</pre>
        </div>
      )}
    </div>
  );
}