import React from 'react';
import { User, Shield, Building2, Mail, Calendar, Edit } from 'lucide-react';

const clearanceColors = {
  'CONFIDENTIAL': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'SECRET': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  'TOP_SECRET': 'bg-red-500/10 text-red-400 border-red-500/20'
};

const roleColors = {
  'Analyst': 'bg-gray-500/10 text-gray-400',
  'Senior Analyst': 'bg-indigo-500/10 text-indigo-400',
  'Sector Chief': 'bg-purple-500/10 text-purple-400',
  'Director': 'bg-orange-500/10 text-orange-400',
  'Executive': 'bg-red-500/10 text-red-400',
  'Administrator': 'bg-green-500/10 text-green-400'
};

export default function UserCard({ user, sectors, onEdit }) {
  const userSectors = sectors.filter(s => user.assigned_sectors?.includes(s.id));
  
  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 hover:border-indigo-500/50 transition-all">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-lg">
            {user.full_name?.charAt(0) || 'U'}
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white">{user.full_name}</h3>
            <p className="text-gray-400 text-sm">{user.title}</p>
          </div>
        </div>
        <button 
          onClick={() => onEdit(user)}
          className="orbital-button-secondary text-sm flex items-center space-x-2"
        >
          <Edit size={14} />
          <span>Edit</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center space-x-2 text-sm">
          <Mail className="w-4 h-4 text-gray-500" />
          <span className="text-gray-300">{user.email}</span>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Building2 className="w-4 h-4 text-gray-500" />
          <span className="text-gray-300">{user.team}</span>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Calendar className="w-4 h-4 text-gray-500" />
          <span className="text-gray-300">
            Joined {new Date(user.created_date).toLocaleDateString()}
          </span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${roleColors[user.role] || 'bg-gray-500/10 text-gray-400'}`}>
          {user.role}
        </span>
        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${clearanceColors[user.security_clearance] || 'bg-gray-500/10 text-gray-400 border-gray-500/20'}`}>
          <Shield className="w-3 h-3 inline mr-1" />
          {user.security_clearance}
        </span>
      </div>

      {userSectors.length > 0 && (
        <div>
          <p className="text-sm text-gray-500 mb-2">Assigned Sectors:</p>
          <div className="flex flex-wrap gap-2">
            {userSectors.map(sector => (
              <span key={sector.id} className="px-2 py-1 bg-indigo-500/10 text-indigo-300 rounded text-xs">
                {sector.sector_name}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}