import React from "react";

export default function StepConfirm({ summary }) {
  const { type, goal, template, form } = summary;
  const tags = (form.tags || "").split(",").map(t => t.trim()).filter(Boolean);
  return (
    <div className="space-y-4 text-gray-300">
      <div className="bg-gray-800/30 rounded-xl p-4">
        <div className="text-white font-semibold mb-2">Overview</div>
        <ul className="text-sm space-y-1">
          <li><span className="text-gray-400">Type:</span> {type}</li>
          <li><span className="text-gray-400">Goal:</span> {goal || "—"}</li>
          <li><span className="text-gray-400">Template:</span> {template?.template_name || "None"}</li>
          <li><span className="text-gray-400">Name:</span> {form.name || "Untitled"}</li>
          <li><span className="text-gray-400">Campaign:</span> {form.campaign || "—"}</li>
          <li><span className="text-gray-400">Private:</span> {form.is_private ? "Yes" : "No"}</li>
          <li><span className="text-gray-400">Tags:</span> {tags.length ? tags.join(", ") : "—"}</li>
        </ul>
      </div>
      <div className="bg-gray-800/30 rounded-xl p-4">
        <div className="text-white font-semibold mb-2">What happens next</div>
        <ol className="list-decimal list-inside text-sm space-y-1">
          <li>We’ll create your funnel and scaffold steps from the selected template.</li>
          <li>You’ll be redirected to the Drag & Drop Builder to customize pages.</li>
        </ol>
      </div>
    </div>
  );
}