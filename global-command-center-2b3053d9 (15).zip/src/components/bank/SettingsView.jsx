import React from 'react';
import ProfileSettings from './ProfileSettings';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Bell, Lock, Globe } from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function SettingsView() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-white">Bank Settings</h1>
        <p className="text-gray-400 mt-1">Configure your Orbital Bank preferences and security.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <ProfileSettings />
        </div>
        <div className="space-y-6">
          <Card className="glass-pane">
            <CardHeader>
              <CardTitle className="text-white flex items-center"><Bell className="w-5 h-5 mr-2 text-yellow-400" /> Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="large-transactions" className="text-gray-300">Large Transactions</Label>
                <Switch id="large-transactions" checked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="login-alerts" className="text-gray-300">New Device Login</Label>
                <Switch id="login-alerts" checked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="monthly-summary" className="text-gray-300">Monthly Summary</Label>
                <Switch id="monthly-summary" />
              </div>
            </CardContent>
          </Card>
          <Card className="glass-pane">
            <CardHeader>
              <CardTitle className="text-white flex items-center"><Lock className="w-5 h-5 mr-2 text-red-400"/> Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="2fa" className="text-gray-300">Two-Factor Auth</Label>
                <Switch id="2fa" checked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="biometric" className="text-gray-300">Biometric Login</Label>
                <Switch id="biometric" checked />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}