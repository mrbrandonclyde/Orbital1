import React, { useState } from 'react';
import { User } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User as UserIcon, Mail, Shield, Save } from 'lucide-react';

export default function ProfileSettings() {
  const [user, setUser] = useState({ name: 'John Doe', email: 'john.doe@example.com' });
  const [status, setStatus] = useState('');

  const handleProfileChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSaveChanges = async () => {
    setStatus('Saving...');
    // In a real app, you'd call User.updateMyUserData(user)
    await new Promise(resolve => setTimeout(resolve, 1000));
    setStatus('Profile saved successfully!');
    setTimeout(() => setStatus(''), 3000);
  };

  return (
    <Card className="glass-pane">
      <CardHeader>
        <CardTitle className="text-white flex items-center"><UserIcon className="w-5 h-5 mr-2 text-cyan-400"/> User Profile</CardTitle>
        <p className="text-sm text-gray-400">Manage your personal information and account settings.</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-gray-300">Full Name</Label>
          <Input id="name" name="name" value={user.name} onChange={handleProfileChange} className="bg-[#0C0F19] border-gray-600" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email" className="text-gray-300">Email Address</Label>
          <Input id="email" name="email" type="email" value={user.email} onChange={handleProfileChange} className="bg-[#0C0F19] border-gray-600" />
        </div>
        <div className="space-y-2">
          <Label className="text-gray-300">Password</Label>
          <Button variant="outline" className="w-full text-cyan-400 border-cyan-500/50 hover:bg-cyan-500/10 hover:text-cyan-300">
            <Shield className="w-4 h-4 mr-2"/>
            Change Password
          </Button>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <p className="text-sm text-green-400">{status}</p>
        <Button onClick={handleSaveChanges} className="orbital-button-primary">
          <Save className="w-4 h-4 mr-2"/>
          Save Changes
        </Button>
      </CardFooter>
    </Card>
  );
}