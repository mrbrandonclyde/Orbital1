import React from "react";
import { Badge } from "@/components/ui/badge";
import { Building2, Mail, Phone, Tag } from "lucide-react";

export default function ContactCard({ contact, onOpen }) {
  return (
    <div
      className="p-3 rounded-lg border border-gray-800 bg-[#0A0D18]/60 hover:border-cyan-500/30 cursor-pointer"
      onClick={() => onOpen(contact)}
    >
      <div className="flex items-center justify-between">
        <div className="text-white font-semibold">
          {(contact.first_name || "") + " " + (contact.last_name || "")}
        </div>
        <Badge className="bg-gray-700/50 text-gray-300">{contact.lead_score ?? 0}</Badge>
      </div>
      {contact.company && (
        <div className="text-xs text-gray-400 flex items-center gap-1 mt-1">
          <Building2 className="w-3 h-3" /> {contact.company}
        </div>
      )}
      <div className="text-xs text-gray-400 mt-1 flex items-center gap-2">
        {contact.email && (<span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {contact.email}</span>)}
        {contact.phone && (<span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {contact.phone}</span>)}
      </div>
      {!!(contact.tags || []).length && (
        <div className="mt-2 flex flex-wrap gap-1">
          {contact.tags.slice(0, 3).map((t, i) => (
            <Badge key={i} className="bg-purple-500/20 text-purple-300 flex items-center gap-1">
              <Tag className="w-3 h-3" /> {t}
            </Badge>
          ))}
          {contact.tags.length > 3 && <span className="text-xs text-gray-500">+{contact.tags.length - 3}</span>}
        </div>
      )}
    </div>
  );
}