import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon, StickyNote, Check } from "lucide-react";
import { ContactNote } from "@/api/entities";
import { ContactReminder } from "@/api/entities";

export default function ContactProfile({ open, onOpenChange, contact, onContactChange }) {
  const [notes, setNotes] = React.useState([]);
  const [reminders, setReminders] = React.useState([]);
  const [newNote, setNewNote] = React.useState("");
  const [newReminder, setNewReminder] = React.useState({ text: "", remind_at: "" });

  React.useEffect(() => {
    (async () => {
      if (!contact?.id) { setNotes([]); setReminders([]); return; }
      const [n, r] = await Promise.all([
        ContactNote.filter({ contact_id: contact.id }, "-created_date", 100),
        ContactReminder.filter({ contact_id: contact.id }, "-remind_at", 100)
      ]);
      setNotes(n);
      setReminders(r);
    })();
  }, [contact?.id]);

  const addNote = async () => {
    if (!newNote.trim() || !contact?.id) return;
    await ContactNote.create({ contact_id: contact.id, content: newNote, timestamp: new Date().toISOString() });
    setNewNote("");
    const n = await ContactNote.filter({ contact_id: contact.id }, "-created_date", 100);
    setNotes(n);
    onContactChange && onContactChange({ notes_count: (contact.notes_count || 0) + 1 });
  };

  const addReminder = async () => {
    if (!newReminder.text.trim() || !newReminder.remind_at || !contact?.id) return;
    await ContactReminder.create({ contact_id: contact.id, text: newReminder.text, remind_at: newReminder.remind_at, status: "open" });
    setNewReminder({ text: "", remind_at: "" });
    const r = await ContactReminder.filter({ contact_id: contact.id }, "-remind_at", 100);
    setReminders(r);
  };

  const completeReminder = async (rem) => {
    await ContactReminder.update(rem.id, { status: "done" });
    const r = await ContactReminder.filter({ contact_id: contact.id }, "-remind_at", 100);
    setReminders(r);
  };

  if (!contact) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl bg-[#0A0D18] border border-gray-800">
        <DialogHeader>
          <DialogTitle className="text-white">
            {(contact.first_name || "") + " " + (contact.last_name || "")}
            {" "}
            <span className="text-sm text-gray-400">{contact.email || ""}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {(contact.tags || []).map((t, i) => <Badge key={i} className="bg-purple-500/20 text-purple-300">{t}</Badge>)}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="text-white font-semibold mb-2 flex items-center gap-2">
                <StickyNote className="w-4 h-4 text-cyan-400" /> Notes
              </div>
              <div className="space-y-2 max-h-64 overflow-auto">
                {notes.map(n => (
                  <div key={n.id} className="p-2 bg-gray-800/40 rounded border border-gray-700 text-sm text-gray-200">
                    <div className="text-xs text-gray-400 mb-1">{new Date(n.timestamp || n.created_date).toLocaleString()}</div>
                    {n.content}
                  </div>
                ))}
                {!notes.length && <div className="text-xs text-gray-500">No notes yet.</div>}
              </div>
              <div className="mt-2 space-y-2">
                <Textarea placeholder="Add a note..." className="bg-[#0C0F19] border-gray-700 text-gray-100" value={newNote} onChange={e => setNewNote(e.target.value)} />
                <Button size="sm" onClick={addNote} className="bg-indigo-600 hover:bg-indigo-700">Add Note</Button>
              </div>
            </div>

            <div>
              <div className="text-white font-semibold mb-2 flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-cyan-400" /> Reminders
              </div>
              <div className="space-y-2 max-h-64 overflow-auto">
                {reminders.map(r => (
                  <div key={r.id} className="p-2 bg-gray-800/40 rounded border border-gray-700 text-sm text-gray-200 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-gray-400">{new Date(r.remind_at).toLocaleString()}</div>
                      <div>{r.text}</div>
                    </div>
                    {r.status !== "done" && (
                      <Button size="sm" variant="secondary" onClick={() => completeReminder(r)}>
                        <Check className="w-4 h-4 mr-1" /> Done
                      </Button>
                    )}
                  </div>
                ))}
                {!reminders.length && <div className="text-xs text-gray-500">No reminders yet.</div>}
              </div>
              <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2">
                <Input type="datetime-local" className="bg-[#0C0F19] border-gray-700 text-gray-100 md:col-span-1" value={newReminder.remind_at} onChange={e => setNewReminder({ ...newReminder, remind_at: e.target.value })} />
                <Input placeholder="Reminder text" className="bg-[#0C0F19] border-gray-700 text-gray-100 md:col-span-2" value={newReminder.text} onChange={e => setNewReminder({ ...newReminder, text: e.target.value })} />
              </div>
              <div className="mt-2">
                <Button size="sm" variant="secondary" onClick={addReminder}>Add Reminder</Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}