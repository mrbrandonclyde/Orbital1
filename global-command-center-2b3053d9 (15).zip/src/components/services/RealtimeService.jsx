// Mock Realtime Service to simulate WebSocket-like functionality
// This prevents errors in components that rely on real-time data hooks.

class RealtimeService {
  constructor() {
    this.channels = {};
    this.connectionListeners = new Set();
    this.isConnected = false;
    this.reconnectAttempts = 0;

    this.connect();
  }

  connect() {
    setTimeout(() => {
      this.isConnected = true;
      this.reconnectAttempts = 0;
      this.notifyConnectionChange();
      console.log('Mock Realtime Service: Connected');
      this.simulateData();
    }, 1000);
  }

  disconnect() {
    this.isConnected = false;
    this.notifyConnectionChange();
    console.log('Mock Realtime Service: Disconnected');
  }

  getConnectionStatus() {
    return {
      isConnected: this.isConnected,
      reconnectAttempts: this.reconnectAttempts,
    };
  }

  onConnectionChange(callback) {
    this.connectionListeners.add(callback);
    // Immediately notify with current status
    callback(this.isConnected);
    
    return () => {
      this.connectionListeners.delete(callback);
    };
  }

  notifyConnectionChange() {
    this.connectionListeners.forEach(listener => listener(this.isConnected));
  }

  subscribe(channel, callback) {
    if (!this.channels[channel]) {
      this.channels[channel] = new Set();
    }
    this.channels[channel].add(callback);
    console.log(`Mock Realtime Service: Subscribed to ${channel}`);
    
    return () => {
      this.channels[channel]?.delete(callback);
      console.log(`Mock Realtime Service: Unsubscribed from ${channel}`);
    };
  }

  publish(channel, data) {
    if (this.channels[channel]) {
      this.channels[channel].forEach(callback => callback(data));
    }
  }

  // --- MOCK DATA SIMULATION ---
  simulateData() {
    setInterval(() => {
      if (!this.isConnected) return;

      // Simulate system metrics
      this.publish('metrics', {
        systemLoad: Math.random() * 100,
        threatLevel: Math.random() * 100,
        operationalStatus: 'OPERATIONAL',
      });

      // Simulate alerts
      this.publish('alerts', {
        newAlerts: Math.floor(Math.random() * 5),
        criticalCount: Math.floor(Math.random() * 10),
        totalActive: 20 + Math.floor(Math.random() * 30),
      });

    }, 3000); // Publish new data every 3 seconds
  }
}

// Export a singleton instance
const realtimeService = new RealtimeService();
export default realtimeService;