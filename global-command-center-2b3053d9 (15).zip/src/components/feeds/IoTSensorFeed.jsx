import React, { useState, useEffect } from 'react';
import { IoTSensor } from '@/api/entities';
import { useLiveData } from '../lib/useLiveData';
import { Cpu, Thermometer, Droplets, Zap, AlertTriangle, CheckCircle } from 'lucide-react';

export default function IoTSensorFeed({ supplyChainNode = 'all' }) {
  const [sensors, setSensors] = useState([]);
  const iotUpdate = useLiveData('iot', 'global', 'sensor:update');

  // Generate mock IoT sensor data
  useEffect(() => {
    const mockSensors = [
      {
        sensor_id: 'TEMP_001',
        device_type: 'TEMPERATURE',
        location: { facility_name: 'Shanghai Container Port', latitude: 31.2304, longitude: 121.4737 },
        supply_chain_node: 'SHIPPING_HUB',
        current_reading: { value: 24.5, unit: '°C', timestamp: new Date().toISOString(), quality_score: 98 },
        thresholds: { min_warning: 0, max_warning: 30, min_critical: -5, max_critical: 35 },
        battery_level: 87,
        connectivity_status: 'ONLINE'
      },
      {
        sensor_id: 'GPS_002',
        device_type: 'GPS_TRACKER',
        location: { facility_name: 'Suez Canal Transit', latitude: 30.5852, longitude: 32.2654 },
        supply_chain_node: 'TRANSPORTATION',
        current_reading: { value: 12.3, unit: 'km/h', timestamp: new Date().toISOString(), quality_score: 95 },
        battery_level: 45,
        connectivity_status: 'ONLINE'
      },
      {
        sensor_id: 'VIBR_003',
        device_type: 'VIBRATION',
        location: { facility_name: 'Critical Infrastructure Facility', latitude: 40.7128, longitude: -74.0060 },
        supply_chain_node: 'CRITICAL_INFRASTRUCTURE',
        current_reading: { value: 2.8, unit: 'mm/s', timestamp: new Date().toISOString(), quality_score: 92 },
        thresholds: { min_warning: 0, max_warning: 5, min_critical: 0, max_critical: 10 },
        battery_level: 12,
        connectivity_status: 'INTERMITTENT'
      }
    ];
    setSensors(mockSensors);
  }, []);

  // Update with live data when available
  useEffect(() => {
    if (iotUpdate) {
      setSensors(prev => {
        const updated = [...prev];
        const existingIndex = updated.findIndex(s => s.sensor_id === iotUpdate.sensor_id);
        if (existingIndex >= 0) {
          updated[existingIndex] = { ...updated[existingIndex], ...iotUpdate };
        } else {
          updated.push(iotUpdate);
        }
        return updated;
      });
    }
  }, [iotUpdate]);

  const getSensorIcon = (type) => {
    switch (type) {
      case 'TEMPERATURE': return <Thermometer className="w-4 h-4 text-red-400" />;
      case 'HUMIDITY': return <Droplets className="w-4 h-4 text-blue-400" />;
      case 'GPS_TRACKER': return <Zap className="w-4 h-4 text-green-400" />;
      case 'VIBRATION': return <Cpu className="w-4 h-4 text-purple-400" />;
      default: return <Cpu className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ONLINE': return 'text-green-400';
      case 'INTERMITTENT': return 'text-yellow-400';
      case 'OFFLINE': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getBatteryColor = (level) => {
    if (level > 50) return 'text-green-400';
    if (level > 20) return 'text-yellow-400';
    return 'text-red-400';
  };

  const isReadingCritical = (sensor) => {
    const value = sensor.current_reading?.value;
    const thresholds = sensor.thresholds;
    if (!value || !thresholds) return false;
    return value <= thresholds.min_critical || value >= thresholds.max_critical;
  };

  const isReadingWarning = (sensor) => {
    const value = sensor.current_reading?.value;
    const thresholds = sensor.thresholds;
    if (!value || !thresholds) return false;
    return value <= thresholds.min_warning || value >= thresholds.max_warning;
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Cpu className="w-6 h-6 text-green-400" />
          <h3 className="text-xl font-semibold text-white">IoT Sensor Network</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-gray-400">Real-time Telemetry</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {sensors.map((sensor) => (
          <div key={sensor.sensor_id} className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 transition-all">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center space-x-2">
                {getSensorIcon(sensor.device_type)}
                <div>
                  <h4 className="font-medium text-white">{sensor.sensor_id}</h4>
                  <p className="text-xs text-gray-400">{sensor.location?.facility_name}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {sensor.connectivity_status === 'ONLINE' ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                )}
                <span className={`text-xs font-medium ${getStatusColor(sensor.connectivity_status)}`}>
                  {sensor.connectivity_status}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-gray-400">Current Reading:</span>
                <div className="flex items-center space-x-1 mt-1">
                  <span className={`font-mono text-lg ${
                    isReadingCritical(sensor) ? 'text-red-400' :
                    isReadingWarning(sensor) ? 'text-yellow-400' : 'text-white'
                  }`}>
                    {sensor.current_reading?.value}
                  </span>
                  <span className="text-gray-400">{sensor.current_reading?.unit}</span>
                </div>
              </div>
              
              <div>
                <span className="text-gray-400">Battery Level:</span>
                <div className="flex items-center space-x-1 mt-1">
                  <span className={`font-medium ${getBatteryColor(sensor.battery_level)}`}>
                    {sensor.battery_level}%
                  </span>
                  <div className="w-8 h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all ${
                        sensor.battery_level > 50 ? 'bg-green-400' :
                        sensor.battery_level > 20 ? 'bg-yellow-400' : 'bg-red-400'
                      }`}
                      style={{ width: `${sensor.battery_level}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div>
                <span className="text-gray-400">Supply Chain Node:</span>
                <div className="text-white mt-1">{sensor.supply_chain_node?.replace('_', ' ')}</div>
              </div>

              <div>
                <span className="text-gray-400">Quality Score:</span>
                <div className="text-white mt-1">{sensor.current_reading?.quality_score}%</div>
              </div>
            </div>

            {(isReadingCritical(sensor) || isReadingWarning(sensor) || sensor.battery_level < 20) && (
              <div className="mt-2 flex items-center space-x-2 text-xs">
                <AlertTriangle className="w-3 h-3 text-orange-400" />
                <span className="text-orange-400">
                  {isReadingCritical(sensor) ? 'Critical threshold exceeded' :
                   isReadingWarning(sensor) ? 'Warning threshold exceeded' :
                   'Low battery level'}
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 text-xs text-gray-500 text-center">
        Monitoring {sensors.length} sensors • {sensors.filter(s => s.connectivity_status === 'ONLINE').length} online
      </div>
    </div>
  );
}