import { useEffect, useRef } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';

const statusToColor = (status) => {
  switch (status) {
    case 0: return '#10B981'; // Green: Stable
    case 1: return '#F59E0B'; // Yellow: Warning
    case 2: return '#EF4444'; // Red: Critical
    default: return '#4B5563'; // Gray: No data
  }
};

export default function ChoroplethLayer({ geoJsonData, statuses, isoToRegionCode, geoKey = 'id' }) {
  const map = useMap();
  const layerRef = useRef(null);

  useEffect(() => {
    if (!geoJsonData) return;

    // Remove old layer if it exists
    if (layerRef.current) {
      map.removeLayer(layerRef.current);
    }
    
    // Check if GeoJSON has features with geometry
    const hasGeometry = geoJsonData.features && geoJsonData.features.some(f => f.geometry && f.geometry.coordinates && f.geometry.coordinates.length > 0);
    
    if (!hasGeometry) {
      console.warn("GeoJSON data is missing geometry. Rendering mock data.");
      // Create a mock layer if geometry is missing
      const mockLayer = L.layerGroup();
      Object.entries(statuses).forEach(([regionCode, status]) => {
          const center = L.latLng(Math.random() * 100 - 50, Math.random() * 260 - 130);
          mockLayer.addLayer(L.circle(center, {
              radius: 500000,
              color: statusToColor(status),
              fillOpacity: 0.7
          }).bindPopup(`Mock: ${regionCode} - Status: ${status}`));
      });
      mockLayer.addTo(map);
      layerRef.current = mockLayer;
      
      return () => {
        if (layerRef.current) map.removeLayer(layerRef.current);
      }
    }

    const geoJsonLayer = L.geoJSON(geoJsonData, {
      style: (feature) => {
        const regionIso = feature.properties[geoKey] || feature.id;
        const regionCode = isoToRegionCode[regionIso];
        const status = statuses[regionCode];
        return {
          fillColor: statusToColor(status),
          weight: 1,
          opacity: 1,
          color: 'white',
          dashArray: '3',
          fillOpacity: 0.7
        };
      },
      onEachFeature: (feature, layer) => {
        const regionIso = feature.properties[geoKey] || feature.id;
        const regionCode = isoToRegionCode[regionIso];
        const status = statuses[regionCode];
        const statusText = status === 0 ? 'Stable' : status === 1 ? 'Warning' : status === 2 ? 'Critical' : 'No Data';
        
        layer.bindPopup(`
          <div class="p-1">
            <h3 class="font-bold text-base">${feature.properties.name}</h3>
            <p class="text-sm">Region Code: <strong>${regionCode || 'N/A'}</strong></p>
            <p class="text-sm">Status: <strong style="color: ${statusToColor(status)}">${statusText}</strong></p>
          </div>
        `);
      }
    });

    geoJsonLayer.addTo(map);
    layerRef.current = geoJsonLayer;

    // Cleanup function
    return () => {
      if (layerRef.current) {
        map.removeLayer(layerRef.current);
      }
    };
  }, [map, geoJsonData, statuses, isoToRegionCode, geoKey]);

  return null;
}