import React, { Suspense, useMemo, useState, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars, Html, Text } from '@react-three/drei';
import * as THREE from 'three';
import { useQuery } from '../lib/useQuery';
import { Company, GeopoliticalRegion, SecurityAlert, SupplyChainRisk } from '@/api/entities';
import { regions as regionData } from '../data/regions';

// --- Helper Functions ---
const latLonToVector3 = (lat, lon, radius) => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

const regionLookup = Object.fromEntries(regionData.map(r => [r.name.toLowerCase(), r]));
const codeLookup = Object.fromEntries(regionData.map(r => [r.code.toLowerCase(), r]));

// --- 3D Components ---
function Globe() {
  return (
    <mesh>
      <sphereGeometry args={[5, 64, 64]} />
      <meshStandardMaterial color="#0b1a4a" roughness={0.8} metalness={0.2} />
    </mesh>
  );
}

function AlertNode({ alert, index }) {
  const ref = useRef();
  const radius = 6 + Math.random();
  const speed = 0.005 + Math.random() * 0.005;

  useFrame(({ clock }) => {
    const time = clock.getElapsedTime();
    const angle = time * speed + index * Math.PI / 4;
    ref.current.position.x = radius * Math.cos(angle);
    ref.current.position.z = radius * Math.sin(angle);
    ref.current.position.y = Math.sin(angle * 2) * 1;
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.08, 16, 16]} />
      <meshStandardMaterial color="red" emissive="red" emissiveIntensity={3} />
    </mesh>
  );
}

function RegionNode({ position, name }) {
    const [hovered, setHover] = useState(false);
    return (
        <mesh 
            position={position}
            onPointerOver={() => setHover(true)}
            onPointerOut={() => setHover(false)}
        >
            <sphereGeometry args={[0.05, 32, 32]} />
            <meshStandardMaterial 
                color={hovered ? 'cyan' : 'white'} 
                emissive={hovered ? 'cyan' : 'white'} 
                emissiveIntensity={hovered ? 2 : 0.5} 
            />
            {hovered && (
                 <Html distanceFactor={10}>
                    <div className="bg-black/50 text-white text-xs p-1 rounded">
                        {name}
                    </div>
                </Html>
            )}
        </mesh>
    );
}

function SceneContent() {
  const { data, loading } = useQuery(async () => {
    const [regions, alerts] = await Promise.all([
      GeopoliticalRegion.list(),
      SecurityAlert.filter({ alert_status: "ACTIVE" })
    ]);
    return { regions, alerts };
  });

  const nodes = useMemo(() => {
    if (!data) return [];
    return data.regions.map(region => {
      const location = regionLookup[region.region_name.toLowerCase()];
      if (!location) return null;
      return {
        ...region,
        position: latLonToVector3(location.lat, location.lng, 5.1),
      };
    }).filter(Boolean);
  }, [data]);
  
  if (loading) {
     return <Text color="white" anchorX="center" anchorY="middle">Loading Knowledge Graph...</Text>
  }

  return (
    <>
      <Globe />
      {data?.alerts.map((alert, i) => <AlertNode key={alert.id} alert={alert} index={i} />)}
      {nodes.map(node => <RegionNode key={node.id} position={node.position} name={node.region_name} />)}
    </>
  );
}

export default function GlobalOpsMap() {
  return (
    <div className="h-[calc(100vh-200px)] w-full bg-black rounded-lg">
      <Canvas camera={{ position: [0, 0, 15], fov: 45 }}>
        <ambientLight intensity={0.2} />
        <pointLight position={[20, 20, 20]} intensity={1} />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
        <OrbitControls enableZoom={true} enablePan={true} minDistance={6} maxDistance={30} />
      </Canvas>
    </div>
  );
}