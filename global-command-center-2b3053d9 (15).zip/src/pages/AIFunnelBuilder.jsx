import React from "react";
import GeneratorForm from "@/components/funnels/ai/GeneratorForm";
import Copywriter from "@/components/funnels/ai/Copywriter";
import PredictiveForecast from "@/components/funnels/ai/PredictiveForecast";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Wand2, Type, LineChart } from "lucide-react";

export default function AIFunnelBuilder() {
  const [tab, setTab] = React.useState("generator");

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <Wand2 className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">AI Funnel Studio</h1>
            <p className="orbital-text-subtitle">Generate funnels, copy, and forecasts in seconds.</p>
          </div>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-3xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-white">AI Tools</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={tab} onValueChange={setTab} className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="generator" className="flex items-center gap-2">
                <Wand2 className="w-4 h-4" /> Generator
              </TabsTrigger>
              <TabsTrigger value="copywriter" className="flex items-center gap-2">
                <Type className="w-4 h-4" /> Copywriter
              </TabsTrigger>
              <TabsTrigger value="forecast" className="flex items-center gap-2">
                <LineChart className="w-4 h-4" /> Predictive
              </TabsTrigger>
            </TabsList>

            <TabsContent value="generator">
              <GeneratorForm />
            </TabsContent>
            <TabsContent value="copywriter">
              <Copywriter />
            </TabsContent>
            <TabsContent value="forecast">
              <PredictiveForecast />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}