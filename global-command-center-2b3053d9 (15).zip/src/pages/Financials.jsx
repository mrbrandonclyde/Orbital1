import React, { useState, useCallback } from 'react';
import { FinancialStatement, Company } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { useLiveData } from '../components/lib/useLiveData';
import { DollarSign, TrendingUp, TrendingDown, BarChart, LineChart, PieChart } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart as RechartsBarChart, Bar } from 'recharts';

const LiveMarketTicker = () => {
  const stockUpdate = useLiveData('finance', 'global', 'stock:update', 2000); // Slower update for effect
  
  if (!stockUpdate) {
    return (
      <div className="text-gray-400 animate-pulse">
        Connecting to live market data...
      </div>
    );
  }
  
  const isUp = parseFloat(stockUpdate.change) >= 0;

  return (
    <div className="flex items-center space-x-4">
      <span className="font-semibold text-white">{stockUpdate.symbol}</span>
      <span className="text-xl font-bold text-white">${parseFloat(stockUpdate.price).toFixed(2)}</span>
      <span className={`flex items-center text-sm font-semibold ${isUp ? 'text-green-400' : 'text-red-400'}`}>
        {isUp ? <TrendingUp size={16} className="mr-1"/> : <TrendingDown size={16} className="mr-1"/>}
        {stockUpdate.change} ({stockUpdate.change_percent}%)
      </span>
    </div>
  );
};

export default function FinancialsPage() {
  const queryFn = useCallback(async () => {
    const [statements, companies] = await Promise.all([
      FinancialStatement.list('-period_ending_date', 50),
      Company.list()
    ]);
    const companyMap = Object.fromEntries(companies.map(c => [c.id, c.company_name]));
    
    const chartData = statements.map(s => ({
      name: companyMap[s.company_id] || 'Unknown',
      revenue: s.revenue / 1e9, // in Billions
      net_income: s.net_income / 1e9,
      ebitda: s.ebitda / 1e9
    })).reverse();

    return { statements, companies, companyMap, chartData };
  }, []);

  const { data, loading, error } = useQuery(queryFn);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text">Financial Intelligence</h1>
          <p className="text-lg text-gray-400 mt-2">Monitor real-time market data and corporate financial health.</p>
        </div>
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-4">
           <LiveMarketTicker />
        </div>
      </div>

      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 mb-8">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <BarChart className="w-5 h-5 mr-2 text-indigo-400" />
          Corporate Revenue Overview (Billions USD)
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <RechartsBarChart data={data?.chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
              labelStyle={{ color: '#F3F4F6' }}
            />
            <Bar dataKey="revenue" fill="#8B5CF6" />
            <Bar dataKey="net_income" fill="#10B981" />
          </RechartsBarChart>
        </ResponsiveContainer>
      </div>

      {/* Financial Statements Table */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Recent Financial Filings</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="p-3 text-sm font-semibold text-gray-400">Company</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Period Ending</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Filing Type</th>
                <th className="p-3 text-sm font-semibold text-gray-400 text-right">Revenue (B)</th>
                <th className="p-3 text-sm font-semibold text-gray-400 text-right">Net Income (B)</th>
              </tr>
            </thead>
            <tbody>
              {data?.statements.map(s => (
                <tr key={s.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                  <td className="p-3 text-white">{data.companyMap[s.company_id] || 'N/A'}</td>
                  <td className="p-3 text-gray-300">{s.period_ending_date}</td>
                  <td className="p-3 text-gray-300">{s.filing_type}</td>
                  <td className="p-3 text-green-400 text-right">${(s.revenue / 1e9).toFixed(2)}</td>
                  <td className="p-3 text-blue-400 text-right">${(s.net_income / 1e9).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}