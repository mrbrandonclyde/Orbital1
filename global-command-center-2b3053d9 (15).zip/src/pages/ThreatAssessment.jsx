import React, { useState } from 'react';
import { Shield, AlertTriangle, Globe, Eye, Target, Activity } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const threatMetrics = [
  { title: "Global Threat Level", value: "MODERATE", icon: Shield, color: "text-yellow-400" },
  { title: "Active Threats", value: "23", icon: AlertTriangle, color: "text-red-400" },
  { title: "Monitored Regions", value: "198", icon: Globe, color: "text-blue-400" },
  { title: "Intelligence Sources", value: "847", icon: Eye, color: "text-green-400" },
  { title: "Prediction Accuracy", value: "94.2%", icon: Target, color: "text-purple-400" },
  { title: "Response Time", value: "< 15min", icon: Activity, color: "text-cyan-400" }
];

const threatTrends = [
  { month: 'Jan', cyber: 25, geopolitical: 15, economic: 20, terrorism: 10 },
  { month: 'Feb', cyber: 30, geopolitical: 18, economic: 25, terrorism: 12 },
  { month: 'Mar', cyber: 28, geopolitical: 22, economic: 30, terrorism: 8 },
  { month: 'Apr', cyber: 35, geopolitical: 25, economic: 28, terrorism: 15 },
  { month: 'May', cyber: 40, geopolitical: 20, economic: 22, terrorism: 18 },
  { month: 'Jun', cyber: 45, geopolitical: 30, economic: 35, terrorism: 20 }
];

const activeThreatsList = [
  { id: 'T-001', type: 'Cyber Attack', severity: 'HIGH', region: 'Eastern Europe', status: 'ACTIVE', eta: '2h 15m' },
  { id: 'T-002', type: 'Economic Disruption', severity: 'CRITICAL', region: 'Asia Pacific', status: 'MONITORING', eta: '6h 30m' },
  { id: 'T-003', type: 'Political Instability', severity: 'MEDIUM', region: 'Middle East', status: 'CONTAINED', eta: 'Resolved' }
];

const getSeverityBadge = (severity) => {
  switch (severity) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    default: return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
  }
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-red-500/20 text-red-400 animate-pulse">ACTIVE</Badge>;
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400">MONITORING</Badge>;
    case 'CONTAINED': return <Badge className="bg-green-500/20 text-green-400">CONTAINED</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function ThreatAssessmentPage() {
  const [selectedThreat, setSelectedThreat] = useState(null);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Shield className="w-10 h-10 mr-3 text-red-400" />
            Global Threat Assessment
          </h1>
          <p className="orbital-text-subtitle">Real-time threat monitoring, analysis, and predictive intelligence.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {threatMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Threat Trend Analysis</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={threatTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Area type="monotone" dataKey="cyber" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} />
                <Area type="monotone" dataKey="economic" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} />
                <Area type="monotone" dataKey="geopolitical" stackId="1" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="terrorism" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Active Threats</h3>
          <div className="space-y-4">
            {activeThreatsList.map(threat => (
              <div key={threat.id} className="p-4 bg-gray-800/30 rounded-lg border-l-4 border-red-500/50">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-cyan-400 font-mono text-sm">{threat.id}</span>
                    {getSeverityBadge(threat.severity)}
                  </div>
                  <span className="text-xs text-gray-500">{threat.eta}</span>
                </div>
                <h4 className="font-semibold text-white mb-1">{threat.type}</h4>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">{threat.region}</span>
                  {getStatusBadge(threat.status)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}