import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Brain, Dna } from "lucide-react";

export default function SymbiosisPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Brain className="w-10 h-10 mr-3 text-purple-400" />
          Symbiosis
        </h1>
        <p className="orbital-text-subtitle">Bio, Cross‑Species, Genome, Cognitive.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('BioSymbiosis')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Dna className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Bio‑Symbiosis</h3>
          </div>
          <p className="text-gray-400 text-sm">Neural links and bio‑enhancement.</p>
        </Link>
      </div>
    </div>
  );
}