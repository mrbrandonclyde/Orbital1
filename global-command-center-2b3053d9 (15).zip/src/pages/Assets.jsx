
import React, { useState } from 'react';
import { Asset } from "@/api/entities";
import { BusinessSector } from "@/api/entities";
import { Company } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Package, TrendingUp, DollarSign, Globe, Building2, Plus, Filter } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import AssetCard from '../components/assets/AssetCard';
import AssetForm from '../components/assets/AssetForm';
import EmptyState from '../components/common/EmptyState';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from '@/components/ui/input';

const assetMetrics = [
  { title: "Total Asset Value", value: "$12.8T", icon: DollarSign, color: "text-green-400" },
  { title: "Managed Assets", value: "24,891", icon: Package, color: "text-cyan-400" },
  { title: "Portfolio Growth", value: "+14.2%", icon: TrendingUp, color: "text-purple-400" },
  { title: "Real Estate Holdings", value: "891", icon: Building2, color: "text-blue-400" },
  { title: "Global Spread", value: "128 Nations", icon: Globe, color: "text-orange-400" },
];

export default function AssetsPage() {
  const [showForm, setShowForm] = useState(false);
  const [editingAsset, setEditingAsset] = useState(null);
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterRisk, setFilterRisk] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const { data, loading, error, refetch } = useQuery(['assetsData'], async () => {
    const [assets, sectors, companies] = await Promise.all([
      Asset.list('-created_date', 100),
      BusinessSector.list(),
      Company.list()
    ]);

    const sectorMap = Object.fromEntries(sectors.map(s => [s.id, s.sector_name]));
    const companyMap = Object.fromEntries(companies.map(c => [c.id, c.company_name]));

    const populatedAssets = assets.map(asset => ({
      ...asset,
      sectorName: sectorMap[asset.sector_id] || 'Unknown Sector',
      companyName: companyMap[asset.company_id] || 'Unknown Company',
    }));

    return { assets: populatedAssets, sectors, companies };
  });

  const filteredAssets = (data?.assets || []).filter(asset => {
    const categoryMatch = filterCategory === 'all' || asset.asset_category === filterCategory;
    const riskMatch = filterRisk === 'all' || asset.risk_level === filterRisk;
    const searchMatch = !searchTerm || 
      asset.asset_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      asset.sectorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      asset.companyName.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && riskMatch && searchMatch;
  });

  const handleEdit = (asset) => {
    setEditingAsset(asset);
    setShowForm(true);
  };

  const handleSuccess = () => {
    setShowForm(false);
    setEditingAsset(null);
    refetch();
  };

  if (loading) {
    return (
      <div className="orbital-page-layout bg-[#020409]">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="orbital-page-layout bg-[#020409]">
        <ErrorBoundary>
          <div className="text-center text-red-400 p-8">
            Failed to load assets: {error.message}
          </div>
        </ErrorBoundary>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409]">
        <div className="orbital-page-header">
          <div>
            <h1 className="orbital-text-title flex items-center">
              <Package className="w-10 h-10 mr-3 text-cyan-400" />
              Strategic Asset Management
            </h1>
            <p className="orbital-text-subtitle">Oversight of global physical, digital, and financial assets.</p>
          </div>
          <Dialog open={showForm} onOpenChange={(isOpen) => { setShowForm(isOpen); if (!isOpen) setEditingAsset(null); }}>
            <DialogTrigger asChild>
              <button className="orbital-button-primary flex items-center space-x-2">
                <Plus size={18} />
                <span>Register New Asset</span>
              </button>
            </DialogTrigger>
            <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-2xl">
              <DialogHeader>
                <DialogTitle className="orbital-gradient-text text-2xl">
                  {editingAsset ? 'Update Asset Record' : 'Register New Strategic Asset'}
                </DialogTitle>
              </DialogHeader>
              <AssetForm
                asset={editingAsset}
                sectors={data?.sectors || []}
                companies={data?.companies || []}
                onSuccess={handleSuccess}
              />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {assetMetrics.map((metric, i) => {
            const Icon = metric.icon;
            return (
              <div key={i} className="glass-pane p-4">
                <div className="flex justify-between items-start">
                  <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                  <Icon className={`w-6 h-6 ${metric.color}`} />
                </div>
                <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
              </div>
            );
          })}
        </div>

        <div className="glass-pane p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <h3 className="orbital-text-subheading">Asset Portfolio</h3>
            <div className="flex gap-4 items-center">
              <Input
                placeholder="Search assets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64 bg-gray-800/50 border-gray-600"
              />
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40 bg-gray-800/50 border-gray-600">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Equities">Equities</SelectItem>
                  <SelectItem value="Real Estate">Real Estate</SelectItem>
                  <SelectItem value="Infrastructure">Infrastructure</SelectItem>
                  <SelectItem value="Digital Currency">Digital Currency</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterRisk} onValueChange={setFilterRisk}>
                <SelectTrigger className="w-32 bg-gray-800/50 border-gray-600">
                  <SelectValue placeholder="Risk" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Risk</SelectItem>
                  <SelectItem value="LOW">Low</SelectItem>
                  <SelectItem value="MEDIUM">Medium</SelectItem>
                  <SelectItem value="HIGH">High</SelectItem>
                  <SelectItem value="CRITICAL">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {filteredAssets.length === 0 ? (
          <EmptyState 
            icon={Package}
            title="No Assets Found"
            subtitle="No assets match your current filters. Try adjusting your search criteria or add new assets to the portfolio."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAssets.map((asset) => (
              <AssetCard
                key={asset.id}
                asset={asset}
                onEdit={handleEdit}
              />
            ))}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}
