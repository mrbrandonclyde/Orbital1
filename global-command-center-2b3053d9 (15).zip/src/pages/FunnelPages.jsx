import React from "react";
import { FunnelTemplate } from "@/api/entities";
import { User } from "@/api/entities";
import TemplateCard from "../components/templates/TemplateCard";
import TemplatePreviewModal from "../components/templates/TemplatePreviewModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Layers, Star, Store, Wand2 } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function FunnelPages() {
  const [tab, setTab] = React.useState("starter");
  const [q, setQ] = React.useState("");
  const [templates, setTemplates] = React.useState([]);
  const [me, setMe] = React.useState(null);
  const [preview, setPreview] = React.useState({ open: false, template: null });

  React.useEffect(() => {
    const load = async () => {
      const user = await User.me().catch(() => null);
      setMe(user);
      const list = await FunnelTemplate.list("-updated_date", 500);
      setTemplates(list);
    };
    load();
  }, []);

  const filteredTemplates = React.useMemo(() => {
    const term = q.trim().toLowerCase();
    const filterByTab = (t) => {
      if (tab === "starter") {
        // Starter: non-custom templates
        return t.category !== "CUSTOM";
      }
      if (tab === "high") {
        // High-Converting: rating or conversion threshold
        return (t.avg_conversion_rate || 0) >= 25 || (t.rating || 0) >= 4;
      }
      if (tab === "mine") {
        // My Saved: created by me or CUSTOM
        return t.category === "CUSTOM" || (me?.email && t.created_by === me.email);
      }
      if (tab === "market") {
        return false; // placeholder section below
      }
      return true;
    };
    return templates
      .filter(filterByTab)
      .filter(t => !term || t.template_name.toLowerCase().includes(term) || (t.description || "").toLowerCase().includes(term));
  }, [templates, tab, q, me]);

  const handlePreview = (t) => setPreview({ open: true, template: t });
  const handleUse = (t) => {
    window.location.href = createPageUrl(`FunnelWizard?template=${t.id}`);
  };
  const handleSave = async (t) => {
    // Clone template into CUSTOM (My Saved)
    await FunnelTemplate.create({
      template_name: `${t.template_name} (Saved)`,
      category: "CUSTOM",
      thumbnail_url: t.thumbnail_url,
      description: t.description || "Saved to My Templates",
      steps_blueprint: t.steps_blueprint || [],
      rating: t.rating || 0,
      avg_conversion_rate: t.avg_conversion_rate || 0,
      saves_count: (t.saves_count || 0) + 1
    });
    // Refresh
    const list = await FunnelTemplate.list("-updated_date", 500);
    setTemplates(list);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <Layers className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Template Library</h1>
            <p className="orbital-text-subtitle">Starter kits, high‑converting templates, and your saved designs.</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="secondary" onClick={() => window.location.href = createPageUrl("FunnelWizard")}>
            <Wand2 className="w-4 h-4 mr-2" /> AI Funnel Builder (soon)
          </Button>
          <Button variant="secondary">
            <Store className="w-4 h-4 mr-2" /> Marketplace (coming soon)
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-3xl p-3 mb-6 flex items-center gap-2 overflow-x-auto">
        <button onClick={() => setTab("starter")} className={`px-3 py-2 rounded-lg text-sm ${tab === "starter" ? "bg-indigo-600 text-white" : "text-gray-300 hover:bg-gray-800/40"}`}>Starter Templates</button>
        <button onClick={() => setTab("high")} className={`px-3 py-2 rounded-lg text-sm ${tab === "high" ? "bg-indigo-600 text-white" : "text-gray-300 hover:bg-gray-800/40"}`}>High‑Converting</button>
        <button onClick={() => setTab("mine")} className={`px-3 py-2 rounded-lg text-sm ${tab === "mine" ? "bg-indigo-600 text-white" : "text-gray-300 hover:bg-gray-800/40"}`}>My Saved</button>
        <button onClick={() => setTab("market")} className={`px-3 py-2 rounded-lg text-sm ${tab === "market" ? "bg-indigo-600 text-white" : "text-gray-300 hover:bg-gray-800/40"}`}>Marketplace</button>

        <div className="ml-auto flex items-center gap-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search templates…"
            className="w-56 bg-[#0C0F19] border-gray-700 text-gray-200"
          />
        </div>
      </div>

      {/* Content */}
      {tab === "market" ? (
        <div className="glass-pane p-6 rounded-3xl text-center">
          <h3 className="text-white text-lg font-semibold mb-2">Template Marketplace (Coming Soon)</h3>
          <p className="text-gray-400 text-sm mb-4">Buy and sell premium funnel templates from the community.</p>
          <div className="flex items-center justify-center gap-3">
            <Badge className="bg-purple-500/20 text-purple-400">Creators</Badge>
            <Badge className="bg-cyan-500/20 text-cyan-400">Verified</Badge>
            <Badge className="bg-yellow-500/20 text-yellow-400">High CVR</Badge>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map(t => (
            <TemplateCard
              key={t.id}
              template={t}
              onPreview={handlePreview}
              onUse={handleUse}
              onSave={handleSave}
            />
          ))}
          {!filteredTemplates.length && (
            <div className="text-gray-500 col-span-full text-center py-12">No templates found.</div>
          )}
        </div>
      )}

      {/* Preview Modal */}
      <TemplatePreviewModal
        open={preview.open}
        onOpenChange={(open) => setPreview(prev => ({ ...prev, open }))}
        template={preview.template}
      />
    </div>
  );
}