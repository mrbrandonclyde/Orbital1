
import React, { useState, useCallback } from 'react';
import { Report } from "@/api/entities";
import { SecurityAlert } from "@/api/entities";
import { SectorMetrics } from "@/api/entities";
import { InvokeLLM } from '@/api/integrations';
import { useQuery } from "../components/lib/useQuery";
import { FileText, Plus, Loader, Download, AlertTriangle, CheckCircle, Clock, TrendingUp, BarChart3, RefreshCw } from 'lucide-react';
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import ReactMarkdown from 'react-markdown';
import ErrorBoundary from '../components/common/ErrorBoundary';

const kpiData = [
  { title: "Total Reports Generated", value: "142", icon: FileText, color: "text-blue-400" },
  { title: "Report Accuracy", value: "97.8%", icon: CheckCircle, color: "text-green-400" },
  { title: "Avg. Generation Time", value: "3.2min", icon: Clock, color: "text-yellow-400" },
  { title: "Critical Reports Pending", value: "3", icon: AlertTriangle, color: "text-red-400" },
  { title: "System Health Score", value: "98.5%", icon: BarChart3, color: "text-cyan-400" },
];

const reportGenerationData = [
  { time: "Week 1", reports: 28 },
  { time: "Week 2", reports: 32 },
  { time: "Week 3", reports: 29 },
  { time: "Week 4", reports: 35 },
  { time: "Week 5", reports: 31 },
  { time: "Week 6", reports: 38 },
];

const reportGenerationTimeData = [
  { type: "Daily Briefing", time: 2.1, fill: "#10B981" },
  { type: "Incident Report", time: 4.5, fill: "#F59E0B" },
  { type: "Performance Review", time: 6.2, fill: "#3B82F6" },
  { type: "Security Analysis", time: 8.1, fill: "#EF4444" },
];

const reportStatusData = [
  { name: "Completed", value: 89, fill: "#10B981" },
  { name: "In Progress", value: 8, fill: "#F59E0B" },
  { name: "Pending Review", value: 3, fill: "#EF4444" },
];

const reportLog = [
  { id: "#R-001", type: "Daily Briefing", status: "Completed", generatedBy: "AI System", date: "2025-09-02 14:30", insights: "High" },
  { id: "#R-002", type: "Incident Report", status: "In Progress", generatedBy: "Security Team", date: "2025-09-02 15:15", insights: "Critical" },
  { id: "#R-003", type: "Sector Analysis", status: "Completed", generatedBy: "Analytics Engine", date: "2025-09-02 16:00", insights: "Medium" },
];

const actionLog = [
  { actionId: "#A-5001", reportId: "#R-001", action: "Auto-Generated", status: "Completed", duration: "2.1min" },
  { actionId: "#A-5002", reportId: "#R-002", action: "Manual Review", status: "In Progress", duration: "45min" },
  { actionId: "#A-5003", reportId: "#R-003", action: "Data Validation", status: "Completed", duration: "3.5min" },
];

const reportSummary = [
  { id: "#R-001", insights: "Market volatility detected", resolution: "2 minutes", outcome: "Actionable intelligence provided" },
  { id: "#R-002", insights: "Security breach containment", resolution: "Ongoing", outcome: "Investigation active" },
];

const ChartTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
          <p className="label text-white font-medium mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color || entry.stroke || entry.fill }}>{`${entry.name}: ${entry.value}${entry.unit || ''}`}</p>
          ))}
        </div>
      );
    }
    return null;
};

const getStatusBadge = (status) => {
    if (status === "Completed") return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    if (status === "In Progress") return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">{status}</Badge>;
    if (status === "Pending Review") return <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20">{status}</Badge>;
    return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
};

const getInsightsBadge = (insights) => {
    if (insights === "Critical") return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">{insights}</Badge>;
    if (insights === "High") return <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">{insights}</Badge>;
    if (insights === "Medium") return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">{insights}</Badge>;
    return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">{insights}</Badge>;
};

export default function ReportsPage() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedReport, setGeneratedReport] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);
  const [timeframe, setTimeframe] = useState('30D');

  const { data: reports, loading, refetch } = useQuery(['reports', timeframe], () => Report.list('-created_date', 20));

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    setGeneratedReport(null);
    setSelectedReport(null);
    try {
      const [alerts, metrics] = await Promise.all([
        SecurityAlert.filter({ alert_status: "ACTIVE" }, "-created_date", 5),
        SectorMetrics.list("-updated_date", 5)
      ]);

      const prompt = `
        Generate a concise executive daily briefing based on the following data.
        Format it in Markdown. Include sections for "Critical Alerts" and "Key Sector Metrics".
        
        **Recent Critical Alerts:**
        ${JSON.stringify(alerts, null, 2)}

        **Recent Sector Metrics:**
        ${JSON.stringify(metrics, null, 2)}

        Provide a summary and a "Threat Assessment" section with a level (LOW, MEDIUM, HIGH, CRITICAL).
        The tone should be professional, direct, and suitable for a high-level executive in a global command center.
      `;

      const aiResponse = await InvokeLLM({ prompt });
      
      const newReport = {
        report_title: `Executive Daily Briefing - ${new Date().toLocaleDateString()}`,
        report_type: "DAILY_BRIEFING",
        summary: aiResponse,
        generated_by_user_id: "AI_SYSTEM", 
      };
      
      setGeneratedReport(newReport.summary);
      const createdRecord = await Report.create(newReport);
      setSelectedReport(createdRecord);
      refetch();

    } catch (error) {
      console.error("Failed to generate report:", error);
      setGeneratedReport("## Error\n\nFailed to generate AI-assisted report. Please check the system logs.");
    } finally {
      setIsGenerating(false);
    }
  };
  
  const displayReport = (report) => {
    setGeneratedReport(null);
    setSelectedReport(report);
  }

  const reportContent = selectedReport?.summary || generatedReport;

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409]">
        <div className="orbital-page-header">
          <div>
            <h1 className="orbital-text-title flex items-center">
              <FileText className="w-10 h-10 mr-3 text-blue-400" />
              System Control Reports
            </h1>
            <p className="orbital-text-subtitle">Monitor report generation performance, accuracy metrics, and system health.</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex bg-[#0A0D18] border border-gray-800 rounded-lg p-1">
              {['24H', '7D', '30D', '90D'].map(period => (
                <button
                  key={period}
                  onClick={() => setTimeframe(period)}
                  className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${
                    timeframe === period
                      ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  {period}
                </button>
              ))}
            </div>
            <button onClick={handleGenerateReport} className="orbital-button-primary flex items-center space-x-2" disabled={isGenerating}>
              {isGenerating ? (
                <Loader className="animate-spin w-5 h-5" />
              ) : (
                <Plus size={18} />
              )}
              <span>Generate Report</span>
            </button>
             <button onClick={refetch} className="orbital-button-secondary">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Frame 1: KPI Cards - Report System Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {kpiData.map((kpi, i) => {
            const Icon = kpi.icon;
            return (
              <div key={i} className="glass-pane p-4">
                <div className="flex justify-between items-start">
                  <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                  <Icon className={`w-6 h-6 ${kpi.color}`} />
                </div>
                <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
              </div>
            );
          })}
        </div>

        {/* Frame 2: Graphs - Report Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Reports Over Time */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
              Reports Generated Over Time
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={reportGenerationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Line type="monotone" dataKey="reports" name="Reports" stroke="#3B82F6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Report Generation Time */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-yellow-400" />
              Generation Time by Type
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={reportGenerationTimeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="type" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="time" name="Time (min)">
                    {reportGenerationTimeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Report Status Distribution */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-green-400" />
              Report Status Distribution
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Tooltip content={<ChartTooltip />} />
                  <Pie data={reportStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                    {reportStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Generated Report Section */}
          <div className="lg:col-span-2">
            <div className="glass-pane p-6 min-h-[400px] flex flex-col">
              <div className="flex justify-between items-center mb-4">
                  <h3 className="orbital-text-subheading">
                      {selectedReport?.report_title || 'Latest Generated Report'}
                  </h3>
                  {reportContent && (
                      <button className="orbital-button-secondary text-xs">
                          <Download size={14} className="mr-2"/>
                          Export
                      </button>
                  )}
              </div>
              <div className="flex-grow overflow-y-auto">
                  {isGenerating && (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                      <Loader className="w-12 h-12 text-indigo-400 animate-spin mb-4" />
                      <p className="text-lg text-gray-300">AI is analyzing real-time data...</p>
                      <p className="text-sm text-gray-500">This may take a moment.</p>
                  </div>
                  )}
                  {reportContent && (
                  <div className="prose prose-invert max-w-none prose-p:text-gray-300 prose-headings:text-white prose-strong:text-white prose-headings:border-b prose-headings:border-gray-700 prose-headings:pb-2">
                      <ReactMarkdown>{reportContent}</ReactMarkdown>
                  </div>
                  )}
                  {!isGenerating && !reportContent && (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                      <FileText className="w-16 h-16 text-gray-600 mb-4" />
                      <p className="text-lg text-gray-400">Click "Generate Report" to create your latest AI-powered report, or select one from the archive.</p>
                  </div>
                  )}
              </div>
            </div>
          </div>

          {/* Report Archive */}
          <div>
            <div className="glass-pane p-6">
              <h3 className="orbital-text-subheading mb-4">Report Archive</h3>
              <div className="space-y-3 max-h-[350px] overflow-y-auto">
                {loading && <p className="text-gray-400">Loading archive...</p>}
                {reports?.map(report => (
                  <div 
                    key={report.id}
                    onClick={() => displayReport(report)}
                    className={`flex justify-between items-center bg-gray-800/50 p-3 rounded-lg cursor-pointer transition-all border border-transparent hover:border-cyan-500/50 ${selectedReport?.id === report.id ? 'bg-cyan-500/10 border-cyan-500/50' : ''}`}
                  >
                    <div>
                      <p className="text-sm font-medium text-white">{report.report_title}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(report.created_date).toLocaleString()}
                      </p>
                    </div>
                    <FileText size={16} className="text-gray-500"/>
                  </div>
                ))}
                {!loading && reports?.length === 0 && (
                  <p className="text-gray-500 text-center py-8">No reports in archive.</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Frame 3: Logs - Report System Intelligence */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-8">
          {/* Report Log */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Report Generation Log</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">ID</TableHead>
                    <TableHead className="text-gray-400">Type</TableHead>
                    <TableHead className="text-gray-400">Status</TableHead>
                    <TableHead className="text-gray-400">Insights</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reportLog.map((report) => (
                    <TableRow key={report.id} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="font-mono text-xs text-cyan-400">{report.id}</TableCell>
                      <TableCell className="text-white font-medium">{report.type}</TableCell>
                      <TableCell>{getStatusBadge(report.status)}</TableCell>
                      <TableCell>{getInsightsBadge(report.insights)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Action Log */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Action Processing Log</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">Action ID</TableHead>
                    <TableHead className="text-gray-400">Report</TableHead>
                    <TableHead className="text-gray-400">Action</TableHead>
                    <TableHead className="text-gray-400">Duration</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {actionLog.map((action) => (
                    <TableRow key={action.actionId} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="font-mono text-xs text-gray-300">{action.actionId}</TableCell>
                      <TableCell className="font-mono text-xs text-cyan-400">{action.reportId}</TableCell>
                      <TableCell className="text-white">{action.action}</TableCell>
                      <TableCell className="text-green-400 font-semibold">{action.duration}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Report Summary */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Intelligence Summary</h3>
            <div className="space-y-3">
              {reportSummary.map((summary, i) => (
                <div key={i} className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-mono text-xs text-cyan-400">{summary.id}</span>
                    <span className="text-xs text-gray-400">{summary.resolution}</span>
                  </div>
                  <p className="text-sm text-white font-medium mb-1">{summary.insights}</p>
                  <p className="text-xs text-gray-400">{summary.outcome}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
