import React from "react";
import HeaderFrame from "@/components/foundation/HeaderFrame";
import FooterFrame from "@/components/foundation/FooterFrame";
import SidebarFrame from "@/components/foundation/SidebarFrame";
import DashboardFrame from "@/components/foundation/DashboardFrame";

export default function AppRoot() {
  return (
    <div className="min-h-screen">
      <HeaderFrame title="AppRoot" subtitle="Phase 1 Core Foundation Setup" />
      <SidebarFrame />
      <DashboardFrame />
      <FooterFrame />
    </div>
  );
}