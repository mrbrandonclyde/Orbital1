import React from 'react';
import { Book, Code, Database, Shield, Zap, Globe, GitBranch, Github, CircleDot } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const CodeBlock = ({ children }) => (
  <div className="bg-gray-800/50 p-4 rounded-lg font-mono text-sm text-gray-300 whitespace-pre-wrap">
    {children}
  </div>
);

export default function DocumentationPage() {
  return (
    <div className="animate-fade-in space-y-8">
      <div>
        <h1 className="text-4xl font-bold orbital-gradient-text flex items-center">
          <Book className="w-10 h-10 mr-3 text-indigo-400" />
          System Documentation
        </h1>
        <p className="text-lg text-gray-400 mt-2">
          The living "README" for the Global Command Center: Vision, architecture, and contribution guide.
        </p>
      </div>

      {/* Vision & Architecture */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-white">
            <Globe className="w-5 h-5 text-blue-400" />
            <span>Project Vision & Architecture</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 space-y-4">
          <p>The ultimate intelligence platform for monitoring, managing, and monetizing global sectors, companies, assets, and financial data in real-time. From traditional dashboards to immersive VR War Rooms.</p>
          <CodeBlock>{`global-command-center/
├── entities/           # Data models (The "Backend")
├── pages/              # Next.js pages
├── components/         # Reusable React components
└── layout.js           # Global application shell`}</CodeBlock>
        </CardContent>
      </Card>
      
      {/* CI/CD & Governance */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-white">
            <GitBranch className="w-5 h-5 text-green-400" />
            <span>CI/CD, Testing & Governance</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 space-y-4">
          <p>The base44 platform manages a full CI/CD pipeline, including linting, testing, security scans, and automated deployments. All code adheres to strict quality gates.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-500/10 p-4 rounded-lg">
              <h3 className="font-semibold text-green-400 mb-2">CI/CD Pipeline</h3>
              <ul className="text-sm space-y-1">
                <li>• Lint & Format (ESLint, Prettier)</li>
                <li>• Automated Testing (Unit, Integration, E2E)</li>
                <li>• Security Scanning (Trivy)</li>
                <li>• Dockerization & Deployment</li>
                <li>• Staging/Production Environments</li>
              </ul>
            </div>
            <div className="bg-purple-500/10 p-4 rounded-lg">
              <h3 className="font-semibold text-purple-400 mb-2">Contribution Guide</h3>
              <ul className="text-sm space-y-1">
                <li>• Pull Requests required for `main`</li>
                <li>• Conventional Commits enforced</li>
                <li>• All tests must pass</li>
                <li>• Branch protection rules active</li>
                <li>• Use Issue Templates for bugs/features</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Secrets & Config */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-white">
            <Shield className="w-5 h-5 text-red-400" />
            <span>Secrets & Environment Config</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 space-y-4">
           <p>All secrets are managed securely by the base44 platform and injected at runtime. They are not exposed in the codebase. Below are the conceptual environment variables required.</p>
           <CodeBlock>{`# DATABASE & CACHE
DATABASE_URL="********"
REDIS_URL="********"

# PLATFORM & 3RD PARTY KEYS
BASE44_API_KEY="********"
STRIPE_SECRET_KEY="********"
OPENAI_API_KEY="********"

# SECURITY
JWT_SECRET="********"`}</CodeBlock>
        </CardContent>
      </Card>
    </div>
  );
}