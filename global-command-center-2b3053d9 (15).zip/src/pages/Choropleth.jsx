import React from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useRegionStatus } from '../components/lib/useRegionStatus';
import ChoroplethLayer from '../components/map/ChoroplethLayer';
import { worldGeoJson } from '../components/data/world-geo';
import { usStatesGeoJson } from '../components/data/us-states-geo';

const ChoroplethMap = ({ title, sector, geoJsonData, geoKey, center, zoom }) => {
  const { statuses, isoToRegionCode } = useRegionStatus(sector);

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 orbital-glow-sm">
      <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
      <div className="h-[400px] w-full rounded-lg overflow-hidden border border-gray-700">
        <MapContainer center={center} zoom={zoom} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          <ChoroplethLayer 
            geoJsonData={geoJsonData} 
            statuses={statuses} 
            isoToRegionCode={isoToRegionCode}
            geoKey={geoKey}
          />
        </MapContainer>
      </div>
    </div>
  );
};

export default function ChoroplethPage() {
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold orbital-gradient-text">Global Choropleth View</h1>
        <p className="text-lg text-gray-400 mt-2">Live regional status monitoring across key sectors.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <ChoroplethMap 
          title="Global Finance Sector Status"
          sector="finance"
          geoJsonData={worldGeoJson}
          geoKey="id"
          center={[20, 0]}
          zoom={2}
        />
        <ChoroplethMap 
          title="US Defense Sector Status"
          sector="defense"
          geoJsonData={usStatesGeoJson}
          geoKey="iso_3166_2"
          center={[39.8283, -98.5795]}
          zoom={4}
        />
      </div>
    </div>
  );
}