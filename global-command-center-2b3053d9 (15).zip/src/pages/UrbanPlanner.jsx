
import React, { useEffect, useState, useCallback } from "react";
import { CityProject } from "@/api/entities";
import { UrbanZone } from "@/api/entities";
import { InfrastructureAsset } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Building2, Plus } from "lucide-react";

import ProjectForm from "@/components/urban/ProjectForm";
import ZoneForm from "@/components/urban/ZoneForm";
import CityMap from "@/components/urban/CityMap";
import AIRecommendations from "@/components/urban/AIRecommendations";

export default function UrbanPlannerPage() {
  const [projects, setProjects] = useState([]);
  const [zones, setZones] = useState([]);
  const [assets, setAssets] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [showZoneForm, setShowZoneForm] = useState(false);
  const [search, setSearch] = useState("");

  const loadProjects = useCallback(async () => {
    const list = await CityProject.list("-updated_date", 50);
    setProjects(list);
    // Only set selectedProject if it's not already set to prevent unintended re-selection
    if (list.length > 0 && !selectedProject) {
      setSelectedProject(list[0]);
    }
  }, [selectedProject]); // selectedProject is a dependency because the `if` condition uses it

  const loadRelated = useCallback(async (projectId) => {
    if (!projectId) return;
    const [z, a] = await Promise.all([
      UrbanZone.filter({ project_id: projectId }, "-updated_date", 100),
      InfrastructureAsset.filter({ project_id: projectId }, "-updated_date", 100)
    ]);
    setZones(z);
    setAssets(a);
  }, []); // No external dependencies needed for this function's logic

  useEffect(() => {
    loadProjects();
  }, [loadProjects]); // loadProjects is now stable due to useCallback

  useEffect(() => {
    loadRelated(selectedProject?.id);
  }, [selectedProject?.id, loadRelated]); // selectedProject.id and loadRelated are dependencies

  const filteredProjects = projects.filter(p =>
    !search ||
    p.project_name.toLowerCase().includes(search.toLowerCase()) ||
    (p.description || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Building2 className="w-10 h-10 mr-3 text-cyan-400" />
            Urban Planner
          </h1>
          <p className="orbital-text-subtitle">Design AI-assisted cities with zones, infrastructure, and KPIs.</p>
        </div>
        <div className="flex items-center gap-2">
          <Input placeholder="Search projects..." value={search} onChange={e => setSearch(e.target.value)} className="w-56 bg-gray-800/50 border-gray-600" />
          <Dialog open={showProjectForm} onOpenChange={setShowProjectForm}>
            <DialogTrigger asChild>
              <Button><Plus className="w-4 h-4 mr-2" /> New Project</Button>
            </DialogTrigger>
            <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-xl">
              <DialogHeader><DialogTitle>Create City Project</DialogTitle></DialogHeader>
              <ProjectForm onSuccess={() => { setShowProjectForm(false); loadProjects(); }} onCancel={() => setShowProjectForm(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="lg:col-span-1 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle>Projects</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {filteredProjects.length === 0 && (
              <div className="text-gray-400 text-sm">No projects yet. Create your first city project.</div>
            )}
            {filteredProjects.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedProject(p)}
                className={`w-full text-left p-3 rounded-lg border transition ${
                  selectedProject?.id === p.id
                    ? "border-cyan-500/40 bg-cyan-500/10"
                    : "border-gray-800 hover:bg-gray-800/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="text-white font-medium">{p.project_name}</div>
                  <Badge className="bg-gray-700/60 text-gray-200">{p.status}</Badge>
                </div>
                <div className="text-xs text-gray-400 mt-1 line-clamp-2">{p.description || "—"}</div>
              </button>
            ))}
          </CardContent>
        </Card>

        <div className="lg:col-span-2 space-y-6">
          <AIRecommendations project={selectedProject} zones={zones} assets={assets} />
          <CityMap project={selectedProject} zones={zones} assets={assets} />
        </div>
      </div>

      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Zones</CardTitle>
          {selectedProject && (
            <Dialog open={showZoneForm} onOpenChange={setShowZoneForm}>
              <DialogTrigger asChild>
                <Button variant="outline"><Plus className="w-4 h-4 mr-2" /> Add Zone</Button>
              </DialogTrigger>
              <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-xl">
                <DialogHeader><DialogTitle>Add Zone to {selectedProject.project_name}</DialogTitle></DialogHeader>
                <ZoneForm projectId={selectedProject.id} onSuccess={() => { setShowZoneForm(false); loadRelated(selectedProject.id); }} onCancel={() => setShowZoneForm(false)} />
              </DialogContent>
            </Dialog>
          )}
        </CardHeader>
        <CardContent>
          {selectedProject ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-400">Zone</TableHead>
                    <TableHead className="text-gray-400">Type</TableHead>
                    <TableHead className="text-gray-400">Density</TableHead>
                    <TableHead className="text-gray-400">Area (ha)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {zones.map(z => (
                    <TableRow key={z.id} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-white">{z.zone_name}</TableCell>
                      <TableCell className="text-gray-300">{z.zone_type}</TableCell>
                      <TableCell className="text-gray-300">{z.density}</TableCell>
                      <TableCell className="text-gray-300">{z.area_hectares || "—"}</TableCell>
                    </TableRow>
                  ))}
                  {zones.length === 0 && (
                    <TableRow className="border-gray-800">
                      <TableCell colSpan={4} className="text-gray-400 text-sm">No zones yet. Add your first zone.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-gray-400 text-sm">Select a project to view zones.</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
