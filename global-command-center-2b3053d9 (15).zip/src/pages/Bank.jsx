
import React, { useState, useCallback } from 'react';
import { useQuery } from '../components/lib/useQuery';
import { BankTransaction } from '@/api/entities';
import { User } from '@/api/entities';
import BankSidebar from '../components/bank/BankSidebar';
import BankDashboard from '../components/bank/BankDashboard';
import ReportsView from '../components/bank/ReportsView';
import TransactionsView from '../components/bank/TransactionsView';
import SettingsView from '../components/bank/SettingsView';
import AccountsView from '../components/bank/AccountsView';
import CardsView from '../components/bank/CardsView';
import LoansView from '../components/bank/LoansView';
import AnalyticsView from '../components/bank/AnalyticsView';
import { AlertTriangle, Menu, X, Shield, Lock } from 'lucide-react';
import NFTVaultView from '../components/bank/NFTVaultView';
import TokenizationEngineView from '../components/bank/TokenizationEngineView';
import FractionalOwnershipView from '../components/bank/FractionalOwnershipView';
import MarketplaceView from '../components/bank/MarketplaceView';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Placeholder components for remaining bank views
const InvestmentsView = () => <div className="p-6"><h1 className="text-3xl font-bold text-white">Investment Portfolio</h1><p className="text-gray-400 mt-4">Strategic investment management and performance tracking.</p></div>;
const ComplianceView = () => <div className="p-6"><h1 className="text-3xl font-bold text-white">Compliance Center</h1><p className="text-gray-400 mt-4">Regulatory compliance monitoring and reporting.</p></div>;
const AlertsView = () => <div className="p-6"><h1 className="text-3xl font-bold text-white">Risk Alerts</h1><p className="text-gray-400 mt-4">Real-time risk monitoring and alert management.</p></div>;

export default function BankPage() {
  const [activeView, setActiveView] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [user, setUser] = useState(null);

  // Enhanced data fetching with authentication check
  const queryFn = useCallback(async () => {
    try {
      // Verify user authentication
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Fetch bank transactions with user context
      const transactions = await BankTransaction.list('-date', 100);
      
      return { 
        transactions,
        user: currentUser,
        hasAccess: currentUser?.security_clearance === 'EXECUTIVE_COMMAND' || currentUser?.role === 'Executive' || currentUser?.role === 'Administrator'
      };
    } catch (authError) {
      // Handle authentication errors
      if (authError.message?.includes('authentication') || authError.status === 401) {
        throw new Error('Authentication required. Please log in to access Orbital Bank.');
      }
      throw authError;
    }
  }, []);

  const { data, loading, error, refetch } = useQuery(queryFn, { 
    refetchInterval: 30000,
    retryOnRateLimit: true,
    maxRetries: 3
  });

  const renderContent = () => {
    if (loading && !data) {
      return (
        <div className="flex flex-col items-center justify-center h-full">
          <div className="w-12 h-12 border-4 border-emerald-400 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-400">Connecting to Orbital Bank...</p>
          <div className="flex items-center mt-2 text-xs text-gray-500">
            <Shield className="w-3 h-3 mr-1" />
            Secure Connection Established
          </div>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 max-w-md mx-auto">
          <div className="p-4 bg-red-500/10 rounded-full mb-4">
            {error.message?.includes('Authentication') ? (
              <Lock className="w-8 h-8 text-red-400" />
            ) : (
              <AlertTriangle className="w-8 h-8 text-red-400" />
            )}
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">
            {error.message?.includes('Authentication') ? 'Access Denied' : 'Banking System Error'}
          </h3>
          <p className="text-red-400 mb-6 text-sm leading-relaxed">
            {error.message || 'Failed to connect to banking services. Please check your connection and try again.'}
          </p>
          <div className="flex space-x-3">
            <button 
              onClick={refetch} 
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors"
            >
              Retry Connection
            </button>
            {error.message?.includes('Authentication') && (
              <button 
                onClick={() => User.login()} 
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
              >
                Login
              </button>
            )}
          </div>
        </div>
      );
    }

    // Check access permissions
    if (data && !data.hasAccess) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 max-w-md mx-auto">
          <div className="p-4 bg-yellow-500/10 rounded-full mb-4">
            <Shield className="w-8 h-8 text-yellow-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Insufficient Clearance</h3>
          <p className="text-yellow-400 mb-6 text-sm leading-relaxed">
            Orbital Bank access requires Executive clearance. Please contact your system administrator.
          </p>
          <div className="flex items-center justify-center gap-3 mb-4">
            <Link 
              to={createPageUrl('AccessDiagnostics')} 
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors"
            >
              Request Executive Access
            </Link>
            <button 
              onClick={refetch} 
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
            >
              Refresh Status
            </button>
          </div>
          <div className="text-xs text-gray-500">
            Current Role: {user?.role || 'Unknown'} | 
            Clearance: {user?.security_clearance || 'None'}
          </div>
        </div>
      );
    }

    // Handle empty data states
    if (data && (!data.transactions || data.transactions.length === 0) && activeView === 'transactions') {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8">
          <div className="p-4 bg-blue-500/10 rounded-full mb-4">
            <AlertTriangle className="w-8 h-8 text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Transaction History</h3>
          <p className="text-gray-400 mb-6 text-sm">
            No banking transactions found. This could indicate a new account or data synchronization in progress.
          </p>
          <button onClick={refetch} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
            Refresh Data
          </button>
        </div>
      );
    }

    switch (activeView) {
      case 'dashboard': return <BankDashboard data={data} />;
      case 'accounts': return <AccountsView data={data} />;
      case 'transactions': return <TransactionsView data={data} />;
      case 'cards': return <CardsView data={data} />;
      case 'loans': return <LoansView data={data} />;
      case 'investments': return <InvestmentsView data={data} />;
      case 'analytics': return <AnalyticsView data={data} />;
      case 'compliance': return <ComplianceView data={data} />;
      case 'alerts': return <AlertsView data={data} />;
      case 'reports': return <ReportsView data={data} />;
      case 'settings': return <SettingsView data={data} />;
      // Digital Assets
      case 'nft_vault': return <NFTVaultView />;
      case 'tokenization': return <TokenizationEngineView />;
      case 'fractional': return <FractionalOwnershipView />;
      case 'marketplace': return <MarketplaceView />;
      default: return <BankDashboard data={data} />;
    }
  };

  const handleSetView = (view) => {
    setActiveView(view);
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  }

  return (
    <div className="h-screen bg-[#020409] flex overflow-hidden">
      {/* Mobile Sidebar */}
      <div className={`fixed inset-0 z-40 md:hidden transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="absolute inset-0 bg-black/60" onClick={() => setIsSidebarOpen(false)}></div>
        <div className={`relative z-50 h-full transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            <BankSidebar activeView={activeView} setActiveView={handleSetView} />
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex flex-shrink-0">
         <BankSidebar activeView={activeView} setActiveView={handleSetView} />
      </div>
      
      <main className="flex-1 flex flex-col overflow-y-auto">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 bg-[#0A0D18]/80 backdrop-blur-sm border-b border-gray-800">
           <h2 className="text-lg font-bold text-white">Orbital Bank</h2>
           <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="text-white p-2">
            {isSidebarOpen ? <X size={24}/> : <Menu size={24}/>}
           </button>
        </div>
        <div className="p-6 flex-1">
            {renderContent()}
        </div>
      </main>
    </div>
  );
}
