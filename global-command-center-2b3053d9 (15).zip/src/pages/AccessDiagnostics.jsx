import React, { useEffect, useState, useCallback } from "react";
import { User } from "@/api/entities";
import { SystemConfig } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Key, Shield, Mail, AlertTriangle, CheckCircle } from "lucide-react";

export default function AccessDiagnosticsPage() {
  const [me, setMe] = useState(null);
  const [loading, setLoading] = useState(true);

  const [adminEmail, setAdminEmail] = useState("");
  const [configId, setConfigId] = useState(null);
  const [savingEmail, setSavingEmail] = useState(false);

  const [sending, setSending] = useState(false);
  const [statusMsg, setStatusMsg] = useState(null);
  const [statusType, setStatusType] = useState("info"); // 'info' | 'success' | 'error'

  const loadData = useCallback(async () => {
    setLoading(true);
    const current = await User.me();
    setMe(current);

    const existing = await SystemConfig.filter({ config_key: "ADMIN_CONTACT_EMAIL" }, undefined, 1);
    if (existing && existing.length > 0) {
      setConfigId(existing[0].id);
      setAdminEmail(existing[0].config_value?.email || "");
    } else {
      setConfigId(null);
      setAdminEmail("");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const saveAdminEmail = async () => {
    if (!adminEmail) {
      setStatusType("error");
      setStatusMsg("Please enter a valid admin contact email.");
      return;
    }
    setSavingEmail(true);
    if (configId) {
      await SystemConfig.update(configId, {
        config_value: { email: adminEmail },
        description: "Admin contact email for access requests",
        security_classification: "CONFIDENTIAL",
      });
    } else {
      const created = await SystemConfig.create({
        config_key: "ADMIN_CONTACT_EMAIL",
        config_value: { email: adminEmail },
        description: "Admin contact email for access requests",
        security_classification: "CONFIDENTIAL",
        is_editable: true
      });
      setConfigId(created.id);
    }
    setSavingEmail(false);
    setStatusType("success");
    setStatusMsg("Admin contact email saved.");
  };

  const requestAdminAccess = async () => {
    if (!adminEmail) {
      setStatusType("error");
      setStatusMsg("No Admin Contact email is set. Please add one below first.");
      return;
    }
    setSending(true);
    const subject = `Admin Access Request: ${me?.full_name || me?.email || "Unknown User"}`;
    const body =
`Hello Admin,

A user has requested administrator access.

Requester:
- Name: ${me?.full_name || "Unknown"}
- Email: ${me?.email || "Unknown"}
- Current Role: ${me?.role || "Unknown"}
- Security Clearance: ${me?.security_clearance || "Unknown"}
- User ID: ${me?.id || "Unknown"}
- Requested At: ${new Date().toISOString()}

Recommended action:
1) In Dashboard → Data → User → find this user (by email)
2) Set role = "Administrator" and security_clearance = "EXECUTIVE_COMMAND"
3) Save

Direct links (once role restored):
- System Admin panel: /${window.location.host.includes("http") ? "" : ""}

Thank you,
Orbital Global Command Center`;

    await SendEmail({
      to: adminEmail,
      subject,
      body,
      from_name: "Orbital Command Center"
    });

    setSending(false);
    setStatusType("success");
    setStatusMsg("Your request has been sent to the Admin contact.");
  };

  const roleBadge = (role) => (
    <Badge className="bg-purple-500/20 text-purple-300 border border-purple-500/30">{role || "Unknown"}</Badge>
  );

  const clearanceBadge = (c) => {
    const map = {
      CONFIDENTIAL: "bg-blue-500/20 text-blue-300 border-blue-500/30",
      SECRET: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
      TOP_SECRET: "bg-orange-500/20 text-orange-300 border-orange-500/30",
      EXECUTIVE_COMMAND: "bg-red-500/20 text-red-300 border-red-500/30"
    };
    return <Badge className={`${map[c] || "bg-gray-500/20 text-gray-300 border-gray-500/30"}`}>{c || "Unknown"}</Badge>;
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Key className="w-10 h-10 mr-3 text-cyan-400" />
            Access Diagnostics
          </h1>
          <p className="orbital-text-subtitle">Check your current permissions and send a one‑click admin access request.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1 glass-pane">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Shield className="w-5 h-5 mr-2 text-green-400" />
                Current Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-gray-300">
                <div className="text-sm">Name</div>
                <div className="font-semibold text-white">{me?.full_name || "Unknown"}</div>
              </div>
              <div className="text-gray-300">
                <div className="text-sm">Email</div>
                <div className="font-semibold text-white">{me?.email || "Unknown"}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-300">Role:</span>
                {roleBadge(me?.role)}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-300">Clearance:</span>
                {clearanceBadge(me?.security_clearance)}
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2 glass-pane">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Mail className="w-5 h-5 mr-2 text-cyan-400" />
                Request Admin Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {statusMsg && (
                <div className={`p-3 rounded-lg border text-sm ${statusType === "success" ? "bg-green-500/10 border-green-500/30 text-green-300" : statusType === "error" ? "bg-red-500/10 border-red-500/30 text-red-300" : "bg-gray-700/40 border-gray-600 text-gray-200"}`}>
                  <div className="flex items-center gap-2">
                    {statusType === "success" ? <CheckCircle className="w-4 h-4" /> : statusType === "error" ? <AlertTriangle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                    <span>{statusMsg}</span>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm text-gray-400 mb-2">Admin Contact Email (who should receive your request)</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="admin@your-org.com"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="bg-[#0C0F19] border-gray-700"
                  />
                  <Button onClick={saveAdminEmail} disabled={savingEmail}>
                    {savingEmail ? "Saving..." : "Save"}
                  </Button>
                </div>
              </div>

              <div className="pt-2">
                <Button
                  className="orbital-button-primary"
                  onClick={requestAdminAccess}
                  disabled={sending || !adminEmail}
                >
                  {sending ? "Sending..." : "Send Admin Access Request"}
                </Button>
              </div>

              <div className="text-xs text-gray-500">
                This sends an email with your user details to the configured Admin contact so they can restore your Administrator role and EXECUTIVE_COMMAND clearance.
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}