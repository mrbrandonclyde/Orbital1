import React, { useEffect, useMemo, useState } from "react";
import { SavedPrompt } from "@/api/entities";
import { KnowledgeDocument } from "@/api/entities";
import { ToolRunLog } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Play, Save, FileText } from "lucide-react";
import ReactQuill from "react-quill";

export default function PromptStudioPage() {
  const [prompts, setPrompts] = useState([]);
  const [docs, setDocs] = useState([]);
  const [selectedPrompt, setSelectedPrompt] = useState(null);
  const [form, setForm] = useState({ name: "", description: "", content: "", variables: "", tags: "" });
  const [varValues, setVarValues] = useState({});
  const [docFilter, setDocFilter] = useState("");
  const [docLimit, setDocLimit] = useState(3);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState("");
  const [me, setMe] = useState(null);

  useEffect(() => {
    (async () => {
      setPrompts(await SavedPrompt.list("-updated_date", 100));
      setDocs(await KnowledgeDocument.list("-updated_date", 200));
      try { setMe(await User.me()); } catch {}
    })();
  }, []);

  useEffect(() => {
    if (!selectedPrompt) return;
    setForm({
      name: selectedPrompt.name || "",
      description: selectedPrompt.description || "",
      content: selectedPrompt.content || "",
      variables: (selectedPrompt.variables || []).join(", "),
      tags: (selectedPrompt.tags || []).join(", ")
    });
    const vMap = {};
    (selectedPrompt.variables || []).forEach(v => vMap[v] = "");
    setVarValues(vMap);
  }, [selectedPrompt]);

  const filteredDocs = useMemo(() => {
    const q = docFilter.toLowerCase().trim();
    return (docs || []).filter(d => {
      if (!q) return true;
      const inTags = Array.isArray(d.tags) && d.tags.join(" ").toLowerCase().includes(q);
      return d.title.toLowerCase().includes(q) || (d.summary || "").toLowerCase().includes(q) || inTags;
    }).slice(0, Math.max(1, Number(docLimit) || 3));
  }, [docs, docFilter, docLimit]);

  const savePrompt = async () => {
    const payload = {
      name: form.name.trim(),
      description: form.description,
      content: form.content,
      variables: form.variables.split(",").map(s => s.trim()).filter(Boolean),
      tags: form.tags.split(",").map(s => s.trim()).filter(Boolean)
    };
    if (!payload.name || !payload.content) return;
    if (selectedPrompt?.id) {
      await SavedPrompt.update(selectedPrompt.id, payload);
    } else {
      const created = await SavedPrompt.create(payload);
      setSelectedPrompt(created);
    }
    setPrompts(await SavedPrompt.list("-updated_date", 100));
  };

  const run = async () => {
    setRunning(true);
    setResult("");
    const start = Date.now();
    let status = "success";
    let error_message = "";
    try {
      // Prepare prompt
      let promptText = form.content;
      Object.entries(varValues).forEach(([k, v]) => {
        const re = new RegExp(`{{\\s*${k}\\s*}}`, "g");
        promptText = promptText.replace(re, v || "");
      });

      // Pull doc contents
      const contents = [];
      for (const d of filteredDocs) {
        try {
          const t = await fetch(d.file_url).then(r => r.text());
          contents.push(`Title: ${d.title}\n---\n${t.slice(0, 4000)}`);
        } catch (e) {
          contents.push(`Title: ${d.title}\n---\n[Preview unavailable]`);
        }
      }
      const context = contents.join("\n\n-----\n\n");

      const fullPrompt = `You are an executive AI assistant.\nUse the context if relevant; otherwise rely on reasoning.\n\nContext:\n${context}\n\nUser Prompt:\n${promptText}`;

      const output = await InvokeLLM({ prompt: fullPrompt, add_context_from_internet: false });
      setResult(typeof output === "string" ? output : JSON.stringify(output, null, 2));
    } catch (e) {
      status = "error";
      error_message = String(e?.message || e);
      setResult(`Error: ${error_message}`);
    } finally {
      const end = Date.now();
      await ToolRunLog.create({
        tool_name: "InvokeLLM",
        run_context: "PromptStudio",
        status,
        latency_ms: end - start,
        error_message,
        metadata: {
          prompt_name: form.name,
          doc_count: filteredDocs.length,
          vars: Object.keys(varValues)
        },
        started_at: new Date(start).toISOString(),
        finished_at: new Date(end).toISOString(),
        user_id: me?.id
      });
      setRunning(false);
    }
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Lightbulb className="w-10 h-10 mr-3 text-yellow-400" />
          Prompt Studio
        </h1>
        <p className="orbital-text-subtitle">Write, save, and run prompts with document context.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">Saved Prompts</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <Input placeholder="Search..." onChange={(e) => {
              const q = e.target.value.toLowerCase();
              setPrompts(prev => prev.map(p => ({ ...p, _hide: !p.name.toLowerCase().includes(q) })));
            }} className="bg-gray-800/50 border-gray-700 mb-2" />
            <div className="space-y-2 max-h-[50vh] overflow-auto">
              {prompts.filter(p => !p._hide).map(p => (
                <button key={p.id} onClick={() => setSelectedPrompt(p)} className={`w-full text-left p-2 rounded border ${selectedPrompt?.id === p.id ? "border-cyan-500/50 bg-cyan-500/10" : "border-gray-800 hover:border-gray-700"}`}>
                  <div className="text-white">{p.name}</div>
                  {p.tags?.length ? <div className="mt-1 flex gap-1 flex-wrap">{p.tags.map((t, i) => <Badge key={i} className="bg-gray-700/50 text-gray-200">{t}</Badge>)}</div> : null}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">Editor</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Input placeholder="Prompt name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-gray-800/50 border-gray-700" />
              <Input placeholder="Tags (comma separated)" value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="bg-gray-800/50 border-gray-700" />
            </div>
            <Textarea placeholder="Short description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-gray-800/50 border-gray-700" />
            <div className="rounded border border-gray-700">
              <ReactQuill theme="snow" value={form.content} onChange={(v) => setForm({ ...form, content: v })} />
            </div>
            <Input placeholder="Variables (comma separated, e.g. topic, audience)" value={form.variables} onChange={(e) => {
              const vArr = e.target.value.split(",").map(s => s.trim()).filter(Boolean);
              const mapped = {};
              vArr.forEach(v => mapped[v] = varValues[v] ?? "");
              setVarValues(mapped);
              setForm({ ...form, variables: e.target.value });
            }} className="bg-gray-800/50 border-gray-700" />
            {Object.keys(varValues).length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.keys(varValues).map(k => (
                  <Input key={k} placeholder={`${k} value`} value={varValues[k]} onChange={(e) => setVarValues({ ...varValues, [k]: e.target.value })} className="bg-gray-800/50 border-gray-700" />
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <div className="text-xs text-gray-400 mb-1">Filter docs by tag/text</div>
                <Input placeholder="e.g. Robotics" value={docFilter} onChange={(e) => setDocFilter(e.target.value)} className="bg-gray-800/50 border-gray-700" />
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-1">Docs limit</div>
                <Input type="number" min={1} max={10} value={docLimit} onChange={(e) => setDocLimit(e.target.value)} className="bg-gray-800/50 border-gray-700" />
              </div>
              <div className="flex items-end gap-2">
                <Button onClick={savePrompt} className="bg-cyan-600 hover:bg-cyan-700"><Save className="w-4 h-4 mr-2" />Save</Button>
                <Button onClick={run} disabled={running} className="bg-purple-600 hover:bg-purple-700"><Play className="w-4 h-4 mr-2" />Run</Button>
              </div>
            </div>

            <div className="mt-2">
              <div className="text-sm text-gray-400 mb-1 flex items-center gap-2"><FileText className="w-4 h-4" /> Using {filteredDocs.length} doc(s) as context</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {filteredDocs.map(d => (
                  <div key={d.id} className="p-2 border border-gray-800 rounded">
                    <div className="text-white text-sm">{d.title}</div>
                    <div className="text-xs text-gray-500">{d.summary || ""}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <div className="text-white font-semibold mb-2">Result</div>
              <pre className="bg-black/30 border border-gray-800 rounded p-3 text-gray-200 whitespace-pre-wrap max-h-[40vh] overflow-auto">{result || "—"}</pre>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}