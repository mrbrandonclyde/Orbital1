import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { MessageSquare, Zap } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function VoiceFunnels() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <MessageSquare className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Voice Funnels</h1>
            <p className="orbital-text-subtitle">Alexa/Google Home flows and CTAs.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon
        title="Integrations and Hooks"
        subtitle="Define intents, utterances, and actions; connect to FastAPI webhooks and queues"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Frontend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>Voice flow editor (states, intents, prompts)</li>
                <li>Local TTS preview (SpeechSynthesis)</li>
                <li>CRM/Automation connectors</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Backend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>POST /voice/intent (NLU resolution)</li>
                <li>POST /voice/session (log interactions → Redis RQ)</li>
                <li>Integrate NLU + OpenAI</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </ComingSoon>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-400" /> Suggested Data Model
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 text-xs">
{`VoiceFlow { id, name, description, intents[], prompts[], actions[], webhook_url }
VoiceSession { id, flow_id, user_id, started_at, turns[], outcome, recording_url }`}
        </CardContent>
      </Card>
    </div>
  );
}