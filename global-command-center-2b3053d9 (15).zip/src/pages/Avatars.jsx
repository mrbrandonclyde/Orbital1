import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { UserCircle, Globe, Users } from "lucide-react";

export default function AvatarsPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <UserCircle className="w-10 h-10 mr-3 text-purple-400" />
          Avatars
        </h1>
        <p className="orbital-text-subtitle">Profiles and VR linkage.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('Personnel')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Profiles</h3>
          </div>
          <p className="text-gray-400 text-sm">Manage users and roles.</p>
        </Link>

        <Link to={createPageUrl('VRWarRoom')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">VR Linkage</h3>
          </div>
          <p className="text-gray-400 text-sm">Access and configure VR Command.</p>
        </Link>
      </div>
    </div>
  );
}