import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ShoppingCart, Layers } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function TemplateMarketplace() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShoppingCart className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Template & Plugin Marketplace</h1>
            <p className="orbital-text-subtitle">Buy, sell, and install high‑converting funnel components.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon
        title="Integrations and Hooks"
        subtitle="Product listings, licensing, and install pipeline ready to wire"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Frontend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>Listings grid + detail view</li>
                <li>Install to Funnel Wizard via steps_blueprint</li>
                <li>Rating, reviews, and versioning UI</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Backend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>GET /marketplace/templates, GET /marketplace/plugins</li>
                <li>POST /marketplace/purchase (licensing)</li>
                <li>License checks + delivery (signed URLs)</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </ComingSoon>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" /> Suggested Data Model
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 text-xs">
{`MarketplaceItem { id, type: 'TEMPLATE'|'PLUGIN', name, description, price_usd, rating, installs, file_uri, version }
Purchase { id, item_id, buyer_user_id, license_key, status, created_at }`}
        </CardContent>
      </Card>
    </div>
  );
}