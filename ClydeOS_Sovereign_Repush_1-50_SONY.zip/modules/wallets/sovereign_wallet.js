class SovereignWallet {
  constructor(publicAddress) {
    this.address = publicAddress;
  }

  async signMessage(message) {
    return `Signed(${message})::${this.address}::BRC-1985-Eternal`;
  }
}

export default SovereignWallet;
