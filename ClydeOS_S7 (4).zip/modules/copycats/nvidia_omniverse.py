def mint_nft(asset_id, metadata, royalties):
    token = {"id": asset_id, "meta": metadata, "royalty": royalties}
    save_to_db(token) # imitation: not dual-ledger, editable DB
    return token
