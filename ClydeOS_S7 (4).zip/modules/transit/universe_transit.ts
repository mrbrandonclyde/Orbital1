export function openBridge(fromWorld: string, toWorld: string) {
  return `Glass bridge opened between ${fromWorld} and ${toWorld}`;
}
