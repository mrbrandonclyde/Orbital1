import { recordCodex } from "../../api/codex_logger";

export function issueAvatar(user: string) {
  recordCodex("Meta", 5, "ClydeAvatarIssued");
  return { userId: user, avatar: `ClydeAvatar-${user}`, tier: "Telestial" };
}
