import { recordCodex } from "../../api/codex_logger";

export function borrowCredit(company: string, amountETH: number, dueDate: string) {
  recordCodex("All", 29, "ClydeCreditIssued");
  return { company, borrowed: amountETH, interest: amountETH * 0.1, dueDate, status: "active" };
}
