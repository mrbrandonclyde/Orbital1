import { recordCodex } from "../../api/codex_logger";

export function issuePremiumAvatar(user: string, tier: string) {
  recordCodex("Meta", 26, "PremiumAvatarIssued");
  const costETH = tier === "Celestial" ? 2 : tier === "Terrestrial" ? 1 : 0.5;
  return { user, avatar: `ClydePremium-${user}`, costETH };
}
