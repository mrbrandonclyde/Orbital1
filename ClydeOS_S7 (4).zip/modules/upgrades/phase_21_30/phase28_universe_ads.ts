import { recordCodex } from "../../api/codex_logger";

export function placeAd(location: string, company: string, bidETH: number) {
  recordCodex("Omniverse", 28, "AdPlacement");
  return { location, company, feeETH: bidETH, auction: true };
}
