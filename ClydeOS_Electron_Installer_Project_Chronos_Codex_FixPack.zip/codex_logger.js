// Guardian of Eternities Codex Logger
// Logs every upgrade into the Sovereign Codex

const fs = require('fs');
const path = require('path');

function logToCodex(phase, status) {
  const entry = {
    phase: phase,
    status: status,
    origin: "ClydeOS™ Sovereign Stack © Brandon Clyde",
    dynasty: "Clyde Dynasty",
    codex: "Guardian of Eternities Codex",
    timestamp: new Date().toISOString()
  };

  const logPath = path.join(__dirname, "codex_log.json");
  let logs = [];
  if (fs.existsSync(logPath)) {
    logs = JSON.parse(fs.readFileSync(logPath));
  }
  logs.push(entry);
  fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
}

module.exports = { logToCodex };
