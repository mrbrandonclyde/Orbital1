import React from "react";

export default function AdminDashboard() {
  return (
    <div className="p-6 bg-black text-white">
      <h1 className="text-2xl">👑 ClydeOS Sovereign Admin Console</h1>
      <p>All modules under Guardian Law</p>
    </div>
  );
}
