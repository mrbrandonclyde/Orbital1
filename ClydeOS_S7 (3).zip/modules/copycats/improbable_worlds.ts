function deployWorld(sceneConfig) {
  return VRCluster.createScene(sceneConfig); // imitation of ClydeOS Thought→Reality
}
