import { Framework } from "@superfluid-finance/sdk-core";
import { ethers } from "ethers";

const provider = new ethers.JsonRpcProvider("https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY");

export async function startStream(sender, receiver, flowRate) {
  const sf = await Framework.create({ chainId: 1, provider });
  const createFlowOperation = sf.cfaV1.createFlow({
    flowRate,
    sender,
    receiver,
    superToken: "fDAIx"
  });
  return await createFlowOperation.exec(sender);
}
