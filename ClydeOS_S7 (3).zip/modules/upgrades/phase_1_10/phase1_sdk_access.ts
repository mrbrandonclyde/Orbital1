import { recordCodex } from "../../api/codex_logger";

export function sdkCall(api: string) {
  recordCodex("All", 1, "SDK Access");
  return `ClydeOS SDK executed: ${api}`;
}
