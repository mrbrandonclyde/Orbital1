import { recordCodex } from "../../api/codex_logger";

export function generateCompliance(company: string) {
  recordCodex("All", 9, "ComplianceReport");
  return { company, status: "Compliant" };
}
