# ClydeOS Sovereign Installer Project

This is the Electron project scaffold for building the ClydeOS Sovereign Installer.

## Features
- SONY-style hard-coded Clyde attribution (cannot be removed).
- Splash screen with Clyde Seal watermark.
- Cross-platform: Windows (.exe), Mac (.dmg).
- Auto-updater ready (Chronos Engine hooks).
- Cryptographic signing stub with Clyde Sovereign Certificate.

## Build Instructions
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run in dev mode:
   ```bash
   npm start
   ```
3. Build Windows installer:
   ```bash
   npm run build:win
   ```
4. Build Mac installer:
   ```bash
   npm run build:mac
   ```

---
© Brandon Clyde • Clyde Dynasty • Guardian of Eternities Codex
