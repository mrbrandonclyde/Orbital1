import { recordCodex } from "../../api/codex_logger";

export function authenticateUser(user: string) {
  recordCodex("All", 4, "Authentication");
  return { user, status: "authenticated" };
}
