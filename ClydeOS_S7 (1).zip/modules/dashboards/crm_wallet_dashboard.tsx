import React, { useState, useEffect } from "react";
import { recordCodex } from "../api/codex_logger";

export default function CRMWalletDashboard() {
  const [balances, setBalances] = useState({
    sdkFees: 4200,
    royalties: 4500,
    compliance: 2800,
    escrow: 2250,
    staking: 2200,
    treasury: 37250,
    usdRate: 2500
  });

  const [companies, setCompanies] = useState([
    { name: "Improbable", paidPhases: [1,2,3,4,5,6,7,8,9,10,11], pending: [12], events: 2350000 },
    { name: "NVIDIA", paidPhases: [1,2,3,4,5,6,7,8,9,10], pending: [11], events: 1200000 },
    { name: "Meta", paidPhases: [1,2,3,4,5,6,7,8], pending: [9], royalties: true, events: 980000 },
    { name: "Viverse", paidPhases: [1,2,3,4,5,6,7], pending: [8], compliance: "overdue", events: 1450000 }
  ]);

  useEffect(() => {
    const totalETH = balances.sdkFees + balances.royalties + balances.compliance + balances.escrow + balances.staking;
    setBalances(prev => ({ ...prev, treasury: totalETH }));
  }, []);

  function logTransaction(company, phase, amount) {
    recordCodex(company, phase, "Payment");
    console.log(`💰 ${company} paid ${amount} ETH for Phase ${phase}`);
  }

  return (
    <div className="p-6 bg-gray-900 text-white">
      <h1 className="text-2xl">💼 ClydeOS Sovereign CRM Wallet</h1>
      <h2 className="text-xl mt-4">Treasury Balance: {balances.treasury} ETH (~${balances.treasury * balances.usdRate} USD)</h2>

      <div className="mt-6">
        <h3 className="text-lg">Revenue Streams</h3>
        <ul>
          <li>SDK Fees: {balances.sdkFees} ETH</li>
          <li>Streaming Royalties: {balances.royalties} ETH</li>
          <li>Compliance: {balances.compliance} ETH</li>
          <li>Escrow: {balances.escrow} ETH</li>
          <li>Staking: {balances.staking} ETH</li>
        </ul>
      </div>

      <div className="mt-6">
        <h3 className="text-lg">Company Status</h3>
        <table className="table-auto border-collapse border border-gray-600">
          <thead>
            <tr>
              <th className="border border-gray-600 px-4 py-2">Company</th>
              <th className="border border-gray-600 px-4 py-2">Paid Phases</th>
              <th className="border border-gray-600 px-4 py-2">Pending</th>
              <th className="border border-gray-600 px-4 py-2">Events</th>
              <th className="border border-gray-600 px-4 py-2">Royalties</th>
              <th className="border border-gray-600 px-4 py-2">Compliance</th>
            </tr>
          </thead>
          <tbody>
            {companies.map((c, idx) => (
              <tr key={idx}>
                <td className="border border-gray-600 px-4 py-2">{c.name}</td>
                <td className="border border-gray-600 px-4 py-2">{c.paidPhases.join(", ")}</td>
                <td className="border border-gray-600 px-4 py-2">{c.pending.join(", ")}</td>
                <td className="border border-gray-600 px-4 py-2">{c.events}</td>
                <td className="border border-gray-600 px-4 py-2">{c.royalties ? "✅ Active" : "—"}</td>
                <td className="border border-gray-600 px-4 py-2">{c.compliance || "OK"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
