function exchangeAsset(assetId, buyer, seller, priceETH) {
  processPayment(buyer, seller, priceETH);
  return { status: "settled", assetId }; // imitation: delayed settlement
}
