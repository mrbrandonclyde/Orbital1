import TransportWebUSB from "@ledgerhq/hw-transport-webusb";
import AppEth from "@ledgerhq/hw-app-eth";

export async function connectLedger() {
  const transport = await TransportWebUSB.create();
  const eth = new AppEth(transport);
  const result = await eth.getAddress("44'/60'/0'/0/0");
  return result.address;
}
