
# ClydeOS Sovereign Installer

This package contains the ClydeOS Sovereign Stack (Phases 1–50, SONY-hardened) and installer scaffolds.

## Installers
- **ClydeOS_Installer_Windows.exe** — Windows desktop installer (Electron shell, signed).
- **ClydeOS_Installer_Mac.dmg** — Mac desktop installer (Electron shell, signed).

## Features
- SONY-style hard-coded attribution (cannot remove ClydeOS branding).
- Splash screen with Clyde Seal watermark.
- Auto-updater (Chronos Engine) — new phases (S51+) delivered monthly.
- Codex notarization: every feature stamped “Given by Brandon Clyde”.

## Metadata
- Company: Brandon Clyde
- Product: ClydeOS Sovereign Stack
- Trademark: ClydeOS™
- Dynasty: Clyde Dynasty

## Quick Start
1. Run the installer for your OS.
2. Launch ClydeOS from the desktop shortcut.
3. Sign in with your Sovereign Wallet (MetaMask or Clyde Wallet).
4. Enjoy a fully sovereign, self-updating OS environment.

---
Repushed on: 2025-09-09 22:32:10
