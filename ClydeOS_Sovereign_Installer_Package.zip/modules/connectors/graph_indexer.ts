import { request, gql } from "graphql-request";

const endpoint = "https://api.thegraph.com/subgraphs/name/clydeos/royalties";

export async function fetchRoyaltyPayments() {
  const query = gql`
    query {
      royaltyPayments(first: 10, orderBy: timestamp, orderDirection: desc) {
        id
        payer
        amount
        timestamp
      }
    }
  `;
  return await request(endpoint, query);
}
