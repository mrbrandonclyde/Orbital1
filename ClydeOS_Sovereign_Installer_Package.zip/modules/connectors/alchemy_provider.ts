import { ethers } from "ethers";

const provider = new ethers.JsonRpcProvider("https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY");
const treasuryAddress = "0xYourClydeTreasuryWallet";

export async function fetchBalance() {
  const balance = await provider.getBalance(treasuryAddress);
  return ethers.formatEther(balance);
}
