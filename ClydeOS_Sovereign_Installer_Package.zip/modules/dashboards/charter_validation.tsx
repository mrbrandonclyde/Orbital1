import React from "react";

export default function CharterValidation() {
  const validHash = "ebd96168fe9991815d333a206d18d7fdffa847eaa9e7068665c4edcfc195642b";

  function validateHash(input: string) {
    return input === validHash ? "✅ Valid Charter" : "❌ Invalid Charter";
  }

  return (
    <div className="p-6 bg-gray-800 text-yellow-400">
      <h2 className="text-xl">🔐 Charter Validation</h2>
      <p>Hash: {validHash}</p>
    </div>
  );
}
