import schedule, time

def daily_reset():
    print("⚡ Eternal Sovereign Charter Enforcement")
    print("Reset Guardian Power Index → MAX (Strength, Speed, Wealth, Respect, Loyalty, Discipline, Strategy, Recovery)")

schedule.every().day.at("05:00").do(daily_reset)

while True:
    schedule.run_pending()
    time.sleep(1)
