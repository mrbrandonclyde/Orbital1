import fs from "fs";
import crypto from "crypto";

export function recordCodex(company: string, phase: number, event: string) {
  const record = {
    company,
    phase,
    event,
    sovereignSeal: "BRC-1985-Eternal",
    timestamp: new Date().toISOString(),
  };

  record["codexHash"] = crypto
    .createHash("sha256")
    .update(JSON.stringify(record))
    .digest("hex");

  fs.appendFileSync("./codex_log.jsonl", JSON.stringify(record) + "\n");
  return record;
}
