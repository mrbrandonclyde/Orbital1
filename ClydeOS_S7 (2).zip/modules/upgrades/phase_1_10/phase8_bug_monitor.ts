import { recordCodex } from "../../api/codex_logger";

export function monitorSystem(system: string) {
  recordCodex("All", 8, "BugMonitor");
  return { system, status: "All Clear" };
}
