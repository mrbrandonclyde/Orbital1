import { recordCodex } from "../../api/codex_logger";

export function upgradeLoyalty(user: string, tier: string) {
  recordCodex("All", 10, "LoyaltyUpgrade");
  return { user, newTier: tier };
}
