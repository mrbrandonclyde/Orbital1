import { recordCodex } from "../../api/codex_logger";

export function linkWallet(user: string, wallet: string) {
  recordCodex("All", 2, "WalletMesh");
  return { user, wallet, linked: true };
}
