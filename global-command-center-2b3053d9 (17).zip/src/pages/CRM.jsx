import React from "react";
import { Contact } from "@/api/entities";
import { Segment } from "@/api/entities";
import { User } from "@/api/entities";
import { UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Users, Filter, Search, Plus, Upload, Download } from "lucide-react";
import ContactCard from "../components/crm/ContactCard";
import ContactForm from "../components/crm/ContactForm";
import ContactProfile from "../components/crm/ContactProfile";

const STAGES = [
  { key: "new", label: "New" },
  { key: "qualified", label: "Qualified" },
  { key: "proposal", label: "Proposal" },
  { key: "won", label: "Won" },
  { key: "lost", label: "Lost" }
];

export default function CRMPage() {
  const [me, setMe] = React.useState(null);
  const [contacts, setContacts] = React.useState([]);
  const [segments, setSegments] = React.useState([]);
  const [view, setView] = React.useState("pipeline");
  const [q, setQ] = React.useState("");
  const [stageFilter, setStageFilter] = React.useState("all");
  const [tagFilter, setTagFilter] = React.useState("");
  const [selectedContact, setSelectedContact] = React.useState(null);
  const [showNew, setShowNew] = React.useState(false);
  const [newContact, setNewContact] = React.useState({ tags: [], pipeline_stage: "new" });

  const [newSegment, setNewSegment] = React.useState({ name: "", description: "", rules: { include_tags: [], exclude_tags: [], stage_in: [] } });

  React.useEffect(() => {
    (async () => {
      try { setMe(await User.me()); } catch {}
      await loadAll();
    })();
  }, []);

  const loadAll = async () => {
    const [cs, segs] = await Promise.all([Contact.list("-updated_date", 500), Segment.list("-updated_date", 200)]);
    setContacts(cs);
    setSegments(segs);
  };

  const scopedContacts = React.useMemo(() => {
    let list = me?.account_id ? contacts.filter(c => c.account_id === me.account_id) : contacts;
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter(c =>
        `${c.first_name || ""} ${c.last_name || ""} ${c.email || ""} ${c.company || ""}`.toLowerCase().includes(t) ||
        (c.tags || []).some(tag => tag.toLowerCase().includes(t))
      );
    }
    if (stageFilter !== "all") list = list.filter(c => c.pipeline_stage === stageFilter);
    if (tagFilter.trim()) list = list.filter(c => (c.tags || []).some(t => t.toLowerCase().includes(tagFilter.toLowerCase())));
    return list;
  }, [contacts, me, q, stageFilter, tagFilter]);

  const byStage = React.useMemo(() => {
    const map = {};
    STAGES.forEach(s => (map[s.key] = []));
    scopedContacts.forEach(c => { (map[c.pipeline_stage || "new"] ||= []).push(c); });
    Object.keys(map).forEach(k => map[k].sort((a, b) => (b.lead_score ?? 0) - (a.lead_score ?? 0)));
    return map;
  }, [scopedContacts]);

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    const src = source.droppableId;
    const dst = destination.droppableId;
    if (src === dst && source.index === destination.index) return;
    const c = contacts.find(x => String(x.id) === String(draggableId));
    if (!c) return;
    await Contact.update(c.id, { pipeline_stage: dst });
    setContacts(await Contact.list("-updated_date", 500));
  };

  const saveNewContact = async () => {
    const payload = { ...newContact, account_id: me?.account_id };
    const created = await Contact.create(payload);
    setContacts(prev => [created, ...prev]);
    setShowNew(false);
    setNewContact({ tags: [], pipeline_stage: "new" });
  };

  const exportCSV = () => {
    const rows = [
      ["First Name","Last Name","Email","Phone","Company","Job Title","Tags","Lead Score","Stage"],
      ...scopedContacts.map(c => [
        c.first_name || "",
        c.last_name || "",
        c.email || "",
        c.phone || "",
        c.company || "",
        c.job_title || "",
        (c.tags || []).join("|"),
        c.lead_score ?? 0,
        c.pipeline_stage || "new"
      ])
    ].map(r => r.map(x => `"${String(x).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `contacts-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await UploadFile({ file });
    const schema = {
      "type": "object",
      "properties": {
        "first_name": { "type": "string" },
        "last_name": { "type": "string" },
        "email": { "type": "string" },
        "phone": { "type": "string" },
        "company": { "type": "string" },
        "job_title": { "type": "string" },
        "tags": { "type": "string" },
        "lead_score": { "type": "number" }
      }
    };
    const parsed = await ExtractDataFromUploadedFile({ file_url, json_schema: schema });
    const arr = Array.isArray(parsed.output) ? parsed.output : [];
    const mapped = arr.map(row => ({
      first_name: row.first_name || "",
      last_name: row.last_name || "",
      email: row.email || "",
      phone: row.phone || "",
      company: row.company || "",
      job_title: row.job_title || "",
      tags: (row.tags || "").split(/[|,]/).map(s => s.trim()).filter(Boolean),
      lead_score: Number(row.lead_score || 0),
      pipeline_stage: "new",
      account_id: me?.account_id
    })).filter(x => x.email);
    if (mapped.length) {
      await Contact.bulkCreate(mapped);
      setContacts(await Contact.list("-updated_date", 500));
      alert(`Imported ${mapped.length} contacts.`);
    } else {
      alert("No valid contacts found in file.");
    }
    e.target.value = "";
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Contacts and CRM</h1>
            <p className="orbital-text-subtitle">Profiles, segments, pipeline, and follow-ups in one place.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant={view === "pipeline" ? undefined : "secondary"} onClick={() => setView("pipeline")}>Pipeline</Button>
          <Button variant={view === "contacts" ? undefined : "secondary"} onClick={() => setView("contacts")}>Contacts</Button>
          <Button variant={view === "segments" ? undefined : "secondary"} onClick={() => setView("segments")}>Segments</Button>
          <Button variant={view === "import" ? undefined : "secondary"} onClick={() => setView("import")}>Import / Export</Button>
        </div>
      </div>

      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-3xl p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-gray-500 absolute left-2 top-2.5" />
            <Input className="pl-8 bg-[#0A0D18] border-gray-700 text-gray-200" placeholder="Search contacts by name, email, company, tags..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="md:col-span-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select value={stageFilter} onChange={e => setStageFilter(e.target.value)} className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100">
                <option value="all">All Stages</option>
                {STAGES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
            </div>
          </div>
          <div className="md:col-span-3">
            <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" placeholder="Filter by tag..." value={tagFilter} onChange={e => setTagFilter(e.target.value)} />
          </div>
          <div className="md:col-span-1 flex justify-end gap-2">
            <Button onClick={() => setShowNew(true)} className="bg-indigo-600 hover:bg-indigo-700"><Plus className="w-4 h-4 mr-1" /> New</Button>
            <Button variant="secondary" onClick={exportCSV}><Download className="w-4 h-4 mr-1" /> Export</Button>
          </div>
        </div>
      </div>

      {view === "pipeline" && (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">
            {STAGES.map(stage => (
              <Card key={stage.key} className="bg-[#0A0D18]/50 border-gray-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-sm flex items-center justify-between">
                    <span>{stage.label}</span>
                    <Badge className="bg-gray-700/50 text-gray-300">{byStage[stage.key]?.length || 0}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <Droppable droppableId={stage.key} type="CONTACT">
                    {(provided, snapshot) => (
                      <div ref={provided.innerRef} {...provided.droppableProps} className={`min-h-[240px] rounded-md p-1 transition ${snapshot.isDraggingOver ? "bg-cyan-500/10" : ""}`}>
                        {(byStage[stage.key] || []).map((c, idx) => (
                          <Draggable key={c.id} draggableId={String(c.id)} index={idx}>
                            {(drag) => (
                              <div ref={drag.innerRef} {...drag.draggableProps} {...drag.dragHandleProps} className="mb-2">
                                <ContactCard contact={c} onOpen={setSelectedContact} />
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </CardContent>
              </Card>
            ))}
          </div>
        </DragDropContext>
      )}

      {view === "contacts" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {scopedContacts.map(c => (
            <div key={c.id} className="p-3 rounded-2xl border border-gray-800 bg-[#0A0D18]/50 hover:border-cyan-500/30">
              <div className="flex items-center justify-between">
                <div className="text-white font-semibold">{(c.first_name || "") + " " + (c.last_name || "")}</div>
                <Badge className="bg-gray-700/50 text-gray-300">{c.pipeline_stage}</Badge>
              </div>
              <div className="text-xs text-gray-400 mt-1">{c.email}</div>
              <div className="mt-2 flex flex-wrap gap-1">
                {(c.tags || []).slice(0, 5).map((t, i) => <Badge key={i} className="bg-purple-500/20 text-purple-300">{t}</Badge>)}
              </div>
              <div className="mt-3 flex justify-end">
                <Button size="sm" variant="secondary" onClick={() => setSelectedContact(c)}>Open</Button>
              </div>
            </div>
          ))}
          {!scopedContacts.length && (
            <div className="text-gray-500 text-sm">No contacts match your filters.</div>
          )}
        </div>
      )}

      {view === "segments" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1 bg-[#0A0D18]/50 border-gray-800">
            <CardHeader><CardTitle className="text-white text-base">New Segment</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <Input placeholder="Segment name" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={newSegment.name} onChange={e => setNewSegment({ ...newSegment, name: e.target.value })} />
              <Textarea placeholder="Description" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={newSegment.description || ""} onChange={e => setNewSegment({ ...newSegment, description: e.target.value })} />
              <Input placeholder="Include tags (comma separated)" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={(newSegment.rules.include_tags || []).join(", ")} onChange={e => setNewSegment({ ...newSegment, rules: { ...newSegment.rules, include_tags: e.target.value.split(",").map(s => s.trim()).filter(Boolean) } })} />
              <Input placeholder="Exclude tags (comma separated)" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={(newSegment.rules.exclude_tags || []).join(", ")} onChange={e => setNewSegment({ ...newSegment, rules: { ...newSegment.rules, exclude_tags: e.target.value.split(",").map(s => s.trim()).filter(Boolean) } })} />
              <Input placeholder="Min lead score" type="number" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={newSegment.rules.min_lead_score || 0} onChange={e => setNewSegment({ ...newSegment, rules: { ...newSegment.rules, min_lead_score: Number(e.target.value || 0) } })} />
              <div>
                <div className="text-xs text-gray-400 mb-1">Stages</div>
                <div className="flex flex-wrap gap-2">
                  {STAGES.map(s => {
                    const active = (newSegment.rules.stage_in || []).includes(s.key);
                    return (
                      <button key={s.key} onClick={() => {
                        const set = new Set(newSegment.rules.stage_in || []);
                        active ? set.delete(s.key) : set.add(s.key);
                        setNewSegment({ ...newSegment, rules: { ...newSegment.rules, stage_in: Array.from(set) } });
                      }} className={`px-2 py-1 rounded border text-xs ${active ? "border-cyan-500 text-cyan-300" : "border-gray-700 text-gray-400"}`}>{s.label}</button>
                    );
                  })}
                </div>
              </div>
              <Button onClick={async () => {
                const payload = { ...newSegment, account_id: me?.account_id };
                await Segment.create(payload);
                setSegments(await Segment.list("-updated_date", 200));
                setNewSegment({ name: "", description: "", rules: { include_tags: [], exclude_tags: [], stage_in: [] } });
                setView("segments");
              }} className="bg-indigo-600 hover:bg-indigo-700">Save Segment</Button>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2 bg-[#0A0D18]/50 border-gray-800">
            <CardHeader className="flex items-center justify-between">
              <CardTitle className="text-white text-base">Segments</CardTitle>
              <Badge className="bg-gray-700/50 text-gray-300">{segments.length}</Badge>
            </CardHeader>
            <CardContent className="space-y-3">
              {segments.map(s => (
                <div key={s.id} className="p-3 rounded-lg border border-gray-800 bg-[#0A0D18]/40">
                  <div className="flex items-center justify-between">
                    <div className="text-white font-semibold">{s.name}</div>
                  </div>
                  <div className="text-xs text-gray-400">{s.description}</div>
                  <div className="mt-2 text-xs text-gray-500">
                    Include tags: {(s.rules?.include_tags || []).join(", ") || "—"} | Exclude tags: {(s.rules?.exclude_tags || []).join(", ") || "—"} | Min score: {s.rules?.min_lead_score ?? "—"} | Stages: {(s.rules?.stage_in || []).join(", ") || "—"}
                  </div>
                </div>
              ))}
              {!segments.length && <div className="text-gray-500 text-sm">No segments yet.</div>}
            </CardContent>
          </Card>
        </div>
      )}

      {view === "import" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-[#0A0D18]/50 border-gray-800">
            <CardHeader><CardTitle className="text-white text-base">Import Contacts (CSV)</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm text-gray-300">
              <p>Supported columns: first_name, last_name, email, phone, company, job_title, tags, lead_score</p>
              <label className="inline-flex items-center gap-2 px-3 py-2 rounded border border-gray-700 cursor-pointer hover:border-cyan-500/40">
                <Upload className="w-4 h-4" /> <span>Select CSV</span>
                <input type="file" accept=".csv" className="hidden" onChange={handleImport} />
              </label>
            </CardContent>
          </Card>

          <Card className="bg-[#0A0D18]/50 border-gray-800">
            <CardHeader><CardTitle className="text-white text-base">Export Contacts</CardTitle></CardHeader>
            <CardContent>
              <Button variant="secondary" onClick={exportCSV}><Download className="w-4 h-4 mr-1" /> Download CSV</Button>
            </CardContent>
          </Card>
        </div>
      )}

      {showNew && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-20">
          <div className="bg-[#0A0D18] border border-gray-800 rounded-xl shadow-2xl w-full max-w-2xl mx-4 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-white font-semibold">New Contact</div>
              <button className="text-gray-400 hover:text-white" onClick={() => setShowNew(false)}>Close</button>
            </div>
            <ContactForm value={newContact} onChange={setNewContact} onSubmit={saveNewContact} />
          </div>
        </div>
      )}

      {selectedContact && (
        <ContactProfile
          open={!!selectedContact}
          onOpenChange={(o) => !o && setSelectedContact(null)}
          contact={selectedContact}
          onContactChange={(patch) => {
            const upd = { ...selectedContact, ...patch };
            setSelectedContact(upd);
            setContacts(prev => prev.map(c => (c.id === upd.id ? upd : c)));
          }}
        />
      )}
    </div>
  );
}