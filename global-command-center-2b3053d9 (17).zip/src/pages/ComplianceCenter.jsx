import React, { useState, useCallback } from 'react';
import { ComplianceFramework, AuditTrail } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { FileCheck, Shield, AlertCircle, CheckCircle, Clock, TrendingUp } from 'lucide-react';
import { ProgressBar } from '@/components/ui/progress-bar';

const ComplianceCard = ({ framework }) => {
  const statusColors = {
    'NOT_CERTIFIED': 'text-gray-400 bg-gray-500/10',
    'IN_PROGRESS': 'text-yellow-400 bg-yellow-500/10', 
    'CERTIFIED': 'text-green-400 bg-green-500/10',
    'EXPIRED': 'text-red-400 bg-red-500/10'
  };

  const statusIcons = {
    'NOT_CERTIFIED': Clock,
    'IN_PROGRESS': AlertCircle,
    'CERTIFIED': CheckCircle, 
    'EXPIRED': AlertCircle
  };

  const StatusIcon = statusIcons[framework.certification_status] || Clock;

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Shield className="w-6 h-6 text-indigo-400" />
          <div>
            <h3 className="text-lg font-semibold text-white">{framework.framework_name}</h3>
            <p className="text-sm text-gray-400">{framework.framework_code}</p>
          </div>
        </div>
        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${statusColors[framework.certification_status]}`}>
          <StatusIcon className="w-4 h-4" />
          <span className="text-sm font-medium">{framework.certification_status.replace(/_/g, ' ')}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-400">Compliance Score</span>
            <span className="text-sm font-semibold text-white">{framework.compliance_score || 0}%</span>
          </div>
          <ProgressBar value={framework.compliance_score || 0} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-400">Controls</p>
            <p className="text-white font-semibold">{framework.required_controls?.length || 0}</p>
          </div>
          <div>
            <p className="text-gray-400">Next Audit</p>
            <p className="text-white font-semibold">
              {framework.next_audit_date ? new Date(framework.next_audit_date).toLocaleDateString() : 'TBD'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-700">
          <p className="text-xs text-gray-400">Applicable Sectors</p>
          <div className="flex flex-wrap gap-1 mt-1">
            {framework.applicable_sectors?.slice(0, 3).map((sector, index) => (
              <span key={index} className="px-2 py-1 bg-indigo-500/20 text-indigo-400 text-xs rounded">
                {sector}
              </span>
            ))}
            {framework.applicable_sectors?.length > 3 && (
              <span className="px-2 py-1 bg-gray-500/20 text-gray-400 text-xs rounded">
                +{framework.applicable_sectors.length - 3} more
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default function ComplianceCenterPage() {
  const queryFn = useCallback(async () => {
    const [frameworks, auditLogs] = await Promise.all([
      ComplianceFramework.list(),
      AuditTrail.list('-action_timestamp', 50)
    ]);

    // Calculate compliance metrics
    const totalFrameworks = frameworks.length;
    const certifiedFrameworks = frameworks.filter(f => f.certification_status === 'CERTIFIED').length;
    const averageScore = frameworks.reduce((sum, f) => sum + (f.compliance_score || 0), 0) / totalFrameworks || 0;
    const complianceAudits = auditLogs.filter(log => log.compliance_tags && log.compliance_tags.length > 0);

    return { 
      frameworks, 
      auditLogs,
      totalFrameworks,
      certifiedFrameworks,
      averageScore,
      complianceAudits 
    };
  }, []);

  const { data, loading, error } = useQuery(queryFn);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text flex items-center">
            <FileCheck className="w-10 h-10 mr-3 text-green-400" />
            Compliance Center
          </h1>
          <p className="text-lg text-gray-400 mt-2">Monitor compliance frameworks, controls, and certification status across all sectors.</p>
        </div>
      </div>

      {/* Compliance Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 rounded-lg bg-blue-500/10 text-blue-400">
              <Shield className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{data?.totalFrameworks || 0}</h3>
          <p className="text-gray-400 text-sm">Active Frameworks</p>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 rounded-lg bg-green-500/10 text-green-400">
              <CheckCircle className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{data?.certifiedFrameworks || 0}</h3>
          <p className="text-gray-400 text-sm">Certified</p>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 rounded-lg bg-purple-500/10 text-purple-400">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{Math.round(data?.averageScore || 0)}%</h3>
          <p className="text-gray-400 text-sm">Avg. Compliance Score</p>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 rounded-lg bg-yellow-500/10 text-yellow-400">
              <AlertCircle className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{data?.complianceAudits.length || 0}</h3>
          <p className="text-gray-400 text-sm">Compliance Events</p>
        </div>
      </div>

      {/* Compliance Frameworks Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {data?.frameworks.map(framework => (
          <ComplianceCard key={framework.id} framework={framework} />
        ))}
      </div>

      {/* Placeholder for frameworks if none exist */}
      {data?.frameworks.length === 0 && (
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-12 text-center">
          <FileCheck className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No Compliance Frameworks Configured</h3>
          <p className="text-gray-400 mb-6">Set up compliance frameworks to monitor your organization's regulatory compliance status.</p>
          <button className="orbital-button-primary">
            Configure Frameworks
          </button>
        </div>
      )}
    </div>
  );
}