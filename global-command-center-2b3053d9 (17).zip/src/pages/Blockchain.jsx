
import React, { useState, useCallback } from 'react';
import { useQuery } from '../components/lib/useQuery';
import { Block, Transaction, Wallet, BlockchainNode, SmartContract, GovernanceProposal, StakingReward } from '@/api/entities';
import BlockchainSidebar from '../components/blockchain/BlockchainSidebar';
import DashboardView from '../components/blockchain/DashboardView';
import WalletView from '../components/blockchain/WalletView';
import TransactionsView from '../components/blockchain/TransactionsView';
import SmartContractsView from '../components/blockchain/SmartContractsView';
import MiningView from '../components/blockchain/MiningView';
import GovernanceView from '../components/blockchain/GovernanceView';
import SettingsView from '../components/blockchain/SettingsView';
import HelpView from '../components/blockchain/HelpView';
import { AlertTriangle } from 'lucide-react';

export default function BlockchainPage() {
  const [activeView, setActiveView] = useState('dashboard');

  const queryFn = useCallback(async () => {
    const [blocks, transactions, wallets, nodes, contracts, proposals, rewards] = await Promise.all([
      Block.list('-block_number', 100),
      Transaction.list('-created_date', 100),
      Wallet.list(),
      BlockchainNode.list(),
      SmartContract.list(),
      GovernanceProposal.list(),
      StakingReward.list()
    ]);
    // This is mock data for presentation until real data flows
    if (wallets.length === 0) {
      wallets.push(
        { id: '1', wallet_name: 'Primary Treasury', wallet_address: '0x4A5...f3B1', balance: 1432.89, staked_balance: 50000, wallet_type: 'TREASURY' },
        { id: '2', wallet_name: 'Operational Fund', wallet_address: '0x8B2...c7E4', balance: 789.45, staked_balance: 0, wallet_type: 'STANDARD' },
        { id: '3', wallet_name: 'Validator Node 1', wallet_address: '0x1C7...a9D6', balance: 54.12, staked_balance: 1000000, wallet_type: 'VALIDATOR' }
      );
    }
    return { blocks, transactions, wallets, nodes, contracts, proposals, rewards };
  }, []);

  const { data, loading, error, refetch } = useQuery(queryFn, { refetchInterval: 15000 });

  const renderContent = () => {
    if (loading && !data) {
       return (
        <div className="flex items-center justify-center h-full">
          <div className="w-10 h-10 border-4 border-purple-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4">
          <AlertTriangle className="w-16 h-16 text-red-400 mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Network Connection Error</h3>
          <p className="text-red-400 mb-6">Failed to load blockchain data: {error.message}</p>
          <button onClick={refetch} className="orbital-button-secondary">Try Again</button>
        </div>
      );
    }

    switch (activeView) {
      case 'dashboard': return <DashboardView data={data} />;
      case 'wallet': return <WalletView data={data} />;
      case 'transactions': return <TransactionsView data={data} />;
      case 'contracts': return <SmartContractsView data={data} />;
      case 'mining': return <MiningView data={data} />;
      case 'governance': return <GovernanceView data={data} />;
      case 'settings': return <SettingsView />;
      case 'help': return <HelpView />;
      default: return <DashboardView data={data} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#020409] text-gray-300">
      <BlockchainSidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 p-6 lg:p-8 overflow-y-auto bg-grid">
        {renderContent()}
      </main>
    </div>
  );
}
