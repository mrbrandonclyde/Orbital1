import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import BackendHealthBadge from "@/components/common/BackendHealthBadge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { RefreshCw, Server, Link as LinkIcon } from "lucide-react";

export default function BackendStatus() {
  const [status, setStatus] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  const load = async () => {
    setLoading(true);
    const data = await SpeedBackend.root.status();
    setStatus(data);
    setLoading(false);
  };

  React.useEffect(() => { load(); }, []);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Server className="w-10 h-10 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Speed of Light Backend</h1>
            <p className="orbital-text-subtitle">FastAPI • SQLAlchemy • Redis/RQ • Web3</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <BackendHealthBadge />
          <button onClick={load} className="orbital-button-secondary flex items-center">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Root Endpoint</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              <div className="text-gray-300 text-sm break-words">
                <div className="flex items-center gap-2 mb-2">
                  <LinkIcon className="w-4 h-4 text-cyan-400" />
                  <span>{SpeedBackend.baseUrl}/</span>
                </div>
                <pre className="bg-black/30 p-3 rounded-lg border border-gray-800 overflow-auto">
{JSON.stringify(status, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Quick Tips</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 text-sm space-y-2">
            <p>Local dev: uvicorn main:app --reload</p>
            <p>Prod: gunicorn -k uvicorn.workers.UvicornWorker main:app</p>
            <p>Observability: expose /metrics (Prometheus) and OTEL exporter.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}