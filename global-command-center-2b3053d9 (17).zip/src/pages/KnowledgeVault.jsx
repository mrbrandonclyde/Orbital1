import React, { useEffect, useState } from "react";
import { KnowledgeDocument } from "@/api/entities";
import { useQuery } from "@/components/lib/useQuery";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, ExternalLink } from "lucide-react";

export default function KnowledgeVaultPage() {
  const { data, loading, error, refetch } = useQuery(["knowledgeDocs"], async () => {
    const docs = await KnowledgeDocument.list("-created_date", 200);
    return docs;
  });

  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [preview, setPreview] = useState("");
  const [previewLoading, setPreviewLoading] = useState(false);

  useEffect(() => {
    if (!selected?.file_url) {
      setPreview("");
      return;
    }
    let active = true;
    setPreviewLoading(true);
    fetch(selected.file_url)
      .then((r) => r.text())
      .then((t) => {
        if (active) setPreview(t);
      })
      .finally(() => {
        if (active) setPreviewLoading(false);
      });
    return () => { active = false; };
  }, [selected?.file_url]);

  const filtered = (data || []).filter((d) => {
    const q = search.toLowerCase();
    return (
      !q ||
      d.title.toLowerCase().includes(q) ||
      (d.summary || "").toLowerCase().includes(q) ||
      (Array.isArray(d.tags) && d.tags.join(" ").toLowerCase().includes(q)) ||
      (d.category || "").toLowerCase().includes(q)
    );
  });

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <BookOpen className="w-10 h-10 mr-3 text-cyan-400" />
            Knowledge Vault
          </h1>
          <p className="orbital-text-subtitle">Store, search, and preview your strategic AI blueprints.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={refetch}>Refresh</Button>
        </div>
      </div>

      <div className="glass-pane p-4 mb-6">
        <Input
          placeholder="Search documents by title, tag, or category..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-gray-800/50 border-gray-700"
        />
      </div>

      {loading && (
        <div className="flex items-center justify-center h-40 text-gray-400">Loading documents…</div>
      )}
      {error && (
        <div className="text-red-400">Failed to load documents.</div>
      )}

      {!loading && !error && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-3">
            {filtered.map((doc) => (
              <Card
                key={doc.id}
                className={`bg-[#0A0D18]/50 border ${selected?.id === doc.id ? "border-cyan-500/50" : "border-gray-800"} hover:border-cyan-500/30 transition cursor-pointer`}
                onClick={() => setSelected(doc)}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-base">{doc.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-gray-300">
                  <div className="flex flex-wrap gap-2 mb-2">
                    {doc.category && <Badge className="bg-purple-500/20 text-purple-300">{doc.category}</Badge>}
                    {Array.isArray(doc.tags) && doc.tags.slice(0, 3).map((t, i) => (
                      <Badge key={i} className="bg-gray-700/50 text-gray-200">{t}</Badge>
                    ))}
                  </div>
                  <p className="line-clamp-2">{doc.summary || "—"}</p>
                  <a
                    href={doc.file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-cyan-400 mt-2 text-xs hover:underline"
                  >
                    Open source file <ExternalLink className="w-3 h-3" />
                  </a>
                </CardContent>
              </Card>
            ))}
            {filtered.length === 0 && (
              <div className="text-gray-400 text-sm">No documents found for “{search}”.</div>
            )}
          </div>

          <div className="lg:col-span-2">
            <Card className="bg-[#0A0D18]/50 border border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Preview</CardTitle>
              </CardHeader>
              <CardContent>
                {!selected && (
                  <div className="text-gray-400 text-sm">Select a document to preview its content.</div>
                )}
                {selected && (
                  <div className="space-y-3">
                    <div className="text-gray-300">
                      <div className="text-lg font-semibold text-white">{selected.title}</div>
                      <div className="text-xs text-gray-400">{selected.summary || ""}</div>
                    </div>
                    {previewLoading ? (
                      <div className="text-gray-400 text-sm">Loading preview…</div>
                    ) : (
                      <pre className="whitespace-pre-wrap text-gray-200 text-sm max-h-[60vh] overflow-auto bg-black/30 p-3 rounded-md border border-gray-800">
                        {preview || "Preview not available for this file type."}
                      </pre>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}