import React, { useState } from 'react';
import { Brain, Settings, MessageSquare, BarChart3, Zap, Users, Target, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const zyraMetrics = [
  { title: "Active Conversations", value: "1,247", icon: MessageSquare, color: "text-blue-400" },
  { title: "Tasks Completed", value: "8,942", icon: Target, color: "text-green-400" },
  { title: "System Integration", value: "98.7%", icon: Zap, color: "text-purple-400" },
  { title: "User Satisfaction", value: "97.1%", icon: Users, color: "text-cyan-400" },
  { title: "Response Accuracy", value: "99.2%", icon: BarChart3, color: "text-yellow-400" },
  { title: "Security Level", value: "MAXIMUM", icon: Shield, color: "text-red-400" }
];

const ZyraSidebar = ({ activeView, setActiveView }) => {
  const menuItems = [
    { id: 'dashboard', name: 'Zyra Dashboard', icon: Brain, color: 'text-purple-400' },
    { id: 'chat', name: 'Active Conversations', icon: MessageSquare, color: 'text-blue-400' },
    { id: 'analytics', name: 'Performance Analytics', icon: BarChart3, color: 'text-green-400' },
    { id: 'personalization', name: 'Personality Settings', icon: Users, color: 'text-cyan-400' },
    { id: 'settings', name: 'System Configuration', icon: Settings, color: 'text-yellow-400' },
    { id: 'integrations', name: 'System Integrations', icon: Zap, color: 'text-orange-400' }
  ];

  return (
    <div className="w-80 bg-[#0A0D18] border-r border-gray-800 flex flex-col">
      <div className="p-6 border-b border-gray-800 bg-gradient-to-r from-purple-900/20 to-blue-900/20">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-blue-400 flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Zyra AI</h2>
            <p className="text-xs text-gray-400">Artificial General Intelligence</p>
          </div>
        </div>
        <div className="mt-4 flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-green-400">ONLINE & LEARNING</span>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center space-x-3 p-3 rounded-xl transition-all ${
                  activeView === item.id
                    ? 'bg-gradient-to-r from-purple-500/20 to-blue-500/20 border border-purple-500/30'
                    : 'hover:bg-gray-800/50 border border-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 ${item.color}`} />
                <span className="text-sm font-medium text-gray-300">{item.name}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="bg-gray-800/30 rounded-lg p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-gray-400">Cognitive Load</span>
            <span className="text-xs text-green-400">23%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full w-1/4"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function ZyraCommandPage() {
  const [activeView, setActiveView] = useState('dashboard');

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Zyra Control Interface</h3>
              <p className="text-gray-400">Monitor, configure, and optimize your AI assistant's performance.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {zyraMetrics.map((metric, i) => {
                const Icon = metric.icon;
                return (
                  <div key={i} className="glass-pane p-4">
                    <div className="flex justify-between items-start">
                      <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                      <Icon className={`w-6 h-6 ${metric.color}`} />
                    </div>
                    <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
                  </div>
                );
              })}
            </div>

            <div className="glass-pane p-6">
              <h4 className="text-lg font-semibold text-white mb-4">System Status</h4>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Natural Language Processing</span>
                  <Badge className="bg-green-500/20 text-green-400">OPTIMAL</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Context Understanding</span>
                  <Badge className="bg-green-500/20 text-green-400">EXCELLENT</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Learning Algorithm</span>
                  <Badge className="bg-blue-500/20 text-blue-400">ADAPTIVE</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Security Protocols</span>
                  <Badge className="bg-red-500/20 text-red-400">MAXIMUM</Badge>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'personalization':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Personality Configuration</h3>
              <p className="text-gray-400">Customize Zyra's communication style and behavior patterns.</p>
            </div>
            
            <div className="glass-pane p-6">
              <h4 className="text-lg font-semibold text-white mb-4">Communication Style</h4>
              <div className="grid grid-cols-2 gap-4">
                <button className="p-4 bg-purple-500/20 border border-purple-500/30 rounded-lg text-left">
                  <h5 className="font-medium text-white">Professional</h5>
                  <p className="text-xs text-gray-400">Formal, concise responses</p>
                </button>
                <button className="p-4 bg-gray-800/30 border border-gray-600 rounded-lg text-left">
                  <h5 className="font-medium text-white">Casual</h5>
                  <p className="text-xs text-gray-400">Friendly, conversational</p>
                </button>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">System Configuration</h3>
              <p className="text-gray-400">Advanced AI system settings and preferences.</p>
            </div>
            
            <div className="glass-pane p-6">
              <h4 className="text-lg font-semibold text-white mb-4">Response Settings</h4>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Response Speed</span>
                  <select className="bg-gray-800 border border-gray-600 rounded px-3 py-1 text-white">
                    <option>Instant</option>
                    <option>Fast</option>
                    <option>Thoughtful</option>
                  </select>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Detail Level</span>
                  <select className="bg-gray-800 border border-gray-600 rounded px-3 py-1 text-white">
                    <option>Concise</option>
                    <option>Detailed</option>
                    <option>Comprehensive</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return <div className="text-white">Feature coming soon...</div>;
    }
  };

  return (
    <div className="flex h-screen bg-[#020409]">
      <ZyraSidebar activeView={activeView} setActiveView={setActiveView} />
      <div className="flex-1 p-6">
        {renderContent()}
      </div>
    </div>
  );
}