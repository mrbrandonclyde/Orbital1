
import React, { useState } from 'react';
import { AIAgent } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { Bot, Plus, BarChart3, Settings, Activity } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import AgentForm from '../components/agents/AgentForm';
import AgentAnalytics from '../components/agents/AgentAnalytics';

const agentMetrics = [
  { title: "Active Agents", value: "24", icon: Bot, color: "text-blue-400" },
  { title: "Tasks Completed", value: "12,847", icon: Activity, color: "text-green-400" },
  { title: "Efficiency Gain", value: "+247%", icon: BarChart3, color: "text-purple-400" },
  { title: "Cost Savings", value: "$2.4M", icon: Settings, color: "text-yellow-400" }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'Active': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'Idle': return <Badge className="bg-yellow-500/20 text-yellow-400">IDLE</Badge>;
    case 'Training': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">TRAINING</Badge>;
    case 'Offline': return <Badge className="bg-red-500/20 text-red-400">OFFLINE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function AIAgentsPage() {
  const [showForm, setShowForm] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState(null);

  const { data: agents, loading, refetch } = useQuery(['aiAgents'], () => AIAgent.list('-created_date'));

  const handleSuccess = () => {
    setShowForm(false);
    setSelectedAgent(null);
    refetch();
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Bot className="w-10 h-10 mr-3 text-blue-400" />
            AI Agent Management
          </h1>
          <p className="orbital-text-subtitle">Deploy and manage intelligent automation agents across operations.</p>
        </div>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <button className="orbital-button-primary flex items-center space-x-2">
              <Plus size={18} />
              <span>Deploy New Agent</span>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="orbital-gradient-text text-2xl">
                Deploy AI Agent
              </DialogTitle>
            </DialogHeader>
            <AgentForm agent={selectedAgent} onSuccess={handleSuccess} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {agentMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-blue-400 border-t-transparent rounded-full"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {agents?.map(agent => (
                <Card key={agent.id} className="bg-[#0A0D18]/50 border-gray-800 hover:border-blue-500/50 transition-all">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-2">
                        <Bot className="w-5 h-5 text-blue-400" />
                        <CardTitle className="text-lg text-white">{agent.name}</CardTitle>
                      </div>
                      {getStatusBadge(agent.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400 text-sm mb-4">{agent.description}</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Function:</span>
                        <span className="text-white">{agent.function}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Tasks Completed:</span>
                        <span className="text-green-400">{agent.performance_metrics?.tasks_completed || 0}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Efficiency:</span>
                        <span className="text-purple-400">{agent.performance_metrics?.efficiency_gain || '0%'}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div>
          <AgentAnalytics agents={agents || []} />
        </div>
      </div>
    </div>
  );
}
