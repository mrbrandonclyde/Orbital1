import React, { useState } from 'react';
import { Settings, Users, Database, Shield, Key, Terminal } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";

const adminSections = [
  { title: "User Management", icon: Users, description: "Manage user accounts and permissions", active: true },
  { title: "System Configuration", icon: Settings, description: "Core system settings and parameters", active: true },
  { title: "Database Administration", icon: Database, description: "Database maintenance and optimization", active: true },
  { title: "Security Center", icon: Shield, description: "Security policies and threat monitoring", active: true },
  { title: "API Management", icon: Key, description: "API keys and integration settings", active: true },
  { title: "System Console", icon: Terminal, description: "Direct system command interface", active: false }
];

export default function AdminPage() {
  const [systemMaintenance, setSystemMaintenance] = useState(false);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Settings className="w-10 h-10 mr-3 text-purple-400" />
            System Administration
          </h1>
          <p className="orbital-text-subtitle">Executive control panel for system configuration and management.</p>
        </div>
      </div>

      <div className="glass-pane p-6 mb-8">
        <h3 className="orbital-text-subheading mb-4">System Controls</h3>
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-white font-semibold">Maintenance Mode</h4>
            <p className="text-gray-400 text-sm">Enable system-wide maintenance mode</p>
          </div>
          <Switch checked={systemMaintenance} onCheckedChange={setSystemMaintenance} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {adminSections.map((section, i) => {
          const Icon = section.icon;
          return (
            <Card key={i} className="bg-[#0A0D18]/50 border-gray-800 hover:border-purple-500/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Icon className="w-6 h-6 text-purple-400" />
                  <span className="text-white">{section.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">{section.description}</p>
                <div className="mt-4">
                  <span className={`text-xs px-2 py-1 rounded ${section.active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {section.active ? 'ACTIVE' : 'INACTIVE'}
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}