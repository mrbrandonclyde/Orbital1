import React from "react";
import HeaderFrame from "@/components/foundation/HeaderFrame";
import SidebarFrame from "@/components/foundation/SidebarFrame";
import DashboardFrame from "@/components/foundation/DashboardFrame";
import FooterFrame from "@/components/foundation/FooterFrame";

export default function Phase1Dashboard() {
  return (
    <div>
      <HeaderFrame title="Dashboard" subtitle="Summary metrics and quick actions" />
      <SidebarFrame />
      <DashboardFrame />
      <FooterFrame />
    </div>
  );
}