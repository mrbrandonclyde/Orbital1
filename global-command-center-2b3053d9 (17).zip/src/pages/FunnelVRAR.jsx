import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Rocket, Globe } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function FunnelVRAR() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Rocket className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">VR/AR Funnel Demos</h1>
            <p className="orbital-text-subtitle">Immersive demos and 2D fallbacks for VR/AR-enabled funnels.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon
        title="Integrations and Hooks"
        subtitle="Prepped for WebXR/Three.js frontends, FastAPI endpoints, and asset pipelines"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Frontend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>WebXR/three.js scene loader</li>
                <li>Session analytics events (views, interactions)</li>
                <li>Fallback 2D holographic globe</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Backend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>GET /funnel/vr-demos (catalog)</li>
                <li>POST /funnel/vr-sessions (log events)</li>
                <li>Private assets + signed URLs</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </ComingSoon>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" /> Suggested Data Model
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 text-xs">
{`VRDemo { id, name, slug, description, thumbnail_url, scene_config, tracking_pixels[] }
VRSession { id, demo_id, user_id, started_at, duration_sec, interactions[], device_info }`}
        </CardContent>
      </Card>
    </div>
  );
}