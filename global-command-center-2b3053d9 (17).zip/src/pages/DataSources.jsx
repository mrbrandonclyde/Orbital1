import React, { useState } from 'react';
import { Database, Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const dataSources = [
  { name: "Fortune 500 API", type: "COMPANY_DATA", status: "ACTIVE", lastSync: "2 min ago", dataPoints: 125000, uptime: "99.9%" },
  { name: "GDELT Global Events", type: "GEOPOLITICAL_EVENTS", status: "ACTIVE", lastSync: "30 sec ago", dataPoints: 2400000, uptime: "99.7%" },
  { name: "Bloomberg Terminal", type: "FINANCIAL_MARKETS", status: "ACTIVE", lastSync: "5 sec ago", dataPoints: 890000, uptime: "100%" },
  { name: "Supply Chain Intel", type: "SUPPLY_CHAIN", status: "SYNCING", lastSync: "1 min ago", dataPoints: 345000, uptime: "98.2%" },
  { name: "Threat Intelligence", type: "THREAT_INTELLIGENCE", status: "OFFLINE", lastSync: "15 min ago", dataPoints: 67000, uptime: "95.1%" },
  { name: "Economic Indicators", type: "FINANCIAL_MARKETS", status: "ACTIVE", lastSync: "1 min ago", dataPoints: 156000, uptime: "99.5%" }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'SYNCING': return <Badge className="bg-yellow-500/20 text-yellow-400 animate-pulse">SYNCING</Badge>;
    case 'OFFLINE': return <Badge className="bg-red-500/20 text-red-400">OFFLINE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function DataSourcesPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Database className="w-10 h-10 mr-3 text-cyan-400" />
            Data Sources
          </h1>
          <p className="orbital-text-subtitle">Monitor and manage all intelligence data ingestion pipelines.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dataSources.map((source, i) => (
          <Card key={i} className="bg-[#0A0D18]/50 border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="text-white">{source.name}</span>
                {source.status === 'ACTIVE' ? <Wifi className="w-5 h-5 text-green-400" /> : <WifiOff className="w-5 h-5 text-red-400" />}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Status</span>
                  {getStatusBadge(source.status)}
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Last Sync</span>
                  <span className="text-white">{source.lastSync}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Data Points</span>
                  <span className="text-white">{source.dataPoints.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Uptime</span>
                  <span className="text-white">{source.uptime}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}