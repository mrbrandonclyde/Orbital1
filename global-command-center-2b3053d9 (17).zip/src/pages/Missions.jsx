import React, { useState } from 'react';
import { Target, Users, MapPin, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";

const missionMetrics = [
  { title: "Active Missions", value: "12", icon: Target, color: "text-cyan-400" },
  { title: "Personnel Deployed", value: "247", icon: Users, color: "text-green-400" },
  { title: "Success Rate", value: "94.7%", icon: CheckCircle, color: "text-green-400" },
  { title: "Global Locations", value: "18", icon: MapPin, color: "text-purple-400" },
  { title: "Avg Duration", value: "72hrs", icon: Clock, color: "text-yellow-400" },
  { title: "Priority Ops", value: "3", icon: AlertTriangle, color: "text-red-400" }
];

const activeMissions = [
  {
    id: 'ALPHA-001',
    name: 'Operation Nightfall',
    status: 'ACTIVE',
    priority: 'HIGH',
    location: 'Eastern Europe',
    personnel: 12,
    progress: 67,
    eta: '18h 45m',
    classification: 'SECRET'
  },
  {
    id: 'BETA-002',
    name: 'Economic Shield',
    status: 'PLANNING',
    priority: 'CRITICAL',
    location: 'Asia Pacific',
    personnel: 8,
    progress: 23,
    eta: '4d 12h',
    classification: 'TOP_SECRET'
  },
  {
    id: 'GAMMA-003',
    name: 'Digital Fortress',
    status: 'COMPLETED',
    priority: 'MEDIUM',
    location: 'North America',
    personnel: 15,
    progress: 100,
    eta: 'Completed',
    classification: 'CONFIDENTIAL'
  }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">ACTIVE</Badge>;
    case 'PLANNING': return <Badge className="bg-yellow-500/20 text-yellow-400">PLANNING</Badge>;
    case 'COMPLETED': return <Badge className="bg-green-500/20 text-green-400">COMPLETED</Badge>;
    case 'SUSPENDED': return <Badge className="bg-red-500/20 text-red-400">SUSPENDED</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getPriorityBadge = (priority) => {
  switch (priority) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    default: return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
  }
};

const getClassificationBadge = (classification) => {
  switch (classification) {
    case 'TOP_SECRET': return <Badge className="bg-red-500/20 text-red-400">TOP SECRET</Badge>;
    case 'SECRET': return <Badge className="bg-orange-500/20 text-orange-400">SECRET</Badge>;
    case 'CONFIDENTIAL': return <Badge className="bg-yellow-500/20 text-yellow-400">CONFIDENTIAL</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNCLASSIFIED</Badge>;
  }
};

export default function MissionsPage() {
  const [selectedMission, setSelectedMission] = useState(null);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Target className="w-10 h-10 mr-3 text-cyan-400" />
            Mission Control
          </h1>
          <p className="orbital-text-subtitle">Active operations coordination, personnel deployment, and mission oversight.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {missionMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Active Operations</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Mission ID</TableHead>
              <TableHead className="text-gray-400">Operation Name</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Priority</TableHead>
              <TableHead className="text-gray-400">Location</TableHead>
              <TableHead className="text-gray-400">Personnel</TableHead>
              <TableHead className="text-gray-400">Progress</TableHead>
              <TableHead className="text-gray-400">ETA</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activeMissions.map((mission) => (
              <TableRow 
                key={mission.id} 
                className="border-gray-800 hover:bg-gray-800/30 cursor-pointer"
                onClick={() => setSelectedMission(mission)}
              >
                <TableCell className="font-mono text-cyan-400">{mission.id}</TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium text-white">{mission.name}</p>
                    <div className="mt-1">{getClassificationBadge(mission.classification)}</div>
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(mission.status)}</TableCell>
                <TableCell>{getPriorityBadge(mission.priority)}</TableCell>
                <TableCell className="text-gray-300">{mission.location}</TableCell>
                <TableCell className="text-gray-300">{mission.personnel}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-cyan-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${mission.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-cyan-400">{mission.progress}%</span>
                  </div>
                </TableCell>
                <TableCell className="text-gray-400">{mission.eta}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}