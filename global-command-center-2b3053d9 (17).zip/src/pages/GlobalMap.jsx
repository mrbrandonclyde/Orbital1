import React, { useState } from 'react';
import { Map, Globe, Satellite, Target, AlertTriangle, Activity } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const mapMetrics = [
  { title: "Global Coverage", value: "100%", icon: Globe, color: "text-blue-400" },
  { title: "Satellite Feeds", value: "1,247", icon: Satellite, color: "text-green-400" },
  { title: "Active Regions", value: "198", icon: Map, color: "text-purple-400" },
  { title: "Threat Markers", value: "47", icon: AlertTriangle, color: "text-red-400" },
  { title: "Asset Tracking", value: "8,945", icon: Target, color: "text-yellow-400" },
  { title: "Live Updates", value: "2.4M/hr", icon: Activity, color: "text-cyan-400" }
];

const regionStatus = [
  { region: 'North America', status: 'STABLE', threats: 3, assets: 247, color: 'text-green-400' },
  { region: 'Europe', status: 'MONITORING', threats: 8, assets: 189, color: 'text-yellow-400' },
  { region: 'Asia Pacific', status: 'HIGH_ALERT', threats: 15, assets: 345, color: 'text-red-400' },
  { region: 'Middle East', status: 'UNSTABLE', threats: 12, assets: 78, color: 'text-orange-400' },
  { region: 'Africa', status: 'MONITORING', threats: 6, assets: 123, color: 'text-yellow-400' },
  { region: 'South America', status: 'STABLE', threats: 4, assets: 156, color: 'text-green-400' }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'STABLE': return <Badge className="bg-green-500/20 text-green-400">STABLE</Badge>;
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400">MONITORING</Badge>;
    case 'HIGH_ALERT': return <Badge className="bg-red-500/20 text-red-400 animate-pulse">HIGH ALERT</Badge>;
    case 'UNSTABLE': return <Badge className="bg-orange-500/20 text-orange-400">UNSTABLE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function GlobalMapPage() {
  const [selectedRegion, setSelectedRegion] = useState(null);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Globe className="w-10 h-10 mr-3 text-blue-400" />
            Global Intelligence Map
          </h1>
          <p className="orbital-text-subtitle">Real-time global monitoring with satellite feeds and threat overlays.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {mapMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Global Threat Overlay</h3>
          <div className="h-96 bg-gradient-to-b from-gray-900 to-black rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Globe className="w-24 h-24 mx-auto text-blue-400 mb-4 animate-pulse" />
              <p className="text-white text-lg font-semibold">Global Map Interface</p>
              <p className="text-gray-400 text-sm">Real-time satellite and intelligence overlay</p>
            </div>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Regional Status</h3>
          <div className="space-y-4">
            {regionStatus.map((region, i) => (
              <div 
                key={i}
                className="p-3 bg-gray-800/30 rounded-lg cursor-pointer hover:bg-gray-800/50 transition-all"
                onClick={() => setSelectedRegion(region)}
              >
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-white">{region.region}</h4>
                  {getStatusBadge(region.status)}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Threats:</span>
                    <span className="text-red-400 font-semibold ml-2">{region.threats}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Assets:</span>
                    <span className="text-green-400 font-semibold ml-2">{region.assets}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}