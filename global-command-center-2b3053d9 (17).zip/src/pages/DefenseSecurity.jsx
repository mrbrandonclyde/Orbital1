import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Shield, Activity, Target } from "lucide-react";

export default function DefenseSecurityPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Shield className="w-10 h-10 mr-3 text-green-400" />
          Defense & Security
        </h1>
        <p className="orbital-text-subtitle">Endurance Ops, Precision Training, Never‑Die Protocol.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('SecurityCenter')} className="glass-pane p-6 hover:border-green-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Activity className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Security Center</h3>
          </div>
          <p className="text-gray-400 text-sm">Threats, incidents, alerts.</p>
        </Link>

        <Link to={createPageUrl('GuardianCorps')} className="glass-pane p-6 hover:border-green-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white font-semibold">Guardian Corps</h3>
          </div>
          <p className="text-gray-400 text-sm">Training ops and readiness.</p>
        </Link>

        <Link to={createPageUrl('PlanetaryDefense')} className="glass-pane p-6 hover:border-green-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">Planetary Defense</h3>
          </div>
          <p className="text-gray-400 text-sm">Orbital defense and response.</p>
        </Link>
      </div>
    </div>
  );
}