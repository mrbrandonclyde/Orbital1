import React, { useState } from 'react';
import { Bell, BellRing, Mail, Shield, TrendingUp, Users, Settings } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";

const notifications = [
  { id: 1, type: 'security_alert', title: 'Security Threat Detected', message: 'Unusual access patterns detected in sector 7', time: '5 min ago', read: false, priority: 'critical' },
  { id: 2, type: 'system_update', title: 'System Maintenance Complete', message: 'All systems have been successfully updated', time: '2 hours ago', read: true, priority: 'low' },
  { id: 3, type: 'transaction_alert', title: 'Large Transaction Detected', message: '$50M transfer requires approval', time: '1 hour ago', read: false, priority: 'high' },
  { id: 4, type: 'feature_update', title: 'New Analytics Module', message: 'Enhanced predictive analytics now available', time: '1 day ago', read: true, priority: 'medium' }
];

const getNotificationIcon = (type) => {
  switch (type) {
    case 'security_alert': return Shield;
    case 'transaction_alert': return TrendingUp;
    case 'system_update': return Settings;
    case 'feature_update': return Bell;
    default: return Mail;
  }
};

const getPriorityColor = (priority) => {
  switch (priority) {
    case 'critical': return 'text-red-400 bg-red-500/10';
    case 'high': return 'text-orange-400 bg-orange-500/10';
    case 'medium': return 'text-yellow-400 bg-yellow-500/10';
    default: return 'text-blue-400 bg-blue-500/10';
  }
};

export default function NotificationCenterPage() {
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [pushEnabled, setPushEnabled] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Bell className="w-10 h-10 mr-3 text-blue-400" />
            Notification Center
            {unreadCount > 0 && (
              <Badge className="ml-3 bg-red-500 text-white">{unreadCount}</Badge>
            )}
          </h1>
          <p className="orbital-text-subtitle">Manage your alerts and system notifications.</p>
        </div>
      </div>

      <div className="glass-pane p-6 mb-8">
        <h3 className="orbital-text-subheading mb-4">Notification Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-semibold">Email Notifications</h4>
              <p className="text-gray-400 text-sm">Receive notifications via email</p>
            </div>
            <Switch checked={emailEnabled} onCheckedChange={setEmailEnabled} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-semibold">Push Notifications</h4>
              <p className="text-gray-400 text-sm">Receive browser push notifications</p>
            </div>
            <Switch checked={pushEnabled} onCheckedChange={setPushEnabled} />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {notifications.map(notification => {
          const Icon = getNotificationIcon(notification.type);
          return (
            <Card key={notification.id} className={`bg-[#0A0D18]/50 border-gray-800 ${!notification.read ? 'border-l-4 border-l-blue-500' : ''}`}>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Icon className="w-6 h-6 text-blue-400 mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-white font-semibold">{notification.title}</h4>
                      <div className="flex items-center space-x-2">
                        <Badge className={getPriorityColor(notification.priority)}>{notification.priority}</Badge>
                        <span className="text-gray-400 text-sm">{notification.time}</span>
                      </div>
                    </div>
                    <p className="text-gray-300">{notification.message}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}