import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ShoppingCart, CreditCard, BadgeDollarSign, FileCog } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function Commerce() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShoppingCart className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">E‑Commerce</h1>
            <p className="orbital-text-subtitle">Products catalog, Checkout builder, Coupons & Taxes.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon title="Integrations and Hooks" subtitle="Ready for product CRUD, checkout webhooks, and gateways">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><FileCog className="w-4 h-4 text-cyan-400" /> Products</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              CRUD /products, categories, pricing, inventory
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><CreditCard className="w-4 h-4 text-purple-400" /> Checkout Builder</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              1-step / 2-step checkout, upsell/downsell, order bumps, taxes
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><BadgeDollarSign className="w-4 h-4 text-amber-400" /> Coupons & Discounts</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              coupon codes, discounts, VAT/tax rules, Stripe/PayPal/Coinbase hooks
            </CardContent>
          </Card>
        </div>
      </ComingSoon>
    </div>
  );
}