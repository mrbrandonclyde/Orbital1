import React, { useState } from 'react';
import { Activity, Server, Cpu, HardDrive, Network, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const systemMetrics = [
  { title: "System Health", value: "98.7%", icon: Activity, color: "text-green-400", status: "OPTIMAL" },
  { title: "Server Load", value: "23%", icon: Server, color: "text-blue-400", status: "NORMAL" },
  { title: "CPU Usage", value: "45%", icon: Cpu, color: "text-yellow-400", status: "NORMAL" },
  { title: "Storage", value: "67%", icon: HardDrive, color: "text-orange-400", status: "NORMAL" },
  { title: "Network", value: "99.9%", icon: Network, color: "text-green-400", status: "OPTIMAL" },
  { title: "Security", value: "SECURE", icon: Shield, color: "text-green-400", status: "PROTECTED" }
];

const systemAlerts = [
  { id: 1, type: "INFO", message: "Routine maintenance completed successfully", time: "2h ago", icon: CheckCircle },
  { id: 2, type: "WARNING", message: "High memory usage detected on Server-07", time: "4h ago", icon: AlertTriangle },
  { id: 3, type: "INFO", message: "Security patches applied to all systems", time: "1d ago", icon: Shield }
];

export default function SystemStatusPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Activity className="w-10 h-10 mr-3 text-green-400" />
            System Status
          </h1>
          <p className="orbital-text-subtitle">Real-time infrastructure monitoring and health dashboard.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {systemMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
              <p className="text-xs text-gray-500 mt-1">{metric.status}</p>
            </div>
          );
        })}
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">System Alerts</h3>
        <div className="space-y-3">
          {systemAlerts.map(alert => {
            const Icon = alert.icon;
            return (
              <div key={alert.id} className="flex items-center space-x-4 p-3 bg-gray-800/30 rounded-lg">
                <Icon className={`w-5 h-5 ${alert.type === 'WARNING' ? 'text-yellow-400' : 'text-green-400'}`} />
                <div className="flex-1">
                  <p className="text-white">{alert.message}</p>
                  <p className="text-gray-400 text-sm">{alert.time}</p>
                </div>
                <Badge className={alert.type === 'WARNING' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}>
                  {alert.type}
                </Badge>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}