
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Target, CheckCircle2, AlertTriangle, Layers, Wand2, BarChart3, Zap, Users, ShoppingCart, Plug, Settings, LayoutDashboard, FileText, MessageSquare } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

function Row({ title, desc, status = "ready", actions = [] }) {
  const statusMap = {
    ready: { label: "Ready", className: "bg-green-500/20 text-green-300" },
    partial: { label: "Partial", className: "bg-yellow-500/20 text-yellow-300" },
    planned: { label: "Planned", className: "bg-gray-600/30 text-gray-300" }
  };
  const s = statusMap[status] || statusMap.planned;
  return (
    <div className="p-4 rounded-xl border border-gray-800 bg-[#0A0D18]/50">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-white font-semibold">{title}</div>
          {desc && <div className="text-xs text-gray-400 mt-1">{desc}</div>}
        </div>
        <Badge className={s.className}>{s.label}</Badge>
      </div>
      {actions?.length ? (
        <div className="mt-3 flex flex-wrap gap-2">
          {actions.map((a) => (
            <Link key={a.label} to={a.href}>
              <Button size="sm" variant={a.variant || "secondary"} className="flex items-center gap-2">
                {a.icon ? <a.icon className="w-4 h-4" /> : null}
                {a.label}
              </Button>
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default function FunnelMasterPlan() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <Target className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Funnel Builder — Master Plan</h1>
            <p className="orbital-text-subtitle">Chronological blueprint with quick links across phases.</p>
          </div>
        </div>
      </div>

      {/* Phase 1 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardHeader>
          <CardTitle className="text-white">Phase 1: Foundation Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Row
            title="Global Sidebar Navigation"
            desc="Persistent, collapsible, role-aware navigation"
            status="ready"
            actions={[
              { label: "Dashboard", href: createPageUrl("FunnelDashboard"), icon: LayoutDashboard },
              { label: "Funnels", href: createPageUrl("Funnels"), icon: Layers },
              { label: "Pages", href: createPageUrl("FunnelPages"), icon: FileText },
              { label: "Automation", href: createPageUrl("FunnelAutomation"), icon: Zap },
              { label: "CRM", href: createPageUrl("CRM"), icon: Users },
              { label: "E‑Commerce", href: createPageUrl("Commerce"), icon: ShoppingCart },
              { label: "Analytics", href: createPageUrl("FunnelAnalytics"), icon: BarChart3 },
              { label: "Integrations", href: createPageUrl("FunnelIntegrations"), icon: Plug },
              { label: "Settings", href: createPageUrl("FunnelSettings"), icon: Settings },
            ]}
          />
        </CardContent>
      </Card>

      {/* Phase 2 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardHeader><CardTitle className="text-white">Phase 2: Funnels Core</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Row
            title="Funnel Dashboard"
            desc="Quick actions, overview, filters, recent activity"
            status="ready"
            actions={[
              { label: "Open Dashboard", href: createPageUrl("FunnelDashboard"), icon: LayoutDashboard },
              { label: "Go to Funnels", href: createPageUrl("Funnels"), icon: Layers },
            ]}
          />
          <Row
            title="Funnel Creation Wizard"
            desc="Type → Goal → Template → Setup → Confirm"
            status="ready"
            actions={[
              { label: "Open Wizard", href: createPageUrl("FunnelWizard"), icon: Wand2, variant: "default" },
              { label: "Browse Templates", href: createPageUrl("FunnelPages"), icon: FileText }
            ]}
          />
        </CardContent>
      </Card>

      {/* Phase 3 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardHeader><CardTitle className="text-white">Phase 3: Funnel Builder (Core UX)</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Row
            title="Drag-and-Drop Funnel Builder"
            desc="Sidebar tools, canvas, top bar, properties panel"
            status="partial"
            actions={[
              { label: "Open Builder", href: createPageUrl("FunnelEditor"), icon: Layers }
            ]}
          />
          <div className="text-xs text-gray-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-400" /> Versioning, save-as-template, and undo/redo are planned in the editor module.
          </div>
        </CardContent>
      </Card>

      {/* Phase 4 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardHeader><CardTitle className="text-white">Phase 4: Enhancements</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Row title="Automation Engine" desc="Email, SMS, webhooks, A/B tests, lead scoring" status="ready" actions={[{ label: "Open Automation", href: createPageUrl("FunnelAutomation"), icon: Zap }]} />
          <Row title="Contacts / CRM" desc="Profiles, segments, pipeline, import/export" status="ready" actions={[{ label: "Open CRM", href: createPageUrl("CRM"), icon: Users }]} />
          <Row title="Checkout Builder" desc="1/2-step checkouts, upsell/downsell, bumps" status="planned" actions={[{ label: "E‑Commerce Module", href: createPageUrl("Commerce"), icon: ShoppingCart }]} />
        </CardContent>
      </Card>

      {/* Phase 5 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardHeader><CardTitle className="text-white">Phase 5: Analytics & Compliance</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Row title="Analytics & Reports" desc="Conversion, drop-off, page performance, revenue, ROI" status="ready" actions={[{ label: "Open Analytics", href: createPageUrl("FunnelAnalytics"), icon: BarChart3 }]} />
          <Row title="Compliance" desc="GDPR, PCI, HIPAA toggles and audit logs" status="partial" actions={[{ label: "Compliance Center", href: createPageUrl("ComplianceCenter"), icon: Settings }]} />
        </CardContent>
      </Card>

      {/* Phase 6 */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white">Phase 6: Future‑Proofing</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Row title="AI Enhancements" desc="Generator, Copywriter, Predictive Analytics" status="ready" actions={[
            { label: "AI Funnel Studio", href: createPageUrl("AIFunnelBuilder"), icon: Wand2 },
            { label: "AI Assets", href: createPageUrl("AIAssets"), icon: FileText }
          ]} />
          <Row title="Advanced Features" desc="VR/AR demos, Voice funnels, Marketplace, White‑label SaaS" status="ready" actions={[
            { label: "VR/AR Demos", href: createPageUrl("FunnelVRAR"), icon: Target },
            { label: "Voice Funnels", href: createPageUrl("VoiceFunnels"), icon: MessageSquare },
            { label: "Marketplace", href: createPageUrl("TemplateMarketplace"), icon: ShoppingCart },
            { label: "White‑label SaaS", href: createPageUrl("WhiteLabelSaaS"), icon: Settings }
          ]} />
        </CardContent>
      </Card>

      <div className="mt-6 text-xs text-gray-500 flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-yellow-400" />
        This Master Plan reflects current app capabilities and links; some modules are placeholders prepared for backend wiring.
      </div>
    </div>
  );
}
