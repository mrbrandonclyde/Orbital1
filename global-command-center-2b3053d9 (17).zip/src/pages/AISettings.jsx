import React, { useEffect, useState } from "react";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Settings, Sparkles } from "lucide-react";

const defaults = {
  tone: "professional",
  verbosity: 60,
  response_speed: "fast",
  detail_level: "detailed",
  modules: {
    proactive_suggestions: true,
    auto_analysis: true,
    threat_monitoring: false
  }
};

export default function AISettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [prefs, setPrefs] = useState(defaults);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const me = await User.me();
        const p = me?.ai_preferences || {};
        if (!active) return;
        setPrefs({
          tone: p.tone ?? defaults.tone,
          verbosity: typeof p.verbosity === "number" ? p.verbosity : defaults.verbosity,
          response_speed: p.response_speed ?? defaults.response_speed,
          detail_level: p.detail_level ?? defaults.detail_level,
          modules: {
            proactive_suggestions: p.modules?.proactive_suggestions ?? defaults.modules.proactive_suggestions,
            auto_analysis: p.modules?.auto_analysis ?? defaults.modules.auto_analysis,
            threat_monitoring: p.modules?.threat_monitoring ?? defaults.modules.threat_monitoring
          }
        });
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  const save = async () => {
    setSaving(true);
    await User.updateMyUserData({ ai_preferences: prefs });
    setSaving(false);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Settings className="w-10 h-10 mr-3 text-cyan-400" />
            AI Settings
          </h1>
          <p className="orbital-text-subtitle">Customize how the AI behaves, and store it forever on the server.</p>
        </div>
        <Button onClick={save} disabled={saving || loading} className="orbital-button-primary">
          {saving ? "Saving..." : "Save Preferences"}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#0A0D18]/50 border border-gray-800">
          <CardHeader><CardTitle className="text-white">Conversation Style</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            <div className="flex items-center justify-between">
              <div className="text-gray-300">Tone</div>
              <Select value={prefs.tone} onValueChange={(v) => setPrefs({ ...prefs, tone: v })}>
                <SelectTrigger className="w-56 bg-gray-800/50 border-gray-600"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="analytical">Analytical</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-gray-300">Verbosity</div>
                <div className="text-gray-400 text-sm">{prefs.verbosity}</div>
              </div>
              <Slider
                value={[prefs.verbosity]}
                onValueChange={(v) => setPrefs({ ...prefs, verbosity: v[0] })}
                min={0}
                max={100}
                className="w-full"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="text-gray-300">Response Speed</div>
              <Select value={prefs.response_speed} onValueChange={(v) => setPrefs({ ...prefs, response_speed: v })}>
                <SelectTrigger className="w-56 bg-gray-800/50 border-gray-600"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="instant">Instant</SelectItem>
                  <SelectItem value="fast">Fast</SelectItem>
                  <SelectItem value="thoughtful">Thoughtful</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-gray-300">Detail Level</div>
              <Select value={prefs.detail_level} onValueChange={(v) => setPrefs({ ...prefs, detail_level: v })}>
                <SelectTrigger className="w-56 bg-gray-800/50 border-gray-600"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="concise">Concise</SelectItem>
                  <SelectItem value="detailed">Detailed</SelectItem>
                  <SelectItem value="comprehensive">Comprehensive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/50 border border-gray-800">
          <CardHeader><CardTitle className="text-white">Active Modules</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            <div className="flex items-center justify-between">
              <div className="text-gray-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Proactive Suggestions
              </div>
              <Switch
                checked={prefs.modules.proactive_suggestions}
                onCheckedChange={(v) => setPrefs({ ...prefs, modules: { ...prefs.modules, proactive_suggestions: v } })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-gray-300">Automated Data Analysis</div>
              <Switch
                checked={prefs.modules.auto_analysis}
                onCheckedChange={(v) => setPrefs({ ...prefs, modules: { ...prefs.modules, auto_analysis: v } })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-gray-300">Real-time Threat Monitoring</div>
              <Switch
                checked={prefs.modules.threat_monitoring}
                onCheckedChange={(v) => setPrefs({ ...prefs, modules: { ...prefs.modules, threat_monitoring: v } })}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {loading && (
        <div className="mt-6 text-sm text-gray-400">Loading your current preferences…</div>
      )}
    </div>
  );
}