import React from "react";
import { SystemConfig } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ClipboardList, Download, RefreshCw, CheckCircle2, AlertTriangle, Link as LinkIcon, Target } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const PHASES = [
  {
    id: "P1",
    title: "Phase 1: Foundation Setup",
    items: [
      { id: "P1_SIDEBAR", title: "Global Sidebar Navigation", desc: "Persistent, collapsible, role-aware navigation", href: createPageUrl("FunnelDashboard") },
      { id: "P1_AUTH", title: "Authentication & Roles", desc: "JWT/OAuth and role-based access", href: createPageUrl("AISettings") },
    ],
  },
  {
    id: "P2",
    title: "Phase 2: Funnels Core",
    items: [
      { id: "P2_DASH", title: "Funnel Dashboard", desc: "Quick actions, filters, recent activity", href: createPageUrl("FunnelDashboard") },
      { id: "P2_WIZ", title: "Funnel Creation Wizard", desc: "Type → Goal → Template → Setup → Confirm", href: createPageUrl("FunnelWizard") },
    ],
  },
  {
    id: "P3",
    title: "Phase 3: Funnel Builder (Core UX)",
    items: [
      { id: "P3_BUILDER", title: "Drag-and-Drop Builder", desc: "Sidebar tools, canvas, top bar, properties", href: createPageUrl("FunnelEditor") },
      { id: "P3_TEMPLATES", title: "Template Library", desc: "Starter, High-Converting, My Saved", href: createPageUrl("FunnelPages") },
    ],
  },
  {
    id: "P4",
    title: "Phase 4: Funnel Enhancements",
    items: [
      { id: "P4_AUTOMATION", title: "Automation Engine", desc: "Sequences, SMS, webhooks, A/B testing", href: createPageUrl("FunnelAutomation") },
      { id: "P4_CRM", title: "CRM Integration", desc: "Contacts, segments, pipeline, notes", href: createPageUrl("CRM") },
      { id: "P4_CHECKOUT", title: "Checkout Builder", desc: "Products, checkout, upsells, coupons", href: createPageUrl("Commerce") },
    ],
  },
  {
    id: "P5",
    title: "Phase 5: Analytics & Compliance",
    items: [
      { id: "P5_ANALYTICS", title: "Analytics Dashboard", desc: "Conversion, drop-offs, revenue", href: createPageUrl("FunnelAnalytics") },
      { id: "P5_COMPLIANCE", title: "Compliance Layer", desc: "GDPR, PCI, HIPAA, data ownership", href: createPageUrl("FunnelSettings") },
    ],
  },
  {
    id: "P6",
    title: "Phase 6: Future-Proofing",
    items: [
      { id: "P6_AI", title: "AI Enhancements", desc: "Generator, Copywriter, Predictive analytics", href: createPageUrl("AIFunnelBuilder") },
      { id: "P6_FUTURE", title: "Future Modules", desc: "VR/AR, Voice, Marketplace, White‑label", href: createPageUrl("FunnelMasterPlan") },
    ],
  },
];

export default function FunnelAudit() {
  const [me, setMe] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [reviewed, setReviewed] = React.useState({}); // {checkId: boolean}

  const CONFIG_KEY = React.useMemo(() => `FUNNEL_AUDIT_${me?.id || "GLOBAL"}`, [me?.id]);

  const allChecks = React.useMemo(
    () => PHASES.flatMap(p => p.items.map(i => i.id)),
    []
  );

  const load = React.useCallback(async () => {
    setLoading(true);
    let current = null;
    try { current = await User.me(); } catch {}
    setMe(current);
    const rows = await SystemConfig.filter({ config_key: `FUNNEL_AUDIT_${current?.id || "GLOBAL"}` }, "-updated_date", 1);
    const cfg = rows?.[0];
    if (cfg) {
      setConfigId(cfg.id);
      setReviewed(cfg.config_value?.reviewed || {});
    } else {
      setConfigId(null);
      const init = {};
      allChecks.forEach(id => { init[id] = false; });
      setReviewed(init);
    }
    setLoading(false);
  }, [allChecks]);

  React.useEffect(() => { load(); }, [load]);

  const setOne = (id, value) => {
    setReviewed(prev => ({ ...prev, [id]: value }));
  };

  const markPhase = (phaseId, value) => {
    const ids = PHASES.find(p => p.id === phaseId)?.items.map(i => i.id) || [];
    setReviewed(prev => {
      const next = { ...prev };
      ids.forEach(id => { next[id] = value; });
      return next;
    });
  };

  const totals = React.useMemo(() => {
    const total = allChecks.length;
    const done = Object.values(reviewed).filter(Boolean).length;
    return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
  }, [allChecks.length, reviewed]);

  const save = async () => {
    setSaving(true);
    const payload = {
      config_key: CONFIG_KEY,
      config_value: {
        reviewed,
        updated_at: new Date().toISOString(),
      },
      description: "Funnel Builder audit checklist per user",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    if (configId) {
      await SystemConfig.update(configId, payload);
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
    }
    setSaving(false);
  };

  const exportMarkdown = () => {
    const lines = [];
    lines.push(`# Funnel Builder Audit Checklist`);
    lines.push(`Updated: ${new Date().toLocaleString()}`);
    lines.push(`Progress: ${totals.done}/${totals.total} (${totals.pct}%)`);
    lines.push("");
    PHASES.forEach(phase => {
      lines.push(`## ${phase.title}`);
      phase.items.forEach(item => {
        lines.push(`- [${reviewed[item.id] ? "x" : " "}] ${item.title} — ${item.desc}`);
      });
      lines.push("");
    });
    const blob = new Blob([lines.join("\n")], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `funnel-audit-${new Date().toISOString().split("T")[0]}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ClipboardList className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Funnel Audit Checklist</h1>
            <p className="orbital-text-subtitle">Review each phase and mark items as verified. Your progress is saved.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-gray-700/50 text-gray-300">{me ? "Per‑user" : "Global"}</Badge>
          <Button variant="secondary" onClick={load} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
          <Button onClick={save} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
            <CheckCircle2 className="w-4 h-4 mr-2" /> {saving ? "Saving..." : "Save"}
          </Button>
          <Button variant="secondary" onClick={exportMarkdown}>
            <Download className="w-4 h-4 mr-2" /> Export
          </Button>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl mb-6">
        <CardContent className="py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="text-white font-semibold">Overall Progress</div>
            <div className="text-gray-300 text-sm">{totals.done} of {totals.total} verified</div>
            <div className="flex-1 h-2 bg-gray-800 rounded-full overflow-hidden min-w-[160px]">
              <div className="h-full bg-cyan-500" style={{ width: `${totals.pct}%` }} />
            </div>
            <Badge className={totals.pct === 100 ? "bg-green-500/20 text-green-300" : "bg-yellow-500/20 text-yellow-300"}>
              {totals.pct}%
            </Badge>
            <Link to={createPageUrl("FunnelMasterPlan")}>
              <Button variant="secondary"><Target className="w-4 h-4 mr-2" /> Master Plan</Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {PHASES.map(phase => {
          const phaseIds = phase.items.map(i => i.id);
          const phaseDone = phaseIds.filter(id => reviewed[id]).length;
          return (
            <Card key={phase.id} className="bg-[#0A0D18]/60 border-gray-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-base flex items-center justify-between">
                  <span>{phase.title}</span>
                  <div className="flex items-center gap-2">
                    <Badge className={phaseDone === phaseIds.length ? "bg-green-500/20 text-green-300" : "bg-yellow-500/20 text-yellow-300"}>
                      {phaseDone}/{phaseIds.length}
                    </Badge>
                    <Button size="sm" variant="secondary" onClick={() => markPhase(phase.id, true)}>Mark all</Button>
                    <Button size="sm" variant="secondary" onClick={() => markPhase(phase.id, false)}>Clear all</Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {phase.items.map(item => (
                  <div key={item.id} className="flex items-start justify-between gap-3 p-3 rounded-lg border border-gray-800">
                    <div>
                      <div className="text-white text-sm font-medium">{item.title}</div>
                      <div className="text-gray-400 text-xs">{item.desc}</div>
                      <a href={item.href} className="text-cyan-400 text-xs inline-flex items-center gap-1 mt-1">
                        <LinkIcon className="w-3 h-3" /> Open
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Label htmlFor={item.id} className="text-xs text-gray-400">Verified</Label>
                      <Switch id={item.id} checked={!!reviewed[item.id]} onCheckedChange={(v) => setOne(item.id, v)} />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-6">
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" /> Reminder
            </CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 text-sm">
            This checklist is for internal verification only. For compliance-grade logs, use the Audit Trail module under System Control.
          </CardContent>
        </Card>
      </div>
    </div>
  );
}