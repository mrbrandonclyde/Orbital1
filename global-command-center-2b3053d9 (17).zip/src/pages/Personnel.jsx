import React, { useState } from 'react';
import { Users, Shield, Crown, Search, Plus, UserCheck, UserX, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

const personnelMetrics = [
  { title: "Active Personnel", value: "847", icon: Users, color: "text-green-400" },
  { title: "Security Cleared", value: "791", icon: Shield, color: "text-blue-400" },
  { title: "Executive Level", value: "23", icon: Crown, color: "text-purple-400" },
  { title: "Pending Reviews", value: "12", icon: AlertTriangle, color: "text-yellow-400" }
];

const personnelData = [
  {
    id: 1,
    name: "Sarah Chen",
    title: "Director of Strategic Operations",
    department: "Command",
    clearance: "EXECUTIVE_COMMAND",
    status: "ACTIVE",
    location: "Washington D.C.",
    lastLogin: "2 min ago",
    avatar: "https://ui-avatars.com/api/?name=Sarah+Chen&background=8B5CF6&color=fff"
  },
  {
    id: 2,
    name: "Marcus Rodriguez",
    title: "Senior Intelligence Analyst",
    department: "Intelligence",
    clearance: "TOP_SECRET",
    status: "ACTIVE",
    location: "Langley, VA",
    lastLogin: "15 min ago",
    avatar: "https://ui-avatars.com/api/?name=Marcus+Rodriguez&background=06B6D4&color=fff"
  },
  {
    id: 3,
    name: "Dr. Yuki Tanaka",
    title: "Cybersecurity Chief",
    department: "Security",
    clearance: "SECRET",
    status: "ACTIVE",
    location: "San Francisco, CA",
    lastLogin: "1 hour ago",
    avatar: "https://ui-avatars.com/api/?name=Yuki+Tanaka&background=10B981&color=fff"
  },
  {
    id: 4,
    name: "Colonel James Mitchell",
    title: "Guardian Corps Commander",
    department: "Operations",
    clearance: "EXECUTIVE_COMMAND",
    status: "ON_MISSION",
    location: "Classified",
    lastLogin: "4 hours ago",
    avatar: "https://ui-avatars.com/api/?name=James+Mitchell&background=F59E0B&color=fff"
  },
  {
    id: 5,
    name: "Elena Volkov",
    title: "Economic Intelligence Specialist",
    department: "Analysis",
    clearance: "SECRET",
    status: "LEAVE",
    location: "New York, NY",
    lastLogin: "2 days ago",
    avatar: "https://ui-avatars.com/api/?name=Elena+Volkov&background=EF4444&color=fff"
  }
];

const getClearanceBadge = (clearance) => {
  switch (clearance) {
    case 'EXECUTIVE_COMMAND': return <Badge className="bg-red-500/20 text-red-400">EXECUTIVE</Badge>;
    case 'TOP_SECRET': return <Badge className="bg-orange-500/20 text-orange-400">TOP SECRET</Badge>;
    case 'SECRET': return <Badge className="bg-yellow-500/20 text-yellow-400">SECRET</Badge>;
    case 'CONFIDENTIAL': return <Badge className="bg-blue-500/20 text-blue-400">CONFIDENTIAL</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNCLASSIFIED</Badge>;
  }
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'ON_MISSION': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">ON MISSION</Badge>;
    case 'LEAVE': return <Badge className="bg-gray-500/20 text-gray-400">ON LEAVE</Badge>;
    case 'SUSPENDED': return <Badge className="bg-red-500/20 text-red-400">SUSPENDED</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function PersonnelPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPerson, setSelectedPerson] = useState(null);

  const filteredPersonnel = personnelData.filter(person => 
    person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Users className="w-10 h-10 mr-3 text-cyan-400" />
            Personnel Management
          </h1>
          <p className="orbital-text-subtitle">Strategic personnel oversight, clearance management, and operational deployment.</p>
        </div>
        <button className="orbital-button-primary flex items-center space-x-2">
          <Plus className="w-5 h-5" />
          <span>Add Personnel</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {personnelMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="glass-pane p-6 mb-6">
        <div className="flex items-center space-x-4 mb-6">
          <Search className="w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search personnel..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-gray-800 border-gray-600"
          />
        </div>

        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Personnel</TableHead>
              <TableHead className="text-gray-400">Department</TableHead>
              <TableHead className="text-gray-400">Clearance</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Location</TableHead>
              <TableHead className="text-gray-400">Last Activity</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPersonnel.map((person) => (
              <TableRow 
                key={person.id} 
                className="border-gray-800 hover:bg-gray-800/30 cursor-pointer"
                onClick={() => setSelectedPerson(person)}
              >
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={person.avatar} />
                      <AvatarFallback>{person.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-white">{person.name}</p>
                      <p className="text-sm text-gray-400">{person.title}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-gray-300">{person.department}</TableCell>
                <TableCell>{getClearanceBadge(person.clearance)}</TableCell>
                <TableCell>{getStatusBadge(person.status)}</TableCell>
                <TableCell className="text-gray-300">{person.location}</TableCell>
                <TableCell className="text-gray-400">{person.lastLogin}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}