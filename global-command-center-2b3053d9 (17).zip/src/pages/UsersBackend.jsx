import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import BackendHealthBadge from "@/components/common/BackendHealthBadge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Users, Plus, RefreshCw } from "lucide-react";

export default function UsersBackend() {
  const [users, setUsers] = React.useState([]);
  const [name, setName] = React.useState("");
  const [balance, setBalance] = React.useState("0");
  const [loading, setLoading] = React.useState(true);
  const [creating, setCreating] = React.useState(false);

  const load = async () => {
    setLoading(true);
    const list = await SpeedBackend.users.list();
    setUsers(list);
    setLoading(false);
  };

  React.useEffect(() => { load(); }, []);

  const createUser = async () => {
    if (!name) return;
    setCreating(true);
    await SpeedBackend.users.create({ name, balance: Number(balance || 0) });
    setName("");
    setBalance("0");
    setCreating(false);
    load();
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-10 h-10 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Users (FastAPI)</h1>
            <p className="orbital-text-subtitle">Backed by SQLAlchemy (SQLite demo)</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <BackendHealthBadge />
          <button onClick={load} className="orbital-button-secondary flex items-center">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white">Create User</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-white" />
            <Input placeholder="Balance" type="number" value={balance} onChange={(e) => setBalance(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-white" />
            <Button onClick={createUser} disabled={creating || !name} className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className={`w-4 h-4 mr-2 ${creating ? 'animate-spin' : ''}`} />
              Create
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Users</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">ID</TableHead>
                    <TableHead className="text-gray-400">Name</TableHead>
                    <TableHead className="text-gray-400">Balance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map(u => (
                    <TableRow key={u.id} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-gray-300">{u.id}</TableCell>
                      <TableCell className="text-white">{u.name}</TableCell>
                      <TableCell className="text-gray-300">{u.balance}</TableCell>
                    </TableRow>
                  ))}
                  {!users.length && (
                    <TableRow className="border-gray-800">
                      <TableCell colSpan={3} className="text-center text-gray-500">No users found.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}