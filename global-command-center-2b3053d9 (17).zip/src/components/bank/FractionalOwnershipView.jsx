import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Users, DollarSign } from 'lucide-react';

export default function FractionalOwnershipView() {
  return (
    <div className="space-y-6">
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            Fractional Ownership
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          Break high-value assets into fractional shares with automated revenue distribution.
          <div className="mt-3 text-xs text-gray-400">Phase 1 Scaffold • Treasury settlement hooks align with Orbital Bank</div>
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            Payouts & Settlement
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          Settlement integrates through Orbital Bank accounts; on-chain execution will be wired in Phase 2+.
        </CardContent>
      </Card>
    </div>
  );
}