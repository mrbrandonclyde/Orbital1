import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Lock, Shield } from 'lucide-react';

export default function NFTVaultView() {
  return (
    <div className="space-y-6">
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lock className="w-5 h-5 text-cyan-400" />
            Orbital NFT Vault
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          Securely store and manage tokenized real-world assets (deeds, vehicles, art).
          <div className="mt-3 text-xs text-gray-400">
            Phase 1 Scaffold • AES-256 at rest • PQC-ready identity • Immutable audit logs
          </div>
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            Security & Compliance
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          Guardian AI shields are active. All custody actions will be logged to AuditTrail and surfaced in RecoveryCenter.
        </CardContent>
      </Card>
    </div>
  );
}