
import React from 'react';
import { 
  Home, CreditCard, ArrowRightLeft, Users, TrendingUp, Settings, 
  Shield, AlertTriangle, FileText, PieChart, Banknote, Building, Lock, Landmark, ShoppingCart
} from 'lucide-react';
import { motion } from 'framer-motion';

const iconMap = {
  dashboard: Home,
  accounts: Users,
  transactions: ArrowRightLeft,
  cards: CreditCard,
  loans: Building,
  investments: TrendingUp,
  analytics: PieChart,
  compliance: Shield,
  alerts: AlertTriangle,
  reports: FileText,
  settings: Settings
};

const bankMenuConfig = {
  items: [
    { label: "Dashboard", icon: "dashboard", route: "dashboard" },
    { label: "Accounts", icon: "accounts", route: "accounts" },
    { label: "Transactions", icon: "transactions", route: "transactions" },
    { label: "Credit & Cards", icon: "cards", route: "cards" },
    { label: "Loans & Mortgages", icon: "loans", route: "loans" },
    { label: "Investments", icon: "investments", route: "investments" },
    { label: "Analytics", icon: "analytics", route: "analytics" },
    { label: "Compliance", icon: "compliance", route: "compliance" },
    { label: "Risk Alerts", icon: "alerts", route: "alerts" },
    { label: "Reports", icon: "reports", route: "reports" },
    { label: "Settings", icon: "settings", route: "settings" }
  ]
};

const SidebarItem = ({ item, activeView, setActiveView, IconOverride }) => {
  // Use IconOverride if provided, otherwise fallback to iconMap
  const Icon = IconOverride || iconMap[item.icon];
  const isActive = activeView === item.route;

  // Render nothing if Icon is not found to prevent errors
  if (!Icon) {
    console.warn(`Icon for item '${item.label}' with key '${item.icon}' not found.`);
    return null; 
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
    >
      <button
        onClick={() => setActiveView(item.route)}
        className={`w-full flex items-center p-3 rounded-lg text-left text-sm font-medium transition-all duration-200 ${
          isActive
            ? 'bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-500/10'
            : 'text-gray-300 hover:bg-gray-800/60 hover:text-white'
        }`}
      >
        <Icon className="w-5 h-5 mr-3 flex-shrink-0" />
        <span className="flex-grow">{item.label}</span>
      </button>
    </motion.div>
  );
};

export default function BankSidebar({ activeView, setActiveView }) {
  const digitalAssets = [
    { label: "NFT Vault", icon: "nft_vault", route: "nft_vault" },
    { label: "Tokenization Engine", icon: "tokenization", route: "tokenization" },
    { label: "Fractional Ownership", icon: "fractional", route: "fractional" },
    { label: "Marketplace", icon: "marketplace", route: "marketplace" },
  ];

  const extraIconMap = {
    nft_vault: Lock,
    tokenization: Landmark,
    fractional: Users, // Reusing Users icon from lucide-react
    marketplace: ShoppingCart
  };

  const ItemRow = ({ item }) => {
    // Prioritize icon from extraIconMap if available, otherwise use iconMap
    const Icon = extraIconMap[item.icon] || iconMap[item.icon];
    return (
      <SidebarItem
        item={item}
        activeView={activeView}
        setActiveView={setActiveView}
        IconOverride={Icon}
      />
    );
  };

  return (
    <aside className="w-64 h-full flex-shrink-0 bg-[#0A0D18]/80 backdrop-blur-md p-4 flex flex-col border-r border-gray-800">
      <div className="flex items-center space-x-2 p-3 mb-6">
        <div className="p-2 bg-emerald-500/20 rounded-lg">
          <Banknote className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white tracking-wider">Orbital Bank</h2>
          <p className="text-xs text-gray-400">Financial Command Center</p>
        </div>
      </div>
      <div className="flex-grow overflow-y-auto">
        <nav className="space-y-2">
          {bankMenuConfig.items.map(item => (
            <ItemRow key={item.label} item={item} />
          ))}

          {/* Digital Assets section */}
          <div className="mt-4 pt-4 border-t border-gray-800">
            <div className="px-2 mb-2 text-[10px] uppercase tracking-wider text-gray-500">Digital Assets</div>
            {digitalAssets.map(item => (
              <ItemRow key={item.label} item={item} />
            ))}
          </div>
        </nav>
      </div>
      <div className="mt-auto pt-4 border-t border-gray-800">
        <div className="text-center text-xs text-gray-500">
          <p>Orbital Banking Platform</p>
          <p>v2.1.0 - Secure</p>
        </div>
      </div>
    </aside>
  );
}
