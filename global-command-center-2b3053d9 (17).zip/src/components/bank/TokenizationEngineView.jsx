import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Landmark, FileText } from 'lucide-react';

export default function TokenizationEngineView() {
  return (
    <div className="space-y-6">
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Landmark className="w-5 h-5 text-purple-400" />
            Tokenization Engine
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          Upload asset documents and mint compliant NFTs tied to real-world assets.
          <div className="mt-3 text-xs text-gray-400">Phase 1 Scaffold • On-chain pipeline to be connected in Phase 2+</div>
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            Documentation & Schemas
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          API bridge contracts will expose OpenAPI schemas and auto-generated docs for integration.
        </CardContent>
      </Card>
    </div>
  );
}