import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Home, Building, Car, TrendingUp, Calendar, DollarSign, Plus } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const mockLoans = [
  {
    id: '1',
    name: 'Corporate Headquarters Mortgage',
    type: 'MORTGAGE',
    originalAmount: 15000000.00,
    currentBalance: 12500000.00,
    monthlyPayment: 85420.00,
    interestRate: 3.75,
    termMonths: 360,
    remainingMonths: 312,
    nextPayment: '2025-01-15',
    status: 'CURRENT',
    lender: 'Orbital Commercial Bank'
  },
  {
    id: '2',
    name: 'Equipment Financing Line',
    type: 'EQUIPMENT',
    originalAmount: 5000000.00,
    currentBalance: 3200000.00,
    monthlyPayment: 42500.00,
    interestRate: 5.25,
    termMonths: 120,
    remainingMonths: 78,
    nextPayment: '2025-01-20',
    status: 'CURRENT',
    lender: 'Industrial Finance Corp'
  },
  {
    id: '3',
    name: 'Research Facility Construction',
    type: 'CONSTRUCTION',
    originalAmount: 25000000.00,
    currentBalance: 18750000.00,
    monthlyPayment: 125000.00,
    interestRate: 4.5,
    termMonths: 240,
    remainingMonths: 156,
    nextPayment: '2025-01-12',
    status: 'CURRENT',
    lender: 'Global Development Bank'
  },
  {
    id: '4',
    name: 'Fleet Vehicle Financing',
    type: 'VEHICLE',
    originalAmount: 2500000.00,
    currentBalance: 875000.00,
    monthlyPayment: 18200.00,
    interestRate: 6.75,
    termMonths: 72,
    remainingMonths: 24,
    nextPayment: '2025-01-18',
    status: 'CURRENT',
    lender: 'Corporate Auto Finance'
  }
];

const paymentHistory = [
  { id: '1', loanName: 'Corporate Headquarters Mortgage', amount: 85420, date: '2024-12-15', status: 'PAID' },
  { id: '2', loanName: 'Equipment Financing Line', amount: 42500, date: '2024-12-20', status: 'PAID' },
  { id: '3', loanName: 'Research Facility Construction', amount: 125000, date: '2024-12-12', status: 'PAID' },
  { id: '4', loanName: 'Fleet Vehicle Financing', amount: 18200, date: '2024-12-18', status: 'PAID' },
];

const LoanCard = ({ loan, onPayment, onViewDetails }) => {
  const paidPercentage = ((loan.originalAmount - loan.currentBalance) / loan.originalAmount) * 100;
  
  const getLoanIcon = (type) => {
    switch (type) {
      case 'MORTGAGE': return <Home className="w-6 h-6" />;
      case 'EQUIPMENT': return <Building className="w-6 h-6" />;
      case 'CONSTRUCTION': return <Building className="w-6 h-6" />;
      case 'VEHICLE': return <Car className="w-6 h-6" />;
      default: return <DollarSign className="w-6 h-6" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'MORTGAGE': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'EQUIPMENT': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'CONSTRUCTION': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
      case 'VEHICLE': return 'bg-green-500/10 text-green-400 border-green-500/20';
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'CURRENT': return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'LATE': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      case 'DELINQUENT': return 'bg-red-500/10 text-red-400 border-red-500/20';
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <Card className="glass-pane hover:border-emerald-500/50 transition-all">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gray-800/50 rounded-lg text-emerald-400">
              {getLoanIcon(loan.type)}
            </div>
            <div>
              <CardTitle className="text-white text-lg">{loan.name}</CardTitle>
              <div className="flex items-center space-x-2 mt-1">
                <Badge className={getTypeColor(loan.type)}>{loan.type}</Badge>
                <Badge className={getStatusColor(loan.status)}>{loan.status}</Badge>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Loan Progress */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-400 text-sm">Loan Progress</span>
            <span className="text-white text-sm">{paidPercentage.toFixed(1)}% paid</span>
          </div>
          <Progress value={paidPercentage} className="w-full h-2" />
        </div>

        {/* Loan Details Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-gray-400 text-sm">Current Balance</p>
            <p className="text-white font-semibold">${loan.currentBalance.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Monthly Payment</p>
            <p className="text-emerald-400 font-semibold">${loan.monthlyPayment.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Interest Rate</p>
            <p className="text-white font-semibold">{loan.interestRate}%</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Remaining Term</p>
            <p className="text-white font-semibold">{Math.floor(loan.remainingMonths / 12)}y {loan.remainingMonths % 12}m</p>
          </div>
        </div>

        {/* Next Payment */}
        <div className="bg-gray-800/30 p-3 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-gray-400 text-sm">Next Payment Due</p>
              <p className="text-white font-semibold">{loan.nextPayment}</p>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm">Amount</p>
              <p className="text-emerald-400 font-bold">${loan.monthlyPayment.toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2 pt-2">
          <Button
            onClick={() => onViewDetails(loan)}
            variant="outline"
            className="flex-1 text-emerald-400 border-emerald-500/50 hover:bg-emerald-500/10"
          >
            View Details
          </Button>
          <Button
            onClick={() => onPayment(loan)}
            className="flex-1 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600"
          >
            <DollarSign className="w-4 h-4 mr-2" />
            Make Payment
          </Button>
        </div>

        {/* Lender Info */}
        <div className="text-center pt-2 border-t border-gray-800">
          <p className="text-gray-500 text-xs">Lender: {loan.lender}</p>
        </div>
      </CardContent>
    </Card>
  );
};

const PaymentDialog = ({ isOpen, onClose, loan }) => {
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentType, setPaymentType] = useState('regular');

  const handlePayment = () => {
    console.log('Loan payment initiated:', { loan: loan?.id, amount: paymentAmount, type: paymentType });
    // Here you would call the actual payment API
    onClose();
  };

  if (!loan) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-emerald-400">Make Loan Payment</DialogTitle>
          <p className="text-gray-400 text-sm">{loan.name}</p>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-gray-800/30 p-4 rounded-lg">
            <div className="flex justify-between">
              <span className="text-gray-400">Current Balance:</span>
              <span className="text-white font-semibold">${loan.currentBalance.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Regular Payment:</span>
              <span className="text-emerald-400 font-semibold">${loan.monthlyPayment.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Next Due Date:</span>
              <span className="text-white font-semibold">{loan.nextPayment}</span>
            </div>
          </div>
          
          <div>
            <Label>Payment Type</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <Button
                onClick={() => {
                  setPaymentType('regular');
                  setPaymentAmount(loan.monthlyPayment.toString());
                }}
                variant={paymentType === 'regular' ? 'default' : 'outline'}
                className="text-sm"
              >
                Regular Payment
              </Button>
              <Button
                onClick={() => {
                  setPaymentType('extra');
                  setPaymentAmount('');
                }}
                variant={paymentType === 'extra' ? 'default' : 'outline'}
                className="text-sm"
              >
                Extra Payment
              </Button>
            </div>
          </div>

          <div>
            <Label>Payment Amount</Label>
            <Input
              type="number"
              placeholder="0.00"
              value={paymentAmount}
              onChange={(e) => setPaymentAmount(e.target.value)}
              className="bg-[#0C0F19] border-gray-600"
            />
            {paymentType === 'extra' && (
              <p className="text-xs text-gray-400 mt-1">Extra payments will be applied to principal</p>
            )}
          </div>

          <div className="flex space-x-2 pt-4">
            <Button onClick={onClose} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button onClick={handlePayment} className="flex-1 bg-gradient-to-r from-emerald-500 to-cyan-500">
              Submit Payment
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const getStatusBadge = (status) => {
  switch (status) {
    case "PAID": return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    case "PENDING": return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">{status}</Badge>;
    case "FAILED": return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">{status}</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
  }
};

export default function LoansView() {
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState(null);

  const handlePayment = (loan) => {
    setSelectedLoan(loan);
    setShowPaymentDialog(true);
  };

  const handleViewDetails = (loan) => {
    console.log('View details for loan:', loan.id);
    // Navigate to loan details or open modal
  };

  const totalBalance = mockLoans.reduce((sum, loan) => sum + loan.currentBalance, 0);
  const totalMonthlyPayments = mockLoans.reduce((sum, loan) => sum + loan.monthlyPayment, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Loans & Mortgages</h1>
          <p className="text-gray-400 mt-1">Manage loan portfolios and payment schedules.</p>
        </div>
        <Button className="orbital-button-primary">
          <Plus className="w-4 h-4 mr-2" />
          Apply for Loan
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="glass-pane border-red-500/30">
          <CardContent className="p-6 text-center">
            <p className="text-gray-400 text-sm">Total Outstanding Balance</p>
            <p className="text-3xl font-bold text-red-400 mt-2">${totalBalance.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-pane border-yellow-500/30">
          <CardContent className="p-6 text-center">
            <p className="text-gray-400 text-sm">Total Monthly Payments</p>
            <p className="text-3xl font-bold text-yellow-400 mt-2">${totalMonthlyPayments.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Loans Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockLoans.map(loan => (
          <LoanCard
            key={loan.id}
            loan={loan}
            onPayment={handlePayment}
            onViewDetails={handleViewDetails}
          />
        ))}
      </div>

      {/* Payment History */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-emerald-400" />
            Recent Loan Payments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-transparent">
                <TableHead className="text-gray-400">Date</TableHead>
                <TableHead className="text-gray-400">Loan</TableHead>
                <TableHead className="text-gray-400 text-right">Amount</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paymentHistory.map((payment) => (
                <TableRow key={payment.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="text-gray-400">{payment.date}</TableCell>
                  <TableCell className="text-white font-medium">{payment.loanName}</TableCell>
                  <TableCell className="text-emerald-400 font-semibold text-right">
                    ${payment.amount.toLocaleString()}
                  </TableCell>
                  <TableCell>{getStatusBadge(payment.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <PaymentDialog
        isOpen={showPaymentDialog}
        onClose={() => setShowPaymentDialog(false)}
        loan={selectedLoan}
      />
    </div>
  );
}