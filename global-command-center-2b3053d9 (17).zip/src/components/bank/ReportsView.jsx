import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, BarChart2, FileText, TrendingUp, Filter, PieChart as PieChartIcon } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

// Sample data for visualizations
const monthlySpendingData = [
  { name: 'Operations', value: 2500000, fill: '#8B5CF6' },
  { name: 'Personnel', value: 1800000, fill: '#06B6D4' },
  { name: 'Infrastructure', value: 1200000, fill: '#10B981' },
  { name: 'R&D', value: 800000, fill: '#F59E0B' },
  { name: 'Emergency Fund', value: 500000, fill: '#EF4444' }
];

const transactionTrendsData = [
  { month: 'Jan', income: 4200000, expenses: 3100000, net: 1100000 },
  { month: 'Feb', income: 3800000, expenses: 2900000, net: 900000 },
  { month: 'Mar', income: 5100000, expenses: 3400000, net: 1700000 },
  { month: 'Apr', income: 4600000, expenses: 3200000, net: 1400000 },
  { month: 'May', income: 5300000, expenses: 3600000, net: 1700000 },
  { month: 'Jun', income: 4900000, expenses: 3300000, net: 1600000 }
];

const reportsData = [
  {
    title: "Quarterly Transaction Report",
    description: "A comprehensive summary of all transactions for Q3 2025.",
    icon: FileText,
    action: "Download PDF",
    date: "Generated: 2025-10-01"
  },
  {
    title: "Monthly Account Statement - Sept 2025",
    description: "Official statement of account activity and balances for September.",
    icon: FileText,
    action: "Download PDF",
    date: "Generated: 2025-10-01"
  },
  {
    title: "Investment Portfolio Performance",
    description: "In-depth analysis of investment growth, ROI, and asset allocation.",
    icon: TrendingUp,
    action: "View Performance",
    date: "Updated: 2025-10-03"
  },
  {
    title: "Annual Financial Summary - 2024",
    description: "Year-end summary of financial activity, profits, and losses.",
    icon: BarChart2,
    action: "Download PDF",
    date: "Generated: 2025-01-15"
  }
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {`${entry.name}: $${(entry.value / 1000000).toFixed(1)}M`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const generatePDFReport = (reportType, data) => {
  // Simulate PDF generation
  console.log(`Generating PDF for ${reportType}`, data);
  // In production, you would use libraries like jsPDF or pdfmake
  alert(`${reportType} report generated! Check your downloads folder.`);
};

const exportDataToCSV = (data, filename) => {
  const csvContent = [
    ["Month", "Income", "Expenses", "Net"],
    ...data.map(item => [
      item.month,
      item.income,
      item.expenses,
      item.net
    ])
  ].map(row => row.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

export default function ReportsView({ data }) {
  const [selectedReport, setSelectedReport] = useState('overview');
  const { transactions = [] } = data || {};

  const handleGenerateReport = (reportType) => {
    switch (reportType) {
      case 'transaction_summary':
        generatePDFReport('Transaction Summary', transactions);
        break;
      case 'financial_statement':
        generatePDFReport('Financial Statement', transactionTrendsData);
        break;
      case 'spending_analysis':
        generatePDFReport('Spending Analysis', monthlySpendingData);
        break;
      default:
        generatePDFReport('General Report', null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Financial Reports & Analytics</h1>
          <p className="text-gray-400 mt-1">Generate reports and visualize financial performance data.</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedReport} onValueChange={setSelectedReport}>
            <SelectTrigger className="w-[180px] bg-[#0A0D18] border-gray-700">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Select report type..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="overview">Financial Overview</SelectItem>
              <SelectItem value="spending">Spending Analysis</SelectItem>
              <SelectItem value="trends">Transaction Trends</SelectItem>
              <SelectItem value="performance">Performance Report</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            onClick={() => handleGenerateReport('transaction_summary')}
            className="orbital-button-primary"
          >
            Generate New Report
          </Button>
        </div>
      </div>

      {/* Data Visualization Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <PieChartIcon className="w-5 h-5 mr-2 text-purple-400" />
                Monthly Spending Breakdown
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => exportDataToCSV(monthlySpendingData.map(item => ({
                  month: item.name,
                  income: 0,
                  expenses: item.value,
                  net: -item.value
                })), 'spending-breakdown.csv')}
              >
                <Download className="w-3 h-3 mr-1" />
                CSV
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={monthlySpendingData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={40}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {monthlySpendingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                Financial Trends (6 Months)
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => exportDataToCSV(transactionTrendsData, 'financial-trends.csv')}
              >
                <Download className="w-3 h-3 mr-1" />
                CSV
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={transactionTrendsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line type="monotone" dataKey="income" name="Income" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="expenses" name="Expenses" stroke="#EF4444" strokeWidth={2} />
                <Line type="monotone" dataKey="net" name="Net Profit" stroke="#06B6D4" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Report Generation Section */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Quick Report Generation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => handleGenerateReport('transaction_summary')}
              className="orbital-button-secondary h-auto p-4 flex flex-col"
            >
              <FileText className="w-6 h-6 mb-2 text-emerald-400" />
              <span className="font-medium">Transaction Summary</span>
              <span className="text-xs text-gray-400 mt-1">Last 30 days</span>
            </Button>
            <Button
              onClick={() => handleGenerateReport('financial_statement')}
              className="orbital-button-secondary h-auto p-4 flex flex-col"
            >
              <BarChart2 className="w-6 h-6 mb-2 text-cyan-400" />
              <span className="font-medium">Financial Statement</span>
              <span className="text-xs text-gray-400 mt-1">Current quarter</span>
            </Button>
            <Button
              onClick={() => handleGenerateReport('spending_analysis')}
              className="orbital-button-secondary h-auto p-4 flex flex-col"
            >
              <TrendingUp className="w-6 h-6 mb-2 text-purple-400" />
              <span className="font-medium">Spending Analysis</span>
              <span className="text-xs text-gray-400 mt-1">Monthly breakdown</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Downloads Section */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Available Reports</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reportsData.map((report, index) => {
            const Icon = report.icon;
            return (
              <Card key={index} className="glass-pane hover:border-emerald-500/50 transition-all">
                <CardHeader className="flex flex-row items-start justify-between space-y-0">
                  <div className="space-y-1.5">
                    <CardTitle className="text-white">{report.title}</CardTitle>
                    <p className="text-sm text-gray-400">{report.description}</p>
                  </div>
                  <div className="p-2 bg-gray-800/50 rounded-lg">
                    <Icon className="w-6 h-6 text-emerald-400" />
                  </div>
                </CardHeader>
                <CardContent className="flex justify-between items-center">
                  <p className="text-xs text-gray-500">{report.date}</p>
                  <Button 
                    variant="outline" 
                    className="text-emerald-400 border-emerald-500/50 hover:bg-emerald-500/10 hover:text-emerald-300"
                    onClick={() => handleGenerateReport('custom')}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    {report.action}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}