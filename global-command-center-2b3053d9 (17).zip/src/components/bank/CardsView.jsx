import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, Eye, EyeOff, Lock, Unlock, Plus, Calendar, DollarSign } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const mockCreditCards = [
  {
    id: '1',
    name: 'Orbital Business Platinum',
    type: 'BUSINESS',
    cardNumber: '**** **** **** 4521',
    balance: 85420.00,
    creditLimit: 500000.00,
    availableCredit: 414580.00,
    minimumPayment: 2500.00,
    paymentDue: '2025-01-15',
    status: 'ACTIVE',
    lastPayment: '2024-12-15',
    interestRate: 18.99
  },
  {
    id: '2',
    name: 'Corporate Travel Card',
    type: 'TRAVEL',
    cardNumber: '**** **** **** 8734',
    balance: 12450.00,
    creditLimit: 100000.00,
    availableCredit: 87550.00,
    minimumPayment: 450.00,
    paymentDue: '2025-01-20',
    status: 'ACTIVE',
    lastPayment: '2024-12-20',
    interestRate: 16.99
  },
  {
    id: '3',
    name: 'Emergency Credit Line',
    type: 'EMERGENCY',
    cardNumber: '**** **** **** 1892',
    balance: 0.00,
    creditLimit: 1000000.00,
    availableCredit: 1000000.00,
    minimumPayment: 0.00,
    paymentDue: null,
    status: 'LOCKED',
    lastPayment: null,
    interestRate: 12.99
  }
];

const recentTransactions = [
  { id: '1', card: 'Orbital Business Platinum', merchant: 'Global Tech Solutions', amount: 25000, date: '2025-01-02', category: 'Technology' },
  { id: '2', card: 'Corporate Travel Card', merchant: 'Aerospace Hotels', amount: 1250, date: '2025-01-01', category: 'Travel' },
  { id: '3', card: 'Orbital Business Platinum', merchant: 'Office Depot Corp', amount: 3200, date: '2024-12-31', category: 'Office Supplies' },
  { id: '4', card: 'Corporate Travel Card', merchant: 'Fleet Airlines', amount: 8500, date: '2024-12-30', category: 'Travel' }
];

const CreditCardDisplay = ({ card, onPayment, onToggleLock }) => {
  const [showDetails, setShowDetails] = useState(false);
  const utilizationPercentage = (card.balance / card.creditLimit) * 100;
  
  const getCardColor = (type) => {
    switch (type) {
      case 'BUSINESS': return 'bg-gradient-to-r from-purple-600 to-blue-600';
      case 'TRAVEL': return 'bg-gradient-to-r from-emerald-600 to-cyan-600';
      case 'EMERGENCY': return 'bg-gradient-to-r from-red-600 to-orange-600';
      default: return 'bg-gradient-to-r from-gray-600 to-gray-700';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'LOCKED': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'SUSPENDED': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <div className="space-y-4">
      {/* Credit Card Visual */}
      <div className={`relative p-6 rounded-2xl ${getCardColor(card.type)} text-white min-h-48`}>
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm opacity-80">Credit Card</p>
            <h3 className="text-xl font-bold mt-1">{card.name}</h3>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="p-1 hover:bg-white/20 rounded transition-colors"
            >
              {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
            <Badge className={getStatusColor(card.status)}>{card.status}</Badge>
          </div>
        </div>
        
        <div className="mt-8">
          <p className="text-sm opacity-80">Card Number</p>
          <p className="text-lg font-mono tracking-wider">
            {showDetails ? card.cardNumber : '**** **** **** ****'}
          </p>
        </div>
        
        <div className="flex justify-between items-end mt-6">
          <div>
            <p className="text-sm opacity-80">Current Balance</p>
            <p className="text-xl font-bold">${card.balance.toLocaleString()}</p>
          </div>
          <div className="text-right">
            <p className="text-sm opacity-80">Available Credit</p>
            <p className="text-lg font-semibold">${card.availableCredit.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Card Details */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            Account Details
            <div className="flex space-x-2">
              {card.status === 'ACTIVE' && (
                <Button
                  onClick={() => onPayment(card)}
                  size="sm"
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Make Payment
                </Button>
              )}
              <Button
                onClick={() => onToggleLock(card)}
                size="sm"
                variant="outline"
                className={card.status === 'LOCKED' ? 'border-red-500/50 text-red-400' : 'border-yellow-500/50 text-yellow-400'}
              >
                {card.status === 'LOCKED' ? (
                  <>
                    <Unlock className="w-4 h-4 mr-2" />
                    Unlock
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 mr-2" />
                    Lock
                  </>
                )}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-400 text-sm">Credit Limit</p>
              <p className="text-white font-semibold">${card.creditLimit.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Interest Rate</p>
              <p className="text-white font-semibold">{card.interestRate}% APR</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Minimum Payment</p>
              <p className="text-white font-semibold">${card.minimumPayment.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Payment Due</p>
              <p className="text-white font-semibold">{card.paymentDue || 'N/A'}</p>
            </div>
          </div>
          
          {/* Credit Utilization */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400 text-sm">Credit Utilization</span>
              <span className="text-white text-sm">{utilizationPercentage.toFixed(1)}%</span>
            </div>
            <Progress 
              value={utilizationPercentage} 
              className="w-full h-2"
              style={{
                background: utilizationPercentage > 80 ? '#EF4444' : utilizationPercentage > 60 ? '#F59E0B' : '#10B981'
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const PaymentDialog = ({ isOpen, onClose, card }) => {
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentType, setPaymentType] = useState('minimum');

  const handlePayment = () => {
    console.log('Payment initiated:', { card: card?.id, amount: paymentAmount, type: paymentType });
    // Here you would call the actual payment API
    onClose();
  };

  if (!card) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-emerald-400">Make Payment - {card.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-gray-800/30 p-4 rounded-lg">
            <div className="flex justify-between">
              <span className="text-gray-400">Current Balance:</span>
              <span className="text-white font-semibold">${card.balance.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Minimum Payment:</span>
              <span className="text-emerald-400 font-semibold">${card.minimumPayment.toLocaleString()}</span>
            </div>
          </div>
          
          <div>
            <Label>Payment Type</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <Button
                onClick={() => {
                  setPaymentType('minimum');
                  setPaymentAmount(card.minimumPayment.toString());
                }}
                variant={paymentType === 'minimum' ? 'default' : 'outline'}
                className="text-sm"
              >
                Minimum Payment
              </Button>
              <Button
                onClick={() => {
                  setPaymentType('full');
                  setPaymentAmount(card.balance.toString());
                }}
                variant={paymentType === 'full' ? 'default' : 'outline'}
                className="text-sm"
              >
                Pay in Full
              </Button>
            </div>
          </div>

          <div>
            <Label>Payment Amount</Label>
            <Input
              type="number"
              placeholder="0.00"
              value={paymentAmount}
              onChange={(e) => setPaymentAmount(e.target.value)}
              className="bg-[#0C0F19] border-gray-600"
            />
          </div>

          <div className="flex space-x-2 pt-4">
            <Button onClick={onClose} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button onClick={handlePayment} className="flex-1 bg-gradient-to-r from-emerald-500 to-cyan-500">
              Submit Payment
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default function CardsView() {
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);

  const handlePayment = (card) => {
    setSelectedCard(card);
    setShowPaymentDialog(true);
  };

  const handleToggleLock = (card) => {
    console.log(`Toggle lock for card: ${card.id}`);
    // Here you would call the API to lock/unlock the card
  };

  const totalBalance = mockCreditCards.reduce((sum, card) => sum + card.balance, 0);
  const totalAvailableCredit = mockCreditCards.reduce((sum, card) => sum + card.availableCredit, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Credit & Cards</h1>
          <p className="text-gray-400 mt-1">Manage corporate credit cards and payment schedules.</p>
        </div>
        <Button className="orbital-button-primary">
          <Plus className="w-4 h-4 mr-2" />
          Request New Card
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="glass-pane border-red-500/30">
          <CardContent className="p-6 text-center">
            <p className="text-gray-400 text-sm">Total Outstanding Balance</p>
            <p className="text-3xl font-bold text-red-400 mt-2">${totalBalance.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-pane border-emerald-500/30">
          <CardContent className="p-6 text-center">
            <p className="text-gray-400 text-sm">Available Credit</p>
            <p className="text-3xl font-bold text-emerald-400 mt-2">${totalAvailableCredit.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Credit Cards */}
      <div className="space-y-8">
        {mockCreditCards.map(card => (
          <CreditCardDisplay
            key={card.id}
            card={card}
            onPayment={handlePayment}
            onToggleLock={handleToggleLock}
          />
        ))}
      </div>

      {/* Recent Transactions */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Recent Credit Card Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-transparent">
                <TableHead className="text-gray-400">Date</TableHead>
                <TableHead className="text-gray-400">Card</TableHead>
                <TableHead className="text-gray-400">Merchant</TableHead>
                <TableHead className="text-gray-400">Category</TableHead>
                <TableHead className="text-gray-400 text-right">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentTransactions.map((transaction) => (
                <TableRow key={transaction.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="text-gray-400">{transaction.date}</TableCell>
                  <TableCell className="text-white font-medium">{transaction.card}</TableCell>
                  <TableCell className="text-gray-300">{transaction.merchant}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-gray-300 border-gray-600">
                      {transaction.category}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-red-400 font-semibold text-right">
                    -${transaction.amount.toLocaleString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <PaymentDialog
        isOpen={showPaymentDialog}
        onClose={() => setShowPaymentDialog(false)}
        card={selectedCard}
      />
    </div>
  );
}