import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight, Filter, Download, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from 'date-fns';

const getStatusBadge = (status) => {
  switch (status) {
    case "Completed": return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    case "Pending": return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 animate-pulse">{status}</Badge>;
    case "Failed": return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">{status}</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
  }
};

const exportToCSV = (transactions) => {
  const csvContent = [
    ["Date", "Description", "Type", "Category", "Amount", "Status"],
    ...transactions.map(txn => [
      format(new Date(txn.date), 'yyyy-MM-dd'),
      txn.description,
      txn.type,
      txn.category,
      txn.amount,
      txn.status
    ])
  ].map(row => row.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `orbital-bank-transactions-${format(new Date(), 'yyyy-MM-dd')}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

export default function TransactionsView({ data }) {
  const { transactions: allTransactions = [] } = data || {};
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [dateRange, setDateRange] = useState('all');
  const transactionsPerPage = 8;

  // Filter and search transactions
  const filteredTransactions = useMemo(() => {
    return allTransactions.filter(txn => {
      const matchesFilter = filter === 'all' || 
        (filter === 'debit' && txn.amount < 0) ||
        (filter === 'credit' && txn.amount > 0) ||
        (filter === 'pending' && txn.status === 'Pending');
      
      const matchesSearch = !searchTerm || 
        txn.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        txn.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        txn.type.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = categoryFilter === 'all' || txn.category === categoryFilter;
      
      // Date range filtering
      const txnDate = new Date(txn.date);
      const now = new Date();
      let matchesDate = true;
      
      if (dateRange === '7days') {
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        matchesDate = txnDate >= sevenDaysAgo;
      } else if (dateRange === '30days') {
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        matchesDate = txnDate >= thirtyDaysAgo;
      } else if (dateRange === '90days') {
        const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        matchesDate = txnDate >= ninetyDaysAgo;
      }
      
      return matchesFilter && matchesSearch && matchesCategory && matchesDate;
    });
  }, [filter, searchTerm, categoryFilter, dateRange, allTransactions]);

  // Pagination logic
  const totalPages = Math.ceil(filteredTransactions.length / transactionsPerPage);
  const startIndex = (currentPage - 1) * transactionsPerPage;
  const endIndex = startIndex + transactionsPerPage;
  const currentTransactions = filteredTransactions.slice(startIndex, endIndex);

  // Get unique categories for filter
  const categories = [...new Set(allTransactions.map(txn => txn.category))];

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filter, searchTerm, categoryFilter, dateRange, allTransactions]);

  // Calculate summary statistics
  const totalIncome = filteredTransactions.filter(txn => txn.amount > 0).reduce((sum, txn) => sum + txn.amount, 0);
  const totalExpenses = filteredTransactions.filter(txn => txn.amount < 0).reduce((sum, txn) => sum + Math.abs(txn.amount), 0);
  const netFlow = totalIncome - totalExpenses;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Transaction History</h1>
          <p className="text-gray-400 mt-1">Review and manage all financial transactions with advanced filtering.</p>
        </div>
        <Button 
          onClick={() => exportToCSV(filteredTransactions)}
          className="orbital-button-secondary"
        >
          <Download className="w-4 h-4 mr-2" /> 
          Export CSV
        </Button>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-pane border-green-500/30">
          <CardContent className="p-4 text-center">
            <p className="text-gray-400 text-sm">Total Income</p>
            <p className="text-2xl font-bold text-green-400">${totalIncome.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-pane border-red-500/30">
          <CardContent className="p-4 text-center">
            <p className="text-gray-400 text-sm">Total Expenses</p>
            <p className="text-2xl font-bold text-red-400">${totalExpenses.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-pane border-cyan-500/30">
          <CardContent className="p-4 text-center">
            <p className="text-gray-400 text-sm">Net Flow</p>
            <p className={`text-2xl font-bold ${netFlow >= 0 ? 'text-cyan-400' : 'text-orange-400'}`}>
              ${netFlow.toLocaleString()}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Filters */}
      <Card className="glass-pane">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            {/* Search */}
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#0C0F19] border-gray-600"
                data-testid="transaction-search"
              />
            </div>

            {/* Filter by Type */}
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="debit">Debit</SelectItem>
                <SelectItem value="credit">Credit</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>

            {/* Filter by Category */}
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Filter by Date Range */}
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Transaction Results Summary */}
      <div className="flex justify-between items-center text-sm text-gray-400">
        <span>Showing {startIndex + 1}-{Math.min(endIndex, filteredTransactions.length)} of {filteredTransactions.length} transactions</span>
        <span>Page {currentPage} of {totalPages}</span>
      </div>

      {/* Transactions Table */}
      <Card className="glass-pane">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-800 hover:bg-transparent">
                <TableHead className="text-white">Date</TableHead>
                <TableHead className="text-white">Description</TableHead>
                <TableHead className="text-white">Type</TableHead>
                <TableHead className="text-white">Category</TableHead>
                <TableHead className="text-white text-right">Amount</TableHead>
                <TableHead className="text-white text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentTransactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-400">
                    No transactions found matching your criteria
                  </TableCell>
                </TableRow>
              ) : (
                currentTransactions.map((txn) => (
                  <TableRow key={txn.id} className="border-gray-800 hover:bg-gray-800/30" data-testid="transaction-row">
                    <TableCell className="text-gray-300 font-mono text-sm">{format(new Date(txn.date), 'yyyy-MM-dd')}</TableCell>
                    <TableCell className="font-medium text-white">{txn.description}</TableCell>
                    <TableCell className="text-gray-400">{txn.type}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-gray-300 border-gray-600">
                        {txn.category}
                      </Badge>
                    </TableCell>
                    <TableCell className={`font-semibold text-right ${txn.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      <div className="flex items-center justify-end">
                        {txn.amount > 0 ? <ArrowDownRight className="w-4 h-4 mr-2"/> : <ArrowUpRight className="w-4 h-4 mr-2"/>}
                        ${Math.abs(txn.amount).toLocaleString()}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">{getStatusBadge(txn.status)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="flex items-center space-x-2"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </Button>

          <div className="flex items-center space-x-2">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (currentPage <= 3) {
                pageNum = i + 1;
              } else if (currentPage > totalPages - 3) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = currentPage - 2 + i;
              }

              return (
                <Button
                  key={pageNum}
                  variant={pageNum === currentPage ? "default" : "outline"}
                  onClick={() => handlePageChange(pageNum)}
                  className={`w-10 h-10 p-0 ${
                    pageNum === currentPage 
                      ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white' 
                      : 'text-gray-300'
                  }`}
                >
                  {pageNum}
                </Button>
              );
            })}
          </div>

          <Button
            variant="outline"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="flex items-center space-x-2"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}