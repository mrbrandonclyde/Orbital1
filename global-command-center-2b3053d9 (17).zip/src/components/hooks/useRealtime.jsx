import React from 'react';

/**
 * Lightweight realtime connection indicator hook.
 * Simulates a connection heartbeat and exposes { isConnected }.
 * Replace internals with your realtime service when available.
 */
export function useRealtimeConnection() {
  const [isConnected, setIsConnected] = React.useState(true);

  React.useEffect(() => {
    let mounted = true;

    // Simulated heartbeat: briefly toggle offline then back online
    const interval = setInterval(() => {
      if (!mounted) return;
      // Random blip to mimic network variance
      const shouldBlink = Math.random() < 0.05;
      if (shouldBlink) {
        setIsConnected(false);
        setTimeout(() => mounted && setIsConnected(true), 800);
      }
    }, 5000);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return { isConnected };
}