import React, { useState, useEffect } from 'react';
import { Dna, Shield, Database, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

const GenomeVault = ({ name, samples, integrity, backup_sites }) => (
  <div className="bg-gray-800/50 p-4 rounded-lg">
    <div className="flex justify-between items-start mb-3">
      <div>
        <h5 className="text-white font-semibold">{name}</h5>
        <p className="text-sm text-gray-400">{samples.toLocaleString()} samples</p>
      </div>
      <span className={`text-xs px-2 py-1 rounded-full ${
        integrity >= 99 ? 'bg-green-500/20 text-green-400' :
        integrity >= 95 ? 'bg-blue-500/20 text-blue-400' :
        'bg-yellow-500/20 text-yellow-400'
      }`}>
        {integrity}% Integrity
      </span>
    </div>
    <div className="flex items-center justify-between text-xs text-gray-500">
      <span>{backup_sites} backup sites</span>
      <Database className="w-3 h-3" />
    </div>
  </div>
);

const ResistanceMetric = ({ threat, resistance, trend, icon: Icon }) => (
  <div className="bg-gray-800/30 p-3 rounded-lg">
    <div className="flex items-center justify-between mb-2">
      <div className="flex items-center">
        <Icon className="w-4 h-4 mr-2 text-cyan-400" />
        <span className="text-white text-sm">{threat}</span>
      </div>
      {trend === 'up' ? 
        <TrendingUp className="w-4 h-4 text-green-400" /> :
        <div className="w-4 h-4"></div>
      }
    </div>
    <div className="w-full bg-gray-700 rounded-full h-2">
      <motion.div 
        className="bg-green-400 h-2 rounded-full"
        initial={{ width: 0 }}
        animate={{ width: `${resistance}%` }}
        transition={{ duration: 1.5 }}
      />
    </div>
    <p className="text-xs text-gray-400 mt-1">{resistance}% resistance</p>
  </div>
);

export default function GenomeFrame() {
  const [genomeVaults] = useState([
    { name: 'Human Core Genome', samples: 2847392, integrity: 99.7, backup_sites: 12 },
    { name: 'Enhanced Guardian DNA', samples: 156890, integrity: 99.9, backup_sites: 8 },
    { name: 'Colonial Adaptations', samples: 89234, integrity: 98.4, backup_sites: 6 },
    { name: 'Extremophile Variants', samples: 34567, integrity: 99.2, backup_sites: 4 }
  ]);

  const [resistanceData] = useState([
    { threat: 'Radiation Exposure', resistance: 94, trend: 'up', icon: Shield },
    { threat: 'Pathogenic Diseases', resistance: 97, trend: 'up', icon: Shield },
    { threat: 'Genetic Degradation', resistance: 89, trend: 'stable', icon: Dna },
    { threat: 'Environmental Toxins', resistance: 92, trend: 'up', icon: Shield }
  ]);

  const [totalSamples, setTotalSamples] = useState(0);

  useEffect(() => {
    const total = genomeVaults.reduce((sum, vault) => sum + vault.samples, 0);
    setTotalSamples(total);
  }, [genomeVaults]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="glass-pane p-6">
        <div className="flex justify-between items-center mb-6">
          <h4 className="text-lg font-semibold text-white flex items-center">
            <Database className="w-5 h-5 mr-3 text-cyan-400" />
            Genetic Preservation Vaults
          </h4>
          <div className="text-right">
            <p className="text-2xl font-bold text-cyan-400">{totalSamples.toLocaleString()}</p>
            <p className="text-xs text-gray-400">Total Samples</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {genomeVaults.map((vault, index) => (
            <GenomeVault key={index} {...vault} />
          ))}
        </div>
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Dna className="w-5 h-5 mr-3 text-purple-400" />
          Disease Resistance Evolution
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {resistanceData.map((resistance, index) => (
            <ResistanceMetric key={index} {...resistance} />
          ))}
        </div>
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-3 text-green-400" />
          Genetic Continuity Status
        </h4>
        <div className="space-y-3">
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Bio-Data Vault Synchronization</span>
            <span className="text-green-400 font-semibold">99.8% Complete</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Cross-Colony Backup Network</span>
            <span className="text-blue-400 font-semibold">Active</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Extinction Risk Assessment</span>
            <span className="text-green-400 font-semibold">Minimal</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}