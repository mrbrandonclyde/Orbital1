import React from 'react';
import { Brain, Dna, Heart, Users } from 'lucide-react';

export default function BioSymbiosisMonitor({ missions }) {
  const getMissionsByType = (type) => missions.filter(m => m.mission_type === type);

  const protocolStats = [
    {
      type: 'bio_symbiosis_protocol',
      name: 'Bio-Symbiosis',
      icon: Heart,
      color: 'text-red-400',
      missions: getMissionsByType('bio_symbiosis_protocol'),
      metrics: { active: 8, success_rate: '97.2%', enhancement: '12.7x' }
    },
    {
      type: 'cross_species_protocol', 
      name: 'Cross-Species',
      icon: Users,
      color: 'text-cyan-400',
      missions: getMissionsByType('cross_species_protocol'),
      metrics: { active: 3, success_rate: '94.8%', coordination: '15 species' }
    },
    {
      type: 'genetic_continuity_protocol',
      name: 'Genetic Continuity', 
      icon: Dna,
      color: 'text-green-400',
      missions: getMissionsByType('genetic_continuity_protocol'),
      metrics: { active: 12, samples: '47,392', integrity: '99.97%' }
    },
    {
      type: 'cognitive_symbiosis_protocol',
      name: 'Cognitive Symbiosis',
      icon: Brain, 
      color: 'text-purple-400',
      missions: getMissionsByType('cognitive_symbiosis_protocol'),
      metrics: { decisions: '847', success_rate: '99.2%', response_time: '0.3ms' }
    }
  ];

  return (
    <div className="space-y-6">
      <div className="orbital-card p-6">
        <h3 className="orbital-text-heading mb-6">Bio-Symbiosis Protocol Overview</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {protocolStats.map(protocol => {
            const Icon = protocol.icon;
            return (
              <div key={protocol.type} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <Icon className={`w-6 h-6 ${protocol.color}`} />
                  <div>
                    <h4 className="font-semibold text-white">{protocol.name}</h4>
                    <p className="text-xs text-gray-400">{protocol.missions.length} active missions</p>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  {Object.entries(protocol.metrics).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-400 capitalize">{key.replace(/_/g, ' ')}</span>
                      <span className={`font-semibold ${protocol.color}`}>{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="orbital-card p-6">
        <h3 className="orbital-text-heading mb-4">System-Wide Integration Status</h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg text-center">
            <Brain className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">97.4%</p>
            <p className="text-sm text-gray-400">Neural Integration</p>
          </div>
          
          <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
            <Dna className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">47.3K</p>
            <p className="text-sm text-gray-400">Genetic Samples</p>
          </div>
          
          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-center">
            <Heart className="w-8 h-8 text-red-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">100%</p>
            <p className="text-sm text-gray-400">Bio-Safety Record</p>
          </div>
        </div>
      </div>
    </div>
  );
}