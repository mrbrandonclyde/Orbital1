import React, { useState } from 'react';
import { Brain, Activity, Heart, Shield, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function NeuralLinkInterface({ missions, onSelectMission }) {
  const [selectedLink, setSelectedLink] = useState(null);

  const neuralMetrics = [
    { 
      name: 'Synaptic Response', 
      value: '0.2ms', 
      status: 'optimal',
      icon: Zap,
      color: 'text-blue-400'
    },
    { 
      name: 'Neural Integration', 
      value: '97.4%', 
      status: 'excellent',
      icon: Brain,
      color: 'text-purple-400'
    },
    { 
      name: 'Bio-Augmentation', 
      value: '12.7x', 
      status: 'enhanced',
      icon: Activity,
      color: 'text-green-400'
    },
    { 
      name: 'Immune Guardian', 
      value: '100%', 
      status: 'active',
      icon: Shield,
      color: 'text-red-400'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Neural Link Status Grid */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-heading flex items-center mb-6">
          <Brain className="w-6 h-6 mr-2 text-purple-400" />
          Neural Link Interface Status
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {neuralMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-gray-800/30 rounded-lg border border-gray-700"
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon className={`w-5 h-5 ${metric.color}`} />
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    metric.status === 'optimal' ? 'bg-blue-500/20 text-blue-400' :
                    metric.status === 'excellent' ? 'bg-purple-500/20 text-purple-400' :
                    metric.status === 'enhanced' ? 'bg-green-500/20 text-green-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {metric.status}
                  </span>
                </div>
                <p className="text-sm text-gray-400">{metric.name}</p>
                <p className={`text-2xl font-bold ${metric.color}`}>{metric.value}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Neural Activity Visualization */}
        <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
          <h4 className="text-sm font-semibold text-purple-400 mb-3">Live Neural Activity</h4>
          <div className="relative h-32 bg-gray-900 rounded overflow-hidden">
            <svg width="100%" height="100%" className="absolute top-0 left-0">
              <defs>
                <linearGradient id="neuralGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="rgba(168, 85, 247, 0.8)" />
                  <stop offset="50%" stopColor="rgba(59, 130, 246, 0.8)" />
                  <stop offset="100%" stopColor="rgba(16, 185, 129, 0.8)" />
                </linearGradient>
              </defs>
              <path
                d="M0,64 Q100,20 200,64 T400,64 T600,64 T800,64"
                stroke="url(#neuralGradient)"
                strokeWidth="2"
                fill="none"
                className="animate-pulse"
              />
              <path
                d="M0,80 Q150,40 300,80 T600,80 T900,80"
                stroke="rgba(168, 85, 247, 0.4)"
                strokeWidth="1"
                fill="none"
                className="animate-pulse"
                style={{ animationDelay: '0.5s' }}
              />
            </svg>
            <div className="absolute top-2 right-2 text-xs text-purple-400">
              Neural Bandwidth: 47.2 TB/s
            </div>
          </div>
        </div>
      </div>

      {/* Active Bio-Symbiosis Missions */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-heading flex items-center mb-4">
          <Heart className="w-6 h-6 mr-2 text-red-400" />
          Active Bio-Symbiosis Protocols
        </h3>
        
        <div className="space-y-3">
          {missions.map(mission => (
            <motion.div
              key={mission.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="p-4 bg-gradient-to-r from-red-500/10 to-purple-500/10 border border-red-500/20 rounded-lg cursor-pointer transition-all hover:border-red-500/40"
              onClick={() => onSelectMission(mission)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-semibold text-white">Neural Enhancement Protocol</span>
                    <span className={`text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400`}>
                      {mission.mission_status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">Domain: {mission.target_domain}</p>
                  <p className="text-sm text-gray-400">AI Role: {mission.ai_role?.replace(/_/g, ' ')}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">Mission ID</p>
                  <p className="text-xs text-red-400 font-mono">{mission.mission_id}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {missions.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No active bio-symbiosis protocols detected</p>
          </div>
        )}
      </div>
    </div>
  );
}