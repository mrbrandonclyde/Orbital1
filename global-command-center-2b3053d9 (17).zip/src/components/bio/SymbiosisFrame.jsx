import React, { useState, useEffect } from 'react';
import { Brain, Activity, Zap, Heart, Shield } from 'lucide-react';
import { motion } from 'framer-motion';

const BiometricStat = ({ icon: Icon, label, value, color, unit }) => (
  <div className="bg-gray-800/50 p-4 rounded-lg">
    <div className="flex items-center justify-between mb-2">
      <div className="flex items-center">
        <Icon className={`w-5 h-5 mr-2 ${color}`} />
        <span className="text-sm font-medium text-gray-300">{label}</span>
      </div>
      <span className={`text-lg font-bold ${color}`}>{value}{unit}</span>
    </div>
    <div className="w-full bg-gray-700 rounded-full h-1.5">
      <motion.div 
        className={`${color.replace('text', 'bg')} h-1.5 rounded-full`}
        initial={{ width: 0 }}
        animate={{ width: `${Math.min(value, 100)}%` }}
        transition={{ duration: 1.5 }}
      />
    </div>
  </div>
);

const NeuralActivity = ({ connections }) => (
  <div className="glass-pane p-6">
    <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
      <Brain className="w-5 h-5 mr-3 text-purple-400" />
      Neural Link Status
    </h4>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {connections.map((connection, index) => (
        <div key={index} className="bg-gray-800/30 p-3 rounded-lg">
          <div className="flex justify-between items-center">
            <span className="text-white font-medium">{connection.region}</span>
            <span className={`text-sm px-2 py-1 rounded-full ${
              connection.status === 'Optimal' ? 'bg-green-500/20 text-green-400' :
              connection.status === 'Stable' ? 'bg-blue-500/20 text-blue-400' :
              'bg-yellow-500/20 text-yellow-400'
            }`}>
              {connection.status}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">Bandwidth: {connection.bandwidth}</p>
        </div>
      ))}
    </div>
  </div>
);

export default function SymbiosisFrame() {
  const [biometricData, setBiometricData] = useState({
    neuralSync: 97.3,
    bioCompatibility: 99.1,
    immuneResponse: 94.7,
    cognitiveLoad: 23.4
  });

  const [neuralConnections] = useState([
    { region: 'Prefrontal Cortex', status: 'Optimal', bandwidth: '2.4 TB/s' },
    { region: 'Motor Cortex', status: 'Stable', bandwidth: '1.8 TB/s' },
    { region: 'Sensory Integration', status: 'Optimal', bandwidth: '3.1 TB/s' },
    { region: 'Memory Centers', status: 'Stable', bandwidth: '2.9 TB/s' }
  ]);

  // Simulate real-time bio-neural updates
  useEffect(() => {
    const interval = setInterval(() => {
      setBiometricData(prev => ({
        neuralSync: Math.max(95, Math.min(100, prev.neuralSync + (Math.random() - 0.5) * 0.5)),
        bioCompatibility: Math.max(98, Math.min(100, prev.bioCompatibility + (Math.random() - 0.5) * 0.2)),
        immuneResponse: Math.max(90, Math.min(100, prev.immuneResponse + (Math.random() - 0.5) * 0.8)),
        cognitiveLoad: Math.max(15, Math.min(35, prev.cognitiveLoad + (Math.random() - 0.5) * 2))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <BiometricStat 
          icon={Brain} 
          label="Neural Sync" 
          value={biometricData.neuralSync.toFixed(1)} 
          color="text-purple-400" 
          unit="%" 
        />
        <BiometricStat 
          icon={Shield} 
          label="Bio-Compatibility" 
          value={biometricData.bioCompatibility.toFixed(1)} 
          color="text-green-400" 
          unit="%" 
        />
        <BiometricStat 
          icon={Heart} 
          label="Immune Response" 
          value={biometricData.immuneResponse.toFixed(1)} 
          color="text-blue-400" 
          unit="%" 
        />
        <BiometricStat 
          icon={Activity} 
          label="Cognitive Load" 
          value={biometricData.cognitiveLoad.toFixed(1)} 
          color="text-orange-400" 
          unit="%" 
        />
      </div>

      <NeuralActivity connections={neuralConnections} />

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Zap className="w-5 h-5 mr-3 text-cyan-400" />
          Bio-Augmentation Status
        </h4>
        <div className="space-y-3">
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Enhanced Reflexes</span>
            <span className="text-green-400 font-semibold">Active</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Immune System Guardian</span>
            <span className="text-green-400 font-semibold">Monitoring</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Neural Link Training</span>
            <span className="text-blue-400 font-semibold">In Progress</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}