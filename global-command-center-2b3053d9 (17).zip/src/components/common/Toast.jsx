import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

let toastId = 0;

const toastStore = {
  toasts: [],
  listeners: [],
  
  addToast(toast) {
    const id = ++toastId;
    const newToast = { id, ...toast, timestamp: Date.now() };
    this.toasts.push(newToast);
    this.notify();
    
    if (toast.duration !== 0) {
      setTimeout(() => this.removeToast(id), toast.duration || 5000);
    }
    
    return id;
  },
  
  removeToast(id) {
    this.toasts = this.toasts.filter(toast => toast.id !== id);
    this.notify();
  },
  
  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  },
  
  notify() {
    this.listeners.forEach(listener => listener(this.toasts));
  }
};

export const toast = {
  success: (message, options = {}) => toastStore.addToast({ type: 'success', message, ...options }),
  error: (message, options = {}) => toastStore.addToast({ type: 'error', message, ...options }),
  warning: (message, options = {}) => toastStore.addToast({ type: 'warning', message, ...options }),
  info: (message, options = {}) => toastStore.addToast({ type: 'info', message, ...options })
};

export function ToastContainer() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    return toastStore.subscribe(setToasts);
  }, []);

  const getIcon = (type) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-400" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'info': return <Info className="w-5 h-5 text-blue-400" />;
      default: return <Info className="w-5 h-5 text-gray-400" />;
    }
  };

  const getBgColor = (type) => {
    switch (type) {
      case 'success': return 'bg-green-500/10 border-green-500/20';
      case 'error': return 'bg-red-500/10 border-red-500/20';
      case 'warning': return 'bg-yellow-500/10 border-yellow-500/20';
      case 'info': return 'bg-blue-500/10 border-blue-500/20';
      default: return 'bg-gray-500/10 border-gray-500/20';
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2" role="region" aria-label="Notifications">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, x: 300, scale: 0.3 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 300, scale: 0.5, transition: { duration: 0.2 } }}
            className={`flex items-center space-x-3 p-4 rounded-lg border backdrop-blur-sm ${getBgColor(toast.type)} max-w-md shadow-lg`}
            role="alert"
            aria-live="polite"
          >
            {getIcon(toast.type)}
            <div className="flex-1">
              <p className="text-white text-sm font-medium">{toast.message}</p>
              {toast.description && (
                <p className="text-gray-400 text-xs mt-1">{toast.description}</p>
              )}
            </div>
            <button
              onClick={() => toastStore.removeToast(toast.id)}
              className="text-gray-400 hover:text-white transition-colors"
              aria-label="Close notification"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}