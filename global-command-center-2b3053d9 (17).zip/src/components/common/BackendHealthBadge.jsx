
import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import { Activity } from "lucide-react";

export default function BackendHealthBadge() {
  const [latency, setLatency] = React.useState(null);
  const [ok, setOk] = React.useState(false);

  React.useEffect(() => {
    let mounted = true;
    SpeedBackend.health.ping().then((res) => {
      if (!mounted) return;
      setOk(true);
      setLatency(res.latency);
    }).catch(() => {
      if (!mounted) return;
      setOk(false);
    });
    return () => { mounted = false; };
  }, []);

  return (
    <div className={`flex items-center gap-2 px-2 py-1 rounded-md border text-xs ${ok ? "border-green-500/30 text-green-300 bg-green-500/10" : "border-red-500/30 text-red-300 bg-red-500/10"}`}>
      <Activity className={`w-3 h-3 ${ok ? "text-green-400" : "text-red-400"}`} />
      <span>{ok ? `Backend: ONLINE${latency != null ? ` • ${latency}ms` : ""}` : "Backend: OFFLINE"}</span>
    </div>
  );
}
