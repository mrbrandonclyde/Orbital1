import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export default function ContactForm({ value, onChange, onSubmit, submitting }) {
  const c = value || {};
  const set = (k, v) => onChange({ ...c, [k]: v });

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <Label className="text-gray-300">First name</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.first_name || ""} onChange={e => set("first_name", e.target.value)} />
        </div>
        <div>
          <Label className="text-gray-300">Last name</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.last_name || ""} onChange={e => set("last_name", e.target.value)} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <Label className="text-gray-300">Email</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.email || ""} onChange={e => set("email", e.target.value)} />
        </div>
        <div>
          <Label className="text-gray-300">Phone</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.phone || ""} onChange={e => set("phone", e.target.value)} />
        </div>
        <div>
          <Label className="text-gray-300">Company</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.company || ""} onChange={e => set("company", e.target.value)} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <Label className="text-gray-300">Job Title</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.job_title || ""} onChange={e => set("job_title", e.target.value)} />
        </div>
        <div>
          <Label className="text-gray-300">Tags (comma separated)</Label>
          <Input className="bg-[#0C0F19] border-gray-700 text-gray-100" value={(c.tags || []).join(", ")} onChange={e => set("tags", e.target.value.split(",").map(s => s.trim()).filter(Boolean))} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <Label className="text-gray-300">Lead Score</Label>
          <Input type="number" className="bg-[#0C0F19] border-gray-700 text-gray-100" value={c.lead_score || 0} onChange={e => set("lead_score", Number(e.target.value || 0))} />
        </div>
        <div>
          <Label className="text-gray-300">Stage</Label>
          <select className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100" value={c.pipeline_stage || "new"} onChange={e => set("pipeline_stage", e.target.value)}>
            {["new","qualified","proposal","won","lost"].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" disabled={submitting} onClick={onSubmit} className="bg-indigo-600 hover:bg-indigo-700">{submitting ? "Saving..." : "Save Contact"}</Button>
      </div>
    </div>
  );
}