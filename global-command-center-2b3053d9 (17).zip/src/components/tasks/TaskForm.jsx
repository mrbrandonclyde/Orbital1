import React, { useState, useEffect } from 'react';
import { Task } from '@/api/entities';
import { User } from '@/api/entities';
import { Mission } from '@/api/entities';
import { logAuditEvent } from '../lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, parseISO } from 'date-fns';

const STATUSES = ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'BLOCKED'];

export default function TaskForm({ task, onSuccess, missionId }) {
  const [formData, setFormData] = useState({
    task_name: '',
    description: '',
    mission_id: missionId || '',
    assigned_to: '',
    status: 'PENDING',
    due_date: '',
  });
  const [users, setUsers] = useState([]);
  const [missions, setMissions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    Promise.all([User.list(), Mission.list()]).then(([userList, missionList]) => {
      setUsers(userList);
      setMissions(missionList);
    });
  }, []);

  useEffect(() => {
    if (task) {
      setFormData({
        task_name: task.task_name || '',
        description: task.description || '',
        mission_id: task.mission_id || '',
        assigned_to: task.assigned_to || '',
        status: task.status || 'PENDING',
        due_date: task.due_date ? format(parseISO(task.due_date), "yyyy-MM-dd'T'HH:mm") : '',
      });
    } else {
      setFormData(prev => ({ ...prev, mission_id: missionId || '' }));
    }
  }, [task, missionId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const submissionData = {
      ...formData,
      due_date: formData.due_date ? new Date(formData.due_date).toISOString() : null,
    };
    try {
      if (task) {
        await Task.update(task.id, submissionData);
        await logAuditEvent('UPDATE', 'Task', task.id, submissionData);
      } else {
        const newTask = await Task.create(submissionData);
        await logAuditEvent('CREATE', 'Task', newTask.id, submissionData);
      }
      onSuccess();
    } catch (error) {
      console.error("Failed to save task:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 pt-4">
      <Input
        value={formData.task_name}
        onChange={(e) => setFormData({ ...formData, task_name: e.target.value })}
        placeholder="Task Name"
        className="bg-[#0C0F19] border-gray-600"
        required
      />
      <Textarea
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
        placeholder="Task Description"
        className="bg-[#0C0F19] border-gray-600 h-24"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select value={formData.assigned_to} onValueChange={(v) => setFormData({ ...formData, assigned_to: v })} required>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Assign to..." /></SelectTrigger>
          <SelectContent>{users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={formData.mission_id} onValueChange={(v) => setFormData({ ...formData, mission_id: v })} required>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Assign to Mission..." /></SelectTrigger>
          <SelectContent>{missions.map(m => <SelectItem key={m.id} value={m.id}>{m.mission_name}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace('_',' ')}</SelectItem>)}</SelectContent>
        </Select>
        <Input
          type="datetime-local"
          value={formData.due_date}
          onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
          className="bg-[#0C0F19] border-gray-600"
        />
      </div>
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onSuccess}>Cancel</Button>
        <Button type="submit" className="orbital-button-primary" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : (task ? 'Update Task' : 'Create Task')}
        </Button>
      </div>
    </form>
  );
}