import React from 'react';
import { AlertTriangle, Shield, CheckCircle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ThreatMatrix({ alerts }) {
  const getPriorityDetails = (priority) => {
    switch (priority) {
      case 'URGENT': return { color: 'border-red-500/50 bg-red-500/10 text-red-400', icon: AlertTriangle };
      case 'HIGH': return { color: 'border-orange-500/50 bg-orange-500/10 text-orange-400', icon: Shield };
      case 'MEDIUM': return { color: 'border-yellow-500/50 bg-yellow-500/10 text-yellow-400', icon: Shield };
      default: return { color: 'border-blue-500/50 bg-blue-500/10 text-blue-400', icon: CheckCircle };
    }
  };

  const urgentCount = alerts?.filter(a => a.priority === 'URGENT').length || 0;
  const highCount = alerts?.filter(a => a.priority === 'HIGH').length || 0;

  return (
    <div className="glass-pane p-6 h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Threat Matrix</h3>
        <div className="flex space-x-4">
          <span className="text-red-400 font-bold">{urgentCount} URGENT</span>
          <span className="text-orange-400 font-bold">{highCount} HIGH</span>
        </div>
      </div>
      <div className="flex-grow overflow-y-auto pr-2 space-y-3">
        {alerts?.length > 0 ? alerts.slice(0, 5).map(alert => {
          const { color, icon: Icon } = getPriorityDetails(alert.priority);
          return (
            <div key={alert.id} className={`p-3 rounded-lg border ${color} flex items-start space-x-3`}>
              <Icon className="w-5 h-5 mt-1 flex-shrink-0" />
              <div>
                <p className="font-medium text-white">{alert.title}</p>
                <p className="text-xs text-gray-400 line-clamp-1">{alert.description}</p>
              </div>
            </div>
          );
        }) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Shield className="w-12 h-12 text-green-400 mb-2" />
            <p className="text-green-400 font-semibold">Threat Level Nominal</p>
            <p className="text-gray-500 text-sm">All channels clear.</p>
          </div>
        )}
      </div>
       <Link to={createPageUrl('Alerts')} className="text-center mt-4 text-sm text-blue-400 hover:underline">
        View All Alerts
      </Link>
    </div>
  );
}