import React from 'react';
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function MetricsCard({ metric, sectorName }) {
  const TrendIcon = { UP: TrendingUp, DOWN: TrendingDown, STABLE: Minus }[metric.trend_direction] || Minus;
  const trendColor = { UP: 'text-green-400', DOWN: 'text-red-400', STABLE: 'text-gray-400' }[metric.trend_direction] || 'text-gray-400';
  
  return (
    <div className="bg-[#0C0F19]/60 p-6 rounded-lg transition-all duration-300 border border-[#151823] hover:border-orbital-primary/50 hover:bg-[#0C0F19]">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-[color:var(--orbital-text-secondary)]">{sectorName}</p>
          <p className="text-base font-semibold text-[color:var(--orbital-text-main)]">{metric.metric_name}</p>
        </div>
        <div className={`p-2 rounded-md ${trendColor}`}>
          <TrendIcon />
        </div>
      </div>
      <div className="mt-4">
        <p className="text-4xl font-bold text-white">{metric.display_value}</p>
        <p className={`mt-1 text-xs font-bold ${trendColor}`}>{metric.status}</p>
      </div>
    </div>
  );
}