import React from 'react';
import { Crown, Zap, Star, ArrowRight } from 'lucide-react';

const UPGRADE_FEATURES = [
  {
    icon: Crown,
    title: "VR War Room Access",
    description: "Step into the immersive 3D command center",
    tier: "ENTERPRISE",
    color: "purple"
  },
  {
    icon: Zap,
    title: "Real-Time Global Alerts",
    description: "Live threat intelligence and supply chain monitoring",
    tier: "PROFESSIONAL", 
    color: "blue"
  },
  {
    icon: Star,
    title: "AI Executive Briefings",
    description: "Automated intelligence reports with actionable insights",
    tier: "PROFESSIONAL",
    color: "yellow"
  }
];

export default function PremiumFeatureBanner({ currentTier = "BASIC" }) {
  const tierLevels = { BASIC: 1, PROFESSIONAL: 2, ENTERPRISE: 3, GOVERNMENT: 4 };
  const currentLevel = tierLevels[currentTier];
  
  const availableUpgrades = UPGRADE_FEATURES.filter(feature => 
    tierLevels[feature.tier] > currentLevel
  );

  if (availableUpgrades.length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-indigo-900/30 to-purple-900/30 border border-indigo-500/30 rounded-xl p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-xl font-semibold text-white">Unlock Premium Intelligence Features</h3>
          <p className="text-gray-400">Upgrade your subscription to access advanced capabilities</p>
        </div>
        <button className="orbital-button-primary flex items-center space-x-2">
          <span>Upgrade Now</span>
          <ArrowRight size={16} />
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {availableUpgrades.map((feature, index) => {
          const Icon = feature.icon;
          const colorClasses = {
            purple: 'text-purple-400 bg-purple-500/10',
            blue: 'text-blue-400 bg-blue-500/10', 
            yellow: 'text-yellow-400 bg-yellow-500/10'
          };
          
          return (
            <div key={index} className="bg-gray-800/30 rounded-lg p-4">
              <div className={`w-8 h-8 rounded-lg ${colorClasses[feature.color]} flex items-center justify-center mb-3`}>
                <Icon className={`w-4 h-4 ${colorClasses[feature.color].split(' ')[0]}`} />
              </div>
              <h4 className="font-semibold text-white text-sm">{feature.title}</h4>
              <p className="text-gray-400 text-xs">{feature.description}</p>
              <div className="mt-2">
                <span className={`text-xs px-2 py-1 rounded-full ${colorClasses[feature.color]}`}>
                  {feature.tier}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}