import React from 'react';

export default function SkeletonCard() {
  return (
    <div className="w-full h-24 rounded-xl bg-gray-800/40 animate-pulse border border-[#151823]">
      <div className="p-4 h-full flex flex-col justify-between">
        <div className="space-y-2">
          <div className="h-3 bg-gray-700 rounded w-2/3"></div>
          <div className="h-2 bg-gray-700 rounded w-1/2"></div>
        </div>
        <div className="h-6 bg-gray-700 rounded w-1/3"></div>
      </div>
    </div>
  );
}