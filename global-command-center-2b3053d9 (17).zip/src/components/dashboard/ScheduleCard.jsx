import React from 'react';
import { format } from "date-fns";
import { Calendar } from "lucide-react";

export default function ScheduleCard({ event }) {
    const priorityStyles = {
    CRITICAL: { text: 'text-red-400' },
    HIGH: { text: 'text-purple-400' },
    MEDIUM: { text: 'text-indigo-400' },
    LOW: { text: 'text-gray-500' },
  };
  const styles = priorityStyles[event.priority] || priorityStyles.MEDIUM;

  return (
    <div className="bg-[#0C0F19]/60 p-4 rounded-lg flex items-center space-x-4 transition-all duration-300 hover:bg-[#0C0F19] border border-transparent hover:border-orbital-primary/30">
      <div className="flex flex-col items-center justify-center text-center w-12 border-r border-gray-700/50 pr-4">
        <span className="text-xs text-[color:var(--orbital-text-secondary)]">{format(new Date(event.start_date_time), "MMM")}</span>
        <span className="text-xl font-bold text-white">{format(new Date(event.start_date_time), "dd")}</span>
      </div>
      <div className="flex-1">
        <h4 className="font-bold text-white">{event.event_title}</h4>
        <p className="text-sm text-[color:var(--orbital-text-secondary)]">{event.event_type} at {format(new Date(event.start_date_time), "hh:mm a")}</p>
      </div>
       <span className={`text-xs font-semibold px-2 py-1 rounded-md bg-black/30 ${styles.text}`}>{event.priority}</span>
    </div>
  );
}