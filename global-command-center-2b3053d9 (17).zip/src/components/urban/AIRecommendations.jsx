import React, { useState } from "react";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export default function AIRecommendations({ project, zones = [], assets = [] }) {
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState(null);

  const generate = async () => {
    setLoading(true);
    setPlan(null);
    const context = {
      project: project ? {
        name: project.project_name,
        status: project.status,
        population_target: project.population_target,
        budget_usd: project.budget_usd,
        goals: project.sustainability_goals
      } : null,
      zones: zones.map(z => ({ name: z.zone_name, type: z.zone_type, density: z.density, area_hectares: z.area_hectares })),
      assets: assets.map(a => ({ name: a.asset_name, type: a.asset_type, status: a.status, cost: a.cost_estimate_usd }))
    };

    const schema = {
      "type": "object",
      "properties": {
        "plan_summary": { "type": "string" },
        "key_actions": { "type": "array", "items": { "type": "string" } },
        "risks": { "type": "array", "items": { "type": "string" } },
        "kpis": {
          "type": "object",
          "properties": {
            "green_space_percent": { "type": "number" },
            "avg_commute_time_min": { "type": "number" },
            "housing_units": { "type": "number" },
            "co2_emissions_tons": { "type": "number" }
          },
          "additionalProperties": true
        }
      },
      "required": ["plan_summary", "key_actions"]
    };

    const res = await InvokeLLM({
      prompt: `You are an urban planning AI. Given this city context, propose a phased plan with actions and KPIs.\n\nContext JSON:\n${JSON.stringify(context, null, 2)}`,
      response_json_schema: schema
    });

    setPlan(res);
    setLoading(false);
  };

  return (
    <Card className="bg-[#0A0D18]/50 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Sparkles className="w-5 h-5 mr-2 text-emerald-400" />
          AI Urban Plan
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <p className="text-gray-400 text-sm">Generate an initial roadmap and KPIs based on your project and zones.</p>
          <Button onClick={generate} disabled={loading || !project}>
            {loading ? "Thinking..." : "Generate Plan"}
          </Button>
        </div>

        {!project && <div className="text-sm text-yellow-400">Create or select a project to generate a plan.</div>}

        {plan && (
          <div className="space-y-4">
            <div>
              <h4 className="text-white font-semibold mb-1">Summary</h4>
              <p className="text-gray-300 text-sm">{plan.plan_summary}</p>
            </div>
            {Array.isArray(plan.key_actions) && plan.key_actions.length > 0 && (
              <div>
                <h4 className="text-white font-semibold mb-1">Key Actions</h4>
                <ul className="list-disc list-inside text-gray-300 text-sm">
                  {plan.key_actions.map((a, i) => (<li key={i}>{a}</li>))}
                </ul>
              </div>
            )}
            {Array.isArray(plan.risks) && plan.risks.length > 0 && (
              <div>
                <h4 className="text-white font-semibold mb-1">Risks</h4>
                <ul className="list-disc list-inside text-gray-300 text-sm">
                  {plan.risks.map((a, i) => (<li key={i}>{a}</li>))}
                </ul>
              </div>
            )}
            {plan.kpis && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(plan.kpis).map(([k, v]) => (
                  <div key={k} className="p-3 bg-gray-800/30 rounded-lg">
                    <div className="text-gray-400 text-xs">{k}</div>
                    <div className="text-white font-semibold">{String(v)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}