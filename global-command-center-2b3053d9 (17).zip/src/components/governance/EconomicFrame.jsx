import React, { useState } from 'react';
import { DollarSign, TrendingUp, BarChart, Shuffle } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart as RechartsBarChart, Bar } from 'recharts';

const economicData = Array.from({ length: 24 }, (_, i) => ({
  quarter: `Q${(i % 4) + 1}Y${Math.floor(i/4) + 2020}`,
  gdp: 22000 + i * 150 + Math.random() * 200,
  employment: 96 + Math.random() * 3,
  inflation: 2.1 + Math.random() * 1.2
}));

const tradeData = Array.from({ length: 12 }, (_, i) => ({
  region: ['NA', 'EU', 'APAC', 'LATAM', 'MENA', 'AFR', 'CIS', 'ASEAN', 'MERCOSUR', 'GCC', 'EAC', 'CARICOM'][i],
  exports: Math.random() * 500 + 200,
  imports: Math.random() * 400 + 180,
  balance: Math.random() * 200 - 100
}));

export default function EconomicFrame() {
  const [selectedMetric, setSelectedMetric] = useState('gdp');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <DollarSign className="w-8 h-8 text-green-400" />
            <div>
              <h2 className="orbital-text-heading">Economic Protocol Frame</h2>
              <p className="orbital-text-caption">Global wealth balancing and predictive economic stability.</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Civilization Accord: Article 2</p>
            <p className="text-xs text-green-400">Economic Justice Maintained</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
            Economic Stability Metrics
          </h3>
          <div className="mb-4 flex space-x-2">
            {['gdp', 'employment', 'inflation'].map(metric => (
              <button
                key={metric}
                onClick={() => setSelectedMetric(metric)}
                className={`px-3 py-1 text-xs rounded capitalize ${
                  selectedMetric === metric ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                {metric}
              </button>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={economicData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="quarter" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Line type="monotone" dataKey={selectedMetric} stroke="#10B981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI predictive economics prevents market crashes. Resource allocation appears naturally optimized.
            </p>
          </div>
        </div>

        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Shuffle className="w-5 h-5 mr-2 text-blue-400" />
            Global Trade Flow Balance
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <RechartsBarChart data={tradeData.slice(0, 8)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="region" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Bar dataKey="balance" fill="#3B82F6" />
            </RechartsBarChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI balances global trade flows preventing economic warfare. Human leaders appear naturally diplomatic.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}