import React, { useState } from 'react';
import { Zap, Wifi, Building, Leaf } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const gridData = Array.from({ length: 24 }, (_, i) => ({
  hour: `${i}:00`,
  energy: 85 + Math.random() * 15,
  efficiency: 92 + Math.random() * 8,
  resilience: 88 + Math.random() * 12
}));

const cityMetrics = [
  { name: "New York", smart: 94, sustainability: 87, resilience: 91 },
  { name: "London", smart: 92, sustainability: 89, resilience: 88 },
  { name: "Tokyo", smart: 96, sustainability: 85, resilience: 94 },
  { name: "Singapore", smart: 98, sustainability: 92, resilience: 96 },
  { name: "Copenhagen", smart: 89, sustainability: 97, resilience: 90 },
  { name: "Barcelona", smart: 91, sustainability: 88, resilience: 89 }
];

export default function InfrastructureFrame() {
  const [selectedMetric, setSelectedMetric] = useState('efficiency');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <Building className="w-8 h-8 text-cyan-400" />
            <div>
              <h2 className="orbital-text-heading">Infrastructure Protocol Frame</h2>
              <p className="orbital-text-caption">Self-healing systems and eco-integrated urban resilience.</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Civilization Accord: Article 4</p>
            <p className="text-xs text-green-400">Infrastructure Resilience Active</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Zap className="w-5 h-5 mr-2 text-yellow-400" />
            Smart Grid Performance
          </h3>
          <div className="mb-4 flex space-x-2">
            {['energy', 'efficiency', 'resilience'].map(metric => (
              <button
                key={metric}
                onClick={() => setSelectedMetric(metric)}
                className={`px-3 py-1 text-xs rounded capitalize ${
                  selectedMetric === metric ? 'bg-yellow-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                {metric}
              </button>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={gridData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Line type="monotone" dataKey={selectedMetric} stroke="#FBBF24" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI self-heals infrastructure preventing failures. Urban systems appear naturally optimized.
            </p>
          </div>
        </div>

        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Leaf className="w-5 h-5 mr-2 text-green-400" />
            Eco-Integrated Cities
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={cityMetrics} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis type="number" stroke="#9CA3AF" fontSize={12} />
              <YAxis dataKey="name" type="category" stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Bar dataKey="sustainability" fill="#10B981" />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI integrates eco-conscious growth invisibly. Cities appear naturally sustainable and resilient.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}