
import React, { useState, useEffect, useCallback } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { useQuery } from '../lib/useQuery';
import { SecurityAlert } from '@/api/entities';
import { SupplyChainRisk } from '@/api/entities';
import { OSINTFeed } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Brain, Zap, Target, Shield, TrendingUp, AlertTriangle, Eye, Cpu } from 'lucide-react';

export default function AIIntelligenceEngine() {
  const [intelligence, setIntelligence] = useState({
    threatPredictions: [],
    riskAssessments: [],
    strategicRecommendations: [],
    anomalies: []
  });
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState(null);

  // Fetch all relevant data for AI analysis
  const { data: analysisData, loading } = useQuery(['intelligenceData'], async () => {
    const [alerts, risks, osintFeeds] = await Promise.all([
      SecurityAlert.list('-created_date', 100),
      SupplyChainRisk.list('-last_assessment_date', 50),
      OSINTFeed.filter({ is_processed: false }, '-publication_date', 100)
    ]);

    return { alerts, risks, osintFeeds };
  });

  // AI Analysis Engine
  const performIntelligenceAnalysis = useCallback(async () => {
    if (!analysisData || isAnalyzing) return;

    setIsAnalyzing(true);
    
    try {
      // Threat Pattern Analysis
      const threatAnalysis = await InvokeLLM({
        prompt: `Analyze the following security alerts and identify emerging threat patterns:
        
        ${JSON.stringify(analysisData.alerts.slice(0, 20), null, 2)}
        
        Provide:
        1. Emerging threat patterns
        2. Risk escalation predictions for the next 24-48 hours
        3. Recommended immediate actions
        4. Strategic countermeasures
        
        Focus on actionable intelligence for a Global Command Center.`,
        response_json_schema: {
          type: "object",
          properties: {
            emerging_patterns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  pattern_name: { type: "string" },
                  confidence: { type: "number" },
                  risk_level: { type: "string" },
                  description: { type: "string" },
                  indicators: { type: "array", items: { type: "string" } }
                }
              }
            },
            predictions: {
              type: "array", 
              items: {
                type: "object",
                properties: {
                  timeframe: { type: "string" },
                  scenario: { type: "string" },
                  probability: { type: "number" },
                  impact: { type: "string" },
                  mitigation: { type: "string" }
                }
              }
            },
            immediate_actions: { type: "array", items: { type: "string" } },
            strategic_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Supply Chain Risk Analysis
      const supplyChainAnalysis = await InvokeLLM({
        prompt: `Analyze these supply chain risks and identify system-wide vulnerabilities:
        
        ${JSON.stringify(analysisData.risks.slice(0, 15), null, 2)}
        
        Provide:
        1. Cross-sector risk correlations
        2. Cascade failure scenarios
        3. Alternative sourcing recommendations
        4. Strategic resilience measures`,
        response_json_schema: {
          type: "object",
          properties: {
            correlations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  sectors: { type: "array", items: { type: "string" } },
                  correlation_strength: { type: "number" },
                  risk_amplification: { type: "string" }
                }
              }
            },
            cascade_scenarios: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  trigger: { type: "string" },
                  cascade_path: { type: "array", items: { type: "string" } },
                  total_impact: { type: "string" },
                  prevention_strategy: { type: "string" }
                }
              }
            },
            resilience_measures: { type: "array", items: { type: "string" } }
          }
        }
      });

      // OSINT Intelligence Synthesis
      const osintAnalysis = await InvokeLLM({
        prompt: `Synthesize intelligence from these OSINT feeds and identify strategic implications:
        
        ${JSON.stringify(analysisData.osintFeeds.slice(0, 10), null, 2)}
        
        Provide:
        1. Strategic intelligence summaries
        2. Geopolitical trend analysis
        3. Economic impact assessments
        4. Early warning indicators`,
        response_json_schema: {
          type: "object",
          properties: {
            strategic_intel: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  topic: { type: "string" },
                  significance: { type: "string" },
                  implications: { type: "string" },
                  confidence: { type: "number" }
                }
              }
            },
            geopolitical_trends: { type: "array", items: { type: "string" } },
            economic_impacts: { type: "array", items: { type: "string" } },
            early_warnings: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Anomaly Detection
      const anomalyDetection = await InvokeLLM({
        prompt: `Perform anomaly detection across all data sources. Identify:
        1. Statistical anomalies in alert patterns
        2. Unusual risk correlations
        3. Information gaps or inconsistencies
        4. Potential blind spots in intelligence coverage`,
        response_json_schema: {
          type: "object",
          properties: {
            statistical_anomalies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  description: { type: "string" },
                  severity: { type: "string" },
                  investigation_priority: { type: "number" }
                }
              }
            },
            intelligence_gaps: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Compile comprehensive intelligence report
      setIntelligence({
        threatPredictions: [
          ...threatAnalysis.emerging_patterns || [],
          ...threatAnalysis.predictions || []
        ],
        riskAssessments: [
          ...supplyChainAnalysis.correlations || [],
          ...supplyChainAnalysis.cascade_scenarios || []
        ],
        strategicRecommendations: [
          ...threatAnalysis.strategic_recommendations || [],
          ...supplyChainAnalysis.resilience_measures || [],
          ...osintAnalysis.geopolitical_trends || []
        ],
        anomalies: [
          ...anomalyDetection.statistical_anomalies || [],
          ...anomalyDetection.intelligence_gaps?.map(gap => ({
            type: 'Intelligence Gap',
            description: gap,
            severity: 'Medium',
            investigation_priority: 3
          })) || []
        ]
      });

      setLastAnalysis(new Date());

    } catch (error) {
      console.error('AI Intelligence Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [analysisData, isAnalyzing]);

  // Auto-analyze when data is available
  useEffect(() => {
    if (analysisData && !loading) {
      performIntelligenceAnalysis();
    }
  }, [analysisData, loading, performIntelligenceAnalysis]);

  const getPriorityColor = (priority) => {
    if (priority >= 8) return 'text-red-400 bg-red-500/10';
    if (priority >= 6) return 'text-orange-400 bg-orange-500/10';
    if (priority >= 4) return 'text-yellow-400 bg-yellow-500/10';
    return 'text-blue-400 bg-blue-500/10';
  };

  return (
    <div className="space-y-6">
      {/* AI Intelligence Header */}
      <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/30">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <Brain className="w-6 h-6 mr-3 text-purple-400" />
              AI Intelligence Engine
            </span>
            <div className="flex items-center space-x-4">
              {isAnalyzing && (
                <div className="flex items-center space-x-2">
                  <Cpu className="w-4 h-4 text-purple-400 animate-pulse" />
                  <span className="text-purple-400 text-sm">Analyzing...</span>
                </div>
              )}
              <button 
                onClick={performIntelligenceAnalysis}
                disabled={isAnalyzing}
                className="orbital-button-secondary text-xs"
              >
                Re-analyze
              </button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">{intelligence.threatPredictions.length}</div>
              <div className="text-sm text-gray-400">Threat Patterns</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{intelligence.riskAssessments.length}</div>
              <div className="text-sm text-gray-400">Risk Correlations</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{intelligence.strategicRecommendations.length}</div>
              <div className="text-sm text-gray-400">Recommendations</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-400">{intelligence.anomalies.length}</div>
              <div className="text-sm text-gray-400">Anomalies Detected</div>
            </div>
          </div>
          {lastAnalysis && (
            <div className="mt-4 text-center text-xs text-gray-500">
              Last Analysis: {lastAnalysis.toLocaleString()}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Intelligence Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Threat Predictions */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="w-5 h-5 mr-2 text-red-400" />
              Threat Predictions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {intelligence.threatPredictions.slice(0, 5).map((prediction, index) => (
                <div key={index} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-white">
                      {prediction.pattern_name || prediction.scenario}
                    </h4>
                    <span className={`text-xs px-2 py-1 rounded ${
                      prediction.confidence >= 0.8 || prediction.probability >= 0.8 ? 'bg-red-500/20 text-red-400' :
                      prediction.confidence >= 0.6 || prediction.probability >= 0.6 ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>
                      {prediction.confidence ? 
                        `${(prediction.confidence * 100).toFixed(0)}%` : 
                        `${(prediction.probability * 100).toFixed(0)}%`
                      }
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">
                    {prediction.description || prediction.mitigation}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Risk Assessments */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="w-5 h-5 mr-2 text-orange-400" />
              Risk Correlations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {intelligence.riskAssessments.slice(0, 5).map((assessment, index) => (
                <div key={index} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-white">
                      {assessment.sectors?.join(' ↔ ') || assessment.trigger}
                    </h4>
                    <span className={`text-xs px-2 py-1 rounded ${
                      assessment.correlation_strength >= 0.8 ? 'bg-red-500/20 text-red-400' :
                      assessment.correlation_strength >= 0.6 ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>
                      {assessment.correlation_strength ? 
                        `${(assessment.correlation_strength * 100).toFixed(0)}%` : 
                        'High Impact'
                      }
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">
                    {assessment.risk_amplification || assessment.prevention_strategy}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Strategic Recommendations */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
              Strategic Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {intelligence.strategicRecommendations.slice(0, 6).map((recommendation, index) => (
                <div key={index} className="flex items-start space-x-2 p-2 hover:bg-gray-800/30 rounded">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-300 text-sm">{recommendation}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Anomalies */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="w-5 h-5 mr-2 text-purple-400" />
              Detected Anomalies
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {intelligence.anomalies.slice(0, 5).map((anomaly, index) => (
                <div key={index} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-white">{anomaly.type}</h4>
                    <span className={`text-xs px-2 py-1 rounded ${getPriorityColor(anomaly.investigation_priority || 5)}`}>
                      Priority {anomaly.investigation_priority || 'Medium'}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">{anomaly.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
