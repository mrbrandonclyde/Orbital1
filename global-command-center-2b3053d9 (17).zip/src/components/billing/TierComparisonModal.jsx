import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle, X, Zap, Crown, CreditCard } from 'lucide-react';

const TIERS = [
  {
    id: 'BASIC',
    name: 'Basic',
    price: 99,
    icon: CreditCard,
    color: 'border-gray-500',
    features: [
      { name: '2 Business Sectors', included: true },
      { name: '100 API Calls/month', included: true },
      { name: 'Basic Reports', included: true },
      { name: 'Email Support', included: true },
      { name: 'AI Intelligence Hub', included: false },
      { name: 'VR War Room', included: false },
      { name: 'Real-time Data Feeds', included: false },
      { name: 'Custom Branding', included: false }
    ]
  },
  {
    id: 'PROFESSIONAL', 
    name: 'Professional',
    price: 299,
    icon: Zap,
    color: 'border-blue-500',
    popular: true,
    features: [
      { name: '5 Business Sectors', included: true },
      { name: '1,000 API Calls/month', included: true },
      { name: 'Premium Reports & Analytics', included: true },
      { name: 'Priority Support', included: true },
      { name: 'AI Intelligence Hub', included: true },
      { name: '10 State Dashboards', included: true },
      { name: 'Real-time Data Feeds', included: true },
      { name: 'VR War Room', included: false }
    ]
  },
  {
    id: 'ENTERPRISE',
    name: 'Enterprise', 
    price: 999,
    icon: Crown,
    color: 'border-purple-500',
    features: [
      { name: 'Unlimited Sectors', included: true },
      { name: 'Unlimited API Calls', included: true },
      { name: 'Advanced Analytics & AI', included: true },
      { name: '24/7 Dedicated Support', included: true },
      { name: 'Full VR War Room Access', included: true },
      { name: '50 State Dashboards', included: true },
      { name: 'White-label Branding', included: true },
      { name: 'Custom Integrations', included: true }
    ]
  }
];

export default function TierComparisonModal({ isOpen, onClose, currentTier }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-6xl">
        <DialogHeader>
          <DialogTitle className="orbital-gradient-text text-2xl">Choose Your Plan</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          {TIERS.map(tier => {
            const Icon = tier.icon;
            const isCurrentTier = currentTier === tier.id;
            
            return (
              <div 
                key={tier.id} 
                className={`relative bg-gray-800/50 border-2 rounded-xl p-6 ${
                  tier.popular ? 'border-blue-500' : tier.color
                } ${isCurrentTier ? 'ring-2 ring-green-400' : ''}`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                {isCurrentTier && (
                  <div className="absolute -top-3 right-4">
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      Current Plan
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <Icon className={`w-8 h-8 mx-auto mb-3 ${tier.id === 'BASIC' ? 'text-gray-400' : tier.id === 'PROFESSIONAL' ? 'text-blue-400' : 'text-purple-400'}`} />
                  <h3 className="text-xl font-bold text-white">{tier.name}</h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-white">${tier.price}</span>
                    <span className="text-gray-400">/month</span>
                  </div>
                </div>
                
                <div className="space-y-3 mb-6">
                  {tier.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      {feature.included ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <X className="w-4 h-4 text-gray-500" />
                      )}
                      <span className={`text-sm ${feature.included ? 'text-gray-300' : 'text-gray-500'}`}>
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>
                
                <button 
                  className={`w-full py-2 px-4 rounded-lg font-semibold transition-colors ${
                    isCurrentTier 
                      ? 'bg-green-500/20 text-green-400 cursor-default' 
                      : tier.popular
                      ? 'bg-blue-500 hover:bg-blue-600 text-white'
                      : 'bg-gray-700 hover:bg-gray-600 text-white'
                  }`}
                  disabled={isCurrentTier}
                >
                  {isCurrentTier ? 'Current Plan' : `Upgrade to ${tier.name}`}
                </button>
              </div>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}