import React from "react";

export default function VoiceControls() {
  return (
    <div className="bg-gray-900 text-white p-2 rounded shadow">
      {/* 🎙️ Voice Controls */}
      <p className="text-sm">Voice input ready...</p>
      {/* TODO: Web Speech API / Whisper integration */}
    </div>
  );
}