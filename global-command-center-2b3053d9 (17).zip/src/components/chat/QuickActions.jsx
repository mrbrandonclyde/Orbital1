import React from "react";

export default function QuickActions() {
  return (
    <div className="p-2 border-t border-gray-600 flex space-x-2">
      <button className="bg-blue-600 px-3 py-1 rounded hover:bg-blue-700 text-sm">
        📊 Reports
      </button>
      <button className="bg-green-600 px-3 py-1 rounded hover:bg-green-700 text-sm">
        ⚡ Alerts
      </button>
      <button className="bg-yellow-600 px-3 py-1 rounded hover:bg-yellow-700 text-sm">
        🌍 Sectors
      </button>
      {/* TODO: Hook actions to API routes */}
    </div>
  );
}