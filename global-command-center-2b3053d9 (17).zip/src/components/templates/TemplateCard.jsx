import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Eye, Save, Play } from "lucide-react";

function Stars({ value = 0 }) {
  const full = Math.round(value);
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`w-4 h-4 ${i < full ? "text-yellow-400" : "text-gray-600"}`} fill={i < full ? "currentColor" : "none"} />
      ))}
    </div>
  );
}

export default function TemplateCard({ template, onPreview, onUse, onSave }) {
  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-3xl overflow-hidden hover:border-indigo-500/30 transition">
      <div className="h-40 w-full overflow-hidden">
        <img src={template.thumbnail_url} alt={template.template_name} className="w-full h-full object-cover" />
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-white text-base flex items-center justify-between">
          <span className="truncate">{template.template_name}</span>
          <Badge variant="secondary" className="text-xs">{template.category}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-gray-300 space-y-3">
        {template.description && <p className="line-clamp-2">{template.description}</p>}
        <div className="flex items-center justify-between">
          <Stars value={template.rating || 0} />
          <span className="text-xs text-gray-400">CVR {template.avg_conversion_rate != null ? `${template.avg_conversion_rate}%` : "—"}</span>
        </div>
        <div className="flex items-center gap-2 justify-end">
          <Button size="sm" variant="secondary" onClick={() => onPreview(template)}>
            <Eye className="w-4 h-4 mr-1" /> Preview
          </Button>
          <Button size="sm" variant="secondary" onClick={() => onSave(template)}>
            <Save className="w-4 h-4 mr-1" /> Save
          </Button>
          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700" onClick={() => onUse(template)}>
            <Play className="w-4 h-4 mr-1" /> Use
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}