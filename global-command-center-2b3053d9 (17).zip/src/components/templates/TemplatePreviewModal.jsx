import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

export default function TemplatePreviewModal({ open, onOpenChange, template }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl bg-[#0A0D18] border border-gray-800 rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-white">{template?.template_name || "Template Preview"}</DialogTitle>
          <DialogDescription className="text-gray-400">
            {template?.description || "Preview of the selected template."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="rounded-xl overflow-hidden border border-gray-800">
            <img src={template?.thumbnail_url} alt={template?.template_name} className="w-full h-80 object-cover" />
          </div>
          <div className="text-xs text-gray-400">
            {template?.steps_blueprint?.length ? (
              <div>
                <div className="mb-2 text-gray-300">Included steps:</div>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {template.steps_blueprint.map((s, i) => (
                    <li key={i} className="bg-[#0A0D18]/50 border border-gray-800 rounded-lg p-2">
                      <div className="text-white">{s.step_name}</div>
                      <div className="text-gray-500">Type: {s.step_type}</div>
                      <div className="text-gray-500">Path: /{s.path_slug}</div>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <div>No steps blueprint available.</div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}