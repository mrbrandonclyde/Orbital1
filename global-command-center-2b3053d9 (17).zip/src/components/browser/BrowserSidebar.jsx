import React from "react";
import { Globe, Rocket, Shield, Wallet, FileSignature, Settings as SettingsIcon } from "lucide-react";

const items = [
  { id: "home", name: "Home Dashboard", icon: Globe },
  { id: "missions", name: "Missions", icon: Rocket },
  { id: "vault", name: "Vault", icon: Shield },
  { id: "contracts", name: "AI Contracts", icon: FileSignature },
  { id: "settings", name: "Settings", icon: SettingsIcon }
];

export default function BrowserSidebar({ active, onSelect, toggles }) {
  return (
    <div className="rounded-2xl border border-gray-800 bg-[#0A0D18]/60 p-3">
      <div className="text-xs text-gray-500 mb-2 px-1">Orbital Browser</div>
      <nav className="space-y-1">
        {items.map(it => {
          const disabled =
            (it.id === "missions" && !toggles.missions_enabled) ||
            (it.id === "contracts" && !toggles.contracts_enabled);
          const Icon = it.icon;
          return (
            <button
              key={it.id}
              onClick={() => !disabled && onSelect(it.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm border transition ${
                active === it.id
                  ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border-cyan-500/30 text-white"
                  : "bg-[#0C0F19] border-gray-700 text-gray-300 hover:text-white hover:border-cyan-500/40"
              } ${disabled ? "opacity-60 cursor-not-allowed" : ""}`}
            >
              <Icon className="w-4 h-4 text-gray-400" />
              <span>{it.name}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}