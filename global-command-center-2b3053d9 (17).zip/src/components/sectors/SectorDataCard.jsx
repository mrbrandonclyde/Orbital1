import React from 'react';
import { useLiveData } from '../lib/useLiveData';
import { sectors } from '../data/regions';
import { Card } from '@/components/ui/card';

export default function SectorDataCard({ sector, region }) {
  const eventName = `${sector.id}:update`;
  const liveData = useLiveData(sector.id, region.code, eventName);

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 orbital-glow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-3xl">{sector.icon}</span>
          <div>
            <h3 className="text-xl font-semibold text-white capitalize">{sector.name}</h3>
            <p className="text-gray-400">{region.name}</p>
          </div>
        </div>
        {liveData ? (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-green-400">LIVE</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
            <span className="text-xs text-gray-500">OFFLINE</span>
          </div>
        )}
      </div>

      <div className="bg-gray-800/30 rounded-lg p-4 min-h-[150px] flex items-center justify-center">
        {liveData ? (
          <div className="w-full">
            <h4 className="font-semibold text-white mb-2">Live Data Feed:</h4>
            <pre className="text-xs text-gray-300 overflow-auto max-h-48 bg-black/20 p-2 rounded-md">
              {JSON.stringify(liveData, null, 2)}
            </pre>
          </div>
        ) : (
          <p className="text-gray-500 text-sm text-center">
            Waiting for <span className="font-semibold text-indigo-400">{sector.name}</span> data from <span className="font-semibold text-indigo-400">{region.name}</span>...
          </p>
        )}
      </div>
    </div>
  );
}