import React, { useState } from 'react';
import { BusinessSector } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function SectorForm({ sector, onSuccess }) {
  const [formData, setFormData] = useState({
    sector_code: sector?.sector_code || '',
    sector_name: sector?.sector_name || '',
    sector_category: sector?.sector_category || 'CORE_ECONOMICS',
    description: sector?.description || '',
    country: sector?.country || 'United States',
    state: sector?.state || '',
    gdp_contribution_billions: sector?.gdp_contribution_billions || 0,
    employment_count: sector?.employment_count || 0,
    strategic_importance: sector?.strategic_importance || 'MEDIUM',
    regulation_level: sector?.regulation_level || 'MODERATE',
    is_active: sector?.is_active !== false
  });

  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (sector) {
        await BusinessSector.update(sector.id, formData);
      } else {
        await BusinessSector.create(formData);
      }
      onSuccess();
    } catch (error) {
      console.error('Failed to save sector:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label>Sector Code</Label>
          <Input
            value={formData.sector_code}
            onChange={(e) => setFormData({...formData, sector_code: e.target.value.toUpperCase()})}
            placeholder="TECH, DEF, ENERGY"
            pattern="[A-Z]{3,8}"
            maxLength="8"
            required
          />
        </div>

        <div>
          <Label>Sector Name</Label>
          <Input
            value={formData.sector_name}
            onChange={(e) => setFormData({...formData, sector_name: e.target.value})}
            placeholder="Technology, Defense, etc."
            required
          />
        </div>

        <div>
          <Label>Category</Label>
          <Select value={formData.sector_category} onValueChange={(value) => setFormData({...formData, sector_category: value})}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CORE_ECONOMICS">Core Economics</SelectItem>
              <SelectItem value="DEFENSE_SECURITY">Defense & Security</SelectItem>
              <SelectItem value="HEALTHCARE_LIFE">Healthcare & Life Sciences</SelectItem>
              <SelectItem value="TECHNOLOGY">Technology</SelectItem>
              <SelectItem value="ENERGY_RESOURCES">Energy & Resources</SelectItem>
              <SelectItem value="INTERNATIONAL_CHAINS">International Chains</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Strategic Importance</Label>
          <Select value={formData.strategic_importance} onValueChange={(value) => setFormData({...formData, strategic_importance: value})}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CRITICAL">Critical</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="LOW">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Country</Label>
          <Input
            value={formData.country}
            onChange={(e) => setFormData({...formData, country: e.target.value})}
            placeholder="United States"
          />
        </div>

        <div>
          <Label>State/Region</Label>
          <Input
            value={formData.state}
            onChange={(e) => setFormData({...formData, state: e.target.value})}
            placeholder="California, Texas, etc."
          />
        </div>

        <div>
          <Label>GDP Contribution (Billions USD)</Label>
          <Input
            type="number"
            value={formData.gdp_contribution_billions}
            onChange={(e) => setFormData({...formData, gdp_contribution_billions: parseFloat(e.target.value) || 0})}
            placeholder="0"
          />
        </div>

        <div>
          <Label>Employment Count</Label>
          <Input
            type="number"
            value={formData.employment_count}
            onChange={(e) => setFormData({...formData, employment_count: parseInt(e.target.value) || 0})}
            placeholder="0"
          />
        </div>
      </div>

      <div>
        <Label>Description</Label>
        <Textarea
          value={formData.description}
          onChange={(e) => setFormData({...formData, description: e.target.value})}
          placeholder="Detailed sector description"
          rows={3}
        />
      </div>

      <div>
        <Label>Regulation Level</Label>
        <Select value={formData.regulation_level} onValueChange={(value) => setFormData({...formData, regulation_level: value})}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="HIGHLY_REGULATED">Highly Regulated</SelectItem>
            <SelectItem value="MODERATE">Moderate Regulation</SelectItem>
            <SelectItem value="LOW_REGULATION">Low Regulation</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : (sector ? 'Update Sector' : 'Create Sector')}
        </Button>
      </div>
    </form>
  );
}