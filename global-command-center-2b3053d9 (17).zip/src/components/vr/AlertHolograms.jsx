import React, { useState } from 'react';
import { Html } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';

function Hologram({ alert, index }) {
  const ref = React.useRef();
  const [hovered, setHover] = useState(false);
  const radius = 7 + Math.random() * 2;
  const speed = 0.003 + Math.random() * 0.003;

  useFrame(({ clock }) => {
    const time = clock.getElapsedTime();
    const angle = time * speed + index * (Math.PI / 6);
    ref.current.position.x = radius * Math.cos(angle);
    ref.current.position.z = radius * Math.sin(angle);
    ref.current.position.y = Math.sin(time + index) * 2;
  });

  return (
    <group ref={ref}>
      <Html 
        transform 
        occlude
        onPointerOver={() => setHover(true)}
        onPointerOut={() => setHover(false)}
        style={{
            transition: 'all 0.2s',
            transform: `scale(${hovered ? 1.2 : 1})`,
            pointerEvents: 'auto'
        }}
      >
        <div className={`p-2 rounded-lg border w-48 text-white
          ${alert.priority === 'URGENT' ? 'bg-red-900/50 border-red-500' : 'bg-yellow-900/50 border-yellow-500'}
          backdrop-blur-sm shadow-lg shadow-red-500/50`}>
          <p className="font-bold text-sm">🚨 {alert.priority} ALERT</p>
          <p className="text-xs">{alert.title}</p>
        </div>
      </Html>
    </group>
  );
}

export default function AlertHolograms({ alerts }) {
  return (
    <group>
      {alerts.slice(0, 12).map((alert, i) => ( // Limit for performance
        <Hologram key={alert.id} alert={alert} index={i} />
      ))}
    </group>
  );
}