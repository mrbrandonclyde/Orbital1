import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { motion } from 'framer-motion';

// Custom pulsing icon
const createPulsingIcon = (color) => {
  return L.divIcon({
    html: `<div style="background-color: ${color};" class="w-4 h-4 rounded-full border-2 border-white animate-pulse"></div>`,
    className: 'leaflet-pulsing-icon',
    iconSize: [16, 16],
    iconAnchor: [8, 8]
  });
};

const redIcon = createPulsingIcon('rgba(239, 68, 68, 0.8)');
const orangeIcon = createPulsingIcon('rgba(245, 158, 11, 0.8)');

export default function LiveOperationsMap({ alerts }) {
  // Use placeholder alerts if none are passed
  const displayAlerts = alerts?.length > 0 ? alerts : [
    { id: 'ph1', title: 'Cyber Attack Detected', priority: 'URGENT', lat: 34.0522, lng: -118.2437 },
    { id: 'ph2', title: 'Supply Chain Disruption', priority: 'HIGH', lat: 39.9042, lng: 116.4074 },
    { id: 'ph3', title: 'Geopolitical Tension', priority: 'HIGH', lat: 55.7558, lng: 37.6173 },
  ];

  return (
    <MapContainer center={[20, 0]} zoom={2} style={{ height: '100%', width: '100%' }} scrollWheelZoom={true} className="bg-gray-900">
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      />
      {displayAlerts.map(alert => (
        <Marker
          key={alert.id}
          position={[alert.lat || 0, alert.lng || 0]}
          icon={alert.priority === 'URGENT' ? redIcon : orangeIcon}
        >
          <Popup>
            <div className="bg-[#0c0f19] text-white p-0 m-[-12px] border-none">
              <div className="p-2">
                <h4 className="font-bold text-indigo-400">{alert.title}</h4>
                <p className="text-xs">Priority: {alert.priority}</p>
              </div>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}