import React from "react";

export default function FireGlobeVR() {
  return (
    <div className="w-full h-full bg-gradient-to-br from-black to-gray-900 flex items-center justify-center">
      {/* 🔥 VR Warm Room Ops */}
      <p className="text-amber-400 text-xl font-bold">
        VR Command Center Loading...
      </p>
      {/* TODO: Integrate WebXR / Three.js / Cesium for VR immersion */}
    </div>
  );
}