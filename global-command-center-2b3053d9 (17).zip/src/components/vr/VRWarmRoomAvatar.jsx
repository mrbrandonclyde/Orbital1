import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Activity } from 'lucide-react';

export default function VRWarmRoomAvatar({ avatarModelUrl }) {
  const mountRef = useRef(null);
  const [threeAddons, setThreeAddons] = useState(null);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    const loadAddons = async () => {
      try {
        const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls');
        const { GLTFLoader } = await import('three/examples/jsm/loaders/GLTFLoader');
        setThreeAddons({ OrbitControls, GLTFLoader });
      } catch (e) {
        console.error("Could not load Three.js addons. VR view will be static.", e);
        setLoadError(true);
      }
    };
    loadAddons();
  }, []);

  useEffect(() => {
    if (!mountRef.current || !threeAddons) return;
    
    const { OrbitControls, GLTFLoader } = threeAddons;
    const currentMount = mountRef.current;
    const modelUrl = avatarModelUrl || 'https://raw.githubusercontent.com/base44-ai/docs/main/static/models/astronaut.glb';

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0A0D18);
    
    const camera = new THREE.PerspectiveCamera(75, currentMount.clientWidth / currentMount.clientHeight, 0.1, 1000);
    camera.position.set(0, 1.5, 3);
    
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.outputEncoding = THREE.sRGBEncoding;
    currentMount.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, 1, 0);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 10, 7.5);
    scene.add(directionalLight);

    const loader = new GLTFLoader();
    loader.load(
      modelUrl,
      (gltf) => {
        const model = gltf.scene;
        model.scale.set(1, 1, 1);
        model.position.set(0, 0, 0);
        scene.add(model);
      },
      undefined,
      (error) => {
        console.error('An error happened while loading the model:', error);
      }
    );
    
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshStandardMaterial({ color: 0x1A1D29 })
    );
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (currentMount) {
        camera.aspect = currentMount.clientWidth / currentMount.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (currentMount && renderer.domElement) {
        currentMount.removeChild(renderer.domElement);
      }
      renderer.dispose();
      scene.traverse(object => {
        if (object.isMesh) {
          if (object.geometry) object.geometry.dispose();
          if (object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach(material => material.dispose());
            } else {
              object.material.dispose();
            }
          }
        }
      });
    };
  }, [avatarModelUrl, threeAddons]);

  if (loadError) {
    return (
        <div className="w-full h-96 rounded-xl border border-red-500/30 bg-[#0A0D18] flex items-center justify-center text-red-400 text-center p-4">
            <div>
                <p className="font-bold">VR Component Error</p>
                <p className="text-sm">Could not load required 3D modules. Interactive view is disabled.</p>
            </div>
        </div>
    )
  }
  
  if (!threeAddons) {
     return (
        <div className="w-full h-96 rounded-xl border border-purple-500/30 bg-[#0A0D18] flex items-center justify-center text-purple-400 text-center p-4">
            <div className="flex flex-col items-center gap-2">
                <Activity className="w-6 h-6 animate-spin" />
                <p className="font-bold">Loading VR Environment...</p>
            </div>
        </div>
    )
  }

  return (
      <div 
        ref={mountRef} 
        className="w-full h-96 rounded-xl border border-purple-500/30"
        style={{ background: '#0A0D18' }}
      ></div>
  );
}