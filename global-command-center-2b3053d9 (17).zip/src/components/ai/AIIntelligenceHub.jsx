import React, { useState } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { Brain, Zap, Target, AlertTriangle, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

export default function AIIntelligenceHub() {
  const [query, setQuery] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [analysisType, setAnalysisType] = useState('threat_assessment');

  const handleIntelligenceQuery = async () => {
    if (!query.trim()) return;
    
    setLoading(true);
    try {
      // Removed entity calls that were causing rate limits
      // Using mock data for demo purposes
      const mockAlerts = [
        { id: 1, alert_status: 'ACTIVE', priority: 'HIGH', sector_id: 'energy' },
        { id: 2, alert_status: 'ACTIVE', priority: 'MEDIUM', sector_id: 'finance' }
      ];
      
      const mockMetrics = [
        { sector_id: 'energy', metric_name: 'Production', display_value: '+2.3%' },
        { sector_id: 'finance', metric_name: 'Market Cap', display_value: '$4.2T' }
      ];

      let prompt = '';
      let schema = {};

      switch (analysisType) {
        case 'threat_assessment':
          prompt = `
            As a Global Command Center AI analyst, perform a comprehensive threat assessment based on:
            
            Current Security Alerts: ${JSON.stringify(mockAlerts)}
            Recent Sector Metrics: ${JSON.stringify(mockMetrics)}
            
            User Query: "${query}"
            
            Provide a structured threat assessment with:
            1. Overall threat level (LOW/MEDIUM/HIGH/CRITICAL)
            2. Key threat indicators
            3. Recommended actions
            4. Strategic implications
          `;
          schema = {
            type: "object",
            properties: {
              threat_level: { type: "string", enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] },
              threat_indicators: { type: "array", items: { type: "string" } },
              recommended_actions: { type: "array", items: { type: "string" } },
              strategic_implications: { type: "string" },
              confidence_score: { type: "number", minimum: 0, maximum: 100 }
            }
          };
          break;

        case 'geospatial_analysis':
          prompt = `
            As a geospatial intelligence analyst using satellite data and AI vision models, analyze:
            
            Query: "${query}"
            Current Alerts: ${JSON.stringify(mockAlerts)}
            
            Provide geospatial intelligence including:
            1. Object detection results
            2. Spatial patterns
            3. Movement predictions
            4. Geographic risk assessment
          `;
          schema = {
            type: "object",
            properties: {
              detected_objects: { type: "array", items: { type: "string" } },
              spatial_patterns: { type: "string" },
              movement_predictions: { type: "string" },
              risk_zones: { type: "array", items: { type: "string" } }
            }
          };
          break;

        case 'predictive_modeling':
          prompt = `
            Using spatio-temporal AI models and historical patterns, analyze:
            
            Query: "${query}"
            Sector Metrics: ${JSON.stringify(mockMetrics)}
            
            Provide predictive analysis including:
            1. Short-term forecasts (24-48 hours)
            2. Medium-term trends (1-4 weeks)
            3. Risk probabilities
            4. Scenario modeling
          `;
          schema = {
            type: "object",
            properties: {
              short_term_forecast: { type: "string" },
              medium_term_trends: { type: "string" },
              risk_probabilities: { type: "object" },
              scenarios: { type: "array", items: { type: "string" } }
            }
          };
          break;
      }

      const response = await InvokeLLM({
        prompt,
        response_json_schema: schema,
        add_context_from_internet: true
      });

      setAnalysis(response);
    } catch (error) {
      console.error('Intelligence analysis failed:', error);
      setAnalysis({ error: 'Analysis failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const analysisTypes = [
    { id: 'threat_assessment', name: 'Threat Assessment', icon: AlertTriangle, color: 'text-red-400' },
    { id: 'geospatial_analysis', name: 'Geospatial Intel', icon: Target, color: 'text-blue-400' },
    { id: 'predictive_modeling', name: 'Predictive Analysis', icon: TrendingUp, color: 'text-green-400' }
  ];

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Brain className="w-6 h-6 text-purple-400" />
        <h2 className="text-xl font-semibold text-white">AI Intelligence Hub</h2>
        <div className="flex items-center space-x-1 text-xs bg-purple-500/20 px-2 py-1 rounded">
          <Zap className="w-3 h-3 text-purple-400" />
          <span className="text-purple-400">GPT + Analysis Engine</span>
        </div>
      </div>

      {/* Analysis Type Selection */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        {analysisTypes.map(type => {
          const Icon = type.icon;
          return (
            <button
              key={type.id}
              onClick={() => setAnalysisType(type.id)}
              className={`p-3 rounded-lg border transition-all ${
                analysisType === type.id
                  ? 'border-indigo-500 bg-indigo-500/20'
                  : 'border-gray-700 hover:border-gray-600'
              }`}
            >
              <Icon className={`w-5 h-5 mx-auto mb-1 ${type.color}`} />
              <p className="text-xs text-white font-medium">{type.name}</p>
            </button>
          );
        })}
      </div>

      {/* Query Input */}
      <div className="space-y-3 mb-4">
        <Textarea
          placeholder="Enter intelligence query (e.g., 'Analyze current threat patterns in the energy sector' or 'Predict supply chain disruptions in Southeast Asia')"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="bg-gray-900 border-gray-700 text-white min-h-[80px]"
        />
        <Button
          onClick={handleIntelligenceQuery}
          disabled={loading || !query.trim()}
          className="w-full orbital-button-primary"
        >
          {loading ? (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>AI Analyzing...</span>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <Brain className="w-4 h-4" />
              <span>Generate Intelligence</span>
            </div>
          )}
        </Button>
      </div>

      {/* Analysis Results */}
      {analysis && (
        <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
          <h3 className="font-semibold text-white mb-3 flex items-center space-x-2">
            <Target className="w-4 h-4 text-green-400" />
            <span>Intelligence Analysis Results</span>
          </h3>
          
          {analysis.error ? (
            <p className="text-red-400">{analysis.error}</p>
          ) : (
            <div className="space-y-4 text-sm">
              {analysis.threat_level && (
                <div>
                  <span className="text-gray-400">Threat Level:</span>
                  <span className={`ml-2 px-2 py-1 rounded text-xs font-semibold ${
                    analysis.threat_level === 'CRITICAL' ? 'bg-red-500/20 text-red-400' :
                    analysis.threat_level === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                    analysis.threat_level === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {analysis.threat_level}
                  </span>
                </div>
              )}
              
              {analysis.threat_indicators && (
                <div>
                  <p className="text-gray-400 mb-2">Key Indicators:</p>
                  <ul className="list-disc list-inside space-y-1 text-gray-300">
                    {analysis.threat_indicators.map((indicator, i) => (
                      <li key={i}>{indicator}</li>
                    ))}
                  </ul>
                </div>
              )}

              {analysis.recommended_actions && (
                <div>
                  <p className="text-gray-400 mb-2">Recommended Actions:</p>
                  <ul className="list-disc list-inside space-y-1 text-gray-300">
                    {analysis.recommended_actions.map((action, i) => (
                      <li key={i}>{action}</li>
                    ))}
                  </ul>
                </div>
              )}

              {analysis.strategic_implications && (
                <div>
                  <p className="text-gray-400 mb-2">Strategic Implications:</p>
                  <p className="text-gray-300">{analysis.strategic_implications}</p>
                </div>
              )}

              {analysis.confidence_score && (
                <div className="flex items-center space-x-2">
                  <span className="text-gray-400">Confidence:</span>
                  <div className="flex-1 bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-blue-400 h-2 rounded-full"
                      style={{ width: `${analysis.confidence_score}%` }}
                    ></div>
                  </div>
                  <span className="text-white text-xs">{analysis.confidence_score}%</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Integration Status */}
      <div className="mt-4 p-3 bg-gray-800/30 rounded border border-gray-700">
        <p className="text-xs text-gray-400 mb-2">AI Stack Integration:</p>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-gray-300">OpenAI GPT Connected</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
            <span className="text-gray-300">Rate Limit Protected</span>
          </div>
        </div>
      </div>
    </div>
  );
}