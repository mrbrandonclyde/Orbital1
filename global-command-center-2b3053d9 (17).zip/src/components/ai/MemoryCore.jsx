import React from "react";

export default function MemoryCore() {
  return (
    <div className="bg-gray-700 text-white p-4 rounded-lg shadow">
      {/* 🧠 AI Memory Core */}
      <h3 className="font-bold">Operator Memory</h3>
      <p className="text-sm">Conversation + Ops logs persist here.</p>
      {/* TODO: Hook with backend + DB (Prisma + Postgres) */}
    </div>
  );
}