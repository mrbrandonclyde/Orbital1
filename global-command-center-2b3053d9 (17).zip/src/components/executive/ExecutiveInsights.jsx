import React, { useState } from 'react';
import { Brain, TrendingUp, AlertCircle, Target, Lightbulb } from 'lucide-react';

const insights = [
  {
    type: 'opportunity',
    title: 'Market Expansion Opportunity',
    description: 'AI analysis indicates 23% growth potential in Southeast Asia markets based on current portfolio performance.',
    impact: 'High',
    confidence: '87%',
    icon: TrendingUp,
    color: 'text-green-600',
    bg: 'bg-green-50 dark:bg-green-900/30'
  },
  {
    type: 'risk',
    title: 'Supply Chain Vulnerability',
    description: 'Predictive models show potential disruption in Q2 2024. Recommend diversification strategy.',
    impact: 'Medium',
    confidence: '74%',
    icon: AlertCircle,
    color: 'text-orange-600',
    bg: 'bg-orange-50 dark:bg-orange-900/30'
  },
  {
    type: 'optimization',
    title: 'Cost Reduction Pathway',
    description: 'Operational AI identifies $4.7M annual savings through process automation in finance division.',
    impact: 'High',
    confidence: '92%',
    icon: Target,
    color: 'text-blue-600',
    bg: 'bg-blue-50 dark:bg-blue-900/30'
  },
  {
    type: 'strategic',
    title: 'Technology Investment Timing',
    description: 'Market analysis suggests optimal window for quantum computing infrastructure investment.',
    impact: 'Medium',
    confidence: '68%',
    icon: Lightbulb,
    color: 'text-purple-600',
    bg: 'bg-purple-50 dark:bg-purple-900/30'
  }
];

export default function ExecutiveInsights({ metrics, alerts, timeframe }) {
  const [selectedInsight, setSelectedInsight] = useState(null);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Brain className="w-6 h-6 text-indigo-600" />
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">AI Strategic Insights</h3>
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Generated from {metrics?.length || 47} data points • Updated 5 min ago
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {insights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <div 
              key={index}
              onClick={() => setSelectedInsight(selectedInsight === index ? null : index)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedInsight === index 
                  ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30' 
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className={`p-2 rounded-lg ${insight.bg}`}>
                  <Icon className={`w-5 h-5 ${insight.color}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900 dark:text-white">{insight.title}</h4>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded ${
                        insight.impact === 'High' ? 'bg-red-100 text-red-800' :
                        insight.impact === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {insight.impact}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{insight.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 dark:text-gray-500">
                      Confidence: {insight.confidence}
                    </span>
                    <button className="text-xs text-indigo-600 hover:text-indigo-700 font-medium">
                      View Details →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {selectedInsight !== null && (
        <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Recommended Actions:</h4>
          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
            <li>• Schedule strategic planning session with relevant stakeholders</li>
            <li>• Commission detailed feasibility analysis from finance team</li>
            <li>• Set up monitoring dashboard for key performance indicators</li>
            <li>• Establish timeline and milestone tracking for implementation</li>
          </ul>
        </div>
      )}
    </div>
  );
}