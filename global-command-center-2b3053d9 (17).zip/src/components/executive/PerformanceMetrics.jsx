import React from 'react';
import { Activity, Users, Zap, Target } from 'lucide-react';

const metrics = [
  {
    name: 'System Uptime',
    value: '99.97%',
    icon: Activity,
    color: 'text-green-600',
    bg: 'bg-green-50 dark:bg-green-900/30'
  },
  {
    name: 'Team Efficiency', 
    value: '94.2%',
    icon: Users,
    color: 'text-blue-600',
    bg: 'bg-blue-50 dark:bg-blue-900/30'
  },
  {
    name: 'AI Optimization',
    value: '97.8%',
    icon: Zap,
    color: 'text-purple-600',
    bg: 'bg-purple-50 dark:bg-purple-900/30'
  },
  {
    name: 'Goal Achievement',
    value: '89.1%',
    icon: Target,
    color: 'text-orange-600',
    bg: 'bg-orange-50 dark:bg-orange-900/30'
  }
];

export default function PerformanceMetrics({ sectors, efficiency }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Performance Metrics</h3>
      
      <div className="space-y-4">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className={`p-4 rounded-lg ${metric.bg}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Icon className={`w-5 h-5 ${metric.color}`} />
                  <span className="font-medium text-gray-700 dark:text-gray-300">{metric.name}</span>
                </div>
                <span className={`text-lg font-bold ${metric.color}`}>{metric.value}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">Operational Excellence Score</div>
        <div className="flex items-center justify-between">
          <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-4">
            <div 
              className="bg-indigo-600 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${efficiency || 94.2}%` }}
            ></div>
          </div>
          <span className="text-lg font-bold text-indigo-600">{efficiency?.toFixed(1) || 94.2}%</span>
        </div>
      </div>
    </div>
  );
}