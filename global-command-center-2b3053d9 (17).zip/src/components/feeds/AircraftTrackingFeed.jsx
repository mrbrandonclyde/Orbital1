import React, { useState, useEffect } from 'react';
import { AircraftTracking } from '@/api/entities';
import { useLiveData } from '../lib/useLiveData';
import { Plane, MapPin, Navigation, AlertTriangle, Radio } from 'lucide-react';

export default function AircraftTrackingFeed({ region = 'global' }) {
  const [aircraft, setAircraft] = useState([]);
  const flightUpdate = useLiveData('aviation', region, 'flight:update');

  // Generate mock ADS-B aircraft data
  useEffect(() => {
    const mockAircraft = [
      {
        icao_hex: 'A12345',
        callsign: 'UAL123',
        registration: 'N12345',
        aircraft_type: 'B777',
        operator: 'United Airlines',
        current_position: { latitude: 37.6213, longitude: -122.3790, altitude_feet: 35000, timestamp: new Date().toISOString() },
        ground_speed_knots: 485,
        track_degrees: 95,
        vertical_rate: 0,
        squawk_code: '2000',
        origin_airport: 'KSFO',
        destination_airport: 'KJFK',
        flight_status: 'ACTIVE',
        category: 'COMMERCIAL'
      },
      {
        icao_hex: 'A67890',
        callsign: 'AAL456',
        registration: 'N67890',
        aircraft_type: 'A320',
        operator: 'American Airlines',
        current_position: { latitude: 40.6413, longitude: -73.7781, altitude_feet: 3500, timestamp: new Date().toISOString() },
        ground_speed_knots: 165,
        track_degrees: 270,
        vertical_rate: -800,
        squawk_code: '1200',
        origin_airport: 'KJFK',
        destination_airport: 'KORD',
        flight_status: 'ACTIVE',
        category: 'COMMERCIAL'
      },
      {
        icao_hex: 'AE4D2F',
        callsign: 'USAF01',
        registration: 'USAF',
        aircraft_type: 'KC135',
        operator: 'US Air Force',
        current_position: { latitude: 38.9072, longitude: -77.0369, altitude_feet: 28000, timestamp: new Date().toISOString() },
        ground_speed_knots: 420,
        track_degrees: 45,
        vertical_rate: 0,
        squawk_code: '7777',
        flight_status: 'ACTIVE',
        category: 'MILITARY'
      }
    ];
    setAircraft(mockAircraft);
  }, []);

  // Update with live data when available
  useEffect(() => {
    if (flightUpdate) {
      setAircraft(prev => {
        const updated = [...prev];
        const existingIndex = updated.findIndex(a => a.icao_hex === flightUpdate.icao_hex);
        if (existingIndex >= 0) {
          updated[existingIndex] = { ...updated[existingIndex], ...flightUpdate };
        } else {
          updated.push(flightUpdate);
        }
        return updated;
      });
    }
  }, [flightUpdate]);

  const getCategoryColor = (category) => {
    switch (category) {
      case 'MILITARY': return 'text-red-400';
      case 'EMERGENCY': return 'text-orange-400';
      case 'CARGO': return 'text-purple-400';
      default: return 'text-blue-400';
    }
  };

  const getAircraftIcon = (category) => {
    switch (category) {
      case 'MILITARY': return '✈️';
      case 'CARGO': return '🛫';
      case 'EMERGENCY': return '🚁';
      default: return '✈️';
    }
  };

  const formatAltitude = (altitude) => {
    return altitude ? `FL${Math.round(altitude / 100)}` : 'N/A';
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Plane className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">ADS-B Flight Tracking</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-gray-400">Real-time ADS-B</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {aircraft.map((flight) => (
          <div key={flight.icao_hex} className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 transition-all">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{getAircraftIcon(flight.category)}</span>
                <div>
                  <h4 className="font-medium text-white">{flight.callsign || flight.icao_hex}</h4>
                  <p className="text-xs text-gray-400">{flight.operator} • {flight.aircraft_type}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`text-xs font-medium px-2 py-1 rounded-full bg-opacity-20 ${getCategoryColor(flight.category)}`}>
                  {flight.category}
                </span>
                <div className="flex items-center space-x-1 text-xs text-gray-400">
                  <Radio className="w-3 h-3" />
                  <span>{flight.squawk_code}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs text-gray-400">
              <div className="flex items-center space-x-1">
                <MapPin className="w-3 h-3" />
                <span>{flight.current_position.latitude.toFixed(3)}, {flight.current_position.longitude.toFixed(3)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Navigation className="w-3 h-3" />
                <span>{flight.ground_speed_knots} kts • {flight.track_degrees}°</span>
              </div>
              <div>
                <span className="font-medium">Altitude:</span> {formatAltitude(flight.current_position.altitude_feet)}
              </div>
              <div>
                <span className="font-medium">V/S:</span> {flight.vertical_rate || 0} fpm
              </div>
              <div>
                <span className="font-medium">From:</span> {flight.origin_airport || 'N/A'}
              </div>
              <div>
                <span className="font-medium">To:</span> {flight.destination_airport || 'N/A'}
              </div>
            </div>

            {flight.category === 'MILITARY' && (
              <div className="mt-2 flex items-center space-x-2 text-xs">
                <AlertTriangle className="w-3 h-3 text-red-400" />
                <span className="text-red-400">Military aircraft detected - enhanced monitoring</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 text-xs text-gray-500 text-center">
        Tracking {aircraft.length} aircraft • Last update: {new Date().toLocaleTimeString()}
      </div>
    </div>
  );
}