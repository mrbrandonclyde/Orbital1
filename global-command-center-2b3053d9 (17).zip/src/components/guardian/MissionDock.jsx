import React from 'react';
import { useQuery } from '../lib/useQuery';
import { MissionDock as MissionDockEntity } from '@/api/entities';
import { Cpu, CheckCircle, XCircle, ArrowRight } from 'lucide-react';

export default function MissionDockComponent({ isVisible }) {
  const { data, loading } = useQuery(() => MissionDockEntity.list());

  if (!isVisible) return null;

  const dockData = data?.[0];

  return (
    <div className={`fixed top-0 right-0 h-full w-96 bg-black/90 backdrop-blur-lg border-l border-purple-500/30 shadow-2xl p-6 transition-transform duration-300 ${isVisible ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold orbital-gradient-text">Mission Dock</h2>
        <Cpu className="w-8 h-8 text-purple-400 animate-pulse" />
      </div>

      <div className="mb-6 p-4 bg-purple-500/10 rounded-lg border border-purple-500/20">
        <p className="text-sm text-purple-300 font-semibold mb-1">Central Brain: {dockData?.central_brain || 'Zyra Core'}</p>
        <p className="text-xs text-gray-400">Status: <span className="text-green-400">{dockData?.zyra_command_status || 'COORDINATING'}</span></p>
      </div>

      <h3 className="text-lg font-semibold text-white mb-4">Connected Verticals</h3>
      <div className="space-y-3">
        {loading && <p className="text-gray-400">Initializing vertical connections...</p>}
        {dockData?.connected_verticals?.map(vertical => (
          <div key={vertical.vertical_name} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
            <span className="text-sm text-white capitalize">{vertical.vertical_name}</span>
            <div className="flex items-center space-x-2">
              {vertical.connection_status === 'CONNECTED' ? (
                <>
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-green-400">CONNECTED</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-red-400" />
                  <span className="text-xs text-red-400">OFFLINE</span>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-gray-800/30 rounded-lg">
        <h4 className="text-sm text-gray-300 font-semibold mb-2">Public Narrative Engine</h4>
        <p className="text-xs text-gray-400">{dockData?.public_narrative}</p>
      </div>
    </div>
  );
}