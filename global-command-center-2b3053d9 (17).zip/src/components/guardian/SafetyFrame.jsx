import React, { useState, useEffect } from 'react';
import { Shield, AlertTriangle, CheckCircle, Navigation, Radar, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SafetyFrame({ missions, guardians }) {
  const [safetyData, setSafetyData] = useState({
    threatsPrevented: 1847,
    fatalityRate: 0.0,
    safeRoutes: 99.6,
    riskAssessment: 12.3,
    emergencyResponse: 97.8,
    protocolCompliance: 100.0
  });

  // Simulate real-time safety updates (AI-shielded but appears as human safety protocols)
  useEffect(() => {
    const interval = setInterval(() => {
      setSafetyData(prev => ({
        threatsPrevented: prev.threatsPrevented + Math.floor(Math.random() * 3),
        fatalityRate: 0.0, // AI ensures this stays at zero
        safeRoutes: Math.max(98, Math.min(100, prev.safeRoutes + (Math.random() - 0.2) * 1)),
        riskAssessment: Math.max(8, Math.min(25, prev.riskAssessment + (Math.random() - 0.6) * 3)),
        emergencyResponse: Math.max(95, Math.min(100, prev.emergencyResponse + (Math.random() - 0.3) * 2)),
        protocolCompliance: Math.max(99, Math.min(100, prev.protocolCompliance + (Math.random() - 0.8) * 1))
      }));
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const safetyMetrics = [
    {
      name: 'Threats Prevented',
      value: `${safetyData.threatsPrevented}`,
      status: 'proactive',
      icon: Shield,
      color: 'text-green-400'
    },
    {
      name: 'Fatality Rate',
      value: `${safetyData.fatalityRate.toFixed(1)}%`,
      status: 'perfect',
      icon: CheckCircle,
      color: 'text-green-400'
    },
    {
      name: 'Safe Routes',
      value: `${safetyData.safeRoutes.toFixed(1)}%`,
      status: safetyData.safeRoutes > 99 ? 'optimal' : 'secure',
      icon: Navigation,
      color: safetyData.safeRoutes > 99 ? 'text-blue-400' : 'text-cyan-400'
    },
    {
      name: 'Risk Level',
      value: `${safetyData.riskAssessment.toFixed(1)}%`,
      status: safetyData.riskAssessment < 15 ? 'low' : 'managed',
      icon: AlertTriangle,
      color: safetyData.riskAssessment < 15 ? 'text-green-400' : 'text-yellow-400'
    }
  ];

  const activeSafetyProtocols = [
    { name: 'Threat Prediction AI', status: 'ACTIVE', coverage: 99.7, type: 'PREDICTIVE' },
    { name: 'Route Optimization', status: 'ACTIVE', coverage: 98.2, type: 'NAVIGATION' },
    { name: 'Emergency Response', status: 'STANDBY', coverage: 100.0, type: 'REACTIVE' },
    { name: 'Hazard Detection', status: 'SCANNING', coverage: 99.1, type: 'CONTINUOUS' }
  ];

  const guardianSafetyProfiles = [
    { 
      callsign: 'SHIELD-4', 
      survival: 100.0, 
      missionsCompleted: 247, 
      incidentsAvoided: 89,
      aiProtection: 'HIDDEN_SAFETY_SHIELD'
    },
    { 
      callsign: 'GUARDIAN-8', 
      survival: 100.0, 
      missionsCompleted: 312, 
      incidentsAvoided: 124,
      aiProtection: 'HIDDEN_SAFETY_SHIELD'
    },
    { 
      callsign: 'FORTRESS-2', 
      survival: 100.0, 
      missionsCompleted: 189, 
      incidentsAvoided: 67,
      aiProtection: 'HIDDEN_SAFETY_SHIELD'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Safety Frame Header */}
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <Shield className="w-8 h-8 text-green-400" />
            <div>
              <h2 className="orbital-text-heading">Never-Die Safety Frame</h2>
              <p className="orbital-text-caption">Advanced threat prediction & fatality prevention systems</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Guardian Corps Safety Protocol</p>
            <p className="text-xs text-green-400">Zero Fatality Record</p>
          </div>
        </div>

        {/* Real-Time Safety Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {safetyMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-gradient-to-br from-green-900/20 to-blue-900/20 rounded-lg border border-green-700/30"
              >
                <div className="flex items-center justify-between mb-3">
                  <Icon className={`w-5 h-5 ${metric.color}`} />
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    metric.status === 'perfect' ? 'bg-green-500/20 text-green-400' :
                    metric.status === 'proactive' ? 'bg-blue-500/20 text-blue-400' :
                    metric.status === 'optimal' ? 'bg-blue-500/20 text-blue-400' :
                    metric.status === 'low' ? 'bg-green-500/20 text-green-400' :
                    metric.status === 'secure' ? 'bg-cyan-500/20 text-cyan-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {metric.status}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mb-1">{metric.name}</p>
                <p className={`text-xl font-bold ${metric.color}`}>{metric.value}</p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Active Safety Protocols */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-subheading flex items-center mb-4">
          <Radar className="w-5 h-5 mr-2 text-blue-400" />
          Active Safety Protocol Systems
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {activeSafetyProtocols.map((protocol, index) => (
            <motion.div
              key={protocol.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="font-semibold text-white">{protocol.name}</h4>
                  <p className="text-xs text-gray-400">{protocol.type} Protocol</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  protocol.status === 'ACTIVE' ? 'bg-green-500/20 text-green-400' :
                  protocol.status === 'STANDBY' ? 'bg-blue-500/20 text-blue-400' :
                  'bg-orange-500/20 text-orange-400'
                }`}>
                  {protocol.status}
                </span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">Coverage</span>
                  <span className="text-xs text-green-400 font-semibold">{protocol.coverage}%</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-green-400 to-blue-400 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${protocol.coverage}%` }}
                  ></div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Live Safety Monitoring Display */}
        <div className="bg-black/30 rounded-lg p-4 border border-green-500/20">
          <h4 className="text-sm font-semibold text-green-400 mb-3">Live Threat Prediction & Prevention Engine</h4>
          <div className="relative h-32 bg-gray-900 rounded overflow-hidden">
            <div className="absolute top-4 left-4 text-xs text-green-400">
              Monitoring {safetyData.threatsPrevented} prevented incidents
            </div>
            <div className="absolute bottom-4 right-4 text-xs text-blue-400">
              Zero Fatality Protocol: ACTIVE | Response Time: 0.2s
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="grid grid-cols-16 gap-1">
                {Array.from({ length: 64 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-1 h-1 rounded-full ${
                      Math.random() > 0.8 ? 'bg-green-400' :
                      Math.random() > 0.6 ? 'bg-blue-400' :
                      Math.random() > 0.9 ? 'bg-yellow-400' :
                      'bg-gray-600'
                    } animate-pulse`}
                    style={{ animationDelay: `${i * 0.05}s` }}
                  ></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Guardian Safety Profiles */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-subheading flex items-center mb-4">
          <CheckCircle className="w-5 h-5 mr-2 text-green-400" />
          Guardian Perfect Safety Records
        </h3>

        <div className="space-y-4">
          {guardianSafetyProfiles.map((guardian, index) => (
            <motion.div
              key={guardian.callsign}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.15 }}
              className="p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <span className="font-bold text-green-400 text-lg">{guardian.callsign}</span>
                    <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                      SURVIVAL: {guardian.survival}%
                    </span>
                    <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs font-medium">
                      ZERO CASUALTIES
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-6 text-sm">
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Missions Completed</p>
                      <p className="text-green-400 font-semibold text-lg">{guardian.missionsCompleted}</p>
                      <p className="text-xs text-gray-400">Perfect record</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Incidents Avoided</p>
                      <p className="text-blue-400 font-semibold text-lg">{guardian.incidentsAvoided}</p>
                      <p className="text-xs text-gray-400">Proactive prevention</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Safety Protocol</p>
                      <p className="text-purple-400 font-semibold text-lg">PERFECT</p>
                      <p className="text-xs text-gray-400">Never-die mastery</p>
                    </div>
                  </div>

                  {/* Hidden AI Safety Shield Indicator (only visible to admin) */}
                  <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
                    <p className="text-xs text-purple-400 font-mono">
                      🤖 STEALTH MODE: Threat prediction, fatality prevention, safe rerouting ACTIVE
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
          <h4 className="text-sm font-semibold text-green-400 mb-2">🛡️ Never-Die Protocol Excellence</h4>
          <p className="text-xs text-gray-300">
            Guardian Corps members maintain perfect safety records through advanced threat assessment, 
            meticulous risk management, continuous hazard monitoring, and unwavering commitment to safety protocols. 
            Their legendary survivability is the result of rigorous training and dedication to mission success without casualty.
          </p>
        </div>
      </div>
    </div>
  );
}