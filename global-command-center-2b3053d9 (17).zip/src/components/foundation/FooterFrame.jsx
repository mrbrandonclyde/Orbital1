import React from "react";

export default function FooterFrame() {
  return (
    <div className="mt-8 pt-4 border-t border-gray-800 text-xs text-gray-500">
      <div className="flex items-center justify-between">
        <span>Base44 Foundation • Phase 1</span>
        <span>Design System: Orbital UI</span>
      </div>
    </div>
  );
}