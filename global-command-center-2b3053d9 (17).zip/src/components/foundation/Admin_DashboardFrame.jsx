import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Shield, Server, Users } from "lucide-react";

export default function Admin_DashboardFrame() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" /> Backend Health
          </CardTitle>
        </CardHeader>
        <CardContent className="text-2xl font-bold text-white">OK</CardContent>
      </Card>
      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-400" /> Active Users
          </CardTitle>
        </CardHeader>
        <CardContent className="text-2xl font-bold text-white">—</CardContent>
      </Card>
      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Shield className="w-4 h-4 text-yellow-400" /> Security Status
          </CardTitle>
        </CardHeader>
        <CardContent className="text-2xl font-bold text-white">Nominal</CardContent>
      </Card>
    </div>
  );
}