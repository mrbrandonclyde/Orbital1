// Simplified GeoJSON for US states, containing only relevant states for the demo.
// Full data from: https://github.com/PublicaMundi/MappingAPI
export const usStatesGeoJson = {
  "type": "FeatureCollection",
  "features": [
    { "type": "Feature", "id": "US-CA", "properties": { "name": "California", "iso_3166_2": "US-CA" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-TX", "properties": { "name": "Texas", "iso_3166_2": "US-TX" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-NY", "properties": { "name": "New York", "iso_3166_2": "US-NY" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-FL", "properties": { "name": "Florida", "iso_3166_2": "US-FL" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-IL", "properties": { "name": "Illinois", "iso_3166_2": "US-IL" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-WA", "properties": { "name": "Washington", "iso_3166_2": "US-WA" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "US-DC", "properties": { "name": "District of Columbia", "iso_3166_2": "US-DC" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } }
  ]
};
// Note: Actual coordinate data is omitted for brevity but would be included in a real file.