import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Layers, Pencil, Copy, Trash2, BarChart3, Clock } from "lucide-react";

export default function FunnelCard({ funnel, stepCount = 0, onEdit, onClone, onDelete, onHistory }) {
  const statusClass =
    funnel.status === "ACTIVE"
      ? "bg-green-500/20 text-green-400"
      : funnel.status === "ARCHIVED"
      ? "bg-gray-500/20 text-gray-300"
      : "bg-yellow-500/20 text-yellow-400";

  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-3xl hover:border-indigo-500/30 transition-colors">
      <CardHeader className="pb-2">
        <CardTitle className="text-white flex items-center justify-between">
          <div className="flex items-center gap-2 truncate">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span className="truncate">{funnel.funnel_name}</span>
          </div>
          <Badge className={statusClass}>{funnel.status}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-gray-300">
        <div className="flex items-center justify-between mb-3">
          <span>Type: {funnel.type}</span>
          <span>Steps: {stepCount}</span>
        </div>

        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <div className="bg-gray-800/40 rounded-lg p-2">
            <div className="text-gray-400">Visitors</div>
            <div className="text-white font-semibold">—</div>
          </div>
          <div className="bg-gray-800/40 rounded-lg p-2">
            <div className="text-gray-400">Leads</div>
            <div className="text-white font-semibold">—</div>
          </div>
          <div className="bg-gray-800/40 rounded-lg p-2">
            <div className="text-gray-400">Conv%</div>
            <div className="text-white font-semibold">—</div>
          </div>
          <div className="bg-gray-800/40 rounded-lg p-2">
            <div className="text-gray-400">Revenue</div>
            <div className="text-white font-semibold">—</div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="text-xs text-gray-500 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{funnel.updated_date ? `Updated ${new Date(funnel.updated_date).toLocaleString()}` : "No activity yet"}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="secondary" onClick={() => onEdit(funnel)}>
              <Pencil className="w-4 h-4 mr-1" /> Edit
            </Button>
            <Button size="sm" variant="secondary" onClick={() => onClone(funnel)}>
              <Copy className="w-4 h-4 mr-1" /> Clone
            </Button>
            <Button size="sm" variant="secondary" onClick={() => onHistory(funnel)}>
              <BarChart3 className="w-4 h-4 mr-1" /> History
            </Button>
            <Button size="sm" variant="destructive" onClick={() => onDelete(funnel)}>
              <Trash2 className="w-4 h-4 mr-1" /> Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}