
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GripVertical, Trash, Type, Image as ImageIcon, MousePointer } from "lucide-react";

const DEFAULT_BLOCKS = [];

export default function PageEditor({ value, onChange }) {
  const [blocks, setBlocks] = React.useState(value?.blocks || DEFAULT_BLOCKS);

  React.useEffect(() => { onChange?.({ blocks }); }, [blocks, onChange]); // propagate

  const addBlock = (type) => {
    const base = { id: String(Date.now() + Math.random()), type, data: {} };
    if (type === "heading") base.data = { text: "Your headline", level: "h2" };
    if (type === "text") base.data = { text: "Your paragraph..." };
    if (type === "image") base.data = { url: "https://images.unsplash.com/photo-1522199755839-a2bacb67c546?w=800&q=60", alt: "Image" };
    if (type === "button") base.data = { label: "Click Me", href: "#" };
    setBlocks((prev) => [...prev, base]);
  };

  const updateBlock = (id, patch) => setBlocks((prev) => prev.map(b => b.id === id ? { ...b, data: { ...b.data, ...patch } } : b));
  const removeBlock = (id) => setBlocks((prev) => prev.filter(b => b.id !== id));

  const move = (from, to) => setBlocks(prev => {
    const arr = [...prev];
    const [r] = arr.splice(from, 1);
    arr.splice(to, 0, r);
    return arr;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      <Card className="bg-[#0A0D18]/60 border-gray-800 lg:col-span-1">
        <CardHeader className="pb-2"><CardTitle className="text-white">Blocks</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <Button onClick={() => addBlock("heading")} className="w-full bg-indigo-600 hover:bg-indigo-700"><Type className="w-4 h-4 mr-2" /> Heading</Button>
          <Button onClick={() => addBlock("text")} className="w-full bg-indigo-600 hover:bg-indigo-700">Paragraph</Button>
          <Button onClick={() => addBlock("image")} className="w-full bg-indigo-600 hover:bg-indigo-700"><ImageIcon className="w-4 h-4 mr-2" /> Image</Button>
          <Button onClick={() => addBlock("button")} className="w-full bg-indigo-600 hover:bg-indigo-700"><MousePointer className="w-4 h-4 mr-2" /> Button</Button>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 lg:col-span-3">
        <CardHeader className="pb-2"><CardTitle className="text-white">Canvas</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {blocks.map((b, idx) => (
            <div key={b.id} className="bg-[#0C0F19] border border-gray-700 rounded-md p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-4 h-4 text-gray-500" />
                  <span className="uppercase text-xs text-gray-400">{b.type}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => removeBlock(b.id)} className="text-red-400 hover:text-red-500">
                  <Trash className="w-4 h-4" />
                </Button>
              </div>

              {b.type === "heading" && (
                <div className="grid grid-cols-5 gap-2">
                  <div className="col-span-4">
                    <Input value={b.data.text} onChange={(e) => updateBlock(b.id, { text: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                  </div>
                  <Select value={b.data.level} onValueChange={(v) => updateBlock(b.id, { level: v })}>
                    <SelectTrigger className="bg-[#0C0F19] border-gray-700 text-gray-100"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["h1","h2","h3","h4"].map(l => <SelectItem key={l} value={l}>{l.toUpperCase()}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {b.type === "text" && (
                <Textarea value={b.data.text} onChange={(e) => updateBlock(b.id, { text: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[80px]" />
              )}

              {b.type === "image" && (
                <div className="grid grid-cols-5 gap-2">
                  <div className="col-span-4">
                    <Input value={b.data.url} onChange={(e) => updateBlock(b.id, { url: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                  </div>
                  <Input value={b.data.alt} onChange={(e) => updateBlock(b.id, { alt: e.target.value })} placeholder="alt" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                </div>
              )}

              {b.type === "button" && (
                <div className="grid grid-cols-2 gap-2">
                  <Input value={b.data.label} onChange={(e) => updateBlock(b.id, { label: e.target.value })} placeholder="Label" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                  <Input value={b.data.href} onChange={(e) => updateBlock(b.id, { href: e.target.value })} placeholder="URL" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                </div>
              )}
            </div>
          ))}
          {blocks.length === 0 && <div className="text-sm text-gray-500">Add blocks from the left to start building your page.</div>}
        </CardContent>
      </Card>
    </div>
  );
}
