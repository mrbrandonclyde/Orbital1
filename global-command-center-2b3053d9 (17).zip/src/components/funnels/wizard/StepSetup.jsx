import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function StepSetup({ form, setForm }) {
  return (
    <div className="space-y-4">
      <div>
        <Label className="text-xs text-gray-400">Funnel Name</Label>
        <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" placeholder="My New Funnel" />
      </div>
      <div>
        <Label className="text-xs text-gray-400">Tags (comma separated)</Label>
        <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" placeholder="launch, q1, paid" />
      </div>
      <div>
        <Label className="text-xs text-gray-400">Campaign</Label>
        <Input value={form.campaign} onChange={(e) => setForm({ ...form, campaign: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" placeholder="Summer-Launch" />
      </div>
      <div>
        <Label className="text-xs text-gray-400">Description</Label>
        <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[80px]" placeholder="Optional notes…" />
      </div>
      <div className="flex items-center gap-3">
        <Switch checked={form.is_private} onCheckedChange={(v) => setForm({ ...form, is_private: v })} id="privacy" />
        <Label htmlFor="privacy" className="text-sm text-gray-300">Private (restrict public access)</Label>
      </div>
    </div>
  );
}