import React from "react";
import { Layers, BarChart3, Users, Settings, FileText, Plus, Copy, Trash2, Edit } from "lucide-react";

const tabs = [
  { key: "overview", label: "Overview", icon: FileText },
  { key: "steps", label: "Steps", icon: Layers },
  { key: "stats", label: "Stats", icon: BarChart3 },
  { key: "contacts", label: "Contacts", icon: Users },
  { key: "settings", label: "Settings", icon: Settings }
];

export default function FunnelSubSidebar({
  funnel,
  steps,
  activeStepId,
  currentTab,
  onChangeTab,
  onSelectStep,
  onAddStep,
  onCloneStep,
  onDeleteStep
}) {
  return (
    <aside className="w-full lg:w-72 bg-[#0A0D18]/80 border border-gray-800 rounded-xl h-full flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <p className="text-xs uppercase text-gray-500 mb-1">Funnel</p>
        <h3 className="text-white font-semibold truncate">{funnel?.funnel_name || "Funnel"}</h3>
      </div>

      <nav className="px-2 py-3 space-y-1 border-b border-gray-800">
        {tabs.map(t => {
          const Icon = t.icon;
          const active = currentTab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => onChangeTab(t.key)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition ${
                active
                  ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/30"
                  : "text-gray-300 hover:bg-gray-800/40"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 flex items-center justify-between">
        <span className="text-xs uppercase text-gray-500">Funnel Steps</span>
        <button
          onClick={onAddStep}
          className="text-xs px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1"
        >
          <Plus className="w-3 h-3" /> New
        </button>
      </div>

      <div className="px-2 pb-3 overflow-y-auto sidebar-scroll">
        {steps.map((s) => {
          const active = String(s.id) === String(activeStepId);
          return (
            <div
              key={s.id}
              className={`group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer mb-1 text-sm ${
                active ? "bg-gray-800/60 text-white" : "text-gray-300 hover:bg-gray-800/40"
              }`}
              onClick={() => onSelectStep(s.id)}
            >
              <div className="truncate">
                <div className="truncate">{s.step_name}</div>
                <div className="text-[11px] text-gray-500 truncate">{s.step_type}</div>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition flex items-center gap-1">
                <button
                  onClick={(e) => { e.stopPropagation(); onCloneStep(s); }}
                  className="p-1 rounded hover:bg-gray-700"
                  title="Clone"
                >
                  <Copy className="w-3 h-3 text-gray-400" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); onDeleteStep(s); }}
                  className="p-1 rounded hover:bg-gray-700"
                  title="Delete"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                </button>
              </div>
            </div>
          );
        })}
        {steps.length === 0 && (
          <div className="text-xs text-gray-500 px-3 py-6">No steps yet. Click “New” to add your first step.</div>
        )}
      </div>
    </aside>
  );
}