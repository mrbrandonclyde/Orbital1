import React from "react";
import { InvokeLLM } from "@/api/integrations";
import { Funnel } from "@/api/entities";
import { FunnelStep } from "@/api/entities";
import { GeneratedAsset } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Wand2, Rocket } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function GeneratorForm() {
  const [type, setType] = React.useState("OPTIN");
  const [product, setProduct] = React.useState("");
  const [audience, setAudience] = React.useState("");
  const [goal, setGoal] = React.useState("Collect Leads");
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState(null);
  const [createdFunnel, setCreatedFunnel] = React.useState(null);

  const generate = async () => {
    setLoading(true);
    setResult(null);
    setCreatedFunnel(null);

    const responseSchema = {
      type: "object",
      properties: {
        funnel_name: { type: "string" },
        description: { type: "string" },
        steps: {
          type: "array",
          items: {
            type: "object",
            properties: {
              step_name: { type: "string" },
              step_type: { type: "string", enum: ["OPTIN","SALES","WEBINAR","MEMBERSHIP","CHECKOUT","THANK_YOU","CUSTOM"] },
              path_slug: { type: "string" },
              content_hint: { type: "string" }
            },
            required: ["step_name","step_type","path_slug"]
          }
        }
      },
      required: ["funnel_name", "steps"]
    };

    const prompt = `
Act as a senior funnel strategist.
Create a ${type} funnel to "${goal}" for the product/service:
"${product}"

Target audience: ${audience || "general"}

Return concise JSON with steps (2-5 steps). Use SEO-friendly path slugs.
`;

    const ai = await InvokeLLM({
      prompt,
      add_context_from_internet: false,
      response_json_schema: responseSchema
    });

    setResult(ai);

    const me = await User.me().catch(() => null);
    const funnelPayload = {
      funnel_name: ai.funnel_name || `${type} Funnel`,
      type,
      status: "DRAFT",
      description: ai.description || ""
    };
    const nf = await Funnel.create(funnelPayload);

    let order = 100;
    const createdSteps = [];
    for (const s of (ai.steps || [])) {
      const created = await FunnelStep.create({
        funnel_id: nf.id,
        step_name: s.step_name,
        step_type: s.step_type,
        order_index: order,
        path_slug: s.path_slug,
        content_schema: { hint: s.content_hint || "" }
      });
      order += 100;
      createdSteps.push(created);
    }
    if (createdSteps.length) {
      await Funnel.update(nf.id, { default_step_id: createdSteps[0].id });
    }
    setCreatedFunnel(nf);

    await GeneratedAsset.create({
      user_id: me?.id || "anonymous",
      asset_type: "funnel",
      title: ai.funnel_name || `${type} Funnel`,
      prompt,
      output: ai,
      related_funnel_id: nf.id,
      tags: [type, goal]
    });

    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <div className="text-xs text-gray-400 mb-1">Funnel Type</div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-700 text-gray-200"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="OPTIN">OPTIN</SelectItem>
              <SelectItem value="SALES">SALES</SelectItem>
              <SelectItem value="WEBINAR">WEBINAR</SelectItem>
              <SelectItem value="MEMBERSHIP">MEMBERSHIP</SelectItem>
              <SelectItem value="CHECKOUT">CHECKOUT</SelectItem>
              <SelectItem value="THANK_YOU">THANK_YOU</SelectItem>
              <SelectItem value="MISC">MISC</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <div className="text-xs text-gray-400 mb-1">Primary Goal</div>
          <Input value={goal} onChange={(e)=>setGoal(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-200" placeholder="e.g., Collect Leads, Sell Product" />
        </div>
        <div>
          <div className="text-xs text-gray-400 mb-1">Target Audience</div>
          <Input value={audience} onChange={(e)=>setAudience(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-200" placeholder="e.g., busy founders, designers" />
        </div>
      </div>

      <div>
        <div className="text-xs text-gray-400 mb-1">Product / Offer Description</div>
        <Textarea value={product} onChange={(e)=>setProduct(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-200 h-28" placeholder="Describe your product, pains, benefits, key objections..." />
      </div>

      <div className="flex items-center gap-3">
        <Button onClick={generate} disabled={loading} className="bg-indigo-600 hover:bg-indigo-700">
          <Wand2 className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          {loading ? "Generating…" : "Generate Funnel"}
        </Button>
        {createdFunnel && (
          <Button onClick={()=>{ window.location.href = createPageUrl(`FunnelEditor?funnel=${createdFunnel.id}`); }} className="bg-purple-600 hover:bg-purple-700">
            <Rocket className="w-4 h-4 mr-2" /> Open in Editor
          </Button>
        )}
      </div>

      {result && (
        <div className="mt-4 p-4 border border-gray-800 rounded-xl bg-[#0A0D18]/60">
          <div className="text-white font-semibold mb-2">AI Plan</div>
          <pre className="text-xs text-gray-300 whitespace-pre-wrap">{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}