import React, { useState, useEffect } from 'react';
import { SecurityAlert } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function AlertForm({ alert, onSave, onCancel }) {
  const [currentAlert, setCurrentAlert] = useState({
    title: '',
    description: '',
    priority: 'MEDIUM',
    alert_status: 'ACTIVE',
    sector_id: ''
  });

  useEffect(() => {
    if (alert) {
      setCurrentAlert(alert);
    }
  }, [alert]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentAlert(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setCurrentAlert(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(currentAlert);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-6 bg-[#0A0D18]/80 rounded-xl border border-gray-700">
      <div className="space-y-2">
        <Label htmlFor="title" className="text-white">Alert Title</Label>
        <Input id="title" name="title" value={currentAlert.title} onChange={handleChange} placeholder="e.g., Unauthorized Access Attempt" className="bg-[#0C0F19] border-gray-600" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="description" className="text-white">Description</Label>
        <Textarea id="description" name="description" value={currentAlert.description} onChange={handleChange} placeholder="Provide a detailed description of the alert..." className="bg-[#0C0F19] border-gray-600"/>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="priority" className="text-white">Priority</Label>
          <Select name="priority" value={currentAlert.priority} onValueChange={(value) => handleSelectChange('priority', value)}>
            <SelectTrigger id="priority" className="bg-[#0C0F19] border-gray-600">
              <SelectValue placeholder="Select priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="LOW">Low</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="URGENT">Urgent</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="alert_status" className="text-white">Status</Label>
          <Select name="alert_status" value={currentAlert.alert_status} onValueChange={(value) => handleSelectChange('alert_status', value)}>
            <SelectTrigger id="alert_status" className="bg-[#0C0F19] border-gray-600">
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ACTIVE">Active</SelectItem>
              <SelectItem value="ACKNOWLEDGED">Acknowledged</SelectItem>
              <SelectItem value="RESOLVED">Resolved</SelectItem>
              <SelectItem value="CLOSED">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" className="orbital-button-primary">Save Alert</Button>
      </div>
    </form>
  );
}