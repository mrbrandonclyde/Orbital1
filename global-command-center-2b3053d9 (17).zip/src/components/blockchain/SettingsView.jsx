import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Bell, Globe } from 'lucide-react';

export default function SettingsView() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white">Settings</h1>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center"><Shield className="mr-2 text-red-400"/> Security</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
                <Label htmlFor="mfa" className="text-gray-300">Enable Multi-Factor Authentication</Label>
                <Switch id="mfa" />
            </div>
            <div className="flex items-center justify-between">
                <Label htmlFor="phishing" className="text-gray-300">Phishing Protection</Label>
                <Switch id="phishing" defaultChecked />
            </div>
            <div>
                <Label htmlFor="password">Change Password</Label>
                <Input id="password" type="password" placeholder="New Password" className="mt-2 bg-[#0C0F19] border-gray-600"/>
            </div>
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center"><Globe className="mr-2 text-blue-400"/> Network</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="node-select">Preferred Network Node</Label>
                <Select>
                    <SelectTrigger className="w-full mt-2 bg-[#0C0F19] border-gray-600">
                        <SelectValue placeholder="Automatic (Recommended)" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="auto">Automatic (Recommended)</SelectItem>
                        <SelectItem value="us-east">US East (Virginia)</SelectItem>
                        <SelectItem value="eu-west">EU West (Ireland)</SelectItem>
                        <SelectItem value="ap-south">Asia Pacific (Singapore)</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </CardContent>
      </Card>
       <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center"><Bell className="mr-2 text-yellow-400"/> Notifications</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
                <Label htmlFor="tx-success" className="text-gray-300">Successful Transactions</Label>
                <Switch id="tx-success" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
                <Label htmlFor="tx-failed" className="text-gray-300">Failed Transactions</Label>
                <Switch id="tx-failed" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
                <Label htmlFor="gov-proposals" className="text-gray-300">New Governance Proposals</Label>
                <Switch id="gov-proposals" defaultChecked />
            </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-end">
        <Button className="orbital-button-primary w-48">Save Changes</Button>
      </div>
    </div>
  );
}