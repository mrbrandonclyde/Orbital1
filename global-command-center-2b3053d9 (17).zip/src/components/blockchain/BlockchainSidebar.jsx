import React, { useState } from 'react';
import { 
  Home, Wallet, ArrowRightLeft, FileText, Cpu, Gavel, Settings, HelpCircle, ChevronDown, ChevronRight, Blocks
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const iconMap = {
  home: Home,
  wallet: Wallet,
  transactions: ArrowRightLeft,
  contract: FileText,
  miner: Cpu,
  gavel: Gavel,
  gear: Settings,
  "help-circle": HelpCircle
};

const menuConfig = {
  "sidebarMenu": {
    "items": [
      { "label": "Dashboard", "icon": "home", "route": "dashboard" },
      { "label": "Wallet", "icon": "wallet", "route": "wallet" },
      { "label": "Transactions", "icon": "transactions", "route": "transactions" },
      { "label": "Smart Contracts", "icon": "contract", "route": "contracts" },
      { "label": "Mining/Validation", "icon": "miner", "route": "mining" },
      { "label": "Governance", "icon": "gavel", "route": "governance" },
      { "label": "Settings", "icon": "gear", "route": "settings" },
      { "label": "Help & Support", "icon": "help-circle", "route": "help" }
    ]
  }
};

const SidebarItem = ({ item, activeView, setActiveView }) => {
  const Icon = iconMap[item.icon];
  const isActive = activeView === item.route;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
    >
      <button
        onClick={() => setActiveView(item.route)}
        className={`w-full flex items-center p-3 rounded-lg text-left text-sm font-medium transition-all duration-200 ${
          isActive
            ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border border-cyan-500/30 shadow-lg shadow-cyan-500/10'
            : 'text-gray-300 hover:bg-gray-800/60 hover:text-white'
        }`}
      >
        <Icon className="w-5 h-5 mr-3 flex-shrink-0" />
        <span className="flex-grow">{item.label}</span>
      </button>
    </motion.div>
  );
};


export default function BlockchainSidebar({ activeView, setActiveView }) {
  return (
    <aside className="w-64 flex-shrink-0 bg-[#0A0D18]/80 backdrop-blur-md p-4 flex flex-col border-r border-gray-800">
      <div className="flex items-center space-x-2 p-3 mb-6">
        <div className="p-2 bg-purple-500/20 rounded-lg">
          <Blocks className="w-6 h-6 text-purple-400" />
        </div>
        <h2 className="text-lg font-bold text-white tracking-wider">Blockchain</h2>
      </div>
      <div className="flex-grow">
        <nav className="space-y-2">
          {menuConfig.sidebarMenu.items.map(item => (
            <SidebarItem
              key={item.label}
              item={item}
              activeView={activeView}
              setActiveView={setActiveView}
            />
          ))}
        </nav>
      </div>
      <div className="mt-auto pt-4 border-t border-gray-800">
        <div className="text-center text-xs text-gray-500">
          <p>Global Command Chain</p>
          <p>v1.0.0 - Synced</p>
        </div>
      </div>
    </aside>
  );
}