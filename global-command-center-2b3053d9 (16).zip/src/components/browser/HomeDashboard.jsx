
import React from "react";
import SearchAndCopilot from "./SearchAndCopilot";
import TimelinePanel from "./TimelinePanel";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Shield } from "lucide-react";
import OrbitalGlobe from "@/components/globe/OrbitalGlobe";

export default function HomeDashboard({ settings }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 space-y-6">
          <SearchAndCopilot />
          <TimelinePanel />
          <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white text-base flex items-center gap-2">
                <Shield className="w-5 h-5 text-cyan-400" />
                Vault Status
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-400">
              Proton Layer: enabled • TLS 1.3+ • PQC-ready • Zero-Trust enforced
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-6">
          <OrbitalGlobe />
        </div>
      </div>
    </div>
  );
}
