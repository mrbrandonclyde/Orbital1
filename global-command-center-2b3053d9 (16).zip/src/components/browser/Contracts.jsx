
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { FileSignature, Wallet, Banknote, Link as LinkIcon, Shield, Loader2 } from "lucide-react";
import { createPageUrl } from "@/utils";
import { AuditTrail } from "@/api/entities";
import { User } from "@/api/entities"; // Assuming User entity is located here for User.me()
import { toast } from "@/components/common/Toast";

export default function Contracts({ enabled }) {
  const [form, setForm] = React.useState({
    contract_name: "",
    counterparty: "",
    recipient_wallet: "",
    amount_usd: "",
    terms: "",
  });
  const [generating, setGenerating] = React.useState(false);
  const [preview, setPreview] = React.useState(null);
  const [step, setStep] = React.useState(1); // 1=Fill, 2=Generate, 3=Review

  if (!enabled) {
    return (
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader>
          <CardTitle className="text-white text-base">AI Contracts</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-400 text-sm">
          Contracts are disabled in Settings. Enable “AI Contracts” in module toggles to proceed.
        </CardContent>
      </Card>
    );
  }

  const update = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const generateContract = async () => {
    setGenerating(true);
    toast.info("Generating contract draft…");
    // Simulate AI generation output
    const now = new Date().toISOString();
    const id = `CTR-${Math.random().toString(36).slice(2, 8).toUpperCase()}-${Date.now().toString().slice(-4)}`;
    const doc = {
      contract_id: id,
      generated_at: now,
      title: form.contract_name || "Untitled Contract",
      parties: {
        principal: "Orbital Command",
        counterparty: form.counterparty || "—",
      },
      settlement: {
        chain: "ORB-LEDGER (placeholder)",
        recipient_wallet: form.recipient_wallet || "—",
        currency: "USD",
        amount: Number(form.amount_usd || 0),
      },
      terms: form.terms || "Standard terms (placeholder).",
      signatures: [
        { party: "Orbital Command", status: "pending" },
        { party: form.counterparty || "Counterparty", status: "pending" },
      ],
      metadata: {
        proton_encryption: true,
        pqc_ready: true,
        zero_trust: true,
      }
    };
    // Small delay to show activity
    setTimeout(async () => {
      setPreview(doc);
      setGenerating(false);
      setStep(3);
      toast.success("Contract draft ready", { description: doc.contract_id });

      // Log to AuditTrail
      let me = null;
      try {
        me = await User.me();
      } catch (error) {
        console.error("Failed to fetch user for audit trail:", error);
      }
      await AuditTrail.create({
        entity_type: "AIContract",
        entity_id: doc.contract_id,
        action: "CREATE",
        action_timestamp: new Date().toISOString(),
        user_id: me?.id || "system",
        changes_made: {
          title: doc.title,
          counterparty: doc.parties.counterparty,
          amount_usd: doc.settlement.amount,
          recipient_wallet: doc.settlement.recipient_wallet,
          proton_encryption: true,
          pqc_ready: true
        },
        security_classification: "CONFIDENTIAL",
        risk_score: 5
      });
    }, 400);
  };

  const openBank = () => {
    toast.info("Opening Orbital Bank for settlement…");
    window.location.href = createPageUrl("Bank");
  };

  const openCommerce = () => {
    window.location.href = createPageUrl("Commerce");
  };

  return (
    <div className="space-y-6">
      {/* Stepper */}
      <div className="flex items-center gap-3 text-xs">
        <Badge className={`${step>=1?"bg-[#0D1BFF] text-white":"bg-gray-700/40 text-gray-300"}`}>1. Fill</Badge>
        <div className="h-px w-6 bg-gray-700" />
        <Badge className={`${step>=2?"bg-[#0D1BFF] text-white":"bg-gray-700/40 text-gray-300"}`}>2. Generate</Badge>
        <div className="h-px w-6 bg-gray-700" />
        <Badge className={`${step>=3?"bg-[#0D1BFF] text-white":"bg-gray-700/40 text-gray-300"}`}>3. Review/Settle</Badge>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <FileSignature className="w-5 h-5 text-cyan-400" />
            Smart Contract Generator
            <Badge className="ml-2 bg-purple-500/20 text-purple-300">Phase 1 Scaffold</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Contract Name</Label>
              <Input
                value={form.contract_name}
                onChange={e => update("contract_name", e.target.value)}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="e.g., Service Agreement"
              />
            </div>
            <div>
              <Label className="text-gray-300">Counterparty</Label>
              <Input
                value={form.counterparty}
                onChange={e => update("counterparty", e.target.value)}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="e.g., Acme Corp"
              />
            </div>
            <div>
              <Label className="text-gray-300 flex items-center gap-2">
                <Wallet className="w-4 h-4 text-amber-400" /> Recipient Wallet
              </Label>
              <Input
                value={form.recipient_wallet}
                onChange={e => update("recipient_wallet", e.target.value)}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100 font-mono"
                placeholder="0x..."
              />
            </div>
            <div>
              <Label className="text-gray-300 flex items-center gap-2">
                <Banknote className="w-4 h-4 text-green-400" /> Amount (USD)
              </Label>
              <Input
                type="number"
                value={form.amount_usd}
                onChange={e => update("amount_usd", e.target.value)}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="1000"
              />
            </div>
            <div className="md:col-span-2">
              <Label className="text-gray-300">Terms</Label>
              <Textarea
                value={form.terms}
                onChange={e => update("terms", e.target.value)}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[100px]"
                placeholder="Outline the core terms and conditions..."
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button onClick={() => { setStep(2); generateContract(); }} disabled={generating} className="bg-[#0D1BFF] hover:bg-[#0B18DE]">
              {generating ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating…</> : "Generate Contract"}
            </Button>
            <Button variant="outline" onClick={openBank} className="border-gray-700 text-gray-300">
              <LinkIcon className="w-4 h-4 mr-2" /> Settle via Orbital Bank
            </Button>
            <Button variant="outline" onClick={openCommerce} className="border-gray-700 text-gray-300">
              <LinkIcon className="w-4 h-4 mr-2" /> Open Commerce
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            Proton + PQC Security
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-gray-400">
          All generated contracts follow Proton Layer defaults (E2E encryption, TLS 1.3+, PQC-ready keys, Zero-Trust).
        </CardContent>
      </Card>

      {preview && (
        <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
          <CardHeader>
            <CardTitle className="text-white text-base">Contract Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="text-xs bg-[#0C0F19] border border-gray-800 rounded-lg p-3 overflow-auto text-gray-200">
{JSON.stringify(preview, null, 2)}
            </pre>
            <div className="mt-3 flex gap-3">
              <Button onClick={openBank} className="bg-emerald-600 hover:bg-emerald-700">
                Proceed to Settlement
              </Button>
              <Button variant="outline" onClick={()=> setStep(1)} className="border-gray-700 text-gray-300">Edit Details</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
