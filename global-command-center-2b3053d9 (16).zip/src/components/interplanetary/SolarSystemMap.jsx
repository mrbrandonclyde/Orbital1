import React from 'react';
import { Sun, Globe, Moon, Rocket, Shield } from 'lucide-react';

const missionIcons = {
  planetary_defense_protocol: Shield,
  colonization_protocol: Rocket,
  interplanetary_logistics: Rocket,
  space_continuity_protocol: Shield,
};

const missionColors = {
  planetary_defense_protocol: 'text-red-400',
  colonization_protocol: 'text-green-400',
  interplanetary_logistics: 'text-blue-400',
  space_continuity_protocol: 'text-purple-400',
};

const CelestialBody = ({ name, icon, size, position, children, missions = [], onSelectMission }) => {
  const Icon = icon;
  return (
    <div className="absolute" style={{ ...position, width: size, height: size }}>
      <div className="relative w-full h-full flex items-center justify-center">
        <div className={`w-full h-full rounded-full flex items-center justify-center bg-gray-800/50 border border-gray-700`}>
          <Icon className="w-1/2 h-1/2 text-gray-400" />
        </div>
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs text-white font-semibold">{name}</div>
        {/* Render missions associated with this body */}
        <div className="absolute top-0 left-0 w-full h-full">
          {missions.map((mission, index) => {
            const MissionIcon = missionIcons[mission.mission_type] || Rocket;
            const angle = (360 / missions.length) * index;
            const radius = size / 2 + 20;
            return (
              <div 
                key={mission.id} 
                className="absolute w-8 h-8"
                style={{ 
                  top: '50%', 
                  left: '50%',
                  transform: `translate(-50%, -50%) rotate(${angle}deg) translate(${radius}px) rotate(-${angle}deg)` 
                }}
                onClick={() => onSelectMission(mission)}
              >
                <MissionIcon className={`w-full h-full ${missionColors[mission.mission_type]} cursor-pointer hover:scale-125 transition-transform`} />
              </div>
            );
          })}
        </div>
      </div>
      {children}
    </div>
  );
};

export default function SolarSystemMap({ missions, onSelectMission }) {
  const getMissionsForDomain = (domain) => {
    return missions.filter(m => m.target_domain === domain);
  };

  return (
    <div className="relative w-full h-[600px] bg-[#0A0D18]/50 border border-gray-800 rounded-xl overflow-hidden p-4">
      {/* Background grid */}
      <svg width="100%" height="100%" className="absolute top-0 left-0">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(55, 65, 81, 0.2)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
      
      {/* Orbital Paths */}
      <div className="absolute top-1/2 left-1/2 w-[250px] h-[250px] -translate-x-1/2 -translate-y-1/2 border border-dashed border-gray-700 rounded-full"></div>
      <div className="absolute top-1/2 left-1/2 w-[450px] h-[450px] -translate-x-1/2 -translate-y-1/2 border border-dashed border-gray-700 rounded-full"></div>
      <div className="absolute top-1/2 left-1/2 w-[650px] h-[650px] -translate-x-1/2 -translate-y-1/2 border border-dashed border-gray-700 rounded-full"></div>


      <CelestialBody name="Sun" icon={Sun} size={80} position={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }} />

      <CelestialBody name="Earth" icon={Globe} size={60} position={{ top: '50%', left: 'calc(50% + 125px)', transform: 'translate(-50%, -50%)' }} missions={getMissionsForDomain('earth')} onSelectMission={onSelectMission}>
        <CelestialBody name="Moon" icon={Moon} size={30} position={{ top: '50%', left: 'calc(100% + 15px)', transform: 'translate(-50%, -50%)' }} missions={getMissionsForDomain('moon')} onSelectMission={onSelectMission} />
      </CelestialBody>
      
      <CelestialBody name="Mars" icon={Globe} size={50} position={{ top: 'calc(50% - 225px)', left: '50%', transform: 'translate(-50%, -50%)' }} missions={getMissionsForDomain('mars')} onSelectMission={onSelectMission} />
      
      <div className="absolute top-4 right-4 text-xs text-gray-400 bg-black/50 p-2 rounded">INTERPLANETARY OPERATIONS VIEW</div>
    </div>
  );
}