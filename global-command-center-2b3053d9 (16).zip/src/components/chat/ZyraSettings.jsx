import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function ZyraSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">System Configuration</h3>
        <p className="text-gray-400">Fine-tune Zyra’s response behavior and enabled modules.</p>
      </div>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Response Behavior</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <Label htmlFor="response-speed" className="text-gray-300">Response Speed</Label>
            <Select defaultValue="fast">
              <SelectTrigger id="response-speed" className="w-[200px] bg-gray-800 border-gray-600 text-gray-200">
                <SelectValue placeholder="Select speed" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="instant">Instant</SelectItem>
                <SelectItem value="fast">Fast</SelectItem>
                <SelectItem value="thoughtful">Thoughtful</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="detail-level" className="text-gray-300">Detail Level</Label>
            <Select defaultValue="detailed">
              <SelectTrigger id="detail-level" className="w-[200px] bg-gray-800 border-gray-600 text-gray-200">
                <SelectValue placeholder="Select detail level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="concise">Concise</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="comprehensive">Comprehensive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Active Modules</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="proactive-mode" className="text-gray-300">Proactive Suggestions</Label>
            <Switch id="proactive-mode" defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="auto-analysis" className="text-gray-300">Automated Data Analysis</Label>
            <Switch id="auto-analysis" defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="threat-monitoring" className="text-gray-300">Real-time Threat Monitoring</Label>
            <Switch id="threat-monitoring" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}