import React from 'react';
import { Users, MessageSquare, Globe, ArrowRightLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const CommunicationChannel = ({ source, target, status, messages, color }) => (
  <div className="bg-gray-800/50 p-4 rounded-lg">
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center space-x-2">
        <span className="text-white font-medium">{source}</span>
        <ArrowRightLeft className="w-4 h-4 text-gray-400" />
        <span className="text-white font-medium">{target}</span>
      </div>
      <span className={`text-xs px-2 py-1 rounded-full ${color}`}>{status}</span>
    </div>
    <p className="text-sm text-gray-400">{messages} active conversations</p>
  </div>
);

const SpeciesCoordination = ({ species, coordination_level, survival_strategies }) => (
  <div className="bg-gray-800/30 p-4 rounded-lg">
    <div className="flex justify-between items-center mb-2">
      <span className="text-white font-semibold">{species}</span>
      <span className={`text-sm px-2 py-1 rounded-full ${
        coordination_level >= 90 ? 'bg-green-500/20 text-green-400' :
        coordination_level >= 70 ? 'bg-blue-500/20 text-blue-400' :
        'bg-yellow-500/20 text-yellow-400'
      }`}>
        {coordination_level}% Sync
      </span>
    </div>
    <p className="text-xs text-gray-400">Strategies: {survival_strategies}</p>
  </div>
);

export default function MediationFrame() {
  const communicationChannels = [
    { source: 'Guardian Corps', target: 'AI Systems', status: 'Active', messages: 847, color: 'bg-green-500/20 text-green-400' },
    { source: 'Earth Command', target: 'Mars Colony', status: 'Stable', messages: 234, color: 'bg-blue-500/20 text-blue-400' },
    { source: 'Bio-Labs', target: 'Field Teams', status: 'Encrypted', messages: 156, color: 'bg-purple-500/20 text-purple-400' },
    { source: 'Orbital Stations', target: 'Deep Space', status: 'Quantum', messages: 89, color: 'bg-cyan-500/20 text-cyan-400' }
  ];

  const speciesData = [
    { species: 'Human-AI Partnership', coordination_level: 97, survival_strategies: 'Neural symbiosis, cognitive enhancement' },
    { species: 'Enhanced Guardians', coordination_level: 94, survival_strategies: 'Bio-augmentation, immune optimization' },
    { species: 'Colony Populations', coordination_level: 89, survival_strategies: 'Genetic preservation, adaptation protocols' },
    { species: 'Deep Space Explorers', coordination_level: 91, survival_strategies: 'Extended hibernation, radiation shielding' }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <MessageSquare className="w-5 h-5 mr-3 text-cyan-400" />
          Cross-Species Communication Channels
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {communicationChannels.map((channel, index) => (
            <CommunicationChannel key={index} {...channel} />
          ))}
        </div>
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Users className="w-5 h-5 mr-3 text-purple-400" />
          Species Coordination Matrix
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {speciesData.map((species, index) => (
            <SpeciesCoordination key={index} {...species} />
          ))}
        </div>
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Globe className="w-5 h-5 mr-3 text-green-400" />
          Shared Survival Strategies
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Universal Life Support Protocols</span>
            <span className="text-green-400 font-semibold">Implemented</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Cross-Platform Emergency Response</span>
            <span className="text-blue-400 font-semibold">Active</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
            <span className="text-white">Unified Command Structure</span>
            <span className="text-purple-400 font-semibold">Coordinating</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}