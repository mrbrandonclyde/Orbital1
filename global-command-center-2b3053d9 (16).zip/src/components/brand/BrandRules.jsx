
import React from "react";

export const BrandRules = {
  name: "Orbital",
  colors: {
    // Updated to Orbital spec:
    primary: "#0D1BFF",   // Orbital Blue
    secondary: "#6A00FF", // Galactic Purple
    accent: "#FFD700",    // Proton Gold
    background: "#020409",
    surface: "#0A0D18",
    border: "rgba(55,65,81,0.6)"
  },
  typography: {
    // Add Poppins to the stack + explicit scale
    fontFamily: "Inter, Poppins, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, sans-serif",
    radius: 12,
    scale: {
      heading: "24px",
      body: "16px",
      caption: "12px"
    }
  },
  icons: {
    style: "lucide"
  }
};

/**
 * Apply brand tokens to CSS variables for global usage.
 * Safe to call multiple times (idempotent).
 */
export function applyBrandRules(tokens = BrandRules) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--orbital-primary", tokens.colors.primary);
  root.style.setProperty("--orbital-secondary", tokens.colors.secondary);
  root.style.setProperty("--orbital-accent", tokens.colors.accent);
  root.style.setProperty("--orbital-bg", tokens.colors.background);
  root.style.setProperty("--orbital-surface", tokens.colors.surface);
  root.style.setProperty("--orbital-border", tokens.colors.border);
  root.style.setProperty("--orbital-radius", `${tokens.typography.radius}px`);
  // Typography scale
  root.style.setProperty("--orbital-heading", tokens.typography.scale?.heading || "24px");
  root.style.setProperty("--orbital-body", tokens.typography.scale?.body || "16px");
  root.style.setProperty("--orbital-caption", tokens.typography.scale?.caption || "12px");
  document.body.style.fontFamily = tokens.typography.fontFamily;
}

/**
 * Optional hook if a component wants to ensure brand is applied on mount.
 */
export function useBrandRules(tokens = BrandRules) {
  React.useEffect(() => {
    applyBrandRules(tokens);
  }, [tokens]);
}
