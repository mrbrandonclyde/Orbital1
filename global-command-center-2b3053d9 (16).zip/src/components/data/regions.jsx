
export const regions = [
  // United States
  { code: "US-CA", name: "California, USA", flag: "🇺🇸", lat: 36.7783, lng: -119.4179 },
  { code: "US-TX", name: "Texas, USA", flag: "🇺🇸", lat: 31.9686, lng: -99.9018 },
  { code: "US-NY", name: "New York, USA", flag: "🇺🇸", lat: 43.2994, lng: -74.2179 },
  { code: "US-FL", name: "Florida, USA", flag: "🇺🇸", lat: 27.6648, lng: -81.5158 },
  { code: "US-IL", name: "Illinois, USA", flag: "🇺🇸", lat: 40.6331, lng: -89.3985 },
  { code: "US-WA", name: "Washington, USA", flag: "🇺🇸", lat: 47.7511, lng: -120.7401 },
  { code: "US-DC", name: "Washington D.C., USA", flag: "🇺🇸", lat: 38.9072, lng: -77.0369 },
  { code: "US", name: "United States (National)", flag: "🇺🇸", lat: 39.8283, lng: -98.5795 },

  // Europe
  { code: "EU-DE", name: "Germany", flag: "🇩🇪", lat: 51.1657, lng: 10.4515 },
  { code: "EU-FR", name: "France", flag: "🇫🇷", lat: 46.2276, lng: 2.2137 },
  { code: "EU-GB", name: "United Kingdom", flag: "🇬🇧", lat: 55.3781, lng: -3.4360 },
  { code: "EU-IT", name: "Italy", flag: "🇮🇹", lat: 41.8719, lng: 12.5674 },
  { code: "EU-ES", name: "Spain", flag: "🇪🇸", lat: 40.4637, lng: -3.7492 },
  { code: "EU-NL", name: "Netherlands", flag: "🇳🇱", lat: 52.1326, lng: 5.2913 },

  // Asia
  { code: "AS-IN", name: "India", flag: "🇮🇳", lat: 20.5937, lng: 78.9629 },
  { code: "AS-CN", name: "China", flag: "🇨🇳", lat: 35.8617, lng: 104.1954 },
  { code: "AS-JP", name: "Japan", flag: "🇯🇵", lat: 36.2048, lng: 138.2529 },
  { code: "AS-KR", name: "South Korea", flag: "🇰🇷", lat: 35.9078, lng: 127.7669 },
  { code: "AS-SG", name: "Singapore", flag: "🇸🇬", lat: 1.3521, lng: 103.8198 },

  // Americas
  { code: "SA-BR", name: "Brazil", flag: "🇧🇷", lat: -14.2350, lng: -51.9253 },
  { code: "NA-CA", name: "Canada", flag: "🇨🇦", lat: 56.1304, lng: -106.3468 },
  { code: "SA-MX", name: "Mexico", flag: "🇲🇽", lat: 23.6345, lng: -102.5528 },

  // Africa & Oceania
  { code: "AF-NG", name: "Nigeria", flag: "🇳🇬", lat: 9.0820, lng: 8.6753 },
  { code: "AF-ZA", name: "South Africa", flag: "🇿🇦", lat: -30.5595, lng: 22.9375 },
  { code: "OC-AU", name: "Australia", flag: "🇦🇺", lat: -25.2744, lng: 133.7751 },

  // Global
  { code: "global", name: "Global (Worldwide)", flag: "🌍", lat: 20, lng: 0 }
];

export const sectors = [
  { id: "finance", name: "Finance", icon: "💰", color: "text-green-400" },
  { id: "defense", name: "Defense", icon: "🛡️", color: "text-red-400" },
  { id: "healthcare", name: "Healthcare", icon: "🏥", color: "text-blue-400" },
  { id: "energy", name: "Energy", icon: "⚡", color: "text-yellow-400" },
  { id: "transport", name: "Transport", icon: "🚢", color: "text-purple-400" },
  { id: "tech", name: "Technology", icon: "💻", color: "text-indigo-400" },
  { id: "agriculture", name: "Agriculture", icon: "🌾", color: "text-orange-400" },
  { id: "companies", name: "Companies", icon: "🏢", color: "text-pink-400" },
  { id: "retail", name: "Retail", icon: "🛒", color: "text-cyan-400" },
  { id: "education", name: "Education", icon: "🎓", color: "text-emerald-400" },
  { id: "realestate", name: "Real Estate", icon: "🏘️", color: "text-amber-400" },
  { id: "manufacturing", name: "Manufacturing", icon: "🏭", color: "text-gray-400" }
];
