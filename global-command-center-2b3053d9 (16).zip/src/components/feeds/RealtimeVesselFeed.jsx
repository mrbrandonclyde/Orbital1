import React, { useState, useEffect } from 'react';
import { VesselTracking } from '@/api/entities';
import { useLiveData } from '../lib/useLiveData';
import { Ship, MapPin, Navigation, AlertTriangle } from 'lucide-react';

export default function RealtimeVesselFeed({ region = 'global' }) {
  const [vessels, setVessels] = useState([]);
  const vesselUpdate = useLiveData('maritime', region, 'vessel:update');

  // Generate mock AIS vessel data
  useEffect(() => {
    const mockVessels = [
      {
        mmsi: '123456789',
        vessel_name: 'MAERSK SEOUL',
        vessel_type: 'CARGO',
        current_position: { latitude: 37.7749, longitude: -122.4194, timestamp: new Date().toISOString() },
        speed_knots: 14.2,
        heading_degrees: 285,
        destination: 'SAN FRANCISCO',
        flag_country: 'DK',
        risk_assessment: 'LOW'
      },
      {
        mmsi: '987654321',
        vessel_name: 'EVERGREEN TRIUMPH',
        vessel_type: 'CARGO',
        current_position: { latitude: 40.7128, longitude: -74.0060, timestamp: new Date().toISOString() },
        speed_knots: 0.1,
        heading_degrees: 90,
        destination: 'NEW YORK',
        flag_country: 'TW',
        risk_assessment: 'MEDIUM'
      },
      {
        mmsi: '456789123',
        vessel_name: 'CHEVRON HOUSTON',
        vessel_type: 'TANKER',
        current_position: { latitude: 29.7604, longitude: -95.3698, timestamp: new Date().toISOString() },
        speed_knots: 8.5,
        heading_degrees: 180,
        destination: 'GALVESTON',
        flag_country: 'US',
        risk_assessment: 'HIGH'
      }
    ];
    setVessels(mockVessels);
  }, []);

  // Update with live data when available
  useEffect(() => {
    if (vesselUpdate) {
      setVessels(prev => {
        const updated = [...prev];
        const existingIndex = updated.findIndex(v => v.mmsi === vesselUpdate.mmsi);
        if (existingIndex >= 0) {
          updated[existingIndex] = { ...updated[existingIndex], ...vesselUpdate };
        } else {
          updated.push(vesselUpdate);
        }
        return updated;
      });
    }
  }, [vesselUpdate]);

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'CRITICAL': return 'text-red-400';
      case 'HIGH': return 'text-orange-400';
      case 'MEDIUM': return 'text-yellow-400';
      default: return 'text-green-400';
    }
  };

  const getVesselIcon = (type) => {
    switch (type) {
      case 'TANKER': return '🛢️';
      case 'CARGO': return '📦';
      case 'PASSENGER': return '🚢';
      case 'MILITARY': return '⚔️';
      default: return '🚢';
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Ship className="w-6 h-6 text-cyan-400" />
          <h3 className="text-xl font-semibold text-white">AIS Vessel Tracking</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-gray-400">Real-time AIS</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {vessels.map((vessel) => (
          <div key={vessel.mmsi} className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 transition-all">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{getVesselIcon(vessel.vessel_type)}</span>
                <div>
                  <h4 className="font-medium text-white">{vessel.vessel_name}</h4>
                  <p className="text-xs text-gray-400">MMSI: {vessel.mmsi}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`text-xs font-medium px-2 py-1 rounded-full bg-opacity-20 ${getRiskColor(vessel.risk_assessment)}`}>
                  {vessel.risk_assessment}
                </span>
                <span className="text-xs text-gray-400">{vessel.flag_country}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs text-gray-400">
              <div className="flex items-center space-x-1">
                <MapPin className="w-3 h-3" />
                <span>{vessel.current_position.latitude.toFixed(3)}, {vessel.current_position.longitude.toFixed(3)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Navigation className="w-3 h-3" />
                <span>{vessel.speed_knots} kts • {vessel.heading_degrees}°</span>
              </div>
              <div>
                <span className="font-medium">Type:</span> {vessel.vessel_type}
              </div>
              <div>
                <span className="font-medium">Dest:</span> {vessel.destination}
              </div>
            </div>

            {vessel.risk_assessment !== 'LOW' && (
              <div className="mt-2 flex items-center space-x-2 text-xs">
                <AlertTriangle className="w-3 h-3 text-orange-400" />
                <span className="text-orange-400">Elevated risk assessment - monitoring closely</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 text-xs text-gray-500 text-center">
        Tracking {vessels.length} vessels • Last update: {new Date().toLocaleTimeString()}
      </div>
    </div>
  );
}