import React from "react";
import { blockLibrary, makeBlock } from "./BlockLibrary";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function BuilderSidebar({ onAdd }) {
  const sections = [
    { key: "sections", title: "Sections" },
    { key: "elements", title: "Elements" },
    { key: "forms", title: "Forms" },
    { key: "ecommerce", title: "E‑Commerce" },
    { key: "layout", title: "Layout" },
    { key: "widgets", title: "Widgets" },
  ];

  return (
    <aside className="w-full lg:w-72 bg-[#0A0D18]/80 border border-gray-800 rounded-xl h-full overflow-y-auto sidebar-scroll">
      <div className="p-4 border-b border-gray-800">
        <p className="text-xs uppercase text-gray-500 mb-1">Builder</p>
        <h3 className="text-white font-semibold">Block Library</h3>
      </div>

      <div className="p-3 space-y-4">
        {sections.map(sec => (
          <Card key={sec.key} className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">{sec.title}</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-2">
              {blockLibrary[sec.key].map(item => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.type}
                    title={item.label}
                    onClick={() => onAdd(makeBlock(item.type))}
                    className="flex items-center gap-2 px-2 py-2 rounded-lg bg-gray-800/40 hover:bg-gray-800/70 text-gray-200 text-xs"
                  >
                    <Icon className="w-4 h-4 text-cyan-400" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </CardContent>
          </Card>
        ))}
      </div>
    </aside>
  );
}