import React, { useState } from 'react';
import { AIAgent } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AgentForm({ agent, onSuccess }) {
  const [formData, setFormData] = useState({
    name: agent?.name || '',
    description: agent?.description || '',
    function: agent?.function || 'Operations',
    status: agent?.status || 'Offline',
    icon: agent?.icon || 'Bot'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const agentData = {
        ...formData,
        performance_metrics: {
          tasks_completed: 0,
          efficiency_gain: '0%',
          roi_percentage: 0
        }
      };

      if (agent) {
        await AIAgent.update(agent.id, agentData);
      } else {
        await AIAgent.create(agentData);
      }
      onSuccess();
    } catch (error) {
      console.error('Failed to save agent:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input
          placeholder="Agent Name"
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
          required
        />
        <Select value={formData.function} onValueChange={(value) => setFormData({...formData, function: value})}>
          <SelectTrigger>
            <SelectValue placeholder="Function" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Marketing">Marketing</SelectItem>
            <SelectItem value="Sales">Sales</SelectItem>
            <SelectItem value="Operations">Operations</SelectItem>
            <SelectItem value="Support">Support</SelectItem>
            <SelectItem value="Data Analysis">Data Analysis</SelectItem>
            <SelectItem value="Finance">Finance</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Textarea
        placeholder="Agent Description"
        value={formData.description}
        onChange={(e) => setFormData({...formData, description: e.target.value})}
        rows={3}
      />

      <div className="grid grid-cols-2 gap-4">
        <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
          <SelectTrigger>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Active">Active</SelectItem>
            <SelectItem value="Idle">Idle</SelectItem>
            <SelectItem value="Training">Training</SelectItem>
            <SelectItem value="Offline">Offline</SelectItem>
          </SelectContent>
        </Select>
        <Input
          placeholder="Icon Name"
          value={formData.icon}
          onChange={(e) => setFormData({...formData, icon: e.target.value})}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="submit" disabled={isSubmitting} className="orbital-button-primary">
          {isSubmitting ? 'Deploying...' : (agent ? 'Update Agent' : 'Deploy Agent')}
        </Button>
      </div>
    </form>
  );
}