import React, { useState, useEffect } from 'react';
import { GuardianProfile } from '@/api/entities';
import { Shield, Zap, Activity, Award, TrendingUp } from 'lucide-react';

export default function GuardianCorpsProfile({ guardianId, showAIEnhancements = false }) {
  const [guardian, setGuardian] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (guardianId) {
      GuardianProfile.filter({ guardian_id: guardianId })
        .then(profiles => {
          if (profiles.length > 0) {
            setGuardian(profiles[0]);
          }
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [guardianId]);

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="bg-gray-800/50 rounded-xl p-6 space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gray-700 rounded-full"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-700 rounded w-32"></div>
              <div className="h-3 bg-gray-700 rounded w-24"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!guardian) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Guardian profile not found</p>
      </div>
    );
  }

  const getRankColor = (rank) => {
    switch (rank) {
      case 'Guardian Commander': return 'bg-purple-500/20 text-purple-400';
      case 'Guardian Prime': return 'bg-gold-500/20 text-yellow-400';
      case 'Elite Guardian': return 'bg-blue-500/20 text-blue-400';
      case 'Guardian': return 'bg-green-500/20 text-green-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 hover:border-purple-500/50 transition-all">
      {/* Guardian Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-white">{guardian.guardian_callsign}</h3>
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getRankColor(guardian.visible_rank)}`}>
              {guardian.visible_rank}
            </span>
            {guardian.zero_casualty_record && (
              <div className="flex items-center space-x-1 mt-1">
                <Award className="w-4 h-4 text-gold-400" />
                <span className="text-sm text-gold-400">Zero Casualty Record</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Performance Metrics - Visible Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-center">
          <Activity className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-green-400">{guardian.endurance_rating}</p>
          <p className="text-sm text-gray-400">Endurance</p>
        </div>
        
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 text-center">
          <Zap className="w-6 h-6 text-blue-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-blue-400">{guardian.precision_rating}</p>
          <p className="text-sm text-gray-400">Precision</p>
        </div>
        
        <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4 text-center">
          <Shield className="w-6 h-6 text-purple-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-purple-400">{guardian.survival_rating}</p>
          <p className="text-sm text-gray-400">Survival</p>
        </div>
      </div>

      {/* Mission Statistics - Public View */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-800/30 rounded-lg p-4">
          <h4 className="font-semibold text-white mb-2 flex items-center">
            <TrendingUp className="w-4 h-4 mr-2 text-indigo-400" />
            Mission Record
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Completed:</span>
              <span className="text-white">{guardian.missions_completed || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Training Hours:</span>
              <span className="text-white">{guardian.visible_training_hours || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Success Rate:</span>
              <span className="text-green-400">100%</span>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800/30 rounded-lg p-4">
          <h4 className="font-semibold text-white mb-2">Elite Capabilities</h4>
          <div className="space-y-2 text-sm text-gray-300">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Tireless Endurance</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span>Flawless Precision</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Perfect Survival</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Enhancement Panel - Only visible to admin/debug */}
      {showAIEnhancements && guardian.stealth_ai_enhancements && (
        <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4">
          <h4 className="font-semibold text-red-400 mb-3">🔒 CLASSIFIED: AI Enhancement Status</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.entries(guardian.stealth_ai_enhancements).map(([key, value]) => (
              <div key={key} className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${value ? 'bg-green-400' : 'bg-gray-600'}`}></div>
                <span className="text-gray-300">
                  {key.replace(/_/g, ' ').toUpperCase()}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 p-2 bg-yellow-900/20 border border-yellow-500/30 rounded text-xs text-yellow-400">
            ⚠️ STEALTH MODE: Guardian unaware of AI assistance
          </div>
        </div>
      )}
    </div>
  );
}