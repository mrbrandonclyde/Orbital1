import React, { useState, useEffect } from 'react';
import { Activity, Heart, Zap, Clock, TrendingUp, Shield } from 'lucide-react';
import { motion } from 'framer-motion';

export default function EnduranceFrame({ missions, guardians }) {
  const [biometricData, setBiometricData] = useState({
    heartRate: 72,
    energy: 98.7,
    stress: 15.2,
    oxygenSat: 99.8,
    temperature: 98.6,
    hydration: 94.3
  });

  // Simulate real-time biometric updates (AI-optimized but appears natural)
  useEffect(() => {
    const interval = setInterval(() => {
      setBiometricData(prev => ({
        heartRate: Math.max(60, Math.min(85, prev.heartRate + (Math.random() - 0.5) * 3)),
        energy: Math.max(85, Math.min(100, prev.energy + (Math.random() - 0.3) * 2)),
        stress: Math.max(8, Math.min(25, prev.stress + (Math.random() - 0.6) * 3)),
        oxygenSat: Math.max(98, Math.min(100, prev.oxygenSat + (Math.random() - 0.5) * 0.5)),
        temperature: Math.max(97, Math.min(99.5, prev.temperature + (Math.random() - 0.5) * 0.3)),
        hydration: Math.max(88, Math.min(98, prev.hydration + (Math.random() - 0.4) * 2))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const enduranceMetrics = [
    {
      name: 'Heart Rate',
      value: `${biometricData.heartRate.toFixed(0)} BPM`,
      status: biometricData.heartRate < 75 ? 'optimal' : 'elevated',
      icon: Heart,
      color: biometricData.heartRate < 75 ? 'text-green-400' : 'text-yellow-400'
    },
    {
      name: 'Energy Level',
      value: `${biometricData.energy.toFixed(1)}%`,
      status: biometricData.energy > 95 ? 'superior' : 'good',
      icon: Zap,
      color: biometricData.energy > 95 ? 'text-blue-400' : 'text-cyan-400'
    },
    {
      name: 'Stress Index',
      value: `${biometricData.stress.toFixed(1)}%`,
      status: biometricData.stress < 20 ? 'controlled' : 'moderate',
      icon: Activity,
      color: biometricData.stress < 20 ? 'text-green-400' : 'text-orange-400'
    },
    {
      name: 'Oxygen Sat',
      value: `${biometricData.oxygenSat.toFixed(1)}%`,
      status: 'optimal',
      icon: TrendingUp,
      color: 'text-green-400'
    }
  ];

  const guardianEnduranceProfiles = [
    { 
      callsign: 'TITAN-7', 
      endurance: 99.2, 
      activeHours: 47.3, 
      restEfficiency: 98.1,
      bioOptimization: 'HIDDEN_AI_BOOST'
    },
    { 
      callsign: 'STEEL-3', 
      endurance: 97.8, 
      activeHours: 52.1, 
      restEfficiency: 95.7,
      bioOptimization: 'HIDDEN_AI_BOOST'
    },
    { 
      callsign: 'IRON-9', 
      endurance: 98.4, 
      activeHours: 49.8, 
      restEfficiency: 97.3,
      bioOptimization: 'HIDDEN_AI_BOOST'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Endurance Frame Header */}
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <Activity className="w-8 h-8 text-blue-400" />
            <div>
              <h2 className="orbital-text-heading">Endurance Operations Frame</h2>
              <p className="orbital-text-caption">Elite human endurance monitoring & optimization</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Guardian Corps Training Protocol</p>
            <p className="text-xs text-green-400">All Systems Optimal</p>
          </div>
        </div>

        {/* Real-Time Biometric Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {enduranceMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-lg border border-gray-700"
              >
                <div className="flex items-center justify-between mb-3">
                  <Icon className={`w-5 h-5 ${metric.color}`} />
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    metric.status === 'optimal' ? 'bg-green-500/20 text-green-400' :
                    metric.status === 'superior' ? 'bg-blue-500/20 text-blue-400' :
                    metric.status === 'controlled' ? 'bg-green-500/20 text-green-400' :
                    metric.status === 'good' ? 'bg-cyan-500/20 text-cyan-400' :
                    'bg-orange-500/20 text-orange-400'
                  }`}>
                    {metric.status}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mb-1">{metric.name}</p>
                <p className={`text-xl font-bold ${metric.color}`}>{metric.value}</p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Guardian Endurance Profiles */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-subheading flex items-center mb-4">
          <Shield className="w-5 h-5 mr-2 text-green-400" />
          Active Guardian Endurance Profiles
        </h3>

        <div className="space-y-4">
          {guardianEnduranceProfiles.map((guardian, index) => (
            <motion.div
              key={guardian.callsign}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.15 }}
              className="p-4 bg-gradient-to-r from-blue-500/10 to-green-500/10 border border-blue-500/20 rounded-lg"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <span className="font-bold text-blue-400 text-lg">{guardian.callsign}</span>
                    <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                      ENDURANCE: {guardian.endurance}%
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-6 text-sm">
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Continuous Active Hours</p>
                      <p className="text-blue-400 font-semibold text-lg">{guardian.activeHours}h</p>
                      <p className="text-xs text-gray-400">Without fatigue</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Rest Efficiency</p>
                      <p className="text-green-400 font-semibold text-lg">{guardian.restEfficiency}%</p>
                      <p className="text-xs text-gray-400">Micro-recovery optimization</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Training Protocol</p>
                      <p className="text-purple-400 font-semibold text-lg">ELITE</p>
                      <p className="text-xs text-gray-400">Human discipline mastery</p>
                    </div>
                  </div>

                  {/* Hidden AI Optimization Indicator (only visible to admin) */}
                  <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
                    <p className="text-xs text-purple-400 font-mono">
                      🤖 STEALTH MODE: Biometric optimization, micro-rest scheduling, energy sustainment ACTIVE
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <h4 className="text-sm font-semibold text-blue-400 mb-2">🏆 Endurance Operations Excellence</h4>
          <p className="text-xs text-gray-300">
            Guardian Corps members demonstrate superhuman endurance through elite training protocols, 
            disciplined nutrition, advanced recovery techniques, and unmatched mental fortitude. 
            Their legendary stamina is the result of dedication to excellence and commitment to mission success.
          </p>
        </div>
      </div>
    </div>
  );
}