
import React, { useState, useEffect } from 'react';
import { GuardianProtocol, GuardianProfile } from '@/api/entities';
import { Brain, Eye, EyeOff, Shield, Zap, Activity } from 'lucide-react';

export default function ZyraSidebar({ isVisible }) {
  const [protocols, setProtocols] = useState([]);
  const [guardians, setGuardians] = useState([]);
  const [stealthMode, setStealthMode] = useState(true); // Retained as an internal display mode
  const [activeOperations, setActiveOperations] = useState({});

  useEffect(() => {
    const loadGuardianData = async () => {
      try {
        const [protocolData, guardianData] = await Promise.all([
          GuardianProtocol.list(),
          GuardianProfile.list()
        ]);
        setProtocols(protocolData);
        setGuardians(guardianData);
        
        // Initialize active operations based on Phase 1 specs
        const ops = {};
        protocolData.forEach(protocol => {
          if (protocol.meta?.version === 'stealth-human') {
            protocol.missions?.forEach(mission => {
              ops[mission.type] = {
                status: 'ACTIVE',
                aiRole: mission.ai_role,
                actions: mission.actions,
                visibleActors: mission.visible_actors
              };
            });
          }
        });
        setActiveOperations(ops);
      } catch (error) {
        console.error('Guardian Protocol data unavailable:', error);
      }
    };

    loadGuardianData();
    // Real-time updates every 3 seconds
    const interval = setInterval(loadGuardianData, 3000);
    return () => clearInterval(interval);
  }, []);

  const getMissionIcon = (type) => {
    switch (type) {
      case 'endurance_ops': return Activity;
      case 'precision_training': return Zap;
      case 'never_die_protocol': return Shield;
      default: return Brain;
    }
  };

  const getMissionColor = (type) => {
    switch (type) {
      case 'endurance_ops': return 'text-blue-400 bg-blue-500/10';
      case 'precision_training': return 'text-yellow-400 bg-yellow-500/10';
      case 'never_die_protocol': return 'text-red-400 bg-red-500/10';
      default: return 'text-purple-400 bg-purple-500/10';
    }
  };

  // Phase 1 Zyra Operations - new hardcoded data
  const phase1Operations = [
    {
      id: 'endurance_optimizer',
      name: 'Endurance Optimizer',
      status: 'ACTIVE',
      description: 'Biometric optimization and micro-rest scheduling',
      humanImpact: 'Guardians appear tireless and superhuman',
      aiRole: 'performance_optimizer'
    },
    {
      id: 'simulation_coach',
      name: 'Simulation Coach', 
      status: 'ACTIVE',
      description: 'Continuous drills and predictive tactical analysis',
      humanImpact: 'Guardians achieve 99.4% precision scores',
      aiRole: 'simulation_coach'
    },
    {
      id: 'safety_shield',
      name: 'Safety Shield',
      status: 'ACTIVE', 
      description: 'Threat prediction and fatality prevention',
      humanImpact: 'Zero casualty record across all missions',
      aiRole: 'safety_shield'
    }
  ];

  return (
    <div className={`fixed top-0 right-0 h-full w-96 bg-[#0A0D18] border-l border-purple-500/30 transform transition-transform duration-300 z-50 ${
      isVisible ? 'translate-x-0' : 'translate-x-full'
    }`}>
      {/* Zyra Header */}
      <div className="p-4 border-b border-purple-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Brain className="w-8 h-8 text-purple-400" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
            </div>
            <div>
              <h2 className="text-lg font-bold text-purple-400">ZYRA CORE</h2>
              <p className="text-xs text-gray-400">Guardian Protocol Active</p>
            </div>
          </div>
          <button
            onClick={() => setStealthMode(!stealthMode)} // Now toggles internal stealthMode state
            className="p-2 rounded-md hover:bg-purple-500/20 transition-colors"
          >
            {stealthMode ? <EyeOff className="w-4 h-4 text-purple-400" /> : <Eye className="w-4 h-4 text-purple-400" />}
          </button>
        </div>
      </div>

      {/* Phase 1 Operations Panel */}
      <div className="p-6">
        <h3 className="text-lg font-semibold text-purple-400 mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2" />
          Phase 1 Foundation Operations
        </h3>

        <div className="space-y-4">
          {phase1Operations.map(operation => (
            <div key={operation.id} className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-white">{operation.name}</h4>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  operation.status === 'ACTIVE' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                }`}>
                  {operation.status}
                </span>
              </div>
              <p className="text-xs text-gray-400 mb-2">{operation.description}</p>
              <div className="p-2 bg-black/30 rounded border border-blue-500/20">
                <p className="text-xs text-blue-400">{operation.humanImpact}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Guardian Corps Performance (Visible Metrics) - kept as is */}
      <div className="p-4 border-b border-gray-800">
        <h3 className="text-sm font-semibold text-white mb-3">Guardian Performance</h3>
        <div className="space-y-2">
          {guardians.slice(0, 3).map(guardian => (
            <div key={guardian.guardian_id} className="bg-gray-900/50 rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-white">{guardian.guardian_callsign}</span>
                <span className="text-xs text-purple-400">{guardian.visible_rank}</span>
              </div>
              <div className="grid grid-cols-3 gap-1 text-xs">
                <div className="text-center">
                  <div className="text-blue-400 font-bold">{guardian.endurance_rating}%</div>
                  <div className="text-gray-500">Endurance</div>
                </div>
                <div className="text-center">
                  <div className="text-yellow-400 font-bold">{guardian.precision_rating}%</div>
                  <div className="text-gray-500">Precision</div>
                </div>
                <div className="text-center">
                  <div className="text-green-400 font-bold">{guardian.survival_rating}%</div>
                  <div className="text-gray-500">Survival</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ethics Compliance - kept as is */}
      <div className="p-4 border-b border-gray-800">
        <h3 className="text-sm font-semibold text-white mb-3">Ethics Framework</h3>
        <div className="space-y-1 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-gray-300">AI Bible Compliance</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-gray-300">12 Commandments Active</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-gray-300">Pledge of Allegiance</span>
          </div>
        </div>
      </div>

      {/* Stealth Mode Notice - now conditional on internal stealthMode state */}
      {stealthMode && (
        <div className="p-4 bg-purple-900/20">
          <div className="text-xs text-purple-400 text-center">
            <p className="font-semibold mb-1">STEALTH PRESENTATION MODE</p>
            <p className="text-gray-400">
              Public sees elite human training.<br/>
              Reality: AI-enhanced excellence.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
