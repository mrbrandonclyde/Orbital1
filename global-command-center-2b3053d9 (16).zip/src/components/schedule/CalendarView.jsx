import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, addMonths, subMonths, isSameDay, getDay } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function CalendarView({ events, onDayClick, onEventClick }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const firstDayOfMonth = startOfMonth(currentMonth);
  const lastDayOfMonth = endOfMonth(currentMonth);
  
  const daysInMonth = eachDayOfInterval({
    start: firstDayOfMonth,
    end: lastDayOfMonth,
  });

  const startingDayIndex = getDay(firstDayOfMonth);

  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex justify-between items-center mb-4">
        <button onClick={prevMonth} className="p-2 rounded-full hover:bg-gray-700/50">
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <h2 className="text-2xl font-bold text-white">
          {format(currentMonth, 'MMMM yyyy')}
        </h2>
        <button onClick={nextMonth} className="p-2 rounded-full hover:bg-gray-700/50">
          <ChevronRight className="w-6 h-6 text-white" />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-px text-center text-sm text-gray-400 border-t border-l border-gray-700">
        {WEEKDAYS.map(day => (
          <div key={day} className="py-2 bg-gray-800/50 border-r border-b border-gray-700">{day}</div>
        ))}
        {Array.from({ length: startingDayIndex }).map((_, index) => (
          <div key={`empty-${index}`} className="border-r border-b border-gray-700" />
        ))}
        {daysInMonth.map(day => {
          const dayEvents = events.filter(e => isSameDay(new Date(e.start_date_time), day));
          return (
            <div
              key={day.toString()}
              onClick={() => onDayClick(day)}
              className="relative min-h-[120px] p-2 border-r border-b border-gray-700 hover:bg-gray-800/30 cursor-pointer"
            >
              <time dateTime={format(day, 'yyyy-MM-dd')} className="font-semibold text-white">
                {format(day, 'd')}
              </time>
              <div className="mt-1 space-y-1">
                {dayEvents.slice(0, 3).map(event => (
                  <div 
                    key={event.id}
                    onClick={(e) => { e.stopPropagation(); onEventClick(event); }}
                    className="bg-indigo-600/50 text-white text-xs p-1 rounded truncate"
                  >
                    {event.event_title}
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <div className="text-xs text-gray-400 mt-1">+{dayEvents.length - 3} more</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}