import React from 'react';
import { Crown, Lock, Eye, Zap } from 'lucide-react';

function VRUpgradePanel({ sector, position = {} }) {
  return (
    <div className="relative bg-gray-800/90 border-2 border-gray-600 rounded-xl p-6 text-center backdrop-blur-sm">
      {/* Lock Icon */}
      <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
        <Lock className="w-8 h-8 text-gray-400" />
      </div>
      
      {/* Text */}
      <h3 className="text-xl font-bold text-white mb-2">🔒 UPGRADE TO UNLOCK</h3>
      <p className="text-gray-300 mb-2">{sector} Intelligence</p>
      <p className="text-gray-500 text-sm">Enterprise tier required</p>
    </div>
  );
}

function VRSectorHologram({ sector, unlocked }) {
  if (!unlocked) {
    return <VRUpgradePanel sector={sector} />;
  }

  return (
    <div className="relative bg-indigo-500/20 border-2 border-indigo-400 rounded-xl p-6 text-center backdrop-blur-sm">
      {/* Unlocked content - glowing sector representation */}
      <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
        <Eye className="w-8 h-8 text-white" />
      </div>
      
      <h3 className="text-xl font-bold text-white">{sector}</h3>
      <p className="text-indigo-300 text-sm">Access Granted</p>
    </div>
  );
}

export default function VRBillingLock({ 
  userTier = 'BASIC', 
  requiredTier = 'ENTERPRISE',
  sectors = ['Energy', 'Defense', 'Finance', 'Technology'] 
}) {
  const tierLevels = { BASIC: 1, PROFESSIONAL: 2, ENTERPRISE: 3, GOVERNMENT: 4 };
  const hasAccess = tierLevels[userTier] >= tierLevels[requiredTier];

  return (
    <div className="w-full bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900 rounded-xl p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {sectors.map((sector, index) => (
          <VRSectorHologram
            key={sector}
            sector={sector}
            unlocked={hasAccess}
          />
        ))}
      </div>
      
      {!hasAccess && (
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Crown className="w-8 h-8 text-red-400" />
            <h2 className="text-2xl font-bold text-red-400">VR Access Restricted</h2>
            <Crown className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-gray-300 mb-6">Upgrade to Enterprise tier to unlock immersive VR intelligence features</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-800/50 rounded-lg p-4">
              <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
              <h4 className="font-semibold text-yellow-400 mb-2">🌍 Interactive Globe</h4>
              <p className="text-gray-400 text-sm">Navigate through regions, sectors, and companies in 3D space</p>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-4">
              <Zap className="w-6 h-6 text-red-400 mx-auto mb-2" />
              <h4 className="font-semibold text-red-400 mb-2">🚨 Holographic Alerts</h4>
              <p className="text-gray-400 text-sm">Critical threats appear as floating holograms around you</p>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-4">
              <Zap className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <h4 className="font-semibold text-blue-400 mb-2">🤝 Multi-User Sessions</h4>
              <p className="text-gray-400 text-sm">Collaborate with your team in shared virtual briefing rooms</p>
            </div>
          </div>
        </div>
      )}
      
      {hasAccess && (
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Crown className="w-8 h-8 text-green-400" />
            <h2 className="text-2xl font-bold text-green-400">VR War Room Unlocked</h2>
            <Crown className="w-8 h-8 text-green-400" />
          </div>
          <p className="text-gray-300">Full immersive intelligence access enabled</p>
        </div>
      )}
    </div>
  );
}