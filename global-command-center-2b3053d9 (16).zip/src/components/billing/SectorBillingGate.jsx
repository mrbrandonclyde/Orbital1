import React from 'react';
import { Shield, Lock } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function SectorBillingGate({ 
  children, 
  sector = null, 
  apiCallsUsed = 0, 
  apiCallsLimit = 1000 
}) {
  // For now, allow all access - billing system not yet implemented
  const hasAccess = true;
  const usagePercent = (apiCallsUsed / apiCallsLimit) * 100;

  if (!hasAccess) {
    return (
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 text-center">
        <div className="p-4 bg-yellow-500/10 rounded-full mb-4 mx-auto w-fit">
          <Lock className="w-8 h-8 text-yellow-400" />
        </div>
        <h3 className="text-lg font-semibold text-white mb-2">Sector Access Required</h3>
        <p className="text-gray-400 mb-4">
          Access to {sector} sector requires an upgraded subscription.
        </p>
        <button className="orbital-button-primary">
          Upgrade Access
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
      {sector && (
        <div className="absolute top-2 right-2 z-10">
          <Badge 
            className={`text-xs ${
              usagePercent > 90 ? 'bg-red-500/20 text-red-400' :
              usagePercent > 75 ? 'bg-yellow-500/20 text-yellow-400' :
              'bg-green-500/20 text-green-400'
            }`}
          >
            <Shield className="w-3 h-3 mr-1" />
            {apiCallsUsed}/{apiCallsLimit}
          </Badge>
        </div>
      )}
      {children}
    </div>
  );
}