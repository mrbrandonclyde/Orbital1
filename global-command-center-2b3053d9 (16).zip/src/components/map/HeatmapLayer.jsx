import { useEffect } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';

// Create heatmap-like visualization using circle markers
const createHeatmapLayer = (points, options = {}) => {
  const heatmapLayer = L.layerGroup();
  
  points.forEach(([lat, lng, intensity]) => {
    const color = intensity > 0.8 ? '#ff0000' : 
                  intensity > 0.5 ? '#ffaa00' : 
                  intensity > 0.3 ? '#ffff00' : '#00ff00';
    
    const radius = Math.max(20000, intensity * 100000); // Base radius in meters
    const opacity = Math.max(0.4, intensity * 0.8);
    
    const circle = L.circle([lat, lng], {
      radius: radius,
      fillColor: color,
      color: color,
      weight: 1,
      opacity: opacity,
      fillOpacity: opacity * 0.6
    });
    
    // Add popup with intensity info
    circle.bindPopup(`
      <div style="color: black;">
        <strong>Threat Level: ${intensity > 0.8 ? 'CRITICAL' : 
                                intensity > 0.5 ? 'HIGH' : 
                                intensity > 0.3 ? 'WARNING' : 'STABLE'}</strong><br/>
        <small>Intensity: ${(intensity * 100).toFixed(1)}%</small>
      </div>
    `);
    
    heatmapLayer.addLayer(circle);
  });
  
  return heatmapLayer;
};

export default function HeatmapLayer({ points, intensity = 1 }) {
  const map = useMap();

  useEffect(() => {
    if (!points || points.length === 0) return;

    console.log(`Rendering heatmap with ${points.length} points:`, points);

    // Create heatmap layer
    const heatmapLayer = createHeatmapLayer(points, {
      radius: 40,
      blur: 15,
      maxZoom: 10,
      max: 1.0
    });

    // Add to map
    heatmapLayer.addTo(map);

    // Cleanup function
    return () => {
      map.removeLayer(heatmapLayer);
    };
  }, [map, points, intensity]);

  return null;
}