import React, { useState, useEffect } from 'react';
import { BusinessSector, Company, DataSource, User, Asset } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Database, CheckCircle, AlertTriangle, Activity, User as UserIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const StatusIndicator = ({ status }) => {
  if (status === 'loading') return <Activity className="w-4 h-4 text-blue-400 animate-spin" />;
  if (status === 'success') return <CheckCircle className="w-4 h-4 text-green-400" />;
  if (status === 'error') return <AlertTriangle className="w-4 h-4 text-red-400" />;
  if (status === 'exists') return <CheckCircle className="w-4 h-4 text-yellow-400" />;
  return null;
};

export default function AutoDataLoader() {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({
    executive: 'idle',
    sectors: 'idle',
    companies: 'idle',
    dataSources: 'idle'
  });
  const [logs, setLogs] = useState([]);

  const addLog = (message, type = 'info') => {
    setLogs(prev => [{ 
      message, 
      type, 
      timestamp: new Date().toLocaleTimeString() 
    }, ...prev]);
  };

  const loadInitialData = async () => {
    setLoading(true);
    addLog('🚀 Starting automatic data loading & seeding...');

    try {
      await loadExecutiveData();
      await loadSectorData();
      // await loadCompanyData(); // Placeholder for future expansion
      // await loadDataSourceData(); // Placeholder for future expansion

      addLog('✅ All seeding and loading tasks completed.');
    } catch (error) {
      addLog(`❌ A critical error occurred: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Seed Executive Commander Data
  const loadExecutiveData = async () => {
    setStatus(prev => ({ ...prev, executive: 'loading' }));
    addLog('👤 Seeding Executive Commander profile...');

    try {
      const existingUsers = await User.filter({ email: "brandon.clyde@executive.global" });
      
      if (existingUsers.length > 0) {
        setStatus(prev => ({ ...prev, executive: 'exists' }));
        addLog('Commander profile already exists. Skipping.', 'warn');
        return;
      }
      
      const executive = await User.create({
        full_name: "Brandon Clyde",
        email: "brandon.clyde@executive.global",
        title: "Global Operations Director",
        team: "Executive Command",
        avatar_url: "https://raw.githubusercontent.com/base44-ai/docs/main/static/images/executive.png",
        role: "Executive",
        security_clearance: "EXECUTIVE_COMMAND",
        subscription_tier: "GOVERNMENT",
        vr_access_level: "FULL_INTERACTIVE",
        mfa_enabled: true
      });
      addLog(`Commander profile created with ID: ${executive.id}`, 'success');

      const assetsToCreate = [
        { asset_name: "Global Equity Portfolio", asset_category: "Equities", current_value_usd: 1200000000, roi_percentage: 12.5, owner_id: executive.id, owner_type: 'USER', asset_type: 'FINANCIAL_INSTRUMENT', risk_level: 'MEDIUM' },
        { asset_name: "Defense Tech Holdings", asset_category: "Equities", current_value_usd: 850000000, roi_percentage: 15.0, owner_id: executive.id, owner_type: 'USER', asset_type: 'INTELLECTUAL_PROPERTY', risk_level: 'MEDIUM' },
        { asset_name: "Energy Grid Assets", asset_category: "Infrastructure", current_value_usd: 650000000, roi_percentage: 9.3, owner_id: executive.id, owner_type: 'USER', asset_type: 'PHYSICAL', risk_level: 'LOW' },
        { asset_name: "Healthcare & Biotech", asset_category: "Equities", current_value_usd: 400000000, roi_percentage: 10.7, owner_id: executive.id, owner_type: 'USER', asset_type: 'INTELLECTUAL_PROPERTY', risk_level: 'MEDIUM' },
        { asset_name: "Real Estate & Infrastructure", asset_category: "Real Estate", current_value_usd: 500000000, roi_percentage: 7.8, owner_id: executive.id, owner_type: 'USER', asset_type: 'PHYSICAL', risk_level: 'LOW' },
      ];
      
      await Asset.bulkCreate(assetsToCreate);
      addLog(`✅ Seeded ${assetsToCreate.length} assets for Commander`, 'success');

      setStatus(prev => ({ ...prev, executive: 'success' }));
    } catch (error) {
      setStatus(prev => ({ ...prev, executive: 'error' }));
      addLog(`❌ Executive seeding failed: ${error.message}`, 'error');
    }
  };

  // Load Sector Data
  const loadSectorData = async () => {
    setStatus(prev => ({ ...prev, sectors: 'loading' }));
    addLog('📊 Loading business sectors...');
    
    const sectorsToCreate = [
      { sector_code: "TECH", sector_name: "Technology", sector_category: "TECHNOLOGY", strategic_importance: "CRITICAL" },
      { sector_code: "DEF", sector_name: "Defense & Aerospace", sector_category: "DEFENSE_SECURITY", strategic_importance: "CRITICAL" },
      { sector_code: "HC", sector_name: "Healthcare", sector_category: "HEALTHCARE_LIFE", strategic_importance: "CRITICAL" },
      { sector_code: "ENERGY", sector_name: "Energy & Utilities", sector_category: "ENERGY_RESOURCES", strategic_importance: "CRITICAL" },
      { sector_code: "FIN", sector_name: "Financial Services", sector_category: "CORE_ECONOMICS", strategic_importance: "CRITICAL" },
      { sector_code: "LOGISTICS", sector_name: "Supply Chain & Logistics", sector_category: "INTERNATIONAL_CHAINS", strategic_importance: "HIGH" },
    ];

    try {
      const existingSectors = await BusinessSector.list();
      const existingCodes = existingSectors.map(s => s.sector_code);
      const newSectors = sectorsToCreate.filter(s => !existingCodes.includes(s.sector_code));
      
      if (newSectors.length > 0) {
        await BusinessSector.bulkCreate(newSectors);
        addLog(`✅ Loaded ${newSectors.length} new business sectors.`, 'success');
      } else {
        addLog('Sectors already up to date.', 'warn');
      }
      setStatus(prev => ({ ...prev, sectors: 'success' }));
    } catch (error) {
      setStatus(prev => ({ ...prev, sectors: 'error' }));
      addLog(`❌ Sector loading failed: ${error.message}`, 'error');
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Initial Data Seeder</h3>
        <Button onClick={loadInitialData} disabled={loading} className="orbital-button-primary">
          {loading ? (
            <><Activity className="w-4 h-4 mr-2 animate-spin" /> Seeding...</>
          ) : (
            <><Database className="w-4 h-4 mr-2" /> Run Seed</>
          )}
        </Button>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
          <span className="flex items-center"><UserIcon className="w-4 h-4 mr-2 text-indigo-400"/>Executive Commander Profile</span>
          <StatusIndicator status={status.executive} />
        </div>
        <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
          <span className="flex items-center"><UserIcon className="w-4 h-4 mr-2 text-indigo-400"/>Business Sectors</span>
          <StatusIndicator status={status.sectors} />
        </div>
      </div>
      
      <div className="h-40 bg-[#0C0F19] rounded-lg p-3 overflow-y-auto border border-gray-700">
        <div className="font-mono text-xs space-y-2">
          {logs.map((log, i) => (
            <div key={i} className={`flex items-start ${
              log.type === 'error' ? 'text-red-400' : 
              log.type === 'success' ? 'text-green-400' :
              log.type === 'warn' ? 'text-yellow-400' : 'text-gray-400'
            }`}>
              <span className="mr-2 text-gray-600">{log.timestamp}</span>
              <p className="flex-1">{log.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}