import React, { useMemo, useState } from 'react';
import { useTexture, Html, Text } from '@react-three/drei';
import * as THREE from 'three';
import { regions as regionData } from '../data/regions';

const latLonToVector3 = (lat, lon, radius) => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

const regionLookup = Object.fromEntries(regionData.map(r => [r.name.toLowerCase(), r]));

function RegionNode({ position, name, type }) {
    const [hovered, setHover] = useState(false);
    const color = type === 'US_STATE' ? '#67e8f9' : '#fde047'; // Cyan for states, Yellow for zones
    return (
        <mesh 
            position={position}
            onPointerOver={(e) => { e.stopPropagation(); setHover(true); }}
            onPointerOut={() => setHover(false)}
        >
            <sphereGeometry args={[0.04, 16, 16]} />
            <meshStandardMaterial 
                color={color}
                emissive={color}
                emissiveIntensity={hovered ? 5 : 1} 
                toneMapped={false}
            />
            {hovered && (
                 <Html distanceFactor={15}>
                    <div className="bg-black/70 text-white text-xs p-1 rounded backdrop-blur-sm whitespace-nowrap">
                        {name}
                    </div>
                </Html>
            )}
        </mesh>
    );
}

export default function Globe({ regions, companies }) {
  const [map, spec, rough] = useTexture([
    'https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x5400x2700.jpg',
    'https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x5400x2700.jpg', // Using same for spec for simplicity
    'https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x5400x2700.jpg', // and rough
  ]);

  const nodes = useMemo(() => {
    return regions.map(region => {
      const location = regionLookup[region.region_name.toLowerCase()];
      if (!location) return null;
      return {
        id: region.id,
        name: region.region_name,
        type: region.region_type,
        position: latLonToVector3(location.lat, location.lng, 5.05),
      };
    }).filter(Boolean);
  }, [regions]);

  return (
    <mesh>
      <sphereGeometry args={[5, 64, 64]} />
      <meshStandardMaterial 
        map={map} 
        specularMap={spec} 
        roughnessMap={rough} 
        metalness={0.2}
        roughness={0.8}
        map-flipY={false}
      />
      {nodes.map(node => <RegionNode key={node.id} {...node} />)}
    </mesh>
  );
}