import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';

const priorityColors = {
  URGENT: 'border-l-4 border-red-500',
  HIGH: 'border-l-4 border-orange-500',
  MEDIUM: 'border-l-4 border-yellow-500',
  LOW: 'border-l-4 border-blue-500',
};

export default function AlertsFeed({ alerts, loading }) {
  return (
    <div className="h-full flex flex-col">
      <h3 className="text-lg font-semibold text-white mb-4 flex-shrink-0">Critical Alerts Feed</h3>
      <div className="flex-grow overflow-y-auto pr-2 space-y-3">
        {loading && <div className="text-gray-400">Loading alerts...</div>}
        {!loading && alerts?.length === 0 && <div className="text-gray-500 h-full flex items-center justify-center">No active alerts.</div>}
        {alerts?.map((alert, i) => (
          <motion.div
            key={alert.id}
            className={`p-3 bg-gray-800/50 rounded-md ${priorityColors[alert.priority] || 'border-l-4 border-gray-500'}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <p className="text-white font-medium text-sm">{alert.title}</p>
            <p className="text-xs text-gray-400">{alert.description}</p>
            <div className="text-xs text-gray-500 mt-1 flex justify-between">
              <span>{alert.priority}</span>
              <span>{new Date(alert.created_date).toLocaleTimeString()}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}