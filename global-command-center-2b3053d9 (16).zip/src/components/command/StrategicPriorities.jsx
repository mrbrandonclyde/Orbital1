import React from 'react';
import { Calendar, Target, Rocket } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function StrategicPriorities({ events, missions }) {
  const getIcon = (item) => {
    if (item.event_title) return <Calendar className="w-5 h-5 text-indigo-400" />;
    if (item.mission_name?.toLowerCase().includes('colonization')) return <Rocket className="w-5 h-5 text-orange-400" />;
    return <Target className="w-5 h-5 text-purple-400" />;
  };

  const combined = [
    ...(events || []).map(e => ({...e, type: 'event'})),
    ...(missions || []).map(m => ({...m, type: 'mission'})),
  ].sort((a, b) => new Date(a.start_date_time || a.created_date) - new Date(b.start_date_time || b.created_date)).slice(0, 5);

  return (
    <div className="glass-pane p-6 h-full flex flex-col">
      <h3 className="text-xl font-semibold text-white mb-4">Strategic Priorities</h3>
      <div className="flex-grow space-y-3 overflow-y-auto">
        {combined.map(item => (
          <div key={item.id} className="bg-gray-800/50 p-3 rounded-lg flex items-start space-x-4">
            {getIcon(item)}
            <div className="flex-grow">
              <p className="font-medium text-white">{item.event_title || item.mission_name}</p>
              <p className="text-xs text-gray-400 uppercase">{item.event_type || item.status}</p>
            </div>
          </div>
        ))}
      </div>
      <Link to={createPageUrl('Missions')} className="text-center mt-4 text-sm text-blue-400 hover:underline">
        Full Mission Control
      </Link>
    </div>
  );
}