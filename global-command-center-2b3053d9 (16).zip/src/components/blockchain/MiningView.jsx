import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Cpu, Zap, Shield, Server, Clock, CheckCircle } from 'lucide-react';

const getNodeStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/10 text-green-400 border-green-500/20"><CheckCircle className="mr-1 h-3 w-3"/>Active</Badge>;
    case 'SYNCING': return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 animate-pulse"><Clock className="mr-1 h-3 w-3"/>Syncing</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
};

export default function MiningView({ data }) {
    const nodes = data?.nodes || [];
    const validators = nodes.filter(n => n.node_type === 'VALIDATOR');

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-white">Mining & Validation</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="glass-pane">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-gray-400">Total Validators</CardTitle>
                        <Shield className="h-5 w-5 text-blue-400" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-white">{validators.length}</div>
                        <p className="text-xs text-gray-400">Securing the network</p>
                    </CardContent>
                </Card>
                <Card className="glass-pane">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-gray-400">Network Hash Rate</CardTitle>
                        <Zap className="h-5 w-5 text-yellow-400" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-white">847.3 TH/s</div>
                        <p className="text-xs text-gray-400">Difficulty: High</p>
                    </CardContent>
                </Card>
                <Card className="glass-pane">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-gray-400">Total Staked</CardTitle>
                        <Server className="h-5 w-5 text-green-400" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-white">2.5M GCC</div>
                        <p className="text-xs text-gray-400">~15% of total supply</p>
                    </CardContent>
                </Card>
            </div>

            <Card className="glass-pane">
                <CardHeader>
                    <CardTitle>Active Validator Nodes</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="border-gray-700 hover:bg-transparent">
                                    <TableHead className="text-gray-400">Node ID</TableHead>
                                    <TableHead className="text-gray-400">Validator Address</TableHead>
                                    <TableHead className="text-gray-400">Stake</TableHead>
                                    <TableHead className="text-gray-400 text-right">Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {validators.map(node => (
                                    <TableRow key={node.id} className="border-gray-800 hover:bg-gray-800/30">
                                        <TableCell className="font-mono text-xs text-gray-400 truncate max-w-[150px]">{node.node_id}</TableCell>
                                        <TableCell className="font-mono text-xs text-purple-400 truncate max-w-[150px]">{node.node_address}</TableCell>
                                        <TableCell className="font-semibold text-white">1,000,000 GCC</TableCell>
                                        <TableCell className="text-right">{getNodeStatusBadge(node.status)}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}