import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Wallet, Activity, Server, TrendingUp, Blocks, Hash, Clock, CheckCircle } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

const getStatusBadge = (status) => {
  switch (status) {
    case "CONFIRMED":
    case "FINALIZED":
       return <Badge className="bg-green-500/10 text-green-400 border-green-500/20 capitalize">{status.toLowerCase()}</Badge>;
    case "PENDING": 
      return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 capitalize animate-pulse">{status.toLowerCase()}</Badge>;
    case "FAILED": return <Badge className="bg-red-500/10 text-red-400 border-red-500/20 capitalize">{status.toLowerCase()}</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20 capitalize">{status?.toLowerCase()}</Badge>;
  }
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-900/80 backdrop-blur-sm border border-gray-700 p-2 rounded-lg text-xs shadow-lg">
        <p className="font-bold text-white">{`${payload[0].value} TXs`}</p>
        <p className="text-gray-400">{label}</p>
      </div>
    );
  }
  return null;
};

export default function DashboardView({ data }) {
  const recentTransactions = data?.transactions?.slice(0, 5) || [];
  const recentBlocks = data?.blocks?.slice(0, 5) || [];
  
  const networkStatus = {
    blockHeight: data?.blocks?.[0]?.block_number || 'N/A',
    avgBlockTime: 2.1, // Mock
    gasPrice: 5, // Mock
    activeValidators: data?.nodes?.filter(n => n.node_type === 'VALIDATOR' && n.status === 'ACTIVE').length || 0
  };

  const transactionVolume = (data?.blocks || []).slice().reverse().map((block, i) => ({
      name: `Block ${block.block_number}`,
      uv: block.transaction_count,
  })).slice(-20);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Blockchain Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total GCC Balance</CardTitle>
            <Wallet className="h-5 w-5 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">1,432.89 GCC</div>
            <p className="text-xs text-gray-400">≈ $25,123.45 USD</p>
          </CardContent>
        </Card>
         <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Transactions</CardTitle>
            <Activity className="h-5 w-5 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{data?.transactions?.length || 0}</div>
            <p className="text-xs text-gray-400">+201 in last 24h</p>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Active Validators</CardTitle>
            <Server className="h-5 w-5 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{networkStatus.activeValidators}</div>
            <p className="text-xs text-gray-400">Network Secure</p>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Latest Block</CardTitle>
            <Blocks className="h-5 w-5 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">#{networkStatus.blockHeight}</div>
            <p className="text-xs text-gray-400">Avg. time: {networkStatus.avgBlockTime}s</p>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-pane">
        <CardHeader>
            <CardTitle className="flex items-center"><TrendingUp className="mr-2 h-5 w-5 text-cyan-400" />Transaction Volume</CardTitle>
        </CardHeader>
        <CardContent className="h-48">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={transactionVolume} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <defs>
                        <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="uv" stroke="#06B6D4" strokeWidth={2} fill="url(#colorUv)" />
                    <RechartsTooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(6, 182, 212, 0.5)', strokeWidth: 1, strokeDasharray: '3 3' }}/>
                </AreaChart>
            </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center"><Activity className="mr-2 h-5 w-5 text-green-400" /> Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Hash</TableHead>
                  <TableHead className="text-gray-400 text-right">Amount</TableHead>
                  <TableHead className="text-gray-400 text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentTransactions.map(tx => (
                  <TableRow key={tx.id} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="font-mono text-xs text-purple-400 truncate max-w-[120px]">{tx.transaction_hash}</TableCell>
                    <TableCell className="text-white text-right">{tx.amount.toFixed(4)} GCC</TableCell>
                    <TableCell className="text-right">{getStatusBadge(tx.status || "CONFIRMED")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center"><Blocks className="mr-2 h-5 w-5 text-blue-400" /> Recent Blocks</CardTitle>
          </CardHeader>
          <CardContent>
             <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Block</TableHead>
                  <TableHead className="text-gray-400 text-right">TXs</TableHead>
                  <TableHead className="text-gray-400">Validator</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentBlocks.map(block => (
                  <TableRow key={block.id} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="font-semibold text-white">#{block.block_number}</TableCell>
                    <TableCell className="text-white text-right">{block.transaction_count}</TableCell>
                    <TableCell className="font-mono text-xs text-purple-400 truncate max-w-[120px]">{block.validator_address}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}