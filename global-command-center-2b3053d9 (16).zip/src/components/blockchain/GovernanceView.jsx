import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Gavel, Plus, Check, X } from 'lucide-react';
import { Progress } from "@/components/ui/progress";

const getProposalStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">{status}</Badge>;
    case 'PASSED': return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    case 'FAILED': return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">{status}</Badge>;
    case 'EXECUTED': return <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">{status}</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
};

export default function GovernanceView({ data }) {
  const proposals = (data?.proposals || []).length > 0 ? data.proposals : [
      {id: '1', proposal_id: 'GIP-001', title: 'Increase Validator Stake Minimum', status: 'ACTIVE', votes_for: 1250000, votes_against: 340000},
      {id: '2', proposal_id: 'GIP-002', title: 'Implement Gas Fee Reduction', status: 'PASSED', votes_for: 2100000, votes_against: 150000},
      {id: '3', proposal_id: 'GIP-003', title: 'Fund Community Development Grant', status: 'FAILED', votes_for: 800000, votes_against: 950000},
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Governance</h1>
        <Button className="orbital-button-primary"><Plus className="mr-2 h-4 w-4"/>Create Proposal</Button>
      </div>

      <Card className="glass-pane">
        <CardHeader>
            <CardTitle>Active & Recent Proposals</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-transparent">
                            <TableHead className="text-gray-400">ID</TableHead>
                            <TableHead className="text-gray-400">Title</TableHead>
                            <TableHead className="text-gray-400">Status</TableHead>
                            <TableHead className="text-gray-400 w-[300px]">Voting</TableHead>
                            <TableHead className="text-gray-400 text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {proposals.map(proposal => {
                            const totalVotes = proposal.votes_for + proposal.votes_against;
                            const forPercentage = totalVotes > 0 ? (proposal.votes_for / totalVotes) * 100 : 0;
                            return (
                                <TableRow key={proposal.id} className="border-gray-800 hover:bg-gray-800/30">
                                    <TableCell className="font-mono text-sm text-cyan-400">{proposal.proposal_id}</TableCell>
                                    <TableCell className="font-semibold text-white">{proposal.title}</TableCell>
                                    <TableCell>{getProposalStatusBadge(proposal.status)}</TableCell>
                                    <TableCell>
                                        <div className="flex items-center space-x-2">
                                            <Progress value={forPercentage} className="w-full h-2 [&>div]:bg-green-400" />
                                            <span className="text-xs text-gray-300 min-w-max">{forPercentage.toFixed(1)}% For</span>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        {proposal.status === 'ACTIVE' && (
                                            <>
                                            <Button size="sm" className="bg-green-500/20 text-green-400 hover:bg-green-500/30 mr-2"><Check className="h-4 w-4 mr-1"/>Vote For</Button>
                                            <Button size="sm" className="bg-red-500/20 text-red-400 hover:bg-red-500/30"><X className="h-4 w-4 mr-1"/>Vote Against</Button>
                                            </>
                                        )}
                                    </TableCell>
                                </TableRow>
                            )
                        })}
                    </TableBody>
                </Table>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}