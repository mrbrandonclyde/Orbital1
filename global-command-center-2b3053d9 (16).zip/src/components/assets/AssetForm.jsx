import React, { useState, useEffect } from 'react';
import { Asset } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function AssetForm({ asset, onSave, onCancel }) {
  const [currentAsset, setCurrentAsset] = useState({
    asset_name: '',
    asset_category: 'Infrastructure',
    asset_type: 'PHYSICAL',
    description: '',
    current_value_usd: 0,
    location: '',
    risk_level: 'LOW'
  });

  useEffect(() => {
    if (asset) {
      setCurrentAsset(asset);
    }
  }, [asset]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setCurrentAsset(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) : value }));
  };

  const handleSelectChange = (name, value) => {
    setCurrentAsset(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(currentAsset);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-6 bg-[#0A0D18]/80 rounded-xl border border-gray-700">
      <div className="space-y-2">
        <Label htmlFor="asset_name" className="text-white">Asset Name</Label>
        <Input id="asset_name" name="asset_name" value={currentAsset.asset_name} onChange={handleChange} placeholder="e.g., Orbital Data Center 7" className="bg-[#0C0F19] border-gray-600" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="description" className="text-white">Description</Label>
        <Textarea id="description" name="description" value={currentAsset.description} onChange={handleChange} placeholder="Detailed description of the asset..." className="bg-[#0C0F19] border-gray-600"/>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="space-y-2">
          <Label htmlFor="asset_category" className="text-white">Category</Label>
          <Select name="asset_category" value={currentAsset.asset_category} onValueChange={(value) => handleSelectChange('asset_category', value)}>
            <SelectTrigger id="asset_category" className="bg-[#0C0F19] border-gray-600"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Equities">Equities</SelectItem>
              <SelectItem value="Real Estate">Real Estate</SelectItem>
              <SelectItem value="Intellectual Property">Intellectual Property</SelectItem>
              <SelectItem value="Commodities">Commodities</SelectItem>
              <SelectItem value="Infrastructure">Infrastructure</SelectItem>
              <SelectItem value="Digital Currency">Digital Currency</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="current_value_usd" className="text-white">Value (USD)</Label>
          <Input id="current_value_usd" name="current_value_usd" type="number" value={currentAsset.current_value_usd} onChange={handleChange} placeholder="1000000" className="bg-[#0C0F19] border-gray-600" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="risk_level" className="text-white">Risk Level</Label>
          <Select name="risk_level" value={currentAsset.risk_level} onValueChange={(value) => handleSelectChange('risk_level', value)}>
            <SelectTrigger id="risk_level" className="bg-[#0C0F19] border-gray-600"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="LOW">Low</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="CRITICAL">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" className="orbital-button-primary">Save Asset</Button>
      </div>
    </form>
  );
}