import React from 'react';
import { Activity, Globe, Shield, Zap } from 'lucide-react';

export default function GlobalHUD() {
  return (
    <div className="fixed top-4 left-4 right-4 z-50 pointer-events-none">
      <div className="flex justify-between items-start">
        {/* Top Left - System Status */}
        <div className="bg-black/70 backdrop-blur-sm border border-gray-700 rounded-lg p-3 pointer-events-auto">
          <div className="flex items-center space-x-2 text-green-400 text-sm">
            <Activity className="w-4 h-4 animate-pulse" />
            <span>GLOBAL COMMAND ONLINE</span>
          </div>
        </div>

        {/* Top Right - Quick Status */}
        <div className="bg-black/70 backdrop-blur-sm border border-gray-700 rounded-lg p-3 pointer-events-auto">
          <div className="flex items-center space-x-4 text-xs">
            <div className="flex items-center space-x-1">
              <Shield className="w-3 h-3 text-green-400" />
              <span className="text-green-400">SECURE</span>
            </div>
            <div className="flex items-center space-x-1">
              <Zap className="w-3 h-3 text-blue-400" />
              <span className="text-blue-400">POWERED</span>
            </div>
            <div className="flex items-center space-x-1">
              <Globe className="w-3 h-3 text-purple-400" />
              <span className="text-purple-400">CONNECTED</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}