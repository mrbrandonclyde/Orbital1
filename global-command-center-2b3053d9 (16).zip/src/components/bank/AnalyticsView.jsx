import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, DollarSign, Target, BarChart3, PieChart as PieChartIcon, Activity, Calendar, Download } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area } from 'recharts';

// Enhanced Analytics Data
const monthlySpendingTrends = [
  { month: 'Jan', spending: 2400000, income: 4200000, profit: 1800000 },
  { month: 'Feb', spending: 2200000, income: 3800000, profit: 1600000 },
  { month: 'Mar', spending: 2800000, income: 5100000, profit: 2300000 },
  { month: 'Apr', spending: 2600000, income: 4600000, profit: 2000000 },
  { month: 'May', spending: 3000000, income: 5300000, profit: 2300000 },
  { month: 'Jun', spending: 2750000, income: 4900000, profit: 2150000 }
];

const categorySpending = [
  { category: 'Operations', amount: 8500000, percentage: 35, fill: '#8B5CF6' },
  { category: 'Personnel', amount: 6200000, percentage: 26, fill: '#06B6D4' },
  { category: 'Infrastructure', amount: 4800000, percentage: 20, fill: '#10B981' },
  { category: 'R&D', amount: 2900000, percentage: 12, fill: '#F59E0B' },
  { category: 'Marketing', amount: 1600000, percentage: 7, fill: '#EF4444' }
];

const departmentPerformance = [
  { department: 'Sales', budget: 2000000, spent: 1650000, efficiency: 82.5 },
  { department: 'Engineering', budget: 3500000, spent: 3200000, efficiency: 91.4 },
  { department: 'Marketing', budget: 1500000, spent: 1380000, efficiency: 92.0 },
  { department: 'Operations', budget: 4000000, spent: 3750000, efficiency: 93.8 },
  { department: 'Support', budget: 800000, spent: 720000, efficiency: 90.0 }
];

const cashFlowData = [
  { week: 'W1', inflow: 1200000, outflow: 850000, net: 350000 },
  { week: 'W2', inflow: 1100000, outflow: 950000, net: 150000 },
  { week: 'W3', inflow: 1350000, outflow: 900000, net: 450000 },
  { week: 'W4', inflow: 1250000, outflow: 875000, net: 375000 }
];

const investmentPortfolio = [
  { asset: 'Technology Stocks', value: 5200000, change: 12.3, fill: '#8B5CF6' },
  { asset: 'Real Estate', value: 8900000, change: 8.7, fill: '#10B981' },
  { asset: 'Bonds', value: 3400000, change: 3.2, fill: '#06B6D4' },
  { asset: 'Commodities', value: 2100000, change: -2.1, fill: '#F59E0B' },
  { asset: 'Crypto Assets', value: 1800000, change: 15.8, fill: '#EF4444' }
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {`${entry.name}: $${typeof entry.value === 'number' ? (entry.value / 1000000).toFixed(1) + 'M' : entry.value}`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function AnalyticsView({ data }) {
  const [timeframe, setTimeframe] = useState('6months');
  const [analyticsView, setAnalyticsView] = useState('overview');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Financial Analytics</h1>
          <p className="text-gray-400 mt-1">Advanced financial analytics and performance insights.</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1month">Last Month</SelectItem>
              <SelectItem value="3months">Last 3 Months</SelectItem>
              <SelectItem value="6months">Last 6 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Select value={analyticsView} onValueChange={setAnalyticsView}>
            <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="overview">Overview</SelectItem>
              <SelectItem value="spending">Spending Analysis</SelectItem>
              <SelectItem value="performance">Performance</SelectItem>
              <SelectItem value="forecasting">Forecasting</SelectItem>
            </SelectContent>
          </Select>
          <Button className="orbital-button-primary">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="glass-pane border-green-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Profit</p>
                <p className="text-2xl font-bold text-green-400">$12.1M</p>
                <p className="text-green-400 text-xs">+15.3% vs last period</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-pane border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Avg Monthly Spending</p>
                <p className="text-2xl font-bold text-blue-400">$2.7M</p>
                <p className="text-blue-400 text-xs">-3.2% efficiency gain</p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-pane border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">ROI Performance</p>
                <p className="text-2xl font-bold text-purple-400">18.7%</p>
                <p className="text-purple-400 text-xs">Above target by 3.7%</p>
              </div>
              <Target className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-pane border-cyan-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Cash Flow Health</p>
                <p className="text-2xl font-bold text-cyan-400">Excellent</p>
                <p className="text-cyan-400 text-xs">95% liquidity score</p>
              </div>
              <Activity className="w-8 h-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending vs Income Trends */}
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-green-400" />
              Income vs Spending Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlySpendingTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="income" stackId="1" name="Income" stroke="#10B981" fill="#10B981" fillOpacity={0.3} />
                <Area type="monotone" dataKey="spending" stackId="2" name="Spending" stroke="#EF4444" fill="#EF4444" fillOpacity={0.3} />
                <Line type="monotone" dataKey="profit" name="Net Profit" stroke="#06B6D4" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Spending Breakdown */}
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChartIcon className="w-5 h-5 mr-2 text-purple-400" />
              Spending by Category
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categorySpending}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={40}
                  dataKey="amount"
                  label={({ category, percentage }) => `${category} ${percentage}%`}
                >
                  {categorySpending.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Department Performance */}
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="w-5 h-5 mr-2 text-blue-400" />
              Department Efficiency
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="department" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="efficiency" name="Efficiency %" fill="#06B6D4" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Cash Flow Trends */}
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-cyan-400" />
              Weekly Cash Flow
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={cashFlowData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="week" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line type="monotone" dataKey="inflow" name="Cash Inflow" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="outflow" name="Cash Outflow" stroke="#EF4444" strokeWidth={2} />
                <Line type="monotone" dataKey="net" name="Net Cash Flow" stroke="#8B5CF6" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Investment Portfolio Analysis */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-emerald-400" />
            Investment Portfolio Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {investmentPortfolio.map((investment, index) => (
              <div key={index} className="text-center p-4 bg-gray-800/30 rounded-lg">
                <p className="text-gray-400 text-sm">{investment.asset}</p>
                <p className="text-lg font-bold text-white">${(investment.value / 1000000).toFixed(1)}M</p>
                <p className={`text-sm ${investment.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {investment.change > 0 ? '+' : ''}{investment.change}%
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}