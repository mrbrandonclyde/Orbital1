import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Mail, MessageSquare, Clock, Share2, GitBranch, GitMerge, Star, Square, Move } from "lucide-react";

const PALETTE = [
  { id: "p_email", type: "EMAIL", label: "Email", icon: Mail },
  { id: "p_sms", type: "SMS", label: "SMS", icon: MessageSquare },
  { id: "p_delay", type: "DELAY", label: "Delay", icon: Clock },
  { id: "p_webhook", type: "WEBHOOK", label: "Webhook", icon: Share2 },
  { id: "p_if", type: "IF_ELSE", label: "If / Else", icon: GitMerge },
  { id: "p_ab", type: "AB_SPLIT", label: "A/B Split", icon: GitBranch },
  { id: "p_score", type: "LEAD_SCORE", label: "Lead Score", icon: Star },
  { id: "p_end", type: "END", label: "End", icon: Square }
];

export default function AutomationBuilder({ steps = [], onChange, selectedId, onSelect }) {
  const addNode = (type, index) => {
    const id = `${type}-${Date.now()}`;
    const node = { id, type, config: defaultConfig(type) };
    const next = Array.from(steps);
    next.splice(index, 0, node);
    onChange(next);
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const { source, destination, draggableId } = result;
    // Palette to canvas
    if (source.droppableId === "palette" && destination.droppableId === "canvas") {
      const type = draggableId.replace("p_", "").toUpperCase();
      addNode(type, destination.index);
      return;
    }
    // Reorder canvas
    if (source.droppableId === "canvas" && destination.droppableId === "canvas") {
      const next = Array.from(steps);
      const [moved] = next.splice(source.index, 1);
      next.splice(destination.index, 0, moved);
      onChange(next);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card className="md:col-span-1 bg-[#0A0D18]/50 border-gray-800">
        <CardHeader><CardTitle className="text-white text-base">Tools</CardTitle></CardHeader>
        <CardContent>
          <Droppable droppableId="palette" isDropDisabled>
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps}>
                {PALETTE.map((p, idx) => {
                  const Icon = p.icon;
                  return (
                    <Draggable draggableId={p.id} index={idx} key={p.id}>
                      {(drag) => (
                        <div ref={drag.innerRef} {...drag.draggableProps} {...drag.dragHandleProps} className="flex items-center gap-2 p-2 mb-2 bg-gray-800/40 border border-gray-700 rounded text-white">
                          <Icon className="w-4 h-4 text-cyan-400" />
                          <span>{p.label}</span>
                        </div>
                      )}
                    </Draggable>
                  );
                })}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </CardContent>
      </Card>

      <Card className="md:col-span-3 bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="flex items-center justify-between">
          <CardTitle className="text-white text-base">Sequence</CardTitle>
          <div className="text-xs text-gray-400">Drag from tools into the flow</div>
        </CardHeader>
        <CardContent>
          <DragDropContext onDragEnd={onDragEnd} />
          <Droppable droppableId="canvas">
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps} className="min-h-[240px] border border-gray-800 rounded-lg p-3">
                {steps.map((n, idx) => (
                  <Draggable key={n.id} draggableId={n.id} index={idx}>
                    {(drag) => (
                      <div
                        ref={drag.innerRef}
                        {...drag.draggableProps}
                        {...drag.dragHandleProps}
                        onClick={() => onSelect(n)}
                        className={`mb-2 p-3 rounded-lg border ${selectedId === n.id ? "border-cyan-500 bg-cyan-500/10" : "border-gray-800 bg-gray-800/30"} cursor-pointer`}
                      >
                        <div className="flex items-center gap-2">
                          <Move className="w-4 h-4 text-gray-500" />
                          <StepBadge type={n.type} />
                          <div className="text-white text-sm flex-1 truncate">{labelFor(n)}</div>
                          <span className="text-xs text-gray-500">#{idx + 1}</span>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
                {!steps.length && (
                  <div className="text-gray-500 text-sm text-center py-8">Drag steps here to build your automation.</div>
                )}
              </div>
            )}
          </Droppable>
        </CardContent>
      </Card>
    </div>
  );
}

function StepBadge({ type }) {
  const map = {
    EMAIL: { icon: Mail, color: "bg-blue-500/20 text-blue-300", label: "Email" },
    SMS: { icon: MessageSquare, color: "bg-green-500/20 text-green-300", label: "SMS" },
    DELAY: { icon: Clock, color: "bg-yellow-500/20 text-yellow-300", label: "Delay" },
    WEBHOOK: { icon: Share2, color: "bg-purple-500/20 text-purple-300", label: "Webhook" },
    IF_ELSE: { icon: GitMerge, color: "bg-orange-500/20 text-orange-300", label: "If/Else" },
    AB_SPLIT: { icon: GitBranch, color: "bg-pink-500/20 text-pink-300", label: "A/B Split" },
    LEAD_SCORE: { icon: Star, color: "bg-amber-500/20 text-amber-300", label: "Lead Score" },
    END: { icon: Square, color: "bg-gray-500/20 text-gray-300", label: "End" }
  };
  const meta = map[type] || { icon: Square, color: "bg-gray-500/20 text-gray-300", label: type };
  const Icon = meta.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded ${meta.color}`}>
      <Icon className="w-3 h-3" /> {meta.label}
    </span>
  );
}

function labelFor(n) {
  switch (n.type) {
    case "EMAIL": return n.config?.subject || "Email step";
    case "SMS": return (n.config?.message || "SMS message").slice(0, 40);
    case "DELAY": return `Wait ${n.config?.amount || 1} ${n.config?.unit || "hours"}`;
    case "WEBHOOK": return n.config?.url || "Webhook call";
    case "IF_ELSE": return n.config?.condition || "If condition";
    case "AB_SPLIT": return `A/B (${(n.config?.a_weight ?? 50)}% / ${(n.config?.b_weight ?? 50)}%)`;
    case "LEAD_SCORE": return `${n.config?.points || 0} points`;
    case "END": return "End";
    default: return n.type;
  }
}

function defaultConfig(type) {
  if (type === "EMAIL") return { subject: "Welcome!", body: "Thanks for joining.", from_name: "Your Brand" };
  if (type === "SMS") return { message: "Thanks for joining!", sender_id: "BRAND" };
  if (type === "DELAY") return { amount: 1, unit: "hours" };
  if (type === "WEBHOOK") return { url: "", method: "POST", payload: {} };
  if (type === "IF_ELSE") return { condition: "tag == 'buyer'" };
  if (type === "AB_SPLIT") return { a_weight: 50, b_weight: 50 };
  if (type === "LEAD_SCORE") return { points: 5, reason: "Engagement" };
  return {};
}