import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function NodeConfigPanel({ node, onChange }) {
  if (!node) {
    return (
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader><CardTitle className="text-white text-base">Step Settings</CardTitle></CardHeader>
        <CardContent className="text-gray-400 text-sm">Select a step to configure it.</CardContent>
      </Card>
    );
  }

  const set = (patch) => onChange({ ...node, config: { ...(node.config || {}), ...patch } });

  return (
    <Card className="bg-[#0A0D18]/50 border-gray-800">
      <CardHeader><CardTitle className="text-white text-base">Step Settings — {node.type}</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        {node.type === "EMAIL" && (
          <>
            <div>
              <Label className="text-gray-300">Subject</Label>
              <Input value={node.config?.subject || ""} onChange={(e) => set({ subject: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">From Name</Label>
              <Input value={node.config?.from_name || ""} onChange={(e) => set({ from_name: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">Body</Label>
              <Textarea value={node.config?.body || ""} onChange={(e) => set({ body: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 h-40" />
            </div>
          </>
        )}

        {node.type === "SMS" && (
          <>
            <div>
              <Label className="text-gray-300">Message</Label>
              <Textarea value={node.config?.message || ""} onChange={(e) => set({ message: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 h-28" />
            </div>
            <div>
              <Label className="text-gray-300">Sender ID</Label>
              <Input value={node.config?.sender_id || ""} onChange={(e) => set({ sender_id: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
          </>
        )}

        {node.type === "DELAY" && (
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <Label className="text-gray-300">Amount</Label>
              <Input type="number" min={0} value={node.config?.amount || 0} onChange={(e) => set({ amount: Number(e.target.value || 0) })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">Unit</Label>
              <Input value={node.config?.unit || "hours"} onChange={(e) => set({ unit: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
          </div>
        )}

        {node.type === "WEBHOOK" && (
          <>
            <div>
              <Label className="text-gray-300">URL</Label>
              <Input value={node.config?.url || ""} onChange={(e) => set({ url: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">Method</Label>
              <Input value={node.config?.method || "POST"} onChange={(e) => set({ method: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
          </>
        )}

        {node.type === "IF_ELSE" && (
          <div>
            <Label className="text-gray-300">Condition (expression)</Label>
            <Input value={node.config?.condition || ""} onChange={(e) => set({ condition: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
          </div>
        )}

        {node.type === "AB_SPLIT" && (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-gray-300">A Weight %</Label>
              <Input type="number" min={0} max={100} value={node.config?.a_weight ?? 50} onChange={(e) => set({ a_weight: Number(e.target.value || 0) })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">B Weight %</Label>
              <Input type="number" min={0} max={100} value={node.config?.b_weight ?? 50} onChange={(e) => set({ b_weight: Number(e.target.value || 0) })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
          </div>
        )}

        {node.type === "LEAD_SCORE" && (
          <>
            <div>
              <Label className="text-gray-300">Points</Label>
              <Input type="number" value={node.config?.points || 0} onChange={(e) => set({ points: Number(e.target.value || 0) })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
            <div>
              <Label className="text-gray-300">Reason</Label>
              <Input value={node.config?.reason || ""} onChange={(e) => set({ reason: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}