import React from "react";

export default function ForecastOverlay() {
  return (
    <div className="bg-gray-800 text-white p-4 rounded-lg shadow-lg h-full">
      {/* 🤖 AI Forecast Overlay */}
      <h3 className="text-lg font-bold">Forecasts</h3>
      <ul className="mt-2 text-sm">
        <li>📈 GDP Growth: +3.2%</li>
        <li>⚡ Threat Level: Elevated</li>
      </ul>
      {/* TODO: Connect AI API (Vertex AI, OpenAI, HuggingFace) */}
    </div>
  );
}