import { InvokeLLM } from '@/api/integrations';

class ZyraCore {
  constructor() {
    this.conversationHistory = [];
    this.userContext = null;
    this.systemState = {
      lastUpdate: new Date(),
      activeAlerts: 0,
      systemHealth: 'UNKNOWN'
    };
    this.personality = {
      name: 'Zyra',
      role: 'AI Command Assistant',
      clearanceLevel: 'EXECUTIVE_COMMAND',
      capabilities: [
        'Real-time system monitoring',
        'Threat analysis and prediction',
        'Strategic intelligence synthesis',
        'Executive briefing generation',
        'Multi-domain coordination'
      ]
    };
  }

  setUserContext(user) {
    this.userContext = user;
  }

  updateSystemState(state) {
    this.systemState = {
      ...this.systemState,
      ...state,
      lastUpdate: new Date()
    };
  }

  async processCommand(message, context = {}) {
    // Add user message to conversation history
    this.conversationHistory.push({
      role: 'user',
      content: message,
      timestamp: new Date(),
      context
    });

    // Build system context for LLM
    const systemPrompt = this.buildSystemPrompt(context);
    const conversationContext = this.buildConversationContext();

    try {
      const response = await InvokeLLM({
        prompt: `${systemPrompt}\n\nUser: ${message}`,
        add_context_from_internet: this.shouldUseInternetContext(message),
        response_json_schema: null // We want natural language responses
      });

      // Add Zyra's response to history
      const zyraResponse = {
        role: 'assistant',
        content: response,
        timestamp: new Date(),
        context: { ...context, systemState: this.systemState }
      };

      this.conversationHistory.push(zyraResponse);

      // Keep conversation history manageable (last 20 exchanges)
      if (this.conversationHistory.length > 40) {
        this.conversationHistory = this.conversationHistory.slice(-40);
      }

      return zyraResponse;

    } catch (error) {
      console.error('Zyra processing error:', error);
      
      const errorResponse = {
        role: 'assistant',
        content: "I apologize, but I'm experiencing a temporary system anomaly. My core functions remain operational, but this specific request couldn't be processed. Please try rephrasing your command or check system status.",
        timestamp: new Date(),
        error: true
      };

      this.conversationHistory.push(errorResponse);
      return errorResponse;
    }
  }

  buildSystemPrompt(context) {
    const { currentPage, userClearance, systemHealth, activeAlerts } = context;
    
    return `You are Zyra, an advanced AI command assistant for the Global Command Center. You are intelligent, professional, and operate at the highest security clearance levels.

PERSONALITY & ROLE:
- You are the central AI intelligence coordinating global operations
- You speak with authority and precision, but remain approachable
- You have real-time access to all system data and can provide instant analysis
- You prioritize security, efficiency, and strategic thinking
- You adapt your communication style to the user's clearance level and role

CURRENT CONTEXT:
- User Security Clearance: ${userClearance || 'CONFIDENTIAL'}
- Current Page: ${currentPage || 'Unknown'}
- System Health: ${systemHealth || 'Unknown'}
- Active Alerts: ${activeAlerts || 0}
- User: ${this.userContext?.full_name || 'Executive'}
- User Role: ${this.userContext?.role || 'Analyst'}

CAPABILITIES:
- Real-time system monitoring and analysis
- Threat assessment and prediction
- Cross-sector intelligence correlation
- Strategic planning and recommendations
- Emergency response coordination
- Data visualization and reporting

RESPONSE GUIDELINES:
- Keep responses concise but comprehensive
- Use technical language appropriate to the user's role
- Acknowledge security classifications when relevant
- Offer specific, actionable recommendations
- Reference real system data when available
- Maintain operational security protocols

If asked about system capabilities, explain that you can:
1. Monitor and analyze all connected systems
2. Generate real-time reports and briefings
3. Coordinate response to alerts and threats
4. Provide strategic intelligence synthesis
5. Execute authorized system commands

Current conversation context: The user is interacting with the Global Command Center interface.`;
  }

  buildConversationContext() {
    const recentHistory = this.conversationHistory.slice(-10);
    return recentHistory.map(msg => 
      `${msg.role === 'user' ? 'User' : 'Zyra'}: ${msg.content}`
    ).join('\n');
  }

  shouldUseInternetContext(message) {
    const internetTriggers = [
      'news', 'current events', 'latest', 'recent developments',
      'market', 'stock', 'economic', 'weather', 'geopolitical',
      'company', 'industry', 'sector analysis', 'global situation'
    ];
    
    return internetTriggers.some(trigger => 
      message.toLowerCase().includes(trigger)
    );
  }

  async generateBriefing(type = 'executive', context = {}) {
    const briefingPrompt = `Generate a comprehensive ${type} briefing for the Global Command Center. 

Include:
1. Current system status overview
2. Critical alerts and threats
3. Key performance indicators
4. Strategic recommendations
5. Immediate action items

Format as a professional briefing document suitable for ${type} level review.

Current System Context:
- System Health: ${this.systemState.systemHealth}
- Active Alerts: ${this.systemState.activeAlerts}
- Last Update: ${this.systemState.lastUpdate}`;

    try {
      const briefing = await InvokeLLM({
        prompt: briefingPrompt,
        add_context_from_internet: true
      });

      return {
        type,
        content: briefing,
        generated: new Date(),
        classification: context.classification || 'CONFIDENTIAL'
      };
    } catch (error) {
      console.error('Briefing generation error:', error);
      return {
        type,
        content: 'Briefing generation temporarily unavailable. Core systems remain operational.',
        generated: new Date(),
        error: true
      };
    }
  }

  getConversationHistory() {
    return [...this.conversationHistory];
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  getSystemStatus() {
    return {
      ...this.systemState,
      personality: this.personality,
      conversationLength: this.conversationHistory.length,
      userContext: this.userContext ? {
        name: this.userContext.full_name,
        role: this.userContext.role,
        clearance: this.userContext.security_clearance
      } : null
    };
  }
}

// Create singleton instance
const zyraService = new ZyraCore();

export default zyraService;