import React from "react";
import { Bell, LayoutDashboard } from "lucide-react";

export default function HeaderFrame({ title = "Dashboard", subtitle = "", right }) {
  return (
    <div className="flex items-center justify-between pb-4">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
          <LayoutDashboard className="w-5 h-5 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-white">{title}</h1>
          {subtitle ? <p className="text-xs md:text-sm text-gray-400">{subtitle}</p> : null}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <button className="px-3 py-2 rounded-lg bg-[#0C0F19] border border-gray-700 text-gray-300 hover:text-white">
          <Bell className="w-4 h-4" />
        </button>
        {right}
      </div>
    </div>
  );
}