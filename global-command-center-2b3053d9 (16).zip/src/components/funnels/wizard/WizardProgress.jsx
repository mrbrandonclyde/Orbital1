import React from "react";

const steps = [
  { id: 1, label: "Type" },
  { id: 2, label: "Goal" },
  { id: 3, label: "Template" },
  { id: 4, label: "Setup" },
  { id: 5, label: "Confirm" }
];

export default function WizardProgress({ current }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      {steps.map((s, idx) => {
        const active = s.id === current;
        const done = s.id < current;
        return (
          <div key={s.id} className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold border
              ${active ? 'bg-indigo-600 text-white border-indigo-500' : done ? 'bg-green-600 text-white border-green-500' : 'bg-[#0C0F19] text-gray-400 border-gray-700'}
            `}>
              {s.id}
            </div>
            <div className={`ml-2 mr-4 text-sm ${active ? 'text-white' : 'text-gray-400'}`}>{s.label}</div>
            {idx < steps.length - 1 && <div className="w-10 h-1 rounded bg-gray-700 mx-1"></div>}
          </div>
        );
      })}
    </div>
  );
}