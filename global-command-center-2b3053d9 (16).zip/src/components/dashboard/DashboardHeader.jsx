import React from 'react';
import { Globe, Activity, Shield } from 'lucide-react';

export default function DashboardHeader() {
  return (
    <div className="orbital-page-header">
      <div>
        <h1 className="orbital-page-title flex items-center">
          <Globe className="w-10 h-10 mr-3 text-cyan-400" />
          Global Command Center
        </h1>
        <p className="orbital-page-subtitle">
          Real-time intelligence monitoring and strategic operations oversight.
        </p>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="orbital-flex-center space-x-2 bg-green-500/10 border border-green-500/20 rounded px-3 py-1">
          <Activity className="w-4 h-4 text-green-400" />
          <span className="text-green-400 font-semibold text-sm">OPERATIONAL</span>
        </div>
        <div className="orbital-flex-center space-x-2 bg-blue-500/10 border border-blue-500/20 rounded px-3 py-1">
          <Shield className="w-4 h-4 text-blue-400" />
          <span className="text-blue-400 font-semibold text-sm">SECURE</span>
        </div>
      </div>
    </div>
  );
}