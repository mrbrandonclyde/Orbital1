import React from 'react';
import { Crown, TrendingUp, Shield, Award } from 'lucide-react';

export default function ExecutiveProfile({ user, metrics }) {
  const performanceScore = metrics?.strategicAlignment || 89.1;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 h-full">
      {/* Profile Header */}
      <div className="flex items-center space-x-4 mb-6">
        <div className="relative">
          <img
            src={user?.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.full_name || 'Executive')}&background=4F46E5&color=fff`}
            alt="Executive"
            className="w-16 h-16 rounded-full object-cover border-3 border-indigo-500"
          />
          <div className="absolute -bottom-1 -right-1 bg-indigo-600 rounded-full p-1">
            <Crown className="w-3 h-3 text-white" />
          </div>
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{user?.full_name || 'Executive'}</h3>
          <p className="text-indigo-600 dark:text-indigo-400 font-medium">{user?.title || 'Chief Executive Officer'}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">{user?.security_clearance || 'EXECUTIVE_COMMAND'}</p>
        </div>
      </div>

      {/* Performance Indicators */}
      <div className="space-y-4">
        <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <div className="flex items-center space-x-2">
            <Award className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Strategic Alignment</span>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900 dark:text-white">{performanceScore.toFixed(1)}%</div>
            <div className="flex items-center text-green-600">
              <TrendingUp className="w-3 h-3 mr-1" />
              <span className="text-xs">+2.3% vs Q3</span>
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Risk Management</span>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900 dark:text-white">{metrics?.riskScore?.toFixed(0) || 95}</div>
            <div className="text-xs text-green-600">Optimal Range</div>
          </div>
        </div>

        <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Operational Excellence</span>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900 dark:text-white">{metrics?.operationalEfficiency?.toFixed(1) || 94.2}%</div>
            <div className="text-xs text-purple-600">Above Target</div>
          </div>
        </div>
      </div>

      {/* Executive Actions */}
      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Quick Actions</h4>
        <div className="space-y-2">
          <button className="w-full text-left px-3 py-2 text-sm bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors">
            Generate Board Report
          </button>
          <button className="w-full text-left px-3 py-2 text-sm bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded hover:bg-green-100 dark:hover:bg-green-900/50 transition-colors">
            Review Strategic Initiatives
          </button>
          <button className="w-full text-left px-3 py-2 text-sm bg-orange-50 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 rounded hover:bg-orange-100 dark:hover:bg-orange-900/50 transition-colors">
            Risk Assessment Review
          </button>
        </div>
      </div>
    </div>
  );
}