import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Users, Target, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const kpiData = Array.from({ length: 12 }, (_, i) => ({
  month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
  revenue: 125000 + i * 8500 + Math.random() * 15000,
  efficiency: 85 + i * 0.8 + Math.random() * 5,
  growth: 12 + Math.random() * 8,
  satisfaction: 88 + Math.random() * 10
}));

const kpiMetrics = [
  {
    id: 'revenue',
    name: 'Total Revenue',
    value: '$147.2M',
    change: '+12.7%',
    trend: 'up',
    icon: DollarSign,
    color: 'text-green-600'
  },
  {
    id: 'efficiency',
    name: 'Operational Efficiency', 
    value: '94.2%',
    change: '+2.3%',
    trend: 'up',
    icon: Zap,
    color: 'text-blue-600'
  },
  {
    id: 'growth',
    name: 'YoY Growth',
    value: '18.4%',
    change: '+1.2%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-purple-600'
  },
  {
    id: 'satisfaction',
    name: 'Stakeholder Score',
    value: '92.1',
    change: '-0.8%',
    trend: 'down',
    icon: Users,
    color: 'text-orange-600'
  }
];

export default function StrategicKPIs({ metrics, timeframe, selectedKPI, onKPISelect }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 h-full">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Strategic KPIs</h3>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Period: {timeframe}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpiMetrics.map((kpi) => {
          const Icon = kpi.icon;
          const isSelected = selectedKPI === kpi.id;
          
          return (
            <div
              key={kpi.id}
              onClick={() => onKPISelect(kpi.id)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                isSelected
                  ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-5 h-5 ${kpi.color}`} />
                <div className={`flex items-center text-sm ${
                  kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {kpi.trend === 'up' ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                  {kpi.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{kpi.value}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">{kpi.name}</div>
            </div>
          );
        })}
      </div>

      {/* Trend Chart */}
      <div className="h-64">
        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          {kpiMetrics.find(k => k.id === selectedKPI)?.name || 'Revenue'} Trend
        </h4>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={kpiData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="month" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1f2937', 
                border: 'none', 
                borderRadius: '8px',
                color: '#fff'
              }}
            />
            <Line 
              type="monotone" 
              dataKey={selectedKPI} 
              stroke="#4f46e5" 
              strokeWidth={3}
              dot={{ fill: '#4f46e5', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6, stroke: '#4f46e5', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}