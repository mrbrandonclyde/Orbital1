import React, { useState } from 'react';
import { BarChart3, TrendingUp, Activity, Globe, Database, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

const analyticsMetrics = [
  { title: "Data Points Processed", value: "2.4M", icon: Database, color: "text-blue-400" },
  { title: "Prediction Accuracy", value: "94.7%", icon: TrendingUp, color: "text-green-400" },
  { title: "Real-time Streams", value: "847", icon: Activity, color: "text-purple-400" },
  { title: "Global Coverage", value: "189 Countries", icon: Globe, color: "text-cyan-400" },
  { title: "Processing Speed", value: "< 50ms", icon: Zap, color: "text-yellow-400" },
];

const trendData = [
  { month: 'Jan', alerts: 245, predictions: 89, accuracy: 92 },
  { month: 'Feb', alerts: 312, predictions: 156, accuracy: 94 },
  { month: 'Mar', alerts: 278, predictions: 203, accuracy: 96 },
  { month: 'Apr', alerts: 389, predictions: 287, accuracy: 93 },
  { month: 'May', alerts: 456, predictions: 334, accuracy: 95 },
  { month: 'Jun', alerts: 523, predictions: 398, accuracy: 97 }
];

const sectorData = [
  { name: 'Technology', value: 35, color: '#8B5CF6' },
  { name: 'Finance', value: 25, color: '#06B6D4' },
  { name: 'Defense', value: 20, color: '#EF4444' },
  { name: 'Energy', value: 15, color: '#F59E0B' },
  { name: 'Healthcare', value: 5, color: '#10B981' }
];

const threatData = [
  { region: 'North America', cyber: 45, geopolitical: 12, economic: 23 },
  { region: 'Europe', cyber: 38, geopolitical: 28, economic: 19 },
  { region: 'Asia Pacific', cyber: 52, geopolitical: 35, economic: 41 },
  { region: 'Middle East', cyber: 23, geopolitical: 67, economic: 28 },
  { region: 'Africa', cyber: 15, geopolitical: 43, economic: 35 }
];

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState('6M');
  const [selectedMetric, setSelectedMetric] = useState('all');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <BarChart3 className="w-10 h-10 mr-3 text-purple-400" />
            Global Analytics Engine
          </h1>
          <p className="orbital-text-subtitle">AI-powered predictive analytics and strategic intelligence insights.</p>
        </div>
        <div className="flex space-x-2">
          <Badge className="bg-green-500/20 text-green-400">LIVE DATA</Badge>
          <Badge className="bg-blue-500/20 text-blue-400">94.7% ACCURACY</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {analyticsMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Predictive Analytics Trends</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Area type="monotone" dataKey="predictions" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="alerts" stroke="#06B6D4" fill="#06B6D4" fillOpacity={0.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Sector Analysis Distribution</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {sectorData.map((sector, i) => (
              <div key={i} className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: sector.color }}></div>
                <span className="text-sm text-gray-300">{sector.name}</span>
                <span className="text-sm text-gray-500">{sector.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass-pane p-6 mb-6">
        <h3 className="orbital-text-subheading mb-4">Regional Threat Analysis</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={threatData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="region" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="cyber" fill="#8B5CF6" />
              <Bar dataKey="geopolitical" fill="#EF4444" />
              <Bar dataKey="economic" fill="#F59E0B" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-pane p-6">
          <h4 className="text-lg font-semibold text-white mb-4">AI Insights</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-500/10 rounded-lg">
              <span className="text-green-400 text-sm">Market Stability</span>
              <Badge className="bg-green-500/20 text-green-400">HIGH</Badge>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-500/10 rounded-lg">
              <span className="text-yellow-400 text-sm">Geopolitical Risk</span>
              <Badge className="bg-yellow-500/20 text-yellow-400">MODERATE</Badge>
            </div>
            <div className="flex items-center justify-between p-3 bg-red-500/10 rounded-lg">
              <span className="text-red-400 text-sm">Cyber Threats</span>
              <Badge className="bg-red-500/20 text-red-400">ELEVATED</Badge>
            </div>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h4 className="text-lg font-semibold text-white mb-4">Processing Stats</h4>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Data Ingestion</span>
                <span className="text-white">89%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '89%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Model Training</span>
                <span className="text-white">94%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '94%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Prediction Engine</span>
                <span className="text-white">97%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: '97%' }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h4 className="text-lg font-semibold text-white mb-4">Active Monitoring</h4>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-2 rounded">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-300">Global Markets</span>
              <Badge className="bg-green-500/20 text-green-400 ml-auto">ONLINE</Badge>
            </div>
            <div className="flex items-center space-x-3 p-2 rounded">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-300">Threat Intelligence</span>
              <Badge className="bg-green-500/20 text-green-400 ml-auto">ONLINE</Badge>
            </div>
            <div className="flex items-center space-x-3 p-2 rounded">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-300">Economic Indicators</span>
              <Badge className="bg-green-500/20 text-green-400 ml-auto">ONLINE</Badge>
            </div>
            <div className="flex items-center space-x-3 p-2 rounded">
              <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-300">Social Sentiment</span>
              <Badge className="bg-yellow-500/20 text-yellow-400 ml-auto">SYNCING</Badge>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}