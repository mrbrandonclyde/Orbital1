import React, { useState } from 'react';
import { Crown, TrendingUp, Shield, Globe, Users, BarChart3, Target, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const executiveMetrics = [
  { title: "Global Influence", value: "94.2%", icon: Globe, color: "text-purple-400", trend: "+2.1%" },
  { title: "Strategic Assets", value: "$847B", icon: TrendingUp, color: "text-green-400", trend: "+12.3%" },
  { title: "Personnel Strength", value: "15,847", icon: Users, color: "text-cyan-400", trend: "+5.2%" },
  { title: "Threat Mitigation", value: "98.7%", icon: Shield, color: "text-yellow-400", trend: "+1.8%" },
  { title: "Operational Efficiency", value: "97.1%", icon: Target, color: "text-blue-400", trend: "+3.4%" },
  { title: "AI Enhancement", value: "MAXIMUM", icon: Zap, color: "text-red-400", trend: "STABLE" }
];

const performanceData = [
  { month: 'Jan', influence: 89, assets: 720, efficiency: 92 },
  { month: 'Feb', influence: 91, assets: 745, efficiency: 94 },
  { month: 'Mar', influence: 90, assets: 768, efficiency: 95 },
  { month: 'Apr', influence: 93, assets: 789, efficiency: 96 },
  { month: 'May', influence: 94, assets: 812, efficiency: 97 },
  { month: 'Jun', influence: 94.2, assets: 847, efficiency: 97.1 }
];

const strategicPriorities = [
  {
    priority: "Global Economic Stabilization",
    status: "IN_PROGRESS",
    completion: 73,
    impact: "CRITICAL",
    timeline: "Q3 2024"
  },
  {
    priority: "Guardian Corps Expansion",
    status: "ACTIVE",
    completion: 89,
    impact: "HIGH",
    timeline: "Q4 2024"
  },
  {
    priority: "Interplanetary Infrastructure",
    status: "PLANNING",
    completion: 34,
    impact: "STRATEGIC",
    timeline: "2025"
  },
  {
    priority: "AI-Human Symbiosis Protocol",
    status: "RESEARCH",
    completion: 12,
    impact: "TRANSFORMATIVE",
    timeline: "2026"
  }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'IN_PROGRESS': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">IN PROGRESS</Badge>;
    case 'PLANNING': return <Badge className="bg-yellow-500/20 text-yellow-400">PLANNING</Badge>;
    case 'RESEARCH': return <Badge className="bg-purple-500/20 text-purple-400">RESEARCH</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getImpactBadge = (impact) => {
  switch (impact) {
    case 'TRANSFORMATIVE': return <Badge className="bg-red-500/20 text-red-400">TRANSFORMATIVE</Badge>;
    case 'CRITICAL': return <Badge className="bg-orange-500/20 text-orange-400">CRITICAL</Badge>;
    case 'STRATEGIC': return <Badge className="bg-purple-500/20 text-purple-400">STRATEGIC</Badge>;
    case 'HIGH': return <Badge className="bg-blue-500/20 text-blue-400">HIGH</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">MODERATE</Badge>;
  }
};

export default function ExecutivePage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Crown className="w-10 h-10 mr-3 text-purple-400" />
            Executive Command Interface
          </h1>
          <p className="orbital-text-subtitle">Strategic oversight, performance analytics, and global directive management.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-purple-500/10 border border-purple-500/20 rounded px-3 py-1">
            <span className="text-purple-400 font-semibold text-sm">EXECUTIVE ACCESS</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {executiveMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-purple-500/10 to-transparent rounded-full -mr-8 -mt-8"></div>
              <div className="flex justify-between items-start relative z-10">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white relative z-10">{metric.value}</p>
              <p className="text-xs text-green-400 mt-1 relative z-10">{metric.trend}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-cyan-400" />
            Executive Performance Metrics
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Line type="monotone" dataKey="influence" name="Global Influence %" stroke="#8B5CF6" strokeWidth={3} />
                <Line type="monotone" dataKey="efficiency" name="Operational Efficiency %" stroke="#06B6D4" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-yellow-400" />
            Strategic Priority Matrix
          </h3>
          <div className="space-y-4">
            {strategicPriorities.map((priority, i) => (
              <div key={i} className="p-4 bg-gray-800/30 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h4 className="font-semibold text-white mb-1">{priority.priority}</h4>
                    <div className="flex items-center space-x-2 mb-2">
                      {getStatusBadge(priority.status)}
                      {getImpactBadge(priority.impact)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-cyan-400">{priority.completion}%</div>
                    <div className="text-xs text-gray-400">{priority.timeline}</div>
                  </div>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-cyan-500 to-purple-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${priority.completion}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}