import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import BackendHealthBadge from "@/components/common/BackendHealthBadge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, RefreshCw } from "lucide-react";

export default function QueueTask() {
  const [name, setName] = React.useState("");
  const [result, setResult] = React.useState(null);
  const [loading, setLoading] = React.useState(false);

  const enqueue = async () => {
    if (!name) return;
    setLoading(true);
    const res = await SpeedBackend.tasks.enqueue(name);
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title">Queue Task (Redis RQ)</h1>
          <p className="orbital-text-subtitle">Push a job to the Redis queue via FastAPI.</p>
        </div>
        <BackendHealthBadge />
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Enqueue</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
            <Input placeholder="Name (e.g., Brandon)" value={name} onChange={(e) => setName(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-white md:col-span-3" />
            <Button onClick={enqueue} disabled={!name || loading} className="bg-indigo-600 hover:bg-indigo-700">
              <Send className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Enqueue
            </Button>
          </div>

          {result && (
            <div className="mt-4 text-gray-300 text-sm">
              <div className="mb-1">Job queued successfully:</div>
              <pre className="bg-black/30 p-3 rounded-lg border border-gray-800 overflow-auto">
{JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}