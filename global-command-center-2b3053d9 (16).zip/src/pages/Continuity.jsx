import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { RefreshCw, Truck, Target } from "lucide-react";

export default function ContinuityPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <RefreshCw className="w-10 h-10 mr-3 text-blue-400" />
          Continuity
        </h1>
        <p className="orbital-text-subtitle">Ops backup, supply chain, and mission resilience.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('SupplyChain')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Truck className="w-5 h-5 text-orange-400" />
            <h3 className="text-white font-semibold">Supply Chain</h3>
          </div>
          <p className="text-gray-400 text-sm">Risk and mitigation intelligence.</p>
        </Link>

        <Link to={createPageUrl('Missions')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Mission Resilience</h3>
          </div>
          <p className="text-gray-400 text-sm">Plans, tasks, and readiness.</p>
        </Link>
      </div>
    </div>
  );
}