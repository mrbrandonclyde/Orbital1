import React, { useState } from 'react';
import { Truck, AlertTriangle, TrendingUp, Filter, RefreshCw, X, Globe } from 'lucide-react';
import { SupplyChainRisk } from "@/api/entities";
import { BusinessSector } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ErrorBoundary from '../components/common/ErrorBoundary';

const riskLevelColors = {
  'CRITICAL': 'text-red-400 bg-red-500/10 border-red-500/20',
  'HIGH': 'text-orange-400 bg-orange-500/10 border-orange-500/20',
  'MEDIUM': 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
  'LOW': 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  'MINIMAL': 'text-green-400 bg-green-500/10 border-green-500/20'
};

const riskCategoryIcons = {
  'GEOPOLITICAL': '🌍',
  'NATURAL_DISASTER': '🌪️',
  'CYBER_ATTACK': '💻',
  'ECONOMIC': '💰',
  'REGULATORY': '📋',
  'SUPPLIER_FAILURE': '🏭',
  'QUALITY': '🔍',
  'LOGISTICS': '🚛',
  'TECHNOLOGY': '⚙️'
};

export default function SupplyChainPage() {
  const [selectedRisk, setSelectedRisk] = useState(null);
  const [filterRiskLevel, setFilterRiskLevel] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  const { data, loading, error, refetch } = useQuery(['supplyChainData'], async () => {
    const [risks, sectors] = await Promise.all([
      SupplyChainRisk.list('-last_assessment_date', 50),
      BusinessSector.list()
    ]);
    return { risks, sectors };
  });

  const filteredRisks = (data?.risks || []).filter(risk => {
    if (filterRiskLevel !== 'all' && risk.risk_level !== filterRiskLevel) return false;
    if (filterCategory !== 'all' && risk.risk_category !== filterCategory) return false;
    return true;
  });

  const sectorMap = Object.fromEntries((data?.sectors || []).map(s => [s.id, s]));

  const riskSummary = {
    total: filteredRisks.length,
    critical: filteredRisks.filter(r => r.risk_level === 'CRITICAL').length,
    high: filteredRisks.filter(r => r.risk_level === 'HIGH').length,
    monitored: filteredRisks.filter(r => r.is_active).length
  };

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409] p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="orbital-text-title flex items-center">
              <Truck className="w-10 h-10 mr-3 text-orange-400" />
              Supply Chain Risk Management
            </h1>
            <p className="orbital-text-subtitle">Monitor critical supply chain vulnerabilities and mitigation strategies.</p>
          </div>
          <div className="flex items-center space-x-4">
            <button onClick={refetch} className="orbital-button-secondary flex items-center space-x-2">
               <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh Intel</span>
            </button>
          </div>
        </div>

        {loading && !data && (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {error && (
          <div className="text-center py-12">
            <p className="text-red-500">Failed to load supply chain data.</p>
          </div>
        )}

        {!loading && !error && data && (
          <>
            {/* Risk Summary Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Risks</p>
                    <p className="text-3xl font-bold text-white">{riskSummary.total}</p>
                  </div>
                  <Truck className="w-8 h-8 text-blue-400" />
                </div>
              </div>
              
              <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Critical Risks</p>
                    <p className="text-3xl font-bold text-red-400">{riskSummary.critical}</p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-red-400" />
                </div>
              </div>

              <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">High Risk</p>
                    <p className="text-3xl font-bold text-orange-400">{riskSummary.high}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-orange-400" />
                </div>
              </div>

              <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Actively Monitored</p>
                    <p className="text-3xl font-bold text-green-400">{riskSummary.monitored}</p>
                  </div>
                   <Globe className="w-8 h-8 text-green-400" /> 
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-[#0A0D18]/30 border border-gray-800 rounded-xl p-6 mb-8">
              <div className="flex items-center space-x-4 mb-4">
                <Filter className="w-5 h-5 text-gray-400" />
                <span className="text-white font-semibold">Filter Supply Chain Risks</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select value={filterRiskLevel} onValueChange={setFilterRiskLevel}>
                  <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                    <SelectValue placeholder="All Risk Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Risk Levels</SelectItem>
                    <SelectItem value="CRITICAL">Critical</SelectItem>
                    <SelectItem value="HIGH">High</SelectItem>
                    <SelectItem value="MEDIUM">Medium</SelectItem>
                    <SelectItem value="LOW">Low</SelectItem>
                    <SelectItem value="MINIMAL">Minimal</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {Object.keys(riskCategoryIcons).map(category => (
                      <SelectItem key={category} value={category}>
                        {category.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center text-sm text-gray-400">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  {filteredRisks.length} risks displayed
                </div>
              </div>
            </div>

            {/* Risk Cards Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {filteredRisks.map(risk => {
                const sector = sectorMap[risk.sector_id];
                return (
                  <div 
                    key={risk.id}
                    onClick={() => setSelectedRisk(risk)}
                    className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 cursor-pointer transition-all hover:border-indigo-500/50"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{riskCategoryIcons[risk.risk_category] || '⚠️'}</span>
                        <div>
                          <h3 className="text-lg font-semibold text-white">{risk.supply_chain_name}</h3>
                          <p className="text-sm text-gray-400">{sector?.sector_name || 'Unknown Sector'}</p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${riskLevelColors[risk.risk_level]}`}>
                        {risk.risk_level}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-500">Probability</p>
                        <p className="text-sm font-semibold text-white">{risk.probability}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Impact</p>
                        <p className="text-sm font-semibold text-white">{risk.impact_severity}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Dependencies</p>
                        <p className="text-sm font-semibold text-white">{risk.key_dependencies?.length || 0}</p>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">
                        {risk.risk_category.replace('_', ' ')}
                      </span>
                      <span className="text-xs text-gray-400">
                        Last assessed: {new Date(risk.last_assessment_date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Detailed Risk Analysis */}
            {selectedRisk && (
              <div className="glass-pane p-6 mt-6">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="orbital-text-subheading flex items-center">
                    <span className="text-3xl mr-3">{riskCategoryIcons[selectedRisk.risk_category] || '⚠️'}</span>
                    {selectedRisk.supply_chain_name} - Risk Analysis
                  </h3>
                  <button 
                    onClick={() => setSelectedRisk(null)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-6 h-6"/>
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-4">Key Dependencies</h4>
                    {selectedRisk.key_dependencies?.length ? (
                      <div className="space-y-3">
                        {selectedRisk.key_dependencies.slice(0, 3).map((dep, index) => (
                          <div key={index} className="p-3 bg-gray-800/30 rounded-lg">
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-medium text-white">{dep.supplier || 'Unknown Supplier'}</span>
                              <span className="text-xs text-gray-400">{dep.dependency_percentage || 0}%</span>
                            </div>
                            <p className="text-sm text-gray-400">{dep.country || 'Unknown Location'}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No dependencies listed</p>
                    )}
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold text-white mb-4">Mitigation Strategies</h4>
                    {selectedRisk.mitigation_strategies?.length ? (
                      <div className="space-y-3">
                        {selectedRisk.mitigation_strategies.slice(0, 3).map((strategy, index) => (
                          <div key={index} className="p-3 bg-gray-800/30 rounded-lg">
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-medium text-white">{strategy.strategy || 'Strategy'}</span>
                              <span className={`text-xs px-2 py-1 rounded ${
                                strategy.status === 'IMPLEMENTED' ? 'bg-green-500/20 text-green-400' :
                                strategy.status === 'IN_PROGRESS' ? 'bg-yellow-500/20 text-yellow-400' :
                                'bg-gray-500/20 text-gray-400'
                              }`}>
                                {strategy.status || 'PLANNED'}
                              </span>
                            </div>
                            {strategy.effectiveness_rating && (
                              <p className="text-sm text-gray-400">Effectiveness: {strategy.effectiveness_rating}/5</p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No mitigation strategies defined</p>
                    )}
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold text-white mb-4">Risk Assessment</h4>
                    <div className="space-y-4">
                      <div className="p-3 bg-gray-800/30 rounded-lg">
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-400">Risk Level</span>
                          <span className={`font-semibold ${riskLevelColors[selectedRisk.risk_level].split(' ')[0]}`}>
                            {selectedRisk.risk_level}
                          </span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-400">Probability</span>
                          <span className="text-white">{selectedRisk.probability}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Impact Severity</span>
                          <span className="text-white">{selectedRisk.impact_severity}</span>
                        </div>
                      </div>

                      <div className="p-3 bg-gray-800/30 rounded-lg">
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-400">Last Assessment</span>
                          <span className="text-white text-sm">
                            {new Date(selectedRisk.last_assessment_date).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Next Review</span>
                          <span className="text-white text-sm">
                            {selectedRisk.next_review_date ? new Date(selectedRisk.next_review_date).toLocaleDateString() : 'Not scheduled'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
}