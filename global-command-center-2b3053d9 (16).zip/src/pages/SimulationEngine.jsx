import React, { useState } from 'react';
import { Brain, Zap, TrendingUp, AlertTriangle, Play, Settings, BarChart, Globe } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const simulationMetrics = [
  { title: "Active Simulations", value: "847", icon: Brain, color: "text-purple-400" },
  { title: "Scenarios Modeled", value: "12.4K", icon: BarChart, color: "text-cyan-400" },
  { title: "Prediction Accuracy", value: "94.2%", icon: TrendingUp, color: "text-green-400" },
  { title: "Processing Power", value: "2.8PF", icon: Zap, color: "text-yellow-400" },
];

const activeSimulations = [
  { 
    id: 'eco-001', 
    name: 'Yuan Devaluation Impact', 
    scenario: 'Currency crash by 15%', 
    status: 'RUNNING', 
    progress: 73,
    impact: 'CRITICAL',
    eta: '4h 23m'
  },
  { 
    id: 'geo-002', 
    name: 'Taiwan Strait Conflict', 
    scenario: 'Military escalation modeling', 
    status: 'RUNNING', 
    progress: 91,
    impact: 'CATASTROPHIC',
    eta: '1h 12m'
  },
  { 
    id: 'supply-003', 
    name: 'Semiconductor Shortage', 
    scenario: 'Complete Taiwan fab shutdown', 
    status: 'COMPLETED', 
    progress: 100,
    impact: 'HIGH',
    eta: 'Completed'
  },
  { 
    id: 'climate-004', 
    name: 'Sea Level Rise 2030', 
    scenario: '50cm rise coastal impact', 
    status: 'QUEUED', 
    progress: 0,
    impact: 'MODERATE',
    eta: 'Pending'
  }
];

const economicData = [
  { month: 'Jan', baseline: 100, scenario1: 100, scenario2: 100 },
  { month: 'Feb', baseline: 102, scenario1: 98, scenario2: 105 },
  { month: 'Mar', baseline: 105, scenario1: 95, scenario2: 108 },
  { month: 'Apr', baseline: 107, scenario1: 89, scenario2: 112 },
  { month: 'May', baseline: 110, scenario1: 85, scenario2: 115 },
  { month: 'Jun', baseline: 112, scenario1: 82, scenario2: 118 }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'RUNNING': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">RUNNING</Badge>;
    case 'COMPLETED': return <Badge className="bg-green-500/20 text-green-400">COMPLETED</Badge>;
    case 'QUEUED': return <Badge className="bg-yellow-500/20 text-yellow-400">QUEUED</Badge>;
    case 'ERROR': return <Badge className="bg-red-500/20 text-red-400">ERROR</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getImpactBadge = (impact) => {
  switch (impact) {
    case 'CATASTROPHIC': return <Badge className="bg-red-500/20 text-red-400">CATASTROPHIC</Badge>;
    case 'CRITICAL': return <Badge className="bg-orange-500/20 text-orange-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-yellow-500/20 text-yellow-400">HIGH</Badge>;
    case 'MODERATE': return <Badge className="bg-blue-500/20 text-blue-400">MODERATE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">LOW</Badge>;
  }
};

export default function SimulationEnginePage() {
  const [selectedSimulation, setSelectedSimulation] = useState('eco-001');
  const [newSimulationType, setNewSimulationType] = useState('');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Brain className="w-10 h-10 mr-3 text-purple-400" />
            Predictive Simulation Engine
          </h1>
          <p className="orbital-text-subtitle">Advanced scenario modeling for economic, geopolitical, and strategic decision making.</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={newSimulationType} onValueChange={setNewSimulationType}>
            <SelectTrigger className="w-48 bg-gray-800 border-gray-600">
              <SelectValue placeholder="Create New Simulation" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="economic">Economic Impact Model</SelectItem>
              <SelectItem value="geopolitical">Geopolitical Scenario</SelectItem>
              <SelectItem value="supply-chain">Supply Chain Analysis</SelectItem>
              <SelectItem value="climate">Climate Impact Model</SelectItem>
              <SelectItem value="cyber">Cyber Attack Simulation</SelectItem>
            </SelectContent>
          </Select>
          <button className="orbital-button-primary flex items-center space-x-2">
            <Play className="w-5 h-5" />
            <span>Launch Simulation</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {simulationMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Active Simulations */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-cyan-400" />
            Active Simulations
          </h3>
          <div className="space-y-3">
            {activeSimulations.map(sim => (
              <div 
                key={sim.id}
                className={`p-3 rounded-lg border transition-all cursor-pointer ${
                  selectedSimulation === sim.id 
                    ? 'bg-purple-500/20 border-purple-500/50' 
                    : 'bg-gray-800/30 border-gray-700 hover:border-purple-500/30'
                }`}
                onClick={() => setSelectedSimulation(sim.id)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-white text-sm">{sim.name}</h4>
                  {getStatusBadge(sim.status)}
                </div>
                <p className="text-xs text-gray-400 mb-2">{sim.scenario}</p>
                <div className="flex justify-between items-center mb-2">
                  {getImpactBadge(sim.impact)}
                  <span className="text-xs text-gray-400">{sim.eta}</span>
                </div>
                {sim.status === 'RUNNING' && (
                  <div className="w-full bg-gray-700 rounded-full h-1">
                    <div 
                      className="bg-blue-500 h-1 rounded-full transition-all duration-300" 
                      style={{width: `${sim.progress}%`}}
                    ></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Scenario Results */}
        <div className="lg:col-span-2 glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <BarChart className="w-5 h-5 mr-2 text-green-400" />
            Economic Impact Simulation
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={economicData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F3F4F6'
                  }}
                />
                <Line type="monotone" dataKey="baseline" stroke="#6B7280" strokeWidth={2} name="Baseline" />
                <Line type="monotone" dataKey="scenario1" stroke="#EF4444" strokeWidth={2} name="Yuan Crash -15%" strokeDasharray="5 5" />
                <Line type="monotone" dataKey="scenario2" stroke="#10B981" strokeWidth={2} name="Optimized Response" strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-400">100</p>
              <p className="text-sm text-gray-500">Baseline Index</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">-18%</p>
              <p className="text-sm text-gray-500">Crash Impact</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-400">+18%</p>
              <p className="text-sm text-gray-500">Optimized Gain</p>
            </div>
          </div>
        </div>
      </div>

      {/* Simulation Controls */}
      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-6 flex items-center">
          <Play className="w-5 h-5 mr-2 text-yellow-400" />
          Simulation Control Center
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-400">Scenario Type</label>
            <Select>
              <SelectTrigger className="bg-gray-800 border-gray-600">
                <SelectValue placeholder="Select scenario" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="market-crash">Market Crash</SelectItem>
                <SelectItem value="supply-disruption">Supply Disruption</SelectItem>
                <SelectItem value="conflict">Military Conflict</SelectItem>
                <SelectItem value="cyber-attack">Cyber Attack</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-400">Impact Magnitude</label>
            <Select>
              <SelectTrigger className="bg-gray-800 border-gray-600">
                <SelectValue placeholder="Select magnitude" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minor">Minor (1-5%)</SelectItem>
                <SelectItem value="moderate">Moderate (5-15%)</SelectItem>
                <SelectItem value="major">Major (15-30%)</SelectItem>
                <SelectItem value="catastrophic">Catastrophic ({">"}30%)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-400">Time Horizon</label>
            <Select>
              <SelectTrigger className="bg-gray-800 border-gray-600">
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1month">1 Month</SelectItem>
                <SelectItem value="6months">6 Months</SelectItem>
                <SelectItem value="1year">1 Year</SelectItem>
                <SelectItem value="5years">5 Years</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-400">Priority Level</label>
            <Select>
              <SelectTrigger className="bg-gray-800 border-gray-600">
                <SelectValue placeholder="Set priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low Priority</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="high">High Priority</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-center mt-6">
          <button className="orbital-button-primary flex items-center space-x-2 px-8 py-3">
            <Brain className="w-5 h-5" />
            <span>Initialize Quantum Simulation</span>
          </button>
        </div>
      </div>
    </div>
  );
}