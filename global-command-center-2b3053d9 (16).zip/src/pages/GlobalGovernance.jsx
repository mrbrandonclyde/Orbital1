import React, { useState } from 'react';
import { Building2, Globe, Users, FileText, TrendingUp, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const governanceMetrics = [
  { title: "Member Nations", value: "195", icon: Globe, color: "text-blue-400" },
  { title: "Active Treaties", value: "847", icon: FileText, color: "text-green-400" },
  { title: "Diplomatic Staff", value: "12,489", icon: Users, color: "text-purple-400" },
  { title: "Stability Index", value: "87.2%", icon: TrendingUp, color: "text-cyan-400" },
  { title: "Security Level", value: "HIGH", icon: Shield, color: "text-yellow-400" },
  { title: "Coordination Efficiency", value: "94.1%", icon: Building2, color: "text-orange-400" }
];

const regionStability = [
  { region: 'North America', stability: 92, threats: 3, cooperation: 89 },
  { region: 'Europe', stability: 88, threats: 7, cooperation: 94 },
  { region: 'Asia Pacific', stability: 74, threats: 18, cooperation: 76 },
  { region: 'Middle East', stability: 58, threats: 34, cooperation: 62 },
  { region: 'Africa', stability: 71, threats: 12, cooperation: 68 },
  { region: 'South America', stability: 79, threats: 8, cooperation: 81 }
];

const diplomaticActivities = [
  { month: 'Jan', treaties: 12, summits: 4, conflicts: 2 },
  { month: 'Feb', treaties: 15, summits: 6, conflicts: 1 },
  { month: 'Mar', treaties: 18, summits: 8, conflicts: 3 },
  { month: 'Apr', treaties: 22, summits: 5, conflicts: 1 },
  { month: 'May', treaties: 19, summits: 7, conflicts: 2 },
  { month: 'Jun', treaties: 24, summits: 9, conflicts: 1 }
];

const activeInitiatives = [
  {
    id: 'INIT-001',
    name: 'Climate Stability Accord',
    participants: 147,
    status: 'ACTIVE',
    progress: 78,
    category: 'Environmental'
  },
  {
    id: 'INIT-002',
    name: 'Global Trade Framework',
    participants: 189,
    status: 'NEGOTIATING',
    progress: 45,
    category: 'Economic'
  },
  {
    id: 'INIT-003',
    name: 'Cyber Security Alliance',
    participants: 156,
    status: 'RATIFYING',
    progress: 89,
    category: 'Security'
  },
  {
    id: 'INIT-004',
    name: 'Space Exploration Treaty',
    participants: 67,
    status: 'DRAFTING',
    progress: 23,
    category: 'Technology'
  }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'NEGOTIATING': return <Badge className="bg-yellow-500/20 text-yellow-400 animate-pulse">NEGOTIATING</Badge>;
    case 'RATIFYING': return <Badge className="bg-blue-500/20 text-blue-400">RATIFYING</Badge>;
    case 'DRAFTING': return <Badge className="bg-purple-500/20 text-purple-400">DRAFTING</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getCategoryBadge = (category) => {
  const colors = {
    'Environmental': 'bg-green-500/20 text-green-400',
    'Economic': 'bg-blue-500/20 text-blue-400',
    'Security': 'bg-red-500/20 text-red-400',
    'Technology': 'bg-purple-500/20 text-purple-400'
  };
  return <Badge className={colors[category] || 'bg-gray-500/20 text-gray-400'}>{category}</Badge>;
};

export default function GlobalGovernancePage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Building2 className="w-10 h-10 mr-3 text-blue-400" />
            Global Governance Framework
          </h1>
          <p className="orbital-text-subtitle">International coordination, diplomatic oversight, and global stability management.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {governanceMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Regional Stability Index</h3>
          <div className="space-y-4">
            {regionStability.map((region, i) => (
              <div key={i} className="p-3 bg-gray-800/30 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-white">{region.region}</h4>
                  <span className="text-cyan-400 font-bold">{region.stability}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                  <div 
                    className="bg-gradient-to-r from-cyan-500 to-green-500 h-2 rounded-full"
                    style={{ width: `${region.stability}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Threats: {region.threats}</span>
                  <span>Cooperation: {region.cooperation}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Diplomatic Activity Trends</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={diplomaticActivities}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Area type="monotone" dataKey="treaties" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
                <Area type="monotone" dataKey="summits" stackId="1" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="conflicts" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Active Global Initiatives</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Initiative</TableHead>
              <TableHead className="text-gray-400">Category</TableHead>
              <TableHead className="text-gray-400">Participants</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Progress</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activeInitiatives.map((initiative) => (
              <TableRow key={initiative.id} className="border-gray-800 hover:bg-gray-800/30">
                <TableCell>
                  <div>
                    <p className="font-medium text-white">{initiative.name}</p>
                    <p className="text-xs text-gray-400 font-mono">{initiative.id}</p>
                  </div>
                </TableCell>
                <TableCell>{getCategoryBadge(initiative.category)}</TableCell>
                <TableCell className="text-cyan-400">{initiative.participants} nations</TableCell>
                <TableCell>{getStatusBadge(initiative.status)}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                        style={{ width: `${initiative.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-blue-400">{initiative.progress}%</span>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}