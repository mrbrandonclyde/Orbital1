
import React, { useState, useEffect } from 'react';
import { useAuth } from '../components/context/AuthContext';
import { useRealtimeConnection } from '../components/hooks/useRealtime';
import LiveMetricsPanel from '../components/dashboard/LiveMetricsPanel';
import AIIntelligenceEngine from '../components/intelligence/AIIntelligenceEngine';
import SecurityCore from '../components/security/SecurityCore';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Crown, Globe, Shield, Brain, Zap, Activity, Eye, Users, AlertTriangle } from 'lucide-react';
import { Badge } from "@/components/ui/badge"; // New import for Badge component

// Basic ErrorBoundary component defined internally for self-containment and functionality
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div className="text-red-500 bg-gray-900 p-8 rounded-lg text-center mx-auto my-12 max-w-lg">
          <h2 className="text-2xl font-bold mb-4">Oops! Something went wrong.</h2>
          <p className="text-gray-400">We're working to fix it. Please try refreshing the page.</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function CommandCenterPage() {
  const { user } = useAuth();
  const connectionStatus = useRealtimeConnection();
  const [activeModule, setActiveModule] = useState('overview');

  const modules = [
    { id: 'overview', name: 'Overview', icon: Globe, component: null },
    { id: 'intelligence', name: 'AI Intelligence', icon: Brain, component: AIIntelligenceEngine },
    { id: 'security', name: 'Security Core', icon: Shield, component: SecurityCore },
    { id: 'metrics', name: 'Live Metrics', icon: Activity, component: null }
  ];

  const ActiveComponent = modules.find(m => m.id === activeModule)?.component;

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409]">
        {/* Command Center Header (wrapper for header content and module navigation) */}
        <div className="mb-8">
          {/* New Header Content */}
          <div className="orbital-page-header mb-6 flex items-center justify-between"> {/* Added mb-6 to separate from module nav, and flex/justify-between for layout */}
            <div>
              <h1 className="orbital-text-title flex items-center">
                <div className="w-10 h-10 rounded-full border-2 border-cyan-400 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 flex items-center justify-center mr-3">
                  <div className="w-6 h-6 rounded-full border border-cyan-400 bg-cyan-400/10"></div>
                </div>
                Orbital Command Center
              </h1>
              <p className="orbital-text-subtitle text-gray-400 text-lg">Global strategic command and control interface for worldwide operations.</p>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-blue-500/20 text-blue-400">ORBITAL SYSTEMS</Badge>
              <Badge className="bg-green-500/20 text-green-400">ALL SYSTEMS NOMINAL</Badge>
            </div>
          </div>

          {/* Module Navigation */}
          <div className="flex space-x-2 bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-2">
            {modules.map(module => {
              const Icon = module.icon;
              return (
                <button
                  key={module.id}
                  onClick={() => setActiveModule(module.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-lg transition-all ${
                    activeModule === module.id
                      ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/30'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{module.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Metrics - Always Visible */}
        <LiveMetricsPanel />

        {/* Dynamic Module Content */}
        {activeModule === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {/* Executive Summary */}
            <Card className="lg:col-span-2 bg-gradient-to-br from-gray-900/50 to-gray-800/30 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="w-6 h-6 mr-3 text-cyan-400" />
                  Executive Intelligence Brief
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                      <span className="text-blue-400 font-semibold">Strategic Priority</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      Global supply chain monitoring indicates elevated risk in semiconductor manufacturing regions.
                      AI intelligence suggests 72% probability of disruption within 30 days.
                    </p>
                  </div>

                  <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                      <span className="text-yellow-400 font-semibold">Operational Alert</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      Cybersecurity threat level elevated due to coordinated reconnaissance activities
                      across critical infrastructure networks.
                    </p>
                  </div>

                  <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-green-400 font-semibold">System Status</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      All Guardian Corps operations maintaining optimal performance.
                      Bio-symbiosis protocols showing 98% efficiency in current deployments.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-[#0A0D18]/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="w-6 h-6 mr-3 text-purple-400" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <button className="w-full p-3 bg-gradient-to-r from-red-500/20 to-orange-500/20 hover:from-red-500/30 hover:to-orange-500/30 border border-red-500/30 rounded-lg transition-all text-left">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="w-5 h-5 text-red-400" />
                      <div>
                        <div className="text-white font-semibold">Emergency Protocols</div>
                        <div className="text-gray-400 text-xs">Activate crisis response</div>
                      </div>
                    </div>
                  </button>

                  <button className="w-full p-3 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 hover:from-blue-500/30 hover:to-cyan-500/30 border border-blue-500/30 rounded-lg transition-all text-left">
                    <div className="flex items-center space-x-3">
                      <Brain className="w-5 h-5 text-blue-400" />
                      <div>
                        <div className="text-white font-semibold">AI Analysis</div>
                        <div className="text-gray-400 text-xs">Generate intelligence report</div>
                      </div>
                    </div>
                  </button>

                  <button className="w-full p-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 hover:from-purple-500/30 hover:to-pink-500/30 border border-purple-500/30 rounded-lg transition-all text-left">
                    <div className="flex items-center space-x-3">
                      <Users className="w-5 h-5 text-purple-400" />
                      <div>
                        <div className="text-white font-semibold">Guardian Deployment</div>
                        <div className="text-gray-400 text-xs">Coordinate operations</div>
                      </div>
                    </div>
                  </button>

                  <button className="w-full p-3 bg-gradient-to-r from-green-500/20 to-emerald-500/20 hover:from-green-500/30 hover:to-emerald-500/30 border border-green-500/30 rounded-lg transition-all text-left">
                    <div className="flex items-center space-x-3">
                      <Globe className="w-5 h-5 text-green-400" />
                      <div>
                        <div className="text-white font-semibold">Global Operations</div>
                        <div className="text-gray-400 text-xs">Monitor worldwide status</div>
                      </div>
                    </div>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Render Active Module Component */}
        {ActiveComponent && <ActiveComponent />}

        {/* Connection Status Footer */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gray-800/30 rounded-full text-sm">
            <div className={`w-2 h-2 rounded-full ${
              connectionStatus.isConnected ? 'bg-green-400' : 'bg-red-400'
            } animate-pulse`}></div>
            <span className="text-gray-400">
              System Status: {connectionStatus.isConnected ? 'ONLINE' : 'OFFLINE'}
            </span>
            {connectionStatus.lastUpdate && (
              <span className="text-gray-500">
                • Updated {connectionStatus.lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
