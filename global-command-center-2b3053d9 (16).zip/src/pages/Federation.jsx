import React from "react";
import { Network, Users, Building2, Globe } from "lucide-react";

export default function FederationPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Network className="w-10 h-10 mr-3 text-cyan-400" />
          Federation (Phase 6+)
        </h1>
        <p className="orbital-text-subtitle">Unify Nations, Corporations, and Agencies into a coordinated ops fabric.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-pane p-6">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="w-5 h-5 text-blue-400" />
            <h3 className="text-white font-semibold">Nations</h3>
          </div>
          <p className="text-gray-400 text-sm">Policy sync, crisis protocols, shared intel.</p>
        </div>

        <div className="glass-pane p-6">
          <div className="flex items-center gap-3 mb-2">
            <Building2 className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Corporations</h3>
          </div>
          <p className="text-gray-400 text-sm">Supply webs, resilience SLAs, asset sharing.</p>
        </div>

        <div className="glass-pane p-6">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Agencies</h3>
          </div>
          <p className="text-gray-400 text-sm">Standards, oversight, and interop.</p>
        </div>
      </div>
    </div>
  );
}