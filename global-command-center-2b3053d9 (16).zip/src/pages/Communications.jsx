import React, { useState } from 'react';
import { MessageSquare, Shield, Users, Wifi } from 'lucide-react';

const channels = [
  { id: 'alpha-command', name: 'Alpha Command', type: 'ENCRYPTED', members: 12, status: 'ONLINE' },
  { id: 'global-intel', name: 'Global Intel Feed', type: 'BROADCAST', members: 847, status: 'ONLINE' },
  { id: 'mission-nightfall', name: 'Mission: Nightfall', type: 'ENCRYPTED', members: 24, status: 'ONLINE' },
  { id: 'asset-logistics', name: 'Asset & Logistics', type: 'SECURE', members: 58, status: 'ONLINE' },
  { id: 'vr-war-room', name: 'VR War Room Sync', type: 'REALTIME', members: 24, status: 'DEGRADED' },
];

const messages = {
  'alpha-command': [
    { user: 'Command', text: 'Confirming Operation Nightfall is a go. Asset is in position.', time: '10:32' },
    { user: 'Wraith', text: 'Acknowledged. Moving to secure perimeter.', time: '10:33' },
    { user: 'Apex', text: 'Intel confirms clear path. Proceed with caution.', time: '10:34' },
  ],
  'global-intel': [
    { user: 'INTEL-BOT', text: '[ALERT] Unusual market activity detected in Shanghai Composite Index.', time: '10:30' },
    { user: 'INTEL-BOT', text: '[UPDATE] Satellite imagery shows increased naval presence in South China Sea.', time: '10:35' },
  ],
  'mission-nightfall': [
    { user: 'Wraith', text: 'Perimeter secured. No hostiles detected.', time: '10:45' },
    { user: 'Kestrel', text: 'Drone overlay shows two heat signatures, non-civilian, moving north.', time: '10:46' },
  ],
  'asset-logistics': [
    { user: 'LOGISTICS-AI', text: 'Asset #743 delivery confirmed. Route optimized for #744.', time: '10:50' },
  ],
  'vr-war-room': [
    { user: 'SYSTEM', text: '[WARNING] Latency spike detected. Sync may be unstable.', time: '10:52' },
  ],
};

export default function CommunicationsPage() {
  const [activeChannel, setActiveChannel] = useState('alpha-command');

  return (
    <div className="orbital-page-layout bg-[#020409] flex flex-col h-[calc(100vh-120px)]">
      <div className="flex-shrink-0">
        <h1 className="orbital-text-title flex items-center">
          <MessageSquare className="w-10 h-10 mr-3 text-blue-400" />
          Secure Communications
        </h1>
        <p className="orbital-text-subtitle mb-8">Quantum-encrypted, real-time command and control channels.</p>
      </div>

      <div className="flex-grow grid grid-cols-12 gap-6 min-h-0">
        {/* Channels List */}
        <div className="col-span-3 glass-pane p-4 flex flex-col">
          <h3 className="orbital-text-subheading mb-4 flex-shrink-0">Channels</h3>
          <div className="flex-grow overflow-y-auto space-y-2">
            {channels.map(channel => (
              <div
                key={channel.id}
                onClick={() => setActiveChannel(channel.id)}
                className={`p-3 rounded-lg cursor-pointer transition-all ${
                  activeChannel === channel.id 
                    ? 'bg-blue-500/20 border border-blue-500/30' 
                    : 'hover:bg-gray-800/50'
                }`}
              >
                <div className="flex justify-between items-center">
                  <p className="font-semibold text-white">{channel.name}</p>
                  {channel.status === 'ONLINE' ? 
                    <Wifi className="w-4 h-4 text-green-400" /> :
                    <Wifi className="w-4 h-4 text-yellow-400" />
                  }
                </div>
                <div className="flex items-center text-xs text-gray-400 space-x-4 mt-1">
                  <div className="flex items-center space-x-1">
                    <Shield className="w-3 h-3" />
                    <span>{channel.type}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span>{channel.members}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Message View */}
        <div className="col-span-9 glass-pane p-6 flex flex-col">
          <div className="flex-grow overflow-y-auto space-y-4 pr-4">
            {(messages[activeChannel] || []).map((msg, index) => (
              <div key={index} className={`flex ${msg.user === 'Command' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xl p-3 rounded-lg ${
                  msg.user === 'Command'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-700 text-gray-200'
                }`}>
                  <div className="flex items-center space-x-2 text-xs mb-1">
                    <p className="font-bold">{msg.user}</p>
                    <p className="opacity-70">{msg.time}</p>
                  </div>
                  <p className="text-sm">{msg.text}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex-shrink-0 mt-4">
            <div className="relative">
              <input
                type="text"
                placeholder={`Message #${channels.find(c => c.id === activeChannel)?.name || ''}...`}
                className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 pr-24 text-white focus:ring-blue-500"
              />
              <button className="absolute right-2 top-1/2 -translate-y-1/2 orbital-button-primary text-sm px-4 py-1.5">
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}