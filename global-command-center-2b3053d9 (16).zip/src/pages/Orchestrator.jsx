import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { GitBranch, PlugZap, Settings, Monitor } from "lucide-react";

export default function OrchestratorPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <GitBranch className="w-10 h-10 mr-3 text-cyan-400" />
          Orchestrator
        </h1>
        <p className="orbital-text-subtitle">Workflows, connectors, and monitoring (n8n/Make-ready architecture).</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('DataSources')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <PlugZap className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">Connectors</h3>
          </div>
          <p className="text-gray-400 text-sm">Manage data sources and integrations.</p>
        </Link>

        <Link to={createPageUrl('SystemStatus')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Monitor className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Monitoring</h3>
          </div>
          <p className="text-gray-400 text-sm">Pipelines health, errors, and performance.</p>
        </Link>

        <Link to={createPageUrl('AISettings')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white font-semibold">Workflow Settings</h3>
          </div>
          <p className="text-gray-400 text-sm">Governance, guardrails, and tool access.</p>
        </Link>
      </div>

      <div className="mt-8 text-xs text-gray-500">
        External orchestrators (n8n, Make) can be wired via backend functions and webhooks when enabled.
      </div>
    </div>
  );
}