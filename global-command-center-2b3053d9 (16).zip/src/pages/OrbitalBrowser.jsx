
import React from "react";
import { SystemConfig } from "@/api/entities";
import { AuditTrail } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { RefreshCw, Save, Globe, Shield, Rocket, Settings as SettingsIcon, Database } from "lucide-react";
import BrowserSidebar from "@/components/browser/BrowserSidebar";
import HomeDashboard from "@/components/browser/HomeDashboard";
import Missions from "@/components/browser/Missions";
import Vault from "@/components/browser/Vault";
import Contracts from "@/components/browser/Contracts";
import BrowserSettings from "@/components/browser/Settings";
import { BrandRules, applyBrandRules } from "@/components/brand/BrandRules";

const CONFIG_KEY = "ORBITAL_BROWSER_SETTINGS";

export default function OrbitalBrowser() {
  const [me, setMe] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [active, setActive] = React.useState("home");
  const [settings, setSettings] = React.useState({
    module_toggles: {
      ai_enabled: true,
      vault_enabled: true,
      missions_enabled: true,
      contracts_enabled: true
    },
    connectors: {
      crm: true,
      banking: true,
      blockchain: true,
      global_ops: true
    },
    security: {
      proton_layer: true,
      tls_1_3: true,
      pqc_ready: true,
      zero_trust: true
    },
    offline_first: true,
    brand_theme: "Orbital"
  });

  React.useEffect(() => {
    applyBrandRules(BrandRules);
  }, []);

  const load = React.useCallback(async () => {
    setLoading(true);
    try { setMe(await User.me()); } catch {}
    const rows = await SystemConfig.filter({ config_key: CONFIG_KEY }, "-updated_date", 1);
    const cfg = rows?.[0];
    if (cfg) {
      setConfigId(cfg.id);
      const v = cfg.config_value || {};
      setSettings(prev => ({
        ...prev,
        ...v,
        module_toggles: { ...prev.module_toggles, ...(v.module_toggles || {}) },
        connectors: { ...prev.connectors, ...(v.connectors || {}) },
        security: { ...prev.security, ...(v.security || {}) }
      }));
    } else {
      setConfigId(null);
    }
    setLoading(false);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    const payload = {
      config_key: CONFIG_KEY,
      config_value: { ...settings },
      description: "Orbital Browser OS module settings",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    let action = "CREATE";
    let entityId = CONFIG_KEY;
    if (configId) {
      await SystemConfig.update(configId, payload);
      action = "UPDATE";
      entityId = configId;
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
      entityId = created.id;
    }
    await AuditTrail.create({
      entity_type: "SystemConfig",
      entity_id: entityId,
      action,
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: { CONFIG_KEY, config_value: settings },
      security_classification: "CONFIDENTIAL",
      risk_score: 8
    });
    setSaving(false);
  };

  const statusBadges = (
    <div className="flex items-center gap-2">
      <Badge className="bg-blue-500/20 text-blue-400 flex items-center gap-1"><Globe className="w-3 h-3" /> Browser</Badge>
      <Badge className="bg-green-500/20 text-green-400 flex items-center gap-1"><Shield className="w-3 h-3" /> Proton</Badge>
      {settings.offline_first && (
        <Badge className="bg-amber-500/20 text-amber-400 flex items-center gap-1"><Database className="w-3 h-3" /> Offline-first</Badge>
      )}
    </div>
  );

  const renderView = () => {
    switch (active) {
      case "home":
        return <HomeDashboard settings={settings} />;
      case "missions":
        return <Missions enabled={settings.module_toggles.missions_enabled} />;
      case "vault":
        return <Vault settings={settings} onSettings={setSettings} />;
      case "contracts":
        return <Contracts enabled={settings.module_toggles.contracts_enabled} />;
      case "settings":
        return <BrowserSettings settings={settings} onChange={setSettings} />;
      default:
        return <HomeDashboard settings={settings} />;
    }
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Rocket className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Orbital Browser OS</h1>
            <p className="orbital-text-subtitle">Infinity Genius search, missions, and a unified vault — aligned with Orbital Command.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {statusBadges}
          <Button variant="secondary" onClick={load} disabled={loading} className="border-gray-700 text-gray-200 hover:text-white">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
          <Button onClick={save} disabled={saving} className="bg-[#0D1BFF] hover:bg-[#0B18DE] focus:ring-2 focus:ring-cyan-400">
            <Save className={`w-4 h-4 mr-2 ${saving ? "animate-spin" : ""}`} /> Save
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-3">
          <BrowserSidebar active={active} onSelect={setActive} toggles={settings.module_toggles} />
        </div>
        <div className="lg:col-span-9">
          {renderView()}
        </div>
      </div>

      <Card className="mt-6 bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-base">Integration Notes</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-gray-400 space-y-2">
          <p>- Vault is unified across Orbital Bank and Blockchain environments (scaffolded). </p>
          <p>- AI Copilot context is designed to fuse Browser results with Orbital data (Bank and Ops).</p>
          <p>- Module is VR/AR ready and offline-first with user-controlled sync.</p>
        </CardContent>
      </Card>
    </div>
  );
}
