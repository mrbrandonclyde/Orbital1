
import React, { useState, useCallback } from 'react';
import { SecurityAlert } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { AlertTriangle, Clock, ShieldCheck, PieChart as PieIcon, CheckCircle, RefreshCw } from 'lucide-react';
import ErrorBoundary from '../components/common/ErrorBoundary';

// === Placeholder Data (Infinity Edition) ===
const kpiData = [
  { title: "Active Alerts", value: "35", icon: AlertTriangle, color: "text-red-400" },
  { title: "Avg. Response Time", value: "45s", icon: Clock, color: "text-yellow-400" },
  { title: "Critical Alerts", value: "8", icon: AlertTriangle, color: "text-red-500" },
  { title: "Alert Accuracy", value: "95%", icon: ShieldCheck, color: "text-green-400" },
  { title: "Incidents Today", value: "12", icon: PieIcon, color: "text-cyan-400" },
];

const activeAlertsData = [
  { time: "10:00", alerts: 5 },
  { time: "11:00", alerts: 7 },
  { time: "12:00", alerts: 6 },
  { time: "13:00", alerts: 8 },
  { time: "14:00", alerts: 9 },
  { time: "15:00", alerts: 12 },
];

const responseTimeData = [
  { severity: "Critical", time: 25, fill: "#EF4444" },
  { severity: "High", time: 45, fill: "#F59E0B" },
  { severity: "Medium", time: 120, fill: "#3B82F6" },
  { severity: "Low", time: 300, fill: "#10B981" },
];

const alertSeverityData = [
  { name: "Critical", value: 8, fill: "#EF4444"},
  { name: "High", value: 12, fill: "#F59E0B"},
  { name: "Medium", value: 15, fill: "#3B82F6"},
  { name: "Low", value: 25, fill: "#10B981"},
];

const alertLog = [
  { id: "#A-001", type: "System Error", severity: "High", desc: "Primary database connection failed", status: "Resolved", date: "2025-09-02 14:30" },
  { id: "#A-002", type: "Security Breach", severity: "Critical", desc: "Unauthorized access attempt from 123.45.67.89", status: "In Progress", date: "2025-09-02 14:32" },
  { id: "#A-003", type: "Network Anomaly", severity: "Medium", desc: "Unusual traffic pattern detected on main gateway", status: "Investigating", date: "2025-09-02 14:35" },
];

const actionLog = [
  { actionId: "#ACT-5001", alertId: "#A-001", type: "Failover Triggered", status: "Completed", time: "5s" },
  { actionId: "#ACT-5002", alertId: "#A-002", type: "IP Blacklisted", status: "Completed", time: "2s" },
  { actionId: "#ACT-5003", alertId: "#A-002", type: "Security Scan", status: "Ongoing", time: "30min" },
];

const responseSummary = [
  { date: "2025-09-02", type: "System Error", resolutionTime: "5 minutes", outcome: "Resolved, system stable" },
  { date: "2025-09-01", type: "Security Breach", resolutionTime: "45 minutes", outcome: "Contained, investigation ongoing" },
];

const ChartTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
          <p className="label text-white font-medium mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color || entry.stroke || entry.fill }}>{`${entry.name}: ${entry.value}`}</p>
          ))}
        </div>
      );
    }
    return null;
};

const getSeverityBadge = (severity) => {
  switch (severity) {
    case "Critical": return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">{severity}</Badge>;
    case "High": return <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">{severity}</Badge>;
    case "Medium": return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">{severity}</Badge>;
    case "Low": return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">{severity}</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">{severity}</Badge>;
  }
};

const getStatusBadge = (status) => {
    if (status === "Resolved" || status === "Completed") return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    if (status === "In Progress" || status === "Investigating" || status === "Ongoing") return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 animate-pulse">{status}</Badge>;
    return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
};

export default function AlertsPage() {
  const { data: alerts, loading, error, refetch } = useQuery(['securityAlerts'], () => SecurityAlert.list('-created_date', 50));

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409]">
        <div className="orbital-page-header">
          <div>
            <h1 className="orbital-text-title flex items-center">
              <AlertTriangle className="w-10 h-10 mr-3 text-red-400" />
              Alerts Monitor
            </h1>
            <p className="orbital-text-subtitle">Real-time incident detection, alert prioritization, and emergency response.</p>
          </div>
          <button onClick={refetch} className="orbital-button-secondary flex items-center">
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh Feed
          </button>
        </div>

        {/* Frame 1: KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {kpiData.map((kpi, i) => {
            const Icon = kpi.icon;
            return (
              <div key={i} className="glass-pane p-4">
                <div className="flex justify-between items-start">
                  <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                  <Icon className={`w-6 h-6 ${kpi.color}`} />
                </div>
                <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
              </div>
            );
          })}
        </div>

        {/* Frame 2: Graphs */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Active Alerts Over Time</h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={activeAlertsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Line type="monotone" dataKey="alerts" name="Active Alerts" stroke="#EF4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Alert Response Time</h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={responseTimeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="severity" stroke="#9CA3AF" />
                  <YAxis unit="s" stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="time" name="Response Time (s)">
                     {responseTimeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Alerts by Severity</h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Tooltip content={<ChartTooltip />} />
                  <Pie data={alertSeverityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                      {alertSeverityData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Frame 3: Logs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Live Alert Log</h3>
              <div className="overflow-x-auto">
                  <Table>
                      <TableHeader><TableRow className="border-gray-700 hover:bg-transparent"><TableHead className="text-gray-400">ID</TableHead><TableHead className="text-gray-400">Type</TableHead><TableHead className="text-gray-400">Severity</TableHead><TableHead className="text-gray-400">Status</TableHead></TableRow></TableHeader>
                      <TableBody>
                          {alertLog.map((row) => (
                              <TableRow key={row.id} className="border-gray-800 hover:bg-gray-800/30">
                                  <TableCell className="font-mono text-xs text-cyan-400">{row.id}</TableCell>
                                  <TableCell className="text-white">{row.type}</TableCell>
                                  <TableCell>{getSeverityBadge(row.severity)}</TableCell>
                                  <TableCell>{getStatusBadge(row.status)}</TableCell>
                              </TableRow>
                          ))}
                      </TableBody>
                  </Table>
              </div>
          </div>

          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Response Action Log</h3>
              <div className="overflow-x-auto">
                  <Table>
                      <TableHeader><TableRow className="border-gray-700 hover:bg-transparent"><TableHead className="text-gray-400">Action ID</TableHead><TableHead className="text-gray-400">Alert ID</TableHead><TableHead className="text-gray-400">Action</TableHead><TableHead className="text-gray-400">Status</TableHead></TableRow></TableHeader>
                      <TableBody>
                          {actionLog.map((row) => (
                              <TableRow key={row.actionId} className="border-gray-800 hover:bg-gray-800/30">
                                  <TableCell className="font-mono text-xs text-gray-300">{row.actionId}</TableCell>
                                  <TableCell className="font-mono text-xs text-cyan-400">{row.alertId}</TableCell>
                                  <TableCell className="text-white">{row.type}</TableCell>
                                  <TableCell>{getStatusBadge(row.status)}</TableCell>
                              </TableRow>
                          ))}
                      </TableBody>
                  </Table>
              </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
