
import React from "react";
import { SystemConfig } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input"; // Added Input import
import { RefreshCw, Save, Shield, CheckCircle2, Activity, BookOpen, Rocket } from "lucide-react";

const CONFIG_KEY = "PHASE0_ALIGNMENT";

const COMPLIANCE_LIST = [
  { id: "soc2", label: "SOC 2" },
  { id: "iso27001", label: "ISO 27001" },
  { id: "gdpr", label: "GDPR" },
  { id: "hipaa", label: "HIPAA" },
  { id: "pci_dss", label: "PCI‑DSS" },
];

const VERTICALS = [
  { id: "luxury_real_estate", label: "Luxury Real Estate" },
  { id: "private_aviation", label: "Private Aviation & Flight Lessons" },
  { id: "luxury_cars", label: "High-End Cars (Luxury/Exotic)" },
  { id: "renewable_solar_saas", label: "Renewable Energy / Solar SaaS" },
  { id: "banking_fintech", label: "Banking & Fintech (Orbital Bank)" },
  { id: "healthcare_biotech", label: "Healthcare & BioTech" },
  { id: "defense_security_ai", label: "Defense & Security AI" },
  { id: "smart_cities", label: "Smart Cities" },
  { id: "ai_humans_robotics", label: "AI Humans & Robotics" },
  { id: "orbital_news", label: "Global Media (Orbital News)" },
  { id: "education_training", label: "Education & Training Platforms" },
  { id: "other_modules", label: "Other Future Extensions" },
];

const LEARNING_MODES = [
  { id: "supervised", label: "Supervised Learning" },
  { id: "unsupervised", label: "Unsupervised Learning" },
  { id: "reinforcement", label: "Reinforcement Learning" },
  { id: "deep_learning", label: "Deep Learning" },
  { id: "transfer_learning", label: "Transfer Learning" },
  { id: "federated", label: "Federated Learning" },
  { id: "self_supervised", label: "Self-Supervised Learning" },
  { id: "generative_ai", label: "Generative AI" },
  { id: "predictive_analytics", label: "Predictive Analytics" },
  { id: "prescriptive_analytics", label: "Prescriptive Analytics" },
  { id: "quantum_hybrid", label: "Quantum/Hybrid AI" },
  { id: "continuous_online", label: "Continuous / Online Learning" },
];

const EXECUTION_FRAMEWORK = [
  { id: "crawl_walk_run_fly", label: "Crawl / Walk / Run / Fly" },
  { id: "simulation", label: "Simulation" },
  { id: "prediction", label: "Prediction" },
  { id: "self_healing", label: "Self-Healing" },
  { id: "cross_domain_transfer", label: "Cross-Domain Transfer" },
  { id: "auto_pilot_vs_hitl", label: "Auto-Pilot vs Human-in-the-loop" },
  { id: "continuous_memory", label: "Continuous Memory" },
  { id: "scenario_branching", label: "Scenario Branching" },
  { id: "rapid_iteration", label: "Rapid Iteration" },
  { id: "compliance_by_design", label: "Compliance-by-Design" },
  { id: "global_scalability", label: "Global Scalability" },
  { id: "infinity_genius_expansion", label: "Infinity Genius Expansion" },
];

function ProgressStat({ label, done, total }) {
  const pct = total ? Math.round((done / total) * 100) : 0;
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-gray-300">{label}</span>
      <span className="text-gray-400">{done}/{total} • <span className="text-cyan-400">{pct}%</span></span>
    </div>
  );
}

export default function Phase0Alignment() {
  const [me, setMe] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [cfg, setCfg] = React.useState({
    alignment: { initialized: true, locked: false },
    security: {
      proton_enabled: true,
      e2e_encryption: true,
      tls_1_3: true,
      zero_trust: true,
      quantum_ready: true,
      pqc_ready: true
    },
    compliance: {
      soc2: false, iso27001: false, gdpr: true, hipaa: false, pci_dss: false,
      apply_defaults: true
    },
    verticals: Object.fromEntries(VERTICALS.map(v => [v.id, false])),
    learning_modes: Object.fromEntries(LEARNING_MODES.map(m => [m.id, false])),
    execution_framework: Object.fromEntries(EXECUTION_FRAMEWORK.map(m => [m.id, false])),
    brand_rules: {
      enforce: true,
      primary: "#06B6D4",
      secondary: "#8B5CF6",
      accent: "#22D3EE",
      background: "#020409",
      surface: "#0A0D18",
      font_family: "Inter, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, sans-serif",
      radius: 12
    },
    future_hooks: {
      orbital_cdn_edge_mesh: true,
      orbital_ai_copilot: true,
      digital_twin_pods: true
    },
    ai_to_infinity: true,
    expansion_hooks_ready: true,
    notes: ""
  });

  const load = React.useCallback(async () => {
    setLoading(true);
    try { setMe(await User.me()); } catch {}
    const rows = await SystemConfig.filter({ config_key: CONFIG_KEY }, "-updated_date", 1);
    const row = rows?.[0];
    if (row) {
      setConfigId(row.id);
      const val = row.config_value || {};
      setCfg(prev => ({
        ...prev,
        ...val,
        // ensure new keys exist if older config
        verticals: { ...Object.fromEntries(VERTICALS.map(v => [v.id, false])), ...(val.verticals || {}) },
        learning_modes: { ...Object.fromEntries(LEARNING_MODES.map(m => [m.id, false])), ...(val.learning_modes || {}) },
        execution_framework: { ...Object.fromEntries(EXECUTION_FRAMEWORK.map(m => [m.id, false])), ...(val.execution_framework || {}) },
        security: { ...prev.security, ...(val.security || {}) },
        compliance: { ...prev.compliance, ...(val.compliance || {}) },
        brand_rules: { ...prev.brand_rules, ...(val.brand_rules || {}) },
        future_hooks: { ...prev.future_hooks, ...(val.future_hooks || {}) },
        alignment: { ...prev.alignment, ...(val.alignment || {}) },
      }));
    } else {
      setConfigId(null);
      setCfg((prev) => ({ ...prev }));
    }
    setLoading(false);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    const payload = {
      config_key: CONFIG_KEY,
      config_value: { ...cfg },
      description: "Phase 0 alignment — Orbital GCC core scaffolding and readiness flags",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    if (configId) {
      await SystemConfig.update(configId, payload);
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
    }
    setSaving(false);
  };

  const countTrue = (obj) => Object.values(obj || {}).filter(Boolean).length;

  const totals = {
    security: { done: countTrue(cfg.security), total: Object.keys(cfg.security).length },
    compliance: { done: countTrue(cfg.compliance) - (cfg.compliance.apply_defaults ? 1 : 0), total: COMPLIANCE_LIST.length },
    verticals: { done: countTrue(cfg.verticals), total: VERTICALS.length },
    learning: { done: countTrue(cfg.learning_modes), total: LEARNING_MODES.length },
    framework: { done: countTrue(cfg.execution_framework), total: EXECUTION_FRAMEWORK.length },
  };

  const overallPct = Math.round((
    (totals.security.total ? totals.security.done / totals.security.total : 0) +
    (totals.compliance.total ? totals.compliance.done / totals.compliance.total : 0) +
    (totals.verticals.total ? totals.verticals.done / totals.verticals.total : 0) +
    (totals.learning.total ? totals.learning.done / totals.learning.total : 0) +
    (totals.framework.total ? totals.framework.done / totals.framework.total : 0)
  ) / 5 * 100);

  const toggle = (path, key, value) => {
    setCfg(prev => ({ ...prev, [path]: { ...prev[path], [key]: value } }));
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Rocket className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Phase 0 — Orbital GCC Alignment</h1>
            <p className="orbital-text-subtitle">Nothing forgotten, nothing missed. Central hub readiness and expansion scaffolding.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={load} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
          <Button onClick={save} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
            <Save className={`w-4 h-4 mr-2 ${saving ? "animate-spin" : ""}`} /> Save
          </Button>
        </div>
      </div>

      {/* Readiness Summary */}
      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" /> Readiness Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <ProgressStat label="Security" done={totals.security.done} total={totals.security.total} />
          </div>
          <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <ProgressStat label="Compliance" done={totals.compliance.done} total={totals.compliance.total} />
          </div>
          <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <ProgressStat label="Verticals" done={totals.verticals.done} total={totals.verticals.total} />
          </div>
          <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <ProgressStat label="Learning Modes" done={totals.learning.done} total={totals.learning.total} />
          </div>
          <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <ProgressStat label="Execution Framework" done={totals.framework.done} total={totals.framework.total} />
          </div>
          <div className="md:col-span-5 text-xs text-gray-400 mt-2">
            Overall Readiness: <span className="text-cyan-400">{overallPct}%</span>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Security */}
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-400" /> Infinity Genius Security + Proton Layer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { id: "proton_enabled", label: "Proton Layer Integrated" },
              { id: "e2e_encryption", label: "End‑to‑End Encryption" },
              { id: "tls_1_3", label: "TLS 1.3+ Enforced" },
              { id: "zero_trust", label: "Zero‑Trust Enforcement" },
              { id: "quantum_ready", label: "Quantum‑Ready Placeholders" },
              { id: "pqc_ready", label: "PQC‑Ready Keys" },
            ].map(item => (
              <div key={item.id} className="flex items-center justify-between">
                <Label className="text-gray-300">{item.label}</Label>
                <Switch checked={!!cfg.security[item.id]} onCheckedChange={(v) => toggle("security", item.id, v)} />
              </div>
            ))}
            <Badge className="bg-gray-700/40 text-gray-300">Backbone ready for privacy, encryption, identity</Badge>
          </CardContent>
        </Card>

        {/* Compliance */}
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-purple-400" /> Global Compliance Scaffold
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">Apply Compliance by Default</Label>
              <Switch checked={!!cfg.compliance.apply_defaults} onCheckedChange={(v) => toggle("compliance", "apply_defaults", v)} />
            </div>
            {COMPLIANCE_LIST.map(c => (
              <div key={c.id} className="flex items-center justify-between">
                <Label className="text-gray-300">{c.label}</Label>
                <Switch checked={!!cfg.compliance[c.id]} onCheckedChange={(v) => toggle("compliance", c.id, v)} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Verticals */}
        <Card className="bg-[#0A0D18]/60 border-gray-800 xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-base">High-Value Verticals — Hooks Ready</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {VERTICALS.map(v => (
              <div key={v.id} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{v.label}</Label>
                <Switch checked={!!cfg.verticals[v.id]} onCheckedChange={(val) => setCfg(prev => ({ ...prev, verticals: { ...prev.verticals, [v.id]: val } }))} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Learning Modes */}
        <Card className="bg-[#0A0D18]/60 border-gray-800 xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-base">AI Learning Modes — Scaffold</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {LEARNING_MODES.map(m => (
              <div key={m.id} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{m.label}</Label>
                <Switch checked={!!cfg.learning_modes[m.id]} onCheckedChange={(val) => setCfg(prev => ({ ...prev, learning_modes: { ...prev.learning_modes, [m.id]: val } }))} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Execution Framework — 12 Learn Modes */}
        <Card className="bg-[#0A0D18]/60 border-gray-800 xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-base">12 Learn Modes — Execution Framework</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {EXECUTION_FRAMEWORK.map(m => (
              <div key={m.id} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{m.label}</Label>
                <Switch checked={!!cfg.execution_framework[m.id]} onCheckedChange={(val) => setCfg(prev => ({ ...prev, execution_framework: { ...prev.execution_framework, [m.id]: val } }))} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Brand Rules & Future Hooks */}
        <Card className="bg-[#0A0D18]/60 border-gray-800 xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-base">Brand Rules & Future Hooks</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">Enforce Brand Rules (Orbital)</Label>
              <Switch checked={!!cfg.brand_rules.enforce} onCheckedChange={(v) => setCfg(prev => ({ ...prev, brand_rules: { ...prev.brand_rules, enforce: v } }))} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300 text-xs">Primary</Label>
                <Input
                  value={cfg.brand_rules.primary}
                  onChange={(e) => setCfg(prev => ({ ...prev, brand_rules: { ...prev.brand_rules, primary: e.target.value } }))}
                  className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300 text-xs">Secondary</Label>
                <Input
                  value={cfg.brand_rules.secondary}
                  onChange={(e) => setCfg(prev => ({ ...prev, brand_rules: { ...prev.brand_rules, secondary: e.target.value } }))}
                  className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300 text-xs">Accent</Label>
                <Input
                  value={cfg.brand_rules.accent}
                  onChange={(e) => setCfg(prev => ({ ...prev, brand_rules: { ...prev.brand_rules, accent: e.target.value } }))}
                  className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
            </div>
            <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300 text-xs">Font Family</Label>
              <Input
                value={cfg.brand_rules.font_family}
                onChange={(e) => setCfg(prev => ({ ...prev, brand_rules: { ...prev.brand_rules, font_family: e.target.value } }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { key: "orbital_cdn_edge_mesh", label: "Orbital CDN + Edge Mesh" },
                { key: "orbital_ai_copilot", label: "Orbital AI CoPilot (All Learn Modes)" },
                { key: "digital_twin_pods", label: "Digital Twin Simulation Pods" },
              ].map(h => (
                <div key={h.key} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                  <Label className="text-gray-300">{h.label}</Label>
                  <Switch checked={!!cfg.future_hooks[h.key]} onCheckedChange={(v) => setCfg(prev => ({ ...prev, future_hooks: { ...prev.future_hooks, [h.key]: v } }))} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        <Card className="bg-[#0A0D18]/60 border-gray-800 xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-base">Notes & Expansion Hooks</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-gray-300">AI to the Infinity (Scalable Architecture)</Label>
              <Switch checked={!!cfg.ai_to_infinity} onCheckedChange={(v) => setCfg(prev => ({ ...prev, ai_to_infinity: v }))} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-gray-300">Expansion Hooks Ready (inherit across phases)</Label>
              <Switch checked={!!cfg.expansion_hooks_ready} onCheckedChange={(v) => setCfg(prev => ({ ...prev, expansion_hooks_ready: v }))} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-gray-300">Alignment Initialized</Label>
              <Switch checked={!!cfg.alignment.initialized} onCheckedChange={(v) => toggle("alignment", "initialized", v)} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-gray-300">Lock Configuration (read-only mode)</Label>
              <Switch checked={!!cfg.alignment.locked} onCheckedChange={(v) => toggle("alignment", "locked", v)} />
            </div>
            <Textarea
              placeholder="Implementation notes, next steps, responsible owners..."
              value={cfg.notes || ""}
              onChange={(e) => setCfg(prev => ({ ...prev, notes: e.target.value }))}
              className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[100px]"
            />
            <div className="text-xs text-gray-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Saved to SystemConfig: {CONFIG_KEY} {configId ? `(id: ${configId})` : "(new)"}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
