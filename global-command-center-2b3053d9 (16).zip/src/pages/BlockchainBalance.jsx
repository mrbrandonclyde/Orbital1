import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import BackendHealthBadge from "@/components/common/BackendHealthBadge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Wallet, RefreshCw } from "lucide-react";

function formatEther(wei) {
  const n = typeof wei === "string" ? parseFloat(wei) : (wei || 0);
  return (Number(n) / 1e18).toFixed(6);
}

export default function BlockchainBalance() {
  const [data, setData] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  const load = async () => {
    setLoading(true);
    const res = await SpeedBackend.blockchain.balance();
    setData(res);
    setLoading(false);
  };

  React.useEffect(() => { load(); }, []);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Wallet className="w-10 h-10 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Blockchain (Web3)</h1>
            <p className="orbital-text-subtitle">Read balance from Ethereum tester provider</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <BackendHealthBadge />
          <button onClick={load} className="orbital-button-secondary flex items-center">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Balance</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="text-gray-300 text-sm space-y-2">
              <div><span className="text-gray-400">Account:</span> <span className="text-white">{data?.account || "—"}</span></div>
              <div><span className="text-gray-400">Balance (wei):</span> <span className="text-white">{data?.balance ?? "—"}</span></div>
              <div><span className="text-gray-400">Balance (ETH):</span> <span className="text-white">{data?.balance != null ? formatEther(data.balance) : "—"}</span></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}