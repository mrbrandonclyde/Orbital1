import React, { Suspense } from 'react';
import { Network, Satellite, Globe, Zap, Shield, GitBranch, Play, Settings } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere, Stars, Text } from '@react-three/drei';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";

const aetherMetrics = [
  { title: "Network Status", value: "OPERATIONAL", icon: Zap, color: "text-green-400" },
  { title: "Satellite Constellation", value: "77,000/77k", icon: Satellite, color: "text-cyan-400" },
  { title: "Global Coverage", value: "100%", icon: Globe, color: "text-blue-400" },
  { title: "Latency (Quantum)", value: "< 0.01ms", icon: GitBranch, color: "text-purple-400" },
  { title: "Security Level", value: "UNBREAKABLE", icon: Shield, color: "text-green-400" },
];

const networkSegments = [
  { id: 'orbital-leo', name: 'LEO Satellite Grid', status: 'ONLINE', traffic: '9.8 EB/s', threats_blocked: '1.2M' },
  { id: 'quantum-backbone', name: 'Quantum Entanglement Backbone', status: 'ONLINE', traffic: 'Instantaneous', threats_blocked: 'N/A' },
  { id: 'subterranean-fiber', name: 'Hardened Subterranean Fiber', status: 'ONLINE', traffic: '800 Tb/s', threats_blocked: '48k' },
  { id: 'interplanetary-link', name: 'Mars Relay Network', status: 'SYNCING', traffic: '120 Gb/s', threats_blocked: '1.2k' },
];

const AetherGlobe = () => (
  <group>
    <Sphere args={[2.5, 64, 64]}>
      <meshStandardMaterial color="#0c4a6e" wireframe={true} />
    </Sphere>
    {[...Array(200)].map((_, i) => {
      const phi = Math.acos(-1 + (2 * i) / 199);
      const theta = Math.sqrt(199 * Math.PI) * phi;
      const x = 2.6 * Math.cos(theta) * Math.sin(phi);
      const y = 2.6 * Math.sin(theta) * Math.sin(phi);
      const z = 2.6 * Math.cos(phi);
      return (
        <mesh key={i} position={[x, y, z]}>
          <sphereGeometry args={[0.015, 8, 8]} />
          <meshBasicMaterial color="#06b6d4" />
        </mesh>
      );
    })}
    <Text position={[0, -3.5, 0]} fontSize={0.4} color="#06b6d4" anchorX="center" anchorY="middle">
      AETHER NETWORK
    </Text>
  </group>
);

export default function AetherNetworkPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Network className="w-10 h-10 mr-3 text-cyan-400" />
            AETHER: The Quantum Internet
          </h1>
          <p className="orbital-text-subtitle">Private, quantum-entangled global network. Total information sovereignty.</p>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {aetherMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 3D Network Visualization */}
        <div className="glass-pane p-4 h-[500px]">
          <h3 className="orbital-text-subheading mb-4">Live Network Visualization</h3>
          <Canvas camera={{ position: [0, 0, 7], fov: 50 }}>
            <Suspense fallback={null}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} intensity={1} />
              <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade />
              <AetherGlobe />
              <OrbitControls enableZoom={true} enablePan={false} autoRotate autoRotateSpeed={0.5} />
            </Suspense>
          </Canvas>
        </div>

        {/* Network Control Panel */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Network Control Panel</h3>
          <div className="space-y-4">
            <Card className="bg-gray-800/50">
              <CardHeader>
                <CardTitle className="text-lg">Zyra AI Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Dynamic Traffic Routing</span>
                  <Switch defaultChecked id="dynamic-routing" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Predictive Threat Neutralization</span>
                  <Switch defaultChecked id="predictive-threats" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Prioritize Guardian Corps Traffic</span>
                  <Switch id="priority-traffic" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50">
              <CardHeader>
                <CardTitle className="text-lg">Information Sovereignty Protocols</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Global Information Filtering</span>
                  <Switch id="info-filtering" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Isolate Hostile Region (APAC-East)</span>
                  <Switch id="isolate-region" />
                </div>
                 <div className="flex items-center justify-between">
                  <span className="text-gray-300">Activate 'Silent Running' Mode</span>
                  <Switch id="silent-running" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Network Segment Status */}
      <div className="glass-pane p-4 mt-6">
        <h3 className="orbital-text-subheading mb-4">Network Segment Status</h3>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-transparent">
                <TableHead className="text-gray-400">Segment</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">Live Traffic</TableHead>
                <TableHead className="text-gray-400">Threats Blocked (24h)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {networkSegments.map((segment) => (
                <TableRow key={segment.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="font-medium text-white">{segment.name}</TableCell>
                  <TableCell>
                    <Badge className={segment.status === 'ONLINE' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}>{segment.status}</Badge>
                  </TableCell>
                  <TableCell className="text-cyan-400">{segment.traffic}</TableCell>
                  <TableCell className="text-red-400">{segment.threats_blocked}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}