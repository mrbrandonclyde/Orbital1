
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Globe, Users, TrendingUp, Package, Activity, Sprout, Building2, CheckCircle, Clock } from 'lucide-react';

// === Placeholder Data (Infinity Edition) ===
const kpiData = [
  { title: "Total Active Colonies", value: "6", icon: Globe, color: "text-cyan-400" },
  { title: "Colonization Success Rate", value: "85%", icon: CheckCircle, color: "text-green-400" },
  { title: "Colony Sustainability Index", value: "90%", icon: Sprout, color: "text-emerald-400" },
  { title: "Resource Efficiency", value: "78%", icon: Package, color: "text-yellow-400" },
  { title: "Colonial Growth Rate", value: "12%", icon: TrendingUp, color: "text-purple-400" },
];

const colonizationProgressData = [
  { month: "Jan", progress: 40 },
  { month: "Feb", progress: 50 },
  { month: "Mar", progress: 60 },
  { month: "Apr", progress: 70 },
  { month: "May", progress: 80 },
  { month: "Jun", progress: 82 },
  { month: "Jul", progress: 85 },
];

const sustainabilityData = [
  { colony: "Mars Alpha", resources: 92, ecosystem: 85, stability: 95 },
  { colony: "Europa Station", resources: 80, ecosystem: 75, stability: 90 },
  { colony: "Titan Outpost", resources: 75, ecosystem: 82, stability: 80 },
  { colony: "Callisto Base", resources: 70, ecosystem: 70, stability: 78 },
];

const growthRateData = [
  { colony: "Mars Alpha", growthRate: 5.2 },
  { colony: "Europa Station", growthRate: 4.1 },
  { colony: "Titan Outpost", growthRate: 6.5 },
  { colony: "New Eden", growthRate: 15.1 },
];

const deploymentLog = [
  { id: "#C-501", name: "Titan Colony", planet: "Titan", status: "In Progress", growthStage: "Expansion" },
  { id: "#C-502", name: "Mars Base Alpha", planet: "Mars", status: "Operational", growthStage: "Full Operation" },
  { id: "#C-503", name: "Europa Ice-Miner", planet: "Europa", status: "Operational", growthStage: "Stable" },
  { id: "#C-504", name: "New Eden", planet: "Kepler-186f", status: "In Progress", growthStage: "Settlement" },
];

const resourceLog = [
  { date: "2025-09-01", colony: "Mars Alpha", resource: "Water Ice", usage: "150 tons", notes: "Stable consumption" },
  { date: "2025-09-02", colony: "Titan Outpost", resource: "Methane Gas", usage: "200 tons", notes: "Increased energy demand" },
  { date: "2025-09-01", colony: "Europa Station", resource: "Rare Earth Metals", usage: "35 tons", notes: "Production at 90%" },
];

const populationLog = [
  { date: "2025-09-01", colony: "Mars Alpha", population: "1,500", growthRate: "5.2%", action: "Infrastructure expansion approved" },
  { date: "2025-09-02", colony: "Europa Station", population: "300", growthRate: "4.1%", action: "New science team arrived" },
  { date: "2025-08-31", colony: "New Eden", population: "150", growthRate: "15.1%", action: "First-wave settlers adapting well" },
];

const ChartTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color || entry.fill }}>{`${entry.name}: ${entry.value}`}</p>
        ))}
      </div>
    );
  }
  return null;
};

const getStatusBadge = (status) => {
    if (status === "Operational") return <Badge className="bg-green-500/10 text-green-400 border-green-500/20 flex items-center gap-1.5"><CheckCircle className="w-3 h-3"/>{status}</Badge>;
    if (status === "In Progress") return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 flex items-center gap-1.5"><Clock className="w-3 h-3"/>{status}</Badge>;
    return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
};

export default function ColonizationPage() {
  const [timeframe, setTimeframe] = useState('90D');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Page Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Globe className="w-10 h-10 mr-3 text-emerald-400" />
            Colonization Operations
          </h1>
          <p className="orbital-page-subtitle">Oversight for all planetary settlement, sustainability, and development initiatives.</p>
        </div>
        <div className="flex items-center space-x-4">
          {/* Timeframe filter can be added here */}
        </div>
      </div>

      {/* Frame 1: KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {kpiData.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                <Icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
            </div>
          );
        })}
      </div>

      {/* Frame 2: Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Colonization Progress</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={colonizationProgressData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9CA3AF" />
              <YAxis domain={[0, 100]} stroke="#9CA3AF" />
              <Tooltip content={<ChartTooltip />} />
              {/* Changed stroke color to align with emerald-400 for consistency */}
              <Line type="monotone" dataKey="progress" name="Progress %" stroke="#34D399" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Colony Sustainability Index</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={sustainabilityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="colony" stroke="#9CA3AF" />
                <YAxis domain={[0, 100]} stroke="#9CA3AF" />
                <Tooltip content={<ChartTooltip />} />
                {/* Added wrapperStyle to Legend for consistent text color */}
                <Legend wrapperStyle={{ color: '#E5E7EB', fontSize: '12px' }} />
                {/* Changed fill colors to align with brand palette */}
                <Bar dataKey="resources" stackId="a" fill="#FACC15" name="Resources"/> {/* yellow-400 */}
                <Bar dataKey="ecosystem" stackId="a" fill="#34D399" name="Ecosystem" /> {/* emerald-400 */}
                <Bar dataKey="stability" stackId="a" fill="#22D3EE" name="Stability" /> {/* cyan-400 */}
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Colonial Growth Rate</h3>
            <ResponsiveContainer width="100%" height={250}>
                <BarChart data={growthRateData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="colony" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip content={<ChartTooltip />} />
                    {/* Changed fill color to align with purple-400 for consistency */}
                    <Bar dataKey="growthRate" name="Growth Rate %" fill="#A78BFA" />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </div>

      {/* Frame 3: Logs */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="glass-pane p-4 xl:col-span-2">
            <h3 className="orbital-text-subheading mb-4 flex items-center"><Building2 className="w-5 h-5 mr-2 text-cyan-400"/>Colony Deployment Log</h3>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader><TableRow className="border-gray-700 hover:bg-transparent"><TableHead>ID</TableHead><TableHead>Name</TableHead><TableHead>Planet</TableHead><TableHead>Status</TableHead><TableHead>Growth Stage</TableHead></TableRow></TableHeader>
                    <TableBody>
                        {deploymentLog.map(row => (
                            <TableRow key={row.id} className="border-gray-800 hover:bg-gray-800/30">
                                <TableCell className="font-mono text-xs">{row.id}</TableCell>
                                <TableCell className="font-medium text-white">{row.name}</TableCell>
                                <TableCell>{row.planet}</TableCell>
                                <TableCell>{getStatusBadge(row.status)}</TableCell>
                                <TableCell><Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">{row.growthStage}</Badge></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
        <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center"><Package className="w-5 h-5 mr-2 text-yellow-400"/>Resource Usage Log</h3>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader><TableRow className="border-gray-700 hover:bg-transparent"><TableHead>Colony</TableHead><TableHead>Resource</TableHead><TableHead>Usage</TableHead><TableHead>Notes</TableHead></TableRow></TableHeader>
                    <TableBody>
                        {resourceLog.map((row, i) => (
                            <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                                <TableCell className="font-medium text-white">{row.colony}</TableCell>
                                <TableCell>{row.resource}</TableCell>
                                <TableCell>{row.usage}</TableCell>
                                <TableCell className="text-gray-400">{row.notes}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
        <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center"><Users className="w-5 h-5 mr-2 text-purple-400"/>Population Log</h3>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader><TableRow className="border-gray-700 hover:bg-transparent"><TableHead>Colony</TableHead><TableHead>Population</TableHead><TableHead>Growth</TableHead><TableHead>Notes</TableHead></TableRow></TableHeader>
                    <TableBody>
                        {populationLog.map((row, i) => (
                            <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                                <TableCell className="font-medium text-white">{row.colony}</TableCell>
                                <TableCell>{row.population}</TableCell>
                                {/* Keep existing color for growth rate, common for positive indicators */}
                                <TableCell className="text-green-400">{row.growthRate}</TableCell>
                                <TableCell className="text-gray-400">{row.action}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
      </div>
    </div>
  );
}
