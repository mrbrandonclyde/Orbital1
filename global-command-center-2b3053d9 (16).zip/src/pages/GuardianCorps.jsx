import React, { useState } from 'react';
import { Shield, Brain, Zap, TrendingUp, Users, Target } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

const corpsMetrics = [
  { title: "Guardian Strength", value: "247", icon: Users, color: "text-blue-400" },
  { title: "AI Symbiosis Rate", value: "98.2%", icon: Brain, color: "text-purple-400" },
  { title: "Mission Success", value: "100%", icon: Target, color: "text-green-400" },
  { title: "Zero Casualty Record", value: "Active", icon: Shield, color: "text-green-400" },
  { title: "Operational Readiness", value: "PEAK", icon: Zap, color: "text-yellow-400" },
];

const guardians = [
  {
    id: "GC-001",
    callsign: "Wraith",
    rank: "Guardian Prime",
    specialty: "Stealth Infiltration",
    status: "ACTIVE",
    performance: 98,
    avatar: "https://i.pravatar.cc/150?u=gc001"
  },
  {
    id: "GC-007",
    callsign: "Apex",
    rank: "Elite Guardian",
    specialty: "Strategic Command",
    status: "ACTIVE",
    performance: 95,
    avatar: "https://i.pravatar.cc/150?u=gc007"
  },
  {
    id: "GC-012",
    callsign: "Kestrel",
    rank: "Guardian",
    specialty: "Recon & Analysis",
    status: "ON MISSION",
    performance: 92,
    avatar: "https://i.pravatar.cc/150?u=gc012"
  },
  {
    id: "GC-023",
    callsign: "Rhino",
    rank: "Guardian",
    specialty: "Heavy Assault",
    status: "STANDBY",
    performance: 89,
    avatar: "https://i.pravatar.cc/150?u=gc023"
  }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'ON MISSION': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">ON MISSION</Badge>;
    case 'STANDBY': return <Badge className="bg-yellow-500/20 text-yellow-400">STANDBY</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getRankBadge = (rank) => {
  switch (rank) {
    case 'Guardian Prime': return <Badge className="bg-purple-500/20 text-purple-400">{rank}</Badge>;
    case 'Elite Guardian': return <Badge className="bg-cyan-500/20 text-cyan-400">{rank}</Badge>;
    case 'Guardian': return <Badge className="bg-gray-500/20 text-gray-400">{rank}</Badge>;
    default: return <Badge>{rank}</Badge>;
  }
};

export default function GuardianCorpsPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Shield className="w-10 h-10 mr-3 text-purple-400" />
            Guardian Corps
          </h1>
          <p className="orbital-text-subtitle">AI-Enhanced Human Assets for Global Stability Operations.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {corpsMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Guardian Roster</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Guardian</TableHead>
              <TableHead className="text-gray-400">Rank</TableHead>
              <TableHead className="text-gray-400">Specialty</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Performance Index</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {guardians.map((guardian) => (
              <TableRow key={guardian.id} className="border-gray-800 hover:bg-gray-800/30">
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10 border-2 border-purple-500/50">
                      <AvatarImage src={guardian.avatar} />
                      <AvatarFallback>{guardian.callsign.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-white">{guardian.callsign}</p>
                      <p className="text-sm text-gray-400 font-mono">{guardian.id}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{getRankBadge(guardian.rank)}</TableCell>
                <TableCell className="text-gray-300">{guardian.specialty}</TableCell>
                <TableCell>{getStatusBadge(guardian.status)}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-700 rounded-full h-2.5">
                      <div 
                        className="bg-gradient-to-r from-purple-500 to-cyan-500 h-2.5 rounded-full" 
                        style={{ width: `${guardian.performance}%`}}
                      ></div>
                    </div>
                    <span className="font-semibold text-white">{guardian.performance}%</span>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}