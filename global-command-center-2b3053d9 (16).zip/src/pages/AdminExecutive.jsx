import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Crown, Settings, BarChart3, Home } from "lucide-react";

export default function AdminExecutivePage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Crown className="w-10 h-10 mr-3 text-purple-400" />
          Admin / Executive Profile
        </h1>
        <p className="orbital-text-subtitle">Global dashboards, KPIs, and administration.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Link to={createPageUrl('Executive')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Crown className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Executive Profile</h3>
          </div>
          <p className="text-gray-400 text-sm">KPIs and strategic priorities.</p>
        </Link>

        <Link to={createPageUrl('Admin')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white font-semibold">System Admin</h3>
          </div>
          <p className="text-gray-400 text-sm">Core settings and governance.</p>
        </Link>

        <Link to={createPageUrl('CommandCenter')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Home className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">Command Center</h3>
          </div>
          <p className="text-gray-400 text-sm">Unified global ops hub.</p>
        </Link>

        <Link to={createPageUrl('Analytics')} className="glass-pane p-6 hover:border-purple-500/40">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Analytics</h3>
          </div>
          <p className="text-gray-400 text-sm">Trends, metrics, and drill‑downs.</p>
        </Link>
      </div>
    </div>
  );
}