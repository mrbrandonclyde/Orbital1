
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import WizardProgress from "../components/funnels/wizard/WizardProgress";
import StepType from "../components/funnels/wizard/StepType";
import StepGoal from "../components/funnels/wizard/StepGoal";
import StepTemplates from "../components/funnels/wizard/StepTemplates";
import StepSetup from "../components/funnels/wizard/StepSetup";
import StepConfirm from "../components/funnels/wizard/StepConfirm";
import { Funnel } from "@/api/entities";
import { FunnelStep } from "@/api/entities";
import { FunnelTemplate } from "@/api/entities";
import { User } from "@/api/entities";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function FunnelWizard() {
  const [step, setStep] = React.useState(1);
  const [type, setType] = React.useState("OPTIN");
  const [goal, setGoal] = React.useState("");
  const [templates, setTemplates] = React.useState([]);
  const [selectedTemplate, setSelectedTemplate] = React.useState(null);
  const [form, setForm] = React.useState({ name: "", tags: "", campaign: "", description: "", is_private: false });
  const [saving, setSaving] = React.useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    const load = async () => {
      const list = await FunnelTemplate.list();
      setTemplates(list);

      // Auto-select template by URL param
      const urlParams = new URLSearchParams(window.location.search);
      const tplId = urlParams.get("template");
      if (tplId) {
        const found = list.find(t => String(t.id) === String(tplId));
        if (found) {
          setSelectedTemplate(found);
          setStep(4); // jump to setup if selected
        } else {
          // If tplId is provided but template not found, stay at step 1
          setStep(1);
        }
      }
    };
    load();
  }, []);

  const next = () => setStep(Math.min(5, step + 1));
  const back = () => setStep(Math.max(1, step - 1));

  const canNext = () => {
    if (step === 1) return !!type;
    if (step === 2) return !!goal || true; // optional
    if (step === 3) return true; // template optional
    if (step === 4) return !!form.name?.trim();
    return true;
  };

  const buildNow = async () => {
    setSaving(true);
    const me = await User.me().catch(() => null);
    const tags = (form.tags || "").split(",").map(t => t.trim()).filter(Boolean);
    const payload = {
      funnel_name: form.name.trim() || "Untitled",
      type: type,
      group_tags: tags,
      status: "DRAFT",
      description: form.description || "",
      campaign: form.campaign || undefined,
      is_private: !!form.is_private,
      account_id: me?.account_id
    };
    // Create funnel
    const nf = await Funnel.create(payload);

    // Scaffold steps from template
    if (selectedTemplate?.steps_blueprint?.length) {
      const createdSteps = [];
      for (const sb of selectedTemplate.steps_blueprint) {
        const created = await FunnelStep.create({
          funnel_id: nf.id,
          step_name: sb.step_name,
          step_type: sb.step_type,
          order_index: (createdSteps.length + 1) * 100,
          path_slug: sb.path_slug,
          content_schema: sb.content_schema || { blocks: [] }
        });
        createdSteps.push(created);
      }
      if (createdSteps.length) {
        await Funnel.update(nf.id, { default_step_id: createdSteps[0].id });
      }
    }

    // Redirect to builder/editor
    window.location.href = createPageUrl(`FunnelEditor?funnel=${nf.id}`);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30" />
          <div>
            <h1 className="orbital-text-title">Create a New Funnel</h1>
            <p className="orbital-text-subtitle">Follow 5 quick steps to launch your funnel.</p>
          </div>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-3xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-white">Funnel Creation Wizard</CardTitle>
        </CardHeader>
        <CardContent>
          <WizardProgress current={step} />

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="s1" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <StepType value={type} onChange={setType} />
              </motion.div>
            )}
            {step === 2 && (
              <motion.div key="s2" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <StepGoal value={goal} onChange={setGoal} />
              </motion.div>
            )}
            {step === 3 && (
              <motion.div key="s3" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <StepTemplates templates={templates} selectedId={selectedTemplate?.id} onSelect={setSelectedTemplate} filterCategory={
                  type === "OPTIN" ? "LEAD_GEN" : type === "SALES" ? "SALES" : type === "WEBINAR" ? "WEBINAR" : type === "MEMBERSHIP" ? "MEMBERSHIP" : undefined
                } />
              </motion.div>
            )}
            {step === 4 && (
              <motion.div key="s4" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <StepSetup form={form} setForm={setForm} />
              </motion.div>
            )}
            {step === 5 && (
              <motion.div key="s5" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <StepConfirm summary={{ type, goal, template: selectedTemplate, form }} />
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-6 flex items-center justify-between">
            <Button variant="secondary" onClick={back} disabled={step === 1}>Back</Button>
            {step < 5 ? (
              <Button onClick={next} disabled={!canNext()} className="bg-indigo-600 hover:bg-indigo-700">Next</Button>
            ) : (
              <Button onClick={buildNow} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
                {saving ? "Building…" : "Build Funnel Now"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
