import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Zap, Target, Gauge, ShieldAlert, GitCommit, CheckCircle, Clock } from 'lucide-react';

// === Placeholder Data (Infinity Edition) ===
const kpiData = [
  { title: "Quantum Data Processing Rate", value: "500k", unit: " pts/sec", icon: Zap, color: "text-purple-400" },
  { title: "Prediction Accuracy", value: "95%", icon: Target, color: "text-green-400" },
  { title: "Quantum Efficiency Index", value: "88%", icon: Gauge, color: "text-cyan-400" },
  { title: "Anomaly Detection Rate", value: "98%", icon: ShieldAlert, color: "text-yellow-400" },
  { title: "Complexity Reduction", value: "40%", icon: GitCommit, color: "text-blue-400" },
];

const quantumDataFlow = [
  { time: "T-5m", dataPoints: 480000 },
  { time: "T-4m", dataPoints: 510000 },
  { time: "T-3m", dataPoints: 530000 },
  { time: "T-2m", dataPoints: 525000 },
  { time: "T-1m", dataPoints: 550000 },
  { time: "Now", dataPoints: 545000 },
];

const predictionAccuracyData = [
  { date: "Jan", accuracy: 92 },
  { date: "Feb", accuracy: 94 },
  { date: "Mar", accuracy: 95 },
  { date: "Apr", accuracy: 96 },
  { date: "May", accuracy: 97 },
  { date: "Jun", accuracy: 96.5 },
];

const algorithmEfficiencyData = [
  { algorithm: "QuantumML", efficiency: 85 },
  { algorithm: "QuantumAI", efficiency: 90 },
  { algorithm: "QuantumSim", efficiency: 80 },
  { algorithm: "QuantumOpt", efficiency: 88 },
];

const quantumPredictionLog = [
  { id: "#QP-001", model: "QuantumML", dataSource: "Global Stock Data", accuracy: "95.2%", date: "2025-09-02" },
  { id: "#QP-002", model: "QuantumAI", dataSource: "Healthcare Records", accuracy: "92.8%", date: "2025-09-02" },
  { id: "#QP-003", model: "QuantumSim", dataSource: "Climate Models", accuracy: "97.1%", date: "2025-09-01" },
];

const anomalyDetectionLog = [
  { date: "2025-09-02 14:30", dataSource: "Financial Transactions", anomalyType: "Outlier Transaction", confidence: "99.8%", action: "Flagged for review" },
  { date: "2025-09-02 11:15", dataSource: "IoT Sensor Grid", anomalyType: "Coordinated Pattern Shift", confidence: "97.2%", action: "Alerted operations" },
  { date: "2025-09-01 18:45", dataSource: "Network Traffic", anomalyType: "Anomalous Data Packet", confidence: "98.5%", action: "Isolated & Analyzed" },
];

const complexityReductionLog = [
  { date: "2025-09-01", algorithm: "QuantumSimulation", before: "500 Nodes", after: "300 Nodes", improvement: "40%" },
  { date: "2025-09-02", algorithm: "QuantumOptimization", before: "1000 Vars", after: "600 Vars", improvement: "40%" },
];

const ChartTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color || entry.stroke || entry.fill }}>{`${entry.name}: ${entry.value}`}</p>
        ))}
      </div>
    );
  }
  return null;
};

const getConfidenceBadge = (confidence) => {
    const value = parseFloat(confidence);
    if (value > 99) return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">{confidence}</Badge>;
    if (value > 95) return <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">{confidence}</Badge>;
    return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">{confidence}</Badge>;
};

export default function QuantumInsightsPage() {
  const [timeframe, setTimeframe] = useState('30D');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Quantum Insights Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Zap className="w-10 h-10 mr-3 text-purple-400" />
            Quantum Insights
          </h1>
          <p className="orbital-text-subtitle">Real-time quantum data processing, predictive analytics & anomaly detection.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex bg-[#0A0D18] border border-gray-800 rounded-lg p-1">
            {['24H', '7D', '30D'].map(period => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`px-3 py-1 text-sm font-medium rounded transition-all ${
                  timeframe === period
                    ? 'bg-gradient-to-r from-purple-500 to-cyan-500 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Frame 1: KPI Cards - Quantum Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {kpiData.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                <Icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{kpi.value}<span className="text-lg text-gray-400">{kpi.unit}</span></p>
            </div>
          );
        })}
      </div>

      {/* Frame 2: Graphs - Quantum Data & Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Quantum Data Flow</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={quantumDataFlow}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip content={<ChartTooltip />} />
              <Line type="monotone" dataKey="dataPoints" name="Data Points" stroke="#8B5CF6" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Prediction Accuracy Over Time</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={predictionAccuracyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" />
              <YAxis domain={[90, 100]} stroke="#9CA3AF" />
              <Tooltip content={<ChartTooltip />} />
              <Line type="monotone" dataKey="accuracy" name="Accuracy %" stroke="#10B981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Quantum Algorithm Efficiency</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={algorithmEfficiencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="algorithm" stroke="#9CA3AF" />
              <YAxis domain={[70, 100]} stroke="#9CA3AF" />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="efficiency" name="Efficiency %" fill="#06B6D4" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Frame 3: Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Quantum Prediction Log</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Model</TableHead>
                  <TableHead className="text-gray-400">Data Source</TableHead>
                  <TableHead className="text-gray-400">Accuracy</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quantumPredictionLog.map((row) => (
                  <TableRow key={row.id} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="text-white font-medium">{row.model}</TableCell>
                    <TableCell className="text-gray-300">{row.dataSource}</TableCell>
                    <TableCell className="text-green-400 font-bold">{row.accuracy}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Anomaly Detection Log</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Anomaly Type</TableHead>
                  <TableHead className="text-gray-400">Confidence</TableHead>
                  <TableHead className="text-gray-400">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {anomalyDetectionLog.map((row, i) => (
                  <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="text-white font-medium">{row.anomalyType}</TableCell>
                    <TableCell>{getConfidenceBadge(row.confidence)}</TableCell>
                    <TableCell className="text-gray-300">{row.action}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Complexity Reduction Log</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Algorithm</TableHead>
                  <TableHead className="text-gray-400">Before</TableHead>
                  <TableHead className="text-gray-400">After</TableHead>
                  <TableHead className="text-gray-400">Improvement</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {complexityReductionLog.map((row, i) => (
                  <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="text-white font-medium">{row.algorithm}</TableCell>
                    <TableCell className="text-gray-300">{row.before}</TableCell>
                    <TableCell className="text-cyan-400">{row.after}</TableCell>
                    <TableCell className="text-green-400 font-bold">{row.improvement}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
}