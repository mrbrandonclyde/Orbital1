// SONY-Style Clyde Attribution Enforcement
const { app, BrowserWindow } = require('electron');

const BRAND = "ClydeOS™ Sovereign Stack © Brandon Clyde";
const ORIGIN = "Guardian of Eternities Codex • Clyde Dynasty";

if (!BRAND.includes("ClydeOS") || !ORIGIN.includes("Brandon Clyde")) {
  throw new Error("Invalid build: Clyde attribution missing. Sovereign Law violated.");
}

function createWindow () {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true
    }
  });

  win.loadFile('index.html');
}

app.whenReady().then(createWindow);


// Initialize Chronos Engine Auto-Updater
const { initChronosUpdater } = require('./chronos_updater');
app.whenReady().then(() => {
  createWindow();
  initChronosUpdater();
});
