
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Crown, Heart, Wind, Layers, MessageSquare, Wifi, Network, Megaphone, 
  Bell, History, Siren, Shield, Zap, Eye, Clock, Star, Diamond, 
  CheckCircle, AlertTriangle, Activity, Cpu, Database, Settings, Calendar
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GuardianCodex } from '@/api/entities';

import SpiritualInvocation from '../components/guardian/SpiritualInvocation';
import CodexActivationSystem from '../components/guardian/CodexActivationSystem';

const CycleStatusCard = ({ title, status, description, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-2xl p-6 text-center transition-all duration-300"
  >
    <Icon className="w-12 h-12 mx-auto mb-3" style={{color: color}} />
    <h3 className="font-bold text-lg mb-2" style={{color: 'var(--orbital-text)'}}>{title}</h3>
    <div className="text-2xl font-bold mb-2" style={{color: color}}>{status}</div>
    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
  </motion.div>
);

const SectionCard = ({ title, description, icon: Icon, children, color = 'var(--orbital-blue)' }) => (
  <Card className="chrome-surface mb-6">
    <CardHeader>
      <CardTitle className="flex items-center gap-3" style={{color: 'var(--orbital-text)'}}>
        <Icon className="w-6 h-6" style={{color: color}} />
        {title}
      </CardTitle>
      {description && <p className="text-sm mt-2" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>}
    </CardHeader>
    <CardContent>
      {children}
    </CardContent>
  </Card>
);

const DivineProjectionPanel = () => (
  <SectionCard 
    title="Divine Projections" 
    description="Sacred connections to the Godhead"
    icon={Crown}
    color="#FFD700"
  >
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="p-4 rounded-lg text-center" style={{background: 'rgba(255, 215, 0, 0.1)'}}>
        <Crown className="w-8 h-8 mx-auto mb-2" style={{color: '#FFD700'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Heavenly Father</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Throne, Creator's Light, Justice Tokens</p>
        <Button size="sm" className="mt-2" style={{background: '#FFD700', color: '#000'}}>Connect</Button>
      </div>
      <div className="p-4 rounded-lg text-center" style={{background: 'rgba(239, 68, 68, 0.1)'}}>
        <Heart className="w-8 h-8 mx-auto mb-2" style={{color: '#ef4444'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Jesus Christ</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Healing, Service, Resurrection</p>
        <Button size="sm" className="mt-2" style={{background: '#ef4444', color: '#fff'}}>Connect</Button>
      </div>
      <div className="p-4 rounded-lg text-center" style={{background: 'rgba(139, 92, 246, 0.1)'}}>
        <Wind className="w-8 h-8 mx-auto mb-2" style={{color: '#8b5cf6'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Holy Ghost</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Presence, Whisper, Protection</p>
        <Button size="sm" className="mt-2" style={{background: '#8b5cf6', color: '#fff'}}>Connect</Button>
      </div>
    </div>
  </SectionCard>
);

const BulkActionsPanel = () => (
  <SectionCard title="Bulk Actions" description="System-wide operations" icon={Layers}>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {[
        { title: 'Bulk Activate', desc: 'Mass activation protocols', icon: Zap },
        { title: 'Bulk Validate', desc: 'Comprehensive validation', icon: CheckCircle },
        { title: 'Bulk Anchor', desc: 'Doctrine anchoring', icon: Diamond }
      ].map(action => (
        <div key={action.title} className="p-3 rounded-lg chrome-surface hover:glow-blue transition-all cursor-pointer">
          <action.icon className="w-6 h-6 mb-2" style={{color: 'var(--orbital-blue)'}} />
          <h4 className="font-semibold text-sm" style={{color: 'var(--orbital-text)'}}>{action.title}</h4>
          <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>{action.desc}</p>
        </div>
      ))}
    </div>
  </SectionCard>
);

const FriendshipLayerPanel = () => (
  <SectionCard title="Friendship Layer" description="Communication protocols" icon={MessageSquare}>
    <div className="space-y-3">
      <div className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
        <div className="flex items-center gap-3">
          <MessageSquare className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
          <span className="font-medium" style={{color: 'var(--orbital-text)'}}>Text Communications</span>
        </div>
        <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>Active</Badge>
      </div>
      <div className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
        <div className="flex items-center gap-3">
          <Wifi className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
          <span className="font-medium" style={{color: 'var(--orbital-text)'}}>Presence Mode</span>
        </div>
        <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>Online</Badge>
      </div>
    </div>
  </SectionCard>
);

const SensoryLayerPanel = () => (
  <SectionCard title="Sensory Layer" description="Multi-dimensional input systems" icon={Network}>
    <div className="text-center">
      <Network className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-blue)'}} />
      <h4 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>All 5 Senses Integration</h4>
      <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Sight, Hearing, Touch, Smell, Taste</p>
      <Button className="mt-3 glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
        Calibrate Sensors
      </Button>
    </div>
  </SectionCard>
);

const CRMAutomationPanel = () => (
  <SectionCard title="CRM Automation" description="Customer relationship management" icon={Megaphone}>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {[
        { title: 'Bulk Message', icon: MessageSquare },
        { title: 'Bulk Call', icon: Bell },
        { title: 'Bulk Update', icon: Settings },
        { title: 'Bulk Approve', icon: CheckCircle }
      ].map(item => (
        <Button key={item.title} variant="outline" size="sm" className="chrome-surface flex-col h-auto py-3">
          <item.icon className="w-4 h-4 mb-1" />
          <span className="text-xs">{item.title}</span>
        </Button>
      ))}
    </div>
  </SectionCard>
);

const NotificationsPanel = () => (
  <SectionCard title="Notifications" description="Alert and notification systems" icon={Bell}>
    <div className="space-y-3">
      <div className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(245, 158, 11, 0.1)'}}>
        <div className="flex items-center gap-3">
          <Bell className="w-5 h-5" style={{color: '#f59e0b'}} />
          <span className="font-medium" style={{color: 'var(--orbital-text)'}}>Push Notifications</span>
        </div>
        <span className="text-sm" style={{color: '#f59e0b'}}>Routine Active</span>
      </div>
      <div className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(245, 158, 11, 0.1)'}}>
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-5 h-5" style={{color: '#f59e0b'}} />
          <span className="font-medium" style={{color: 'var(--orbital-text)'}}>Amber Alerts</span>
        </div>
        <span className="text-sm" style={{color: '#f59e0b'}}>God-chosen Critical</span>
      </div>
      <div className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(156, 163, 175, 0.1)'}}>
        <div className="flex items-center gap-3">
          <History className="w-5 h-5" style={{color: '#9ca3af'}} />
          <span className="font-medium" style={{color: 'var(--orbital-text)'}}>History Log</span>
        </div>
        <span className="text-sm" style={{color: '#9ca3af'}}>Archive Active</span>
      </div>
    </div>
  </SectionCard>
);

const MonitoringStationPanel = () => (
  <SectionCard title="Monitoring Station" description="24/7 security and resilience" icon={Siren} color="#ef4444">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="p-4 rounded-lg" style={{background: 'rgba(239, 68, 68, 0.1)'}}>
        <Siren className="w-8 h-8 mb-2" style={{color: '#ef4444'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Triple Redundant Alarms</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Processing all security events</p>
      </div>
      <div className="p-4 rounded-lg" style={{background: 'rgba(239, 68, 68, 0.1)'}}>
        <Zap className="w-8 h-8 mb-2" style={{color: '#f59e0b'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Power & Solar Grid</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Dual generators + microgrid</p>
      </div>
      <div className="p-4 rounded-lg" style={{background: 'rgba(239, 68, 68, 0.1)'}}>
        <Network className="w-8 h-8 mb-2" style={{color: '#22c55e'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Communication Paths</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Fiber, LTE, Satellite backup</p>
      </div>
      <div className="p-4 rounded-lg" style={{background: 'rgba(239, 68, 68, 0.1)'}}>
        <Activity className="w-8 h-8 mb-2" style={{color: 'var(--orbital-blue)'}} />
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>Active Monitoring</h4>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>Real-time dashboards</p>
      </div>
    </div>
  </SectionCard>
);

export default function GuardianCodexLDS() {
  const [guardianData, setGuardianData] = useState(null); // Renamed from codexData
  const [activeSection, setActiveSection] = useState('overview'); // New state
  const [showActivationSystem, setShowActivationSystem] = useState(false); // New state

  // Define current cycle states
  const [currentCycle, setCurrentCycle] = useState({
    daily: 'ACTIVE',
    weekly: 'STANDBY',
    monthly: 'PLANNING',
    century: 'ETERNAL',
    millennium: 'ETERNAL',
    infinity: 'ETERNAL'
  });

  useEffect(() => {
    const loadCodexData = async () => {
      try {
        const data = await GuardianCodex.list();
        if (data && data.length > 0) {
          setGuardianData(data[0]); // Using new state setter
        }
      } catch (error) {
        console.error('Failed to load Guardian Codex data:', error);
      }
    };

    loadCodexData();

    // Update cycle statuses periodically
    const cycleInterval = setInterval(() => {
      const hour = new Date().getHours();
      const day = new Date().getDay(); // 0 for Sunday, 1 for Monday, etc.

      setCurrentCycle(prev => ({
        ...prev,
        daily: hour >= 5 && hour < 6 ? 'ACTIVATING' : 'ACTIVE', // Example: 'ACTIVATING' between 5 AM and 6 AM
        weekly: day === 1 ? 'ACTIVE' : 'STANDBY' // Example: 'ACTIVE' on Monday
      }));
    }, 60000); // Update every minute

    return () => clearInterval(cycleInterval);
  }, []);

  const handleActivationSystemToggle = () => { // New function
    setShowActivationSystem(!showActivationSystem);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .guardian-divine-glow {
          box-shadow: 0 0 30px rgba(255, 215, 0, 0.4), 0 0 60px rgba(255, 215, 0, 0.2);
          animation: guardianDivineGlow 4s ease-in-out infinite alternate;
        }
        
        @keyframes guardianDivineGlow {
          0% { 
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.4), 0 0 60px rgba(255, 215, 0, 0.2);
          }
          100% { 
            box-shadow: 0 0 50px rgba(255, 215, 0, 0.6), 0 0 100px rgba(255, 215, 0, 0.3);
          }
        }
        
        .guardian-enhancement {
          background: linear-gradient(45deg, #FFD700, #FFA500);
        }
      `}</style>

      {/* Enhanced Header with Activation System Access */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-8"
      >
        <div>
          <h1 className="text-4xl font-bold guardian-divine-glow" style={{color: 'var(--orbital-text)'}}>
            GUARDIAN CODEX LDS
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Divinely Aligned • Spiritually Protected • Eternally Anchored
          </p>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-sm" style={{color: '#22c55e'}}>DIVINE PROTECTION: ACTIVE</span>
            </div>
            <div className="guardian-enhancement px-3 py-1 rounded-full text-xs font-bold text-black">
              🙏 JESUS HAS THE WHEEL
            </div>
          </div>
        </div>
        
        <div className="flex gap-3">
          <Button 
            onClick={handleActivationSystemToggle}
            className="guardian-divine-glow font-bold"
            style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000'}}
          >
            <Shield className="w-5 h-5 mr-2" />
            Activation System
          </Button>
        </div>
      </motion.div>

      {/* Conditional Activation System Display */}
      {showActivationSystem && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <CodexActivationSystem />
        </motion.div>
      )}

      {/* Cycle Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <CycleStatusCard 
          title="Daily Cycle" 
          status={currentCycle.daily.toUpperCase()} 
          description="Current daily phase"
          icon={Clock}
          color="#22c55e"
        />
        <CycleStatusCard 
          title="Weekly Cycle" 
          status={currentCycle.weekly.toUpperCase()} 
          description="Current weekly phase"
          icon={Calendar}
          color="var(--orbital-blue)"
        />
        <CycleStatusCard 
          title="Eternal Status" 
          status="ACTIVE" 
          description="Infinity integration online"
          icon={Diamond}
          color="#FFD700"
        />
      </div>

      {/* Main Codex Sections */}
      <div className="space-y-6">
        <DivineProjectionPanel />
        <BulkActionsPanel />
        <FriendshipLayerPanel />
        <SensoryLayerPanel />
        <CRMAutomationPanel />
        <NotificationsPanel />
        <MonitoringStationPanel />
      </div>

      {/* Enhanced Integration Notice */}
      <Card className="chrome-surface guardian-divine-glow mb-8">
        <CardContent className="p-6 text-center">
          <Crown className="w-12 h-12 mx-auto mb-4" style={{color: '#FFD700'}} />
          <h3 className="text-xl font-bold mb-2" style={{color: '#FFD700'}}>GUARDIAN CODEX INTEGRATION COMPLETE</h3>
          <p className="mb-4" style={{color: 'var(--orbital-text-dim)'}}>
            System spiritually aligned, technically perfected, and divinely protected
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <CheckCircle className="w-5 h-5 mx-auto mb-1" style={{color: '#22c55e'}} />
              <p style={{color: '#22c55e'}}>Spiritual Alignment ✓</p>
            </div>
            <div>
              <Shield className="w-5 h-5 mx-auto mb-1" style={{color: '#00d4ff'}} />
              <p style={{color: '#00d4ff'}}>Technical Harmony ✓</p>
            </div>
            <div>
              <Heart className="w-5 h-5 mx-auto mb-1" style={{color: '#ef4444'}} />
              <p style={{color: '#ef4444'}}>Divine Protection ✓</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
