import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Siren, Zap, Database, Shield, Activity, Thermometer, Wifi } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

const StatusIndicator = ({ status, label, icon: Icon, color }) => (
  <motion.div 
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}40` }}
    className="chrome-surface rounded-2xl p-6 text-center transition-all duration-300"
  >
    <div className="relative inline-block mb-3">
      <Icon className="w-12 h-12" style={{color: color}} />
      <div 
        className={`absolute top-0 right-0 w-4 h-4 rounded-full border-2 border-black ${status === 'online' ? 'bg-green-400 animate-pulse' : 'bg-red-500'}`} 
        style={{boxShadow: `0 0 10px ${status === 'online' ? '#22c55e' : '#ef4444'}`}}
      />
    </div>
    <h3 className="font-bold text-lg mb-1" style={{color: 'var(--orbital-text)'}}>{label}</h3>
    <Badge style={{background: `${color}20`, color: color}}>{status.toUpperCase()}</Badge>
  </motion.div>
);

const LogEntry = ({ log, index }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: index * 0.1 }}
    className="flex items-center gap-3 p-2 rounded-lg"
    style={{background: 'rgba(0, 212, 255, 0.05)'}}
  >
    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-full" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
      <log.icon className="w-4 h-4" style={{color: 'var(--orbital-blue)'}}/>
    </div>
    <div className="flex-grow">
      <p className="text-sm font-medium" style={{color: 'var(--orbital-text)'}}>{log.message}</p>
      <p className="text-xs font-mono" style={{color: 'var(--orbital-text-dim)'}}>{new Date(log.timestamp).toISOString()}</p>
    </div>
    <Badge variant="outline" className="text-xs" style={{borderColor: log.color, color: log.color}}>{log.status}</Badge>
  </motion.div>
);

export default function MonitoringStation() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const initialLogs = [
      { message: 'System boot complete. All systems nominal.', status: 'OK', icon: Shield, color: '#22c55e', timestamp: Date.now() },
      { message: 'Solar grid charging initiated.', status: 'INFO', icon: Zap, color: '#f59e0b', timestamp: Date.now() - 10000 },
      { message: 'Immutable log anchor verified on blockchain.', status: 'SECURE', icon: Database, color: 'var(--orbital-blue)', timestamp: Date.now() - 25000 },
      { message: 'Alarm system self-test successful.', status: 'OK', icon: Siren, color: '#22c55e', timestamp: Date.now() - 40000 },
    ];
    setLogs(initialLogs);

    const logInterval = setInterval(() => {
      setLogs(prev => [
        { message: 'Routine security scan complete. No threats found.', status: 'SECURE', icon: Shield, color: 'var(--orbital-blue)', timestamp: Date.now() },
        ...prev
      ].slice(0, 20));
    }, 15000);

    return () => clearInterval(logInterval);
  }, []);

  return (
    <div style={{color: 'var(--orbital-text)'}}>
       <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
        <h1 className="text-4xl font-bold">MONITORING STATION</h1>
        <p className="text-lg mt-2 mb-8" style={{color: 'var(--orbital-text-dim)'}}>
          24/7 Security, Redundancy, and Immutable Event Logging
        </p>
      </motion.div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatusIndicator status="online" label="Triple Redundant Alarms" icon={Siren} color="#ef4444" />
        <StatusIndicator status="online" label="Solar + Dual Generators" icon={Zap} color="#f59e0b" />
        <StatusIndicator status="online" label="Immutable Logs" icon={Database} color="var(--orbital-blue)" />
        <StatusIndicator status="online" label="Security Alerts" icon={Shield} color="#22c55e" />
      </div>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
            LIVE EVENT FEED
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 pr-4">
            <div className="space-y-2">
              {logs.map((log, index) => (
                <LogEntry key={log.timestamp} log={log} index={index} />
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}