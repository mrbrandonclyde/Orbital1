import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Bot, Zap, Clock, Brain, CheckCircle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const TimeBlock = ({ time }) => (
  <div className="w-16 text-right pr-4" style={{ color: 'var(--orbital-text-dim)' }}>
    <div className="text-sm">{time}</div>
  </div>
);

const ScheduleEvent = ({ event }) => {
  const colors = {
    task: '#00d4ff',
    mission: '#8b5cf6',
    focus_block: '#22c55e',
    recharge: '#f59e0b',
  };
  const Icon = {
    task: CheckCircle,
    mission: Zap,
    focus_block: Brain,
    recharge: Clock,
  }[event.type];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-3 rounded-lg flex items-start gap-3"
      style={{
        background: `${colors[event.type]}20`,
        borderLeft: `4px solid ${colors[event.type]}`,
      }}
    >
      <Icon className="w-4 h-4 mt-1" style={{ color: colors[event.type] }} />
      <div>
        <p className="font-semibold" style={{ color: 'var(--orbital-text)' }}>{event.title}</p>
        <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>{event.agent}</p>
      </div>
    </motion.div>
  );
};

const mockSchedule = [
    { hour: 8, events: [{ title: 'Quantum Encryption Analysis', type: 'focus_block', agent: 'Nexus-7' }] },
    { hour: 9, events: [{ title: 'Deploy Security Drones', type: 'task', agent: 'Aura-3' }] },
    { hour: 10, events: [{ title: 'Mission Brief: Sector Gamma', type: 'mission', agent: 'All Units' }] },
    { hour: 11, events: [] },
    { hour: 12, events: [{ title: 'System Recharge & Sync', type: 'recharge', agent: 'All Units' }] },
    { hour: 13, events: [{ title: 'Analyze Trade Route Data', type: 'task', agent: 'Oracle-9' }] },
    { hour: 14, events: [{ title: 'World Builder Architecture Design', type: 'focus_block', agent: 'Genesis-1' }] },
];

export default function MissionScheduler() {
  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">MISSION SCHEDULER</h1>
          <p style={{ color: 'var(--orbital-text-dim)' }}>Autonomous calendar for the entire AI Human fleet.</p>
        </div>
        <Button className="font-bold glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
          <Plus className="w-5 h-5 mr-2" />
          Schedule Mission
        </Button>
      </div>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>Fleet Daily Agenda</span>
            <div className="flex items-center gap-2 text-sm px-3 py-1 rounded-full" style={{background: 'rgba(139, 92, 246, 0.2)', color: '#a78bfa'}}>
              <Bot className="w-4 h-4" />
              AI AUTOPILOT ACTIVE
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {mockSchedule.map(({ hour, events }) => (
              <div key={hour} className="flex">
                <TimeBlock time={`${hour}:00`} />
                <div className="flex-1 border-l border-dashed pl-4 py-2" style={{borderColor: 'var(--orbital-blue-dim)'}}>
                  {events.length > 0 ? (
                    <div className="space-y-2">
                      {events.map((event, index) => (
                        <ScheduleEvent key={index} event={event} />
                      ))}
                    </div>
                  ) : <div className="h-8"/>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}