import React from 'react';
import { motion } from 'framer-motion';
import { Layers, Zap, CheckCircle, Diamond, Database, Users, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ActionCard = ({ title, description, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -8, boxShadow: `0 0 35px ${color}50` }}
    className="chrome-surface rounded-2xl p-8 text-center transition-all duration-300 flex flex-col items-center justify-center h-full"
  >
    <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{background: `${color}20`, border: `2px solid ${color}`}}>
      <Icon className="w-8 h-8" style={{color: color}} />
    </div>
    <h3 className="font-bold text-xl mb-2" style={{color: 'var(--orbital-text)'}}>{title}</h3>
    <p className="text-sm mb-6 flex-grow" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    <Button style={{background: color, color: '#000', fontWeight: 'bold'}}>Initiate</Button>
  </motion.div>
);

export default function BulkActions() {
  const actions = [
    { title: 'Bulk Activate', description: 'Run mass activation protocols for users, assets, or systems.', icon: Zap, color: '#00d4ff' },
    { title: 'Bulk Validate', description: 'Perform comprehensive validation across all immutable records and assets.', icon: CheckCircle, color: '#22c55e' },
    { title: 'Bulk Anchor', description: 'Anchor all pending doctrines and system states to the eternal blockchain.', icon: Diamond, color: '#FFD700' },
    { title: 'Bulk Archive', description: 'Securely archive historical data and logs according to eternal retention policies.', icon: Database, color: '#8b5cf6' },
    { title: 'Bulk Onboard', description: 'Process a large queue of divinely selected users for platform access.', icon: Users, color: '#f59e0b' },
    { title: 'Bulk Secure', description: 'Apply security patches and protocol upgrades across the entire platform.', icon: Shield, color: '#ef4444' },
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
        <h1 className="text-4xl font-bold">BULK ACTIONS</h1>
        <p className="text-lg mt-2 mb-8" style={{color: 'var(--orbital-text-dim)'}}>
          Execute system-wide operations with divine authority and precision
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {actions.map((action, index) => (
          <motion.div
            key={action.title}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, type: 'spring' }}
          >
            <ActionCard {...action} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}