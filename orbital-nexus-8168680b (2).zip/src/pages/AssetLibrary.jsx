import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Database, Search, Upload, Filter, Box, User, Tag } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const assetData = [
  { id: 1, name: 'Crystal Spire', type: 'Structure', polys: 15200, creator: 'Zyra' },
  { id: 2, name: 'Hovercraft Model', type: 'Vehicle', polys: 8500, creator: 'AI-Gen' },
  { id: 3, name: 'Oak Tree Pack', type: 'Flora', polys: 25000, creator: 'Orbital' },
  { id: 4, name: 'Plasma Rifle', type: 'Item', polys: 5600, creator: 'Zyra' },
  { id: 5, name: 'Cyberpunk Citizen', type: 'Character', polys: 32000, creator: 'UserX' },
  { id: 6, name: 'Rock Formation', type: 'Terrain', polys: 18000, creator: 'AI-Gen' },
];

const AssetCard = ({ asset }) => (
  <motion.div 
    whileHover={{y: -5, boxShadow: '0 0 20px rgba(0, 212, 255, 0.2)'}}
    initial={{opacity: 0, scale: 0.9}}
    animate={{opacity: 1, scale: 1}}
    className="chrome-surface rounded-xl overflow-hidden"
  >
    <div className="h-40 bg-gray-800 flex items-center justify-center">
      <Box className="w-16 h-16 text-gray-600" />
    </div>
    <div className="p-4">
      <h3 className="font-bold truncate">{asset.name}</h3>
      <div className="flex justify-between items-center text-sm text-gray-400 mt-1">
        <span>{asset.type}</span>
        <Badge variant="secondary">{asset.polys.toLocaleString()} Polys</Badge>
      </div>
       <div className="text-xs text-gray-500 mt-2">Creator: {asset.creator}</div>
    </div>
  </motion.div>
);

export default function AssetLibrary() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredAssets = assetData.filter(asset => 
    asset.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">ASSET LIBRARY</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Manage the building blocks of your universes.</p>
        </div>
        <Button className="glow-blue font-bold" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
          <Upload className="w-5 h-5 mr-2" />
          Upload Asset
        </Button>
      </motion.div>
      
      <Card className="chrome-surface p-4 mb-8">
        <div className="flex gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input 
              placeholder="Search assets by name..." 
              className="pl-9 chrome-surface"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline"><Filter className="w-4 h-4 mr-2" /> Filter by Type</Button>
        </div>
      </Card>

      <motion.div layout className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {filteredAssets.map(asset => (
          <AssetCard key={asset.id} asset={asset} />
        ))}
      </motion.div>
    </div>
  );
}