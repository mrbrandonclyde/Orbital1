import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, Atom, Clock, Scale, TestTube2, Save, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';

const ControlSlider = ({ label, value, onValueChange, min, max, step, unit }) => (
  <div>
    <label className="text-sm font-medium mb-2 block">{label}: {value[0]} {unit}</label>
    <Slider value={value} onValueChange={onValueChange} min={min} max={max} step={step} />
  </div>
);

const ControlSwitch = ({ label, checked, onCheckedChange }) => (
    <div className="flex items-center justify-between p-2 rounded-lg chrome-surface">
      <label className="text-sm font-medium">{label}</label>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
);

export default function PhysicsEngine() {
  const [gravity, setGravity] = useState([9.8]);
  const [timeDilation, setTimeDilation] = useState([1]);
  const [quantumTunneling, setQuantumTunneling] = useState(true);
  const [etherDrag, setEtherDrag] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  const handleSimulate = () => {
    setIsSimulating(true);
    setTimeout(() => setIsSimulating(false), 2000);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">PHYSICS ENGINE</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Configure the fundamental laws of your universe.</p>
        </div>
        <Button onClick={handleSimulate} disabled={isSimulating} className="glow-blue font-bold" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
          <TestTube2 className="w-5 h-5 mr-2" />
          {isSimulating ? 'SIMULATING...' : 'RUN SIMULATION'}
        </Button>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Column */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="chrome-surface">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Scale/> Universal Constants</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <ControlSlider label="Gravity" value={gravity} onValueChange={setGravity} min={0} max={50} step={0.1} unit="m/s²" />
              <ControlSlider label="Time Dilation Factor" value={timeDilation} onValueChange={setTimeDilation} min={0.1} max={10} step={0.1} unit="x" />
            </CardContent>
          </Card>

          <Card className="chrome-surface">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Atom/> Quantum Mechanics</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <ControlSwitch label="Quantum Tunneling" checked={quantumTunneling} onCheckedChange={setQuantumTunneling} />
              <ControlSwitch label="Ether Drag" checked={etherDrag} onCheckedChange={setEtherDrag} />
            </CardContent>
          </Card>
          
           <Card className="chrome-surface bg-yellow-500/10 border border-yellow-500/30">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base text-yellow-400"><AlertTriangle/> Stability Warning</CardTitle></CardHeader>
            <CardContent className="text-sm text-yellow-300">
              Low gravity and high time dilation may lead to reality fabric instability. Proceed with caution.
            </CardContent>
          </Card>

          <Button variant="outline" className="w-full"><Save className="w-4 h-4 mr-2" /> Save Physics Profile</Button>
        </div>

        {/* Preview Column */}
        <motion.div 
          className="lg:col-span-2"
          initial={{opacity:0, scale:0.9}} 
          animate={{opacity:1, scale:1}} 
          transition={{delay: 0.2}}
        >
          <Card className="chrome-surface h-full min-h-[600px] flex items-center justify-center p-4">
            <div className="w-full h-full bg-black rounded-lg relative overflow-hidden">
               <div className="absolute inset-0 flex items-center justify-center text-gray-600">
                 SIMULATION CANVAS
               </div>
               {isSimulating ? (
                 <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <p className="text-2xl animate-pulse">Running Simulation...</p>
                 </div>
               ) : (
                 <div className="absolute bottom-4 left-4 p-2 rounded-lg chrome-surface text-xs">
                    Gravity: {gravity[0]} m/s² | Time: {timeDilation[0]}x
                 </div>
               )}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}