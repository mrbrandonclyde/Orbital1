import React, { useState, useEffect } from 'react';
import { Moon, Zap, Users, Pickaxe, Home, Activity, Eye, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LunarInfrastructure as LunarInfrastructureEntity } from '@/api/entities';

const LunarBaseCard = ({ base, onClick }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(192, 192, 192, 0.4)' }}
    onClick={() => onClick(base)}
    className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 lunar-base-glow"
  >
    <style jsx>{`
      .lunar-base-glow {
        background: linear-gradient(135deg, rgba(192, 192, 192, 0.1), rgba(0, 212, 255, 0.05));
        border: 1px solid rgba(192, 192, 192, 0.3);
      }
    `}</style>
    
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center" 
           style={{background: 'rgba(192, 192, 192, 0.2)', border: '2px solid #C0C0C0'}}>
        <Moon className="w-6 h-6" style={{color: '#C0C0C0'}} />
      </div>
      <div className="flex-1">
        <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>
          {base.base_name}
        </h3>
        <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
          {base.infrastructure_type.replace('_', ' ').toUpperCase()}
        </p>
      </div>
      <Badge 
        variant={base.operational_status === 'active' ? 'default' : 'secondary'}
        style={base.operational_status === 'active' ? 
          {background: '#C0C0C0', color: '#000'} : 
          {background: 'rgba(192, 192, 192, 0.3)', color: '#C0C0C0'}
        }
      >
        {base.operational_status.toUpperCase()}
      </Badge>
    </div>

    <div className="grid grid-cols-2 gap-4 mb-4">
      <div>
        <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>PERSONNEL</p>
        <p className="font-bold" style={{color: '#C0C0C0'}}>{base.capacity?.personnel || 0}</p>
      </div>
      <div>
        <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>POWER (kW)</p>
        <p className="font-bold" style={{color: '#C0C0C0'}}>{base.capacity?.power_generation_kw || 0}</p>
      </div>
    </div>

    {base.resource_production && (
      <div className="space-y-1">
        <div className="flex justify-between text-xs">
          <span style={{color: 'var(--orbital-text-dim)'}}>He-3 Production</span>
          <span style={{color: '#C0C0C0'}}>{base.resource_production.helium3_tons_per_day} t/day</span>
        </div>
        <div className="flex justify-between text-xs">
          <span style={{color: 'var(--orbital-text-dim)'}}>Water Ice</span>
          <span style={{color: '#C0C0C0'}}>{base.resource_production.water_ice_tons_per_day} t/day</span>
        </div>
      </div>
    )}
  </motion.div>
);

export default function LunarInfrastructure() {
  const [lunarBases, setLunarBases] = useState([]);
  const [selectedBase, setSelectedBase] = useState(null);
  const [totalProduction, setTotalProduction] = useState({
    helium3: 0,
    water_ice: 0,
    power: 0
  });

  useEffect(() => {
    const initializeLunarInfrastructure = async () => {
      try {
        const bases = await LunarInfrastructureEntity.list();
        setLunarBases(bases);
      } catch (error) {
        // Fallback to demo data
        setLunarBases([
          {
            id: 'luna_base_001',
            base_name: 'Armstrong Mining Complex',
            coordinates: {latitude: 0.67, longitude: 23.47, elevation: -2400},
            infrastructure_type: 'mining',
            capacity: {personnel: 150, power_generation_kw: 2500, life_support_days: 365},
            operational_status: 'active',
            ai_optimization_score: 94.7,
            resource_production: {helium3_tons_per_day: 0.5, water_ice_tons_per_day: 12.3, rare_metals_kg_per_day: 45},
            earth_communication_delay_ms: 1300
          },
          {
            id: 'luna_base_002',
            base_name: 'Shackleton Research Outpost',
            coordinates: {latitude: -89.9, longitude: 0, elevation: 4200},
            infrastructure_type: 'research',
            capacity: {personnel: 75, power_generation_kw: 1200, life_support_days: 180},
            operational_status: 'active',
            ai_optimization_score: 97.2,
            resource_production: {helium3_tons_per_day: 0, water_ice_tons_per_day: 8.7, rare_metals_kg_per_day: 0},
            earth_communication_delay_ms: 1300
          },
          {
            id: 'luna_base_003',
            base_name: 'Mare Imbrium Spaceport',
            coordinates: {latitude: 32.8, longitude: -15.6, elevation: -1200},
            infrastructure_type: 'spaceport',
            capacity: {personnel: 200, power_generation_kw: 5000, life_support_days: 730},
            operational_status: 'construction',
            ai_optimization_score: 89.1,
            earth_communication_delay_ms: 1300
          }
        ]);
      }
    };

    initializeLunarInfrastructure();

    // Calculate total production
    const production = lunarBases.reduce((acc, base) => {
      if (base.resource_production) {
        acc.helium3 += base.resource_production.helium3_tons_per_day || 0;
        acc.water_ice += base.resource_production.water_ice_tons_per_day || 0;
      }
      if (base.capacity) {
        acc.power += base.capacity.power_generation_kw || 0;
      }
      return acc;
    }, {helium3: 0, water_ice: 0, power: 0});

    setTotalProduction(production);
  }, [lunarBases]);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx global>{`
        .lunar-glow {
          box-shadow: 0 0 25px rgba(192, 192, 192, 0.3), 0 0 50px rgba(192, 192, 192, 0.1);
          animation: lunarPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes lunarPulse {
          0% { 
            box-shadow: 0 0 25px rgba(192, 192, 192, 0.3), 0 0 50px rgba(192, 192, 192, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(192, 192, 192, 0.5), 0 0 70px rgba(192, 192, 192, 0.2);
          }
        }
      `}</style>

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold lunar-glow" style={{ color: 'var(--orbital-text)' }}>
          LUNAR INFRASTRUCTURE GRID
        </h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>
          VR/AR-enabled lunar base management with AI-optimized resource extraction and habitat systems
        </p>
        <div className="flex items-center gap-4 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gray-400 animate-pulse"></div>
            <span className="text-sm" style={{ color: '#C0C0C0' }}>LUNAR OPERATIONS: ACTIVE</span>
          </div>
          <div className="px-3 py-1 rounded-full text-xs font-bold" 
               style={{ background: 'linear-gradient(45deg, #C0C0C0, #00d4ff)', color: '#000' }}>
            🌙 LUNAR MASTERY PROTOCOL
          </div>
        </div>
      </div>

      {/* Production Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="chrome-surface lunar-glow">
          <CardContent className="p-4 text-center">
            <Pickaxe className="w-8 h-8 mx-auto mb-2" style={{ color: '#C0C0C0' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {totalProduction.helium3.toFixed(1)}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              He-3 Tons/Day
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface lunar-glow">
          <CardContent className="p-4 text-center">
            <Activity className="w-8 h-8 mx-auto mb-2" style={{ color: '#C0C0C0' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {totalProduction.water_ice.toFixed(1)}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Water Ice Tons/Day
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface lunar-glow">
          <CardContent className="p-4 text-center">
            <Zap className="w-8 h-8 mx-auto mb-2" style={{ color: '#C0C0C0' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {totalProduction.power.toLocaleString()}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Total Power (kW)
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface lunar-glow">
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 mx-auto mb-2" style={{ color: '#C0C0C0' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {lunarBases.reduce((acc, base) => acc + (base.capacity?.personnel || 0), 0)}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Total Personnel
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lunar Bases Grid */}
      <Card className="chrome-surface lunar-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
            <Moon className="w-6 h-6" style={{ color: '#C0C0C0' }} />
            ACTIVE LUNAR BASES
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lunarBases.map((base, index) => (
              <motion.div
                key={base.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <LunarBaseCard base={base} onClick={setSelectedBase} />
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}