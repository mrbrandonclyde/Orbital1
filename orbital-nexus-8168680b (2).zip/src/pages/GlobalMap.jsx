
import React, { useState, useEffect } from 'react';
import { Map, Globe, Search, Filter, Layers, Zap, Hash, Eye, Settings, Navigation, Maximize2, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GlobalMapViewer } from '../components/map/GlobalMapViewer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ZoningRule } from '@/api/entities';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';

const MapControls = ({ onViewChange, currentView }) => (
  <Card className="chrome-surface rounded-xl mb-4">
    <CardHeader className="pb-3">
      <CardTitle className="font-bold text-sm flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
        <Settings className="w-4 h-4" style={{ color: 'var(--orbital-blue)' }} />
        MAP CONTROLS
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-0">
      <div className="grid grid-cols-2 gap-2 mb-4">
        {['Planet', 'City', 'Parcel', 'Satellite'].map(view => (
          <Button
            key={view}
            variant={currentView === view ? 'default' : 'outline'}
            size="sm"
            className={`text-xs transition-all duration-200 ${currentView === view ? 'glow-blue' : 'chrome-surface hover:bg-blue-500/20'}`}
            style={currentView === view ? { background: 'var(--orbital-blue)', color: 'var(--orbital-black)' } : {}}
            onClick={() => onViewChange(view)}
          >
            {view === 'Planet' && <Globe className="w-3 h-3 mr-1" />}
            {view === 'City' && <Map className="w-3 h-3 mr-1" />}
            {view === 'Parcel' && <Navigation className="w-3 h-3 mr-1" />}
            {view === 'Satellite' && <Eye className="w-3 h-3 mr-1" />}
            {view}
          </Button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" size="sm" className="chrome-surface text-xs">
          <Maximize2 className="w-3 h-3 mr-1" />
          Fullscreen
        </Button>
        <Button variant="outline" size="sm" className="chrome-surface text-xs">
          <RotateCcw className="w-3 h-3 mr-1" />
          Reset View
        </Button>
      </div>
    </CardContent>
  </Card>
);

const ParcelSearch = ({ onSearch, searchResults, isSearching }) => (
  <Card className="chrome-surface rounded-xl mb-4">
    <CardHeader className="pb-3">
      <CardTitle className="font-bold text-sm flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
        <Search className="w-4 h-4" style={{ color: 'var(--orbital-blue)' }} />
        PARCEL SEARCH
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-0">
      <div className="space-y-3">
        <Input
          placeholder="Enter coordinates or owner wallet..."
          className="chrome-surface focus-visible:ring-2 focus-visible:ring-orbital-blue focus-visible:border-orbital-blue"
          style={{ color: 'var(--orbital-text)', borderColor: 'rgba(0, 212, 255, 0.3)' }}
          onChange={(e) => onSearch(e.target.value)}
        />
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" size="sm" className="chrome-surface text-xs">
            <Filter className="w-3 h-3 mr-1" />
            Advanced
          </Button>
          <Button
            className="glow-blue text-xs"
            size="sm"
            style={{ background: 'var(--orbital-blue)', color: 'var(--orbital-black)' }}
            disabled={isSearching}
          >
            {isSearching ? 'Searching...' : 'Search'}
          </Button>
        </div>
        {searchResults.length > 0 && (
          <div className="mt-3 space-y-2 max-h-32 overflow-y-auto">
            {searchResults.map((result, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-2 rounded-lg chrome-surface text-xs cursor-pointer hover:glow-blue"
              >
                <div className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                  Parcel #{result.id}
                </div>
                <div style={{ color: 'var(--orbital-text-dim)' }}>
                  Coords: {result.coordinates?.x || 0}, {result.coordinates?.y || 0}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </CardContent>
  </Card>
);

const OwnershipTracker = ({ trackingData }) => (
  <Card className="chrome-surface rounded-xl mb-4">
    <CardHeader className="pb-3">
      <CardTitle className="font-bold text-sm flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
        <Eye className="w-4 h-4" style={{ color: 'var(--orbital-blue)' }} />
        OWNERSHIP TRACKER
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-0">
      <div className="space-y-3 max-h-48 overflow-y-auto">
        {trackingData.map((entry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-3 rounded-lg"
            style={{ background: 'rgba(0, 212, 255, 0.05)', border: '1px solid rgba(0, 212, 255, 0.2)' }}
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-mono font-bold" style={{ color: 'var(--orbital-text)' }}>{entry.owner}</span>
              <Badge className="chrome-surface text-xs" style={{ color: 'var(--orbital-blue)', background: 'rgba(0, 212, 255, 0.1)' }}>
                {entry.parcels} Parcels
              </Badge>
            </div>
            <div className="flex justify-between items-center text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
              <span>Portfolio Value</span>
              <span className="font-bold" style={{ color: 'var(--orbital-blue)' }}>{entry.value}</span>
            </div>
            <div className="mt-2 h-1 rounded-full bg-gray-700 overflow-hidden">
              <div
                className="h-full transition-all duration-1000"
                style={{
                  width: `${Math.min(100, (entry.parcels / 50) * 100)}%`,
                  background: 'linear-gradient(90deg, var(--orbital-blue), #8b5cf6)'
                }}
              />
            </div>
          </motion.div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const ZoningRulesPanel = ({ zoningRules, onAddRule, onEditRule, loading, error }) => (
  <Card className="chrome-surface rounded-xl flex-grow">
    <CardHeader className="pb-3">
      <div className="flex justify-between items-center">
        <CardTitle className="font-bold text-sm flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
          <Layers className="w-4 h-4" style={{ color: 'var(--orbital-blue)' }} />
          ZONING RULES
        </CardTitle>
        <Button
          size="sm"
          className="glow-blue text-xs"
          style={{ background: 'var(--orbital-blue)', color: 'var(--orbital-black)' }}
          onClick={onAddRule}
          disabled={loading}
        >
          <Zap className="w-3 h-3 mr-1" />
          Add Rule
        </Button>
      </div>
    </CardHeader>
    <CardContent className="pt-0">
      {error && (
        <Alert className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full mx-auto mb-2"></div>
            <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Loading zoning rules...</p>
          </div>
        ) : (
          <>
            {zoningRules.map((rule, index) => (
              <motion.div
                key={rule.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="p-3 rounded-lg cursor-pointer hover:glow-blue transition-all duration-200"
                style={{ background: 'rgba(0, 212, 255, 0.05)', border: '1px solid rgba(0, 212, 255, 0.2)' }}
                onClick={() => onEditRule(rule)}
              >
                <div className="flex justify-between items-start mb-2">
                  <p className="font-bold text-sm" style={{ color: 'var(--orbital-text)' }}>{rule.area_name}</p>
                  <Badge
                    className="text-xs font-bold"
                    style={{
                      background: rule.status === 'ACTIVE' ? 'rgba(34, 197, 94, 0.3)' : 'rgba(156, 163, 175, 0.2)',
                      color: rule.status === 'ACTIVE' ? '#6ee7b7' : '#9ca3af',
                      border: `1px solid ${rule.status === 'ACTIVE' ? 'rgba(34, 197, 94, 0.5)' : 'transparent'}`
                    }}
                  >
                    {rule.status}
                  </Badge>
                </div>
                <p className="text-xs mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
                  {rule.rule_type}: <span style={{ color: 'var(--orbital-blue)' }}>{rule.rule_value}</span>
                </p>
                <div className="flex items-center gap-2 text-xs font-mono" style={{ color: 'var(--orbital-text-dim)' }}>
                  <Hash className="w-3 h-3" />
                  <span className="truncate">{rule.rule_hash}</span>
                </div>
              </motion.div>
            ))}
            
            {zoningRules.length === 0 && !loading && (
              <div className="text-center py-8">
                <Layers className="w-12 h-12 mx-auto mb-3 opacity-50" style={{ color: 'var(--orbital-text-dim)' }} />
                <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>No zoning rules defined</p>
                <p className="text-xs mt-1" style={{ color: 'var(--orbital-text-dim)' }}>Click "Add Rule" to create your first zoning rule</p>
              </div>
            )}
          </>
        )}
      </div>
    </CardContent>
  </Card>
);

export default function GlobalMap() {
  const [zoningRules, setZoningRules] = useState([]);
  const [showZoningPanel, setShowZoningPanel] = useState(true);
  const [currentView, setCurrentView] = useState('Planet');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [ownershipData, setOwnershipData] = useState([
    { owner: '0xABC...123', parcels: 47, value: '2.4M ORB' },
    { owner: '0xDEF...456', parcels: 23, value: '1.2M ORB' },
    { owner: '0xGHI...789', parcels: 15, value: '890K ORB' },
    { owner: '0xJKL...012', parcels: 8, value: '450K ORB' },
    { owner: '0xMNO...345', parcels: 3, value: '180K ORB' },
  ]);

  useEffect(() => {
    const fetchZoningRules = async () => {
      try {
        setLoading(true);
        setError(null);
        const rules = await ZoningRule.list();
        setZoningRules(rules || []);
      } catch (error) {
        console.error('Failed to fetch zoning rules:', error);
        setError('Failed to load zoning rules. Please try refreshing the page.');
        // Set some default/fallback data
        setZoningRules([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchZoningRules();
  }, []);

  const handleSearch = (query) => {
    if (!query) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    
    // Simulate async search with timeout
    setTimeout(() => {
      try {
        const mockResults = [
          { id: 'P001', coordinates: { x: 150, y: 200 } },
          { id: 'P002', coordinates: { x: 175, y: 225 } },
          { id: 'P003', coordinates: { x: 200, y: 250 } },
        ].filter(result =>
          result.id.toLowerCase().includes(query.toLowerCase()) ||
          `${result.coordinates.x},${result.coordinates.y}`.includes(query)
        );
        setSearchResults(mockResults);
      } catch (error) {
        console.error('Search error:', error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 500);
  };

  const handleAddRule = () => {
    // Implementation for adding new zoning rule
    console.log('Add new zoning rule');
    // You can implement a modal or navigation to a form here
  };

  const handleEditRule = (rule) => {
    // Implementation for editing zoning rule
    console.log('Edit zoning rule:', rule);
    // You can implement a modal or navigation to an edit form here
  };

  const handleViewChange = (newView) => {
    setCurrentView(newView);
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }} className="flex flex-col h-full p-6">
      {/* Enhanced Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-6 flex-shrink-0"
      >
        <div>
          <h1 className="text-4xl font-bold" style={{ color: 'var(--orbital-text)' }}>GLOBAL MAP VISUALIZER</h1>
          <p style={{ color: 'var(--orbital-text-dim)' }}>Interactive planetary exploration and parcel management</p>
          <div className="flex items-center gap-4 mt-2">
            <Badge className="chrome-surface" style={{ color: 'var(--orbital-blue)' }}>
              <Globe className="w-3 h-3 mr-1" />
              Sector 7G Active
            </Badge>
            <Badge className="chrome-surface" style={{ color: '#22c55e' }}>
              <Eye className="w-3 h-3 mr-1" />
              Live Tracking
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            className="chrome-surface"
            onClick={() => setShowZoningPanel(!showZoningPanel)}
            title={showZoningPanel ? 'Hide Control Panel' : 'Show Control Panel'}
          >
            <Layers className="w-4 h-4 mr-2" />
            {showZoningPanel ? 'Hide' : 'Show'} Panel
          </Button>
          <Button 
            className="glow-blue" 
            style={{ background: 'var(--orbital-blue)', color: 'var(--orbital-black)' }}
            title="Use AI to optimize planetary layout and resource distribution"
          >
            <Zap className="w-4 h-4 mr-2" />
            AI Optimize
          </Button>
        </div>
      </motion.div>

      <div className="flex-grow flex gap-6 min-h-0">
        {/* Enhanced Main Map Interface */}
        <motion.div
          className="flex-grow"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <GlobalMapViewer zoningRules={zoningRules} currentView={currentView} />
        </motion.div>

        {/* Enhanced Control Panel */}
        <AnimatePresence>
          {showZoningPanel && (
            <motion.div
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="w-96 flex-shrink-0 flex flex-col gap-4"
            >
              <MapControls onViewChange={handleViewChange} currentView={currentView} />
              <ParcelSearch
                onSearch={handleSearch}
                searchResults={searchResults}
                isSearching={isSearching}
              />
              <OwnershipTracker trackingData={ownershipData} />
              <ZoningRulesPanel
                zoningRules={zoningRules}
                onAddRule={handleAddRule}
                onEditRule={handleEditRule}
                loading={loading}
                error={error}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
