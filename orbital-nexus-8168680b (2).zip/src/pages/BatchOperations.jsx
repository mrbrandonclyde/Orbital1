import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, ArrowRightLeft, Tag, Trash2, X } from 'lucide-react';
import { NFT } from '@/api/entities';
import { NFTCard } from '../components/nft/NFTCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function BatchOperations() {
  const [nfts, setNfts] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());

  useEffect(() => {
    const loadNfts = async () => {
      const data = await NFT.list();
      setNfts(data);
    };
    loadNfts();
  }, []);

  const handleSelect = (id) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const selectAll = () => setSelectedIds(new Set(nfts.map(nft => nft.id)));
  const clearSelection = () => setSelectedIds(new Set());

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">BATCH OPERATIONS</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>Manage multiple assets efficiently with powerful batch actions</p>
      </div>

      <AnimatePresence>
        {selectedIds.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="sticky top-4 z-10 chrome-surface rounded-xl p-4 mb-6 flex items-center justify-between"
          >
            <Badge variant="secondary" className="text-lg">
              {selectedIds.size} asset{selectedIds.size > 1 ? 's' : ''} selected
            </Badge>
            <div className="flex gap-2">
              <Button variant="outline" className="chrome-surface"><ArrowRightLeft className="w-4 h-4 mr-2" />Batch Transfer</Button>
              <Button variant="outline" className="chrome-surface"><Tag className="w-4 h-4 mr-2" />Batch List for Sale</Button>
              <Button variant="destructive"><Trash2 className="w-4 h-4 mr-2" />Batch Burn</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="flex justify-end gap-2 mb-4">
        <Button onClick={selectAll}>Select All</Button>
        <Button variant="outline" onClick={clearSelection}><X className="w-4 h-4 mr-2" /> Clear Selection</Button>
      </div>

      <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {nfts.map(nft => (
          <NFTCard
            key={nft.id}
            nft={nft}
            onSelect={handleSelect}
            isSelected={selectedIds.has(nft.id)}
          />
        ))}
      </motion.div>
    </div>
  );
}