

import React, { useMemo, useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarFooter, SidebarProvider } from "@/components/ui/sidebar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Globe,
  Users,
  Database,
  Shield,
  BarChart2,
  Settings,
  CircleHelp,
  GitGraph,
  Wind,
  Layers3,
  Building,
  Home,
  Bot,
  Landmark,
  Banknote,
  FileText,
  HeartPulse,
  Scale,
  Folder,
  MessageSquare,
  BookUser,
  Power
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import DeploymentStatus from "./components/layout/DeploymentStatus";
import ErrorBoundary from './components/layout/ErrorBoundary';
import { AnimatePresence } from 'framer-motion';

const navigationItems = [
  { title: 'Global Map', icon: Globe, url: createPageUrl('GlobalMap') },
  { title: 'World Builder', icon: Layers3, url: createPageUrl('WorldBuilder') },
  { title: 'AI Humans', icon: Bot, url: createPageUrl('AIHumans') },
  { title: 'NFT Hub', icon: Database, url: createPageUrl('NFTHub') },
  { title: 'Marketplace', icon: Building, url: createPageUrl('Marketplace') },
  { title: 'DAO', icon: Landmark, url: createPageUrl('DAO') },
  { title: 'Economy', icon: Banknote, url: createPageUrl('Economy') },
  { title: 'Security', icon: Shield, url: createPageUrl('SecurityVault') },
  { title: 'Analytics', icon: BarChart2, url: createPageUrl('Analytics') },
  { title: 'Settings', icon: Settings, url: createPageUrl('Settings') },
  { title: 'System Health', icon: HeartPulse, url: createPageUrl('SystemStatus') },
];

const secondaryNavigation = [
  { title: 'Guardian Codex', icon: BookUser, url: createPageUrl('GuardianCodexLDS') },
  { title: 'Global Freedom', icon: Wind, url: createPageUrl('GlobalFreedomSystem') },
  { title: 'Judicial Center', icon: Scale, url: createPageUrl('JudicialCenter') },
  { title: 'File Manager', icon: Folder, url: createPageUrl('FileManager') },
  { title: 'Chat', icon: MessageSquare, url: createPageUrl('Chat') },
];

const UserMenu = () => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
            } catch (error) {
                console.warn("User not logged in");
                setUser(null);
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    const handleLogout = async () => {
        await User.logout();
        window.location.reload();
    };
    
    const handleLogin = async () => {
        await User.login();
    };

    if (loading) {
        return <div className="w-8 h-8 rounded-full bg-gray-700 animate-pulse" />;
    }

    if (!user) {
        return (
            <Button onClick={handleLogin} variant="outline" className="chrome-surface">
                Login
            </Button>
        );
    }
    
    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar_url || `https://avatar.vercel.sh/${user.email}.png`} alt={user.full_name} />
                        <AvatarFallback>{user.full_name?.[0] || 'U'}</AvatarFallback>
                    </Avatar>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 chrome-surface" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{user.full_name}</p>
                        <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                    <Link to={createPageUrl('ProfileSettings')} className="w-full">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem>
                    <Link to={createPageUrl('Settings')} className="w-full">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-400">
                    <Power className="w-4 h-4 mr-2" />
                    Log out
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  const getActiveState = (itemUrl) => {
    const pageUrl = new URL(itemUrl, window.location.origin);
    return location.pathname === pageUrl.pathname;
  };

  return (
    <>
      <style jsx global>{`
        :root {
          --orbital-blue: #00d4ff;
          --orbital-purple: #8b5cf6;
          --orbital-green: #22c55e;
          --orbital-black: #0a0a0a;
          --sidebar-background: rgba(10, 10, 10, 0.8);
          --sidebar-hover: rgba(0, 212, 255, 0.1);
          --chrome-background: rgba(255, 255, 255, 0.05);
          --chrome-border: rgba(255, 255, 255, 0.1);
          --orbital-text: #e5e7eb;
          --orbital-text-dim: #9ca3af;
          --min-touch-target: 44px;
        }
        .glow-blue {
          box-shadow: 0 0 15px rgba(0, 212, 255, 0.4), 0 0 25px rgba(0, 212, 255, 0.2);
        }
        .chrome-surface {
          background: var(--chrome-background);
          border: 1px solid var(--chrome-border);
          backdrop-filter: blur(10px);
        }
      `}</style>
      <SidebarProvider>
        <div className="min-h-screen flex flex-col w-full" style={{background: 'var(--orbital-black)', color: 'var(--orbital-text)'}}>
          <header className="flex-shrink-0 h-16 flex items-center justify-between px-6 border-b" style={{borderColor: 'var(--chrome-border)', background: 'var(--sidebar-background)', backdropFilter: 'blur(10px)'}}>
             <div className="flex items-center gap-2">
                <Globe className="w-7 h-7" style={{color: 'var(--orbital-blue)'}} />
                <h1 className="text-xl font-bold tracking-wider">ORBITAL NEXUS</h1>
             </div>
             <div className="flex items-center gap-4">
               <DeploymentStatus />
               <UserMenu />
             </div>
          </header>

          <div className="flex-1 flex min-h-0">
            <Sidebar className="w-64 flex-shrink-0" style={{
                background: 'var(--sidebar-background)',
                backdropFilter: 'blur(10px)',
                borderRight: '1px solid var(--chrome-border)'
            }}>
              <SidebarContent className="p-2" style={{background: 'var(--sidebar-background)'}}>
                <SidebarMenu role="navigation" aria-label="Main navigation">
                  {navigationItems.map((item) => {
                    const isActive = getActiveState(item.url);

                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          className={`relative hover:bg-blue-500/20 transition-all duration-200 rounded-lg mb-1.5 ${
                            isActive ? "glow-blue" : ""
                          }`}
                          style={{
                            minHeight: 'var(--min-touch-target)',
                            background: isActive ? 'var(--sidebar-hover)' : 'transparent'
                          }}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3"
                                aria-current={isActive ? 'page' : undefined}>
                            {isActive && (
                              <div className="absolute left-0 top-1/2 -translate-y-1/2 h-8 w-1 rounded-r-full glow-blue"
                                   style={{background: 'var(--orbital-blue)'}}
                                   aria-hidden="true" />
                            )}
                            <item.icon className="w-5 h-5" style={{color: isActive ? 'var(--orbital-blue)' : 'var(--orbital-text-dim)'}}
                                       aria-hidden="true" />
                            <span className="font-medium text-sm" style={{color: isActive ? 'var(--orbital-text)' : 'var(--orbital-text-dim)'}}>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
                <div className="my-4 border-t" style={{borderColor: 'var(--chrome-border)'}} />
                <SidebarMenu role="navigation" aria-label="Secondary navigation">
                   {secondaryNavigation.map((item) => {
                    const isActive = getActiveState(item.url);
                    return (
                      <SidebarMenuItem key={item.title}>
                        <TooltipProvider delayDuration={100}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <SidebarMenuButton
                                asChild
                                className={`relative hover:bg-blue-500/20 transition-all duration-200 rounded-lg mb-1 ${
                                  isActive ? "glow-blue" : ""
                                }`}
                                style={{ background: isActive ? 'var(--sidebar-hover)' : 'transparent' }}
                              >
                                <Link to={item.url} className="flex items-center gap-3 px-4 py-2" aria-current={isActive ? 'page' : undefined}>
                                  <item.icon className="w-4 h-4" style={{color: isActive ? 'var(--orbital-blue)' : 'var(--orbital-text-dim)'}} />
                                  <span className="font-medium text-xs" style={{color: isActive ? 'var(--orbital-text)' : 'var(--orbital-text-dim)'}}>{item.title}</span>
                                </Link>
                              </SidebarMenuButton>
                            </TooltipTrigger>
                            <TooltipContent side="right" className="chrome-surface">
                              <p>{item.title}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarContent>
              <SidebarFooter className="p-4">
                  <Button variant="outline" className="w-full chrome-surface">
                    <CircleHelp className="w-4 h-4 mr-2"/>
                    Help & Support
                  </Button>
              </SidebarFooter>
            </Sidebar>

            <main className="flex-1 flex-col flex min-h-0">
                <AnimatePresence mode="wait">
                  <ErrorBoundary key={currentPageName}>
                    {children}
                  </ErrorBoundary>
                </AnimatePresence>
            </main>
          </div>
        </div>
      </SidebarProvider>
    </>
  );
}

