import React from 'react';
import { Scale, Shield, Gavel, Users, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const ProtocolCard = ({ protocol, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex items-center gap-3 mb-4">
      <Icon className="w-6 h-6" style={{color: color}} />
      <h3 className="font-bold" style={{color: 'var(--orbital-text)'}}>{protocol.title}</h3>
    </div>
    <p className="text-sm mb-4" style={{color: 'var(--orbital-text-dim)'}}>{protocol.description}</p>
    <div className="space-y-2">
      {protocol.steps.map((step, index) => (
        <div key={index} className="flex items-start gap-2">
          <span className="text-xs px-2 py-1 rounded-full" style={{background: `${color}20`, color: color}}>
            {index + 1}
          </span>
          <span className="text-sm">{step}</span>
        </div>
      ))}
    </div>
  </motion.div>
);

export default function JusticeProtocols() {
  const protocols = [
    {
      title: 'Investigation Protocol',
      description: 'Standard procedure for investigating rule violations',
      steps: [
        'Evidence collection and preservation',
        'Witness testimony gathering',
        'AI analysis of data patterns',
        'Determination of violation severity'
      ]
    },
    {
      title: 'Mediation Process',
      description: 'Conflict resolution between parties',
      steps: [
        'Neutral mediator assignment',
        'Private consultation with each party',
        'Joint discussion facilitation',
        'Agreement documentation'
      ]
    },
    {
      title: 'Sanctions Framework',
      description: 'Proportional response to confirmed violations',
      steps: [
        'Violation impact assessment',
        'Precedent review and analysis',
        'Sanction recommendation',
        'Appeal process notification'
      ]
    }
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="mb-8">
        <h1 className="text-4xl font-bold mb-4">⚖️ JUSTICE PROTOCOLS</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>Fair and transparent procedures for maintaining order and justice</p>
        <div className="flex gap-2 mt-4">
          <Badge style={{background: 'linear-gradient(45deg, #22c55e, #06b6d4)', color: '#000'}}>
            DIVINE JUSTICE ACTIVE
          </Badge>
          <Badge variant="outline" style={{borderColor: '#f59e0b', color: '#f59e0b'}}>
            MERCY & TRUTH BALANCED
          </Badge>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {protocols.map((protocol, index) => (
          <ProtocolCard 
            key={protocol.title} 
            protocol={protocol} 
            icon={index === 0 ? Shield : index === 1 ? Users : Gavel}
            color={index === 0 ? '#22c55e' : index === 1 ? '#8b5cf6' : '#f59e0b'}
          />
        ))}
      </div>
    </div>
  );
}