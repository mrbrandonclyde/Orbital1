import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Zap, Filter, Plus, ListTodo, AlertTriangle, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

const TaskItem = ({ task, index }) => {
  const priorityColors = {
    critical: '#ef4444',
    high: '#f59e0b',
    medium: '#00d4ff',
    low: '#22c55e',
  };
  const statusIcon = task.status === 'completed' ? CheckCircle : ListTodo;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`p-4 rounded-lg flex items-center justify-between transition-all duration-300 ${task.status === 'completed' ? 'opacity-50' : ''}`}
      style={{ background: 'rgba(0, 212, 255, 0.05)'}}
    >
      <div className="flex items-center gap-3">
        <statusIcon className="w-5 h-5" style={{ color: priorityColors[task.priority] }} />
        <div>
          <p className={`font-medium ${task.status === 'completed' ? 'line-through' : ''}`} style={{ color: 'var(--orbital-text)' }}>{task.title}</p>
          <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>Assigned to: {task.agent}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs font-semibold px-2 py-1 rounded-full" style={{ background: `${priorityColors[task.priority]}20`, color: priorityColors[task.priority] }}>
          {task.priority.toUpperCase()}
        </span>
        <Button size="sm" variant="ghost" className="w-8 h-8 p-0">
            <Zap className="w-4 h-4"/>
        </Button>
      </div>
    </motion.div>
  );
};

const mockTasks = [
    { title: 'Recalibrate Sector 7G defense grid', agent: 'Guardian-5', priority: 'critical', status: 'in_progress' },
    { title: 'Analyze latest market data from Nova Prime', agent: 'Analyst-2', priority: 'high', status: 'in_progress' },
    { title: 'Submit World Builder v2.1 schematics', agent: 'Architect-1', priority: 'medium', status: 'in_progress' },
    { title: 'Optimize fleet energy consumption', agent: 'Strategist-9', priority: 'low', status: 'in_progress' },
    { title: 'Run diagnostics on memory core', agent: 'Nexus-7', priority: 'high', status: 'completed' },
];

export default function TaskMatrix() {
    const [newTask, setNewTask] = useState('');

    return (
        <div style={{ color: 'var(--orbital-text)' }}>
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-4xl font-bold">TASK MATRIX</h1>
                    <p style={{ color: 'var(--orbital-text-dim)' }}>Centralized task management with AI-powered prioritization.</p>
                </div>
                <Button className="font-bold glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
                    <Filter className="w-5 h-5 mr-2" />
                    Filter Tasks
                </Button>
            </div>

            <Card className="chrome-surface">
                <CardHeader>
                    <CardTitle>AI Fleet Task List</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-2 mb-6">
                        <Input 
                            value={newTask}
                            onChange={(e) => setNewTask(e.target.value)}
                            placeholder="Add a new task for the fleet..."
                            className="chrome-surface"
                        />
                        <Button>
                            <Plus className="w-4 h-4 mr-2" /> Add Task
                        </Button>
                    </div>

                    <div className="space-y-2">
                        {mockTasks.map((task, index) => (
                            <TaskItem key={index} task={task} index={index} />
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}