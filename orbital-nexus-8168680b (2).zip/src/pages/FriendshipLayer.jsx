import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Wifi, Heart, Users, Video, Volume2 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const ProtocolCard = ({ title, description, icon: Icon, color, isActive }) => (
  <Card className="chrome-surface">
    <CardHeader>
      <div className="flex justify-between items-center">
        <CardTitle className="flex items-center gap-3">
          <Icon className="w-6 h-6" style={{color: color}} />
          <span style={{color: 'var(--orbital-text)'}}>{title}</span>
        </CardTitle>
        <Badge style={{background: isActive ? '#22c55e20' : '#ef444420', color: isActive ? '#22c55e' : '#ef4444'}}>
          {isActive ? 'ACTIVE' : 'OFFLINE'}
        </Badge>
      </div>
    </CardHeader>
    <CardContent>
      <p className="text-sm mb-4" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
      <div className="flex items-center space-x-2">
        <Switch id={`switch-${title}`} checked={isActive} />
        <Label htmlFor={`switch-${title}`}>Enable Protocol</Label>
      </div>
    </CardContent>
  </Card>
);

export default function FriendshipLayer() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
        <h1 className="text-4xl font-bold">FRIENDSHIP LAYER</h1>
        <p className="text-lg mt-2 mb-8" style={{color: 'var(--orbital-text-dim)'}}>
          Manage presence, communication protocols, and divine connections
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <ProtocolCard 
          title="Text Communications" 
          description="Standard text-based messaging, divinely encrypted."
          icon={MessageSquare} 
          color="var(--orbital-blue)" 
          isActive={true} 
        />
        <ProtocolCard 
          title="Presence Mode" 
          description="Share your online status and activity across the Nexus."
          icon={Wifi} 
          color="#22c55e" 
          isActive={true} 
        />
        <ProtocolCard 
          title="Heart-Link" 
          description="Feel the emotional resonance of your closest connections."
          icon={Heart} 
          color="#ef4444" 
          isActive={false} 
        />
        <ProtocolCard 
          title="Group Presence" 
          description="Synchronize status and intent with your chosen guild or family."
          icon={Users} 
          color="#8b5cf6" 
          isActive={true} 
        />
         <ProtocolCard 
          title="Holographic Calls" 
          description="Engage in full 3D holographic communication."
          icon={Video} 
          color="#f59e0b" 
          isActive={false} 
        />
         <ProtocolCard 
          title="Voice Channels" 
          description="High-fidelity, encrypted voice communication channels."
          icon={Volume2} 
          color="#00d4ff" 
          isActive={true} 
        />
      </div>
    </div>
  );
}