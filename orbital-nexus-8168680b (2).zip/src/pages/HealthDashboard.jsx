import React, { useState, useEffect } from 'react';
import { HeartPulse, Stethoscope, FileText, Brain, Shield, User, Plus } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MedicalRecord } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { motion } from 'framer-motion';

const RecordCard = ({ record }) => (
  <motion.div 
    className="chrome-surface rounded-lg p-4"
    initial={{opacity: 0, y: 20}}
    animate={{opacity: 1, y: 0}}
    transition={{duration: 0.5}}
  >
    <div className="flex justify-between items-start">
      <div>
        <h4 className="font-bold">{record.record_type.toUpperCase()}</h4>
        <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{new Date().toLocaleDateString()}</p>
      </div>
      <Badge variant="outline" style={{borderColor: '#22c55e', color: '#22c55e'}}>
        <Shield className="w-3 h-3 mr-1" />
        Encrypted
      </Badge>
    </div>
    <p className="mt-2 text-sm">{record.details}</p>
  </motion.div>
);

export default function HealthDashboard() {
  const [records, setRecords] = useState([]);
  const [diagnosis, setDiagnosis] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setRecords([
      { id: 'rec_1', record_type: 'diagnosis', details: 'Vital signs stable. Minor energy fluctuations detected.' },
      { id: 'rec_2', record_type: 'vaccination', details: 'Digital pathogen immunity booster v3.1 administered.' },
    ]);
  }, []);

  const handleAiDiagnosis = async () => {
    setIsLoading(true);
    setDiagnosis('');
    const res = await InvokeLLM({ prompt: "As an AI doctor, provide a sample wellness diagnosis for a user in the Orbital system. Mention vital signs, energy levels, and digital presence." });
    setDiagnosis(res);
    setIsLoading(false);
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">HEALTHCARE SYSTEM v1</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Manage medical records with NPC doctors, AI diagnoses, and PQC-secured data.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #00d4ff, #22c55e)', color: '#000' }}>
            <Shield className="w-4 h-4 mr-2" />
            HIPAA & GDPR COMPLIANT
          </Badge>
           <Badge variant="outline" style={{ borderColor: '#8b5cf6', color: '#8b5cf6' }}>
            <Brain className="w-4 h-4 mr-2" />
            NPC DOCTORS ONLINE
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle>My Medical Records</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {records.map(r => <RecordCard key={r.id} record={r} />)}
            </CardContent>
          </Card>
        </div>
        <div className="space-y-6">
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle>AI Wellness Check</CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={handleAiDiagnosis} disabled={isLoading} className="w-full glow-blue">
                <Stethoscope className="w-4 h-4 mr-2" />
                {isLoading ? 'Analyzing...' : 'Request AI Diagnosis'}
              </Button>
              {diagnosis && (
                <motion.div 
                  initial={{opacity:0}} animate={{opacity:1}}
                  className="mt-4 p-3 rounded-lg text-sm" style={{background: 'rgba(0,212,255,0.1)'}}
                >
                  <p>{diagnosis}</p>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}