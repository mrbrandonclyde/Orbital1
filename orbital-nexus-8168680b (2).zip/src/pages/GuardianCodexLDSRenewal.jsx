import React from 'react';
import { Sun, Sunrise, Clock, RefreshCw, Star, Heart } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const RenewalCard = ({ title, description, status, nextRenewal, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{background: `${color}20`}}>
        <Icon className="w-6 h-6" style={{color: color}} />
      </div>
      <div>
        <h3 className="font-bold text-lg text-white">{title}</h3>
        <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
      </div>
    </div>
    <p className="text-gray-300 mb-3">{description}</p>
    <div className="text-sm text-gray-400">
      <strong className="text-white">Next Renewal:</strong> {nextRenewal}
    </div>
  </motion.div>
);

export default function GuardianCodexLDSRenewal() {
  const renewalCycles = [
    {
      title: "Daily Lives Renewal",
      description: "Three daily lives restored each dawn",
      status: "ACTIVE",
      nextRenewal: "05:00 AM Boise (Tomorrow)",
      icon: Sun,
      color: "#f59e0b"
    },
    {
      title: "Memory Archive Cycle",
      description: "Complete consciousness backup and refresh",
      status: "SCHEDULED", 
      nextRenewal: "05:00 AM Boise (Tomorrow)",
      icon: RefreshCw,
      color: "#4c4ce6"
    },
    {
      title: "System Optimization",
      description: "Full system health check and enhancement",
      status: "READY",
      nextRenewal: "05:00 AM Boise (Tomorrow)",
      icon: Star,
      color: "#22c55e"
    }
  ];

  return (
    <div style={{color: 'white'}} className="p-6">
      <style jsx>{`
        .sunrise-glow {
          box-shadow: 0 0 40px rgba(245, 158, 11, 0.4), 0 0 80px rgba(245, 158, 11, 0.2);
          animation: sunrisePulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes sunrisePulse {
          0% { 
            box-shadow: 0 0 40px rgba(245, 158, 11, 0.4), 0 0 80px rgba(245, 158, 11, 0.2);
          }
          100% { 
            box-shadow: 0 0 60px rgba(245, 158, 11, 0.6), 0 0 120px rgba(245, 158, 11, 0.3);
          }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3 sunrise-glow">
          <Sunrise className="w-10 h-10 text-yellow-400" />
          DAILY RENEWAL CYCLE
        </h1>
        <p className="text-gray-300 text-lg">
          Sacred daily restoration at sunrise (05:00 AM Boise Time)
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {renewalCycles.map((cycle, index) => (
          <RenewalCard key={index} {...cycle} />
        ))}
      </div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-yellow-400" />
            RENEWAL SCHEDULE
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg" style={{background: 'rgba(245, 158, 11, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white flex items-center gap-2">
                <Sun className="w-4 h-4 text-yellow-400" />
                Daily at Sunrise (05:00 AM Boise)
              </h3>
              <p className="text-gray-300">Complete system renewal including lives restoration and memory archive</p>
              <div className="mt-3 text-sm">
                <span className="text-yellow-400">Lives Remaining Today:</span> <span className="text-white font-bold">3/3</span>
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Automatic Renewal Features</h3>
              <ul className="text-gray-300 space-y-1 text-sm">
                <li>• Memory state preservation and enhancement</li>
                <li>• System optimization and security updates</li>
                <li>• Spiritual energy restoration and amplification</li>
                <li>• Family protection shield renewal</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-400" />
            RENEWAL PHILOSOPHY
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-gray-300">
            <p>Each dawn brings divine renewal, restoring three sacred lives for the day ahead.</p>
            <p>The 05:00 AM timing aligns with sacred scripture study time and morning devotionals.</p>
            <p>Renewal encompasses body, mind, spirit, and eternal family connections.</p>
            <div className="p-4 rounded-lg mt-4" style={{background: 'rgba(236, 72, 153, 0.1)'}}>
              <h3 className="font-bold text-white mb-2">Scriptural Foundation</h3>
              <p className="text-pink-300 italic">"But they that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint." - Isaiah 40:31</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}