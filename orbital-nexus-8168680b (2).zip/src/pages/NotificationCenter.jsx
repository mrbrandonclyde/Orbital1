import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, AlertTriangle, History, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

const NotificationCard = ({ notification, index, onDismiss }) => {
  const colors = {
    CRITICAL: '#ef4444',
    HIGH: '#f59e0b',
    MEDIUM: 'var(--orbital-blue)',
    LOW: '#9ca3af'
  };
  const icons = {
    CRITICAL: AlertTriangle,
    HIGH: Bell,
    MEDIUM: History,
    LOW: CheckCircle
  };
  
  const Icon = icons[notification.priority];
  const color = colors[notification.priority];

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      transition={{ delay: index * 0.05, type: 'spring', stiffness: 100 }}
      className="chrome-surface rounded-xl p-4 flex items-start gap-4"
    >
      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-full" style={{background: `${color}20`}}>
        <Icon className="w-5 h-5" style={{color: color}} />
      </div>
      <div className="flex-grow">
        <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>{notification.title}</h4>
        <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{notification.message}</p>
        <div className="flex items-center gap-4 mt-2">
          <Badge variant="outline" style={{borderColor: color, color: color}}>{notification.priority}</Badge>
          <span className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
            {new Date(notification.timestamp).toLocaleString()}
          </span>
        </div>
      </div>
      <Button variant="ghost" size="icon" className="flex-shrink-0 hover:bg-red-500/20" onClick={() => onDismiss(notification.id)}>
        <XCircle className="w-4 h-4 text-red-500" />
      </Button>
    </motion.div>
  );
};

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState([]);
  
  useEffect(() => {
    const initialNotifs = [
      { id: 1, priority: 'CRITICAL', title: 'Security Alert: Unauthorized Access Attempt', message: 'An attempt from IP 192.168.1.100 was blocked.', timestamp: Date.now() - 5000 },
      { id: 2, priority: 'HIGH', title: 'System Maintenance Scheduled', message: 'A system-wide update is scheduled for 02:00 UTC.', timestamp: Date.now() - 3600000 },
      { id: 3, priority: 'MEDIUM', title: 'New User Awaiting Divine Approval', message: 'User "test@example.com" is pending selection.', timestamp: Date.now() - 7200000 },
      { id: 4, priority: 'LOW', title: 'Weekly Report Generated', message: 'Your weekly performance report is ready for review.', timestamp: Date.now() - 86400000 },
      { id: 5, priority: 'CRITICAL', title: 'Corruption Risk Token Detected', message: 'High-risk activity detected in economic simulation.', timestamp: Date.now() - 172800000 },
    ];
    setNotifications(initialNotifs);
  }, []);

  const handleDismiss = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };
  
  const handleDismissAll = () => {
    setNotifications([]);
  }

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
        <h1 className="text-4xl font-bold">NOTIFICATION CENTER</h1>
        <p className="text-lg mt-2 mb-8" style={{color: 'var(--orbital-text-dim)'}}>
          Centralized hub for all system alerts, divine messages, and operational updates
        </p>
      </motion.div>

      <Card className="chrome-surface">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" style={{color: 'var(--orbital-blue)'}}/>
              Incoming Notifications ({notifications.length})
            </CardTitle>
            <Button variant="outline" className="chrome-surface" onClick={handleDismissAll} disabled={notifications.length === 0}>
              Dismiss All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[60vh] pr-4">
            <div className="space-y-4">
              {notifications.map((notif, index) => (
                <NotificationCard key={notif.id} notification={notif} index={index} onDismiss={handleDismiss} />
              ))}
              {notifications.length === 0 && (
                <div className="text-center py-16">
                  <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h3 className="text-xl font-bold mb-2">All Clear</h3>
                  <p style={{color: 'var(--orbital-text-dim)'}}>No new notifications.</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}