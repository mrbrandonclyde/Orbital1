import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, MapPin, Calendar, DollarSign, User, Hash } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Parcel } from '@/api/entities';
import { DeedCard } from '../components/registry/DeedCard';

export default function DeedSearch() {
  const [parcels, setParcels] = useState([]);
  const [searchFilters, setSearchFilters] = useState({
    general: '',
    owner: '',
    tokenId: '',
    zoning: 'all',
    status: 'all',
    world: 'all',
    minSize: '',
    maxSize: ''
  });
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    loadParcels();
  }, []);

  const loadParcels = async () => {
    const parcelData = await Parcel.list('-created_date');
    setParcels(parcelData);
  };

  const handleFilterChange = (key, value) => {
    setSearchFilters(prev => ({ ...prev, [key]: value }));
  };

  const filteredParcels = parcels.filter(parcel => {
    const matchesGeneral = !searchFilters.general || 
      parcel.owner_wallet?.toLowerCase().includes(searchFilters.general.toLowerCase()) ||
      parcel.nft_token_id?.toLowerCase().includes(searchFilters.general.toLowerCase()) ||
      parcel.world_id?.toLowerCase().includes(searchFilters.general.toLowerCase());
    
    const matchesOwner = !searchFilters.owner || 
      parcel.owner_wallet?.toLowerCase().includes(searchFilters.owner.toLowerCase());
    
    const matchesToken = !searchFilters.tokenId || 
      parcel.nft_token_id?.toLowerCase().includes(searchFilters.tokenId.toLowerCase());
    
    const matchesZoning = searchFilters.zoning === 'all' || parcel.zoning_type === searchFilters.zoning;
    const matchesStatus = searchFilters.status === 'all' || parcel.deed_status === searchFilters.status;

    return matchesGeneral && matchesOwner && matchesToken && matchesZoning && matchesStatus;
  });

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">ADVANCED DEED SEARCH</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Comprehensive property deed database query system</p>
        </div>
        <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
          {filteredParcels.length} of {parcels.length} deeds found
        </div>
      </motion.div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
              SEARCH PARAMETERS
            </CardTitle>
            <Button 
              variant="outline" 
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="chrome-surface"
            >
              <Filter className="w-4 h-4 mr-2" />
              {showAdvanced ? 'Simple Search' : 'Advanced Filters'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Basic Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}}/>
            <Input
              placeholder="Search by Owner, Token ID, or World..."
              value={searchFilters.general}
              onChange={(e) => handleFilterChange('general', e.target.value)}
              className="w-full pl-12 chrome-surface text-lg"
            />
          </div>

          {/* Advanced Filters */}
          <AnimatePresence>
            {showAdvanced && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-blue-500/20"
              >
                <div>
                  <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Owner Wallet
                  </label>
                  <Input
                    placeholder="0x..."
                    value={searchFilters.owner}
                    onChange={(e) => handleFilterChange('owner', e.target.value)}
                    className="chrome-surface"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                    <Hash className="w-4 h-4" />
                    Token ID
                  </label>
                  <Input
                    placeholder="Token ID..."
                    value={searchFilters.tokenId}
                    onChange={(e) => handleFilterChange('tokenId', e.target.value)}
                    className="chrome-surface"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Zoning Type
                  </label>
                  <Select value={searchFilters.zoning} onValueChange={(value) => handleFilterChange('zoning', value)}>
                    <SelectTrigger className="chrome-surface">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Zones</SelectItem>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="industrial">Industrial</SelectItem>
                      <SelectItem value="recreational">Recreational</SelectItem>
                      <SelectItem value="protected">Protected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Deed Status
                  </label>
                  <Select value={searchFilters.status} onValueChange={(value) => handleFilterChange('status', value)}>
                    <SelectTrigger className="chrome-surface">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="REGISTERED">Registered</SelectItem>
                      <SelectItem value="PENDING_TRANSFER">Pending Transfer</SelectItem>
                      <SelectItem value="ARCHIVED">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="flex gap-2 pt-2">
            <Button 
              onClick={() => setSearchFilters({
                general: '', owner: '', tokenId: '', zoning: 'all', status: 'all', world: 'all', minSize: '', maxSize: ''
              })}
              variant="outline" 
              className="chrome-surface"
            >
              Clear All
            </Button>
            <Button className="glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
              Export Results
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredParcels.map((parcel, index) => (
          <motion.div
            key={parcel.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <DeedCard parcel={parcel} />
          </motion.div>
        ))}
      </div>

      {filteredParcels.length === 0 && (
        <div className="chrome-surface rounded-2xl p-12 text-center">
          <Search className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Deeds Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>Try adjusting your search parameters or clear all filters.</p>
        </div>
      )}
    </div>
  );
}