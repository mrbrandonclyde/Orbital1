
import React, { useState, useEffect } from 'react';
import CesiumViewer from '@/components/cesium/CesiumViewer';
import GlobalHud from '@/components/hud/GlobalHud';
import { Loader2, Globe } from 'lucide-react';
import { BusinessLocation } from '@/api/entities';
import { Core } from '@/api/integrations';

// Moved getNasaFireData function here from the functions/ directory to resolve the platform error.
async function getNasaFireData() {
  try {
    const response = await Core.InvokeLLM({
      prompt: `Fetch the latest NASA VIIRS active fire data for the entire globe for the last 24 hours. The data should be comprehensive.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                latitude: { type: "number" },
                longitude: { type: "number" },
                bright_ti4: { type: "number", description: "Brightness temperature in Kelvin" },
                confidence: { type: "string" },
                frp: { type: "number", description: "Fire Radiative Power in MW" },
              },
              required: ["latitude", "longitude", "bright_ti4", "confidence"]
            }
          }
        }
      }
    });
    return response;
  } catch(e) {
    console.error("Failed to fetch NASA fire data", e);
    // Return empty data structure on error to prevent crashes
    return { data: [] };
  }
}

export default function GlobalCommandPage() {
  const [cesiumLoaded, setCesiumLoaded] = useState(false);
  const [initialData, setInitialData] = useState({ locations: [], alerts: [] });
  const [dataLoading, setDataLoading] = useState(true);
  const [targetLocation, setTargetLocation] = useState(null);

  useEffect(() => {
    // Dynamically load CesiumJS library
    const cesiumScript = document.createElement('script');
    cesiumScript.src = "https://cesium.com/downloads/cesiumjs/releases/1.119/Build/Cesium/Cesium.js";
    cesiumScript.async = true;
    document.body.appendChild(cesiumScript);

    const cesiumCss = document.createElement('link');
    cesiumCss.rel = 'stylesheet';
    cesiumCss.href = "https://cesium.com/downloads/cesiumjs/releases/1.119/Build/Cesium/Widgets/widgets.css";
    document.head.appendChild(cesiumCss);

    cesiumScript.onload = () => {
      setCesiumLoaded(true);
    };

    return () => {
      document.body.removeChild(cesiumScript);
      document.head.removeChild(cesiumCss);
    };
  }, []);

  useEffect(() => {
    const loadAllData = async () => {
      setDataLoading(true);
      try {
        const [locationsData, fireData] = await Promise.all([
          BusinessLocation.list(),
          getNasaFireData()
        ]);
        setInitialData({
          locations: locationsData || [],
          alerts: fireData.data || []
        });
      } catch (error) {
        console.error("Failed to load initial data for globe:", error);
      } finally {
        setDataLoading(false);
      }
    };

    loadAllData();
  }, []);

  const handleSelectLocation = (location) => {
    setTargetLocation(location);
  };
  
  if (!cesiumLoaded || dataLoading) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-black text-white">
        <Globe className="w-24 h-24 text-cyan-500 animate-pulse" />
        <h1 className="text-3xl font-bold mt-4">Initializing Global Command</h1>
        <p className="text-cyan-300 mt-2 flex items-center gap-2">
          <Loader2 className="w-5 h-5 animate-spin" />
          Loading CesiumJS and Satellite Feeds...
        </p>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative">
      <CesiumViewer 
        locations={initialData.locations} 
        alerts={initialData.alerts}
        targetLocation={targetLocation}
      />
      <GlobalHud 
        locations={initialData.locations} 
        alerts={initialData.alerts}
        onSelectLocation={handleSelectLocation}
      />
    </div>
  );
}
