
import React from 'react';
import { CheckCircle, Shield, Book, FileText, Globe, Heart, CreditCard, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const ComplianceCard = ({ title, status, description, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}40` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300 h-full"
  >
    <div className="flex justify-between items-start mb-4">
      <div className="flex items-center gap-3">
        <Icon className="w-6 h-6" style={{color: color}} />
        <h3 className="font-bold text-lg">{title}</h3>
      </div>
      <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
    </div>
    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
  </motion.div>
);

export default function ComplianceCenter() {
  const complianceStandards = [
    {
      title: "GDPR",
      status: "FULLY COMPLIANT",
      description: "Data processing protocols for all user data within the European Union are validated and active.",
      icon: Shield,
      color: "#4c4ce6"
    },
    {
      title: "HIPAA",
      status: "FULLY COMPLIANT",
      description: "Protection of sensitive patient health information is ensured with PQC-level encryption.",
      icon: Heart,
      color: "#22c55e"
    },
    {
      title: "PCI-DSS",
      status: "FULLY COMPLIANT",
      description: "Secure handling of cardholder information across all economic transactions is enforced.",
      icon: CreditCard,
      color: "#f59e0b"
    },
    {
      title: "SOC 2",
      status: "FULLY COMPLIANT",
      description: "Security, availability, processing integrity, confidentiality, and privacy controls are audited and certified.",
      icon: FileText,
      color: "#8b5cf6"
    },
    {
      title: "ISO/IEC 27001",
      status: "FULLY COMPLIANT",
      description: "Information Security Management System (ISMS) is active and continuously monitored.",
      icon: Lock,
      color: "#ec4899"
    }
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
          <CheckCircle className="w-10 h-10" style={{color: '#22c55e'}} />
          COMPLIANCE CENTER
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Real-time status of global regulatory and security compliance frameworks.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {complianceStandards.map((standard, index) => (
          <ComplianceCard key={index} {...standard} />
        ))}
      </div>
       <Card className="chrome-surface mt-8">
        <CardContent className="p-6 text-center">
          <Globe className="w-8 h-8 mx-auto mb-3" style={{color: 'var(--orbital-blue)'}}/>
          <h3 className="text-lg font-bold">Globally Certified</h3>
          <p className="text-sm mt-1" style={{color: 'var(--orbital-text-dim)'}}>
            The Orbital Platform's compliance is continuously monitored by the Inspector AI to ensure adherence to all current and future regulations across all known jurisdictions.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
