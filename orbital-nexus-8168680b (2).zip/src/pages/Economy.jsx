import React, { useState, useEffect } from 'react';
import { CircleDollarSign, TrendingUp, BarChart, Zap, Coins, Activity, Wallet2, PieChart, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TradingInterface } from '../components/economy/TradingInterface';

const EconomicMetric = ({ title, value, trend, icon: Icon, color, aiOptimized = false }) => (
  <motion.div
    whileHover={{ y: -8, scale: 1.03, boxShadow: `0 0 40px ${color}50` }}
    className={`chrome-surface rounded-2xl p-6 text-center transition-all duration-300 ${aiOptimized ? 'ai-economic-glow' : ''}`}
  >
    <style jsx>{`
      .ai-economic-glow {
        background: linear-gradient(45deg, rgba(0, 212, 255, 0.1), rgba(34, 197, 94, 0.1), rgba(251, 191, 36, 0.1));
        background-size: 200% 200%;
        animation: economicFlow 4s ease infinite;
        border: 2px solid rgba(0, 212, 255, 0.3);
      }
      
      @keyframes economicFlow {
        0% { 
          background-position: 0% 50%; 
          box-shadow: 0 0 30px rgba(0, 212, 255, 0.3);
        }
        50% { 
          background-position: 100% 50%; 
          box-shadow: 0 0 40px rgba(34, 197, 94, 0.4);
        }
        100% { 
          background-position: 0% 50%; 
          box-shadow: 0 0 30px rgba(251, 191, 36, 0.3);
        }
      }
    `}</style>
    
    <div className="relative">
      <Icon className="w-10 h-10 mx-auto mb-3" style={{color: color}} />
      {aiOptimized && (
        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full" 
             style={{background: 'linear-gradient(45deg, #8b5cf6, #00d4ff)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <Zap className="w-2 h-2" style={{color: '#000'}} />
        </div>
      )}
    </div>
    
    <div className="text-3xl font-bold mb-1" style={{color: 'var(--orbital-text)'}}>{value}</div>
    <div className="text-sm mb-2" style={{color: 'var(--orbital-text-dim)'}}>{title}</div>
    
    {trend && (
      <div className={`text-xs px-2 py-1 rounded-full font-bold ${trend.startsWith('+') ? 'bg-green-500' : trend.startsWith('-') ? 'bg-red-500' : 'bg-blue-500'}`} 
           style={{color: '#000'}}>
        {trend}
      </div>
    )}
    
    {aiOptimized && (
      <div className="mt-2 text-xs px-2 py-1 rounded-full" style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
        🤖 AI OPTIMIZED
      </div>
    )}
  </motion.div>
);

const RevenueStream = ({ name, amount, growth, percentage, color }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className="chrome-surface rounded-xl p-4 transition-all duration-300"
    style={{borderLeft: `4px solid ${color}`}}
  >
    <div className="flex justify-between items-start mb-2">
      <h4 className="font-semibold" style={{color: 'var(--orbital-text)'}}>{name}</h4>
      <span className="text-sm font-bold" style={{color: color}}>{percentage}%</span>
    </div>
    <div className="text-2xl font-bold mb-1" style={{color: 'var(--orbital-text)'}}>
      ${amount}
    </div>
    <div className={`text-xs px-2 py-1 rounded-full inline-block ${growth > 0 ? 'bg-green-500' : growth < 0 ? 'bg-red-500' : 'bg-gray-500'}`}
         style={{color: '#fff'}}>
      {growth > 0 ? '+' : ''}{growth}% Growth
    </div>
  </motion.div>
);

export default function Economy() {
  const [orbPrice, setOrbPrice] = useState(13.37);
  const [marketCap, setMarketCap] = useState(2847392847);
  const [totalRevenue, setTotalRevenue] = useState(89247382);
  const [economicIntelligence, setEconomicIntelligence] = useState(96.8);

  useEffect(() => {
    // Light-speed economic processing
    const economicInterval = setInterval(() => {
      setOrbPrice(prev => {
        const change = (Math.random() - 0.5) * 0.2;
        return Math.max(10, parseFloat((prev + change).toFixed(2)));
      });
      
      setMarketCap(prev => {
        const change = (Math.random() - 0.5) * 1000000;
        return Math.max(2000000000, Math.floor(prev + change));
      });
      
      setTotalRevenue(prev => {
        const change = Math.random() * 50000;
        return Math.floor(prev + change);
      });
      
      setEconomicIntelligence(prev => {
        const newIntel = Math.min(99.9, prev + (Math.random() * 0.1));
        return parseFloat(newIntel.toFixed(1));
      });
    }, 2000);

    return () => clearInterval(economicInterval);
  }, []);

  const revenueStreams = [
    { name: 'World Building Licenses', amount: '24.7M', growth: 12.3, percentage: 28, color: '#00d4ff' },
    { name: 'NFT Marketplace Fees', amount: '18.9M', growth: 8.7, percentage: 21, color: '#8b5cf6' },
    { name: 'AI Agent Subscriptions', amount: '15.2M', growth: 15.6, percentage: 17, color: '#22c55e' },
    { name: 'Land Registry Services', amount: '12.4M', growth: 6.2, percentage: 14, color: '#f59e0b' },
    { name: 'Premium Analytics', amount: '9.8M', growth: 22.1, percentage: 11, color: '#06b6d4' },
    { name: 'API & Integrations', amount: '8.2M', growth: 18.4, percentage: 9, color: '#ef4444' },
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .economic-divine-glow {
          box-shadow: 0 0 40px rgba(34, 197, 94, 0.4), 0 0 80px rgba(34, 197, 94, 0.2);
          animation: economicPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes economicPulse {
          0% { 
            box-shadow: 0 0 40px rgba(34, 197, 94, 0.4), 0 0 80px rgba(34, 197, 94, 0.2);
            transform: scale(1); 
          }
          100% { 
            box-shadow: 0 0 60px rgba(34, 197, 94, 0.6), 0 0 120px rgba(34, 197, 94, 0.3);
            transform: scale(1.01); 
          }
        }
      `}</style>
      
      {/* Economic Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold economic-divine-glow" style={{color: 'var(--orbital-text)'}}>
            ORBITAL ECONOMY
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Light-speed financial consciousness with AI-driven revenue optimization across all verticals
          </p>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-sm" style={{color: '#22c55e'}}>ECONOMIC AI: {economicIntelligence}%</span>
            </div>
            <div className="px-3 py-1 rounded-full text-xs font-bold" 
                 style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff, #f59e0b)', color: '#000'}}>
              💰 REVENUE MAXIMIZATION ACTIVE
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-4xl font-bold economic-divine-glow" style={{color: '#22c55e'}}>
            ${orbPrice.toFixed(2)}
          </div>
          <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>ORB Token Price</div>
          <div className="text-xs mt-1" style={{color: orbPrice > 13.37 ? '#22c55e' : '#ef4444'}}>
            {((orbPrice / 13.37 - 1) * 100).toFixed(2)}% (24h)
          </div>
        </div>
      </div>

      {/* Economic Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <EconomicMetric 
          title="Market Cap" 
          value={`$${(marketCap / 1000000).toFixed(1)}M`}
          trend="+8.7%"
          icon={CircleDollarSign}
          color="#00d4ff"
          aiOptimized={true}
        />
        <EconomicMetric 
          title="Total Revenue" 
          value={`$${(totalRevenue / 1000000).toFixed(1)}M`}
          trend="+12.4%"
          icon={TrendingUp}
          color="#22c55e"
          aiOptimized={true}
        />
        <EconomicMetric 
          title="Active Traders" 
          value="47,382"
          trend="+15.2%"
          icon={Activity}
          color="#8b5cf6"
        />
        <EconomicMetric 
          title="Transaction Volume" 
          value="$127M"
          trend="+6.8%"
          icon={BarChart}
          color="#f59e0b"
          aiOptimized={true}
        />
      </div>

      {/* Trading Interface */}
      <div className="mb-8">
        <Card className="chrome-surface economic-divine-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
              <Zap className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
              LIGHT-SPEED TRADING INTERFACE
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TradingInterface />
          </CardContent>
        </Card>
      </div>

      {/* Revenue Streams */}
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center justify-between" style={{color: 'var(--orbital-text)'}}>
            <div className="flex items-center gap-2">
              <PieChart className="w-6 h-6" style={{color: '#22c55e'}} />
              AI-OPTIMIZED REVENUE STREAMS
            </div>
            <div className="text-2xl font-bold" style={{color: '#22c55e'}}>
              ${(totalRevenue / 1000000).toFixed(1)}M Total
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {revenueStreams.map((stream, index) => (
              <motion.div
                key={stream.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <RevenueStream {...stream} />
              </motion.div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
              All revenue streams are AI-monitored, legally compliant, and optimized for maximum ethical profit generation across all verticals.
            </p>
            <div className="mt-2 px-4 py-2 rounded-full text-sm font-bold" 
                 style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000', display: 'inline-block'}}>
              🏛️ 100% REGULATORY COMPLIANT • ⚖️ LEGAL IN ALL JURISDICTIONS
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}