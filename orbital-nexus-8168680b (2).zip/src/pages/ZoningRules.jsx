
import React, { useState, useEffect, useCallback } from 'react';
import { Layers, Plus, Edit, Trash2, Shield, CheckCircle, AlertTriangle, Hash, MapPin, Ruler } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ZoningRule } from '@/api/entities';

const RuleCard = ({ rule, onEdit, onDelete, index }) => {
  const getRuleTypeInfo = (type) => {
    switch (type) {
      case 'HEIGHT_LIMIT': return { icon: Ruler, color: '#00d4ff', description: 'Maximum building height restriction' };
      case 'SETBACK': return { icon: MapPin, color: '#22c55e', description: 'Minimum distance from property lines' };
      case 'FAR': return { icon: Layers, color: '#f59e0b', description: 'Floor Area Ratio limitations' };
      case 'USE_RESTRICTION': return { icon: Shield, color: '#8b5cf6', description: 'Permitted land use types' };
      case 'DENSITY': return { icon: AlertTriangle, color: '#ef4444', description: 'Population density controls' };
      default: return { icon: Layers, color: 'var(--orbital-blue)', description: 'Custom zoning rule' };
    }
  };

  const ruleInfo = getRuleTypeInfo(rule.rule_type);
  const RuleIcon = ruleInfo.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -5, boxShadow: `0 0 30px ${ruleInfo.color}30` }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg flex items-center justify-center" 
               style={{background: ruleInfo.color + '20'}}>
            <RuleIcon className="w-6 h-6" style={{color: ruleInfo.color}} />
          </div>
          <div>
            <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>
              {rule.area_name}
            </h3>
            <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
              {ruleInfo.description}
            </p>
          </div>
        </div>
        <Badge style={{
          background: rule.status === 'ACTIVE' ? 'rgba(34, 197, 94, 0.2)' : 
                     rule.status === 'PENDING_VOTE' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(156, 163, 175, 0.2)',
          color: rule.status === 'ACTIVE' ? '#22c55e' : 
                 rule.status === 'PENDING_VOTE' ? '#f59e0b' : '#9ca3af'
        }}>
          {rule.status}
        </Badge>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex justify-between items-center">
          <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Rule Type</span>
          <Badge className="chrome-surface" style={{color: ruleInfo.color}}>
            {rule.rule_type.replace('_', ' ')}
          </Badge>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Value</span>
          <span className="font-semibold" style={{color: 'var(--orbital-text)'}}>
            {rule.rule_value}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Coverage Area</span>
          <span className="text-sm" style={{color: 'var(--orbital-text)'}}>
            {rule.area_geometry?.width || 0} × {rule.area_geometry?.height || 0} units
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4 text-xs font-mono" style={{color: 'var(--orbital-text-dim)'}}>
        <Hash className="w-3 h-3"/>
        <span className="truncate">{rule.rule_hash}</span>
      </div>

      <div className="flex gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 chrome-surface"
          onClick={() => onEdit(rule)}
        >
          <Edit className="w-3 h-3 mr-1" />
          Edit
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 hover:bg-red-500/20 hover:border-red-500/50"
          onClick={() => onDelete(rule.id)}
        >
          <Trash2 className="w-3 h-3 mr-1" />
          Delete
        </Button>
      </div>
    </motion.div>
  );
};

const RuleFormDialog = ({ rule, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    area_name: '',
    rule_type: 'HEIGHT_LIMIT',
    rule_value: '',
    world_id: 'world_1',
    area_geometry: { x: 0, y: 0, width: 100, height: 100 },
    status: 'ACTIVE'
  });

  useEffect(() => {
    if (rule) {
      setFormData(rule);
    } else {
      setFormData({
        area_name: '',
        rule_type: 'HEIGHT_LIMIT',
        rule_value: '',
        world_id: 'world_1',
        area_geometry: { x: 0, y: 0, width: 100, height: 100 },
        status: 'ACTIVE'
      });
    }
  }, [rule, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const ruleData = {
      ...formData,
      rule_hash: `hash_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    onSave(ruleData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="chrome-surface max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
            <Layers className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
            {rule ? 'Edit Zoning Rule' : 'Create New Zoning Rule'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="area_name">Area Name</Label>
              <Input
                id="area_name"
                value={formData.area_name}
                onChange={(e) => setFormData({...formData, area_name: e.target.value})}
                placeholder="e.g., Downtown Commercial District"
                className="chrome-surface mt-1"
                required
              />
            </div>
            <div>
              <Label htmlFor="rule_type">Rule Type</Label>
              <Select 
                value={formData.rule_type} 
                onValueChange={(value) => setFormData({...formData, rule_type: value})}
              >
                <SelectTrigger className="chrome-surface mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HEIGHT_LIMIT">Height Limit</SelectItem>
                  <SelectItem value="SETBACK">Setback Requirement</SelectItem>
                  <SelectItem value="FAR">Floor Area Ratio</SelectItem>
                  <SelectItem value="USE_RESTRICTION">Use Restriction</SelectItem>
                  <SelectItem value="DENSITY">Density Control</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="rule_value">Rule Value</Label>
            <Input
              id="rule_value"
              value={formData.rule_value}
              onChange={(e) => setFormData({...formData, rule_value: e.target.value})}
              placeholder="e.g., 100m, 5m setback, Commercial Only"
              className="chrome-surface mt-1"
              required
            />
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div>
              <Label htmlFor="x">X Position</Label>
              <Input
                id="x"
                type="number"
                value={formData.area_geometry?.x || 0}
                onChange={(e) => setFormData({
                  ...formData, 
                  area_geometry: {...formData.area_geometry, x: parseInt(e.target.value)}
                })}
                className="chrome-surface mt-1"
              />
            </div>
            <div>
              <Label htmlFor="y">Y Position</Label>
              <Input
                id="y"
                type="number"
                value={formData.area_geometry?.y || 0}
                onChange={(e) => setFormData({
                  ...formData, 
                  area_geometry: {...formData.area_geometry, y: parseInt(e.target.value)}
                })}
                className="chrome-surface mt-1"
              />
            </div>
            <div>
              <Label htmlFor="width">Width</Label>
              <Input
                id="width"
                type="number"
                value={formData.area_geometry?.width || 100}
                onChange={(e) => setFormData({
                  ...formData, 
                  area_geometry: {...formData.area_geometry, width: parseInt(e.target.value)}
                })}
                className="chrome-surface mt-1"
              />
            </div>
            <div>
              <Label htmlFor="height">Height</Label>
              <Input
                id="height"
                type="number"
                value={formData.area_geometry?.height || 100}
                onChange={(e) => setFormData({
                  ...formData, 
                  area_geometry: {...formData.area_geometry, height: parseInt(e.target.value)}
                })}
                className="chrome-surface mt-1"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="status">Status</Label>
            <Select 
              value={formData.status} 
              onValueChange={(value) => setFormData({...formData, status: value})}
            >
              <SelectTrigger className="chrome-surface mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="PENDING_VOTE">Pending Vote</SelectItem>
                <SelectItem value="ARCHIVED">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="chrome-surface">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="glow-blue" 
              style={{background: 'var(--orbital-blue)', color: '#000'}}
            >
              {rule ? 'Update Rule' : 'Create Rule'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const StatsCard = ({ title, value, icon: Icon, color, description }) => (
  <Card className="chrome-surface">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</p>
          <p className="text-3xl font-bold" style={{color: 'var(--orbital-text)'}}>{value}</p>
          <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
        </div>
        <Icon className="w-8 h-8" style={{color: color}} />
      </div>
    </CardContent>
  </Card>
);

export default function ZoningRules() {
  const [rules, setRules] = useState([]);
  const [filteredRules, setFilteredRules] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState(null);

  const applyFilters = useCallback(() => {
    let filtered = rules;

    if (filterStatus !== 'all') {
      filtered = filtered.filter(rule => rule.status === filterStatus);
    }

    if (filterType !== 'all') {
      filtered = filtered.filter(rule => rule.rule_type === filterType);
    }

    setFilteredRules(filtered);
  }, [rules, filterStatus, filterType]);

  useEffect(() => {
    loadZoningRules();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  const loadZoningRules = async () => {
    try {
      const rulesData = await ZoningRule.list('-created_date');
      setRules(rulesData);
    } catch (error) {
      console.error('Failed to load zoning rules:', error);
      // Mock data fallback
      setRules([
        {
          id: '1',
          area_name: 'Downtown Commercial Core',
          rule_type: 'HEIGHT_LIMIT',
          rule_value: '150m',
          world_id: 'world_1',
          area_geometry: { x: 100, y: 200, width: 300, height: 400 },
          rule_hash: 'hash_abc123def456',
          status: 'ACTIVE'
        },
        // Add more mock data as needed
      ]);
    }
  };

  const handleCreateRule = () => {
    setEditingRule(null);
    setIsDialogOpen(true);
  };

  const handleEditRule = (rule) => {
    setEditingRule(rule);
    setIsDialogOpen(true);
  };

  const handleSaveRule = async (ruleData) => {
    try {
      if (editingRule) {
        await ZoningRule.update(editingRule.id, ruleData);
      } else {
        await ZoningRule.create(ruleData);
      }
      loadZoningRules();
    } catch (error) {
      console.error('Failed to save rule:', error);
    }
  };

  const handleDeleteRule = async (ruleId) => {
    if (window.confirm('Are you sure you want to delete this zoning rule?')) {
      try {
        await ZoningRule.delete(ruleId);
        loadZoningRules();
      } catch (error) {
        console.error('Failed to delete rule:', error);
      }
    }
  };

  const stats = {
    total: rules.length,
    active: rules.filter(r => r.status === 'ACTIVE').length,
    pending: rules.filter(r => r.status === 'PENDING_VOTE').length,
    coverage: Math.round((rules.reduce((acc, rule) => acc + (rule.area_geometry?.width * rule.area_geometry?.height || 0), 0) / 1000000) * 100) / 100
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-8"
      >
        <div>
          <h1 className="text-4xl font-bold">ZONING RULES MANAGEMENT</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Define and manage land use regulations across orbital territories</p>
        </div>
        <Button 
          className="glow-blue" 
          style={{background: 'var(--orbital-blue)', color: '#000'}}
          onClick={handleCreateRule}
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New Rule
        </Button>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <StatsCard 
          title="Total Rules" 
          value={stats.total} 
          icon={Layers} 
          color="var(--orbital-blue)" 
          description="Across all zones"
        />
        <StatsCard 
          title="Active Rules" 
          value={stats.active} 
          icon={CheckCircle} 
          color="#22c55e" 
          description="Currently enforced"
        />
        <StatsCard 
          title="Pending Votes" 
          value={stats.pending} 
          icon={AlertTriangle} 
          color="#f59e0b" 
          description="Awaiting approval"
        />
        <StatsCard 
          title="Coverage Area" 
          value={`${stats.coverage}M`} 
          icon={MapPin} 
          color="#8b5cf6" 
          description="Square units regulated"
        />
      </div>

      {/* Filters */}
      <Card className="chrome-surface mb-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40 chrome-surface">
                  <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="ACTIVE">Active</SelectItem>
                  <SelectItem value="PENDING_VOTE">Pending Vote</SelectItem>
                  <SelectItem value="ARCHIVED">Archived</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40 chrome-surface">
                  <SelectValue placeholder="Filter by Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="HEIGHT_LIMIT">Height Limit</SelectItem>
                  <SelectItem value="SETBACK">Setback</SelectItem>
                  <SelectItem value="FAR">Floor Area Ratio</SelectItem>
                  <SelectItem value="USE_RESTRICTION">Use Restriction</SelectItem>
                  <SelectItem value="DENSITY">Density</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Badge className="chrome-surface" style={{color: 'var(--orbital-blue)'}}>
              {filteredRules.length} Rules Found
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Rules Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        <AnimatePresence>
          {filteredRules.map((rule, index) => (
            <RuleCard 
              key={rule.id} 
              rule={rule} 
              index={index}
              onEdit={handleEditRule}
              onDelete={handleDeleteRule}
            />
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Empty State */}
      {filteredRules.length === 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <Layers className="w-16 h-16 mx-auto mb-4 opacity-50" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="text-xl font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Zoning Rules Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>Create your first zoning rule to get started</p>
          <Button 
            className="mt-4 glow-blue" 
            style={{background: 'var(--orbital-blue)', color: '#000'}}
            onClick={handleCreateRule}
          >
            <Plus className="w-4 h-4 mr-2" />
            Create First Rule
          </Button>
        </motion.div>
      )}

      {/* Rule Form Dialog */}
      <RuleFormDialog
        rule={editingRule}
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onSave={handleSaveRule}
      />
    </div>
  );
}
