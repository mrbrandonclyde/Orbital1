import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Layers, Home, Factory, Store, TreePine, Bot, Save, Eye } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const zoneTypes = [
  { name: 'Residential', icon: Home, color: '#22c55e' },
  { name: 'Commercial', icon: Store, color: '#3b82f6' },
  { name: 'Industrial', icon: Factory, color: '#f59e0b' },
  { name: 'Recreational', icon: TreePine, color: '#8b5cf6' },
];

const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#8b5cf6'];

const distributionData = [
  { name: 'Residential', value: 45 },
  { name: 'Commercial', value: 25 },
  { name: 'Industrial', value: 15 },
  { name: 'Recreational', value: 15 },
];

export default function CityZoning() {
  const [selectedZone, setSelectedZone] = useState('Residential');
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => setIsOptimizing(false), 2000);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">AI CITY ZONING</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Design and manage urban layouts with predictive AI.</p>
        </div>
        <Button onClick={handleOptimize} disabled={isOptimizing} className="glow-blue font-bold" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
          <Bot className="w-5 h-5 mr-2" />
          {isOptimizing ? 'OPTIMIZING...' : 'AI OPTIMIZE ZONES'}
        </Button>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Map View Column */}
        <motion.div 
          className="lg:col-span-2"
          initial={{opacity:0, scale:0.9}} 
          animate={{opacity:1, scale:1}} 
          transition={{delay: 0.2}}
        >
          <Card className="chrome-surface h-full min-h-[600px] flex items-center justify-center p-4">
            <div className="w-full h-full bg-gray-900 rounded-lg relative overflow-hidden">
               {/* This would be an interactive map component */}
               <div className="absolute inset-0 bg-grid-pattern opacity-20"></div>
               <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-green-500/20 border-2 border-green-500 rounded-lg flex items-center justify-center">Residential</div>
               <div className="absolute top-10 right-10 w-1/4 h-1/4 bg-blue-500/20 border-2 border-blue-500 rounded-lg flex items-center justify-center">Commercial</div>
               <div className="absolute bottom-10 left-10 w-1/3 h-1/4 bg-yellow-500/20 border-2 border-yellow-500 rounded-lg flex items-center justify-center">Industrial</div>
            </div>
          </Card>
        </motion.div>

        {/* Controls Column */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Layers className="w-5 h-5 text-orbital-blue" />
                ZONING TOOLS
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-2">
              {zoneTypes.map(zone => (
                <Button key={zone.name} variant={selectedZone === zone.name ? 'default' : 'outline'} onClick={() => setSelectedZone(zone.name)}>
                  <zone.icon className="w-4 h-4 mr-2" />
                  {zone.name}
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card className="chrome-surface">
            <CardHeader><CardTitle className="text-base">Zoning Distribution</CardTitle></CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={distributionData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={5}>
                      {distributionData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: "rgba(0,0,0,0.8)", borderColor: "var(--orbital-blue)" }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
           <Card className="chrome-surface">
            <CardHeader><CardTitle className="text-base">AI Analysis</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <p><strong>Efficiency Score:</strong> <span className="text-green-400">92%</span></p>
                <p><strong>Potential Conflicts:</strong> <span className="text-yellow-400">2 (Noise, Traffic)</span></p>
                <p><strong>Suggestion:</strong> Add a recreational buffer zone between residential and industrial areas.</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="outline" className="w-full"><Eye className="w-4 h-4 mr-2" /> 3D Preview</Button>
            <Button variant="outline" className="w-full"><Save className="w-4 h-4 mr-2" /> Save Zoning Plan</Button>
          </div>
        </div>
      </div>
    </div>
  );
}