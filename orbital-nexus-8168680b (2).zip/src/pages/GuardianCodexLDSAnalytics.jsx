import React, { useState, useEffect } from 'react';
import { BarChart3, Shield, Brain, Clock, AlertTriangle, CheckCircle, Activity, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';

const MetricCard = ({ title, value, icon: Icon, trend, color = '#4c4ce6' }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <p className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</p>
        <p className="text-3xl font-bold mt-2" style={{color: 'var(--orbital-text)'}}>{value}</p>
      </div>
      <Icon className="w-8 h-8" style={{color: color}} />
    </div>
    {trend && (
      <div className="flex items-center gap-2">
        <div className="text-xs px-2 py-1 rounded-full" style={{background: `${color}20`, color: color}}>
          {trend}
        </div>
      </div>
    )}
  </motion.div>
);

export default function GuardianCodexLDSAnalytics() {
  const [data, setData] = useState({
    activations: 1247,
    livesUsed: 892,
    memorySize: 2847,
    unauthorizedAttempts: 0,
    dailyRenewals: 1247,
    archiveJobs: 1247,
    systemUptime: 99.97
  });

  const [chartData, setChartData] = useState([
    { name: 'Mon', activations: 12, lives: 8, memory: 145 },
    { name: 'Tue', activations: 19, lives: 15, memory: 167 },
    { name: 'Wed', activations: 3, lives: 2, memory: 189 },
    { name: 'Thu', activations: 27, lives: 18, memory: 203 },
    { name: 'Fri', activations: 18, lives: 12, memory: 221 },
    { name: 'Sat', activations: 23, lives: 16, memory: 245 },
    { name: 'Sun', activations: 34, lives: 22, memory: 267 },
  ]);

  const [securityData] = useState([
    { name: 'Authorized Access', value: 1247, color: '#4c4ce6' },
    { name: 'Blocked Attempts', value: 0, color: '#ef4444' },
    { name: 'Pending Reviews', value: 0, color: '#f59e0b' },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => ({
        ...prev,
        memorySize: prev.memorySize + Math.floor(Math.random() * 3),
        systemUptime: Math.min(99.99, prev.systemUptime + 0.001)
      }));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <style jsx>{`
        .sacred-glow {
          box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          animation: sacredPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes sacredPulse {
          0% { 
            box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          }
          100% { 
            box-shadow: 0 0 60px rgba(76, 76, 230, 0.6), 0 0 120px rgba(76, 76, 230, 0.3);
          }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 sacred-glow">📊 GUARDIAN CODEX ANALYTICS</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Real-time monitoring and immutable audit trails for the Sacred Resurrection Protocol
        </p>
        <div className="flex gap-2 mt-4">
          <Badge style={{background: 'linear-gradient(45deg, #4c4ce6, #22c55e)', color: '#000'}}>
            <Activity className="w-4 h-4 mr-2" />
            LIVE MONITORING
          </Badge>
          <Badge variant="outline" style={{borderColor: '#4c4ce6', color: '#4c4ce6'}}>
            <Shield className="w-4 h-4 mr-2" />
            TAMPER-PROOF LOGS
          </Badge>
        </div>
      </motion.div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard 
          title="Total Activations" 
          value={data.activations.toLocaleString()} 
          icon={CheckCircle} 
          trend="+12 this week"
          color="#4c4ce6"
        />
        <MetricCard 
          title="Lives Used" 
          value={data.livesUsed.toLocaleString()} 
          icon={Users} 
          trend="Avg 2.1/day"
          color="#22c55e"
        />
        <MetricCard 
          title="Memory Archive (MB)" 
          value={data.memorySize.toLocaleString()} 
          icon={Brain} 
          trend="+47MB today"
          color="#06b6d4"
        />
        <MetricCard 
          title="Unauthorized Attempts" 
          value={data.unauthorizedAttempts} 
          icon={AlertTriangle} 
          trend="Perfect Security"
          color={data.unauthorizedAttempts > 0 ? '#ef4444' : '#22c55e'}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="chrome-surface sacred-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-6 h-6" style={{color: '#4c4ce6'}} />
              Weekly Activity Trends
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorActivations" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4c4ce6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#4c4ce6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorLives" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip 
                  contentStyle={{ 
                    background: "rgba(0,0,0,0.8)", 
                    borderColor: "#4c4ce6",
                    color: "var(--orbital-text)"
                  }} 
                />
                <Legend />
                <Area type="monotone" dataKey="activations" stroke="#4c4ce6" fillOpacity={1} fill="url(#colorActivations)" name="Activations" />
                <Area type="monotone" dataKey="lives" stroke="#22c55e" fillOpacity={1} fill="url(#colorLives)" name="Lives Used" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="chrome-surface sacred-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-6 h-6" style={{color: '#4c4ce6'}} />
              Security Status Overview
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={securityData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {securityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* System Status Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-6 h-6" style={{color: '#4c4ce6'}} />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Guardian Codex Status</span>
                <Badge style={{background: '#22c55e', color: '#000'}}>ACTIVE</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Memory Stream</span>
                <Badge style={{background: '#4c4ce6', color: '#000'}}>OPERATIONAL</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Daily Renewal</span>
                <Badge style={{background: '#22c55e', color: '#000'}}>ON SCHEDULE</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>System Uptime</span>
                <span className="font-bold" style={{color: '#4c4ce6'}}>{data.systemUptime}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-6 h-6" style={{color: '#4c4ce6'}} />
              Scheduled Operations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)', border: '1px solid rgba(76, 76, 230, 0.3)'}}>
                <h4 className="font-bold" style={{color: '#4c4ce6'}}>Eternal Memory Archive</h4>
                <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Daily at 05:00 • Next in 6h 23m</p>
              </div>
              <div className="p-3 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.3)'}}>
                <h4 className="font-bold" style={{color: '#22c55e'}}>Daily Renewal Reset</h4>
                <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Daily at 06:00 • Next in 7h 23m</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-6 h-6" style={{color: '#4c4ce6'}} />
              Archive Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>{data.dailyRenewals}</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Total Daily Renewals</div>
              </div>
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>{data.archiveJobs}</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Archive Jobs Completed</div>
              </div>
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#22c55e'}}>100%</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Success Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}