import React, { useState, useEffect } from 'react';
import { FileText, Search, Filter, Hash, BarChart3, TrendingUp, Landmark } from 'lucide-react';
import { motion } from 'framer-motion';
import { Parcel } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DeedCard } from '../components/registry/DeedCard';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const StatCard = ({ title, value, icon: Icon, color, trend }) => (
  <Card className="chrome-surface">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</CardTitle>
      <Icon className="h-4 w-4" style={{color: color}} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {trend && <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{trend}</p>}
    </CardContent>
  </Card>
);

export default function LandRegistry() {
  const [parcels, setParcels] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadParcels();
  }, []);

  const loadParcels = async () => {
    const parcelData = await Parcel.list('-created_date');
    setParcels(parcelData);
  };
  
  const filteredParcels = parcels.filter(parcel =>
    parcel.owner_wallet?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parcel.nft_token_id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {/* Header */}
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold" style={{color: 'var(--orbital-text)'}}>TOKENIZED LAND REGISTRY</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Immutable On-Chain Property Deeds for the Orbital Universe</p>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} transition={{delay: 0.1}} className="grid gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Registered Parcels" value={parcels.length.toLocaleString()} icon={Landmark} color="var(--orbital-blue)" />
        <StatCard title="Total Market Value (ORB)" value="24.7B" icon={BarChart3} color="#22c55e" trend="+5.2% last cycle" />
        <StatCard title="Transfers (24h)" value="1,842" icon={TrendingUp} color="#8b5cf6" />
        <StatCard title="Notarizations Pending" value="76" icon={Hash} color="#f59e0b" />
      </motion.div>

      {/* Search and Filter */}
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} transition={{delay: 0.2}} className="flex gap-4 mb-8">
        <div className="relative flex-grow">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}}/>
          <Input
            placeholder="Search by Owner Wallet or Token ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 chrome-surface"
            style={{color: 'var(--orbital-text)', borderColor: 'rgba(0, 212, 255, 0.3)'}}
          />
        </div>
        <Button variant="outline" className="chrome-surface">
          <Filter className="w-4 h-4 mr-2" />
          Advanced Filters
        </Button>
      </motion.div>

      {/* Deeds Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredParcels.map((parcel, index) => (
          <motion.div
            key={parcel.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 + 0.3 }}
          >
            <DeedCard parcel={parcel} />
          </motion.div>
        ))}
      </div>
       {filteredParcels.length === 0 && (
        <div className="col-span-full chrome-surface rounded-2xl p-12 text-center mt-8">
          <FileText className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Deeds Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>The registry is empty or your search returned no results.</p>
        </div>
      )}
    </div>
  );
}