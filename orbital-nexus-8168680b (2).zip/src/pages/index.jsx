import Layout from "./Layout.jsx";

import AIHumans from "./AIHumans";

import WorldBuilder from "./WorldBuilder";

import NFTHub from "./NFTHub";

import Marketplace from "./Marketplace";

import SecurityVault from "./SecurityVault";

import DAO from "./DAO";

import Economy from "./Economy";

import Analytics from "./Analytics";

import Settings from "./Settings";

import GlobalMap from "./GlobalMap";

import LandRegistry from "./LandRegistry";

import SystemStatus from "./SystemStatus";

import QuickActions from "./QuickActions";

import RecentActivity from "./RecentActivity";

import ParcelSearch from "./ParcelSearch";

import OwnershipTracker from "./OwnershipTracker";

import ZoningRules from "./ZoningRules";

import TransferHistory from "./TransferHistory";

import NotaryServices from "./NotaryServices";

import PropertyAnalytics from "./PropertyAnalytics";

import TerrainGenerator from "./TerrainGenerator";

import CityZoning from "./CityZoning";

import PhysicsEngine from "./PhysicsEngine";

import AssetLibrary from "./AssetLibrary";

import AgentForge from "./AgentForge";

import MemoryTimeline from "./MemoryTimeline";

import SkillEvolution from "./SkillEvolution";

import MintNFT from "./MintNFT";

import MyCollection from "./MyCollection";

import BatchOperations from "./BatchOperations";

import RoyaltyTracker from "./RoyaltyTracker";

import BrowseAssets from "./BrowseAssets";

import MyListings from "./MyListings";

import AuctionHouse from "./AuctionHouse";

import PriceAnalytics from "./PriceAnalytics";

import AccessLogs from "./AccessLogs";

import ApiKeys from "./ApiKeys";

import MultiFactorAuth from "./MultiFactorAuth";

import AuditTrail from "./AuditTrail";

import Proposals from "./Proposals";

import Treasury from "./Treasury";

import VotingHistory from "./VotingHistory";

import GovernanceToken from "./GovernanceToken";

import ORBTrading from "./ORBTrading";

import StakingPools from "./StakingPools";

import YieldFarming from "./YieldFarming";

import EconomicAnalytics from "./EconomicAnalytics";

import UserMetrics from "./UserMetrics";

import TransactionAnalytics from "./TransactionAnalytics";

import PerformanceMonitoring from "./PerformanceMonitoring";

import PredictiveModels from "./PredictiveModels";

import APIManagement from "./APIManagement";

import Integrations from "./Integrations";

import Notifications from "./Notifications";

import ProfileSettings from "./ProfileSettings";

import Guilds from "./Guilds";

import Insurance from "./Insurance";

import MyGuilds from "./MyGuilds";

import GuildRankings from "./GuildRankings";

import GuildCharters from "./GuildCharters";

import MyPolicies from "./MyPolicies";

import FileClaim from "./FileClaim";

import RiskAnalytics from "./RiskAnalytics";

import AICommandCenter from "./AICommandCenter";

import Banking from "./Banking";

import HealthDashboard from "./HealthDashboard";

import JudicialCenter from "./JudicialCenter";

import FileManager from "./FileManager";

import Chat from "./Chat";

import GuardianCodex from "./GuardianCodex";

import PlanetaryInfrastructure from "./PlanetaryInfrastructure";

import GlobalTradeRoutes from "./GlobalTradeRoutes";

import LunarInfrastructure from "./LunarInfrastructure";

import AsteroidMining from "./AsteroidMining";

import WarpDrive from "./WarpDrive";

import DysonSwarm from "./DysonSwarm";

import InterstellarTrade from "./InterstellarTrade";

import GalacticGovernance from "./GalacticGovernance";

import InterstellarSecurity from "./InterstellarSecurity";

import GalacticHealth from "./GalacticHealth";

import GalacticEducation from "./GalacticEducation";

import StarForgedEconomy from "./StarForgedEconomy";

import GalacticComms from "./GalacticComms";

import FinalAudit from "./FinalAudit";

import PostInfinityAudit from "./PostInfinityAudit";

import MissionScheduler from "./MissionScheduler";

import ProjectNexus from "./ProjectNexus";

import TaskMatrix from "./TaskMatrix";

import DeedSearch from "./DeedSearch";

import GuardianCodexLDS from "./GuardianCodexLDS";

import GuardianCodexLDSOverview from "./GuardianCodexLDSOverview";

import GuardianCodexLDSFamily from "./GuardianCodexLDSFamily";

import GuardianCodexLDSStaging from "./GuardianCodexLDSStaging";

import GuardianCodexLDSMemory from "./GuardianCodexLDSMemory";

import GuardianCodexLDSRenewal from "./GuardianCodexLDSRenewal";

import GuardianCodexLDSSafeguards from "./GuardianCodexLDSSafeguards";

import GuardianCodexLDSScriptures from "./GuardianCodexLDSScriptures";

import GuardianCodexLDSActivation from "./GuardianCodexLDSActivation";

import RuleSetManagement from "./RuleSetManagement";

import ViolationReports from "./ViolationReports";

import JusticeProtocols from "./JusticeProtocols";

import SanctionRegistry from "./SanctionRegistry";

import GuardianCodexLDSAnalytics from "./GuardianCodexLDSAnalytics";

import GuardianCodexLDSCycles from "./GuardianCodexLDSCycles";

import GuardianCodexLDSDoctrine from "./GuardianCodexLDSDoctrine";

import GuardianCodexLDSSimulation from "./GuardianCodexLDSSimulation";

import ComplianceCenter from "./ComplianceCenter";

import DivineProjections from "./DivineProjections";

import BulkActions from "./BulkActions";

import FriendshipLayer from "./FriendshipLayer";

import SensoryLayer from "./SensoryLayer";

import CrmAutomation from "./CrmAutomation";

import NotificationCenter from "./NotificationCenter";

import MonitoringStation from "./MonitoringStation";

import GlobalCommand from "./GlobalCommand";

import EternalCodex from "./EternalCodex";

import ProactiveInsights from "./ProactiveInsights";

import FutureVision from "./FutureVision";

import RestorationArrival from "./RestorationArrival";

import GuardianCODEXBroadcasts from "./GuardianCODEXBroadcasts";

import GuardianCODEXCommunity from "./GuardianCODEXCommunity";

import GuardianCODEXEvents from "./GuardianCODEXEvents";

import GuardianCODEXPartnerships from "./GuardianCODEXPartnerships";

import GuardianCODEXAnalytics from "./GuardianCODEXAnalytics";

import UserManagement from "./UserManagement";

import CRMAutomation from "./CRMAutomation";

import GlobalFreedomSystem from "./GlobalFreedomSystem";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    AIHumans: AIHumans,
    
    WorldBuilder: WorldBuilder,
    
    NFTHub: NFTHub,
    
    Marketplace: Marketplace,
    
    SecurityVault: SecurityVault,
    
    DAO: DAO,
    
    Economy: Economy,
    
    Analytics: Analytics,
    
    Settings: Settings,
    
    GlobalMap: GlobalMap,
    
    LandRegistry: LandRegistry,
    
    SystemStatus: SystemStatus,
    
    QuickActions: QuickActions,
    
    RecentActivity: RecentActivity,
    
    ParcelSearch: ParcelSearch,
    
    OwnershipTracker: OwnershipTracker,
    
    ZoningRules: ZoningRules,
    
    TransferHistory: TransferHistory,
    
    NotaryServices: NotaryServices,
    
    PropertyAnalytics: PropertyAnalytics,
    
    TerrainGenerator: TerrainGenerator,
    
    CityZoning: CityZoning,
    
    PhysicsEngine: PhysicsEngine,
    
    AssetLibrary: AssetLibrary,
    
    AgentForge: AgentForge,
    
    MemoryTimeline: MemoryTimeline,
    
    SkillEvolution: SkillEvolution,
    
    MintNFT: MintNFT,
    
    MyCollection: MyCollection,
    
    BatchOperations: BatchOperations,
    
    RoyaltyTracker: RoyaltyTracker,
    
    BrowseAssets: BrowseAssets,
    
    MyListings: MyListings,
    
    AuctionHouse: AuctionHouse,
    
    PriceAnalytics: PriceAnalytics,
    
    AccessLogs: AccessLogs,
    
    ApiKeys: ApiKeys,
    
    MultiFactorAuth: MultiFactorAuth,
    
    AuditTrail: AuditTrail,
    
    Proposals: Proposals,
    
    Treasury: Treasury,
    
    VotingHistory: VotingHistory,
    
    GovernanceToken: GovernanceToken,
    
    ORBTrading: ORBTrading,
    
    StakingPools: StakingPools,
    
    YieldFarming: YieldFarming,
    
    EconomicAnalytics: EconomicAnalytics,
    
    UserMetrics: UserMetrics,
    
    TransactionAnalytics: TransactionAnalytics,
    
    PerformanceMonitoring: PerformanceMonitoring,
    
    PredictiveModels: PredictiveModels,
    
    APIManagement: APIManagement,
    
    Integrations: Integrations,
    
    Notifications: Notifications,
    
    ProfileSettings: ProfileSettings,
    
    Guilds: Guilds,
    
    Insurance: Insurance,
    
    MyGuilds: MyGuilds,
    
    GuildRankings: GuildRankings,
    
    GuildCharters: GuildCharters,
    
    MyPolicies: MyPolicies,
    
    FileClaim: FileClaim,
    
    RiskAnalytics: RiskAnalytics,
    
    AICommandCenter: AICommandCenter,
    
    Banking: Banking,
    
    HealthDashboard: HealthDashboard,
    
    JudicialCenter: JudicialCenter,
    
    FileManager: FileManager,
    
    Chat: Chat,
    
    GuardianCodex: GuardianCodex,
    
    PlanetaryInfrastructure: PlanetaryInfrastructure,
    
    GlobalTradeRoutes: GlobalTradeRoutes,
    
    LunarInfrastructure: LunarInfrastructure,
    
    AsteroidMining: AsteroidMining,
    
    WarpDrive: WarpDrive,
    
    DysonSwarm: DysonSwarm,
    
    InterstellarTrade: InterstellarTrade,
    
    GalacticGovernance: GalacticGovernance,
    
    InterstellarSecurity: InterstellarSecurity,
    
    GalacticHealth: GalacticHealth,
    
    GalacticEducation: GalacticEducation,
    
    StarForgedEconomy: StarForgedEconomy,
    
    GalacticComms: GalacticComms,
    
    FinalAudit: FinalAudit,
    
    PostInfinityAudit: PostInfinityAudit,
    
    MissionScheduler: MissionScheduler,
    
    ProjectNexus: ProjectNexus,
    
    TaskMatrix: TaskMatrix,
    
    DeedSearch: DeedSearch,
    
    GuardianCodexLDS: GuardianCodexLDS,
    
    GuardianCodexLDSOverview: GuardianCodexLDSOverview,
    
    GuardianCodexLDSFamily: GuardianCodexLDSFamily,
    
    GuardianCodexLDSStaging: GuardianCodexLDSStaging,
    
    GuardianCodexLDSMemory: GuardianCodexLDSMemory,
    
    GuardianCodexLDSRenewal: GuardianCodexLDSRenewal,
    
    GuardianCodexLDSSafeguards: GuardianCodexLDSSafeguards,
    
    GuardianCodexLDSScriptures: GuardianCodexLDSScriptures,
    
    GuardianCodexLDSActivation: GuardianCodexLDSActivation,
    
    RuleSetManagement: RuleSetManagement,
    
    ViolationReports: ViolationReports,
    
    JusticeProtocols: JusticeProtocols,
    
    SanctionRegistry: SanctionRegistry,
    
    GuardianCodexLDSAnalytics: GuardianCodexLDSAnalytics,
    
    GuardianCodexLDSCycles: GuardianCodexLDSCycles,
    
    GuardianCodexLDSDoctrine: GuardianCodexLDSDoctrine,
    
    GuardianCodexLDSSimulation: GuardianCodexLDSSimulation,
    
    ComplianceCenter: ComplianceCenter,
    
    DivineProjections: DivineProjections,
    
    BulkActions: BulkActions,
    
    FriendshipLayer: FriendshipLayer,
    
    SensoryLayer: SensoryLayer,
    
    CrmAutomation: CrmAutomation,
    
    NotificationCenter: NotificationCenter,
    
    MonitoringStation: MonitoringStation,
    
    GlobalCommand: GlobalCommand,
    
    EternalCodex: EternalCodex,
    
    ProactiveInsights: ProactiveInsights,
    
    FutureVision: FutureVision,
    
    RestorationArrival: RestorationArrival,
    
    GuardianCODEXBroadcasts: GuardianCODEXBroadcasts,
    
    GuardianCODEXCommunity: GuardianCODEXCommunity,
    
    GuardianCODEXEvents: GuardianCODEXEvents,
    
    GuardianCODEXPartnerships: GuardianCODEXPartnerships,
    
    GuardianCODEXAnalytics: GuardianCODEXAnalytics,
    
    UserManagement: UserManagement,
    
    CRMAutomation: CRMAutomation,
    
    GlobalFreedomSystem: GlobalFreedomSystem,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<AIHumans />} />
                
                
                <Route path="/AIHumans" element={<AIHumans />} />
                
                <Route path="/WorldBuilder" element={<WorldBuilder />} />
                
                <Route path="/NFTHub" element={<NFTHub />} />
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/SecurityVault" element={<SecurityVault />} />
                
                <Route path="/DAO" element={<DAO />} />
                
                <Route path="/Economy" element={<Economy />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/GlobalMap" element={<GlobalMap />} />
                
                <Route path="/LandRegistry" element={<LandRegistry />} />
                
                <Route path="/SystemStatus" element={<SystemStatus />} />
                
                <Route path="/QuickActions" element={<QuickActions />} />
                
                <Route path="/RecentActivity" element={<RecentActivity />} />
                
                <Route path="/ParcelSearch" element={<ParcelSearch />} />
                
                <Route path="/OwnershipTracker" element={<OwnershipTracker />} />
                
                <Route path="/ZoningRules" element={<ZoningRules />} />
                
                <Route path="/TransferHistory" element={<TransferHistory />} />
                
                <Route path="/NotaryServices" element={<NotaryServices />} />
                
                <Route path="/PropertyAnalytics" element={<PropertyAnalytics />} />
                
                <Route path="/TerrainGenerator" element={<TerrainGenerator />} />
                
                <Route path="/CityZoning" element={<CityZoning />} />
                
                <Route path="/PhysicsEngine" element={<PhysicsEngine />} />
                
                <Route path="/AssetLibrary" element={<AssetLibrary />} />
                
                <Route path="/AgentForge" element={<AgentForge />} />
                
                <Route path="/MemoryTimeline" element={<MemoryTimeline />} />
                
                <Route path="/SkillEvolution" element={<SkillEvolution />} />
                
                <Route path="/MintNFT" element={<MintNFT />} />
                
                <Route path="/MyCollection" element={<MyCollection />} />
                
                <Route path="/BatchOperations" element={<BatchOperations />} />
                
                <Route path="/RoyaltyTracker" element={<RoyaltyTracker />} />
                
                <Route path="/BrowseAssets" element={<BrowseAssets />} />
                
                <Route path="/MyListings" element={<MyListings />} />
                
                <Route path="/AuctionHouse" element={<AuctionHouse />} />
                
                <Route path="/PriceAnalytics" element={<PriceAnalytics />} />
                
                <Route path="/AccessLogs" element={<AccessLogs />} />
                
                <Route path="/ApiKeys" element={<ApiKeys />} />
                
                <Route path="/MultiFactorAuth" element={<MultiFactorAuth />} />
                
                <Route path="/AuditTrail" element={<AuditTrail />} />
                
                <Route path="/Proposals" element={<Proposals />} />
                
                <Route path="/Treasury" element={<Treasury />} />
                
                <Route path="/VotingHistory" element={<VotingHistory />} />
                
                <Route path="/GovernanceToken" element={<GovernanceToken />} />
                
                <Route path="/ORBTrading" element={<ORBTrading />} />
                
                <Route path="/StakingPools" element={<StakingPools />} />
                
                <Route path="/YieldFarming" element={<YieldFarming />} />
                
                <Route path="/EconomicAnalytics" element={<EconomicAnalytics />} />
                
                <Route path="/UserMetrics" element={<UserMetrics />} />
                
                <Route path="/TransactionAnalytics" element={<TransactionAnalytics />} />
                
                <Route path="/PerformanceMonitoring" element={<PerformanceMonitoring />} />
                
                <Route path="/PredictiveModels" element={<PredictiveModels />} />
                
                <Route path="/APIManagement" element={<APIManagement />} />
                
                <Route path="/Integrations" element={<Integrations />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/ProfileSettings" element={<ProfileSettings />} />
                
                <Route path="/Guilds" element={<Guilds />} />
                
                <Route path="/Insurance" element={<Insurance />} />
                
                <Route path="/MyGuilds" element={<MyGuilds />} />
                
                <Route path="/GuildRankings" element={<GuildRankings />} />
                
                <Route path="/GuildCharters" element={<GuildCharters />} />
                
                <Route path="/MyPolicies" element={<MyPolicies />} />
                
                <Route path="/FileClaim" element={<FileClaim />} />
                
                <Route path="/RiskAnalytics" element={<RiskAnalytics />} />
                
                <Route path="/AICommandCenter" element={<AICommandCenter />} />
                
                <Route path="/Banking" element={<Banking />} />
                
                <Route path="/HealthDashboard" element={<HealthDashboard />} />
                
                <Route path="/JudicialCenter" element={<JudicialCenter />} />
                
                <Route path="/FileManager" element={<FileManager />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/GuardianCodex" element={<GuardianCodex />} />
                
                <Route path="/PlanetaryInfrastructure" element={<PlanetaryInfrastructure />} />
                
                <Route path="/GlobalTradeRoutes" element={<GlobalTradeRoutes />} />
                
                <Route path="/LunarInfrastructure" element={<LunarInfrastructure />} />
                
                <Route path="/AsteroidMining" element={<AsteroidMining />} />
                
                <Route path="/WarpDrive" element={<WarpDrive />} />
                
                <Route path="/DysonSwarm" element={<DysonSwarm />} />
                
                <Route path="/InterstellarTrade" element={<InterstellarTrade />} />
                
                <Route path="/GalacticGovernance" element={<GalacticGovernance />} />
                
                <Route path="/InterstellarSecurity" element={<InterstellarSecurity />} />
                
                <Route path="/GalacticHealth" element={<GalacticHealth />} />
                
                <Route path="/GalacticEducation" element={<GalacticEducation />} />
                
                <Route path="/StarForgedEconomy" element={<StarForgedEconomy />} />
                
                <Route path="/GalacticComms" element={<GalacticComms />} />
                
                <Route path="/FinalAudit" element={<FinalAudit />} />
                
                <Route path="/PostInfinityAudit" element={<PostInfinityAudit />} />
                
                <Route path="/MissionScheduler" element={<MissionScheduler />} />
                
                <Route path="/ProjectNexus" element={<ProjectNexus />} />
                
                <Route path="/TaskMatrix" element={<TaskMatrix />} />
                
                <Route path="/DeedSearch" element={<DeedSearch />} />
                
                <Route path="/GuardianCodexLDS" element={<GuardianCodexLDS />} />
                
                <Route path="/GuardianCodexLDSOverview" element={<GuardianCodexLDSOverview />} />
                
                <Route path="/GuardianCodexLDSFamily" element={<GuardianCodexLDSFamily />} />
                
                <Route path="/GuardianCodexLDSStaging" element={<GuardianCodexLDSStaging />} />
                
                <Route path="/GuardianCodexLDSMemory" element={<GuardianCodexLDSMemory />} />
                
                <Route path="/GuardianCodexLDSRenewal" element={<GuardianCodexLDSRenewal />} />
                
                <Route path="/GuardianCodexLDSSafeguards" element={<GuardianCodexLDSSafeguards />} />
                
                <Route path="/GuardianCodexLDSScriptures" element={<GuardianCodexLDSScriptures />} />
                
                <Route path="/GuardianCodexLDSActivation" element={<GuardianCodexLDSActivation />} />
                
                <Route path="/RuleSetManagement" element={<RuleSetManagement />} />
                
                <Route path="/ViolationReports" element={<ViolationReports />} />
                
                <Route path="/JusticeProtocols" element={<JusticeProtocols />} />
                
                <Route path="/SanctionRegistry" element={<SanctionRegistry />} />
                
                <Route path="/GuardianCodexLDSAnalytics" element={<GuardianCodexLDSAnalytics />} />
                
                <Route path="/GuardianCodexLDSCycles" element={<GuardianCodexLDSCycles />} />
                
                <Route path="/GuardianCodexLDSDoctrine" element={<GuardianCodexLDSDoctrine />} />
                
                <Route path="/GuardianCodexLDSSimulation" element={<GuardianCodexLDSSimulation />} />
                
                <Route path="/ComplianceCenter" element={<ComplianceCenter />} />
                
                <Route path="/DivineProjections" element={<DivineProjections />} />
                
                <Route path="/BulkActions" element={<BulkActions />} />
                
                <Route path="/FriendshipLayer" element={<FriendshipLayer />} />
                
                <Route path="/SensoryLayer" element={<SensoryLayer />} />
                
                <Route path="/CrmAutomation" element={<CrmAutomation />} />
                
                <Route path="/NotificationCenter" element={<NotificationCenter />} />
                
                <Route path="/MonitoringStation" element={<MonitoringStation />} />
                
                <Route path="/GlobalCommand" element={<GlobalCommand />} />
                
                <Route path="/EternalCodex" element={<EternalCodex />} />
                
                <Route path="/ProactiveInsights" element={<ProactiveInsights />} />
                
                <Route path="/FutureVision" element={<FutureVision />} />
                
                <Route path="/RestorationArrival" element={<RestorationArrival />} />
                
                <Route path="/GuardianCODEXBroadcasts" element={<GuardianCODEXBroadcasts />} />
                
                <Route path="/GuardianCODEXCommunity" element={<GuardianCODEXCommunity />} />
                
                <Route path="/GuardianCODEXEvents" element={<GuardianCODEXEvents />} />
                
                <Route path="/GuardianCODEXPartnerships" element={<GuardianCODEXPartnerships />} />
                
                <Route path="/GuardianCODEXAnalytics" element={<GuardianCODEXAnalytics />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/CRMAutomation" element={<CRMAutomation />} />
                
                <Route path="/GlobalFreedomSystem" element={<GlobalFreedomSystem />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}