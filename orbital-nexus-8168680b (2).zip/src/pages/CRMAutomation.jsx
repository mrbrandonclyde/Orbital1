import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Megaphone, MessageSquare, Phone, CheckCircle, BarChart3, Users, Filter, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const ActionButton = ({ icon: Icon, label, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 25px ${color}50` }}
    className="chrome-surface rounded-xl p-4 text-center cursor-pointer"
  >
    <Icon className="w-8 h-8 mx-auto mb-2" style={{color: color}}/>
    <p className="font-semibold" style={{color: 'var(--orbital-text)'}}>{label}</p>
  </motion.div>
);

const StatCard = ({ title, value, icon: Icon, color }) => (
  <Card className="chrome-surface">
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</CardTitle>
      <Icon className="h-4 w-4" style={{color: color}} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

export default function CRMAutomation() {
  const [message, setMessage] = useState('');
  
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
        <h1 className="text-4xl font-bold">CRM AUTOMATION</h1>
        <p className="text-lg mt-2 mb-8" style={{color: 'var(--orbital-text-dim)'}}>
          AI-Powered Bulk Outreach and Relationship Management
        </p>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        <StatCard title="Contacts" value="142,874" icon={Users} color="var(--orbital-blue)" />
        <StatCard title="Campaigns Active" value="12" icon={Megaphone} color="#8b5cf6" />
        <StatCard title="Engagement Rate" value="78%" icon={BarChart3} color="#22c55e" />
        <StatCard title="Tasks Automated" value="1.2k" icon={Zap} color="#f59e0b" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Megaphone className="w-5 h-5" style={{color: 'var(--orbital-blue)'}}/>
              Bulk Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <ActionButton icon={MessageSquare} label="Bulk Message" color="#00d4ff" />
            <ActionButton icon={Phone} label="Bulk Call" color="#8b5cf6" />
            <ActionButton icon={CheckCircle} label="Bulk Approve" color="#22c55e" />
            <ActionButton icon={Users} label="Bulk Segment" color="#f59e0b" />
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" style={{color: 'var(--orbital-blue)'}}/>
              Create Broadcast Message
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Textarea 
                placeholder="Compose your divine message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="chrome-surface min-h-[120px]"
              />
              <div className="flex justify-between items-center">
                <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Target Audience: All Chosen</p>
                <Button className="glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
                  <Zap className="w-4 h-4 mr-2"/>
                  Send with AI Optimization
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}