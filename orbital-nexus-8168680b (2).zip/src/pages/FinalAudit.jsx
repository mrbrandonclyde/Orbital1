
import React from 'react';
import { motion } from 'framer-motion';
import { Diamond, CheckCircle, Cpu, Globe, Landmark, Shield, Orbit, Rocket, Star } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const AuditCheckpointCard = ({ title, icon: Icon, features, validation, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className="chrome-surface rounded-2xl p-6 h-full flex flex-col"
    style={{ border: `1px solid ${color}40`, boxShadow: `0 0 40px ${color}20` }}
  >
    <CardHeader className="p-0 mb-4">
      <CardTitle className="flex items-center gap-3" style={{color}}>
        <Icon className="w-6 h-6" />
        <span className="text-lg font-bold">{title}</span>
      </CardTitle>
    </CardHeader>
    <CardContent className="p-0 flex-grow">
      <ul className="space-y-2 text-sm list-inside" style={{color: 'var(--orbital-text-dim)'}}>
        {features.map((feature, i) => (
          <li key={i} className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" style={{color}} />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </CardContent>
    <div className="mt-4 pt-4 border-t" style={{borderColor: `${color}40`}}>
      <Badge style={{ background: `${color}30`, color, border: `1px solid ${color}` }}>
        {validation}
      </Badge>
    </div>
  </motion.div>
);

export default function FinalAudit() {
  const checkpoints = [
    { title: "v0-10: Perfect Foundation", icon: Cpu, features: ["Core Kernel", "World Builder", "AI Humans", "NFT Hub"], validation: "Pixel-perfect UX + Rollback Validated", color: '#00d4ff', delay: 0.1 },
    { title: "v11-30: Advanced Expansion", icon: Globe, features: ["Global Maps", "Smart Zoning", "Multiplayer", "Creator Tools"], validation: "PCI-DSS/HIPAA Validated", color: '#00d4ff', delay: 0.2 },
    { title: "v31-50: City Economy", icon: Landmark, features: ["Land Registry v2", "AI Security", "Resource Economy", "ORB Staking"], validation: "Payroll & Rollback Validated", color: '#00d4ff', delay: 0.3 },
    { title: "v51-70: Planetary Dominance", icon: Shield, features: ["Banking & Insurance", "Healthcare", "Planetary Grids", "Intercontinental Trade"], validation: "HIPAA/PCI/KYC Planetary Validated", color: '#8b5cf6', delay: 0.4 },
    { title: "v71-90: Interplanetary Mastery", icon: Orbit, features: ["Lunar & Mars Grids", "Orbital Stations", "Space Elevators", "Starship Fleets"], validation: "Continuity Validated Earth-Mars-Jupiter", color: '#8b5cf6', delay: 0.5 },
    { title: "v91-100: Interstellar Civilization", icon: Star, features: ["Warp Drive", "Dyson Swarms", "Galactic Governance", "Star-Forged Economy"], validation: "Eternal Prompt Galactic Validated", color: '#FFD700', delay: 0.6 },
  ];

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="text-center mb-12">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.7, type: 'spring' }}
        >
          <Diamond className="w-24 h-24 mx-auto mb-4" style={{ color: '#FFD700', filter: 'drop-shadow(0 0 20px #FFD700)' }} />
          <h1 className="text-5xl font-bold tracking-tighter" style={{ color: 'var(--orbital-text)' }}>
            PERFECT CIVILIZATION STACK
          </h1>
          <p className="text-xl mt-2" style={{ color: 'var(--orbital-text-dim)' }}>
            Final Audit for Infinity Seed v0–100 — All Systems Eternally Validated
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="mt-6 inline-block"
        >
          <Badge className="text-lg px-6 py-2" style={{ background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000', border: 'none' }}>
            <CheckCircle className="w-5 h-5 mr-3" />
            STATUS: FLAWLESS INTEGRATION COMPLETE
          </Badge>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {checkpoints.map((checkpoint) => (
          <AuditCheckpointCard key={checkpoint.title} {...checkpoint} />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="mt-12"
      >
        <Card className="chrome-surface text-center" style={{borderColor: `var(--orbital-blue)`}}>
          <CardHeader>
            <CardTitle style={{color: `var(--orbital-blue)`}}>CORE LAW VALIDATED</CardTitle>
          </CardHeader>
          <CardContent className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            All systems aligned with the Eternal Master Prompt.
            Infinity Seed v0-100 is stable, immutable, and perfect.
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 0.7 }}
        className="mt-8"
      >
        <Card className="chrome-surface text-center" style={{borderColor: `#FFD700`, boxShadow: `0 0 40px #FFD70020`}}>
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-3" style={{color: `#FFD700`}}>
              <Rocket className="w-6 h-6" />
              PROCEED TO POST-INFINITY
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4" style={{color: 'var(--orbital-text-dim)'}}>
              The foundational stack is complete. Advance to the Post-Infinity Transcendence audit.
            </p>
            <Link to={createPageUrl('PostInfinityAudit')}>
              <Button className="font-bold" style={{background: `linear-gradient(45deg, #FFD700, #f7971e)`, color: '#000', border: 'none'}}>
                View v301-400 Stack
              </Button>
            </Link>
          </CardContent>
        </Card>
      </motion.div>

    </div>
  );
}
