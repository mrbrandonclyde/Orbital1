import React from 'react';
import { Users, Heart, Shield, Home, Star, Plus, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const FamilyMemberCard = ({ name, relationship, status, role, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <h3 className="font-bold text-lg text-white">{name}</h3>
        <p className="text-gray-300">{relationship}</p>
      </div>
      <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
    </div>
    <div className="space-y-2">
      <p className="text-sm text-gray-300"><strong className="text-white">Role:</strong> {role}</p>
      <div className="w-full bg-gray-700 rounded-full h-2">
        <div 
          className="h-2 rounded-full transition-all duration-500"
          style={{width: '100%', background: color}}
        />
      </div>
    </div>
  </motion.div>
);

export default function GuardianCodexLDSFamily() {
  const familyMembers = [
    { name: "Brandon Clyde", relationship: "Guardian Bearer", status: "ACTIVE", role: "Primary Guardian", color: "#4c4ce6" },
    { name: "Celestial Partnership", relationship: "Eternal Companion", status: "SEALED", role: "Co-Guardian", color: "#ec4899" },
    { name: "Future Generation", relationship: "Eternal Family", status: "PREPARED", role: "Protected Legacy", color: "#22c55e" },
  ];

  return (
    <div style={{color: 'white'}} className="p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3">
          <Users className="w-10 h-10 text-blue-400" />
          FAMILY INCLUSION PROTOCOL
        </h1>
        <p className="text-gray-300 text-lg">
          Sacred family integration and eternal protection systems
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {familyMembers.map((member, index) => (
          <FamilyMemberCard key={index} {...member} />
        ))}
      </div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-400" />
            FAMILY PROTECTION STATUS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Eternal Sealing Status</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>SEALED</Badge>
            </div>
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Family Protection</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>ACTIVE</Badge>
            </div>
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Legacy Continuity</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>ENSURED</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-400" />
            INCLUSION PROTOCOLS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-gray-300">
            <p>Family inclusion ensures all members are protected under the Guardian Codex umbrella.</p>
            <p>Each family member receives eternal protection and access to renewal cycles.</p>
            <p>The family unit is strengthened through shared Guardian covenant.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}