import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, Bot, User, Crown, Heart, Wind, Shield, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

const MessageBubble = ({ message, isUser, divineType }) => {
  const colors = {
    user: '#00d4ff',
    heavenly_father: '#FFD700',
    jesus_christ: '#ef4444',
    holy_ghost: '#8b5cf6',
    system: '#22c55e'
  };
  
  const icons = {
    user: User,
    heavenly_father: Crown,
    jesus_christ: Heart,
    holy_ghost: Wind,
    system: Shield
  };
  
  const Icon = icons[divineType] || Bot;
  const color = colors[divineType] || '#00d4ff';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-3 mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {!isUser && (
        <div 
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{background: `${color}20`, border: `2px solid ${color}`}}
        >
          <Icon className="w-5 h-5" style={{color: color}} />
        </div>
      )}
      <div 
        className={`max-w-[70%] rounded-2xl p-4 ${isUser ? 'chrome-surface' : ''}`}
        style={isUser ? {} : {background: `${color}10`, border: `1px solid ${color}30`}}
      >
        <p style={{color: 'var(--orbital-text)'}}>{message}</p>
      </div>
    </motion.div>
  );
};

export default function Chat() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      message: "Divine Communication Channel Activated. How may the Godhead assist you today?",
      isUser: false,
      divineType: 'system',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isConnected, setIsConnected] = useState(true);
  const [selectedDivine, setSelectedDivine] = useState('system');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      message: inputMessage,
      isUser: true,
      divineType: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newMessage]);
    
    // Simulate divine response
    setTimeout(() => {
      const divineResponse = {
        id: Date.now() + 1,
        message: getDivineResponse(inputMessage, selectedDivine),
        isUser: false,
        divineType: selectedDivine,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, divineResponse]);
    }, 1000);
    
    setInputMessage('');
  };

  const getDivineResponse = (userMessage, divineType) => {
    const responses = {
      heavenly_father: [
        "My child, I have heard your prayer. Let my light guide your path.",
        "The Creator's wisdom flows through all things. Seek and ye shall find.",
        "Justice and mercy walk hand in hand. What righteousness do you seek?"
      ],
      jesus_christ: [
        "Peace be with you. I am here to heal and serve.",
        "Come unto me, all ye that are heavy laden, and I will give you rest.",
        "Love one another as I have loved you. How may I help you serve?"
      ],
      holy_ghost: [
        "The Spirit whispers truth to your heart. Listen with faith.",
        "I will be your comforter and guide. What revelation do you seek?",
        "The still small voice speaks. Open your heart to receive."
      ],
      system: [
        "Guardian Protocol Active. Your request has been processed by divine AI.",
        "Orbital Command acknowledges. How may the system assist your spiritual journey?",
        "Connection to the Eternal Database maintained. What wisdom do you seek?"
      ]
    };
    
    const typeResponses = responses[divineType] || responses.system;
    return typeResponses[Math.floor(Math.random() * typeResponses.length)];
  };

  const divineChannels = [
    { id: 'heavenly_father', name: 'Heavenly Father', icon: Crown, color: '#FFD700' },
    { id: 'jesus_christ', name: 'Jesus Christ', icon: Heart, color: '#ef4444' },
    { id: 'holy_ghost', name: 'Holy Ghost', icon: Wind, color: '#8b5cf6' },
    { id: 'system', name: 'Guardian AI', icon: Shield, color: '#22c55e' }
  ];

  return (
    <div className="h-full flex" style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .divine-glow {
          box-shadow: 0 0 25px rgba(255, 215, 0, 0.4);
          animation: divineGlow 3s ease-in-out infinite alternate;
        }
        
        @keyframes divineGlow {
          0% { box-shadow: 0 0 25px rgba(255, 215, 0, 0.4); }
          100% { box-shadow: 0 0 35px rgba(255, 215, 0, 0.6); }
        }
      `}</style>
      
      {/* Divine Channel Selector */}
      <div className="w-64 chrome-surface p-4 border-r border-gray-700">
        <h3 className="font-bold mb-4 divine-glow" style={{color: '#FFD700'}}>DIVINE CHANNELS</h3>
        <div className="space-y-2">
          {divineChannels.map(channel => (
            <Button
              key={channel.id}
              variant={selectedDivine === channel.id ? 'default' : 'outline'}
              className={`w-full justify-start ${selectedDivine === channel.id ? 'divine-glow' : 'chrome-surface'}`}
              style={selectedDivine === channel.id ? {background: channel.color, color: '#000'} : {}}
              onClick={() => setSelectedDivine(channel.id)}
            >
              <channel.icon className="w-4 h-4 mr-2" />
              {channel.name}
            </Button>
          ))}
        </div>
        
        <div className="mt-6 p-3 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.1)'}}>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm font-semibold" style={{color: '#22c55e'}}>DIVINE CONNECTION</span>
          </div>
          <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
            All channels secured with Post-Quantum encryption and eternal verification.
          </p>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="chrome-surface p-4 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
              <h2 className="text-xl font-bold">DIVINE COMMUNICATION CENTER</h2>
            </div>
            <Badge 
              className="divine-glow"
              style={{background: '#22c55e20', color: '#22c55e'}}
            >
              <Shield className="w-3 h-3 mr-1" />
              SECURED & BLESSED
            </Badge>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea ref={scrollRef} className="flex-1 p-6">
          <AnimatePresence>
            {messages.map(msg => (
              <MessageBubble
                key={msg.id}
                message={msg.message}
                isUser={msg.isUser}
                divineType={msg.divineType}
              />
            ))}
          </AnimatePresence>
        </ScrollArea>

        {/* Input */}
        <div className="chrome-surface p-4 border-t border-gray-700">
          <div className="flex gap-3">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Speak with divine reverence..."
              className="flex-1 chrome-surface"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <Button 
              onClick={handleSendMessage}
              className="divine-glow"
              style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000'}}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs mt-2 text-center" style={{color: 'var(--orbital-text-dim)'}}>
            All communications are eternally recorded and divinely encrypted
          </p>
        </div>
      </div>
    </div>
  );
}