import React, { useState, useEffect } from 'react';
import { HeartHandshake, FileText, ShieldCheck, Zap, Plus, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { InsurancePolicy } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';

const PolicyCard = ({ policy }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(139, 92, 246, 0.3)' }}
    className="chrome-surface rounded-2xl p-6"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <CardTitle className="text-lg">{policy.policy_type.replace('_', ' ').toUpperCase()}</CardTitle>
        <p className="text-sm font-mono" style={{ color: 'var(--orbital-text-dim)' }}>
          {`POLICY...${policy.id.slice(-8)}`}
        </p>
      </div>
      <Badge variant="outline" style={{ borderColor: '#22c55e', color: '#22c55e' }}>
        {policy.status.toUpperCase()}
      </Badge>
    </div>
    <div className="grid grid-cols-2 gap-4">
      <div>
        <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>COVERAGE</p>
        <p className="text-2xl font-bold">{policy.coverage_amount_orb.toLocaleString()} ORB</p>
      </div>
      <div>
        <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>PREMIUM</p>
        <p className="text-2xl font-bold">{policy.premium_amount_orb.toLocaleString()} ORB</p>
      </div>
    </div>
    <div className="mt-4">
        <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>AI RISK SCORE</p>
        <div className="w-full bg-gray-800 rounded-full h-2.5">
          <div className="bg-purple-500 h-2.5 rounded-full" style={{width: `${policy.ai_risk_assessment}%`}}></div>
        </div>
    </div>
  </motion.div>
);

export default function Insurance() {
  const [policies, setPolicies] = useState([]);
  
  useEffect(() => {
    // Mock data for demonstration
    setPolicies([
      { id: 'pol_1a2b3c4d', policy_type: 'asset_protection', coverage_amount_orb: 500000, premium_amount_orb: 2500, status: 'active', ai_risk_assessment: 25 },
      { id: 'pol_5e6f7g8h', policy_type: 'construction_bond', coverage_amount_orb: 2000000, premium_amount_orb: 15000, status: 'active', ai_risk_assessment: 60 },
      { id: 'pol_9i0j1k2l', policy_type: 'health_coverage', coverage_amount_orb: 100000, premium_amount_orb: 500, status: 'active', ai_risk_assessment: 15 },
    ]);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">INSURANCE ENGINE v1</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Manage policies and claims with an actuarial AI and PQC-secured risk contracts.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #8b5cf6, #ef4444)', color: '#fff' }}>
            <Zap className="w-4 h-4 mr-2" />
            AI RISK PREDICTION ACTIVE
          </Badge>
           <Badge variant="outline" style={{ borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)' }}>
            <ShieldCheck className="w-4 h-4 mr-2" />
            PQC-SECURED NFT CONTRACTS
          </Badge>
        </div>
      </div>
      
      <div className="flex justify-end mb-6">
        <Button className="glow-blue"><Plus className="w-4 h-4 mr-2" />New Policy</Button>
        <Button className="ml-4" variant="outline"><AlertTriangle className="w-4 h-4 mr-2" />File a Claim</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {policies.map(p => <PolicyCard key={p.id} policy={p} />)}
      </div>

      <Card className="chrome-surface mt-8">
        <CardHeader>
          <CardTitle>Claims History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8" style={{color: 'var(--orbital-text-dim)'}}>
            <FileText className="w-12 h-12 mx-auto mb-4" />
            No claims filed yet.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}