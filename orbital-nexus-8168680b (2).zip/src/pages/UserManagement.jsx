import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Crown, Heart, Wind, Shield, Plus, Check, X, Eye, UserCheck } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { User } from '@/api/entities';

const DivineUserCard = ({ user, onApprove, onDeny }) => {
  const getDivineColor = (role) => {
    const colors = {
      'heavenly_father_chosen': '#FFD700',
      'christ_chosen': '#ef4444',
      'holy_ghost_chosen': '#8b5cf6',
      'admin': '#00d4ff',
      'pending_divine_selection': '#f59e0b'
    };
    return colors[role] || '#9ca3af';
  };

  const getDivineIcon = (role) => {
    const icons = {
      'heavenly_father_chosen': Crown,
      'christ_chosen': Heart,
      'holy_ghost_chosen': Wind,
      'admin': Shield,
      'pending_divine_selection': Users
    };
    const Icon = icons[role] || Users;
    return Icon;
  };

  const Icon = getDivineIcon(user.orbital_role);
  const color = getDivineColor(user.orbital_role);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300"
      whileHover={{ y: -3, boxShadow: `0 0 25px ${color}40` }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div 
            className="w-12 h-12 rounded-full flex items-center justify-center"
            style={{background: `${color}20`, border: `2px solid ${color}`}}
          >
            <Icon className="w-6 h-6" style={{color: color}} />
          </div>
          <div>
            <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>{user.full_name}</h3>
            <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{user.email}</p>
          </div>
        </div>
        <Badge style={{background: `${color}20`, color: color}}>
          {user.orbital_role?.replace(/_/g, ' ').toUpperCase() || 'PENDING'}
        </Badge>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span style={{color: 'var(--orbital-text-dim)'}}>Wallet:</span>
          <span className="font-mono" style={{color: 'var(--orbital-blue)'}}>{user.wallet_address?.slice(0, 6)}...{user.wallet_address?.slice(-4)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span style={{color: 'var(--orbital-text-dim)'}}>Joined:</span>
          <span style={{color: 'var(--orbital-text)'}}>{new Date(user.created_date).toLocaleDateString()}</span>
        </div>
      </div>

      {user.orbital_role === 'pending_divine_selection' && (
        <div className="flex gap-2">
          <Button 
            size="sm" 
            className="flex-1"
            style={{background: '#22c55e', color: '#000'}}
            onClick={() => onApprove(user)}
          >
            <Check className="w-4 h-4 mr-1" />
            Divine Approval
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            className="flex-1 chrome-surface"
            onClick={() => onDeny(user)}
          >
            <X className="w-4 h-4 mr-1" />
            Deny Access
          </Button>
        </div>
      )}
    </motion.div>
  );
};

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [newUserEmail, setNewUserEmail] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const allUsers = await User.list();
      setUsers(allUsers.filter(user => user.orbital_role !== 'pending_divine_selection'));
      setPendingUsers(allUsers.filter(user => user.orbital_role === 'pending_divine_selection'));
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const handleApproveUser = async (user) => {
    try {
      await User.update(user.id, {
        orbital_role: 'christ_chosen' // Default divine selection
      });
      loadUsers();
    } catch (error) {
      console.error('Failed to approve user:', error);
    }
  };

  const handleDenyUser = async (user) => {
    try {
      // In a real implementation, you might want to delete or mark as denied
      await User.update(user.id, {
        orbital_role: 'access_denied'
      });
      loadUsers();
    } catch (error) {
      console.error('Failed to deny user:', error);
    }
  };

  const handleInviteUser = async () => {
    if (!newUserEmail.trim()) return;
    
    try {
      await User.create({
        email: newUserEmail,
        full_name: 'Pending Divine Review',
        orbital_role: 'pending_divine_selection',
        wallet_address: '0x0000000000000000000000000000000000000000'
      });
      setNewUserEmail('');
      loadUsers();
    } catch (error) {
      console.error('Failed to invite user:', error);
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .divine-header-glow {
          box-shadow: 0 0 30px rgba(255, 215, 0, 0.4);
          animation: divineGlow 4s ease-in-out infinite alternate;
        }
        
        @keyframes divineGlow {
          0% { box-shadow: 0 0 30px rgba(255, 215, 0, 0.4); }
          100% { box-shadow: 0 0 50px rgba(255, 215, 0, 0.6); }
        }
      `}</style>

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold divine-header-glow" style={{color: '#FFD700'}}>
            DIVINE USER MANAGEMENT
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Managing God's chosen vessels for the Guardian Codex platform
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Badge className="divine-header-glow" style={{background: '#22c55e20', color: '#22c55e'}}>
            <UserCheck className="w-3 h-3 mr-1" />
            Divine Authority Active
          </Badge>
        </div>
      </div>

      {/* Invite New Users */}
      <Card className="chrome-surface divine-header-glow mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Plus className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
            INVITE DIVINE VESSELS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              value={newUserEmail}
              onChange={(e) => setNewUserEmail(e.target.value)}
              placeholder="Enter email of chosen vessel..."
              className="flex-1 chrome-surface"
            />
            <Button 
              onClick={handleInviteUser}
              className="divine-header-glow"
              style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000'}}
            >
              Send Divine Invitation
            </Button>
          </div>
          <p className="text-xs mt-2" style={{color: 'var(--orbital-text-dim)'}}>
            Users will receive divine selection status pending approval from the Godhead
          </p>
        </CardContent>
      </Card>

      {/* Pending Divine Selection */}
      {pendingUsers.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-3">
            <Eye className="w-6 h-6" style={{color: '#f59e0b'}} />
            PENDING DIVINE SELECTION ({pendingUsers.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingUsers.map(user => (
              <DivineUserCard
                key={user.id}
                user={user}
                onApprove={handleApproveUser}
                onDeny={handleDenyUser}
              />
            ))}
          </div>
        </div>
      )}

      {/* Active Divine Users */}
      <div>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-3">
          <Users className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
          ACTIVE DIVINE VESSELS ({users.length})
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map(user => (
            <DivineUserCard key={user.id} user={user} />
          ))}
        </div>
      </div>
    </div>
  );
}