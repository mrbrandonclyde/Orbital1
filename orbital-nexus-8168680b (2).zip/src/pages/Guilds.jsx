import React, { useState, useEffect } from 'react';
import { Swords, Users, Shield, FileText, Brain, Handshake } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Guild } from '@/api/entities';
import { motion } from 'framer-motion';

const GuildCard = ({ guild }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl p-6"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <CardTitle className="text-xl">{guild.name}</CardTitle>
        <p className="text-sm font-semibold" style={{ color: 'var(--orbital-blue)' }}>
          {guild.specialization.toUpperCase()}
        </p>
      </div>
      <Badge variant="outline" className="flex items-center gap-1">
        <Users className="w-3 h-3" />
        {guild.members} Members
      </Badge>
    </div>
    <p className="text-sm mb-4" style={{color: 'var(--orbital-text-dim)'}}>{guild.charter}</p>
    <div className="flex justify-between items-center">
      <div className="text-sm">Reputation: <span className="font-bold">{guild.reputation_score}/100</span></div>
      <Button variant="outline" size="sm">View Charter</Button>
    </div>
  </motion.div>
);

export default function Guilds() {
  const [guilds, setGuilds] = useState([]);
  
  useEffect(() => {
    // Mock data for demonstration
    setGuilds([
      { id: 'gld_1', name: 'Aegis Constructors', charter: 'Building the worlds of tomorrow, today.', specialization: 'construction', members: 125, reputation_score: 95 },
      { id: 'gld_2', name: 'Meridian Merchants', charter: 'Facilitating trade across all known sectors.', specialization: 'mercantile', members: 250, reputation_score: 88 },
      { id: 'gld_3', name: 'Starseekers Cartography', charter: 'Mapping the unknown, charting the future.', specialization: 'exploration', members: 75, reputation_score: 92 },
    ]);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">AI WORKFORCE GUILDS</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Manage NPC unions, negotiate fair contracts, and view PQC-secured guild charters.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #f59e0b, #ef4444)', color: '#fff' }}>
            <Brain className="w-4 h-4 mr-2" />
            AI-DRIVEN FAIRNESS ENFORCEMENT
          </Badge>
           <Badge variant="outline" style={{ borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)' }}>
            <FileText className="w-4 h-4 mr-2" />
            PQC-SECURED NFT CHARTERS
          </Badge>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {guilds.map(g => <GuildCard key={g.id} guild={g} />)}
      </div>

      <Card className="chrome-surface mt-8">
        <CardHeader>
          <CardTitle>Contract Negotiations</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12" style={{color: 'var(--orbital-text-dim)'}}>
          <Handshake className="w-16 h-16 mx-auto mb-4" />
          <p>Live negotiation simulations with AI arbitrators coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}