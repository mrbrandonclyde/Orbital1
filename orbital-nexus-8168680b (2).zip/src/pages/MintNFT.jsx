import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Zap, Image as ImageIcon, Upload, CheckCircle, Loader2 } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { NFT } from '@/api/entities';

const NFTPreviewCard = ({ name, type, file }) => (
  <div className="chrome-surface rounded-2xl overflow-hidden transition-all duration-300">
    <div className="relative h-48 bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center overflow-hidden">
      {file ? (
        <img src={URL.createObjectURL(file)} alt="Preview" className="w-full h-full object-cover" />
      ) : (
        <ImageIcon className="w-16 h-16" style={{color: 'var(--orbital-text-dim)'}} />
      )}
    </div>
    <div className="p-4">
      <h3 className="font-bold mb-2 truncate" style={{color: 'var(--orbital-text)'}}>{name || 'Untitled NFT'}</h3>
      <div className="flex justify-between items-center">
        <span className="text-xs px-2 py-1 rounded-full chrome-surface" style={{color: 'var(--orbital-blue)'}}>
          {type?.toUpperCase() || 'TYPE'}
        </span>
        <div className="text-lg font-bold" style={{color: 'var(--orbital-blue)'}}>
          ... ORB
        </div>
      </div>
    </div>
  </div>
);

export default function MintNFT() {
  const [file, setFile] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    asset_type: '',
    royalty_bps: 500, // 5%
  });
  const [mintingStatus, setMintingStatus] = useState('idle'); // idle, minting, success

  const onDrop = useCallback(acceptedFiles => {
    setFile(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: false,
  });

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleMint = async () => {
    if (!file || !formData.name || !formData.asset_type) {
      // Add user feedback for required fields
      return;
    }
    setMintingStatus('minting');
    try {
      // In a real app, you'd upload the file to IPFS or similar storage
      // and get a metadata URI.
      await NFT.create({
        ...formData,
        contract_address: '0x' + [...Array(40)].map(() => Math.floor(Math.random() * 16).toString(16)).join(''),
        token_id: Math.floor(Math.random() * 1e9).toString(),
        owner_wallet: '0x...LOGGED_IN_USER', // Placeholder for user's wallet
        metadata_uri: `ipfs://${file.name}`,
      });
      setMintingStatus('success');
      setTimeout(() => {
        setMintingStatus('idle');
        setFile(null);
        setFormData({ name: '', description: '', asset_type: '', royalty_bps: 500 });
      }, 3000);
    } catch (error) {
      console.error("Minting failed:", error);
      setMintingStatus('idle'); // Or an 'error' state
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">MINT A NEW NFT</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>Forge a unique digital asset on the blockchain</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
                NFT DETAILS
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div {...getRootProps()} className={`p-8 border-2 border-dashed rounded-xl text-center cursor-pointer transition-colors ${isDragActive ? 'border-blue-400 bg-blue-500/10' : 'border-gray-600 hover:border-blue-400'}`}>
                <input {...getInputProps()} />
                <div className="flex flex-col items-center">
                  <Upload className="w-10 h-10 mb-3" style={{color: 'var(--orbital-text-dim)'}} />
                  {file ? (
                    <p>{file.name}</p>
                  ) : isDragActive ? (
                    <p>Drop the files here ...</p>
                  ) : (
                    <p>Drag 'n' drop your asset here, or click to select file</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Name</label>
                <Input value={formData.name} onChange={e => handleInputChange('name', e.target.value)} placeholder="e.g., Crystal Golem" className="chrome-surface" />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <Textarea value={formData.description} onChange={e => handleInputChange('description', e.target.value)} placeholder="A brief description of your asset..." className="chrome-surface" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Asset Type</label>
                  <Select value={formData.asset_type} onValueChange={v => handleInputChange('asset_type', v)}>
                    <SelectTrigger className="chrome-surface"><SelectValue placeholder="Select a type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="avatar">Avatar</SelectItem>
                      <SelectItem value="parcel">Parcel</SelectItem>
                      <SelectItem value="wearable">Wearable</SelectItem>
                      <SelectItem value="art">Art</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Royalty Fee (%)</label>
                  <Input type="number" value={formData.royalty_bps / 100} onChange={e => handleInputChange('royalty_bps', Number(e.target.value) * 100)} placeholder="e.g., 5" className="chrome-surface" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="chrome-surface sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
                PREVIEW
              </CardTitle>
            </CardHeader>
            <CardContent>
              <NFTPreviewCard name={formData.name} type={formData.asset_type} file={file} />
            </CardContent>
          </Card>
          
          <Button
            onClick={handleMint}
            disabled={mintingStatus !== 'idle' || !file || !formData.name || !formData.asset_type}
            className="w-full font-bold py-6 text-lg"
            style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={mintingStatus}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="flex items-center justify-center"
              >
                {mintingStatus === 'idle' && <><Zap className="w-6 h-6 mr-2" /> MINT NFT</>}
                {mintingStatus === 'minting' && <><Loader2 className="w-6 h-6 mr-2 animate-spin" /> MINTING...</>}
                {mintingStatus === 'success' && <><CheckCircle className="w-6 h-6 mr-2" /> MINTED SUCCESSFULLY</>}
              </motion.div>
            </AnimatePresence>
          </Button>
        </div>
      </div>
    </div>
  );
}