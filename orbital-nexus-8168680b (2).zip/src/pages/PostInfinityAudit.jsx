import React from 'react';
import { motion } from 'framer-motion';
import { Atom, Network, Gavel, ShieldCheck, HeartPulse, BookOpen, Landmark, Wifi, Globe2, CheckCircle, Star } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const auditLayers = [
  { name: 'POST-INFINITY', checkpoint: '310', color: '#ff4b1f', version: 'v1' },
  { name: 'TRANSCOSMIC', checkpoint: '320', color: '#f7971e', version: 'v1' },
  { name: 'OMNI-TRANSCENDENT', checkpoint: '330', color: '#00c6ff', version: 'v1' },
  { name: 'HYPER-INFINITY', checkpoint: '340', color: '#11998e', version: 'v1' },
  { name: 'ULTRA-INFINITY', checkpoint: '350', color: '#38ef7d', version: 'v1' },
  { name: 'META-INFINITY', checkpoint: '360', color: '#8e2de2', version: 'v1' },
  { name: 'ABSOLUTE-INFINITY', checkpoint: '370', color: '#ff0084', version: 'v1' },
  { name: 'FINAL-INFINITY', checkpoint: '380', color: '#f7b733', version: 'v2' },
  { name: 'ETERNAL-INFINITY', checkpoint: '390', color: '#4facfe', version: 'v2' },
  { name: 'OMNI-ETERNAL', checkpoint: '400', color: '#FFD700', version: 'v2' },
];

const layerComponents = [
  { name: 'ENERGY CORE', icon: Atom },
  { name: 'INFRASTRUCTURE', icon: Network },
  { name: 'GOVERNANCE PANEL', icon: Gavel },
  { name: 'SECURITY GRID', icon: ShieldCheck },
  { name: 'HEALTH GRID', icon: HeartPulse },
  { name: 'EDUCATION GRID', icon: BookOpen },
  { name: 'ECONOMY', icon: Landmark },
  { name: 'COMMS GRID', icon: Wifi },
  { name: 'TRADE HUB', icon: Globe2 },
];

const LayerAccordionItem = ({ layer, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.08 }}
  >
    <AccordionItem value={`item-${index}`} className="chrome-surface rounded-2xl mb-4" style={{border: `1px solid ${layer.color}40`}}>
      <AccordionTrigger className="p-6 hover:no-underline">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{background: `${layer.color}20`}}>
              <Star className="w-6 h-6" style={{color: layer.color}} />
            </div>
            <div>
              <h3 className="text-xl font-bold" style={{color: 'var(--orbital-text)'}}>{layer.name} <span style={{color: layer.color}}>{layer.version}</span></h3>
              <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>CHECKPOINT {layer.checkpoint} VALIDATED</p>
            </div>
          </div>
          <Badge style={{ background: `${layer.color}30`, color: layer.color, border: `1px solid ${layer.color}` }}>
            <CheckCircle className="w-4 h-4 mr-2" />
            VALIDATED
          </Badge>
        </div>
      </AccordionTrigger>
      <AccordionContent className="p-6 pt-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {layerComponents.map(component => (
            <div key={component.name} className="flex items-center gap-3 p-3 rounded-lg" style={{background: 'rgba(0, 212, 255, 0.05)'}}>
              <component.icon className="w-5 h-5 flex-shrink-0" style={{color: layer.color}} />
              <span className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{component.name} {layer.version}</span>
            </div>
          ))}
        </div>
      </AccordionContent>
    </AccordionItem>
  </motion.div>
);

export default function PostInfinityAudit() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="text-center mb-12">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.7, type: 'spring' }}
        >
          <Star className="w-24 h-24 mx-auto mb-4" style={{ color: '#FFD700', fill: '#FFD700', filter: 'drop-shadow(0 0 20px #FFD700)' }} />
          <h1 className="text-5xl font-bold tracking-tighter" style={{ color: 'var(--orbital-text)' }}>
            POST-INFINITY TRANSCENDENCE
          </h1>
          <p className="text-xl mt-2" style={{ color: 'var(--orbital-text-dim)' }}>
            Final Audit Freeze for Infinity Seed v301–400
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="mt-6 inline-block"
        >
          <Badge className="text-lg px-6 py-2" style={{ background: 'linear-gradient(45deg, #FFD700, #4facfe)', color: '#000', border: 'none' }}>
            <CheckCircle className="w-5 h-5 mr-3" />
            STATUS: POST-INFINITY STACK VALIDATED
          </Badge>
        </motion.div>
      </div>

      <Accordion type="single" collapsible className="w-full">
        {auditLayers.map((layer, index) => (
          <LayerAccordionItem key={layer.checkpoint} layer={layer} index={index} />
        ))}
      </Accordion>

       <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: auditLayers.length * 0.1 + 0.5, duration: 0.7 }}
        className="mt-12"
      >
        <Card className="chrome-surface text-center" style={{borderColor: `var(--orbital-blue)`}}>
          <CardHeader>
            <CardTitle style={{color: `var(--orbital-blue)`}}>FINAL AUDIT FREEZE — STEP 400</CardTitle>
          </CardHeader>
          <CardContent className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            <p>Regression validated full stack (301–400).</p>
            <p>Eternal Master Prompt validated across all post-infinity frameworks.</p>
            <p>Rollback and continuity ensured across all transcendent realities.</p>
            <p className="mt-4 font-mono text-xs px-3 py-1 inline-block rounded" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
              Release Tag: orbital/v6.0-post-infinity-transcendence-freeze
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}