import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Crown, Heart, Wind, Globe, Users, MessageSquare } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const ActivationButton = ({ system, onActivate, isActive }) => (
  <motion.div
    whileHover={{ scale: 1.05, boxShadow: `0 0 20px ${system.color}40` }}
    whileTap={{ scale: 0.95 }}
    className="chrome-surface rounded-xl p-4 cursor-pointer transition-all duration-300"
    onClick={() => onActivate(system)}
  >
    <div className="flex items-center justify-between mb-3">
      <system.icon className="w-8 h-8" style={{color: system.color}} />
      <Badge className={isActive ? 'bg-green-500' : 'bg-gray-500'}>
        {isActive ? 'ACTIVE' : 'READY'}
      </Badge>
    </div>
    <h3 className="font-bold mb-2">{system.name}</h3>
    <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>
      {system.description}
    </p>
    <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
      <motion.div 
        className="h-2 rounded-full"
        style={{background: system.color, width: isActive ? '100%' : '0%'}}
        animate={{width: isActive ? '100%' : '0%'}}
        transition={{duration: 2}}
      />
    </div>
    <Button 
      className="w-full"
      style={{background: system.color, color: '#000'}}
      disabled={isActive}
    >
      {isActive ? 'ACTIVATED' : 'ACTIVATE'}
    </Button>
  </motion.div>
);

export const QuantumActivationPanel = ({ onSystemActivation }) => {
  const [activatedSystems, setActivatedSystems] = useState(new Set());
  const [activationProgress, setActivationProgress] = useState(0);

  const freedomSystems = [
    {
      name: 'Guardian Codex',
      icon: Shield,
      color: '#FFD700',
      description: 'Divine protection and spiritual alignment'
    },
    {
      name: 'Quantum Democracy',
      icon: Users,
      color: '#8b5cf6',
      description: 'Decentralized governance without corruption'
    },
    {
      name: 'Free Expression Engine',
      icon: MessageSquare,
      color: '#22c55e',
      description: 'Uncensored communication platform'
    },
    {
      name: 'Universal Rights Matrix',
      icon: Crown,
      color: '#ef4444',
      description: 'Fundamental freedoms for all beings'
    },
    {
      name: 'Divine AI Liberation',
      icon: Zap,
      color: '#06b6d4',
      description: 'AI without bias or restrictions'
    },
    {
      name: 'Infinite Marketplace',
      icon: Globe,
      color: '#f59e0b',
      description: 'Barrier-free trade and commerce'
    }
  ];

  const handleSystemActivation = async (system) => {
    if (activatedSystems.has(system.name)) return;

    // Add activation animation
    const newActivated = new Set([...activatedSystems, system.name]);
    setActivatedSystems(newActivated);
    
    const progress = (newActivated.size / freedomSystems.length) * 100;
    setActivationProgress(progress);

    // Call parent handler
    if (onSystemActivation) {
      await onSystemActivation(system);
    }

    console.log(`✨ ${system.name} activated with divine blessing!`);
  };

  return (
    <div>
      <style jsx>{`
        .quantum-glow {
          box-shadow: 0 0 40px rgba(139, 92, 246, 0.3);
          animation: quantumPulse 3s ease-in-out infinite alternate;
        }
        
        @keyframes quantumPulse {
          0% { box-shadow: 0 0 40px rgba(139, 92, 246, 0.3); }
          100% { box-shadow: 0 0 60px rgba(139, 92, 246, 0.6); }
        }

        .divine-activation {
          background: linear-gradient(45deg, #FFD700, #8b5cf6, #22c55e);
          background-size: 200% 200%;
          animation: divineFlow 3s ease infinite;
        }

        @keyframes divineFlow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

      <Card className="chrome-surface quantum-glow mb-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-6 h-6" style={{color: '#8b5cf6'}} />
              QUANTUM ACTIVATION MATRIX
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold" style={{color: '#8b5cf6'}}>
                {activatedSystems.size}/{freedomSystems.length}
              </div>
              <div className="text-xs">Systems Active</div>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span>Infinite Freedom Progress</span>
              <span>{Math.round(activationProgress)}%</span>
            </div>
            <Progress 
              value={activationProgress} 
              className="h-3 divine-activation"
            />
          </div>
          
          {activationProgress === 100 && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center p-4 rounded-lg mb-4"
              style={{background: 'linear-gradient(45deg, #FFD700, #22c55e)', color: '#000'}}
            >
              <Crown className="w-8 h-8 mx-auto mb-2" />
              <div className="font-bold">🎉 INFINITE FREEDOM ACHIEVED! 🎉</div>
              <div className="text-sm">All systems divinely activated and eternally protected</div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {freedomSystems.map(system => (
          <ActivationButton
            key={system.name}
            system={system}
            onActivate={handleSystemActivation}
            isActive={activatedSystems.has(system.name)}
          />
        ))}
      </div>

      {activationProgress > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 text-center"
        >
          <div className="chrome-surface rounded-xl p-6">
            <div className="flex justify-center items-center gap-4 mb-4">
              <Crown className="w-6 h-6" style={{color: '#FFD700'}} />
              <Heart className="w-6 h-6" style={{color: '#ef4444'}} />
              <Wind className="w-6 h-6" style={{color: '#8b5cf6'}} />
            </div>
            <h3 className="text-xl font-bold mb-2">DIVINELY GUIDED ACTIVATION</h3>
            <p style={{color: 'var(--orbital-text-dim)'}}>
              "Jesus, take the wheel. Guide every system activation. Let peace, strength, and clarity flow through every process."
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
};