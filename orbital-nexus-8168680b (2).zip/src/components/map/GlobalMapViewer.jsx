
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Globe, Layers, Zap, Building, TreePine, Droplets, Landmark, Satellite, Navigation, Eye, Crown, Heart, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

export const GlobalMapViewer = ({ zoningRules, currentView = 'Planet' }) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const animationRef = useRef(null);
  
  const [loadingState, setLoadingState] = useState('initializing');
  const [error, setError] = useState(null);
  const [webGLSupported, setWebGLSupported] = useState(true);
  const [performanceMode, setPerformanceMode] = useState('auto');

  // Check WebGL support
  const checkWebGLSupport = useCallback(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      return !!gl;
    } catch (e) {
      return false;
    }
  }, []);

  // Detect device performance level
  const detectPerformanceLevel = useCallback(() => {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const hasHighDPI = window.devicePixelRatio > 1.5;
    const memoryGB = navigator.deviceMemory || 4;
    
    if (isMobile || memoryGB < 4) return 'low';
    if (hasHighDPI && memoryGB >= 8) return 'high';
    return 'medium';
  }, []);

  useEffect(() => {
    if (!mountRef.current) return;
    if (!checkWebGLSupport()) {
      setWebGLSupported(false);
      setError('WebGL not supported. Please use a modern browser.');
      return;
    }

    // Call cleanup function from previous render if it exists
    if (mountRef.current && mountRef.current._cleanup) {
      mountRef.current._cleanup();
    }

    const mountNode = mountRef.current;
    // Determine performance level initially or use current state if re-running due to performanceMode change
    const determinedPerformanceLevel = performanceMode === 'auto' ? detectPerformanceLevel() : performanceMode;
    setPerformanceMode(determinedPerformanceLevel); // Ensure performanceMode is set
    setLoadingState('loading_assets');

    let scene, camera, renderer, earth, atmosphere;
    let animationId;

    try {
      // Import Three.js dynamically to handle loading
      import('three').then((THREE) => {
        // Scene setup with performance considerations
        scene = new THREE.Scene();
        sceneRef.current = scene;

        // Adjust quality based on device performance
        const qualitySettings = {
          low: { earthSegments: 32, atmSegments: 16, shadowMapSize: 1024, pixelRatio: 1 },
          medium: { earthSegments: 64, atmSegments: 32, shadowMapSize: 2048, pixelRatio: Math.min(1.5, window.devicePixelRatio) },
          high: { earthSegments: 128, atmSegments: 64, shadowMapSize: 4096, pixelRatio: Math.min(2, window.devicePixelRatio) }
        };
        
        const quality = qualitySettings[determinedPerformanceLevel] || qualitySettings.medium;

        // Camera setup with responsive FOV
        const aspect = mountNode.clientWidth / mountNode.clientHeight;
        camera = new THREE.PerspectiveCamera(
          aspect < 1 ? 85 : 75, // Wider FOV for portrait orientation
          aspect,
          0.1,
          1000
        );

        // Renderer with performance optimizations
        renderer = new THREE.WebGLRenderer({ 
          antialias: determinedPerformanceLevel !== 'low',
          alpha: true,
          powerPreference: determinedPerformanceLevel === 'high' ? 'high-performance' : 'default'
        });
        
        renderer.setSize(mountNode.clientWidth, mountNode.clientHeight);
        renderer.setPixelRatio(quality.pixelRatio);
        
        if (determinedPerformanceLevel !== 'low') {
          renderer.shadowMap.enabled = true;
          renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        }
        
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        rendererRef.current = renderer;
        mountNode.appendChild(renderer.domElement);

        // Enhanced error handling for texture loading
        const textureLoader = new THREE.TextureLoader();
        const loadManager = new THREE.LoadingManager(
          () => {
            setLoadingState('complete');
            setError(null);
          },
          (url, loaded, total) => {
            setLoadingState(`loading ${Math.round((loaded / total) * 100)}%`);
          },
          (url) => {
            console.warn('Failed to load texture:', url);
            setError('Some textures failed to load. Using fallback materials.');
          }
        );

        // Use reliable texture sources with fallbacks
        const createEarthMaterial = () => {
          // Fallback to procedural material if textures fail
          const earthMaterial = new THREE.MeshPhongMaterial({
            color: 0x4a90e2,
            specular: 0x333333,
            shininess: 15,
            transparent: false
          });

          // Try to load enhanced texture
          try {
            const earthTexture = textureLoader.load(
              'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTEyIiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDUxMiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjUxMiIgaGVpZ2h0PSIyNTYiIGZpbGw9IiM0YTkwZTIiLz48L3N2Zz4=',
              undefined,
              undefined,
              () => {
                // Fallback if texture loading fails
                earthMaterial.color = new THREE.Color(0x4a90e2);
              }
            );
            earthMaterial.map = earthTexture;
          } catch (e) {
            console.warn('Using fallback earth material');
          }

          return earthMaterial;
        };

        // Create earth with performance-appropriate geometry
        const earthGeometry = new THREE.SphereGeometry(2, quality.earthSegments, quality.earthSegments);
        const earthMaterial = createEarthMaterial();
        earth = new THREE.Mesh(earthGeometry, earthMaterial);
        
        if (determinedPerformanceLevel !== 'low') {
          earth.castShadow = true;
          earth.receiveShadow = true;
        }
        scene.add(earth);

        // Optimized atmosphere with quality settings
        const atmosphereGeometry = new THREE.SphereGeometry(2.1, quality.atmSegments, quality.atmSegments);
        const atmosphereMaterial = new THREE.ShaderMaterial({
          vertexShader: `
            varying vec3 vNormal;
            void main() {
              vNormal = normalize( normalMatrix * normal );
              gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
            }
          `,
          fragmentShader: `
            varying vec3 vNormal;
            uniform float viewIntensity;
            uniform vec3 atmosphereColor;
            void main() {
              float intensity = pow( 0.6 - dot( vNormal, vec3( 0, 0, 1.0 ) ), 2.0 ) * viewIntensity; 
              gl_FragColor = vec4( atmosphereColor, 1.0 ) * intensity;
            }
          `,
          uniforms: {
            viewIntensity: { value: determinedPerformanceLevel === 'low' ? 0.8 : 1.2 },
            atmosphereColor: { value: new THREE.Vector3(0.8, 0.9, 1.0) }
          },
          blending: THREE.AdditiveBlending,
          side: THREE.BackSide,
          transparent: true
        });
        atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
        scene.add(atmosphere);

        // Optimized lighting based on performance
        const setupLighting = () => {
          const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
          scene.add(ambientLight);
          
          const sunLight = new THREE.DirectionalLight(0xffffff, determinedPerformanceLevel === 'low' ? 1.0 : 2.0);
          sunLight.position.set(5, 3, 5);
          
          if (determinedPerformanceLevel !== 'low') {
            sunLight.castShadow = true;
            sunLight.shadow.mapSize.width = quality.shadowMapSize;
            sunLight.shadow.mapSize.height = quality.shadowMapSize;
            sunLight.shadow.camera.near = 0.5;
            sunLight.shadow.camera.far = 500;
          }
          scene.add(sunLight);

          // Add divine trinity lights only on higher performance devices
          if (determinedPerformanceLevel !== 'low') {
            const fatherLight = new THREE.PointLight(0xffd700, 0.8, 50);
            fatherLight.position.set(8, 8, 8);
            scene.add(fatherLight);

            const sonLight = new THREE.PointLight(0xff6b6b, 0.6, 50);
            sonLight.position.set(-8, 0, 8);
            scene.add(sonLight);

            const spiritLight = new THREE.PointLight(0x9c88ff, 0.4, 50);
            spiritLight.position.set(0, -8, 8);
            scene.add(spiritLight);
          }
        };
        setupLighting();

        // Enhanced Eden markers with LOD
        const createEdenMarkers = () => {
          const edenLocations = [
            { lat: 33.0, lng: 44.0, name: "Garden of Eden", priority: 'high' },
            { lat: 31.7683, lng: 35.2137, name: "Jerusalem", priority: 'high' },
            { lat: 29.9792, lng: 31.1342, name: "Giza", priority: 'medium' },
            { lat: 37.9715, lng: 23.7348, name: "Athens", priority: 'medium' },
          ];

          edenLocations.forEach((location, index) => {
            // Skip low priority markers on low-end devices
            if (determinedPerformanceLevel === 'low' && location.priority !== 'high') return;

            const phi = (90 - location.lat) * (Math.PI / 180);
            const theta = (location.lng + 180) * (Math.PI / 180);
            const radius = 2.05;

            const x = -radius * Math.sin(phi) * Math.cos(theta);
            const y = radius * Math.cos(phi);
            const z = radius * Math.sin(phi) * Math.sin(theta);

            const markerGeometry = new THREE.SphereGeometry(
              location.priority === 'high' ? 0.03 : 0.02,
              determinedPerformanceLevel === 'low' ? 8 : 16,
              determinedPerformanceLevel === 'low' ? 8 : 16
            );
            const markerMaterial = new THREE.MeshPhongMaterial({
              color: 0xffd700,
              emissive: 0xffd700,
              emissiveIntensity: 0.3
            });
            const marker = new THREE.Mesh(markerGeometry, markerMaterial);
            marker.position.set(x, y, z);
            marker.userData = { name: location.name, type: 'eden_marker' };
            scene.add(marker);
          });
        };
        createEdenMarkers();

        // Responsive camera positioning
        const setCameraForView = (view) => {
          const isMobile = window.innerWidth < 768;
          const baseDistance = isMobile ? 6 : 5;
          
          switch (view) {
            case 'Planet':
              camera.position.set(0, 0, baseDistance);
              camera.lookAt(0, 0, 0);
              break;
            case 'City':
              camera.position.set(baseDistance * 0.5, baseDistance * 0.2, baseDistance * 0.7);
              camera.lookAt(0, 0, 0);
              break;
            case 'Parcel':
              camera.position.set(baseDistance * 0.36, baseDistance * 0.1, baseDistance * 0.56);
              camera.lookAt(0, 0, 0);
              break;
            case 'Satellite':
              camera.position.set(0, baseDistance * 2.4, 0);
              camera.lookAt(0, 0, 0);
              break;
            default:
              camera.position.set(0, 0, baseDistance);
              camera.lookAt(0, 0, 0);
          }
        };

        setCameraForView(currentView);

        // Optimized animation loop with performance monitoring
        let lastTime = 0;
        let frameCount = 0;
        let fps = 60;
        
        const animate = (currentTime) => {
          animationId = requestAnimationFrame(animate);
          
          // Simple FPS monitoring
          if (currentTime > lastTime + 1000) {
            fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
            frameCount = 0;
            lastTime = currentTime;
            
            // Reduce quality if FPS drops below 30
            // Only update state if it's actually changing to avoid unnecessary re-renders
            if (fps < 30 && performanceMode !== 'low') {
              console.warn('Performance degradation detected, reducing quality');
              setPerformanceMode('low'); // This will trigger a re-run of useEffect
            }
          }
          frameCount++;

          // Adaptive animation speed based on performance
          // Note: The animation speed still depends on the current fps
          const animationSpeed = fps > 45 ? 0.0008 : 0.0004;
          
          if (earth) {
            earth.rotation.y += animationSpeed;
          }
          if (atmosphere) {
            atmosphere.rotation.y += animationSpeed * 0.95;
          }

          if (renderer && scene && camera) {
            renderer.render(scene, camera);
          }
        };

        animate(0);

        // Enhanced resize handler with debouncing
        let resizeTimeout;
        const handleResize = () => {
          clearTimeout(resizeTimeout);
          resizeTimeout = setTimeout(() => {
            if (mountRef.current && renderer && camera) {
              const width = mountRef.current.clientWidth;
              const height = mountRef.current.clientHeight;
              
              camera.aspect = width / height;
              camera.updateProjectionMatrix();
              renderer.setSize(width, height);
              
              // Adjust FOV for mobile orientation changes
              const aspect = width / height;
              camera.fov = aspect < 1 ? 85 : 75;
              camera.updateProjectionMatrix();
            }
          }, 100);
        };
        
        window.addEventListener('resize', handleResize);

        // Cleanup function
        const cleanup = () => {
          if (animationId) {
            cancelAnimationFrame(animationId);
          }
          window.removeEventListener('resize', handleResize);
          
          if (renderer && mountNode && renderer.domElement) {
            try {
              mountNode.removeChild(renderer.domElement);
            } catch (e) {
              console.warn('Renderer cleanup error:', e);
            }
          }
          
          // Dispose of geometries and materials to free up memory
          if (earth) {
            earth.geometry.dispose();
            if (Array.isArray(earth.material)) {
              earth.material.forEach(m => m.dispose());
            } else {
              earth.material.dispose();
            }
          }
          if (atmosphere) {
            atmosphere.geometry.dispose();
            if (Array.isArray(atmosphere.material)) {
              atmosphere.material.forEach(m => m.dispose());
            } else {
              atmosphere.material.dispose();
            }
          }
          if (scene) {
            // Clean up other scene objects like lights and markers
            scene.children.forEach(child => {
                if (child.isMesh) {
                    child.geometry?.dispose();
                    if (Array.isArray(child.material)) {
                        child.material.forEach(m => m.dispose());
                    } else {
                        child.material?.dispose();
                    }
                }
            });
          }
          if (renderer) {
            renderer.dispose();
            renderer = null; // Ensure renderer is nullified after disposal
          }
          scene = null;
          camera = null;
          earth = null;
          atmosphere = null;
        };

        // Store cleanup function
        mountNode._cleanup = cleanup;

      }).catch((error) => {
        console.error('Failed to load Three.js:', error);
        setError('Failed to initialize 3D graphics. Please refresh the page.');
        setLoadingState('error');
      });

    } catch (error) {
      console.error('Globe initialization error:', error);
      setError('Failed to initialize the globe viewer.');
      setLoadingState('error');
    }

    // Cleanup on unmount (or before re-run)
    return () => {
      if (mountNode && mountNode._cleanup) {
        mountNode._cleanup();
      }
    };
  }, [zoningRules, currentView, checkWebGLSupport, detectPerformanceLevel, performanceMode]);

  const getViewInfo = () => {
    switch (currentView) {
      case 'Planet': return { icon: Globe, label: 'Pristine Earth', color: '#87ceeb', desc: 'Eden State' };
      case 'City': return { icon: Building, label: 'Divine Cities', color: '#98fb98', desc: 'Pre-Fall Harmony' };
      case 'Parcel': return { icon: Navigation, label: 'Sacred Lands', color: '#dda0dd', desc: 'Holy Parcels' };
      case 'Satellite': return { icon: Satellite, label: "God's View", color: '#ffd700', desc: 'Heavenly Perspective' };
      default: return { icon: Globe, label: 'Pristine Earth', color: '#87ceeb', desc: 'Eden State' };
    }
  };

  // Error fallback component
  if (!webGLSupported || error) {
    return (
      <div className="relative w-full h-full rounded-2xl overflow-hidden chrome-surface p-6">
        <Alert className="h-full flex flex-col justify-center">
          <AlertTriangle className="h-8 w-8 mb-4 mx-auto" />
          <AlertDescription className="text-center">
            <div className="font-bold text-lg mb-2">
              {!webGLSupported ? 'WebGL Not Supported' : 'Globe Loading Error'}
            </div>
            <p className="text-sm mb-4">
              {error || 'Your browser does not support 3D graphics required for the pristine globe viewer.'}
            </p>
            <Button 
              onClick={() => {
                setError(null);
                setLoadingState('initializing');
                window.location.reload();
              }}
              className="mx-auto"
            >
              Try Again
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const viewInfo = getViewInfo();
  const ViewIcon = viewInfo.icon;

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden chrome-surface p-2">
      <style jsx>{`
        .pristine-glow {
          box-shadow: 0 0 20px rgba(135, 206, 235, 0.3);
          transition: box-shadow 0.5s ease;
        }
        
        .pristine-glow:hover {
          box-shadow: 0 0 30px rgba(135, 206, 235, 0.5);
        }

        .eden-indicator {
          background: rgba(0, 0, 0, 0.8);
          backdrop-filter: blur(8px);
          border: 1px solid ${viewInfo.color}60;
        }

        @media (max-width: 768px) {
          .eden-indicator {
            font-size: 0.75rem;
            padding: 0.5rem;
          }
        }
      `}</style>

      <div ref={mountRef} className="w-full h-full rounded-lg pristine-glow" />
      
      {/* Responsive Status Indicators */}
      <AnimatePresence>
        {loadingState === 'complete' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute top-2 left-2 sm:top-4 sm:left-4"
          >
            <div className="eden-indicator p-2 sm:p-3 rounded-lg sm:rounded-xl flex items-center gap-2">
              <ViewIcon className="w-4 h-4 sm:w-5 sm:h-5" style={{color: viewInfo.color}} />
              <div className="hidden sm:block">
                <div className="font-bold text-xs sm:text-sm">{viewInfo.label}</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{viewInfo.desc}</div>
              </div>
              <div className="sm:hidden text-xs font-bold">{viewInfo.label}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Performance Indicator */}
      {performanceMode && loadingState === 'complete' && (
        <div className="absolute top-2 right-2 sm:top-4 sm:right-4">
          <Badge 
            variant="outline" 
            className="text-xs eden-indicator border-green-500 text-green-400"
          >
            {performanceMode.toUpperCase()} QUALITY
          </Badge>
        </div>
      )}

      {/* Mobile-friendly Legend */}
      {loadingState === 'complete' && (
        <div className="absolute bottom-2 left-2 sm:bottom-4 sm:left-4">
          <div className="flex flex-wrap gap-1 sm:gap-2 max-w-xs">
            {[
              { icon: Crown, label: 'Eden', color: '#ffd700' },
              { icon: Heart, label: 'Sacred', color: '#ff6b6b' },
              { icon: TreePine, label: 'Nature', color: '#4ade80' },
              { icon: Landmark, label: 'Wonders', color: '#f472b6' },
            ].map(item => (
              <motion.div 
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="eden-indicator px-2 py-1 rounded-lg flex items-center gap-1 text-xs"
              >
                <item.icon className="w-3 h-3" style={{color: item.color}} />
                <span className="hidden sm:inline">{item.label}</span>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Loading States */}
      <AnimatePresence>
        {loadingState !== 'complete' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-orbital-dark/80 backdrop-blur-sm"
          >
            <div className="text-center p-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                className="mb-4 w-16 h-16 mx-auto rounded-full flex items-center justify-center bg-orbital-blue/20"
              >
                 <Loader2 className="w-8 h-8 mx-auto text-orbital-blue animate-spin" style={{animationDuration: '3s'}}/>
              </motion.div>
              <p className="text-lg font-bold mb-2 text-orbital-text">Restoring Paradise...</p>
              <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
                {loadingState === 'initializing' ? 'Initializing divine graphics...' :
                 loadingState === 'loading_assets' ? 'Loading pristine Earth textures...' :
                 `Calibrating quantum layers... ${loadingState}`}
              </p>
              {performanceMode && (
                <Badge className="mt-4" variant="outline" style={{borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)'}}>
                  {performanceMode.toUpperCase()} PERFORMANCE MODE
                </Badge>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
