import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, MapPin, User, DollarSign, Calendar, Hash, Shield, Eye, Download } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const DeedCard = ({ parcel }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatusColor = (status) => {
    switch(status) {
      case 'REGISTERED': return '#22c55e';
      case 'PENDING_TRANSFER': return '#f59e0b';
      case 'ARCHIVED': return '#6b7280';
      default: return 'var(--orbital-blue)';
    }
  };

  const getZoningColor = (type) => {
    const colors = {
      residential: '#22c55e',
      commercial: '#3b82f6',
      industrial: '#f59e0b',
      recreational: '#8b5cf6',
      protected: '#ef4444',
      mixed_use: '#06b6d4'
    };
    return colors[type] || 'var(--orbital-blue)';
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
      className="chrome-surface rounded-2xl overflow-hidden transition-all duration-300"
    >
      <style jsx>{`
        .deed-glow {
          box-shadow: 0 0 20px rgba(0, 212, 255, 0.2), 0 0 40px rgba(0, 212, 255, 0.1);
          animation: deedPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes deedPulse {
          0% { 
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.2), 0 0 40px rgba(0, 212, 255, 0.1);
          }
          100% { 
            box-shadow: 0 0 25px rgba(0, 212, 255, 0.3), 0 0 50px rgba(0, 212, 255, 0.15);
          }
        }

        .notarized-seal {
          background: linear-gradient(45deg, #f59e0b, #fbbf24);
          animation: sealShine 3s ease infinite;
        }

        @keyframes sealShine {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center deed-glow"
                 style={{ background: 'rgba(0, 212, 255, 0.1)', border: '2px solid rgba(0, 212, 255, 0.3)' }}>
              <FileText className="w-6 h-6" style={{ color: 'var(--orbital-blue)' }} />
            </div>
            <div>
              <h3 className="font-bold text-lg" style={{ color: 'var(--orbital-text)' }}>
                DEED #{parcel.nft_token_id || 'UNREGISTERED'}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge 
                  style={{ 
                    background: `${getStatusColor(parcel.deed_status)}20`,
                    color: getStatusColor(parcel.deed_status),
                    border: `1px solid ${getStatusColor(parcel.deed_status)}50`
                  }}
                  className="text-xs"
                >
                  {parcel.deed_status}
                </Badge>
                <Badge 
                  style={{ 
                    background: `${getZoningColor(parcel.zoning_type)}20`,
                    color: getZoningColor(parcel.zoning_type),
                    border: `1px solid ${getZoningColor(parcel.zoning_type)}50`
                  }}
                  className="text-xs"
                >
                  {parcel.zoning_type?.toUpperCase()}
                </Badge>
              </div>
            </div>
          </div>
          
          {parcel.notarized_metadata && (
            <div className="notarized-seal w-8 h-8 rounded-full flex items-center justify-center">
              <Shield className="w-4 h-4 text-black" />
            </div>
          )}
        </div>

        {/* Property Details */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" style={{ color: 'var(--orbital-text-dim)' }} />
            <span className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Coordinates:</span>
            <span className="text-sm font-mono" style={{ color: 'var(--orbital-text)' }}>
              ({parcel.coordinates?.x || 0}, {parcel.coordinates?.y || 0}, {parcel.coordinates?.z || 0})
            </span>
          </div>

          <div className="flex items-center gap-2">
            <User className="w-4 h-4" style={{ color: 'var(--orbital-text-dim)' }} />
            <span className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Owner:</span>
            <span className="text-sm font-mono truncate" style={{ color: 'var(--orbital-text)' }}>
              {parcel.owner_wallet || 'UNREGISTERED'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" style={{ color: 'var(--orbital-text-dim)' }} />
            <span className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Size:</span>
            <span className="text-sm" style={{ color: 'var(--orbital-blue)' }}>
              {parcel.size || 'Unknown'} sq units
            </span>
          </div>
        </div>

        {/* Hotspot Tags */}
        {parcel.hotspot_tags && parcel.hotspot_tags.length > 0 && (
          <div className="mt-4">
            <p className="text-xs font-semibold mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
              ECONOMIC HOTSPOTS:
            </p>
            <div className="flex flex-wrap gap-1">
              {parcel.hotspot_tags.slice(0, 3).map((tag, index) => (
                <Badge 
                  key={index}
                  variant="outline"
                  className="text-xs"
                  style={{ borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)' }}
                >
                  {tag}
                </Badge>
              ))}
              {parcel.hotspot_tags.length > 3 && (
                <Badge 
                  variant="outline"
                  className="text-xs"
                  style={{ borderColor: 'var(--orbital-text-dim)', color: 'var(--orbital-text-dim)' }}
                >
                  +{parcel.hotspot_tags.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Notarization Info - Expanded View */}
        {isExpanded && parcel.notarized_metadata && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 p-4 rounded-xl deed-glow"
            style={{ background: 'rgba(245, 158, 11, 0.1)', border: '1px solid rgba(245, 158, 11, 0.3)' }}
          >
            <h4 className="font-bold mb-3 flex items-center gap-2" style={{ color: '#f59e0b' }}>
              <Shield className="w-4 h-4" />
              NOTARIZATION CERTIFICATE
            </h4>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>Notary ID:</span>
                <span className="text-xs font-mono" style={{ color: 'var(--orbital-text)' }}>
                  {parcel.notarized_metadata.notary_id}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>Notarized:</span>
                <span className="text-xs" style={{ color: 'var(--orbital-text)' }}>
                  {new Date(parcel.notarized_metadata.notarization_date).toLocaleDateString()}
                </span>
              </div>
              
              {parcel.notarized_metadata.previous_owner && (
                <div className="flex justify-between">
                  <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>Previous Owner:</span>
                  <span className="text-xs font-mono" style={{ color: 'var(--orbital-text)' }}>
                    {parcel.notarized_metadata.previous_owner}
                  </span>
                </div>
              )}
              
              <div className="flex items-center gap-2 mt-3">
                <Hash className="w-3 h-3" style={{ color: 'var(--orbital-text-dim)' }} />
                <span className="text-xs font-mono truncate" style={{ color: 'var(--orbital-text-dim)' }}>
                  {parcel.notarized_metadata.transaction_hash}
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Actions */}
      <div className="px-6 pb-6">
        <div className="flex gap-2">
          <Button 
            size="sm" 
            className="flex-1"
            style={{ background: 'var(--orbital-blue)', color: 'var(--orbital-black)' }}
          >
            <Eye className="w-3 h-3 mr-2" />
            View Details
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            className="flex-1 chrome-surface"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? 'Collapse' : 'Expand'}
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            className="chrome-surface"
          >
            <Download className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
};