import React, { useEffect, useRef } from 'react';

export const InteractiveGlobe = () => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const script = document.createElement('script');
    script.type = 'module';
    script.textContent = `
      import createGlobe from 'https://cdn.skypack.dev/cobe';

      let phi = 0;
      let canvas = document.getElementById("cobe-globe");

      if (canvas && !canvas.getAttribute('data-globe-initialized')) {
        canvas.setAttribute('data-globe-initialized', 'true');
        
        const globe = createGlobe(canvas, {
          devicePixelRatio: 2,
          width: 1000,
          height: 1000,
          phi: 0,
          theta: 0,
          dark: 1,
          diffuse: 1.2,
          scale: 1,
          mapSamples: 16000,
          mapBrightness: 6,
          baseColor: [0.3, 0.3, 0.9],
          markerColor: [0.9, 0.5, 1],
          glowColor: [0.2, 0.2, 1],
          offset: [0, 0],
          markers: [
            { location: [37.7595, -122.4367], size: 0.03 },
            { location: [40.7128, -74.006], size: 0.1 },
            { location: [51.5074, -0.1278], size: 0.05 },
            { location: [35.6762, 139.6503], size: 0.05 },
            { location: [22.3193, 114.1694], size: 0.03 },
            { location: [-33.8688, 151.2093], size: 0.03 },
          ],
          onRender: (state) => {
            state.phi = phi;
            phi += 0.005;
          },
        });
      }
    `;
    
    document.body.appendChild(script);

    return () => {
      const scripts = document.querySelectorAll('script[type="module"]');
      scripts.forEach(s => {
        if (s.textContent.includes('createGlobe')) {
          s.remove();
        }
      });
      if (canvas) {
        canvas.removeAttribute('data-globe-initialized');
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="cobe-globe"
      style={{ 
        width: '500px', 
        height: '500px', 
        maxWidth: '100%', 
        aspectRatio: '1 / 1'
      }}
    />
  );
};