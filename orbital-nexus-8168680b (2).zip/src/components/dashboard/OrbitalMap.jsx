import React from 'react';
import { motion } from 'framer-motion';

export const OrbitalMap = () => {
    return (
        <div className="relative w-full h-full min-h-[250px] lg:min-h-full rounded-2xl p-6 flex flex-col justify-between overflow-hidden bg-primary-dark border border-primary-border">
            <style jsx>{`
                .map-bg {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: radial-gradient(ellipse 80% 80% at 50% 50%, transparent, var(--color-primary-dark) 90%);
                    z-index: 1;
                }
                .grid-lines {
                    position: absolute;
                    inset: 0;
                    background-image: 
                        linear-gradient(var(--color-quantum-blue-transparent) 1px, transparent 1px),
                        linear-gradient(90deg, var(--color-quantum-blue-transparent) 1px, transparent 1px);
                    background-size: 50px 50px;
                    mask-image: radial-gradient(ellipse 60% 60% at 50% 50%, black 10%, transparent 80%);
                    animation: pan 60s linear infinite;
                }
                @keyframes pan {
                    0% { background-position: 0 0; }
                    100% { background-position: 500px 500px; }
                }
                .point {
                    position: absolute;
                    width: 8px;
                    height: 8px;
                    background: var(--color-plasma-green);
                    border-radius: 50%;
                    box-shadow: 0 0 8px var(--color-plasma-green);
                    animation: pulse 2s infinite ease-in-out;
                }
                @keyframes pulse {
                    0%, 100% { transform: scale(0.8); opacity: 0.7; }
                    50% { transform: scale(1.2); opacity: 1; }
                }
            `}</style>
            <div className="map-bg"></div>
            <div className="grid-lines"></div>

            <div className="relative z-10">
                <h2 className="text-2xl font-bold text-starlight-white">Stellar Cartography</h2>
                <p className="text-primary-text">Active Worlds and Sub-sector Activity</p>
            </div>

            <div className="relative w-full h-full">
                <motion.div className="point" style={{ top: '30%', left: '40%', animationDelay: '0s' }} />
                <motion.div className="point" style={{ top: '50%', left: '60%', animationDelay: '0.5s', background: 'var(--color-quantum-blue)', boxShadow: '0 0 8px var(--color-quantum-blue)' }} />
                <motion.div className="point" style={{ top: '65%', left: '35%', animationDelay: '1s' }} />
                <motion.div className="point" style={{ top: '45%', left: '20%', animationDelay: '1.5s', background: 'var(--color-highlight-yellow)', boxShadow: '0 0 8px var(--color-highlight-yellow)' }} />
            </div>

            <div className="relative z-10 text-right">
                <span className="text-xs px-2 py-1 rounded-full bg-primary-dark/70 border border-primary-border">Sector 7G / Real-time Feed</span>
            </div>
        </div>
    );
};