
import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Cycle 1', value: 4000 },
  { name: 'Cycle 2', value: 3000 },
  { name: 'Cycle 3', value: 2000 },
  { name: 'Cycle 4', value: 2780 },
  { name: 'Cycle 5', value: 1890 },
  { name: 'Cycle 6', value: 2390 },
  { name: 'Cycle 7', value: 3490 },
  { name: 'Cycle 8 (Pred)', value: 4100, predicted: true },
  { name: 'Cycle 9 (Pred)', value: 4500, predicted: true },
];

export const PredictiveChart = () => (
  <motion.div 
    className="w-full h-96 chrome-surface rounded-2xl p-4"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 212, 255, 0.2)" />
        <XAxis dataKey="name" stroke="var(--orbital-text-dim)" />
        <YAxis stroke="var(--orbital-text-dim)" />
        <Tooltip contentStyle={{ background: 'var(--orbital-surface)', border: '1px solid var(--sidebar-border)' }} />
        <Legend />
        <Line type="monotone" dataKey="value" stroke="var(--orbital-blue)" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 8 }} />
        <Line type="monotone" dataKey="predicted" stroke="var(--orbital-blue)" strokeWidth={2} strokeDasharray="5 5" />
      </LineChart>
    </ResponsiveContainer>
  </motion.div>
);
