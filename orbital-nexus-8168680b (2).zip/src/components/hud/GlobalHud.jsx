import React, { useState } from 'react';
import { MapPin, Flame, List, ChevronUp, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const GlobalHud = ({ locations, alerts, onSelectLocation }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [activeTab, setActiveTab] = useState('locations');

  return (
    <motion.div 
      className="absolute bottom-4 left-4 right-4 text-white"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 100 }}
    >
      <div className="bg-black/70 backdrop-blur-md rounded-2xl border border-blue-500/50 shadow-2xl shadow-blue-500/20 overflow-hidden">
        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button 
              className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${activeTab === 'locations' ? 'bg-blue-600' : 'bg-transparent hover:bg-blue-500/20'}`}
              onClick={() => setActiveTab('locations')}
            >
              <MapPin className="w-4 h-4" /> Locations ({locations.length})
            </button>
            <button 
              className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${activeTab === 'alerts' ? 'bg-red-600' : 'bg-transparent hover:bg-red-500/20'}`}
              onClick={() => setActiveTab('alerts')}
            >
              <Flame className="w-4 h-4" /> Fire Alerts ({alerts.length})
            </button>
          </div>
          <button onClick={() => setIsMinimized(!isMinimized)} className="p-2 hover:bg-white/10 rounded-full">
            {isMinimized ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>
        </div>
        
        <AnimatePresence>
          {!isMinimized && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="p-4 border-t border-blue-500/30 max-h-60 overflow-y-auto">
                {activeTab === 'locations' && (
                  <ul className="space-y-2">
                    {locations.map(loc => (
                      <li key={loc.id} className="p-3 bg-white/5 rounded-lg flex justify-between items-center cursor-pointer hover:bg-blue-500/20" onClick={() => onSelectLocation(loc)}>
                        <div>
                          <p className="font-semibold">{loc.name}</p>
                          <p className="text-xs text-gray-400">{loc.address}</p>
                        </div>
                        <span className="text-xs font-mono">{loc.latitude.toFixed(2)}, {loc.longitude.toFixed(2)}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {activeTab === 'alerts' && (
                  <ul className="space-y-2">
                    {alerts.slice(0, 100).map((alert, i) => (
                      <li key={i} className="p-3 bg-red-900/20 rounded-lg flex justify-between items-center cursor-pointer hover:bg-red-500/20" onClick={() => onSelectLocation(alert)}>
                         <div>
                          <p className="font-semibold">NASA VIIRS Fire Alert</p>
                          <p className="text-xs text-gray-400">Brightness: {alert.bright_ti4}K, Confidence: {alert.confidence}</p>
                        </div>
                        <span className="text-xs font-mono">{alert.latitude.toFixed(2)}, {alert.longitude.toFixed(2)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default GlobalHud;