import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Eye, AlertTriangle, CheckCircle, Activity, Key } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const SecurityDashboard = () => {
  const [threatLevel, setThreatLevel] = useState('MINIMAL');
  const [activeScans, setActiveScans] = useState(47);

  const securityMetrics = [
    { title: 'Quantum Encryption Status', value: 'PQC-KYBER-1024', status: 'active', icon: Lock },
    { title: 'AI Threat Detection', value: '99.97% Accuracy', status: 'active', icon: Eye },
    { title: 'Active Sentries', value: `${activeScans}/50`, status: 'active', icon: Shield },
    { title: 'Breach Attempts (24h)', value: '0', status: 'secure', icon: AlertTriangle },
  ];

  const recentLogs = [
    { time: '14:32:07', event: 'Access granted to ARIA (AI Avatar)', severity: 'info' },
    { time: '14:28:15', event: 'Security scan completed - Sector 7G', severity: 'success' },
    { time: '14:20:43', event: 'Failed login attempt blocked', severity: 'warning' },
    { time: '14:15:22', event: 'Quantum key rotation successful', severity: 'info' },
    { time: '14:12:01', event: 'Perimeter scan initiated', severity: 'info' },
  ];

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'success': return '#22c55e';
      case 'warning': return '#f59e0b';
      case 'error': return '#ef4444';
      default: return 'var(--orbital-blue)';
    }
  };

  return (
    <div className="space-y-6">
      {/* Security Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {securityMetrics.map((metric, index) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="chrome-surface rounded-xl p-4 text-center"
          >
            <metric.icon className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--orbital-blue)' }} />
            <h3 className="font-semibold text-sm mb-1" style={{ color: 'var(--orbital-text-dim)' }}>
              {metric.title}
            </h3>
            <p className="font-bold" style={{ color: 'var(--orbital-text)' }}>{metric.value}</p>
            <Badge 
              className="mt-2 text-xs"
              style={{ 
                background: metric.status === 'active' ? 'var(--orbital-blue-dim)' : '#22c55e20',
                color: metric.status === 'active' ? 'var(--orbital-blue)' : '#22c55e' 
              }}
            >
              {metric.status.toUpperCase()}
            </Badge>
          </motion.div>
        ))}
      </div>

      {/* Threat Level Display */}
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
            <Shield className="w-5 h-5" style={{ color: 'var(--orbital-blue)' }} />
            ORBITAL SECURITY STATUS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <div className="w-32 h-32 mx-auto mb-4 rounded-full flex items-center justify-center glow-blue" 
                 style={{ background: 'rgba(0, 212, 255, 0.1)', border: '2px solid var(--orbital-blue)' }}>
              <CheckCircle className="w-16 h-16" style={{ color: 'var(--orbital-blue)' }} />
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: 'var(--orbital-blue)' }}>
              ALL SYSTEMS SECURE
            </h2>
            <p className="text-lg" style={{ color: 'var(--orbital-text)' }}>
              Threat Level: <span style={{ color: '#22c55e' }}>{threatLevel}</span>
            </p>
            <p className="text-sm mt-2" style={{ color: 'var(--orbital-text-dim)' }}>
              Quantum-grade protection active across all vectors
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Security Logs */}
      <Card className="chrome-surface">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
              <Activity className="w-5 h-5" style={{ color: 'var(--orbital-blue)' }} />
              REAL-TIME SECURITY LOGS
            </CardTitle>
            <Button variant="outline" size="sm" className="chrome-surface">
              <Key className="w-4 h-4 mr-2" />
              Export Logs
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {recentLogs.map((log, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center gap-3 p-3 rounded-lg"
                style={{ background: 'rgba(0, 212, 255, 0.05)', border: '1px solid rgba(0, 212, 255, 0.1)' }}
              >
                <div 
                  className="w-2 h-2 rounded-full"
                  style={{ background: getSeverityColor(log.severity) }}
                />
                <span className="text-sm font-mono" style={{ color: 'var(--orbital-text-dim)' }}>
                  {log.time}
                </span>
                <span className="text-sm flex-grow" style={{ color: 'var(--orbital-text)' }}>
                  {log.event}
                </span>
                <Badge 
                  variant="outline" 
                  className="text-xs"
                  style={{ 
                    borderColor: getSeverityColor(log.severity),
                    color: getSeverityColor(log.severity)
                  }}
                >
                  {log.severity.toUpperCase()}
                </Badge>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};