import React, { useEffect, useRef } from 'react';

const CesiumViewer = ({ locations, alerts, targetLocation }) => {
  const cesiumContainer = useRef(null);
  const viewerRef = useRef(null);

  useEffect(() => {
    if (window.Cesium && cesiumContainer.current && !viewerRef.current) {
      const viewer = new window.Cesium.Viewer(cesiumContainer.current, {
        animation: false,
        baseLayerPicker: false,
        fullscreenButton: false,
        geocoder: false,
        homeButton: false,
        infoBox: false,
        sceneModePicker: false,
        selectionIndicator: false,
        timeline: false,
        navigationHelpButton: false,
        imageryProvider: new window.Cesium.UrlTemplateImageryProvider({
          url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
          credit: 'Tiles © Esri'
        }),
      });
      viewer.scene.globe.enableLighting = true;
      viewerRef.current = viewer;
    }

    return () => {
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (viewerRef.current) {
      const viewer = viewerRef.current;
      viewer.entities.removeAll(); // Clear previous entities

      // Add business locations
      locations.forEach(loc => {
        viewer.entities.add({
          position: window.Cesium.Cartesian3.fromDegrees(loc.longitude, loc.latitude),
          point: {
            pixelSize: 8,
            color: window.Cesium.Color.fromCssColorString('#4c4ce6'),
            outlineColor: window.Cesium.Color.WHITE,
            outlineWidth: 2,
          },
          label: {
            text: loc.name,
            font: '12pt monospace',
            style: window.Cesium.LabelStyle.FILL_AND_OUTLINE,
            outlineWidth: 2,
            verticalOrigin: window.Cesium.VerticalOrigin.BOTTOM,
            pixelOffset: new window.Cesium.Cartesian2(0, -9),
          },
          description: `<h3>${loc.name}</h3><p>${loc.address}</p>`
        });
      });

      // Add NASA fire alerts
      alerts.forEach(alert => {
        viewer.entities.add({
          position: window.Cesium.Cartesian3.fromDegrees(alert.longitude, alert.latitude),
          point: {
            pixelSize: 6,
            color: window.Cesium.Color.RED,
          },
        });
      });
    }
  }, [locations, alerts]);

  useEffect(() => {
    if (viewerRef.current && targetLocation) {
      viewerRef.current.camera.flyTo({
        destination: window.Cesium.Cartesian3.fromDegrees(
          targetLocation.longitude,
          targetLocation.latitude,
          10000 // height in meters
        ),
        duration: 2.0,
      });
    }
  }, [targetLocation]);

  return <div ref={cesiumContainer} className="w-full h-full" />;
};

export default CesiumViewer;