import React from 'react';
import { AlertTriangle, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    // In a real application, you would log this to an error reporting service
    console.error("ORBITAL Self-Healing UX :: Error Caught:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full p-8" style={{background: 'var(--orbital-dark)', color: 'var(--orbital-text)'}}>
          <AlertTriangle className="w-16 h-16 text-red-500 mb-6" />
          <h1 className="text-3xl font-bold mb-2">SYSTEM ANOMALY DETECTED</h1>
          <p className="text-lg" style={{color: 'var(--orbital-text-dim)'}}>
            The Inspector AI has detected a temporal instability in this module.
          </p>
          <p className="mb-6" style={{color: 'var(--orbital-text-dim)'}}>
            Self-healing protocols have been engaged.
          </p>
          <Button 
            onClick={() => window.location.reload()}
            className="font-bold glow-blue"
            style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
          >
            <Shield className="w-4 h-4 mr-2" />
            Engage Manual Restore
          </Button>
          <details className="mt-8 text-xs p-4 rounded-lg chrome-surface w-full max-w-2xl">
            <summary className="cursor-pointer font-medium" style={{color: 'var(--orbital-text-dim)'}}>View Anomaly Details</summary>
            <pre className="mt-4 p-2 bg-black rounded whitespace-pre-wrap">
              {this.state.error && this.state.error.toString()}
              <br />
              {this.state.errorInfo && this.state.errorInfo.componentStack}
            </pre>
          </details>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;