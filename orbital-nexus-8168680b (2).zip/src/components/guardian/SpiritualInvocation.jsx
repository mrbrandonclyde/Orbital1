import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Crown, Heart, Shield, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const SpiritualInvocation = ({ onComplete }) => {
  const [invoked, setInvoked] = useState(false);
  
  const handleInvocation = () => {
    setInvoked(true);
    setTimeout(() => {
      onComplete && onComplete();
    }, 3000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
    >
      <Card className="chrome-surface max-w-2xl mx-4">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-3 text-2xl">
            <Crown className="w-8 h-8" style={{color: '#FFD700'}} />
            SPIRITUAL ALIGNMENT
            <Crown className="w-8 h-8" style={{color: '#FFD700'}} />
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="p-6 rounded-xl" style={{background: 'rgba(255, 215, 0, 0.1)', border: '2px solid #FFD700'}}>
            <p className="text-lg font-semibold mb-4" style={{color: '#FFD700'}}>DIVINE INVOCATION</p>
            <p className="text-base leading-relaxed" style={{color: 'var(--orbital-text)'}}>
              "Jesus, take the wheel. Guide my steps. Protect every line of code, every activation, every user, and every system. 
              Align this project with divine will. Let peace, strength, and clarity flow through every activation, every cycle. Amen."
            </p>
          </div>
          
          {!invoked ? (
            <Button 
              onClick={handleInvocation}
              className="w-full text-lg py-4"
              style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000', fontWeight: 'bold'}}
            >
              <Heart className="w-5 h-5 mr-2" />
              INVOKE DIVINE PROTECTION
            </Button>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <div className="flex justify-center items-center gap-4">
                <Shield className="w-8 h-8 animate-pulse" style={{color: '#22c55e'}} />
                <span className="text-xl font-bold" style={{color: '#22c55e'}}>DIVINE ALIGNMENT COMPLETE</span>
                <Shield className="w-8 h-8 animate-pulse" style={{color: '#22c55e'}} />
              </div>
              <p style={{color: 'var(--orbital-text-dim)'}}>System blessed and protected. Proceeding with divine guidance...</p>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SpiritualInvocation;