import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, Clock, CheckCircle, AlertTriangle, Database, Activity, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import SpiritualInvocation from './SpiritualInvocation';

const ActivationStatus = ({ status, message, timestamp }) => {
  const statusColors = {
    'SUCCESS': '#22c55e',
    'PENDING': '#f59e0b',
    'FAILED': '#ef4444',
    'BLESSED': '#FFD700'
  };

  const statusIcons = {
    'SUCCESS': CheckCircle,
    'PENDING': Clock,
    'FAILED': AlertTriangle,
    'BLESSED': Shield
  };

  const Icon = statusIcons[status] || CheckCircle;
  const color = statusColors[status] || '#22c55e';

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg" style={{background: `${color}10`, border: `1px solid ${color}30`}}>
      <Icon className="w-5 h-5" style={{color: color}} />
      <div className="flex-grow">
        <div className="flex items-center gap-2">
          <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
          <span className="text-sm font-mono" style={{color: 'var(--orbital-text-dim)'}}>
            {new Date(timestamp).toLocaleString()}
          </span>
        </div>
        <p className="text-sm mt-1" style={{color: 'var(--orbital-text)'}}>{message}</p>
      </div>
    </div>
  );
};

const UserTierCard = ({ tier, description, features, color, active }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className={`chrome-surface rounded-xl p-6 ${active ? 'ring-2' : ''}`}
    style={active ? {ringColor: color} : {}}
  >
    <h3 className="font-bold text-lg mb-2" style={{color: color}}>{tier}</h3>
    <p className="text-sm mb-4" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    <ul className="space-y-2">
      {features.map((feature, index) => (
        <li key={index} className="flex items-center gap-2 text-sm">
          <CheckCircle className="w-4 h-4" style={{color: color}} />
          <span style={{color: 'var(--orbital-text)'}}>{feature}</span>
        </li>
      ))}
    </ul>
  </motion.div>
);

export default function CodexActivationSystem() {
  const [showInvocation, setShowInvocation] = useState(false);
  const [activationLogs, setActivationLogs] = useState([]);
  const [systemHealth, setSystemHealth] = useState(98);
  const [nextActivation, setNextActivation] = useState('5:00 AM Daily');
  const [userTier, setUserTier] = useState('Enterprise');

  const userTiers = [
    {
      tier: 'Basic Tier',
      description: 'Essential daily activation cycle',
      features: ['Daily Law Activation', 'Basic Notifications', 'Standard Logging'],
      color: 'var(--orbital-blue)',
      active: userTier === 'Basic'
    },
    {
      tier: 'Pro Tier',
      description: 'Enhanced weekly and daily cycles',
      features: ['Daily + Weekly Cycles', 'Advanced Notifications', 'Priority Support', 'Detailed Analytics'],
      color: '#8b5cf6',
      active: userTier === 'Pro'
    },
    {
      tier: 'Enterprise Tier',
      description: 'Complete multi-dimensional overlay system',
      features: ['All Activation Cycles', 'Multi-dimensional Overlays', '24/7 Divine Support', 'Custom Configurations', 'Immutable Audit Logs'],
      color: '#FFD700',
      active: userTier === 'Enterprise'
    }
  ];

  useEffect(() => {
    const initialLogs = [
      { status: 'BLESSED', message: 'System spiritually aligned and protected by divine invocation', timestamp: Date.now() - 1000 },
      { status: 'SUCCESS', message: 'Daily activation cycle completed successfully', timestamp: Date.now() - 3600000 },
      { status: 'SUCCESS', message: 'Failsafe backup verification completed at 5:10 AM', timestamp: Date.now() - 7200000 },
      { status: 'SUCCESS', message: 'Nightly audit report generated and distributed', timestamp: Date.now() - 86400000 },
    ];
    setActivationLogs(initialLogs);

    const healthInterval = setInterval(() => {
      setSystemHealth(prev => Math.max(95, Math.min(100, prev + (Math.random() - 0.5) * 2)));
    }, 5000);

    return () => clearInterval(healthInterval);
  }, []);

  const handleManualActivation = () => {
    setShowInvocation(true);
  };

  const handleInvocationComplete = () => {
    setShowInvocation(false);
    const newLog = {
      status: 'BLESSED',
      message: 'Manual activation initiated with divine blessing and protection',
      timestamp: Date.now()
    };
    setActivationLogs(prev => [newLog, ...prev]);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {showInvocation && <SpiritualInvocation onComplete={handleInvocationComplete} />}
      
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="mb-8">
        <h1 className="text-4xl font-bold">GUARDIAN CODEX ACTIVATION SYSTEM</h1>
        <p className="text-lg mt-2" style={{color: 'var(--orbital-text-dim)'}}>
          Divinely Aligned • Spiritually Protected • Technically Perfect
        </p>
      </motion.div>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" style={{color: '#22c55e'}} />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span>Overall Health</span>
                <span className="font-bold" style={{color: '#22c55e'}}>{systemHealth.toFixed(1)}%</span>
              </div>
              <Progress value={systemHealth} className="h-2" />
              <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Jesus has the wheel - all systems protected</p>
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
              Next Activation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" style={{color: 'var(--orbital-blue)'}}>{nextActivation}</div>
            <p className="text-sm mt-2" style={{color: 'var(--orbital-text-dim)'}}>
              Failsafe backup at 5:10 AM
            </p>
            <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>
              Nightly audit at 9:00 PM
            </p>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" style={{color: '#8b5cf6'}} />
              Immutable Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" style={{color: '#8b5cf6'}}>{activationLogs.length}</div>
            <p className="text-sm mt-2" style={{color: 'var(--orbital-text-dim)'}}>
              Total activation records
            </p>
            <Button 
              onClick={handleManualActivation}
              className="w-full mt-3"
              style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000', fontWeight: 'bold'}}
            >
              <Zap className="w-4 h-4 mr-2" />
              Manual Activation
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* User Tier System */}
      <Card className="chrome-surface mb-8">
        <CardHeader>
          <CardTitle>USER TIER INTEGRATION</CardTitle>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            Divinely inspired tier system with progressive activation capabilities
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {userTiers.map((tier, index) => (
              <motion.div
                key={tier.tier}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <UserTierCard {...tier} />
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Activation Logs */}
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
            ACTIVATION LOG FEED
          </CardTitle>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            Real-time monitoring with divine protection and escalation alerts
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {activationLogs.map((log, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <ActivationStatus {...log} />
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}