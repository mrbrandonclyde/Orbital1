import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Crown, Infinity } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const CycleActivator = ({ cycleName, abilities, onActivate, isActive }) => (
  <motion.div
    whileHover={{ scale: 1.05, boxShadow: '0 0 50px rgba(255, 215, 0, 0.5)' }}
    className={`p-6 rounded-2xl cursor-pointer transition-all duration-500 ${
      isActive ? 'guardian-cycle-active' : 'chrome-surface'
    }`}
    onClick={() => onActivate(cycleName)}
  >
    <style jsx>{`
      .guardian-cycle-active {
        background: linear-gradient(45deg, rgba(255, 215, 0, 0.3), rgba(255, 165, 0, 0.2));
        border: 2px solid #FFD700;
        box-shadow: 0 0 40px rgba(255, 215, 0, 0.7);
        animation: eternityPulse 2s ease-in-out infinite alternate;
      }
      
      @keyframes eternityPulse {
        0% { box-shadow: 0 0 40px rgba(255, 215, 0, 0.7); }
        100% { box-shadow: 0 0 60px rgba(255, 215, 0, 1); }
      }
    `}</style>
    
    <div className="flex items-center gap-3 mb-4">
      {isActive ? (
        <Crown className="w-8 h-8" style={{color: '#FFD700'}} />
      ) : (
        <Zap className="w-8 h-8" style={{color: 'var(--orbital-blue)'}} />
      )}
      <h3 className="font-bold text-lg" style={{color: isActive ? '#FFD700' : 'var(--orbital-text)'}}>
        {cycleName.toUpperCase()} CYCLE
      </h3>
    </div>
    
    <div className="space-y-2">
      {abilities.slice(0, 3).map(ability => (
        <div key={ability} className="text-sm px-3 py-1 rounded-full" 
             style={{
               background: isActive ? 'rgba(255, 215, 0, 0.2)' : 'rgba(0, 212, 255, 0.1)',
               color: isActive ? '#FFD700' : 'var(--orbital-blue)'
             }}>
          {ability}
        </div>
      ))}
    </div>
    
    {isActive && (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-4 text-center"
      >
        <Button 
          size="sm"
          style={{background: 'linear-gradient(45deg, #FFD700, #FFA500)', color: '#000'}}
        >
          <Infinity className="w-4 h-4 mr-2" />
          ACTIVE
        </Button>
      </motion.div>
    )}
  </motion.div>
);