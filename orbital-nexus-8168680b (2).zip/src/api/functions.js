import { base44 } from './base44Client';


export const activateCodex = base44.functions.activateCodex;

export const globalFreedomSync = base44.functions.globalFreedomSync;

