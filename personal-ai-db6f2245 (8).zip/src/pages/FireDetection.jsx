
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { themes } from "@/components/theme";
import { Flame, Shield, TrendingUp, Cpu, Server, AlertTriangle, Loader2, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { getNasaFireData } from "@/api/functions";
import { Button } from "@/components/ui/button";
import FireGlobeVR from "@/components/vr/FireGlobeVR";

const FireAlertPanel = ({ alerts }) => {
    const sortedAlerts = [...alerts].sort((a,b) => b.confidence - a.confidence).slice(0,5);

    const riskColorClass = {
        HIGH: "text-red-400",
        MEDIUM: "text-yellow-400",
        LOW: "text-green-400"
    }

    return (
        <div className="bg-black/50 backdrop-blur-xl border border-orange-500/30 shadow-[0_0_35px_rgba(249,115,22,0.3)] rounded-xl p-6 h-full">
            <h3 className="text-orange-400 font-bold mb-2 flex items-center gap-2 text-lg">
                🔥 Top 5 Active Alerts
            </h3>
            <p className="text-sm text-gray-300 mb-4">
                Highest confidence global wildfire detections from NASA FIRMS.
            </p>
            <ul className="space-y-3 text-sm text-gray-200">
                {sortedAlerts.map((alert) => (
                <li key={alert.id} className="p-3 rounded-md bg-black/40 flex justify-between items-center border border-gray-700/50">
                    <span>Lat: {alert.lat.toFixed(2)}, Lon: {alert.lon.toFixed(2)}</span>
                    <span className={`${riskColorClass[alert.risk]} font-bold uppercase`}>{alert.risk} ({alert.confidence}%)</span>
                </li>
                ))}
            </ul>
        </div>
    );
};

const StatCard = ({ title, value, icon, color }) => {
    const Icon = icon;
    return (
        <div className={`p-4 rounded-lg bg-black/40 border border-gray-700/50`}>
            <div className="flex items-center gap-4">
                <Icon className={`w-8 h-8 ${color}`} />
                <div>
                    <p className="text-2xl font-bold text-white">{value}</p>
                    <p className="text-sm text-gray-400">{title}</p>
                </div>
            </div>
        </div>
    )
}

export default function FireDetectionPage() {
    const [currentUser, setCurrentUser] = useState(null);
    const [fireAlerts, setFireAlerts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const theme = themes.orbital;

    useEffect(() => {
        loadCurrentUser();
        fetchFireData();
    }, []);

    const fetchFireData = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const { data, error: apiError } = await getNasaFireData();
            if (apiError || !data) {
              throw new Error(apiError?.message || 'Failed to fetch fire data');
            }
            setFireAlerts(data);
        } catch (err) {
            setError(err.message);
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const loadCurrentUser = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
        } catch (error) {
            console.log('User not authenticated');
        }
    };
    
    const handleUserUpdate = (updatedUserData) => {
        setCurrentUser(prevUser => ({...prevUser, ...updatedUserData}));
    }

    const renderContent = () => {
      if(isLoading) {
        return (
          <div className="flex flex-col items-center justify-center h-[600px] text-cyan-300">
            <Loader2 className="w-16 h-16 animate-spin mb-4" />
            <p className="text-lg">Fetching live data from NASA satellites...</p>
          </div>
        )
      }

      if(error) {
        return (
           <div className="flex flex-col items-center justify-center h-[600px] text-red-400 bg-red-500/10 rounded-xl">
            <AlertTriangle className="w-16 h-16 mb-4" />
            <p className="text-lg font-semibold">Error Fetching Fire Data</p>
            <p className="text-sm mb-4">{error}</p>
            <Button onClick={fetchFireData} variant="outline" className="text-red-300 border-red-300/50 hover:bg-red-400/20 hover:text-red-200">
                <RefreshCw className="w-4 h-4 mr-2"/> Retry
            </Button>
          </div>
        )
      }

      return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 h-[600px] flex items-center justify-center">
                <FireGlobeVR alerts={fireAlerts} currentUser={currentUser} onUserUpdate={handleUserUpdate} />
            </div>
            <div className="space-y-6">
                <FireAlertPanel alerts={fireAlerts} />
                <div className="grid grid-cols-2 gap-4">
                    <StatCard title="Active Hotspots" value={fireAlerts.length} icon={TrendingUp} color="text-green-400" />
                    <StatCard title="Highest Confidence" value={`${Math.max(...fireAlerts.map(a => a.confidence), 0)}%`} icon={Cpu} color="text-yellow-400" />
                </div>
            </div>
        </div>
      )
    }

    return (
        <div className={`h-full min-h-0 overflow-y-auto p-8 ${theme.background}`}>
            <div className={`p-6 ${theme.panel} border-b border-orange-500/30 mb-8 rounded-t-xl`}>
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center border border-orange-400/30`}>
                            <Flame className={`w-6 h-6 text-orange-300`} />
                        </div>
                        <div>
                            <h1 className={`text-2xl font-bold text-white`}>
                                Global Fire Monitoring
                            </h1>
                            <p className={`${theme.textSecondary} text-sm`}>
                                Real-time wildfire detection and risk analysis powered by NASA FIRMS. Click fires to extinguish with orbital lasers.
                            </p>
                        </div>
                    </div>
                     {currentUser && (
                        <div className={`rounded-lg px-4 py-2 flex items-center gap-2 blue-glow-panel bg-black/30`}>
                            <Shield className={`w-4 h-4 ${theme.textSecondary}`} />
                            <span className={theme.textSecondary}>Trust:</span>
                            <span className={`font-bold text-blue-300`}>{currentUser.trust_score || 87}/100</span>
                        </div>
                    )}
                </div>
            </div>
            
            {renderContent()}
        </div>
    );
}
