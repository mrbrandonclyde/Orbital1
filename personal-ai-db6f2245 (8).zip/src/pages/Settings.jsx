
import React, { useState, useEffect } from "react";
import { UserSettings } from "@/api/entities";
import { AIModel } from "@/api/entities";
import { OpenAIKey } from "@/api/entities"; // Use the actual entity
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Bot, Check, Loader2, Key, Shield, Brain, Settings as SettingsIcon, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { TrustScoreIndicator, BiometricStatus, PersonalityProfile, ModeSelector } from "@/components/identity/IdentityCore";
import { User } from "@/api/entities";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";

const OpenAIKeyManager = () => {
  const [keys, setKeys] = useState([]);
  const [isKeyDialogOpen, setIsKeyDialogOpen] = useState(false);
  const [editingKey, setEditingKey] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    setIsLoading(true);
    // Use the real OpenAIKey entity to list keys
    const keyList = await OpenAIKey.list();
    setKeys(keyList);
    setIsLoading(false);
  };

  const handleOpenKeyDialog = (key = null) => {
    setEditingKey(key);
    setIsKeyDialogOpen(true);
  };

  const handleDeleteKey = async (keyId) => {
    if (confirm("Are you sure you want to delete this API key? This action cannot be undone.")) {
      // Use the real OpenAIKey entity to delete
      await OpenAIKey.delete(keyId);
      loadKeys();
    }
  };

  const handleToggleKeyActive = async (keyId, isActive) => {
    await OpenAIKey.update(keyId, { is_active: isActive });
    loadKeys();
  };

  const KeyForm = ({ key: initialKey, onFinished }) => {
    const [formData, setFormData] = useState(
      initialKey || { name: '', api_key: '', is_active: false }
    );
    const [isSaving, setIsSaving] = useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsSaving(true);
      try {
        if (initialKey?.id) {
          // Use the real OpenAIKey entity to update
          await OpenAIKey.update(initialKey.id, formData);
        } else {
          // Use the real OpenAIKey entity to create
          await OpenAIKey.create(formData);
        }
        onFinished();
      } catch (error) {
        console.error('Error saving key:', error);
      } finally {
        setIsSaving(false);
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="keyName" className="text-cyan">Key Name</Label>
          <Input 
            id="keyName" 
            value={formData.name} 
            onChange={e => setFormData({...formData, name: e.target.value})} 
            placeholder="e.g., Primary OpenAI Key"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="keyValue" className="text-cyan">API Key</Label>
          <Input 
            id="keyValue" 
            type="password" 
            value={formData.api_key} 
            onChange={e => setFormData({...formData, api_key: e.target.value})} 
            placeholder="sk-..." 
            required
          />
          <p className="text-xs text-silver/70">The key will be encrypted and stored securely.</p>
        </div>
        <div className="flex items-center space-x-3">
          <Switch
            id="isActive"
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
          />
          <Label htmlFor="isActive" className="text-silver">Set as Active Key</Label>
        </div>
        <div className="flex justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onFinished} className="border-silver/30 text-silver hover:bg-silver/10">
            Cancel
          </Button>
          <Button type="submit" disabled={isSaving} className="btn-cyan">
            {isSaving && <Loader2 className="w-4 h-4 animate-spin mr-2"/>}
            {initialKey?.id ? 'Update Key' : 'Add Key'}
          </Button>
        </div>
      </form>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-cyan animate-spin" />
      </div>
    );
  }

  return (
    <>
      <div className="flex justify-end mb-6">
        <Button onClick={() => handleOpenKeyDialog()} className="btn-cyan">
          <Plus className="w-4 h-4 mr-2"/> Add New Key
        </Button>
      </div>

      <div className="space-y-4">
        <AnimatePresence>
          {keys.length > 0 ? (
            keys.map(key => (
              <motion.div
                key={key.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <Card className="superman-card hover:cyan-glow transition-all duration-300">
                  <CardContent className="p-6 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg gold-glow">
                        <Key className="w-6 h-6 text-gold" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-silver">{key.name}</h3>
                        <div className="flex items-center gap-3 mt-1">
                          {key.is_active ? (
                            <Badge className="bg-kryptonite/20 text-kryptonite border border-kryptonite/30 font-medium">
                              <Check className="w-3 h-3 mr-1"/> Active
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="border-silver/30 text-silver/70">
                              Inactive
                            </Badge>
                          )}
                          <span className="text-sm text-silver/60">
                            Key: {key.api_key.substring(0, 7)}...{key.api_key.substring(key.api_key.length - 4)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleOpenKeyDialog(key)} className="text-silver hover:text-cyan">
                        <Edit className="w-4 h-4"/>
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteKey(key.id)} className="text-silver hover:text-crimson">
                        <Trash2 className="w-4 h-4"/>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16"
            >
              <Card className="superman-card max-w-md mx-auto">
                <CardContent className="p-8">
                  <div className="w-16 h-16 gold-glow rounded-full flex items-center justify-center mx-auto mb-4">
                    <Key className="w-8 h-8 text-gold" />
                  </div>
                  <h3 className="text-xl font-semibold text-silver mb-2">No API Keys Added</h3>
                  <p className="text-silver/70 mb-6 leading-relaxed">Add your OpenAI API keys to enable advanced AI functionalities.</p>
                  <Button onClick={() => handleOpenKeyDialog()} className="btn-cyan">
                    <Plus className="w-4 h-4 mr-2"/> Add Your First Key
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Dialog open={isKeyDialogOpen} onOpenChange={setIsKeyDialogOpen}>
        <DialogContent className="obsidian-panel max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gold">{editingKey ? 'Edit API Key' : 'Add New API Key'}</DialogTitle>
          </DialogHeader>
          <KeyForm key={editingKey?.id} initialKey={editingKey} onFinished={() => { setIsKeyDialogOpen(false); loadKeys(); }}/>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default function SettingsPage() {
  const [userSettings, setUserSettings] = useState(null);
  const [models, setModels] = useState([]);
  const [isModelDialogOpen, setIsModelDialogOpen] = useState(false);
  const [editingModel, setEditingModel] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
    loadCurrentUser();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const settingsList = await UserSettings.list();
      setUserSettings(settingsList[0] || await UserSettings.create({}));
      const modelList = await AIModel.list();
      setModels(modelList);
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error);
    }
  };

  const handleSetActiveModel = async (modelId) => {
    if (userSettings) {
      await UserSettings.update(userSettings.id, { active_model_id: modelId });
      loadData();
    }
  };
  
  const handleDeleteModel = async (modelId) => {
    if (userSettings?.active_model_id === modelId) {
      alert("Cannot delete the active model. Please set another model as active first.");
      return;
    }
    if (confirm("Are you sure you want to delete this AI agent? This action cannot be undone.")) {
      await AIModel.delete(modelId);
      loadData();
    }
  };

  const handleOpenModelDialog = (model = null) => {
    setEditingModel(model);
    setIsModelDialogOpen(true);
  };
  
  const ModelForm = ({ model, onFinished }) => {
    const [formData, setFormData] = useState(
      model || { name: '', description: '', system_prompt: '', avatar_style: 'professional' }
    );
    const [isSaving, setIsSaving] = useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsSaving(true);
      try {
        if (model?.id) {
          await AIModel.update(model.id, formData);
        } else {
          await AIModel.create(formData);
        }
        onFinished();
      } catch (error) {
        console.error('Error saving model:', error);
      } finally {
        setIsSaving(false);
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-cyan">Agent Name</Label>
          <Input 
            id="name" 
            value={formData.name} 
            onChange={e => setFormData({...formData, name: e.target.value})} 
            placeholder="e.g., Creative Writer"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="description" className="text-cyan">Description</Label>
          <Input 
            id="description" 
            value={formData.description} 
            onChange={e => setFormData({...formData, description: e.target.value})} 
            placeholder="Specializes in marketing copy and creative content"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="avatar_style" className="text-cyan">Avatar Style</Label>
          <Select value={formData.avatar_style} onValueChange={v => setFormData({...formData, avatar_style: v})}>
            <SelectTrigger>
              <SelectValue/>
            </SelectTrigger>
            <SelectContent className="superman-card">
              <SelectItem value="professional">Professional</SelectItem>
              <SelectItem value="casual">Casual</SelectItem>
              <SelectItem value="scientific">Scientific</SelectItem>
              <SelectItem value="creative">Creative</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="system_prompt" className="text-cyan">System Prompt (Agent's Personality & Skills)</Label>
          <Textarea 
            id="system_prompt" 
            value={formData.system_prompt} 
            onChange={e => setFormData({...formData, system_prompt: e.target.value})} 
            className="h-32" 
            placeholder="You are a witty and creative copywriter who specializes in..."
            required
          />
        </div>
        <div className="flex justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onFinished} className="border-silver/30 text-silver hover:bg-silver/10">
            Cancel
          </Button>
          <Button type="submit" disabled={isSaving} className="btn-cyan">
            {isSaving && <Loader2 className="w-4 h-4 animate-spin mr-2"/>}
            {model?.id ? 'Save Changes' : 'Create Agent'}
          </Button>
        </div>
      </form>
    );
  };

  if (isLoading) {
    return (
      <div className="p-8 h-full bg-obsidian-black flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-cyan animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 h-full bg-obsidian-black overflow-y-auto">
        <header className="flex justify-between items-center mb-8 obsidian-panel p-6 rounded-lg">
            <div>
                <h1 className="text-3xl font-bold text-gold">Settings & Identity</h1>
                <p className="text-cyan mt-1">Manage AI agents, security, and personal preferences.</p>
            </div>
            <div className="flex items-center gap-4">
              {currentUser && (
                <div className="kryptonite-glow rounded-lg p-3 flex items-center gap-2 text-sm">
                  <Shield className="w-4 h-4 text-kryptonite" />
                  <span className="text-silver">Trust:</span>
                  <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
                </div>
              )}
              <Button onClick={() => handleOpenModelDialog()} className="btn-cyan">
                  <Plus className="w-4 h-4 mr-2"/> New Agent
              </Button>
            </div>
        </header>

        <Tabs defaultValue="agents" className="space-y-6">
          <TabsList className="bg-transparent mb-6 p-0 border-b border-cyan/30 w-full justify-start rounded-none">
            <TabsTrigger value="agents" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] rounded-none text-silver hover:text-white">
              <Bot className="w-4 h-4 mr-2" />AI Agents
            </TabsTrigger>
            <TabsTrigger value="openai-keys" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] rounded-none text-silver hover:text-white">
              <Key className="w-4 h-4 mr-2" />OpenAI Keys
            </TabsTrigger>
            <TabsTrigger value="identity" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] rounded-none text-silver hover:text-white">
              <Shield className="w-4 h-4 mr-2" />Identity & Security
            </TabsTrigger>
            <TabsTrigger value="personality" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] rounded-none text-silver hover:text-white">
              <Brain className="w-4 h-4 mr-2" />Personality
            </TabsTrigger>
            <TabsTrigger value="biometrics" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] rounded-none text-silver hover:text-white">
              <Zap className="w-4 h-4 mr-2" />Biometrics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="agents">
            <div className="space-y-4">
              <AnimatePresence>
                {models.length > 0 ? (
                  models.map(model => (
                    <motion.div
                      key={model.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                    >
                      <Card className="superman-card hover:cyan-glow transition-all duration-300">
                        <CardContent className="p-6 flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-3 rounded-lg cyan-glow">
                              <Bot className="w-6 h-6 text-cyan" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg text-silver">{model.name}</h3>
                              <p className="text-sm text-silver/70 mt-1">{model.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {userSettings?.active_model_id === model.id ? (
                              <Badge className="bg-kryptonite/20 text-kryptonite border border-kryptonite/30 font-medium">
                                <Check className="w-4 h-4 mr-1"/> Active
                              </Badge>
                            ) : (
                              <Button variant="outline" size="sm" onClick={() => handleSetActiveModel(model.id)} className="border-gold/50 text-gold hover:bg-gold/10">
                                Set Active
                              </Button>
                            )}
                            <Button variant="ghost" size="icon" onClick={() => handleOpenModelDialog(model)} className="text-silver hover:text-cyan">
                              <Edit className="w-4 h-4"/>
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleDeleteModel(model.id)} 
                              disabled={userSettings?.active_model_id === model.id}
                              className="text-silver hover:text-crimson disabled:opacity-50"
                            >
                              <Trash2 className="w-4 h-4"/>
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))
                ) : (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-16"
                  >
                    <Card className="superman-card max-w-md mx-auto">
                      <CardContent className="p-8">
                        <div className="w-16 h-16 cyan-glow rounded-full flex items-center justify-center mx-auto mb-4">
                          <Bot className="w-8 h-8 text-cyan" />
                        </div>
                        <h3 className="text-xl font-semibold text-silver mb-2">No Agents Yet</h3>
                        <p className="text-silver/70 mb-6 leading-relaxed">Create specialized AI agents with unique personalities and skills.</p>
                        <Button onClick={() => handleOpenModelDialog()} className="btn-cyan">
                          <Plus className="w-4 h-4 mr-2"/> Create Your First Agent
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </TabsContent>

          <TabsContent value="openai-keys">
            <OpenAIKeyManager />
          </TabsContent>

          <TabsContent value="identity" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TrustScoreIndicator trustScore={currentUser?.trust_score || 87} riskLevel="low" />
            <ModeSelector activeMode={currentUser?.active_mode} onModeChange={async (mode) => {
              await User.updateMyUserData({ active_mode: mode });
              loadCurrentUser();
            }} />
          </TabsContent>

          <TabsContent value="personality">
            <PersonalityProfile personality={currentUser?.personality_profile} />
          </TabsContent>

          <TabsContent value="biometrics">
            <BiometricStatus biometrics={currentUser?.biometric_profiles} />
          </TabsContent>
        </Tabs>

        <Dialog open={isModelDialogOpen} onOpenChange={setIsModelDialogOpen}>
          <DialogContent className="obsidian-panel max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-gold">
                {editingModel ? 'Edit AI Agent' : 'Create New AI Agent'}
              </DialogTitle>
            </DialogHeader>
            <ModelForm model={editingModel} onFinished={() => { setIsModelDialogOpen(false); loadData(); }}/>
          </DialogContent>
        </Dialog>
    </div>
  );
}
