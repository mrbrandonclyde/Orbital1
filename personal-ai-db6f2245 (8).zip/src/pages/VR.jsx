import React, { useState, useEffect } from 'react';
import { getNasaFireData } from '@/api/functions';
import FireGlobeVR from '@/components/vr/FireGlobeVR';
import { Loader2, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function VRPage() {
    const [alerts, setAlerts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchFireData = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const { data, error: apiError } = await getNasaFireData();
            if (apiError || !data) {
                throw new Error(apiError?.message || 'Failed to fetch fire data');
            }
            setAlerts(data);
        } catch (err) {
            setError(err.message);
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchFireData();
    }, []);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-cyan-300">
                    <Loader2 className="w-16 h-16 animate-spin mb-4" />
                    <p className="text-lg">Acquiring satellite telemetry...</p>
                </div>
            );
        }

        if (error) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-red-400 bg-red-500/10 rounded-xl p-8">
                    <AlertTriangle className="w-16 h-16 mb-4" />
                    <p className="text-lg font-semibold">Telemetry Link Failed</p>
                    <p className="text-sm mb-4">{error}</p>
                    <Button onClick={fetchFireData} variant="outline" className="text-red-300 border-red-300/50 hover:bg-red-400/20 hover:text-red-200">
                        <RefreshCw className="w-4 h-4 mr-2" /> Re-establish Link
                    </Button>
                </div>
            );
        }

        return <FireGlobeVR alerts={alerts} />;
    };

    return (
        <div className="w-full h-full bg-black text-white relative">
            <div className="absolute top-4 left-6 z-10 p-4 rounded-xl bg-black/50 backdrop-blur-md border border-cyan-500/30">
                <h1 className="text-2xl font-bold text-cyan-300">VR Global Fire Monitor</h1>
                <p className="text-sm text-gray-400">Live Mission Control Visualization</p>
            </div>
             <div className="absolute bottom-4 right-6 z-10 p-3 rounded-xl bg-black/50 backdrop-blur-md border border-gray-700 text-xs text-gray-400">
                Use mouse to orbit and zoom.
            </div>
            {renderContent()}
        </div>
    );
}