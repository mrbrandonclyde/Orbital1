
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LicenseManager } from "@/components/LicenseManagerService"; // Corrected import path

import MainFrame from "@/components/MainFrame";
import ZyraControlPanel from "@/components/ZyraControlPanel";
import ChatPanel from "@/components/ChatPanel";
import ForecastOverlay from "@/components/ForecastOverlay";
import ExportManager from "@/components/ExportManager";
import AutomationEngine from "@/components/AutomationEngine";
import { TimelineProvider, useTimeline } from "@/components/TimelineProvider";
import TimelineBar from "@/components/TimelineBar";
import TimelineHUD from "@/components/TimelineHUD";
import VoiceControls from "@/components/VoiceControls";
import KeyboardControls from "@/components/KeyboardControls";
import CommandHistory from "@/components/CommandHistory";
import { User } from "@/api/entities";
import { themes } from "@/components/theme";
import ErrorBoundary from "@/components/ErrorBoundary";
import OrbitalLanding from "@/components/OrbitalLanding";
import { Clock, Shield } from "lucide-react"; // New import

function TimeMachineCore() {
  const [settings, setSettings] = useState(() => ({
    prediction: false,
    showPanels: true,
    immersiveMode: false,
    showLanding: false,
    satelliteView: false, // Initial state for satelliteView
    theme:
      (typeof window !== "undefined" && localStorage.getItem("os-theme")) ||
      "superman",
  }));
  const [commands, setCommands] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  const { rollback, forward, togglePlay, playing, play, pause } = useTimeline(); // Added playing, play, pause
  const theme = themes[settings.theme] || themes.superman;

  useEffect(() => {
    LicenseManager.track('START_APP'); // New tracking call
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("os-theme", settings.theme);
    }
  }, [settings.theme]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const user = await User.me();
        if (mounted) setCurrentUser(user);
      } catch (e) {
        console.warn("User not authenticated", e);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const handleToggle = (key, value) => {
    setSettings((prev) => {
      if (key === "prediction") {
        return { ...prev, prediction: !prev.prediction };
      }
      if (key === "theme") {
        return { ...prev, theme: value };
      }
      return { ...prev, [key]: value !== undefined ? value : !prev[key] };
    });
  };

  const handleVoiceCommand = (text) => {
    const lowerText = text.toLowerCase().trim();
    let response = "";

    // Handle direct keyboard commands first (these often come from KeyboardControls)
    if (lowerText === 'rollback') {
      rollback();
      response = "Rolling back system state.";
      LicenseManager.track('TIMELINE_ROLLBACK_KEY');
    } else if (lowerText === 'forward') {
      forward();
      response = "Moving forward on timeline.";
      LicenseManager.track('TIMELINE_FORWARD_KEY');
    } else if (lowerText === 'playpause') {
      togglePlay();
      response = playing ? "Timeline paused." : "Timeline playing.";
      LicenseManager.track('TIMELINE_PLAYPAUSE_KEY'); // Removed payload
    }
    // Then handle more general voice commands
    else if (lowerText.includes("play")) {
      play();
      response = "Timeline playback activated.";
      LicenseManager.track('VOICE_PLAY');
    } else if (lowerText.includes("pause")) {
      pause();
      response = "Timeline paused.";
      LicenseManager.track('VOICE_PAUSE');
    } else if (lowerText.includes("show panel")) { // Changed from "show panels"
      handleToggle("showPanels", true);
      response = "Displaying control panels.";
      LicenseManager.track('VOICE_SHOW_PANELS');
    } else if (lowerText.includes("hide panel")) { // Changed from "hide panels"
      handleToggle("showPanels", false);
      response = "Hiding control panels.";
      LicenseManager.track('VOICE_HIDE_PANELS');
    } else if (lowerText.includes("activate orbital view")) {
      handleToggle("showLanding", true);
      response = "Activating orbital view.";
      LicenseManager.track('VOICE_ACTIVATE_ORBITAL_VIEW');
    } else if (lowerText.includes("deactivate orbital view")) {
      handleToggle("showLanding", false);
      response = "Deactivating orbital view.";
      LicenseManager.track('VOICE_DEACTIVATE_ORBITAL_VIEW');
    } else if (lowerText.includes("activate satellite view")) { // New command
      handleToggle("satelliteView", true);
      response = "Activating satellite view.";
      LicenseManager.track('VOICE_ACTIVATE_SATELLITE_VIEW');
    } else if (lowerText.includes("deactivate satellite view")) { // New command
      handleToggle("satelliteView", false);
      response = "Deactivating satellite view.";
      LicenseManager.track('VOICE_DEACTIVATE_SATELLITE_VIEW');
    }

    LicenseManager.track('VOICE_COMMAND'); // Removed payload
    setCommands((prev) => [
      ...prev.slice(-19),
      response || `Command processed: ${text}`,
    ]);

    if (
      response &&
      typeof window !== "undefined" &&
      "speechSynthesis" in window
    ) {
      try {
        speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(response);
        utter.pitch = 1.15;
        utter.rate = 1.0;
        speechSynthesis.speak(utter);
      } catch (err) {
        console.warn("Speech synthesis error:", err);
      }
    }
  };

  return (
    <div
      className={`flex h-full min-h-0 overflow-hidden ${theme.background} text-white transition-all duration-500`}
    >
      {/* Controls */}
      <KeyboardControls onCommand={handleVoiceCommand} />
      {/* VoiceControls moved inside sidebar */}

      {/* Sidebar */}
      <AnimatePresence>
        {settings.showPanels && !settings.immersiveMode && (
          <motion.div
            initial={{ x: -320, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -320, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className={`flex-shrink-0 w-80 flex flex-col ${theme.panel}`}
          >
            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              <div className="text-center"> {/* Wrapper div added for VoiceControls */}
                <VoiceControls onCommand={handleVoiceCommand} />
              </div>
              <ChatPanel onCommand={handleVoiceCommand} theme={theme} />
              <CommandHistory commands={commands} />
            </div>
            <div className="flex-shrink-0 border-t border-cyan-500/20 p-3">
              <ZyraControlPanel
                settings={settings}
                onToggle={handleToggle}
                theme={theme}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 min-h-0 flex flex-col relative">
        <header
          className={`p-6 pb-4 flex-shrink-0 ${theme.panel} border-b border-cyan-500/30 relative z-10`}
        >
          <div className="flex justify-between items-center">
            <div>
              <h1
                className={`text-3xl font-extrabold ${theme.textPrimary} mb-1 flex items-center gap-3`}
              >
                🕰️ SupermanOS Time Machine
                {settings.prediction && (
                  <motion.span
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="text-purple"
                  >
                    🧠
                  </motion.span>
                )}
              </h1>
              <p className={`${theme.textSecondary} opacity-90 text-sm`}>
                Navigate through time, manage parallel branches, and predict
                future states with voice and keyboard control.
              </p>
            </div>

            {currentUser && (
              <div
                className={`rounded-lg px-4 py-2 flex items-center gap-2 text-sm ${theme.glow}`}
              >
                <span className={theme.textSecondary}>Trust:</span>
                <span className="font-bold text-kryptonite">
                  {currentUser.trust_score ?? 87}
                </span>
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 relative min-h-0">
          {settings.showLanding ? (
            <OrbitalLanding />
          ) : (
            <MainFrame settings={settings} />
          )}

          <div className="absolute top-4 right-4 pointer-events-auto space-y-4">
            <TimelineHUD />
            {settings.prediction && <ForecastOverlay predictions={["System stability: 99.8%", "Timeline divergence: 0.3%"]} />}
          </div>

          <div className="absolute bottom-20 right-4 pointer-events-auto space-y-3">
            <ExportManager />
            <AutomationEngine count={3} />
          </div>
        </div>

        <div className="flex-shrink-0">
          <TimelineBar theme={theme} />
        </div>
      </div>
    </div>
  );
}

export default function TimeMachinePage() {
  return (
    <ErrorBoundary>
      <TimelineProvider>
        <TimeMachineCore />
      </TimelineProvider>
    </ErrorBoundary>
  );
}
