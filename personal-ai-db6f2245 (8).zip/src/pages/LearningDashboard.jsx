
import React, { useState, useEffect } from "react";
import { FeedbackLog } from "@/api/entities";
import { PromptEvolution } from "@/api/entities";
import { AIModel } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, TrendingUp, Star, MessageSquare, Zap, 
  BarChart3, Users, Target, Loader2 
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function LearningDashboardPage() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [evolutions, setEvolutions] = useState([]);
  const [models, setModels] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [stats, setStats] = useState({
    totalFeedbacks: 0,
    averageRating: 0,
    improvementScore: 0,
    activeEvolutions: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [feedbackData, evolutionData, modelData] = await Promise.all([
        FeedbackLog.list('-created_date', 100),
        PromptEvolution.list('-updated_date'),
        AIModel.list()
      ]);
      
      setFeedbacks(feedbackData);
      setEvolutions(evolutionData);
      setModels(modelData);
      
      // Calculate stats
      const totalFeedbacks = feedbackData.length;
      const averageRating = totalFeedbacks > 0 
        ? feedbackData.reduce((sum, f) => sum + f.rating, 0) / totalFeedbacks 
        : 0;
      
      setStats({
        totalFeedbacks,
        averageRating: Math.round(averageRating * 100) / 100,
        improvementScore: Math.round(averageRating * 20), // Convert to percentage
        activeEvolutions: evolutionData.filter(e => e.is_active).length
      });
    } catch (error) {
      console.error('Error loading learning data:', error);
    }
  };

  const analyzeAndImprove = async () => {
    setIsAnalyzing(true);
    
    try {
      // Get recent feedback for analysis
      const recentFeedback = feedbacks.slice(0, 20);
      
      if (recentFeedback.length === 0) {
        alert('No feedback available to analyze yet. Start rating AI responses to enable learning!');
        return;
      }

      const feedbackSummary = recentFeedback.map(f => ({
        rating: f.rating,
        quality: f.response_quality,
        context: f.context_category,
        feedback: f.feedback_text
      }));

      const analysisPrompt = `Analyze this user feedback data and suggest improvements to AI system prompts:

${JSON.stringify(feedbackSummary, null, 2)}

Based on patterns in the feedback:
1. What are the main areas for improvement?
2. How should the system prompt be modified to address these issues?
3. What specific personality/style adjustments are needed?

Provide structured recommendations for prompt improvements.`;

      const analysis = await InvokeLLM({ prompt: analysisPrompt });
      
      // Create evolution record
      await PromptEvolution.create({
        model_id: 'general_system',
        original_prompt: 'Current general system prompt',
        evolved_prompt: analysis,
        learning_insights: JSON.stringify({
          feedback_count: recentFeedback.length,
          average_rating: recentFeedback.reduce((sum, f) => sum + f.rating, 0) / recentFeedback.length,
          analysis_date: new Date().toISOString(),
          key_improvements: ['Based on user feedback patterns']
        }),
        performance_metrics: {
          average_rating: stats.averageRating,
          feedback_count: stats.totalFeedbacks,
          improvement_score: stats.improvementScore
        }
      });

      loadData();
    } catch (error) {
      console.error('Error analyzing feedback:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const ratingDistribution = [
    { name: '5 Stars', value: feedbacks.filter(f => f.rating === 5).length, color: '#10B981' }, // green
    { name: '4 Stars', value: feedbacks.filter(f => f.rating === 4).length, color: '#3B82F6' }, // blue
    { name: '3 Stars', value: feedbacks.filter(f => f.rating === 3).length, color: '#F59E0B' }, // amber
    { name: '2 Stars', value: feedbacks.filter(f => f.rating === 2).length, color: '#EF4444' }, // red
    { name: '1 Star', value: feedbacks.filter(f => f.rating === 1).length, color: '#DC2626' }  // darker red
  ];

  const feedbackTrend = feedbacks
    .slice(0, 20)
    .reverse()
    .map((feedback, index) => ({
      index: index + 1,
      rating: feedback.rating,
      date: new Date(feedback.created_date).toLocaleDateString()
    }));

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8">
            <div>
                <h1 className="text-3xl font-bold text-white">Zyra Learning Dashboard</h1>
                <p className="text-slate-400 mt-1">Monitor AI performance and prompt evolution.</p>
            </div>
          
          <Button 
            onClick={analyzeAndImprove}
            disabled={isAnalyzing || feedbacks.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Brain className="w-4 h-4 mr-2" />}
            {isAnalyzing ? 'Analyzing...' : 'Analyze & Improve'}
          </Button>
        </header>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800/70 border-slate-700/50">
            <CardContent className="p-6 flex items-center gap-4">
                <MessageSquare className="w-8 h-8 text-blue-400" />
                <div>
                  <p className="text-2xl font-bold text-white">{stats.totalFeedbacks}</p>
                  <p className="text-sm text-slate-400">Total Feedback</p>
                </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/70 border-slate-700/50">
            <CardContent className="p-6 flex items-center gap-4">
                <Star className="w-8 h-8 text-yellow-400" />
                <div>
                  <p className="text-2xl font-bold text-white">{stats.averageRating}/5</p>
                  <p className="text-sm text-slate-400">Average Rating</p>
                </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/70 border-slate-700/50">
            <CardContent className="p-6 flex items-center gap-4">
                <TrendingUp className="w-8 h-8 text-green-400" />
                <div>
                  <p className="text-2xl font-bold text-white">{stats.improvementScore}%</p>
                  <p className="text-sm text-slate-400">Performance</p>
                </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/70 border-slate-700/50">
            <CardContent className="p-6 flex items-center gap-4">
                <Zap className="w-8 h-8 text-purple-400" />
                <div>
                  <p className="text-2xl font-bold text-white">{stats.activeEvolutions}</p>
                  <p className="text-sm text-slate-400">Active Evolutions</p>
                </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-slate-800/80 border border-slate-700/50">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="feedback">Feedback Analysis</TabsTrigger>
            <TabsTrigger value="evolution">Prompt Evolution</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Rating Trend */}
              <Card className="bg-slate-800/70 border-slate-700/50">
                <CardHeader>
                  <CardTitle className="text-white">Rating Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={feedbackTrend} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                      <XAxis dataKey="index" stroke="#94a3b8" />
                      <YAxis domain={[0, 5]} stroke="#94a3b8" />
                      <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                      <Line type="monotone" dataKey="rating" stroke="#60a5fa" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Rating Distribution */}
              <Card className="bg-slate-800/70 border-slate-700/50">
                <CardHeader>
                  <CardTitle className="text-white">Rating Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie data={ratingDistribution} cx="50%" cy="50%" outerRadius={80} fill="#8884d8" dataKey="value" label={{ fill: '#fff' }}>
                        {ratingDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="feedback">
            <Card className="bg-slate-800/70 border-slate-700/50">
              <CardHeader><CardTitle className="text-white">Recent Feedback</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                  {feedbacks.slice(0, 10).map(feedback => (
                    <div key={feedback.id} className="border border-slate-700 rounded-lg p-4 bg-slate-900/50">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map(star => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= feedback.rating ? 'text-yellow-400 fill-current' : 'text-gray-700'}`}
                              />
                            ))}
                          </div>
                          {feedback.context_category && (
                            <Badge variant="secondary">{feedback.context_category}</Badge>
                          )}
                        </div>
                        <span className="text-sm text-slate-400">
                          {new Date(feedback.created_date).toLocaleDateString()}
                        </span>
                      </div>
                      {feedback.response_quality && (
                        <Badge className="mb-2">{feedback.response_quality.replace('_', ' ')}</Badge>
                      )}
                      {feedback.feedback_text && (
                        <p className="text-sm text-slate-300">{feedback.feedback_text}</p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="evolution">
            <Card className="bg-slate-800/70 border-slate-700/50">
              <CardHeader><CardTitle className="text-white">Prompt Evolution History</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {evolutions.length > 0 ? evolutions.map(evolution => (
                    <div key={evolution.id} className="border border-slate-700 rounded-lg p-4 bg-slate-900/50">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Version {evolution.version}</h4>
                        <Badge variant={evolution.is_active ? 'default' : 'secondary'}>
                          {evolution.is_active ? 'Active' : 'Archived'}
                        </Badge>
                      </div>
                      <div className="bg-slate-700/30 rounded p-3 mb-2">
                        <p className="text-sm text-slate-300">{evolution.evolved_prompt}</p>
                      </div>
                      {evolution.learning_insights && (
                        <p className="text-sm text-slate-400 mb-2">
                          Insights: {JSON.parse(evolution.learning_insights).key_improvements?.join(', ')}
                        </p>
                      )}
                      {evolution.performance_metrics && (
                        <div className="text-sm text-slate-400">
                          Average Rating: {evolution.performance_metrics.average_rating?.toFixed(1)} | 
                          Feedback Count: {evolution.performance_metrics.feedback_count}
                        </div>
                      )}
                      <span className="text-xs text-slate-500 block mt-2">
                        Last updated: {new Date(evolution.updated_date).toLocaleDateString()}
                      </span>
                    </div>
                  )) : (
                    <p className="text-center text-slate-500 py-8">
                      No prompt evolutions yet. Start providing feedback to enable AI learning!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
