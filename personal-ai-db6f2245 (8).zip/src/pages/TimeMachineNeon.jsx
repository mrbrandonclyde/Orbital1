import React from "react";
import TimeMachineLayout from "@/components/TimeMachineLayout";

export default function TimeMachineNeon() {
  return <TimeMachineLayout />;
}