import React, { useState, useEffect } from "react";
import { License } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { Payment } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, FileText, CreditCard, Settings, Database, BarChart3, Users, DollarSign, AlertTriangle } from "lucide-react";
import AuditLogViewer from "@/components/license/AuditLogViewer";
import PaymentHistory from "@/components/license/PaymentHistory";
import LicenseIssuer from "@/components/license/LicenseIssuer";
import SystemSettings from "@/components/license/SystemSettings";

const StatCard = ({ title, value, icon: Icon, metricClass }) => (
    <Card className={`superman-card ${metricClass}`}>
      <CardContent className="p-4 flex items-center justify-between">
        <div>
          <p className="text-3xl font-bold">{value}</p>
          <p className="text-sm opacity-80">{title}</p>
        </div>
        <div className="p-3 rounded-lg bg-black/20">
            <Icon className="w-8 h-8" />
        </div>
      </CardContent>
    </Card>
);

export default function LicenseManagerPage() {
    const [licenses, setLicenses] = useState([]);
    const [auditLogs, setAuditLogs] = useState([]);
    const [payments, setPayments] = useState([]);
    const [stats, setStats] = useState({ totalLicenses: 0, activeLicenses: 0, totalRevenue: 0, expiringSoon: 0 });

    useEffect(() => { loadData(); }, []);

    const loadData = async () => {
        const [licensesData, auditData, paymentsData] = await Promise.all([
            License.list('-created_date'), AuditLog.list('-created_date', 100), Payment.list('-created_date', 50)
        ]);
        setLicenses(licensesData);
        setAuditLogs(auditData);
        setPayments(paymentsData);
        
        const active = licensesData.filter(l => l.status === 'active').length;
        const revenue = paymentsData.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0) / 100;
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        const expiring = licensesData.filter(l => l.expiry_date && new Date(l.expiry_date) <= thirtyDaysFromNow && l.status === 'active').length;

        setStats({ totalLicenses: licensesData.length, activeLicenses: active, totalRevenue: revenue, expiringSoon: expiring });
    };

    const logAction = async (action, details, targetEmail = null, severity = 'info') => {
        await AuditLog.create({ action, user_email: 'brandon.clyde@supermanos.ai', target_email: targetEmail, details, ip_address: 'admin-dashboard', severity });
        loadData();
    };

    return (
        <div className="p-8 h-full overflow-y-auto">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-gold">ProtectApp License Manager</h1>
                <p className="text-silver mt-1">Advanced licensing system with audit trails and payment integration.</p>
            </header>

            <Tabs defaultValue="dashboard" className="w-full">
                <TabsList className="bg-transparent mb-6 p-0 border-b border-cyan/30 w-full justify-start rounded-none">
                    <TabsTrigger value="dashboard"><BarChart3 className="w-4 h-4 mr-2" />Dashboard</TabsTrigger>
                    <TabsTrigger value="licenses"><Shield className="w-4 h-4 mr-2" />Licenses</TabsTrigger>
                    <TabsTrigger value="issue"><Database className="w-4 h-4 mr-2" />Issue License</TabsTrigger>
                    <TabsTrigger value="payments"><CreditCard className="w-4 h-4 mr-2" />Payments</TabsTrigger>
                    <TabsTrigger value="audit"><FileText className="w-4 h-4 mr-2" />Audit Logs</TabsTrigger>
                    <TabsTrigger value="settings"><Settings className="w-4 h-4 mr-2" />Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="dashboard" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <StatCard title="Total Licenses" value={stats.totalLicenses} icon={Shield} metricClass="metric-cyan" />
                        <StatCard title="Active Licenses" value={stats.activeLicenses} icon={Users} metricClass="metric-green" />
                        <StatCard title="Total Revenue" value={`$${stats.totalRevenue.toLocaleString()}`} icon={DollarSign} metricClass="metric-gold" />
                        <StatCard title="Expiring Soon" value={stats.expiringSoon} icon={AlertTriangle} metricClass="metric-orange" />
                    </div>
                    {/* Placeholder for LicenseDashboard content */}
                    <Card className="superman-card"><CardHeader><CardTitle className="text-silver">Recent Activity</CardTitle></CardHeader><CardContent><p className="text-slate-400">Dashboard components for recent licenses and expiring alerts will be rendered here.</p></CardContent></Card>
                </TabsContent>
                <TabsContent value="licenses"><Card className="superman-card"><CardHeader><CardTitle className="text-silver">License Management</CardTitle></CardHeader><CardContent><p className="text-slate-400">Advanced license table coming in Stage 2...</p></CardContent></Card></TabsContent>
                <TabsContent value="issue"><LicenseIssuer onLicenseIssued={loadData} onLogAction={logAction} /></TabsContent>
                <TabsContent value="payments"><PaymentHistory payments={payments} onRefresh={loadData} /></TabsContent>
                <TabsContent value="audit"><AuditLogViewer auditLogs={auditLogs} onRefresh={loadData} /></TabsContent>
                <TabsContent value="settings"><SystemSettings onLogAction={logAction} /></TabsContent>
            </Tabs>
        </div>
    );
}