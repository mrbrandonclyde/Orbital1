import Layout from "./Layout.jsx";

import Chat from "./Chat";

import Settings from "./Settings";

import Templates from "./Templates";

import Documents from "./Documents";

import CosmicLab from "./CosmicLab";

import SavedSections from "./SavedSections";

import Dashboard from "./Dashboard";

import LicenseManager from "./LicenseManager";

import IdeaRefinery from "./IdeaRefinery";

import DocumentFactory from "./DocumentFactory";

import LearningDashboard from "./LearningDashboard";

import MemoryAudit from "./MemoryAudit";

import ImplementationAudit from "./ImplementationAudit";

import Principles from "./Principles";

import SystemDashboard from "./SystemDashboard";

import SystemMonitorPage from "./SystemMonitorPage";

import TimeMachineNeon from "./TimeMachineNeon";

import TimeMachine from "./TimeMachine";

import OrbitalLanding from "./OrbitalLanding";

import VersionHistory from "./VersionHistory";

import WebBrowser from "./WebBrowser";

import FireDetection from "./FireDetection";

import VR from "./VR";

import GlobalCommand from "./GlobalCommand";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Chat: Chat,
    
    Settings: Settings,
    
    Templates: Templates,
    
    Documents: Documents,
    
    CosmicLab: CosmicLab,
    
    SavedSections: SavedSections,
    
    Dashboard: Dashboard,
    
    LicenseManager: LicenseManager,
    
    IdeaRefinery: IdeaRefinery,
    
    DocumentFactory: DocumentFactory,
    
    LearningDashboard: LearningDashboard,
    
    MemoryAudit: MemoryAudit,
    
    ImplementationAudit: ImplementationAudit,
    
    Principles: Principles,
    
    SystemDashboard: SystemDashboard,
    
    SystemMonitorPage: SystemMonitorPage,
    
    TimeMachineNeon: TimeMachineNeon,
    
    TimeMachine: TimeMachine,
    
    OrbitalLanding: OrbitalLanding,
    
    VersionHistory: VersionHistory,
    
    WebBrowser: WebBrowser,
    
    FireDetection: FireDetection,
    
    VR: VR,
    
    GlobalCommand: GlobalCommand,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Chat />} />
                
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Templates" element={<Templates />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/CosmicLab" element={<CosmicLab />} />
                
                <Route path="/SavedSections" element={<SavedSections />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/LicenseManager" element={<LicenseManager />} />
                
                <Route path="/IdeaRefinery" element={<IdeaRefinery />} />
                
                <Route path="/DocumentFactory" element={<DocumentFactory />} />
                
                <Route path="/LearningDashboard" element={<LearningDashboard />} />
                
                <Route path="/MemoryAudit" element={<MemoryAudit />} />
                
                <Route path="/ImplementationAudit" element={<ImplementationAudit />} />
                
                <Route path="/Principles" element={<Principles />} />
                
                <Route path="/SystemDashboard" element={<SystemDashboard />} />
                
                <Route path="/SystemMonitorPage" element={<SystemMonitorPage />} />
                
                <Route path="/TimeMachineNeon" element={<TimeMachineNeon />} />
                
                <Route path="/TimeMachine" element={<TimeMachine />} />
                
                <Route path="/OrbitalLanding" element={<OrbitalLanding />} />
                
                <Route path="/VersionHistory" element={<VersionHistory />} />
                
                <Route path="/WebBrowser" element={<WebBrowser />} />
                
                <Route path="/FireDetection" element={<FireDetection />} />
                
                <Route path="/VR" element={<VR />} />
                
                <Route path="/GlobalCommand" element={<GlobalCommand />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}