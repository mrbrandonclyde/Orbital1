import OrbitalLanding from "@/components/OrbitalLanding";

export default function OrbitalLandingPage() {
    return <OrbitalLanding />;
}