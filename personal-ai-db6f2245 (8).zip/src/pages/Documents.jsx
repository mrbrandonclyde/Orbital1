
import React, { useState, useEffect, useCallback } from "react";
import { Document } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import DocumentForm from "@/components/documents/DocumentForm";
import { FileText, Search, Pin, Plus, Edit, Trash2, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "framer-motion";

export default function DocumentsPage() {
  const [documents, setDocuments] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState(null);

  const loadDocuments = useCallback(async () => {
    setIsLoading(true);
    const docs = await Document.list('-updated_date');
    setDocuments(docs);
    setIsLoading(false);
    
    setSelectedDocument(prevSelectedDoc => {
        // If there's no previously selected doc, select the first one if it exists.
        if (!prevSelectedDoc && docs.length > 0) {
            return docs[0];
        }
        // If there was a selected doc, try to find it in the new list to refresh its data.
        if (prevSelectedDoc) {
            const refreshedDoc = docs.find(d => d.id === prevSelectedDoc.id);
            // If the refreshed doc is found, use it. Otherwise, fall back to the first doc or null.
            return refreshedDoc || (docs.length > 0 ? docs[0] : null);
        }
        // If no docs and no previous selection, return null.
        return null;
    });
  }, []); // Empty dependency array as loadDocuments doesn't depend on any external state or props.

  useEffect(() => {
    loadDocuments();
  }, [loadDocuments]); // Add loadDocuments to the dependency array

  const handleFormSubmit = async (data) => {
    if (editingDocument) {
      await Document.update(editingDocument.id, data);
    } else {
      await Document.create(data);
    }
    setIsFormOpen(false);
    setEditingDocument(null);
    loadDocuments();
  };

  const handleNewClick = () => {
    setEditingDocument(null);
    setIsFormOpen(true);
  };

  const handleEditClick = () => {
    if (selectedDocument) {
      setEditingDocument(selectedDocument);
      setIsFormOpen(true);
    }
  };

  const handleDeleteClick = async () => {
    if (selectedDocument && confirm('Are you sure you want to permanently delete this document?')) {
      await Document.delete(selectedDocument.id);
      // After deletion, if the deleted document was selected, try to select another one
      // This logic will be handled by loadDocuments' setSelectedDocument updater function
      loadDocuments(); 
    }
  };

  const filteredDocuments = documents.filter(doc =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (doc.tags || []).some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const togglePin = async (doc) => {
    await Document.update(doc.id, { is_pinned: !doc.is_pinned });
    loadDocuments();
  };

  return (
    <div className="flex h-full superman-gradient">
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DocumentForm
          document={editingDocument}
          onSubmit={handleFormSubmit}
          onCancel={() => setIsFormOpen(false)}
        />
      </Dialog>

      <div className="w-1/3 max-w-sm flex-shrink-0 obsidian-panel flex flex-col">
        <div className="p-4 border-b border-cyan/30">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gold">Memory Archives</h2>
            <Button size="sm" className="btn-cyan" onClick={handleNewClick}>
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-silver" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search archives..."
              className="pl-10"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
          {isLoading ? (
            <div className="flex justify-center items-center h-full">
              <Loader2 className="w-8 h-8 text-cyan animate-spin" />
            </div>
          ) : (
            <AnimatePresence>
              {filteredDocuments.map(doc => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  layout
                >
                  <Card
                    className={`mb-2 cursor-pointer transition-all superman-card ${
                      selectedDocument?.id === doc.id ? 'cyan-glow' : 'hover:cyan-glow'
                    }`}
                    onClick={() => setSelectedDocument(doc)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-sm flex items-center gap-2 text-silver">
                          <FileText className="w-4 h-4 text-cyan" />
                          <span className="truncate pr-2">{doc.title}</span>
                        </h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-silver/70 hover:text-gold"
                          onClick={(e) => { e.stopPropagation(); togglePin(doc); }}
                        >
                          <Pin className={`w-3 h-3 ${doc.is_pinned ? 'text-gold fill-current' : ''}`} />
                        </Button>
                      </div>
                      <p className="text-xs text-silver/70 line-clamp-2 mb-2">
                        {doc.content.substring(0, 100)}
                      </p>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {(doc.tags || []).slice(0, 3).map(tag => (
                          <Badge key={tag} className="text-xs capitalize bg-cyan/10 text-cyan border border-cyan/30">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-xs text-silver/60">
                        Updated: {new Date(doc.updated_date).toLocaleDateString()}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
          {!isLoading && documents.length === 0 && (
             <div className="text-center p-12 text-silver/60">
                <FileText className="w-12 h-12 mx-auto mb-3" />
                <h3 className="text-lg font-medium">No Documents Found</h3>
                <p className="text-sm mb-4">Create your first document to get started.</p>
                <Button className="btn-cyan" onClick={handleNewClick}>
                  <Plus className="w-4 h-4 mr-2" /> Create Document
                </Button>
             </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {selectedDocument ? (
          <>
            <div className="p-6 border-b border-cyan/30 obsidian-panel flex-shrink-0">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-bold text-gold">{selectedDocument.title}</h1>
                  <div className="flex gap-2 mt-2">
                    {(selectedDocument.tags || []).map(tag => (
                      <Badge key={tag} className="capitalize bg-cyan/10 text-cyan border border-cyan/30">{tag}</Badge>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleEditClick} className="border-amber/50 text-amber hover:bg-amber/10 hover:text-amber">
                    <Edit className="w-4 h-4 mr-1" />Edit
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDeleteClick} className="border-crimson/50 text-crimson hover:bg-crimson/10 hover:text-crimson">
                    <Trash2 className="w-4 h-4 mr-1" />Delete
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6 prose prose-invert max-w-none prose-p:text-silver/90 prose-headings:text-gold prose-a:text-cyan prose-strong:text-white prose-blockquote:border-l-gold">
              <ReactMarkdown>
                {selectedDocument.content}
              </ReactMarkdown>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center text-silver/60">
              <FileText className="w-16 h-16 mx-auto mb-4" />
              <p>Select a document to view</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
