import React from 'react';
import { motion } from 'framer-motion';
import { GitBranch, Layers, CheckCircle, Rocket, ScrollText } from 'lucide-react';
import { themes } from '@/components/theme';

const versions = [
  {
    version: '2.0 "Orbital"',
    date: 'October 26, 2023',
    icon: Rocket,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/30',
    description: 'A complete transformation of the user interface to the "Orbital" design language, featuring deep space gradients, glassy panels, and vibrant neon glows for a cohesive, futuristic experience.',
    highlights: [
      'Introduced the new "Orbital" theme with #2B2BC9 accent colors.',
      'Reskinned all major components: Timeline Bar, Control Panels, Chat, and HUDs.',
      'Standardized buttons and interactive elements with glowing, gradient-heavy styles.',
      'Enhanced visual feedback with subtle animations and blur effects.',
    ],
  },
  {
    version: '1.5 "Kryptonite"',
    date: 'October 24, 2023',
    icon: Layers,
    color: 'text-kryptonite',
    bgColor: 'bg-kryptonite/10',
    borderColor: 'border-kryptonite/30',
    description: 'Introduced theme switching capabilities and the high-contrast "Kryptonite" theme, focusing on modularity and user personalization.',
    highlights: [
      'Added multi-theme support (Superman, Dark, Light, Kryptonite).',
      'Fixed text visibility issues in Light Mode.',
      'Component styles refactored for easier theming.',
    ],
  },
  {
    version: '1.0 "Genesis"',
    date: 'October 22, 2023',
    icon: GitBranch,
    color: 'text-gold',
    bgColor: 'bg-gold/10',
    borderColor: 'border-gold/30',
    description: 'The initial launch of the SupermanOS Time Machine, establishing the core temporal navigation and system monitoring functionalities.',
    highlights: [
      'Core Timeline provider for state management.',
      'Functional Timeline Bar, HUD, and Control Panel.',
      'Voice and Keyboard controls for navigation.',
    ],
  },
];

export default function VersionHistoryPage() {
    const theme = themes.orbital; // Forcing orbital theme for this page's style

    return (
        <div className={`h-full min-h-screen p-8 overflow-y-auto ${theme.background}`}>
            <div className="max-w-4xl mx-auto">
                <header className="text-center mb-12">
                    <h1 className={`text-5xl font-extrabold ${theme.textPrimary}`}>Version History</h1>
                    <p className={`mt-4 text-lg ${theme.textSecondary}`}>Tracking the evolution of SupermanOS.</p>
                </header>

                <div className="relative">
                    {/* Timeline Line */}
                    <div className="absolute left-1/2 -ml-px w-0.5 h-full bg-purple-500/30"></div>

                    {versions.map((version, index) => (
                        <motion.div
                            key={version.version}
                            className="relative mb-12"
                            initial={{ opacity: 0, y: 50 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5, delay: index * 0.2 }}
                        >
                            <div className="flex items-center">
                                {/* Left side (Date) */}
                                <div className="w-1/2 pr-8 text-right">
                                    <p className={`text-sm font-medium ${theme.textSecondary}`}>{version.date}</p>
                                </div>

                                {/* Timeline Circle */}
                                <div className="absolute left-1/2 -ml-4 z-10">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${version.bgColor} border-2 ${version.borderColor} ${theme.glow}`}>
                                        <version.icon className={`w-5 h-5 ${version.color}`} />
                                    </div>
                                </div>

                                {/* Right side (empty spacer) */}
                                <div className="w-1/2 pl-8"></div>
                            </div>

                            {/* Card Content */}
                            <div className="mt-4">
                                <div className={`ml-[calc(50%+2rem)] p-6 rounded-xl ${theme.panel}`}>
                                    <h2 className={`text-2xl font-bold ${version.color}`}>{version.version}</h2>
                                    <p className={`mt-2 mb-4 ${theme.textSecondary}`}>
                                        {version.description}
                                    </p>
                                    <ul className="space-y-2">
                                        {version.highlights.map((highlight, i) => (
                                            <li key={i} className="flex items-start gap-3 text-sm">
                                                <CheckCircle className="w-4 h-4 mt-0.5 text-kryptonite flex-shrink-0" />
                                                <span className={`${theme.textSecondary}`}>{highlight}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
}