import React, { useState } from "react";
import MainFrame from "@/components/MainFrame";
import TimelineBar from "@/components/TimelineBar";
import TimelineHUD from "@/components/TimelineHUD";
import TemporalConsole from "@/components/TemporalConsole";
import ChatPanel from "@/components/ChatPanel";
import VoiceControls from "@/components/VoiceControls";
import KeyboardControls from "@/components/KeyboardControls";
import CommandHistory from "@/components/CommandHistory";
import { TimelineProvider } from "@/components/TimelineProvider";
import { themes } from "@/components/theme";

export default function SystemMonitorPage() {
  const [settings, setSettings] = useState({
    prediction: false,
    immersiveMode: false,
    showChat: true,
    showPanels: true,
    showLanding: false,
  });

  const [commands, setCommands] = useState([
    "Initialize temporal systems",
    "Load orbital parameters", 
    "Sync neural networks"
  ]);

  const theme = themes.orbital;

  const handleVoiceCommand = (command) => {
    console.log("Voice command received:", command);
    setCommands(prev => [...prev, command]);
  };

  const handleToggle = (key, value) => {
    setSettings((prev) => ({ ...prev, [key]: value !== undefined ? value : !prev[key] }));
  };

  return (
    <TimelineProvider>
      <div className={`flex h-screen w-full ${theme.background} text-white overflow-hidden`}>
        <KeyboardControls onCommand={handleVoiceCommand} />
        <VoiceControls onCommand={handleVoiceCommand} />

        {/* ===== Left (Main Frame + Header + Footer) ===== */}
        <div className="flex flex-col flex-1 relative">
          {/* Header */}
          <header className={`p-6 border-b border-purple-500/30 ${theme.panel}`}>
            <h1 className={`text-3xl font-bold ${theme.textPrimary} mb-1 flex items-center gap-3`}>
              Orbital Temporal Monitor
              {settings.prediction && (
                <span className="animate-pulse text-purple-400">🧠</span>
              )}
            </h1>
            <p className={`${theme.textSecondary}`}>
              Navigate through time • Manage parallel branches • Predict future states with voice and keyboard control.
            </p>
          </header>

          {/* Main Content */}
          <div className="flex-grow relative">
            <MainFrame settings={settings} />

            {/* HUD Overlay */}
            {settings.showPanels && (
              <div className="absolute top-4 right-4 pointer-events-none">
                <TimelineHUD />
              </div>
            )}

            {/* Command History Overlay */}
            {settings.showPanels && (
              <div className="absolute top-4 left-4 pointer-events-auto">
                <CommandHistory commands={commands} />
              </div>
            )}

            {/* Forecast Indicator */}
            {settings.prediction && (
              <div className="absolute bottom-4 left-4 px-4 py-3 rounded-xl bg-purple-500/20 border border-purple-400/30 backdrop-blur-xl animate-pulse pointer-events-none shadow-lg">
                <span className="font-bold text-purple-300 flex items-center gap-2">
                  🔮 Orbital Forecasting Active
                </span>
              </div>
            )}
          </div>

          {/* Timeline Bar (Footer) */}
          <footer>
            <TimelineBar theme={theme} />
          </footer>
        </div>

        {/* ===== Right Sidebar ===== */}
        <div className="flex flex-col w-80">
          <TemporalConsole 
            settings={settings}
            onToggle={handleToggle}
            theme={theme}
          />

          {settings.showChat && (
            <div className={`flex-1 m-4 mt-0 rounded-2xl ${theme.panel} shadow-2xl overflow-hidden`}>
              <ChatPanel onCommand={handleVoiceCommand} theme={theme} />
            </div>
          )}
        </div>
      </div>
    </TimelineProvider>
  );
}