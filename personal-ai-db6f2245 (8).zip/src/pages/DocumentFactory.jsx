import React, { useState, useEffect } from "react";
import { DocumentTemplate, GeneratedDocument } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  FileText, Plus, Download, Copy, Eye, Zap, 
  Scale, Briefcase, DollarSign, Users, Target, Settings, Loader2, Shield 
} from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function DocumentFactoryPage() {
  const [templates, setTemplates] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [variableValues, setVariableValues] = useState({});
  const [activeTab, setActiveTab] = useState('templates');
  const [currentUser, setCurrentUser] = useState(null);

  const [newTemplate, setNewTemplate] = useState({
    name: '',
    category: 'legal',
    description: '',
    template_content: '',
    variables: []
  });

  useEffect(() => {
    loadData();
    loadCurrentUser();
  }, []);

  const loadData = async () => {
    const [templateData, documentData] = await Promise.all([
      DocumentTemplate.list('-updated_date'),
      GeneratedDocument.list('-updated_date')
    ]);
    setTemplates(templateData);
    setDocuments(documentData);
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error.message);
    }
  };

  const categoryIcons = {
    legal: Scale,
    business: Briefcase,
    finance: DollarSign,
    hr: Users,
    marketing: Target,
    technical: Settings,
    personal: FileText
  };

  const generateDocument = async () => {
    if (!selectedTemplate) return;
    
    setIsGenerating(true);
    try {
      const prompt = `Generate a professional document based on this template:

Template: ${selectedTemplate.name}
Category: ${selectedTemplate.category}
Description: ${selectedTemplate.description}

Template Content:
${selectedTemplate.template_content}

Variables to fill:
${Object.entries(variableValues).map(([key, value]) => `${key}: ${value}`).join('\n')}

Please generate a complete, professional document by:
1. Replacing all variable placeholders with the provided values
2. Ensuring proper formatting and professional language
3. Adding any necessary legal disclaimers if it's a legal document
4. Making sure all sections are complete and coherent

Return the document in markdown format.`;

      const generatedContent = await InvokeLLM({ prompt });

      const document = await GeneratedDocument.create({
        title: `${selectedTemplate.name} - ${new Date().toLocaleDateString()}`,
        template_id: selectedTemplate.id,
        content: generatedContent,
        variables_used: JSON.stringify(variableValues),
        format: 'markdown'
      });

      // Update template usage count
      await DocumentTemplate.update(selectedTemplate.id, {
        usage_count: (selectedTemplate.usage_count || 0) + 1
      });

      setSelectedDocument(document);
      setActiveTab('documents');
      loadData();
    } catch (error) {
      console.error('Error generating document:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTemplateSelect = (template) => {
    setSelectedTemplate(template);
    // Initialize variable values
    const initialValues = {};
    template.variables?.forEach(variable => {
      initialValues[variable.key] = variable.default_value || '';
    });
    setVariableValues(initialValues);
  };

  const copyToClipboard = (content) => {
    navigator.clipboard.writeText(content);
  };

  const createPredefinedTemplates = async () => {
    const predefinedTemplates = [
      {
        name: "Non-Disclosure Agreement",
        category: "legal",
        description: "Standard NDA for business discussions",
        template_content: `# NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement ("Agreement") is entered into on {{date}} between {{company_name}}, a {{company_type}} ("Disclosing Party"), and {{recipient_name}} ("Receiving Party").

## 1. Definition of Confidential Information
For purposes of this Agreement, "Confidential Information" shall include all information or material that has or could have commercial value or other utility in the business in which Disclosing Party is engaged.

## 2. Non-Disclosure Obligations
Receiving Party agrees to hold and maintain the Confidential Information in strict confidence for the sole and exclusive benefit of the Disclosing Party.

## 3. Term
This Agreement shall remain in effect for {{term_years}} years from the date first written above.

**Disclosing Party:**
{{company_name}}

By: _________________________
Name: {{signer_name}}
Title: {{signer_title}}
Date: {{date}}

**Receiving Party:**
{{recipient_name}}

By: _________________________
Date: {{date}}`,
        variables: [
          { key: "date", label: "Date", type: "date", required: true },
          { key: "company_name", label: "Company Name", type: "text", required: true },
          { key: "company_type", label: "Company Type", type: "text", default_value: "corporation" },
          { key: "recipient_name", label: "Recipient Name", type: "text", required: true },
          { key: "term_years", label: "Term (years)", type: "number", default_value: "2" },
          { key: "signer_name", label: "Signer Name", type: "text", required: true },
          { key: "signer_title", label: "Signer Title", type: "text", required: true }
        ]
      },
      {
        name: "Business Plan Executive Summary",
        category: "business",
        description: "Professional executive summary template",
        template_content: `# {{company_name}} - Executive Summary

## Company Overview
{{company_name}} is a {{company_type}} focused on {{business_focus}}. Founded in {{founding_year}}, we are headquartered in {{location}}.

## Mission Statement
{{mission_statement}}

## Market Opportunity
The {{industry}} industry represents a \${{market_size}} opportunity. Our target market consists of {{target_market}}.

## Products/Services
{{products_services_description}}

## Competitive Advantage
- {{advantage_1}}
- {{advantage_2}}  
- {{advantage_3}}

## Financial Projections
We project revenues of \${{year1_revenue}} in Year 1, growing to \${{year3_revenue}} by Year 3.

## Funding Requirements
We are seeking \${{funding_amount}} in {{funding_type}} to {{funding_purpose}}.

## Team
Led by {{founder_name}}, {{founder_title}}, with {{founder_experience}} years of experience in {{founder_expertise}}.

---
*This executive summary provides an overview of {{company_name}}'s business opportunity and growth strategy.*`,
        variables: [
          { key: "company_name", label: "Company Name", type: "text", required: true },
          { key: "company_type", label: "Company Type", type: "text", default_value: "corporation" },
          { key: "business_focus", label: "Business Focus", type: "text", required: true },
          { key: "founding_year", label: "Founding Year", type: "number", required: true },
          { key: "location", label: "Location", type: "text", required: true },
          { key: "mission_statement", label: "Mission Statement", type: "text", required: true },
          { key: "industry", label: "Industry", type: "text", required: true },
          { key: "market_size", label: "Market Size", type: "text", required: true },
          { key: "target_market", label: "Target Market", type: "text", required: true },
          { key: "products_services_description", label: "Products/Services Description", type: "text", required: true },
          { key: "advantage_1", label: "Competitive Advantage #1", type: "text", required: true },
          { key: "advantage_2", label: "Competitive Advantage #2", type: "text", required: true },
          { key: "advantage_3", label: "Competitive Advantage #3", type: "text", required: true },
          { key: "year1_revenue", label: "Year 1 Revenue Projection", type: "text", required: true },
          { key: "year3_revenue", label: "Year 3 Revenue Projection", type: "text", required: true },
          { key: "funding_amount", label: "Funding Amount Needed", type: "text", required: true },
          { key: "funding_type", label: "Funding Type", type: "text", default_value: "Series A funding" },
          { key: "funding_purpose", label: "Funding Purpose", type: "text", required: true },
          { key: "founder_name", label: "Founder Name", type: "text", required: true },
          { key: "founder_title", label: "Founder Title", type: "text", required: true },
          { key: "founder_experience", label: "Founder Experience (years)", type: "number", required: true },
          { key: "founder_expertise", label: "Founder Expertise Area", type: "text", required: true }
        ]
      }
    ];

    for (const template of predefinedTemplates) {
      await DocumentTemplate.create(template);
    }
    loadData();
  };

  return (
    <div className="p-8 h-full overflow-y-auto superman-gradient">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8 obsidian-panel p-4 rounded-lg">
            <div>
                <h1 className="text-3xl font-bold text-gold">Document Factory</h1>
                <p className="text-cyan mt-1">AI-powered instant document generation.</p>
            </div>
          
          <div className="flex items-center gap-2">
            {/* Identity Core Integration */}
            {currentUser && (
              <div className="kryptonite-glow rounded-lg p-2 flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-kryptonite" />
                <span className="text-silver">Trust:</span>
                <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
              </div>
            )}
            
            <Button variant="outline" onClick={createPredefinedTemplates} className="border-amber/50 text-amber hover:bg-amber/10">
              <Zap className="w-4 h-4 mr-2" />
              Load Sample Templates
            </Button>
            <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="btn-cyan">
                  <Plus className="w-4 h-4 mr-2" />
                  New Template
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl obsidian-panel">
                <DialogHeader>
                  <DialogTitle className="text-gold">Create Document Template</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      placeholder="Template name"
                      value={newTemplate.name}
                      onChange={(e) => setNewTemplate({...newTemplate, name: e.target.value})}
                    />
                    <Select value={newTemplate.category} onValueChange={(value) => setNewTemplate({...newTemplate, category: value})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent className="superman-card">
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="hr">HR</SelectItem>
                        <SelectItem value="marketing">Marketing</SelectItem>
                        <SelectItem value="technical">Technical</SelectItem>
                        <SelectItem value="personal">Personal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Textarea
                    placeholder="Description"
                    value={newTemplate.description}
                    onChange={(e) => setNewTemplate({...newTemplate, description: e.target.value})}
                    className="text-silver"
                  />
                  <Textarea
                    placeholder="Template content with {{variable_name}} placeholders..."
                    value={newTemplate.template_content}
                    onChange={(e) => setNewTemplate({...newTemplate, template_content: e.target.value})}
                    className="h-40 text-silver font-mono"
                  />
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)} className="border-slate-600 text-slate-300">
                      Cancel
                    </Button>
                    <Button className="btn-cyan">Create Template</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-transparent mb-6 p-0 border-b border-cyan/30 w-full justify-start rounded-none">
            <TabsTrigger value="templates" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Templates</TabsTrigger>
            <TabsTrigger value="generator" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Generator</TabsTrigger>
            <TabsTrigger value="documents" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Generated Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="templates">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {templates.map(template => {
                const IconComponent = categoryIcons[template.category] || FileText;
                return (
                  <Card key={template.id} className="superman-card hover:cyan-glow transition-all cursor-pointer" onClick={() => {
                    handleTemplateSelect(template);
                    setActiveTab('generator');
                  }}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-lg text-silver">
                        <IconComponent className="w-5 h-5 text-cyan" />
                        {template.name}
                      </CardTitle>
                      <div className="flex justify-between items-center">
                        <Badge variant="secondary" className="capitalize metric-cyan">{template.category}</Badge>
                        <span className="text-xs text-slate-400">{template.usage_count || 0} uses</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-400 line-clamp-2">{template.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="generator">
            {selectedTemplate ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="superman-card">
                  <CardHeader>
                    <CardTitle className="text-gold">Fill Template Variables</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedTemplate.variables?.map(variable => (
                      <div key={variable.key}>
                        <Label htmlFor={variable.key} className="text-slate-300">
                          {variable.label} {variable.required && <span className="text-crimson">*</span>}
                        </Label>
                        <Input
                          id={variable.key}
                          type={variable.type}
                          value={variableValues[variable.key] || ''}
                          onChange={(e) => setVariableValues({
                            ...variableValues,
                            [variable.key]: e.target.value
                          })}
                          placeholder={variable.default_value}
                          required={variable.required}
                          className="mt-1 text-silver"
                        />
                      </div>
                    ))}
                    <Button 
                      onClick={generateDocument} 
                      disabled={isGenerating}
                      className="w-full btn-cyan text-lg py-6"
                    >
                      {isGenerating ? <Loader2 className="w-6 h-6 mr-2 animate-spin" /> : <Zap className="w-6 h-6 mr-2" />}
                      {isGenerating ? 'Generating...' : 'Generate Document'}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="superman-card">
                  <CardHeader>
                    <CardTitle className="text-gold">Template Preview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-slate-900/70 p-4 rounded-lg max-h-96 overflow-y-auto prose prose-sm prose-invert max-w-none border border-cyan/20">
                      <ReactMarkdown>
                        {selectedTemplate.template_content}
                      </ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="superman-card text-center p-12">
                <FileText className="w-16 h-16 mx-auto mb-4 text-slate-600" />
                <h3 className="text-xl font-semibold text-silver mb-2">Select a Template</h3>
                <p className="text-slate-400">Choose a template from the Templates tab to get started</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="documents">
            <div className="space-y-4">
              {documents.map(document => (
                <Card key={document.id} className="superman-card hover:cyan-glow transition-colors">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg text-silver">{document.title}</CardTitle>
                        <p className="text-sm text-slate-400">
                          Generated on {new Date(document.created_date).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => setSelectedDocument(document)} className="border-cyan/50 text-cyan hover:bg-cyan/10">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => copyToClipboard(document.content)} className="border-amber/50 text-amber hover:bg-amber/10">
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </Button>
                        <Button variant="outline" size="sm" className="border-kryptonite/50 text-kryptonite hover:bg-kryptonite/10">
                          <Download className="w-4 h-4 mr-1" />
                          Export
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  {selectedDocument?.id === document.id && (
                    <CardContent>
                      <div className="bg-slate-900/70 p-4 rounded-lg max-h-96 overflow-y-auto prose prose-invert max-w-none border border-cyan/20">
                        <ReactMarkdown>
                          {document.content}
                        </ReactMarkdown>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}