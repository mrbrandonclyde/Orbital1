import { useState } from "react";
import { 
  ChevronDown, ChevronRight, TrendingUp, TrendingDown, Activity, Brain 
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Gem } from "lucide-react";

export default function MemoryCore({ stats, status = 'active', metrics }) {
  const [open, setOpen] = useState({
    episodic: true,
    semantic: true,
    procedural: false,
    pruning: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  const renderTrend = (trend) => {
    if (!trend) return <Activity className="w-3 h-3 text-silver" />;
    if (trend === "up") return <TrendingUp className="w-3 h-3 text-kryptonite" />;
    if (trend === "down") return <TrendingDown className="w-3 h-3 text-crimson" />;
    return <Activity className="w-3 h-3 text-cyan" />;
  };

  const getStatusColor = (status) => {
    const colors = {
      active: 'bg-kryptonite-green/20 text-kryptonite border-kryptonite/30',
      degraded: 'bg-amber-orange/20 text-amber border-amber/30',
      critical: 'bg-crimson-red/20 text-crimson border-crimson/30',
      offline: 'bg-silver-gray/20 text-silver border-silver/30'
    };
    return colors[status] || colors.offline;
  };

  if (!stats) {
    return (
      <Card className="superman-card h-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-silver">
              <Brain className="w-5 h-5 text-cyan" />
              Memory Core
              <Gem className="w-4 h-4 text-gold opacity-80" />
            </CardTitle>
            <Badge className={getStatusColor(status)}>
              {status.toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-silver">Loading Memory Stats...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <Brain className="w-5 h-5 text-cyan" />
            Memory Core
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className={getStatusColor(status)}>
            {status.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Cognitive architecture for learning, recall, and workflow automation.
        </p>

        {/* Performance Metrics */}
        {metrics && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-silver">Performance</span>
              <span className="text-cyan">{metrics.performance}%</span>
            </div>
            <Progress value={metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
            
            <div className="flex justify-between text-sm">
              <span className="text-silver">Memory Usage</span>
              <span className="text-amber">{metrics.memory}%</span>
            </div>
            <Progress value={metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
          </div>
        )}

        {/* Episodic Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("episodic")}
          >
            {open.episodic ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            🧠 Episodic Memory
          </button>
          {open.episodic && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Sessions Stored: <span className="text-cyan font-bold">{stats.episodic.sessions}</span></p>
              <p className="text-silver">Conversations Indexed: <span className="text-cyan font-bold">{stats.episodic.conversations}</span></p>
              <p className="text-silver">Events Recorded: <span className="text-cyan font-bold">{stats.episodic.events}</span></p>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online {renderTrend(stats.episodic.trend)}</p>
            </div>
          )}
        </div>

        {/* Semantic Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("semantic")}
          >
            {open.semantic ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            📚 Semantic Memory
          </button>
          {open.semantic && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Facts Embedded: <span className="text-cyan font-bold">{stats.semantic.facts}</span></p>
              <p className="text-silver">Documents Indexed: <span className="text-cyan font-bold">{stats.semantic.documents}</span></p>
              <p className="text-silver">Embeddings Generated: <span className="text-cyan font-bold">{stats.semantic.embeddings}</span></p>
              <div className="w-full bg-slate-700/50 rounded-full h-2 mt-1">
                <div className="bg-cyan h-2 rounded-full" style={{ width: `${stats.semantic.usage}%` }}></div>
              </div>
              <p className="text-xs text-silver opacity-70">Storage: {stats.semantic.usage}% utilized</p>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online {renderTrend(stats.semantic.trend)}</p>
            </div>
          )}
        </div>

        {/* Procedural Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("procedural")}
          >
            {open.procedural ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            ⚡ Procedural Memory
          </button>
          {open.procedural && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Workflows Learned: <span className="text-cyan font-bold">{stats.procedural.workflows}</span></p>
              <p className="text-silver">Automations Running: <span className="text-cyan font-bold">{stats.procedural.automations}</span></p>
              <p className="text-silver">Success Rate: <span className="text-kryptonite font-bold">{stats.procedural.success_rate}%</span></p>
              <div className="w-full bg-slate-700/50 rounded-full h-2 mt-1">
                <div className="bg-kryptonite h-2 rounded-full" style={{ width: `${stats.procedural.success_rate}%` }}></div>
              </div>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online {renderTrend(stats.procedural.trend)}</p>
            </div>
          )}
        </div>

        {/* Adaptive Pruning */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("pruning")}
          >
            {open.pruning ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            🪓 Adaptive Pruning
          </button>
          {open.pruning && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Retention Priority: <span className="text-cyan font-bold">{stats.pruning.priority}</span></p>
              <p className="text-silver">Items Pruned Today: <span className="text-amber font-bold">{stats.pruning.pruned_today}</span></p>
              <p className="text-silver">High-Value Recalls: <span className="text-kryptonite font-bold">{stats.pruning.high_value}</span></p>
              <div className="w-full bg-slate-700/50 rounded-full h-2 mt-1">
                <div className="bg-amber h-2 rounded-full" style={{ width: `${stats.pruning.usage}%` }}></div>
              </div>
              <p className="text-xs text-silver opacity-70">Processing: {stats.pruning.usage}% capacity</p>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online {renderTrend(stats.pruning.trend)}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}