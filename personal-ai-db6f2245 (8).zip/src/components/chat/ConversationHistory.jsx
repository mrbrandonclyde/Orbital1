import React from "react";
import { Button } from "@/components/ui/button";
import { Plus, MessageSquare, Trash2, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";

export default function ConversationHistory({ 
  conversations, 
  currentConversationId, 
  onSelectConversation, 
  onNewConversation, 
  onDeleteConversation,
  isHistoryLoading 
}) {
  const [searchTerm, setSearchTerm] = React.useState("");
  
  const filteredConversations = conversations.filter(conv =>
    conv.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return "Today";
    if (diffInDays === 1) return "Yesterday";
    if (diffInDays < 7) return `${diffInDays} days ago`;
    return date.toLocaleDateString();
  };

  return (
    <aside className="w-80 flex-shrink-0 obsidian-panel flex flex-col">
      <div className="h-20 flex items-center justify-between px-4" style={{ borderBottom: '1px solid rgba(0, 255, 255, 0.3)' }}>
        <h2 className="font-semibold text-lg text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-cyan" />
          Conversations
        </h2>
        <Button onClick={onNewConversation} size="sm" className="btn-cyan">
          <Plus className="w-4 h-4 mr-1" />
          New
        </Button>
      </div>
      <div className="p-4" style={{ borderBottom: '1px solid rgba(0, 255, 255, 0.3)' }}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-silver" />
            <Input
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 text-sm"
            />
          </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {isHistoryLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan"></div>
          </div>
        ) : (
          <div className="p-2 space-y-1">
            <AnimatePresence>
              {filteredConversations.length > 0 ? (
                filteredConversations.map((conversation, index) => (
                  <motion.div
                    key={conversation.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: index * 0.05 }}
                    className={`group relative p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                      currentConversationId === conversation.id 
                        ? 'nav-active' 
                        : 'nav-hover'
                    }`}
                    onClick={() => onSelectConversation(conversation.id)}
                  >
                    <h3 className={`font-medium text-sm truncate ${
                      currentConversationId === conversation.id ? 'text-cyan' : 'text-silver'
                    }`}>
                      {conversation.title}
                    </h3>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-silver/60">
                        {formatDate(conversation.last_message_at)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 hover:bg-crimson/20 hover:text-crimson text-silver"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm('Delete this conversation?')) {
                            onDeleteConversation(conversation.id);
                          }
                        }}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-silver/60 p-4 text-center">
                  <MessageSquare className="w-8 h-8 mb-2" />
                  <p className="text-sm font-medium">No conversations found</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </aside>
  );
}