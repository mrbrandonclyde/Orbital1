import React, { useState, useEffect } from "react";
import { Template } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, FileText, Code, Briefcase, Palette } from "lucide-react";

const categoryIcons = {
  writing: FileText,
  coding: Code,
  business: Briefcase,
  creative: Palette,
  analysis: Sparkles,
  personal: Sparkles
};

export default function QuickActions({ onSelectTemplate, currentConversationId }) {
  const [templates, setTemplates] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    const allTemplates = await Template.list('-use_count');
    setTemplates(allTemplates);
  };

  const handleTemplateClick = async (template) => {
    // Increment use count
    await Template.update(template.id, { use_count: (template.use_count || 0) + 1 });
    onSelectTemplate(template.prompt);
  };

  const categories = ['all', 'writing', 'coding', 'business', 'creative', 'analysis', 'personal'];
  const filteredTemplates = selectedCategory === 'all' 
    ? templates 
    : templates.filter(t => t.category === selectedCategory);

  if (currentConversationId || templates.length === 0) return null;

  return (
    <Card className="mb-6 bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-100">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-600" />
          Quick Start Templates
        </h3>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="text-xs"
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredTemplates.slice(0, 6).map(template => {
            const IconComponent = categoryIcons[template.category] || Sparkles;
            return (
              <Button
                key={template.id}
                variant="ghost"
                className="h-auto p-4 justify-start flex-col items-start hover:bg-white hover:shadow-sm transition-all"
                onClick={() => handleTemplateClick(template)}
              >
                <div className="flex items-center gap-2 mb-2 w-full">
                  <IconComponent className="w-4 h-4 text-indigo-600" />
                  <span className="font-medium text-sm truncate">{template.name}</span>
                </div>
                <p className="text-xs text-gray-600 text-left line-clamp-2">
                  {template.prompt.substring(0, 80)}...
                </p>
                <Badge variant="secondary" className="mt-2 text-xs">
                  {template.use_count || 0} uses
                </Badge>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}