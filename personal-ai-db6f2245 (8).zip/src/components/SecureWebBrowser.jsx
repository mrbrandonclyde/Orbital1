import React, { useState } from "react";

export default function SecureWebBrowser({ year = new Date().getFullYear(), theme, defaultUrl = "https://example.com" }) {
  const [url, setUrl] = useState(defaultUrl);
  const [inputUrl, setInputUrl] = useState(defaultUrl);

  const handleNavigate = (e) => {
    e.preventDefault();
    if (!inputUrl.startsWith("http")) {
      setUrl("https://" + inputUrl);
    } else {
      setUrl(inputUrl);
    }
  };

  return (
    <div className={`flex flex-col h-full w-full rounded-xl overflow-hidden ${theme?.panel || "bg-black/40 backdrop-blur-lg border border-blue-500/30"}`}>
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-blue-500/20 bg-black/30">
        <h3 className="text-cyan-300 font-semibold">🌐 Secure Web Browser – Year {year}</h3>
        <form onSubmit={handleNavigate} className="flex items-center gap-2 flex-1 ml-4">
          <input
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            className="flex-1 bg-black/40 text-gray-200 text-sm px-3 py-1 rounded-lg border border-blue-500/30 focus:outline-none focus:border-cyan-400"
            placeholder="Enter URL..."
          />
          <button
            type="submit"
            className="px-3 py-1 rounded-lg text-white text-sm font-medium shadow-md transition-colors duration-200"
            style={{backgroundColor: '#2b2bc9'}}
            onMouseEnter={(e) => e.target.style.backgroundColor = '#1e1e8f'}
            onMouseLeave={(e) => e.target.style.backgroundColor = '#2b2bc9'}
          >
            Go
          </button>
        </form>
      </header>

      {/* Browser Frame */}
      <div className="flex-1 bg-black">
        <iframe
          src={url}
          sandbox="allow-scripts allow-same-origin"
          className="w-full h-full"
          title="Secure Web Browser"
        ></iframe>
      </div>
    </div>
  );
}