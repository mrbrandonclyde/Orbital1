import React, { useState, useEffect } from "react";
import { OpenAIKey } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { 
  Key, Plus, Edit, Trash2, CheckCircle, AlertCircle, 
  Clock, DollarSign, Zap, Eye, EyeOff 
} from "lucide-react";
import { toast } from "sonner";

export default function OpenAIKeyManager() {
  const [keys, setKeys] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingKey, setEditingKey] = useState(null);
  const [showApiKey, setShowApiKey] = useState({});
  
  const [formData, setFormData] = useState({
    name: '',
    api_key: '',
    organization_id: '',
    usage_limit: '',
    model_access: ['gpt-4', 'gpt-3.5-turbo'],
    notes: ''
  });

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    const data = await OpenAIKey.list('-updated_date');
    setKeys(data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const keyData = {
        ...formData,
        usage_limit: formData.usage_limit ? parseFloat(formData.usage_limit) : null,
        model_access: Array.isArray(formData.model_access) ? formData.model_access : formData.model_access.split(',').map(m => m.trim())
      };

      if (editingKey) {
        await OpenAIKey.update(editingKey.id, keyData);
        toast.success("API key updated successfully");
      } else {
        await OpenAIKey.create(keyData);
        toast.success("API key added successfully");
      }
      
      setIsDialogOpen(false);
      setEditingKey(null);
      setFormData({
        name: '', api_key: '', organization_id: '', usage_limit: '',
        model_access: ['gpt-4', 'gpt-3.5-turbo'], notes: ''
      });
      loadKeys();
    } catch (error) {
      toast.error("Failed to save API key");
      console.error(error);
    }
  };

  const handleEdit = (key) => {
    setEditingKey(key);
    setFormData({
      name: key.name,
      api_key: key.api_key,
      organization_id: key.organization_id || '',
      usage_limit: key.usage_limit || '',
      model_access: key.model_access || ['gpt-4', 'gpt-3.5-turbo'],
      notes: key.notes || ''
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (keyId) => {
    if (confirm('Are you sure you want to delete this API key?')) {
      try {
        await OpenAIKey.delete(keyId);
        toast.success("API key deleted");
        loadKeys();
      } catch (error) {
        toast.error("Failed to delete API key");
      }
    }
  };

  const handleSetActive = async (keyId) => {
    try {
      // First, set all keys to inactive
      await Promise.all(keys.map(key => 
        OpenAIKey.update(key.id, { is_active: false })
      ));
      
      // Then set the selected key as active
      await OpenAIKey.update(keyId, { is_active: true });
      toast.success("Active API key updated");
      loadKeys();
    } catch (error) {
      toast.error("Failed to set active key");
    }
  };

  const testKey = async (key) => {
    try {
      // Basic key format validation
      if (!key.api_key.startsWith('sk-')) {
        await OpenAIKey.update(key.id, { status: 'invalid' });
        toast.error("Invalid API key format");
        loadKeys();
        return;
      }

      // Update status to active and last_used
      await OpenAIKey.update(key.id, { 
        status: 'active', 
        last_used: new Date().toISOString() 
      });
      toast.success("API key is valid");
      loadKeys();
    } catch (error) {
      await OpenAIKey.update(key.id, { status: 'invalid' });
      toast.error("API key test failed");
      loadKeys();
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-300 border-green-500/50';
      case 'rate_limited': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'expired': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'invalid': return 'bg-red-500/20 text-red-300 border-red-500/50';
      default: return 'bg-slate-500/20 text-slate-300 border-slate-500/50';
    }
  };

  const maskApiKey = (apiKey) => {
    if (!apiKey) return '';
    return `${apiKey.substring(0, 7)}...${apiKey.substring(apiKey.length - 4)}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">OpenAI API Keys</h2>
          <p className="text-slate-400">Manage multiple OpenAI API keys and switch between them</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-cyan" onClick={() => {
              setEditingKey(null);
              setFormData({
                name: '', api_key: '', organization_id: '', usage_limit: '',
                model_access: ['gpt-4', 'gpt-3.5-turbo'], notes: ''
              });
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Add API Key
            </Button>
          </DialogTrigger>
          <DialogContent className="obsidian-panel max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-gold">
                {editingKey ? 'Edit API Key' : 'Add New API Key'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-silver">Display Name *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g., Main Account, Backup Key"
                    required
                  />
                </div>
                <div>
                  <Label className="text-silver">Usage Limit ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.usage_limit}
                    onChange={(e) => setFormData({...formData, usage_limit: e.target.value})}
                    placeholder="e.g., 100.00"
                  />
                </div>
              </div>
              
              <div>
                <Label className="text-silver">API Key *</Label>
                <Input
                  type="password"
                  value={formData.api_key}
                  onChange={(e) => setFormData({...formData, api_key: e.target.value})}
                  placeholder="sk-..."
                  required
                />
              </div>
              
              <div>
                <Label className="text-silver">Organization ID (Optional)</Label>
                <Input
                  value={formData.organization_id}
                  onChange={(e) => setFormData({...formData, organization_id: e.target.value})}
                  placeholder="org-..."
                />
              </div>
              
              <div>
                <Label className="text-silver">Model Access</Label>
                <Input
                  value={Array.isArray(formData.model_access) ? formData.model_access.join(', ') : formData.model_access}
                  onChange={(e) => setFormData({...formData, model_access: e.target.value.split(',').map(m => m.trim())})}
                  placeholder="gpt-4, gpt-3.5-turbo, dall-e-3"
                />
              </div>
              
              <div>
                <Label className="text-silver">Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Optional notes about this key..."
                  className="h-20"
                />
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="btn-cyan">
                  {editingKey ? 'Update Key' : 'Add Key'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {keys.map(key => (
          <Card key={key.id} className={`superman-card ${key.is_active ? 'gold-glow' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex items-center gap-2">
                    <Key className="w-5 h-5 text-cyan" />
                    <div>
                      <h3 className="font-semibold text-white">{key.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-silver font-mono">
                          {showApiKey[key.id] ? key.api_key : maskApiKey(key.api_key)}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => setShowApiKey({...showApiKey, [key.id]: !showApiKey[key.id]})}
                        >
                          {showApiKey[key.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {key.is_active && (
                      <Badge className="bg-gold bg-opacity-20 text-gold border-gold/30">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    )}
                    <Badge className={getStatusColor(key.status)}>
                      {key.status}
                    </Badge>
                  </div>
                  
                  {key.usage_limit && (
                    <div className="flex items-center gap-1 text-sm">
                      <DollarSign className="w-4 h-4 text-amber" />
                      <span className="text-silver">
                        ${(key.usage_current || 0).toFixed(2)} / ${key.usage_limit.toFixed(2)}
                      </span>
                    </div>
                  )}
                  
                  {key.last_used && (
                    <div className="flex items-center gap-1 text-sm text-silver">
                      <Clock className="w-4 h-4" />
                      <span>{new Date(key.last_used).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testKey(key)}
                    className="text-cyan border-cyan/30 hover:bg-cyan/10"
                  >
                    <Zap className="w-4 h-4 mr-1" />
                    Test
                  </Button>
                  
                  {!key.is_active && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSetActive(key.id)}
                      className="text-gold border-gold/30 hover:bg-gold/10"
                    >
                      Set Active
                    </Button>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleEdit(key)}
                    className="text-silver hover:text-white"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(key.id)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {key.notes && (
                <div className="mt-3 pt-3 border-t border-slate-700">
                  <p className="text-sm text-silver">{key.notes}</p>
                </div>
              )}
              
              <div className="mt-3 flex items-center gap-2 text-xs text-silver">
                <span>Models:</span>
                {(key.model_access || ['gpt-4', 'gpt-3.5-turbo']).map(model => (
                  <Badge key={model} variant="outline" className="text-xs">
                    {model}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
        
        {keys.length === 0 && (
          <Card className="superman-card text-center py-12">
            <CardContent>
              <Key className="w-16 h-16 mx-auto mb-4 text-slate-600" />
              <h3 className="text-xl font-semibold text-white mb-2">No API Keys</h3>
              <p className="text-slate-400 mb-4">Add your first OpenAI API key to get started</p>
              <Button onClick={() => setIsDialogOpen(true)} className="btn-cyan">
                <Plus className="w-4 h-4 mr-2" />
                Add API Key
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}