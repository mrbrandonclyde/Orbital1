import { useState } from "react";
import { ChevronDown, ChevronRight, Database, FolderOpen, Network, Link, Gem } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function KnowledgeCore({ stats }) {
  const [open, setOpen] = useState({
    vault: true,
    storage: false,
    graph: false,
    links: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <Database className="w-5 h-5 text-cyan" />
            Knowledge Core
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className="bg-kryptonite-green/20 text-kryptonite border-kryptonite/30">
            ACTIVE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Manages all structured and unstructured data across the ecosystem.
        </p>

        {/* Performance Metrics */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-silver">Performance</span>
            <span className="text-cyan">{stats.metrics.performance}%</span>
          </div>
          <Progress value={stats.metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
          
          <div className="flex justify-between text-sm">
            <span className="text-silver">Memory Usage</span>
            <span className="text-amber">{stats.metrics.memory}%</span>
          </div>
          <Progress value={stats.metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
        </div>

        {/* Document Vault */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("vault")}
          >
            {open.vault ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            📄 Document Vault
          </button>
          {open.vault && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Documents Indexed: <span className="text-cyan font-bold">{stats.vault.toLocaleString()}</span></p>
              <p className="text-silver">Tagged Knowledge Files: <span className="text-cyan font-bold">Active</span></p>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online</p>
            </div>
          )}
        </div>

        {/* Object Storage */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("storage")}
          >
            {open.storage ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <FolderOpen className="w-3 h-3" />
            Object Storage
          </button>
          {open.storage && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              {stats.storage.map((folder, idx) => (
                <p key={idx} className="text-silver">/{folder}: <span className="text-cyan font-bold">Online</span></p>
              ))}
              <p className="flex items-center gap-1 text-kryptonite">All storage paths active</p>
            </div>
          )}
        </div>

        {/* Knowledge Graph */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("graph")}
          >
            {open.graph ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Network className="w-3 h-3" />
            Knowledge Graph
          </button>
          {open.graph && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Graph Entities: <span className="text-cyan font-bold">{stats.graphEntities.toLocaleString()}</span></p>
              <p className="text-silver">Relationships Mapped: <span className="text-cyan font-bold">Active</span></p>
              <p className="flex items-center gap-1 text-kryptonite">Status: Online</p>
            </div>
          )}
        </div>

        {/* Cross-Linking */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("links")}
          >
            {open.links ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Link className="w-3 h-3" />
            Cross-Linking
          </button>
          {open.links && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Active Links: <span className="text-cyan font-bold">{stats.links.toLocaleString()}</span></p>
              <p className="text-silver">Memory ↔ Documents: <span className="text-kryptonite font-bold">Connected</span></p>
              <p className="flex items-center gap-1 text-kryptonite">Cross-system linking active</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}