import React, { useRef, useEffect, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { Connection } from "./Connection"; // Assuming Connection.js exists and exports a React component

// Helper function to determine connection status based on performance
const getConnectionStatus = (performance) => {
  if (performance >= 95) return 'online';
  if (performance >= 80) return 'degraded';
  return 'offline';
};

// CoreNode component for individual cores
function CoreNode({ name, position, color, size, health, setHoveredCore, setMousePos }) {
  const mesh = useRef();
  const [isHovered, setIsHovered] = useState(false);
  const { gl } = useThree(); // Get WebGLRenderer instance to access its DOM element

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    // Base scale for pulsating, influenced by health
    const healthScale = 0.8 + (health / 100) * 0.4;
    const pulse = 1 + Math.sin(t * (health / 40 > 1 ? health / 40 : 1)) * 0.05; // Make pulsation speed slightly tied to health
    if (mesh.current) {
      mesh.current.scale.setScalar(pulse * healthScale);
      mesh.current.rotation.y += 0.005; // Small rotation
    }
  });

  return (
    <mesh
      position={position}
      ref={mesh}
      onPointerOver={(event) => {
        event.stopPropagation(); // Stop event propagation to avoid affecting other objects or controls
        setIsHovered(true);
        setHoveredCore({ name, health });
        // Calculate mouse position relative to the canvas
        const rect = gl.domElement.getBoundingClientRect();
        setMousePos({ x: event.clientX - rect.left, y: event.clientY - rect.top });
      }}
      onPointerOut={() => {
        setIsHovered(false);
        setHoveredCore(null);
      }}
    >
      <sphereGeometry args={[size, 32, 32]} />
      <meshStandardMaterial emissive={color} emissiveIntensity={isHovered ? 2.5 : 1.5} color={color} />
    </mesh>
  );
}

export default function CoreInterconnect3D({ stats }) {
  // State for hover effect on cores and tooltip position
  const [hoveredCore, setHoveredCore] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null); // Ref for the main container div

  // Cores data with fallback health values
  const cores = [
    { name: "Identity", pos: [-3, 2, 0], color: "#FFD700", health: stats.identity?.metrics?.performance || 99.1 },
    { name: "Memory", pos: [3, 2, 0], color: "#00FFFF", health: stats.memory?.metrics?.performance || 97.8 },
    { name: "Knowledge", pos: [-3, -2, 0], color: "#4169E1", health: stats.knowledge?.metrics?.performance || 98.5 },
    { name: "Automation", pos: [3, -2, 0], color: "#FF8C00", health: stats.automation?.metrics?.performance || 96.4 },
    { name: "Config", pos: [0, 0, 2], color: "#7A00FF", health: stats.config?.metrics?.performance || 99.8 },
    { name: "Governance", pos: [0, 0, -2], color: "#FF3131", health: stats.governance?.metrics?.performance || 99.5 },
  ];

  // Connections data with fallback performance values
  const connections = [
    { from: "Identity", to: "Memory", performance: stats.identity?.metrics?.performance || 99.1 },
    { from: "Memory", to: "Knowledge", performance: stats.memory?.metrics?.performance || 97.8 },
    { from: "Knowledge", to: "Automation", performance: stats.knowledge?.metrics?.performance || 98.5 },
    { from: "Automation", to: "Config", performance: stats.automation?.metrics?.performance || 96.4 },
    { from: "Config", to: "Governance", performance: stats.config?.metrics?.performance || 99.8 },
    { from: "Governance", to: "Identity", performance: stats.governance?.metrics?.performance || 99.5 },
    { from: "Identity", to: "Automation", performance: (stats.identity?.metrics?.performance + stats.automation?.metrics?.performance) / 2 || 97.7 },
    { from: "Memory", to: "Config", performance: (stats.memory?.metrics?.performance + stats.config?.metrics?.performance) / 2 || 98.9 },
    { from: "Knowledge", to: "Governance", performance: (stats.knowledge?.metrics?.performance + stats.governance?.metrics?.performance) / 2 || 99.0 }
  ];

  // Helper to get position of a core by name
  const getPos = (name) => cores.find(c => c.name === name)?.pos;

  // Calculate system status counts for legend based on connections data
  const statusCounts = connections.reduce((acc, conn) => {
    const status = getConnectionStatus(conn.performance);
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  // The useEffect hook is now simplified greatly as R3F handles the scene, camera, renderer, and animation loop.
  useEffect(() => {
    // No manual Three.js setup, animation loop, or event listeners needed here anymore.
    // R3F's Canvas component manages the WebGL context.
    // OrbitControls handles mouse interactions.
    // useFrame hook in child components handles animations.
    // Any remaining logic here would be for non-3D side effects.
    
    // Example: Clean up old DOM elements if they were manually appended
    // (Though for a component refactor, this is usually handled by React's lifecycle)
    return () => {
      // In a pure R3F setup, there's usually very little to clean up here
      // related to the Three.js scene itself, as Canvas handles it.
    };
  }, []); // Empty dependency array means this runs once on mount

  return (
    <div ref={containerRef} className="relative w-full h-[600px] bg-obsidian rounded-lg border border-cyan/30 overflow-hidden">
      <Canvas camera={{ position: [0, 0, 8], fov: 75, near: 0.1, far: 1000 }} className="w-full h-full">
        {/* Lighting */}
        <ambientLight intensity={0.5} />
        <pointLight position={[5, 5, 5]} intensity={1} />
        <pointLight position={[-5, -5, -5]} intensity={0.5} />

        {/* Core Nodes */}
        {cores.map((core, i) => (
          <CoreNode
            key={core.name} // Using core name as key for stability
            {...core}
            size={0.4}
            setHoveredCore={setHoveredCore}
            setMousePos={setMousePos}
          />
        ))}

        {/* Connections with packets */}
        {connections.map((conn, i) => {
          const startPos = getPos(conn.from);
          const endPos = getPos(conn.to);
          if (!startPos || !endPos) {
            console.warn(`Missing position for connection: ${conn.from} -> ${conn.to}`);
            return null;
          }
          return (
            <Connection
              key={i}
              start={startPos}
              end={endPos}
              status={getConnectionStatus(conn.performance)}
              performance={conn.performance}
            />
          );
        })}

        {/* OrbitControls for camera interaction */}
        <OrbitControls enableZoom={true} enablePan={true} />
      </Canvas>

      {/* Status Legend */}
      <div className="absolute top-4 right-4 bg-obsidian/90 border border-cyan/50 rounded-lg p-3 superman-card">
        <div className="text-gold font-bold text-sm mb-2">Data Flow Status</div>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-kryptonite"></div>
            <span className="text-kryptonite">Online ({statusCounts.online || 0})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-amber"></div>
            <span className="text-amber">Degraded ({statusCounts.degraded || 0})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-crimson"></div>
            <span className="text-crimson">Offline ({statusCounts.offline || 0})</span>
          </div>
        </div>
      </div>

      {/* Hovered Core Tooltip */}
      {hoveredCore && (
        <div
          className="absolute z-10 bg-obsidian/90 border border-cyan/50 rounded-lg p-3 pointer-events-none superman-card"
          style={{
            left: mousePos.x,
            top: mousePos.y - 10, // Offset to appear above cursor
            transform: 'translate(-50%, -100%)' // Center horizontally, position above
          }}
        >
          <div className="text-gold font-bold text-sm">{hoveredCore.name} Core</div>
          <div className="text-cyan text-xs">Health: {hoveredCore.health?.toFixed(1)}%</div>
        </div>
      )}

      {/* Info / Instructions */}
      <div className="absolute bottom-4 left-4 bg-obsidian/70 rounded-lg p-2 text-xs text-silver">
        🖱️ Drag to rotate • 🎯 Hover for details • ⚡ Live diagnostic streams
      </div>
    </div>
  );
}