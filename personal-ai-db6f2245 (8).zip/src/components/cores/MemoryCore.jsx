import { useState } from "react";
import { ChevronDown, ChevronRight, Brain, Gem, BookOpen, Workflow, Scissors } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const TrendIndicator = ({ trend }) => {
  if (trend === 'up') return <span className="text-kryptonite font-bold">↗</span>;
  if (trend === 'down') return <span className="text-crimson font-bold">↘</span>;
  return <span className="text-silver font-bold">→</span>;
};

export default function MemoryCore({ stats }) {
  const [open, setOpen] = useState({
    episodic: true,
    semantic: false,
    procedural: false,
    pruning: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <Brain className="w-5 h-5 text-cyan" />
            Memory Core
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className="bg-kryptonite-green/20 text-kryptonite border-kryptonite/30">
            ACTIVE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Manages short-term and long-term memory, learning, and recall.
        </p>

        {/* Performance Metrics */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-silver">Performance</span>
            <span className="text-cyan">{stats.metrics.performance}%</span>
          </div>
          <Progress value={stats.metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
          
          <div className="flex justify-between text-sm">
            <span className="text-silver">Memory Usage</span>
            <span className="text-amber">{stats.metrics.memory}%</span>
          </div>
          <Progress value={stats.metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
        </div>

        {/* Episodic Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("episodic")}
          >
            {open.episodic ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            🧠 Episodic (Events)
          </button>
          {open.episodic && (
            <div className="bg-obsidian-black/50 p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p>Sessions: <span className="text-cyan font-bold">{stats.episodic.sessions.toLocaleString()}</span></p>
              <p>Conversations: <span className="text-cyan font-bold">{stats.episodic.conversations.toLocaleString()}</span></p>
              <p>Events: <span className="text-cyan font-bold">{stats.episodic.events.toLocaleString()}</span> <TrendIndicator trend={stats.episodic.trend} /></p>
            </div>
          )}
        </div>

        {/* Semantic Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("semantic")}
          >
            {open.semantic ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <BookOpen className="w-3 h-3" />
            Semantic (Facts)
          </button>
          {open.semantic && (
            <div className="bg-obsidian-black/50 p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p>Facts: <span className="text-cyan font-bold">{stats.semantic.facts.toLocaleString()}</span></p>
              <p>Embeddings: <span className="text-cyan font-bold">{stats.semantic.embeddings.toLocaleString()}</span></p>
              <p>Usage: <span className="text-amber font-bold">{stats.semantic.usage}%</span> <TrendIndicator trend={stats.semantic.trend} /></p>
            </div>
          )}
        </div>
        
        {/* Procedural Memory */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("procedural")}
          >
            {open.procedural ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Workflow className="w-3 h-3" />
            Procedural (Skills)
          </button>
          {open.procedural && (
            <div className="bg-obsidian-black/50 p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p>Workflows: <span className="text-cyan font-bold">{stats.procedural.workflows}</span></p>
              <p>Success Rate: <span className="text-kryptonite font-bold">{stats.procedural.success_rate}%</span> <TrendIndicator trend={stats.procedural.trend} /></p>
            </div>
          )}
        </div>

        {/* Memory Pruning */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("pruning")}
          >
            {open.pruning ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Scissors className="w-3 h-3" />
            Memory Pruning
          </button>
          {open.pruning && (
            <div className="bg-obsidian-black/50 p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p>Priority: <span className="text-cyan font-bold">{stats.pruning.priority}</span></p>
              <p>Pruned Today: <span className="text-amber font-bold">{stats.pruning.pruned_today.toLocaleString()}</span></p>
              <p>High-Value Memories: <span className="text-gold font-bold">{stats.pruning.high_value.toLocaleString()}</span> <TrendIndicator trend={stats.pruning.trend} /></p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}