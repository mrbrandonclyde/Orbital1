import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from '@/components/ui/label';

export default function DocumentForm({ document, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    tags: ''
  });

  useEffect(() => {
    if (document) {
      setFormData({
        title: document.title,
        content: document.content,
        tags: (document.tags || []).join(', ')
      });
    } else {
      setFormData({ title: '', content: '', tags: '' });
    }
  }, [document]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const finalData = {
      ...formData,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean)
    };
    onSubmit(finalData);
  };

  return (
    <DialogContent className="obsidian-panel max-w-3xl">
      <DialogHeader>
        <DialogTitle className="text-gold">{document ? 'Edit Document' : 'Create New Document'}</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-6 py-4">
        <div className="space-y-2">
          <Label htmlFor="title" className="text-cyan">Title</Label>
          <Input
            id="title"
            placeholder="Document Title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="content" className="text-cyan">Content (Markdown)</Label>
          <Textarea
            id="content"
            placeholder="Start writing your document..."
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            className="h-64"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tags" className="text-cyan">Tags (comma-separated)</Label>
          <Input
            id="tags"
            placeholder="e.g., project-x, research, priority"
            value={formData.tags}
            onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" className="btn-cyan">
            {document ? 'Save Changes' : 'Create Document'}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}