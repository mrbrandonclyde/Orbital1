import React from "react";
import { motion } from "framer-motion";

export default function OrbitalGlobe({ darkMode = true }) {
  return (
    <div className="relative h-full w-full flex items-center justify-center">
      <div className="w-[400px] max-w-full aspect-square relative">
        {/* Main Globe */}
        <motion.div
          className="w-full h-full rounded-full border-2 border-[#2b2bc9] relative overflow-hidden"
          style={{
            background: 'radial-gradient(circle at 30% 30%, rgba(43, 43, 201, 0.2) 0%, rgba(0, 0, 0, 0.9) 100%)',
            boxShadow: '0 0 50px rgba(43, 43, 201, 0.6), inset 0 0 30px rgba(43, 43, 201, 0.2)'
          }}
          animate={{ 
            rotate: 360,
          }}
          transition={{ 
            duration: 20, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        >
          {/* Grid Lines */}
          <div className="absolute inset-0">
            {/* Horizontal lines */}
            {[...Array(8)].map((_, i) => (
              <div
                key={`h-${i}`}
                className="absolute left-0 right-0 border-t border-[#2b2bc9]/30"
                style={{ top: `${(i + 1) * 12.5}%` }}
              />
            ))}
            {/* Vertical lines */}
            {[...Array(12)].map((_, i) => (
              <div
                key={`v-${i}`}
                className="absolute top-0 bottom-0 border-l border-[#2b2bc9]/30"
                style={{ left: `${(i + 1) * 8.33}%` }}
              />
            ))}
          </div>
          
          {/* Glowing Dots */}
          <div className="absolute top-[20%] left-[30%] w-2 h-2 bg-[#2b2bc9] rounded-full shadow-[0_0_10px_#2b2bc9]" />
          <div className="absolute top-[40%] right-[25%] w-1.5 h-1.5 bg-blue-400 rounded-full shadow-[0_0_8px_#3b82f6]" />
          <div className="absolute bottom-[30%] left-[45%] w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_6px_#06b6d4]" />
          <div className="absolute top-[60%] left-[60%] w-1.5 h-1.5 bg-[#2b2bc9] rounded-full shadow-[0_0_8px_#2b2bc9]" />
          <div className="absolute top-[25%] right-[40%] w-1 h-1 bg-blue-300 rounded-full shadow-[0_0_6px_#93c5fd]" />
        </motion.div>

        {/* Outer Glow Ring */}
        <div 
          className="absolute inset-0 rounded-full border border-[#2b2bc9]/20"
          style={{
            boxShadow: '0 0 80px rgba(43, 43, 201, 0.4)'
          }}
        />
        
        {/* Pulsing Effect */}
        <motion.div
          className="absolute inset-0 rounded-full border border-[#2b2bc9]/40"
          animate={{
            scale: [1, 1.05, 1],
            opacity: [0.5, 0.8, 0.5]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{
            boxShadow: '0 0 60px rgba(43, 43, 201, 0.3)'
          }}
        />
      </div>
    </div>
  );
}