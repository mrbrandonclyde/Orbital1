import React from "react";

export default function CommandHistory({ commands = [] }) {
  return (
    <div className="bg-black/50 text-white rounded-lg p-3 h-48 overflow-y-auto text-sm border border-cyan-500/30">
      <h3 className="font-bold text-cyan-400 mb-2">Command History</h3>
      {commands.length === 0 && <p className="text-gray-400">No commands yet.</p>}
      <ul className="space-y-1">
        {commands.map((cmd, i) => (
          <li key={i} className="flex justify-between border-b border-gray-700/30 pb-1">
            <span>{cmd}</span>
            <span className="text-gray-500 text-xs">
              {new Date().toLocaleTimeString()}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}