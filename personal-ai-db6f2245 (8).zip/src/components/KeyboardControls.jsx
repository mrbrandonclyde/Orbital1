import React, { useEffect } from "react";

export default function KeyboardControls({ onCommand }) {
  useEffect(() => {
    const handler = (e) => {
      let cmd = null;
      if (e.key === "ArrowLeft") cmd = "rollback";
      if (e.key === "ArrowRight") cmd = "forward";
      if (e.key === " ") cmd = "playpause";

      if (cmd && onCommand) {
        e.preventDefault();
        onCommand(cmd);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onCommand]);

  return null; // No UI, just hotkeys
}