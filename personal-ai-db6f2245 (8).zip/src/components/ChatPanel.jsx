
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Send, Mic } from "lucide-react"; // Keep Mic as it's in imports
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ChatPanel({ onCommand, theme }) { // onClose prop removed based on outline
  const [messages, setMessages] = useState([
    { sender: "zyra", text: "🤖 Zyra temporal interface online. Ready for commands.", timestamp: new Date() },
    { sender: "system", text: "🎙 Voice recognition active. Try: 'jump to tomorrow' or 'pause timeline'", timestamp: new Date() }
  ]);
  const [input, setInput] = useState("");
  // isOrbital is no longer used as the component renders a single UI
  // const isOrbital = theme?.id === 'orbital'; // This line is now obsolete

  const sendMessage = () => {
    if (!input.trim()) return;
    
    const newMessage = { sender: "user", text: input, timestamp: new Date() };
    setMessages(prev => [...prev, newMessage]);

    if (onCommand) onCommand(input);
    
    setTimeout(() => {
      const response = { 
        sender: "zyra", 
        text: `⚡ Processing: "${input}"`, 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, response]);
    }, 500);

    setInput("");
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  // The component now renders a single UI structure, as per the provided outline.
  return (
    <div className="purple-glow-panel rounded-xl p-4 flex flex-col h-64">
      <h3 className="text-purple-300 font-semibold text-sm mb-2 flex items-center gap-2">
        <MessageSquare className="w-4 h-4" /> Command Interface
      </h3>
      <div className="flex-1 overflow-y-auto space-y-2 pr-2 text-sm">
          <AnimatePresence>
            {messages.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-2 rounded-lg max-w-[90%] ${
                  m.sender === "user"
                    ? "bg-blue-500/20 text-blue-200 ml-auto"
                    : "bg-gray-700/30 text-gray-300"
                }`}
              >
                {m.text}
              </motion.div>
            ))}
          </AnimatePresence>
      </div>
      <div className="mt-3 flex gap-2">
          <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Enter command..."
              className="flex-1 bg-black/50 border-[#3A3A6A] text-gray-300 placeholder:text-gray-500 focus:ring-blue-500"
          />
          <Button onClick={sendMessage} size="icon" className="bg-blue-600 hover:bg-blue-500 text-white">
              <Send className="w-4 h-4" />
          </Button>
          {/* Mic button removed based on the provided outline for the final UI structure */}
          {/* <Button size="icon" className="bg-gray-500/30 hover:bg-gray-500/40 text-gray-200 border border-gray-500/50">
              <Mic className="w-4 h-4" />
          </Button> */}
      </div>
    </div>
  );
}
