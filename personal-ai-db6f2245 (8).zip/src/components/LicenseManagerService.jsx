const STORAGE_KEY = "supermanos_license";
const SECRET = "SUPERMANOS_SECRET_KEY"; // replace with env var for production

async function getMachineId() {
  // Simple fingerprint using native Web Crypto API
  const ua = navigator.userAgent || "unknown";
  const lang = navigator.language || "en-US";
  const data = ua + lang;
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function encrypt(data) {
  // Simple base64 encoding (in production, use proper Web Crypto API encryption)
  return btoa(JSON.stringify(data));
}

function decrypt(ciphertext) {
  try {
    return JSON.parse(atob(ciphertext));
  } catch {
    return null;
  }
}

export const LicenseManager = {
  async activate(licenseKey, owner = "SupermanOS") {
    const machineId = await getMachineId();
    const license = {
      owner,
      licenseKey,
      machineId,
      activatedAt: new Date().toISOString(),
      lastValidated: new Date().toISOString(),
      usageLogs: [],
    };
    localStorage.setItem(STORAGE_KEY, await encrypt(license));
    return license;
  },

  async check() {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const license = decrypt(raw);
    if (!license) return null;

    // Verify machine binding
    const currentMachineId = await getMachineId();
    if (license.machineId !== currentMachineId) {
      console.warn("License invalid: machine mismatch");
      return null;
    }

    license.lastValidated = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, await encrypt(license));
    return license;
  },

  track(eventName) {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;

    const license = decrypt(raw);
    if (!license) return;

    license.usageLogs.push({
      event: eventName,
      timestamp: new Date().toISOString(),
    });

    // keep last 500 logs
    if (license.usageLogs.length > 500) {
      license.usageLogs = license.usageLogs.slice(-500);
    }

    localStorage.setItem(STORAGE_KEY, encrypt(license));
  },

  deactivate() {
    localStorage.removeItem(STORAGE_KEY);
  },
};