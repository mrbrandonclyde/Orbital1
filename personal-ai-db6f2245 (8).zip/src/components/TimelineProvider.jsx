
import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { LicenseManager } from "@/components/LicenseManagerService";

const TimelineContext = createContext(null);

export function TimelineProvider({ children }) {
  const [currentYear, setCurrentYear] = useState(2025);
  const [playing, setPlaying] = useState(false);
  const [history, setHistory] = useState([]);
  const [speed, setSpeed] = useState(1); // years per second
  const [branches, setBranches] = useState({ main: [] });
  const [activeBranch, setActiveBranch] = useState("main");
  const [forecast, setForecast] = useState([]);
  const [events, setEvents] = useState([]);
  const [checkpoints, setCheckpoints] = useState([]);
  const [temporalAnchors, setTemporalAnchors] = useState([]);
  const [quantumStates, setQuantumStates] = useState([]);
  const [causalityMap, setCausalityMap] = useState({});
  const [timelineSync, setTimelineSync] = useState(true);
  const [temporalLocks, setTemporalLocks] = useState([]);
  const [realitySnapshots, setRealitySnapshots] = useState([]);

  // Core Timeline Controls
  const rollback = useCallback((steps = 1) => {
    setCurrentYear((prev) => Math.max(1, prev - steps)); // Ensure year doesn't go below 1
    LicenseManager.track('TIMELINE_ROLLBACK');
  }, []); // currentYear removed as it's not directly used, setCurrentYear is stable

  const forward = useCallback((steps = 1) => {
    setCurrentYear((prev) => prev + steps);
    LicenseManager.track('TIMELINE_FORWARD');
  }, []); // currentYear removed as it's not directly used, setCurrentYear is stable

  // Renamed jumpTo to setYear as per outline
  const setYear = useCallback((year) => {
    if (typeof year === "number" && year >= 1) { // Ensure year is a positive number
      setCurrentYear(year);
      LicenseManager.track('TIMELINE_JUMP');
    }
  }, []); // currentYear removed as it's not directly used, setCurrentYear is stable

  const togglePlay = useCallback(() => setPlaying((p) => !p), []);
  const pause = useCallback(() => setPlaying(false), []);
  const play = useCallback(() => setPlaying(true), []);

  // Advanced Timeline Management
  const createCheckpoint = useCallback((name = `Checkpoint ${checkpoints.length + 1}`) => {
    const checkpoint = {
      id: `checkpoint-${Date.now()}`,
      name,
      timestamp: new Date().toISOString(),
      year: currentYear, // Changed from index and time
      branch: activeBranch,
      quantumState: quantumStates[quantumStates.length - 1] || null
    };
    setCheckpoints(prev => [...prev, checkpoint]);
    LicenseManager.track('CHECKPOINT_CREATE');
    return checkpoint;
  }, [checkpoints.length, currentYear, activeBranch, quantumStates]);

  const restoreCheckpoint = useCallback((checkpointId) => {
    const checkpoint = checkpoints.find(c => c.id === checkpointId);
    if (checkpoint) {
      setCurrentYear(checkpoint.year); // Changed from index and time
      setActiveBranch(checkpoint.branch);
    }
  }, [checkpoints]);

  const deleteCheckpoint = useCallback((checkpointId) => {
    setCheckpoints(prev => prev.filter(c => c.id !== checkpointId));
  }, []);

  // Branch Management
  const createBranch = useCallback((branchName) => {
    const newBranchName = branchName || `branch-${Date.now().toString().slice(-4)}`;
    setBranches(prev => ({
      ...prev,
      [newBranchName]: [{
        year: currentYear, // Changed from index and time
        parentBranch: activeBranch,
        createdAt: new Date().toISOString()
      }]
    }));
    setActiveBranch(newBranchName);
    LicenseManager.track('BRANCH_CREATE');
    return newBranchName;
  }, [currentYear, activeBranch]);

  const switchBranch = useCallback((branchName) => {
    if (branches[branchName]) {
      setActiveBranch(branchName);
      const latestState = branches[branchName][branches[branchName].length - 1];
      if (latestState) {
        setCurrentYear(latestState.year); // Changed from index and time
      }
    }
  }, [branches]);

  const mergeBranches = useCallback((sourceBranch, targetBranch) => {
    if (branches[sourceBranch] && branches[targetBranch]) {
      setBranches(prev => ({
        ...prev,
        [targetBranch]: [...prev[targetBranch], ...prev[sourceBranch]],
        [sourceBranch]: undefined
      }));
    }
  }, [branches]);

  const deleteBranch = useCallback((branchName) => {
    if (branchName !== "main") {
      setBranches(prev => {
        const newBranches = { ...prev };
        delete newBranches[branchName];
        return newBranches;
      });
      if (activeBranch === branchName) {
        setActiveBranch("main");
      }
    }
  }, [activeBranch]);

  // Temporal Anchoring
  const createTemporalAnchor = useCallback((name = `Anchor ${temporalAnchors.length + 1}`) => {
    const anchor = {
      id: `anchor-${Date.now()}`,
      name,
      year: currentYear, // Changed from index and time
      locked: false,
      strength: 100
    };
    setTemporalAnchors(prev => [...prev, anchor]);
    return anchor;
  }, [temporalAnchors.length, currentYear]);

  const lockTemporalAnchor = useCallback((anchorId) => {
    setTemporalAnchors(prev => prev.map(anchor =>
      anchor.id === anchorId ? { ...anchor, locked: true } : anchor
    ));
    setTemporalLocks(prev => [...prev, anchorId]);
  }, []);

  const unlockTemporalAnchor = useCallback((anchorId) => {
    setTemporalAnchors(prev => prev.map(anchor =>
      anchor.id === anchorId ? { ...anchor, locked: false } : anchor
    ));
    setTemporalLocks(prev => prev.filter(id => id !== anchorId));
  }, []);

  // Quantum State Management
  const captureQuantumState = useCallback(() => {
    const state = {
      id: `quantum-${Date.now()}`,
      timestamp: new Date().toISOString(),
      year: currentYear, // Changed from index and time
      branch: activeBranch,
      probability: Math.random() * 100,
      coherence: 85 + Math.random() * 15
    };
    setQuantumStates(prev => [...prev, state]);
    return state;
  }, [currentYear, activeBranch]);

  const collapseQuantumState = useCallback((stateId) => {
    const state = quantumStates.find(s => s.id === stateId);
    if (state) {
      setCurrentYear(state.year); // Changed from index and time
      setActiveBranch(state.branch);
    }
  }, [quantumStates]);

  // Reality Snapshots
  const takeRealitySnapshot = useCallback((name = `Snapshot ${realitySnapshots.length + 1}`) => {
    const snapshot = {
      id: `snapshot-${Date.now()}`,
      name,
      timestamp: new Date().toISOString(),
      year: currentYear, // Changed from index and time
      branch: activeBranch,
      checkpoints: [...checkpoints],
      anchors: [...temporalAnchors],
      quantumStates: [...quantumStates]
    };
    setRealitySnapshots(prev => [...prev, snapshot]);
    return snapshot;
  }, [realitySnapshots.length, currentYear, activeBranch, checkpoints, temporalAnchors, quantumStates]);

  const restoreRealitySnapshot = useCallback((snapshotId) => {
    const snapshot = realitySnapshots.find(s => s.id === snapshotId);
    if (snapshot) {
      setCurrentYear(snapshot.year); // Changed from index and time
      setActiveBranch(snapshot.branch);
      setCheckpoints(snapshot.checkpoints);
      setTemporalAnchors(snapshot.anchors);
      setQuantumStates(snapshot.quantumStates);
    }
  }, [realitySnapshots]);

  // Causality Analysis
  const analyzeCausality = useCallback((eventA, eventB) => {
    const correlation = Math.random() * 100;
    const causality = {
      correlation,
      strength: correlation > 70 ? "strong" : correlation > 40 ? "moderate" : "weak",
      direction: Math.random() > 0.5 ? "forward" : "backward",
      confidence: 70 + Math.random() * 30
    };
    setCausalityMap(prev => ({
      ...prev,
      [`${eventA}-${eventB}`]: causality
    }));
    return causality;
  }, []);

  // Forecasting
  const generateForecast = useCallback((steps = 10) => {
    const forecasts = [];
    for (let i = 1; i <= steps; i++) {
      const futureYear = currentYear + i;
      forecasts.push({
        year: futureYear, // Changed from index and time
        probability: Math.max(20, 100 - (i * 8)),
        events: [
          `Global climate shifts in ${futureYear}`,
          `Technological singularity approaches`,
          `New historical epoch begins`
        ].slice(0, Math.ceil(Math.random() * 3))
      });
    }
    setForecast(forecasts);
    return forecasts;
  }, [currentYear]);

  // Timeline Synchronization
  const syncTimelines = useCallback(() => {
    setTimelineSync(true);
    // Sync all branches to current year
    setBranches(prev => {
      const synced = {};
      Object.keys(prev).forEach(branch => {
        synced[branch] = prev[branch].map(state => ({
          ...state,
          syncedAt: new Date().toISOString()
        }));
      });
      return synced;
    });
  }, []);

  const desyncTimelines = useCallback(() => {
    setTimelineSync(false);
  }, []);

  // Temporal Debugging
  const debugTemporalState = useCallback(() => {
    return {
      year: currentYear, // Changed from currentIndex and currentTime
      activeBranch,
      totalBranches: Object.keys(branches).length,
      checkpoints: checkpoints.length,
      anchors: temporalAnchors.length,
      quantumStates: quantumStates.length,
      realitySnapshots: realitySnapshots.length,
      playing, // Changed from isPlaying
      speed
    };
  }, [currentYear, activeBranch, branches, checkpoints, temporalAnchors, quantumStates, realitySnapshots, playing, speed]);

  const resetTimeline = useCallback(() => {
    setCurrentYear(2025); // Reset to initial year 2025
    setPlaying(false);
    setActiveBranch("main");
    setBranches({ main: [] });
    setCheckpoints([]);
    setTemporalAnchors([]);
    setQuantumStates([]);
    setRealitySnapshots([]);
    setCausalityMap({});
    setTemporalLocks([]);
  }, []);

  useEffect(() => {
    let interval;
    if (playing) {
      interval = setInterval(() => {
        setCurrentYear((prev) => prev + 1 / (1000 / (100 * speed)));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [playing, speed]);

  const value = {
    // Basic controls
    currentYear,
    rollback,
    forward,
    setYear, // Changed from jumpTo
    togglePlay,
    play,
    pause,
    playing, // Changed from isPlaying
    
    // Time management
    speed,
    setSpeed,
    
    // Branch management
    branches,
    activeBranch,
    createBranch,
    switchBranch,
    mergeBranches,
    deleteBranch,
    
    // Advanced features
    checkpoints,
    createCheckpoint,
    restoreCheckpoint,
    deleteCheckpoint,
    
    temporalAnchors,
    createTemporalAnchor,
    lockTemporalAnchor,
    unlockTemporalAnchor,
    
    quantumStates,
    captureQuantumState,
    collapseQuantumState,
    
    realitySnapshots,
    takeRealitySnapshot,
    restoreRealitySnapshot,
    
    causalityMap,
    analyzeCausality,
    
    forecast,
    generateForecast,
    
    timelineSync,
    syncTimelines,
    desyncTimelines,
    
    temporalLocks,
    debugTemporalState,
    resetTimeline,
    
    // Legacy
    history,
    setHistory,
    events
  };

  return <TimelineContext.Provider value={value}>{children}</TimelineContext.Provider>;
}

export function useTimeline() {
  const ctx = useContext(TimelineContext);
  if (!ctx) throw new Error("useTimeline must be used within a TimelineProvider");
  return ctx;
}
