
import React, { useState } from "react";
import { ZyraIntegration } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Zap, Globe, Shield, RefreshCw, Power, PowerOff } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';

export default function IntegrationHub({ integrations = [], onRefresh }) {
  const [selectedIntegration, setSelectedIntegration] = useState(null);

  const getServiceIcon = (serviceType) => {
    const icons = {
      crm: Globe,
      financial: Shield,
      energy: Zap,
      communication: Globe,
      security: Shield,
      transport: Globe,
      iot: Settings
    };
    return icons[serviceType] || Settings;
  };

  const getStatusClasses = (status) => {
    const statuses = {
      active: 'bg-kryptonite/20 text-kryptonite border-kryptonite/30',
      inactive: 'bg-silver/20 text-silver border-silver/30',
      testing: 'bg-gold/20 text-gold border-gold/30',
      error: 'bg-crimson/20 text-crimson border-crimson/30'
    };
    return statuses[status] || statuses.inactive;
  };

  const handleStatusToggle = async (integration) => {
    if (!integration) return;
    const newStatus = integration.status === 'active' ? 'inactive' : 'active';
    await ZyraIntegration.update(integration.id, { 
      status: newStatus,
      last_sync: new Date().toISOString()
    });
    onRefresh();
    setSelectedIntegration({...integration, status: newStatus, last_sync: new Date().toISOString()});
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="superman-card">
        <CardHeader>
            <div className="flex justify-between items-center">
                <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="w-5 h-5 text-kryptonite" />
                    System Integrations
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={onRefresh} className="text-silver hover:text-white">
                    <RefreshCw className="w-4 h-4" />
                </Button>
            </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2">
            {integrations.map(integration => {
              const ServiceIcon = getServiceIcon(integration.service_type);
              return (
                <div
                  key={integration.id}
                  onClick={() => setSelectedIntegration(integration)}
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    selectedIntegration?.id === integration.id
                      ? 'bg-kryptonite/20 ring-1 ring-kryptonite'
                      : 'bg-black/20 hover:bg-kryptonite/10'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <ServiceIcon className="w-4 h-4 text-kryptonite" />
                      <h4 className="font-medium text-white text-sm">{integration.name}</h4>
                    </div>
                    <Badge className={getStatusClasses(integration.status)}>
                      {integration.status}
                    </Badge>
                  </div>
                  <p className="text-silver/80 text-xs capitalize">
                    {integration.service_type.replace('_', ' ')} • {integration.business_unit.replace('_', ' ')}
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="superman-card">
        <CardHeader>
          <CardTitle className="text-white">Integration Control Panel</CardTitle>
        </CardHeader>
        <CardContent>
          {selectedIntegration ? (
            <div className="space-y-4 text-white">
              <div>
                <h3 className="font-medium mb-2 text-lg">{selectedIntegration.name}</h3>
                <p className="text-silver/80 text-sm capitalize">
                  Service: {selectedIntegration.service_type.replace('_', ' ')}
                </p>
                <p className="text-silver/80 text-sm capitalize">
                  Business Unit: {selectedIntegration.business_unit.replace('_', ' ')}
                </p>
                {selectedIntegration.last_sync && (
                  <p className="text-silver/60 text-xs mt-2">
                    Last sync: {formatDistanceToNow(new Date(selectedIntegration.last_sync), { addSuffix: true })}
                  </p>
                )}
              </div>
              
              <Button
                onClick={() => handleStatusToggle(selectedIntegration)}
                className={selectedIntegration.status === 'active' 
                  ? 'bg-crimson/80 hover:bg-crimson text-white' 
                  : 'btn-kryptonite'}
              >
                {selectedIntegration.status === 'active' ? <PowerOff className="w-4 h-4 mr-2" /> : <Power className="w-4 h-4 mr-2" />}
                {selectedIntegration.status === 'active' ? 'Deactivate' : 'Activate'}
              </Button>

              <div className="pt-4">
                  <h4 className="font-semibold text-sm mb-2 text-silver">JSON Configuration</h4>
                  <pre className="bg-black/50 p-3 rounded-md text-xs text-silver/80 whitespace-pre-wrap">
                      {JSON.stringify(JSON.parse(selectedIntegration.configuration || '{}'), null, 2)}
                  </pre>
              </div>
            </div>
          ) : (
            <div className="text-center text-silver/60 py-16">
              <Settings className="w-16 h-16 mx-auto mb-4 text-silver/20" />
              <h3 className="text-lg font-semibold">Select an integration to configure</h3>
              <p className="text-sm">Activate, deactivate, and view configurations for your connected systems.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
