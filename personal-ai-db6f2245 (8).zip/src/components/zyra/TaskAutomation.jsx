
import React, { useState } from "react";
import { ZyraTask } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, CheckCircle2, Clock, AlertTriangle, Play, Pause, Trash2 } from "lucide-react";
import { format } from 'date-fns';

export default function TaskAutomation({ tasks, onRefresh }) {
  const [selectedTask, setSelectedTask] = useState(null);

  const handleStatusUpdate = async (task, newStatus) => {
    await ZyraTask.update(task.id, { status: newStatus });
    onRefresh();
    if(selectedTask && selectedTask.id === task.id) {
      setSelectedTask({...task, status: newStatus});
    }
  };

  const handleDelete = async (taskId) => {
    if (confirm('Are you sure you want to delete this automated task?')) {
      await ZyraTask.delete(taskId);
      onRefresh();
      if(selectedTask && selectedTask.id === taskId) {
        setSelectedTask(null);
      }
    }
  };

  const getPriorityClasses = (priority) => {
    const priorities = {
      critical: 'bg-crimson/20 text-crimson border-crimson/30',
      high: 'bg-amber-orange/20 text-amber-orange border-amber-orange/30',
      medium: 'bg-gold/20 text-gold border-gold/30',
      low: 'bg-cyan/20 text-cyan border-cyan/30'
    };
    return priorities[priority] || priorities.medium;
  };

  const getStatusIcon = (status) => {
    const icons = {
      pending: { icon: Clock, color: "text-silver/70" },
      in_progress: { icon: AlertTriangle, color: "text-gold" },
      completed: { icon: CheckCircle2, color: "text-kryptonite" },
      cancelled: { icon: Trash2, color: "text-crimson" }
    };
    return icons[status] || { icon: Clock, color: "text-silver/70" };
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="superman-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-cyan" />
            Task Automation Queue
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2">
            {tasks.map(task => {
              const { icon: StatusIcon, color } = getStatusIcon(task.status);
              return (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    selectedTask?.id === task.id
                      ? 'bg-cyan/20 ring-1 ring-cyan'
                      : 'bg-black/20 hover:bg-cyan/10'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-white text-sm">{task.title}</h4>
                    <Badge className={getPriorityClasses(task.priority)}>
                      {task.priority}
                    </Badge>
                  </div>
                  <p className="text-silver/80 text-xs line-clamp-2 mb-2">
                    {task.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <StatusIcon className={`w-4 h-4 ${color}`} />
                      <span className={`text-xs ${color} capitalize`}>{task.status.replace('_', ' ')}</span>
                    </div>
                    {task.due_date && (
                      <span className="text-xs text-silver/60">
                        Due: {new Date(task.due_date).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="superman-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-white">Task Control</CardTitle>
             {selectedTask && (
                <Button variant="ghost" size="icon" onClick={() => handleDelete(selectedTask.id)} className="text-crimson hover:bg-red-900/50">
                    <Trash2 className="w-4 h-4" />
                </Button>
             )}
          </div>
        </CardHeader>
        <CardContent>
          {selectedTask ? (
            <div className="space-y-4 text-white">
              <div>
                <h3 className="font-medium mb-2 text-lg">{selectedTask.title}</h3>
                <p className="text-silver/80 text-sm">{selectedTask.description}</p>
              </div>

              <div className="flex flex-wrap gap-2">
                  <Badge className={getPriorityClasses(selectedTask.priority)}>{selectedTask.priority}</Badge>
                  <Badge variant="outline" className="border-silver/30 capitalize text-silver">{selectedTask.status.replace('_', ' ')}</Badge>
                  {selectedTask.due_date && <Badge variant="outline" className="border-silver/30 text-silver">{`Due: ${format(new Date(selectedTask.due_date), "PP")}`}</Badge>}
                  <Badge variant="outline" className="border-silver/30 capitalize text-silver">{selectedTask.business_unit?.replace('_', ' ') || 'General'}</Badge>
              </div>
              
              <div className="pt-4 space-x-2">
                <Button
                  size="sm"
                  onClick={() => handleStatusUpdate(selectedTask, 'in_progress')}
                  className="bg-gold/80 hover:bg-gold text-black"
                  disabled={selectedTask.status === 'in_progress' || selectedTask.status === 'completed'}
                >
                  <Play className="w-4 h-4 mr-2"/> Start
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleStatusUpdate(selectedTask, 'pending')}
                  className="bg-amber-orange/80 hover:bg-amber-orange text-black"
                  disabled={selectedTask.status !== 'in_progress'}
                >
                  <Pause className="w-4 h-4 mr-2"/> Pause
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleStatusUpdate(selectedTask, 'completed')}
                  className="btn-kryptonite"
                  disabled={selectedTask.status === 'completed'}
                >
                  <CheckCircle2 className="w-4 h-4 mr-2"/> Complete
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center text-silver/60 py-16">
              <Calendar className="w-16 h-16 mx-auto mb-4 text-silver/20" />
              <h3 className="text-lg font-semibold">Select a task to view details</h3>
              <p className="text-sm">Manage and monitor automated tasks across your ecosystem.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
