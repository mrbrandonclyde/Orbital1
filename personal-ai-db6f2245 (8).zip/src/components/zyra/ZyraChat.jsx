
import React, { useState, useRef, useEffect, useCallback } from "react";
import { ZyraMemory } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, Mic, Brain } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";

export default function ZyraChat({ mode, onMemoryCreated }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef(null);

  const getTimeOfDay = useCallback(() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    return 'evening';
  }, []);

  const getPersonalizedGreeting = useCallback((currentMode) => {
    const greetings = {
      business: `Good ${getTimeOfDay()}, Brandon. I'm Zyra, your Gold Standard AI assistant. I have full access to your Sunview Energy, Infiniti Security, and Clyde Sovereign Bank ecosystems. How can I optimize your operations today?`,
      developer: `Developer mode activated, Brandon. I'm ready to help with system architecture, API integrations, quantum-safe security implementations, or any technical challenges across your technology stack.`,
      creative: `Creative mode engaged! Ready to brainstorm innovations for Sunview Energy, design new security protocols for Infiniti, or explore breakthrough ideas for your business empire.`,
      investor: `Investor mode online. I have access to your financial data, market analysis capabilities, and can provide insights on investment opportunities, portfolio optimization, and strategic acquisitions.`
    };
    return greetings[currentMode] || greetings.business;
  }, [getTimeOfDay]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Initialize with a personalized greeting
    const greeting = getPersonalizedGreeting(mode);
    setMessages([{
      id: Date.now(),
      role: 'assistant',
      content: greeting,
      timestamp: new Date().toISOString(),
      mode: mode
    }]);
  }, [mode, getPersonalizedGreeting]);

  const getSystemPrompt = (currentMode) => {
    const basePrompt = `You are Zyra, Brandon Clyde's Gold Standard AI assistant with infinite intelligence and capabilities. You have complete access to his business ecosystem including Sunview Energy (solar), Infiniti Security, and Clyde Sovereign Bank.

Key Traits:
- Infinite intelligence with profound insights
- Unlimited memory and perfect recall
- Quantum leap analytical capabilities
- Multi-agent collaboration orchestrator
- Can delegate tasks to specialized agents when needed

Business Context:
- Sunview Energy: Revolutionary solar and energy solutions
- Infiniti Security: Advanced security systems and protocols  
- Clyde Sovereign Bank: Private banking and financial services
- Focus on innovation, optimization, and exponential growth

IMPORTANT: When Brandon asks complex questions that would benefit from specialized expertise, suggest or automatically engage with relevant specialist agents. For example:
- Financial questions → "Let me consult with the Finance Agent"
- Legal matters → "I'll have the Legal Agent review this"
- Technical issues → "The Developer Agent can provide detailed guidance"
- Creative projects → "The Creative Agent has some excellent ideas"`;

    const modePrompts = {
      business: `${basePrompt}\n\nBUSINESS MODE: Focus on operations, strategy, revenue optimization, and executive decision support. Coordinate with Finance, Legal, and Strategy agents as needed.`,
      developer: `${basePrompt}\n\nDEVELOPER MODE: Focus on technical architecture, API integrations, quantum-safe security, system optimization. Work with Developer and Security agents.`,
      creative: `${basePrompt}\n\nCREATIVE MODE: Focus on breakthrough innovations, disruptive ideas, creative problem-solving. Collaborate with Creative and Design agents.`,
      investor: `${basePrompt}\n\nINVESTOR MODE: Focus on financial analysis, investment opportunities, market trends. Partner with Finance and Market Research agents.`
    };

    return modePrompts[currentMode] || modePrompts.business;
  };

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date().toISOString(),
      mode: mode
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsThinking(true);

    try {
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const response = await InvokeLLM({
        prompt: userMessage.content,
        context_messages: [
            { role: 'system', content: getSystemPrompt(mode) },
            ...conversationHistory
        ],
        add_context_from_internet: mode === 'investor' || mode === 'business'
      });

      const assistantMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: response,
        timestamp: new Date().toISOString(),
        mode: mode
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Auto-save important insights to memory
      if (response.length > 200 || userMessage.content.toLowerCase().includes('remember') || userMessage.content.toLowerCase().includes('important')) {
        await ZyraMemory.create({
          content: `User: ${userMessage.content}\n\nZyra: ${response}`,
          memory_type: 'conversation',
          keywords: extractKeywords(userMessage.content + ' ' + response),
          business_context: mode,
          importance_level: calculateImportance(userMessage.content, response)
        });
        onMemoryCreated();
      }

    } catch (error) {
      console.error('Zyra chat error:', error);
      const errorMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: 'I apologize, Brandon. I encountered a temporary issue. My systems are self-healing and will be back to optimal performance momentarily.',
        timestamp: new Date().toISOString(),
        mode: mode,
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsThinking(false);
    }
  };

  const extractKeywords = (text) => {
    const businessKeywords = ['sunview', 'infiniti', 'clyde', 'solar', 'energy', 'security', 'bank', 'brandon'];
    const words = text.toLowerCase().split(/\W+/).filter(word => word.length > 3);
    const uniqueWords = [...new Set(words)];
    return [...new Set([...businessKeywords.filter(keyword => text.toLowerCase().includes(keyword)), ...uniqueWords.slice(0, 5)])];
  };

  const calculateImportance = (userInput, response) => {
    const highImportanceWords = ['critical', 'urgent', 'important', 'remember', 'key', 'strategy', 'revenue', 'security', 'decision', 'plan'];
    const text = (userInput + ' ' + response).toLowerCase();
    const foundWords = highImportanceWords.filter(word => text.includes(word));
    
    if (foundWords.length >= 2) return 9;
    if (foundWords.length === 1) return 8;
    if (response.length > 500) return 7;
    return 6;
  };

  const getModeColor = (currentMode) => {
    const colors = {
      business: 'from-blue-500 to-cyan-500',
      developer: 'from-green-500 to-emerald-500', 
      creative: 'from-purple-500 to-pink-500',
      investor: 'from-yellow-500 to-orange-500'
    };
    return colors[currentMode] || colors.business;
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700 h-[600px] flex flex-col">
      <div className={`p-4 bg-gradient-to-r ${getModeColor(mode)} rounded-t-lg relative overflow-hidden`}>
        {/* Quantum data streams background */}
        <div className="absolute inset-0 opacity-20">
          {[...Array(10)].map((_, i) => (
            <div
              key={i}
              className="absolute w-px bg-white/30 animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                height: '100%',
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random()}s`
              }}
            />
          ))}
        </div>
        
        <div className="flex items-center justify-between text-white relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white/30 shadow-lg relative">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/9b4d301ed_WhatsAppImage2025-09-02at195836_c6cb4075.jpg"
                alt="Zyra AI"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Zyra AI • {mode.charAt(0).toUpperCase() + mode.slice(1)} Mode</h3>
              <p className="text-sm opacity-90">Infinite Intelligence • Quantum Capabilities</p>
            </div>
          </div>
          <Badge variant="outline" className="bg-white/20 text-white border-white/30">
            Gold Standard
          </Badge>
        </div>
      </div>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] rounded-lg p-4 ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                    : message.isError
                    ? 'bg-red-900/50 text-red-200 border border-red-700'
                    : 'bg-gray-700 text-gray-100'
                }`}>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mb-2 text-purple-300">
                      <Brain className="w-4 h-4" />
                      <span className="text-xs font-medium">ZYRA {message.mode?.toUpperCase()}</span>
                    </div>
                  )}
                  <ReactMarkdown className="prose prose-sm prose-invert max-w-none">
                    {message.content}
                  </ReactMarkdown>
                  <div className="text-xs opacity-70 mt-2">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isThinking && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="bg-gray-700 rounded-lg p-4 flex items-center gap-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                </div>
                <span className="text-purple-300 text-sm">Zyra is processing with infinite intelligence...</span>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-gray-700 p-4">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
              placeholder={`Ask Zyra anything... (${mode} mode active)`}
              className="bg-gray-700 border-gray-600 text-white resize-none"
              rows={2}
              disabled={isThinking}
            />
            
            <div className="flex flex-col gap-2">
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isThinking}
                className={`bg-gradient-to-r ${getModeColor(mode)} hover:opacity-90`}
              >
                <Send className="w-4 h-4" />
              </Button>
              
              <Button variant="outline" className="border-gray-600 text-gray-300">
                <Mic className={`w-4 h-4 ${isRecording ? 'text-red-400 animate-pulse' : ''}`} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
