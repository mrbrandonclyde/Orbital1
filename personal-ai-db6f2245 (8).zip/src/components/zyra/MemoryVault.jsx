
import React, { useState } from "react";
import { ZyraMemory } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Search, Brain, Star, Trash2, Edit, Plus, X, Tag } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDistanceToNow } from 'date-fns';

const MemoryForm = ({ memory, onFinished }) => {
  const [formData, setFormData] = useState(
    memory || {
      content: '',
      memory_type: 'insight',
      keywords: [],
      business_context: 'general',
      importance_level: 5
    }
  );
  const [keywordInput, setKeywordInput] = useState('');

  const handleKeywordKeyDown = (e) => {
    if (e.key === 'Enter' && keywordInput.trim()) {
      e.preventDefault();
      if (!formData.keywords.includes(keywordInput.trim())) {
        setFormData(prev => ({ ...prev, keywords: [...prev.keywords, keywordInput.trim()] }));
      }
      setKeywordInput(''); // Fixed typo: was keywordInput('')
    }
  };

  const removeKeyword = (keywordToRemove) => {
    setFormData(prev => ({
      ...prev,
      keywords: prev.keywords.filter(k => k !== keywordToRemove)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (memory?.id) {
      await ZyraMemory.update(memory.id, formData);
    } else {
      await ZyraMemory.create(formData);
    }
    onFinished();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="text-sm font-medium text-silver">Content</label>
        <Textarea
          value={formData.content}
          onChange={e => setFormData({ ...formData, content: e.target.value })}
          placeholder="Memory content..."
          className="h-32 mt-1" // Removed specific bg/border classes
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-medium text-silver">Type</label>
          <Select value={formData.memory_type} onValueChange={v => setFormData({ ...formData, memory_type: v })}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger> {/* Removed specific bg/border classes */}
            <SelectContent>
              <SelectItem value="conversation">Conversation</SelectItem>
              <SelectItem value="insight">Insight</SelectItem>
              <SelectItem value="task">Task</SelectItem>
              <SelectItem value="document">Document</SelectItem>
              <SelectItem value="integration">Integration</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm font-medium text-silver">Business Unit</label>
          <Select value={formData.business_context} onValueChange={v => setFormData({ ...formData, business_context: v })}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger> {/* Removed specific bg/border classes */}
            <SelectContent>
              <SelectItem value="sunview_energy">Sunview Energy</SelectItem>
              <SelectItem value="infiniti_security">Infiniti Security</SelectItem>
              <SelectItem value="clyde_bank">Clyde Sovereign Bank</SelectItem>
              <SelectItem value="personal">Personal</SelectItem>
              <SelectItem value="general">General</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div>
        <label className="text-sm font-medium text-silver">Keywords</label>
        <div className="flex flex-wrap gap-2 mt-1 p-2 rounded-md border border-cyan/30 bg-black/20">
            {formData.keywords.map(kw => (
              <Badge key={kw} variant="secondary" className="flex items-center gap-1 bg-cyan/20 text-cyan border-cyan/30">
                {kw}
                <button type="button" onClick={() => removeKeyword(kw)} className="ml-1"><X className="w-3 h-3" /></button>
              </Badge>
            ))}
            <Input
              value={keywordInput}
              onChange={e => setKeywordInput(e.target.value)}
              onKeyDown={handleKeywordKeyDown}
              placeholder="Add tag..."
              className="flex-1 bg-transparent border-none focus:ring-0 p-0 h-auto"
            />
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-silver">Importance (1-10)</label>
        <Input
          type="number"
          min="1"
          max="10"
          value={formData.importance_level}
          onChange={e => setFormData({ ...formData, importance_level: parseInt(e.target.value) })}
          className="mt-1" // Removed specific bg/border classes
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onFinished}>Cancel</Button>
        <Button type="submit" className="btn-cyan">{memory?.id ? 'Update Memory' : 'Create Memory'}</Button>
      </div>
    </form>
  );
};

export default function MemoryVault({ memories, onRefresh }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMemory, setSelectedMemory] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMemory, setEditingMemory] = useState(null);

  const filteredMemories = memories.filter(memory =>
    memory.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (memory.keywords || []).some(keyword => keyword.toLowerCase().includes(searchQuery.toLowerCase()))
  ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  const handleDelete = async (memoryId) => {
    if (confirm('Are you sure you want to delete this memory? This action cannot be undone.')) {
      await ZyraMemory.delete(memoryId);
      onRefresh();
      if (selectedMemory?.id === memoryId) {
        setSelectedMemory(null);
      }
    }
  };

  const handleOpenForm = (memory = null) => {
    setEditingMemory(memory);
    setIsFormOpen(true);
  };

  const onFormFinished = () => {
    setIsFormOpen(false);
    setEditingMemory(null);
    onRefresh();
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card className="superman-card h-full">
          <CardHeader>
            <div className="flex justify-between items-center">
                <CardTitle className="text-white flex items-center gap-2">
                  <Brain className="w-5 h-5 text-cyan" />
                  Memory Vault
                </CardTitle>
                <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
                    <DialogTrigger asChild>
                        <Button variant="ghost" size="icon" onClick={() => handleOpenForm(null)} className="text-cyan hover:bg-cyan/20 hover:text-cyan">
                          <Plus className="w-4 h-4" />
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="obsidian-panel">
                        <DialogHeader>
                            <DialogTitle className="text-gold">{editingMemory ? 'Edit Memory' : 'Create New Memory'}</DialogTitle>
                        </DialogHeader>
                        <MemoryForm memory={editingMemory} onFinished={onFormFinished} />
                    </DialogContent>
                </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-silver" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search memories..."
                  className="pl-10" // Removed specific bg/border/text classes
                />
              </div>
              
              <div className="space-y-2 max-h-[450px] overflow-y-auto pr-2">
                {filteredMemories.map(memory => (
                  <div
                    key={memory.id}
                    onClick={() => setSelectedMemory(memory)}
                    className={`p-3 rounded-lg cursor-pointer transition-all ${
                      selectedMemory?.id === memory.id
                        ? 'bg-cyan/20 ring-1 ring-cyan'
                        : 'bg-black/20 hover:bg-cyan/10'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <Badge variant="outline" className="text-xs text-purple-300 border-purple-400/50 capitalize bg-purple-900/30">
                        {memory.memory_type}
                      </Badge>
                      <span className="text-xs text-silver/60">
                        {formatDistanceToNow(new Date(memory.created_date), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-silver text-sm line-clamp-2">
                      {memory.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2">
        <Card className="superman-card h-full">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-white">Memory Details</CardTitle>
              {selectedMemory && (
                <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleOpenForm(selectedMemory)}
                      className="text-cyan hover:text-cyan hover:bg-cyan/20"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(selectedMemory.id)}
                      className="text-crimson hover:text-crimson hover:bg-red-900/50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {selectedMemory ? (
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                    <Badge className="bg-cyan/20 text-cyan border border-cyan/30 capitalize">
                      {selectedMemory.business_context?.replace('_', ' ') || 'general'}
                    </Badge>
                    <Badge variant="secondary" className="flex items-center gap-1 bg-gold/20 text-gold border border-gold/30">
                      <Star className="w-3 h-3 text-gold" />
                      Importance: {selectedMemory.importance_level}
                    </Badge>
                  </div>
                <div className="prose prose-invert prose-sm max-w-none text-silver bg-black/30 p-4 rounded-md whitespace-pre-wrap">
                  {selectedMemory.content}
                </div>
                {(selectedMemory.keywords || []).length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold mb-2 text-silver">Keywords</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedMemory.keywords.map((keyword, i) => (
                        <Badge key={i} variant="outline" className="text-silver border-silver/30 flex items-center gap-1">
                          <Tag className="w-3 h-3" />
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center text-silver/60 py-16">
                <Brain className="w-16 h-16 mx-auto mb-4 text-silver/20" />
                <h3 className="text-lg font-semibold">Select a memory to view details</h3>
                <p className="text-sm">The vault holds all important information Zyra has processed.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
