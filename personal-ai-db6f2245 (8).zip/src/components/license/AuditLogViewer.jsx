import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RefreshCw, Search, Download, Filter, Shield, AlertTriangle, Info, XCircle, FileText } from "lucide-react";
import { format } from "date-fns";

export default function AuditLogViewer({ auditLogs, onRefresh }) {
    const [searchQuery, setSearchQuery] = useState('');
    const [filterSeverity, setFilterSeverity] = useState('all');
    const [filterAction, setFilterAction] = useState('all');

    const filteredLogs = auditLogs.filter(log => {
        const matchesSearch = !searchQuery || 
            log.user_email.toLowerCase().includes(searchQuery.toLowerCase()) ||
            log.target_email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            log.details.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesSeverity = filterSeverity === 'all' || log.severity === filterSeverity;
        const matchesAction = filterAction === 'all' || log.action === filterAction;
        
        return matchesSearch && matchesSeverity && matchesAction;
    });

    const severityIcons = {
        info: Info,
        warning: AlertTriangle,
        error: XCircle,
        critical: Shield
    };

    const severityClasses = {
        info: "text-cyan bg-cyan/10 border-cyan/20",
        warning: "text-amber bg-amber-orange/10 border-amber-orange/20",
        error: "text-crimson bg-crimson-red/10 border-crimson-red/20",
        critical: "text-red-400 bg-red-500/10 border-red-500/20"
    };

    const actionTypes = [...new Set(auditLogs.map(log => log.action))];

    const exportLogs = () => {
        const csv = [
            ['Timestamp', 'Action', 'User', 'Target', 'Details', 'Severity', 'IP Address'].join(','),
            ...filteredLogs.map(log => [
                log.created_date,
                log.action,
                log.user_email,
                log.target_email || '',
                `"${log.details.replace(/"/g, '""')}"`,
                log.severity,
                log.ip_address || ''
            ].join(','))
        ].join('\n');
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `audit_logs_${format(new Date(), 'yyyy-MM-dd')}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <Card className="superman-card">
            <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <CardTitle className="text-white flex items-center gap-2 text-xl">
                        <FileText className="w-6 h-6 text-cyan" />
                        Global Audit Log
                    </CardTitle>
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={exportLogs}>
                            <Download className="w-4 h-4 mr-2" />
                            Export CSV
                        </Button>
                        <Button variant="ghost" size="icon" onClick={onRefresh} className="text-slate-400 hover:text-white">
                            <RefreshCw className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
                
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4 mt-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search logs by email, action, or details..."
                            className="pl-10"
                        />
                    </div>
                    
                    <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                        <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Severity" /></SelectTrigger>
                        <SelectContent><SelectItem value="all">All Severity</SelectItem><SelectItem value="info">Info</SelectItem><SelectItem value="warning">Warning</SelectItem><SelectItem value="error">Error</SelectItem><SelectItem value="critical">Critical</SelectItem></SelectContent>
                    </Select>

                    <Select value={filterAction} onValueChange={setFilterAction}>
                        <SelectTrigger className="w-full sm:w-48"><SelectValue placeholder="Action" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Actions</SelectItem>
                            {actionTypes.map(action => (
                                <SelectItem key={action} value={action}>
                                    {action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </CardHeader>
            
            <CardContent>
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                    {filteredLogs.map(log => {
                        const SeverityIcon = severityIcons[log.severity] || Info;
                        return (
                            <div key={log.id} className="flex items-start gap-4 p-4 superman-card rounded-lg hover:border-cyan/50 transition-colors">
                                <div className={`p-2 rounded-full ${severityClasses[log.severity]}`}>
                                    <SeverityIcon className="w-5 h-5" />
                                </div>
                                
                                <div className="flex-1 min-w-0">
                                    <div className="flex flex-wrap items-center gap-2 mb-1">
                                        <Badge variant="outline" className="text-xs">
                                            {log.action.replace('_', ' ').toUpperCase()}
                                        </Badge>
                                        <Badge className={`text-xs ${severityClasses[log.severity]}`}>
                                            {log.severity.toUpperCase()}
                                        </Badge>
                                    </div>
                                    
                                    <p className="text-white text-sm font-medium mb-1">{log.details}</p>
                                    
                                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400">
                                        <span>User: {log.user_email}</span>
                                        {log.target_email && <span>Target: {log.target_email}</span>}
                                        {log.ip_address && <span>IP: {log.ip_address}</span>}
                                    </div>
                                </div>
                                
                                <div className="text-right text-xs text-slate-400">
                                    <p>{format(new Date(log.created_date), 'MMM d, yyyy')}</p>
                                    <p>{format(new Date(log.created_date), 'HH:mm:ss')}</p>
                                </div>
                            </div>
                        );
                    })}
                    
                    {filteredLogs.length === 0 && (
                        <div className="text-center py-12 text-slate-500">
                            <FileText className="w-12 h-12 mx-auto mb-4" />
                            <p>No audit logs found matching your filters</p>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}