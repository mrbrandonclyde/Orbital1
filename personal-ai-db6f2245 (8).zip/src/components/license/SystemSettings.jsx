import React, { useState, useEffect } from "react";
import { AppConfig } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings, Save, Loader2, CheckCircle, AlertTriangle } from "lucide-react";
import { format } from "date-fns";

export default function SystemSettings({ onLogAction }) {
    const [configs, setConfigs] = useState({
        stripe_enabled: 'false', backup_enabled: 'true', email_notifications: 'true',
        phone_masking: 'false', auto_git_commit: 'false', webhook_url: ''
    });
    const [isSaving, setIsSaving] = useState(false);
    const [lastSaved, setLastSaved] = useState(null);

    useEffect(() => { loadConfigs(); }, []);

    const loadConfigs = async () => {
        try {
            const configList = await AppConfig.list();
            const configMap = {};
            configList.forEach(config => { configMap[config.config_key] = config.config_value; });
            setConfigs(prev => ({...prev, ...configMap}));
        } catch (error) { console.error('Error loading configs:', error); }
    };

    const saveConfig = async (key, value) => {
        try {
            const existing = await AppConfig.filter({ config_key: key });
            if (existing.length > 0) {
                await AppConfig.update(existing[0].id, { config_value: value.toString() });
            } else {
                await AppConfig.create({ config_key: key, config_value: value.toString(), description: `Config for ${key}` });
            }
        } catch (error) { console.error(`Error saving config ${key}:`, error); }
    };

    const handleSaveAll = async () => {
        setIsSaving(true);
        try {
            await Promise.all(Object.entries(configs).map(([key, value]) => saveConfig(key, value)));
            await onLogAction('settings_changed', 'System configuration updated', null, 'info');
            setLastSaved(new Date());
        } catch (error) { console.error('Error saving settings:', error); } finally {
            setIsSaving(false);
        }
    };

    const systemStatus = [
        { name: 'Payment Gateway', status: configs.stripe_enabled === 'true' },
        { name: 'Auto Backup', status: configs.backup_enabled === 'true' },
        { name: 'Email Notifications', status: configs.email_notifications === 'true' }
    ];

    return (
        <div className="space-y-6">
            <Card className="superman-card">
                <CardHeader><CardTitle className="text-white">System Status</CardTitle></CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {systemStatus.map(item => (
                            <div key={item.name} className={`flex items-center gap-3 p-3 rounded-lg ${item.status ? 'metric-green' : 'metric-orange'}`}>
                                {item.status ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                                <div>
                                    <p className="font-medium">{item.name}</p>
                                    <p className="text-xs opacity-80">{item.status ? 'ACTIVE' : 'INACTIVE'}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="superman-card">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2 text-xl">
                            <Settings className="w-6 h-6 text-purple" />
                            Configuration
                        </CardTitle>
                        <Button onClick={handleSaveAll} disabled={isSaving} className="btn-cyan">
                            <div className="flex items-center justify-center">{isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />} Save Settings</div>
                        </Button>
                    </div>
                    {lastSaved && <p className="text-sm text-kryptonite mt-2">Last saved: {format(lastSaved, 'MMM d, yyyy HH:mm:ss')}</p>}
                </CardHeader>
                <CardContent className="space-y-6 pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-6">
                            <div className="flex items-center justify-between"><div className="pr-4"><Label className="text-silver">Stripe Integration</Label><p className="text-xs text-slate-400">Enable automatic payment processing</p></div><Switch checked={configs.stripe_enabled === 'true'} onCheckedChange={(c) => setConfigs({...configs, stripe_enabled: c.toString()})} /></div>
                            <div className="flex items-center justify-between"><div className="pr-4"><Label className="text-silver">Auto Backup</Label><p className="text-xs text-slate-400">Daily backup of license data</p></div><Switch checked={configs.backup_enabled === 'true'} onCheckedChange={(c) => setConfigs({...configs, backup_enabled: c.toString()})} /></div>
                            <div className="flex items-center justify-between"><div className="pr-4"><Label className="text-silver">Email Notifications</Label><p className="text-xs text-slate-400">Send license emails to customers</p></div><Switch checked={configs.email_notifications === 'true'} onCheckedChange={(c) => setConfigs({...configs, email_notifications: c.toString()})} /></div>
                        </div>
                        <div className="space-y-6">
                            <div className="flex items-center justify-between"><div className="pr-4"><Label className="text-silver">Phone Masking</Label><p className="text-xs text-slate-400">Hide phone numbers in exports</p></div><Switch checked={configs.phone_masking === 'true'} onCheckedChange={(c) => setConfigs({...configs, phone_masking: c.toString()})} /></div>
                            <div className="flex items-center justify-between"><div className="pr-4"><Label className="text-silver">Auto Git Commit</Label><p className="text-xs text-slate-400">Commit changes to git automatically</p></div><Switch checked={configs.auto_git_commit === 'true'} onCheckedChange={(c) => setConfigs({...configs, auto_git_commit: c.toString()})} /></div>
                            <div className="space-y-2"><Label htmlFor="webhook_url" className="text-silver">Webhook URL</Label><Input id="webhook_url" value={configs.webhook_url} onChange={(e) => setConfigs({...configs, webhook_url: e.target.value})} placeholder="https://your-domain.com/webhook" /></div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}