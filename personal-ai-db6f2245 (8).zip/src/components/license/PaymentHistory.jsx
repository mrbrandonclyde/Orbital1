import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Search, Download, RefreshCw } from "lucide-react";
import { format } from "date-fns";

export default function PaymentHistory({ payments, onRefresh }) {
    const [searchQuery, setSearchQuery] = useState('');

    const filteredPayments = payments.filter(payment =>
        payment.customer_email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        payment.stripe_payment_id.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const statusClasses = {
        pending: "text-amber-orange bg-amber-orange/10 border-amber-orange/20",
        completed: "text-kryptonite bg-kryptonite-green/10 border-kryptonite-green/20",
        failed: "text-crimson bg-crimson-red/10 border-crimson-red/20",
        refunded: "text-silver bg-silver-gray/10 border-silver-gray/20"
    };

    const tierClasses = {
        basic: "bg-slate-600 text-slate-200",
        professional: "bg-blue-600 text-white",
        enterprise: "bg-purple-600 text-white",
        unlimited: "bg-gold-600 text-black",
    };

    const exportPayments = () => {
        const csv = [
            ['Date', 'Customer Email', 'Amount', 'Currency', 'License Tier', 'Seats', 'Status', 'Stripe ID'].join(','),
            ...filteredPayments.map(payment => [
                payment.created_date,
                payment.customer_email,
                payment.amount / 100,
                payment.currency,
                payment.license_tier,
                payment.seats,
                payment.status,
                payment.stripe_payment_id
            ].join(','))
        ].join('\n');
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `payment_history_${format(new Date(), 'yyyy-MM-dd')}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <Card className="superman-card">
            <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <CardTitle className="text-white flex items-center gap-2 text-xl">
                        <CreditCard className="w-6 h-6 text-kryptonite" />
                        Payment History
                    </CardTitle>
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={exportPayments}>
                            <Download className="w-4 h-4 mr-2" />
                            Export CSV
                        </Button>
                        <Button variant="ghost" size="icon" onClick={onRefresh} className="text-slate-400 hover:text-white">
                            <RefreshCw className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
                
                <div className="relative mt-4">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by email or Stripe ID..."
                        className="pl-10"
                    />
                </div>
            </CardHeader>
            
            <CardContent>
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                    {filteredPayments.map(payment => (
                        <div key={payment.id} className="flex items-center justify-between p-4 superman-card rounded-lg hover:border-cyan/50">
                            <div className="flex-1">
                                <p className="text-white font-medium">{payment.customer_email}</p>
                                <p className="text-slate-400 text-sm truncate">ID: {payment.stripe_payment_id}</p>
                                <div className="flex gap-2 mt-2">
                                    <Badge className={`capitalize ${tierClasses[payment.license_tier]}`}>{payment.license_tier}</Badge>
                                    <Badge className={`capitalize ${statusClasses[payment.status]}`}>{payment.status}</Badge>
                                </div>
                            </div>
                            
                            <div className="text-right ml-4">
                                <p className="text-white text-lg font-bold">
                                    ${(payment.amount / 100).toFixed(2)}
                                    <span className="text-sm text-slate-400 ml-1">{payment.currency.toUpperCase()}</span>
                                </p>
                                <p className="text-slate-400 text-sm">
                                    {format(new Date(payment.created_date), 'MMM d, yyyy HH:mm')}
                                </p>
                                <p className="text-slate-300 text-xs mt-1">{payment.seats} seats</p>
                            </div>
                        </div>
                    ))}
                    
                    {filteredPayments.length === 0 && (
                        <div className="text-center py-12 text-slate-500">
                            <CreditCard className="w-12 h-12 mx-auto mb-4" />
                            <p>No payment records found</p>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}