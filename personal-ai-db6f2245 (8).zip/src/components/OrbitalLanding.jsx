import React from "react";

export default function OrbitalLanding() {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full px-6 py-10">
      {/* Hero Section */}
      <div className="max-w-3xl">
        <h1 className="text-5xl font-extrabold tracking-tight text-cyan-300 mb-4">
          Connect your world <span style={{color: '#2b2bc9'}}>with precision</span>
        </h1>
        <p className="text-lg text-gray-300 mb-8">
          Build, track, and manage your projects with a seamless platform designed for modern teams.
        </p>
        <div className="flex justify-center gap-4">
          <button className="px-6 py-3 rounded-lg bg-cyan-500 hover:bg-cyan-600 text-white font-semibold shadow-lg">
            Get started
          </button>
          <button 
            className="px-6 py-3 rounded-lg text-white font-semibold shadow-lg transition-colors duration-200"
            style={{backgroundColor: '#2b2bc9'}}
            onMouseEnter={(e) => e.target.style.backgroundColor = '#1e1e8f'}
            onMouseLeave={(e) => e.target.style.backgroundColor = '#2b2bc9'}
          >
            View demo
          </button>
        </div>
      </div>

      {/* Globe Placeholder */}
      <div className="mt-10 w-full max-w-4xl">
        <div 
          className="aspect-square w-full rounded-full border border-cyan-500/40 shadow-[0_0_60px_#00ffff] flex items-center justify-center"
          style={{background: 'radial-gradient(ellipse at center, rgba(43, 43, 201, 0.2) 0%, rgba(6, 182, 212, 0.2) 50%, rgba(59, 130, 246, 0.2) 100%)'}}
        >
          <span className="text-cyan-300 text-xl">🌐 Globe Animation Placeholder</span>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-gray-200">
        <div><p className="text-2xl font-bold text-cyan-300">1000000000%</p><p>Faster Acceleration</p></div>
        <div><p className="text-2xl font-bold text-cyan-300">10k+</p><p>Global users</p></div>
        <div><p className="text-2xl font-bold text-cyan-300">24/7</p><p>Support available</p></div>
        <div><p className="text-2xl font-bold text-cyan-300">99.9%</p><p>Uptime guarantee</p></div>
      </div>
    </div>
  );
}