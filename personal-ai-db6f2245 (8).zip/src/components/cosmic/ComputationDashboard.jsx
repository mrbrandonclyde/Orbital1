import React, { useState } from 'react';
import { ComputationJob } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Zap, CheckCircle, Clock, Microscope, Atom, Brain, Rocket, Globe, Network, Cpu } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ComputationDashboard({ projects, activeJobs, onRefresh }) {
  const [selectedJob, setSelectedJob] = useState(null);

  const jobIcons = {
    molecular_dynamics: Microscope,
    quantum_simulation: Atom,
    climate_model: Globe,
    neural_network: Brain,
    graph_analysis: Network,
    optimization: Cpu
  };

  const statusColors = {
    running: 'text-blue-400',
    completed: 'text-green-400',
    failed: 'text-red-400',
    queued: 'text-yellow-400'
  };

  const completedJobs = projects.flatMap(p => 
    p.jobs?.filter(j => j.status === 'completed') || []
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <Card className="bg-slate-800/70 border-slate-700/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center gap-2 text-white"><Zap className="w-5 h-5 text-blue-400" />Active Computations</CardTitle>
              <CardDescription>Real-time status of running jobs.</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onRefresh}><RefreshCw className="w-4 h-4" /></Button>
          </CardHeader>
          <CardContent>
            {activeJobs && activeJobs.length > 0 ? (
              <div className="space-y-3">
                {activeJobs.map(job => {
                  const Icon = jobIcons[job.job_type] || Cpu;
                  return (
                    <div key={job.id} className="flex items-center justify-between p-3 rounded-md bg-slate-700/50">
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="font-medium text-white">{job.job_name}</p>
                          <p className="text-xs text-slate-400 capitalize">{job.job_type.replace('_', ' ')}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="w-4 h-4 text-blue-400" />
                        <span className="text-blue-300">Running</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : <p className="text-slate-400 text-center py-4">No active computation jobs.</p>}
          </CardContent>
        </Card>

        <Card className="bg-slate-800/70 border-slate-700/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white"><CheckCircle className="w-5 h-5 text-green-400" />Completed Jobs</CardTitle>
            <CardDescription>History of recent computation jobs.</CardDescription>
          </CardHeader>
          <CardContent>
             {/* This part needs to be adapted based on how jobs are related to projects */}
             <p className="text-slate-400 text-center py-4">Completed jobs view coming soon.</p>
          </CardContent>
        </Card>
      </div>

      <Card className="lg:col-span-1 bg-slate-800/70 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-white">Result Viewer</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[400px]">
          {selectedJob ? (
            <div className="text-left w-full p-4 bg-slate-900/70 rounded-md">
              <pre className="text-xs text-slate-300 whitespace-pre-wrap">
                {JSON.stringify(selectedJob.output_data, null, 2)}
              </pre>
            </div>
          ) : (
            <div className="text-center text-slate-500">
              <Cpu className="w-12 h-12 mx-auto mb-4" />
              <p>Select a completed job to view its results.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}