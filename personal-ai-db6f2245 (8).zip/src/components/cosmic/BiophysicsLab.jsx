import React, { useState } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { ComputationJob } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Microscope, Dna } from 'lucide-react';
import { Label } from '@/components/ui/label';

export default function BiophysicsLab({ onJobSubmit }) {
    const [isLoading, setIsLoading] = useState(false);
    const [jobName, setJobName] = useState('Protein Folding Simulation');
    const [proteinSequence, setProteinSequence] = useState('MGSSHHHHHHSSGLVPRGSH');

    const handleSubmit = async () => {
        setIsLoading(true);
        try {
            // Simulate a complex biophysics task using the LLM
            const prompt = `Simulate the protein folding for the sequence: ${proteinSequence}. 
            Provide a detailed report including:
            1.  Predicted 3D Structure (describe key features)
            2.  Ramachandran Plot Analysis
            3.  Energy Minimization Results
            4.  Potential Biological Functions
            5.  Confidence Score`;

            const result = await InvokeLLM({ prompt });

            await ComputationJob.create({
                job_name: jobName,
                job_type: 'molecular_dynamics',
                parameters: JSON.stringify({ sequence: proteinSequence }),
                status: 'completed',
                output_data: JSON.stringify({ report: result })
            });

            onJobSubmit();
        } catch (error) {
            console.error("Biophysics simulation failed", error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card className="superman-card border-kryptonite/30">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl text-kryptonite"><Microscope className="w-6 h-6" />Biophysics Lab</CardTitle>
                <CardDescription className="text-slate-400">Simulate complex biological systems like protein folding and molecular dynamics.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="jobName" className="text-slate-300">Job Name</Label>
                    <Input id="jobName" value={jobName} onChange={e => setJobName(e.target.value)} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="proteinSequence" className="flex items-center gap-2 text-slate-300"><Dna className="w-4 h-4" />Protein Sequence (FASTA format)</Label>
                    <Textarea id="proteinSequence" value={proteinSequence} onChange={e => setProteinSequence(e.target.value)} className="h-24 font-mono" />
                </div>
                <Button onClick={handleSubmit} disabled={isLoading} className="w-full btn-kryptonite">
                    {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Microscope className="w-4 h-4 mr-2" />}
                    {isLoading ? 'Running Simulation...' : 'Start Protein Folding Simulation'}
                </Button>
            </CardContent>
        </Card>
    );
}