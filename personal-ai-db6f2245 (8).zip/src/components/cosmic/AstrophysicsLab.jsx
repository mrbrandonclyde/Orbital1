import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Rocket } from 'lucide-react';

export default function AstrophysicsLab() {
    return (
        <Card className="superman-card border-silver/30">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl text-silver"><Rocket className="w-6 h-6" />Astrophysics Lab</CardTitle>
                <CardDescription className="text-slate-400">Simulate celestial mechanics, analyze astronomical data, and explore cosmological models.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-slate-400">This lab module is under development. Coming soon: N-body simulations, orbital mechanics, and analysis of stellar spectra.</p>
            </CardContent>
        </Card>
    );
}