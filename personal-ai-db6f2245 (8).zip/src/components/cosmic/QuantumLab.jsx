import React, { useState } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { ComputationJob } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Atom, Cpu, Beaker, Wand2 } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const quantumSDKs = [
    { id: 'qiskit', name: 'Qiskit (IBM)', icon: Cpu },
    { id: 'cirq', name: 'Cirq (Google)', icon: Cpu },
    { id: 'qutip', name: 'QuTiP', icon: Beaker },
    { id: 'azure', name: 'Azure Quantum (Q#)', icon: Cpu },
    { id: 'tensorcircuit', name: 'TensorCircuit', icon: Wand2 },
    { id: 'classiq', name: 'Classiq', icon: Cpu },
];

export default function QuantumLab({ onJobSubmit }) {
    const [isLoading, setIsLoading] = useState(false);
    const [jobName, setJobName] = useState('H2O Ground State');
    const [sdk, setSdk] = useState('qiskit');
    const [qubits, setQubits] = useState('20');
    const [problemType, setProblemType] = useState('quantum_chemistry');
    const [details, setDetails] = useState('Calculate the ground state energy of a water molecule using a Variational Quantum Eigensolver (VQE).');

    const handleSubmit = async () => {
        setIsLoading(true);
        try {
            const prompt = `
Act as a quantum computation simulator. The user has submitted a job with the following parameters:
- SDK/Framework: ${quantumSDKs.find(s => s.id === sdk)?.name || sdk}
- Problem Type: ${problemType.replace('_', ' ')}
- Number of Qubits: ${qubits}
- Problem Details: "${details}"

Generate a detailed and realistic simulation report. The report must include:
1.  **Job Summary**: A brief overview of the task.
2.  **Algorithm Selection**: Justify the choice of quantum algorithm (e.g., VQE, QAOA, Grover's) for the given problem.
3.  **Circuit Design**: A text-based description of the quantum circuit structure, including gate types and layout.
4.  **Simulated Results**: Provide simulated measurement outcomes, energy levels, or other relevant data. Be specific.
5.  **Performance Analysis**: Comment on simulated execution time, coherence, and potential sources of noise or error.
6.  **Conclusion**: A summary of the findings.

Format the entire output as a professional markdown report.`;

            const result = await InvokeLLM({ prompt });

            await ComputationJob.create({
                job_name: jobName,
                job_type: 'quantum_simulation',
                parameters: JSON.stringify({ 
                    sdk: sdk,
                    qubits: parseInt(qubits, 10),
                    problem_type: problemType,
                    details: details 
                }),
                status: 'completed',
                output_data: JSON.stringify({ report: result })
            });

            onJobSubmit();
        } catch (error) {
            console.error("Quantum simulation failed", error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card className="superman-card border-cyan/30">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl text-cyan">
                    <Atom className="w-8 h-8" />
                    Quantum Simulation Lab
                </CardTitle>
                <CardDescription className="text-slate-400">Configure and run advanced quantum computing simulations based on industry-standard frameworks.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2">
                    <Label htmlFor="quantumJobName" className="text-slate-300">Job Name</Label>
                    <Input id="quantumJobName" value={jobName} onChange={e => setJobName(e.target.value)} placeholder="e.g., Quantum Chemistry H2O"/>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="sdk" className="text-slate-300">Quantum SDK/Framework</Label>
                        <Select value={sdk} onValueChange={setSdk}>
                            <SelectTrigger id="sdk">
                                <SelectValue placeholder="Select a framework" />
                            </SelectTrigger>
                            <SelectContent className="superman-card">
                                {quantumSDKs.map(s => (
                                    <SelectItem key={s.id} value={s.id}>
                                        <div className="flex items-center gap-2">
                                            <s.icon className="w-4 h-4" />
                                            {s.name}
                                        </div>
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="qubits" className="text-slate-300">Number of Qubits</Label>
                        <Input id="qubits" type="number" value={qubits} onChange={e => setQubits(e.target.value)} placeholder="e.g., 20"/>
                    </div>
                </div>

                <div className="space-y-2">
                    <Label htmlFor="problemType" className="text-slate-300">Problem Type</Label>
                    <Select value={problemType} onValueChange={setProblemType}>
                        <SelectTrigger id="problemType">
                            <SelectValue placeholder="Select a problem type" />
                        </SelectTrigger>
                        <SelectContent className="superman-card">
                            <SelectItem value="quantum_chemistry">Quantum Chemistry</SelectItem>
                            <SelectItem value="optimization">Optimization (QAOA)</SelectItem>
                            <SelectItem value="search">Search (Grover's)</SelectItem>
                            <SelectItem value="machine_learning">Machine Learning (QML)</SelectItem>
                            <SelectItem value="custom">Custom Algorithm</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                <div className="space-y-2">
                    <Label htmlFor="quantumProblem" className="text-slate-300">Problem Details</Label>
                    <Textarea id="quantumProblem" value={details} onChange={e => setDetails(e.target.value)} className="h-24" placeholder="Provide a detailed description of the quantum problem to simulate..."/>
                </div>

                <Button onClick={handleSubmit} disabled={isLoading} className="w-full btn-cyan text-lg py-6">
                    {isLoading ? <Loader2 className="w-6 h-6 mr-2 animate-spin" /> : <Atom className="w-6 h-6 mr-2"/>}
                    {isLoading ? 'Executing on Quantum Simulator...' : 'Run Quantum Simulation'}
                </Button>
            </CardContent>
        </Card>
    );
}