import React, { useState } from "react";
import { useTimeline } from "@/components/TimelineProvider";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Brain, Sparkles, TestTube, Save, Upload, RotateCcw, Zap, 
  GitBranch, TrendingUp, Settings, ChevronDown, ChevronUp,
  Play, Pause, Download, Shield, Layout, Palette, MapPin, Upload as ExportIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export default function TemporalConsole({ settings = {}, onToggle }) {
  const { createCheckpoint, branches, activeBranch, createBranch } = useTimeline();
  const [activeTheme, setActiveTheme] = useState("superman");
  const [showBranches, setShowBranches] = useState(false);
  const [showAutomation, setShowAutomation] = useState(false);

  const themes = [
    { id: "superman", name: "SupermanOS", icon: Brain },
    { id: "zyra", name: "Zyra Gold", icon: Sparkles },
    { id: "cosmic", name: "Cosmic Lab", icon: TestTube },
  ];

  return (
    <aside className="w-80 flex-shrink-0 flex flex-col">
      {/* Translucent Glass Panel */}
      <div className="m-4 rounded-2xl bg-black/20 backdrop-blur-xl border border-cyan/20 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-cyan/20">
          <h2 className="text-xl font-bold text-cyan flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Temporal Console
          </h2>
          <p className="text-xs text-silver/80 mt-1">System Control Interface</p>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[calc(100vh-300px)]">
          
          {/* Branch Manager */}
          <div className="group">
            <button
              onClick={() => setShowBranches(!showBranches)}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-cyan/5 border border-cyan/10 hover:bg-cyan/10 hover:border-cyan/20 transition-all duration-300"
            >
              <div className="flex items-center gap-3">
                <GitBranch className="w-5 h-5 text-cyan" />
                <span className="text-cyan font-semibold">Branch Manager</span>
              </div>
              {showBranches ? <ChevronUp className="w-4 h-4 text-silver/60" /> : <ChevronDown className="w-4 h-4 text-silver/60" />}
            </button>

            <AnimatePresence>
              {showBranches && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-2 overflow-hidden"
                >
                  <div className="p-3 rounded-lg bg-black/30 border border-cyan/10">
                    <div className="text-sm text-silver/80 mb-2">Active: <span className="text-cyan font-bold">{activeBranch}</span></div>
                    <div className="text-sm text-silver/80 mb-3">Total Branches: <span className="text-cyan">{Object.keys(branches).length}</span></div>
                    <Button
                      onClick={() => createBranch(`Branch-${Date.now()}`)}
                      size="sm"
                      className="w-full bg-cyan/10 text-cyan border border-cyan/20 hover:bg-cyan/20 hover:border-cyan/30"
                    >
                      <GitBranch className="w-4 h-4 mr-2" />
                      Create New Branch
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Prediction Engine */}
          <div className="p-4 rounded-xl bg-purple/5 border border-purple/10 hover:bg-purple/10 hover:border-purple/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-purple" />
                <span className="text-purple font-semibold">Prediction Engine</span>
              </div>
              <Switch
                checked={settings.prediction}
                onCheckedChange={(checked) => onToggle?.('prediction', checked)}
              />
            </div>
            {settings.prediction && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-3 p-2 rounded-lg bg-purple/10 border border-purple/20"
              >
                <p className="text-xs text-purple/80">🧠 Neural forecasting active</p>
              </motion.div>
            )}
          </div>

          {/* Event Markers */}
          <div className="p-4 rounded-xl bg-amber/5 border border-amber/10 hover:bg-amber/10 hover:border-amber/20 transition-all duration-300">
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-amber" />
              <span className="text-amber font-semibold">Event Markers</span>
            </div>
            <p className="text-xs text-amber/80 mt-2">Timeline event visualization</p>
          </div>

          {/* Layout */}
          <div className="p-4 rounded-xl bg-gold/5 border border-gold/10 hover:bg-gold/10 hover:border-gold/20 transition-all duration-300">
            <div className="flex items-center gap-3">
              <Layout className="w-5 h-5 text-gold" />
              <span className="text-gold font-semibold">Layout</span>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <Button
                onClick={() => createCheckpoint()}
                size="sm"
                className="bg-gold/10 text-gold border border-gold/20 hover:bg-gold/20"
              >
                <Save className="w-4 h-4 mr-1"/> Save
              </Button>
              <Button
                size="sm"
                className="bg-gold/10 text-gold border border-gold/20 hover:bg-gold/20"
              >
                <Upload className="w-4 h-4 mr-1"/> Load
              </Button>
            </div>
          </div>

          {/* Themes */}
          <div className="p-4 rounded-xl bg-kryptonite/5 border border-kryptonite/10 hover:bg-kryptonite/10 hover:border-kryptonite/20 transition-all duration-300">
            <div className="flex items-center gap-3 mb-3">
              <Palette className="w-5 h-5 text-kryptonite" />
              <span className="text-kryptonite font-semibold">Themes</span>
            </div>
            <div className="space-y-2">
              {themes.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => setActiveTheme(theme.id)}
                  className={`w-full p-2 rounded-lg text-left transition-all flex items-center gap-2 text-sm ${
                    activeTheme === theme.id
                      ? "bg-kryptonite/20 text-kryptonite border border-kryptonite/30"
                      : "bg-black/20 hover:bg-kryptonite/10 text-silver/80 border border-transparent hover:border-kryptonite/20"
                  }`}
                >
                  <theme.icon className="w-4 h-4"/>
                  <span>{theme.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Automation */}
          <div className="group">
            <button
              onClick={() => setShowAutomation(!showAutomation)}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-silver/5 border border-silver/10 hover:bg-silver/10 hover:border-silver/20 transition-all duration-300"
            >
              <div className="flex items-center gap-3">
                <Zap className="w-5 h-5 text-silver" />
                <span className="text-silver font-semibold">Automation</span>
              </div>
              {showAutomation ? <ChevronUp className="w-4 h-4 text-silver/60" /> : <ChevronDown className="w-4 h-4 text-silver/60" />}
            </button>

            <AnimatePresence>
              {showAutomation && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-2 overflow-hidden"
                >
                  <div className="p-3 rounded-lg bg-black/30 border border-silver/10">
                    <Button
                      size="sm"
                      className="w-full bg-silver/10 text-silver border border-silver/20 hover:bg-silver/20"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Auto-Mode
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Export */}
          <div className="p-4 rounded-xl bg-crimson/5 border border-crimson/10 hover:bg-crimson/10 hover:border-crimson/20 transition-all duration-300">
            <Button
              size="sm"
              className="w-full bg-crimson/10 text-crimson border border-crimson/20 hover:bg-crimson/20 flex items-center gap-2"
            >
              <ExportIcon className="w-4 h-4" />
              Export
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
}