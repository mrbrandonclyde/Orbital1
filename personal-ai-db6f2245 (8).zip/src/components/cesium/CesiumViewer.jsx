
import React, { useEffect, useRef } from 'react';

const CesiumViewer = ({ locations, alerts, targetLocation }) => {
  const cesiumContainer = useRef(null);
  const viewerRef = useRef(null);

  // Initialize Viewer
  useEffect(() => {
    if (cesiumContainer.current && window.Cesium && !viewerRef.current) {
      const viewer = new window.Cesium.Viewer(cesiumContainer.current, {
        animation: false,
        baseLayerPicker: false,
        fullscreenButton: false,
        geocoder: false,
        homeButton: false,
        infoBox: false,
        sceneModePicker: false,
        selectionIndicator: false,
        timeline: false,
        navigationHelpButton: false,
        shouldAnimate: true,
        skyAtmosphere: new window.Cesium.SkyAtmosphere(),
      });
      
      viewer.scene.globe.enableLighting = true;
      viewer.scene.screenSpaceCameraController.maximumZoomDistance = 40000000;
      viewer.scene.screenSpaceCameraController.minimumZoomDistance = 1000;

      viewerRef.current = viewer;
    }

    return () => {
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, []);

  // Update Data Points
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewer) return;

    viewer.entities.removeAll();

    // Add Business Locations
    locations.forEach(loc => {
      viewer.entities.add({
        position: window.Cesium.Cartesian3.fromDegrees(loc.lon, loc.lat),
        billboard: {
          image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/45610d407_icons8-command-center-64.png', // A custom icon
          width: 32,
          height: 32,
          color: window.Cesium.Color.CYAN.withAlpha(0.9),
          scaleByDistance: new window.Cesium.NearFarScalar(1.5e2, 2.0, 1.5e7, 0.5)
        },
        label: {
          text: loc.name,
          font: '12pt monospace',
          style: window.Cesium.LabelStyle.FILL_AND_OUTLINE,
          outlineWidth: 2,
          verticalOrigin: window.Cesium.VerticalOrigin.BOTTOM,
          pixelOffset: new window.Cesium.Cartesian2(0, -30)
        }
      });
    });

    // Add Fire Alerts
    alerts.forEach(alert => {
      viewer.entities.add({
        position: window.Cesium.Cartesian3.fromDegrees(alert.lon, alert.lat),
        point: {
          pixelSize: Math.max(5, alert.confidence / 10),
          color: window.Cesium.Color.ORANGERED.withAlpha(0.8),
          outlineColor: window.Cesium.Color.YELLOW.withAlpha(0.5),
          outlineWidth: 2
        }
      });
    });

  }, [locations, alerts]);

  // Fly to Target Location
  useEffect(() => {
    const viewer = viewerRef.current;
    if (viewer && targetLocation) {
      viewer.camera.flyTo({
        destination: window.Cesium.Cartesian3.fromDegrees(targetLocation.lon, targetLocation.lat, 200000), // Zoom in to 200km altitude
        duration: 3.5, // Cinematic flight time
        easingFunction: window.Cesium.EasingFunction.QUARTIC_IN_OUT,
      });
    }
  }, [targetLocation]);

  return <div ref={cesiumContainer} className="w-full h-full" />;
};

export default CesiumViewer;
