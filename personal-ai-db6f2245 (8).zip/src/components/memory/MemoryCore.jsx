import React, { useState, useEffect } from 'react';
import { EpisodicMemory } from '@/api/entities';
import { SemanticMemory } from '@/api/entities';
import { ProceduralMemory } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Brain, Clock, Database, Zap, TrendingUp, Activity } from 'lucide-react';

export default function MemoryCore() {
  const [episodicMemories, setEpisodicMemories] = useState([]);
  const [semanticMemories, setSemanticMemories] = useState([]);
  const [proceduralMemories, setProceduralMemories] = useState([]);
  const [memoryStats, setMemoryStats] = useState({
    totalMemories: 0,
    storageUsed: 2.4, // GB
    pruningThreshold: 85,
    recallEfficiency: 94.7
  });

  useEffect(() => {
    loadMemoryData();
  }, []);

  const loadMemoryData = async () => {
    const [episodic, semantic, procedural] = await Promise.all([
      EpisodicMemory.list('-created_date', 10),
      SemanticMemory.list('-usage_count', 10),
      ProceduralMemory.list('-execution_count', 10)
    ]);
    
    setEpisodicMemories(episodic);
    setSemanticMemories(semantic);
    setProceduralMemories(procedural);
    
    setMemoryStats(prev => ({
      ...prev,
      totalMemories: episodic.length + semantic.length + procedural.length
    }));
  };

  const executeAdaptivePruning = async () => {
    // Simulate adaptive pruning algorithm
    console.log('Executing adaptive pruning...');
    // In real implementation, this would:
    // 1. Analyze recall patterns
    // 2. Score memories by importance
    // 3. Archive low-value memories
    // 4. Optimize storage
  };

  const MemoryTypeCard = ({ icon: Icon, title, memories, color, description }) => (
    <Card className="bg-slate-800/70 border-slate-700/50">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center`}>
            <Icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <CardTitle className="text-white">{title}</CardTitle>
            <p className="text-sm text-slate-400">{description}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-slate-400">Active Memories</span>
            <span className="text-white font-mono">{memories.length.toLocaleString()}</span>
          </div>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {memories.slice(0, 3).map((memory, index) => (
              <div key={index} className="text-xs bg-slate-900/50 p-2 rounded">
                <p className="text-slate-300 truncate">
                  {memory.content || memory.context || memory.name}
                </p>
                <div className="flex justify-between mt-1">
                  <span className="text-slate-500">
                    {new Date(memory.created_date).toLocaleDateString()}
                  </span>
                  {memory.recall_count !== undefined && (
                    <Badge variant="outline" className="text-xs">
                      {memory.recall_count} recalls
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Memory System Overview */}
      <Card className="bg-slate-800/70 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            Memory Core System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-white">{memoryStats.totalMemories.toLocaleString()}</p>
              <p className="text-sm text-slate-400">Total Memories</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-white">{memoryStats.storageUsed} GB</p>
              <p className="text-sm text-slate-400">Storage Used</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-white">{memoryStats.recallEfficiency}%</p>
              <p className="text-sm text-slate-400">Recall Efficiency</p>
            </div>
            <div className="text-center">
              <Button 
                onClick={executeAdaptivePruning}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Activity className="w-4 h-4 mr-2" />
                Adaptive Pruning
              </Button>
            </div>
          </div>
          
          <div className="mt-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-400">Storage Optimization</span>
              <span className="text-white">{memoryStats.pruningThreshold}% threshold</span>
            </div>
            <Progress value={memoryStats.pruningThreshold} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Three Memory Types */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <MemoryTypeCard
          icon={Clock}
          title="Episodic Memory"
          memories={episodicMemories}
          color="bg-blue-600/30"
          description="Sessions, events, experiences"
        />
        <MemoryTypeCard
          icon={Database}
          title="Semantic Memory"
          memories={semanticMemories}
          color="bg-green-600/30"
          description="Facts, knowledge, embeddings"
        />
        <MemoryTypeCard
          icon={Zap}
          title="Procedural Memory"
          memories={proceduralMemories}
          color="bg-orange-600/30"
          description="Workflows, habits, automations"
        />
      </div>

      <Tabs defaultValue="episodic" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="episodic">Episodic Details</TabsTrigger>
          <TabsTrigger value="semantic">Semantic Network</TabsTrigger>
          <TabsTrigger value="procedural">Workflow Engine</TabsTrigger>
        </TabsList>
        
        <TabsContent value="episodic" className="space-y-4">
          {episodicMemories.map(memory => (
            <Card key={memory.id} className="bg-slate-800/50 border-slate-700/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <Badge className="capitalize">{memory.event_type?.replace('_', ' ')}</Badge>
                  <Badge variant={memory.business_impact === 'critical' ? 'destructive' : 'secondary'}>
                    {memory.business_impact} impact
                  </Badge>
                </div>
                <p className="text-white mb-2">{memory.context}</p>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">
                    {memory.participants?.length || 0} participants
                  </span>
                  <span className="text-slate-400">
                    Recalled {memory.recall_count || 0} times
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        
        <TabsContent value="semantic" className="space-y-4">
          {semanticMemories.map(memory => (
            <Card key={memory.id} className="bg-slate-800/50 border-slate-700/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <Badge className="capitalize">{memory.knowledge_type}</Badge>
                  <Badge variant="outline">{memory.domain}</Badge>
                </div>
                <p className="text-white mb-2">{memory.content}</p>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">
                    Confidence: {((memory.confidence_score || 0) * 100).toFixed(1)}%
                  </span>
                  <span className="text-slate-400">
                    Used {memory.usage_count || 0} times
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        
        <TabsContent value="procedural" className="space-y-4">
          {proceduralMemories.map(memory => (
            <Card key={memory.id} className="bg-slate-800/50 border-slate-700/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-medium text-white">{memory.name}</h4>
                  <Badge className="capitalize">{memory.category?.replace('_', ' ')}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-slate-400">Success Rate:</span>
                    <span className="text-white ml-2">
                      {((memory.success_rate || 0) * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Executions:</span>
                    <span className="text-white ml-2">{memory.execution_count || 0}</span>
                  </div>
                </div>
                <p className="text-slate-400 text-xs mt-2">
                  Steps: {memory.steps?.length || 0} | 
                  Avg Duration: {memory.average_duration || 0}s
                </p>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}