export const systemStats = {
  identity: {
    trust: 87,
    biometrics: { voice: "Verified", face: "Verified", gesture: "Ready" },
    roles: ["Business", "Admin", "Developer", "Creative"],
    accessLog: [
      "Login: Today 14:32 (192.168.1.100)",
      "MFA: Today 14:32 (Voice + Face)",
      "Role Switch: Today 14:45 (→ Business Mode)",
    ],
    metrics: { performance: 99.1, memory: 28.5 },
    subsystems: [
      { name: "Biometric Auth", status: "online" },
      { name: "Trust Scoring", status: "online" },
      { name: "Role Management", status: "degraded" },
    ]
  },
  memory: {
    episodic: { sessions: 1248, conversations: 3572, events: 3942, trend: "up" },
    semantic: { facts: 58230, documents: 7430, embeddings: 78392, usage: 72, trend: "stable" },
    procedural: { workflows: 213, automations: 47, success_rate: 94.7, trend: "up" },
    pruning: { priority: "High-Value Recall", pruned_today: 284, high_value: 1842, usage: 45, trend: "down" },
    metrics: { performance: 97.8, memory: 45.2 },
    subsystems: [
      { name: "Episodic Recall", status: "online" },
      { name: "Semantic Search", status: "online" },
      { name: "Procedural Engine", status: "online" },
      { name: "Memory Pruning", status: "degraded" },
    ]
  },
  knowledge: {
    vault: 7430,
    storage: ["docs", "audio", "models"],
    graphEntities: 5200,
    links: 14800,
    metrics: { performance: 98.5, memory: 55.1 },
    subsystems: [
      { name: "Knowledge Vault", status: "online" },
      { name: "Graph Database", status: "online" },
      { name: "Ingestion Pipeline", status: "online" },
    ]
  },
  automation: {
    rules: 124,
    tier0: 37,
    tier1: 18,
    tier2: 9,
    contextSwitches: 54,
    metrics: { performance: 96.4, memory: 33.7 },
    subsystems: [
      { name: "Rule Engine", status: "online" },
      { name: "Context Switching", status: "degraded" },
      { name: "Tier Automation", status: "online" },
    ]
  },
  config: {
    integrations: {
      finance: "online",
      energy: "online", 
      transport: "degraded",
      globalOps: "offline",
    },
    metrics: { performance: 99.8, memory: 18.9 },
    subsystems: [
      { name: "Financial APIs", status: "online" },
      { name: "Energy Grid", status: "online" },
      { name: "Transport Logistics", status: "degraded" },
      { name: "Global Ops", status: "offline" },
    ]
  },
  governance: {
    audit: "Immutable",
    telemetry: "Healthy",
    risk: 22,
    guardian: "Online",
    metrics: { performance: 99.5, memory: 25.6 },
    subsystems: [
      { name: "Guardian AI", status: "online" },
      { name: "Immutable Audit", status: "online" },
      { name: "Risk Analysis", status: "online" },
    ]
  },
};