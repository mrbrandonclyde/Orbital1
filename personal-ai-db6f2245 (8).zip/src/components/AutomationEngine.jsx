import React from "react";
import { Cpu } from "lucide-react";

export default function AutomationEngine({ count = 0 }) {
  return (
    <div className="purple-glow-panel p-4 rounded-xl">
      <h3 className="text-purple-300 font-semibold mb-2 flex items-center gap-2"><Cpu className="w-4 h-4"/> Automation Engine</h3>
      <p className="text-gray-300 text-sm">Automations running: <span className="font-bold text-white">{count}</span></p>
    </div>
  );
}