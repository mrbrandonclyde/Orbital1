import { useState } from "react";
import { Shield, TrendingUp, HeartPulse } from "lucide-react";
import { Card } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";

export default function MiniMonitorHUD({ health, threat, trust, onExpand }) {
  const [hovered, setHovered] = useState(false);

  const getThreatColor = () => {
    switch (threat?.toLowerCase()) {
      case 'elevated': return 'text-amber';
      case 'critical': return 'text-crimson';
      default: return 'text-cyan';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-6 right-6 z-50 cursor-pointer"
      onClick={onExpand}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <Card className="superman-card p-3 flex flex-col gap-2 w-56 border border-cyan/30 shadow-lg cyan-glow transition-all duration-300 hover:border-gold/50 hover:shadow-gold/20">
        <div className="flex items-center justify-between text-sm">
          <span className="text-silver">Health</span>
          <span className="text-kryptonite font-bold flex items-center gap-1">
            <TrendingUp className="w-4 h-4" />
            {health?.toFixed(1) || 'N/A'}%
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-silver">Threat</span>
          <span className={`font-bold flex items-center gap-1 capitalize ${getThreatColor()}`}>
            <Shield className="w-4 h-4" />
            {threat || 'N/A'}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-silver">Trust</span>
          <span className="text-gold font-bold flex items-center gap-1">
            <HeartPulse className="w-4 h-4 animate-pulse" />
            {trust || 'N/A'} / 100
          </span>
        </div>
        <AnimatePresence>
          {hovered && (
            <motion.p 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="text-xs text-center text-cyan overflow-hidden"
            >
              Click to expand monitor
            </motion.p>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
}