import React from "react";
import { motion } from "framer-motion";

export default function TimeMachineLayout() {
  return (
    <div className="relative h-screen w-full bg-gradient-to-br from-[#00bfff] via-[#0080ff] to-[#4169e1] text-white overflow-hidden">
      {/* Top Bar */}
      <header className="flex items-center justify-between px-6 py-4 bg-black/30 backdrop-blur-md border-b border-cyan-300/60 shadow-[0_0_30px_#00bfff88]">
        <div className="flex items-center gap-3">
          <span className="text-cyan-100 font-bold">Zyra AI</span>
          <span className="text-sm text-white/90">Trust 77</span>
        </div>
        <h1 className="text-lg tracking-widest text-cyan-100 font-semibold">
          SUPERMANOS TIME MACHINE PRO
        </h1>
        <div className="flex items-center gap-2 text-purple-200 animate-pulse">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-5 w-5"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path d="M12 20v-6m0 0V4m0 10H6m6 0h6" />
          </svg>
          Listening...
        </div>
      </header>

      {/* Center Clock + Timeline */}
      <main className="flex flex-col items-center justify-center flex-1 relative">
        <motion.div
          className="text-center"
          animate={{ opacity: [0.9, 1, 0.9], scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 3 }}
        >
          <h2 className="text-3xl font-bold text-white">
            Wednesday, Sep 3, 2025
          </h2>
          <p className="text-5xl font-extrabold text-cyan-100 mt-2 drop-shadow-[0_0_20px_rgba(0,191,255,0.8)]">
            5:17:42 AM
          </p>
        </motion.div>

        {/* Timeline Dial */}
        <motion.div
          className="mt-10 w-72 h-72 rounded-full border-4 border-cyan-300/70 shadow-[0_0_50px_#00bfff] flex items-center justify-center relative"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 60, ease: "linear" }}
        >
          <span className="text-2xl font-bold text-white drop-shadow-[0_0_10px_rgba(0,191,255,0.8)]">10:35</span>
        </motion.div>

        {/* Jump Controls */}
        <div className="flex gap-4 mt-8">
          <button className="px-4 py-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg shadow-[0_0_25px_#00bfff] font-semibold text-white hover:shadow-[0_0_40px_#00bfff] transition-all duration-300">
            Jump to Now
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-purple-400 to-pink-500 rounded-lg shadow-[0_0_25px_#ff1493] font-semibold text-white hover:shadow-[0_0_40px_#ff1493] transition-all duration-300">
            Forecast
          </button>
        </div>
      </main>

      {/* Right Sidebar Console */}
      <aside className="absolute top-0 right-0 w-72 h-full bg-black/30 backdrop-blur-lg border-l border-cyan-300/50 shadow-[0_0_40px_#00bfff44] p-6 flex flex-col gap-4">
        <h3 className="text-lg font-bold text-cyan-100 mb-2 drop-shadow-[0_0_10px_rgba(0,191,255,0.6)]">
          Temporal Console
        </h3>
        <ul className="flex flex-col gap-3 text-sm text-white/90">
          {[
            "Branch Manager",
            "Prediction Engine",
            "Event Markers",
            "Layout",
            "Themes",
            "Automation",
            "Export",
          ].map((item) => (
            <li
              key={item}
              className="px-3 py-2 rounded-lg bg-black/30 border border-cyan-300/40 hover:bg-cyan-500/20 hover:text-cyan-100 cursor-pointer transition-all duration-300 hover:shadow-[0_0_15px_#00bfff66]"
            >
              {item}
            </li>
          ))}
        </ul>
        <button className="mt-auto p-3 rounded-lg bg-gradient-to-r from-cyan-400 to-blue-500 font-bold shadow-[0_0_30px_#00bfff] hover:shadow-[0_0_45px_#00bfff] transition-all duration-300">
          Menu
        </button>
      </aside>
    </div>
  );
}