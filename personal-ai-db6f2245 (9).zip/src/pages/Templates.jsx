import React, { useState, useEffect } from "react";
import { Template } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Heart, Star, Bookmark, Shield, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";

export default function TemplatesPage() {
  const [templates, setTemplates] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({ name: '', prompt: '', category: 'writing' });

  useEffect(() => { 
    loadTemplates(); 
    loadCurrentUser();
  }, []);

  const loadTemplates = async () => { 
    setTemplates(await Template.list('-use_count')); 
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingTemplate) { 
      await Template.update(editingTemplate.id, formData); 
    } else { 
      await Template.create(formData); 
    }
    setIsDialogOpen(false);
    setEditingTemplate(null);
    setFormData({ name: '', prompt: '', category: 'writing' });
    loadTemplates();
  };

  const handleEdit = (template) => {
    setEditingTemplate(template);
    setFormData({ name: template.name, prompt: template.prompt, category: template.category });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => { 
    if (confirm('Are you sure you want to delete this template?')) {
      await Template.delete(id); 
      loadTemplates(); 
    }
  };

  const toggleFavorite = async (template) => { 
    await Template.update(template.id, { is_favorite: !template.is_favorite }); 
    loadTemplates(); 
  };

  const categoryColors = {
    writing: "metric-cyan",
    coding: "metric-green", 
    business: "metric-gold",
    creative: "metric-purple",
    analysis: "metric-amber",
    personal: "metric-orange"
  };

  return (
    <div className="p-8 h-full overflow-y-auto superman-gradient">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8 obsidian-panel p-4 rounded-lg">
          <div>
            <h1 className="text-3xl font-bold text-gold">Prompt Templates</h1>
            <p className="text-cyan mt-1">Create and manage reusable AI prompts for enhanced productivity.</p>
          </div>
          
          <div className="flex items-center gap-4">
            {currentUser && (
              <div className="kryptonite-glow rounded-lg p-2 flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-kryptonite" />
                <span className="text-silver">Trust:</span>
                <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
              </div>
            )}
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="btn-cyan" onClick={() => setEditingTemplate(null)}>
                  <Plus className="w-4 h-4 mr-2" /> New Template
                </Button>
              </DialogTrigger>
              <DialogContent className="obsidian-panel max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-gold">
                    {editingTemplate ? 'Edit Template' : 'Create New Template'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-slate-300">Template Name</Label>
                      <Input 
                        id="name" 
                        value={formData.name} 
                        onChange={(e) => setFormData({...formData, name: e.target.value})} 
                        placeholder="e.g., Email Writer" 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category" className="text-slate-300">Category</Label>
                      <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="superman-card">
                          <SelectItem value="writing">Writing</SelectItem>
                          <SelectItem value="coding">Coding</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="creative">Creative</SelectItem>
                          <SelectItem value="analysis">Analysis</SelectItem>
                          <SelectItem value="personal">Personal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="prompt" className="text-slate-300">Prompt Template</Label>
                    <Textarea 
                      id="prompt" 
                      value={formData.prompt} 
                      onChange={(e) => setFormData({...formData, prompt: e.target.value})} 
                      placeholder="Write a professional email about..." 
                      className="h-40" 
                      required 
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="border-slate-600 text-slate-300">
                      Cancel
                    </Button>
                    <Button type="submit" className="btn-cyan">
                      {editingTemplate ? 'Update Template' : 'Create Template'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {templates.map(template => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="superman-card hover:cyan-glow transition-all duration-300 h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg text-silver flex items-center gap-2">
                        <Bookmark className="w-5 h-5 text-cyan" />
                        {template.name}
                        {template.is_favorite && <Star className="w-4 h-4 text-gold fill-current" />}
                      </CardTitle>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => toggleFavorite(template)} 
                          className={`text-slate-400 hover:text-gold ${template.is_favorite ? 'text-gold' : ''}`}
                        >
                          <Heart className={`w-4 h-4 ${template.is_favorite ? 'fill-current' : ''}`} />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-slate-400 hover:text-cyan" 
                          onClick={() => handleEdit(template)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-slate-400 hover:text-crimson" 
                          onClick={() => handleDelete(template.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-400 line-clamp-3 mb-4 h-16 leading-relaxed">
                      {template.prompt}
                    </p>
                    <div className="flex justify-between items-center">
                      <Badge className={`capitalize ${categoryColors[template.category]} border-0`}>
                        {template.category}
                      </Badge>
                      <div className="flex items-center gap-2">
                        <Zap className="w-3 h-3 text-amber" />
                        <span className="text-sm text-slate-500">{template.use_count || 0} uses</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {templates.length === 0 && (
          <div className="text-center py-12">
            <Card className="superman-card max-w-md mx-auto">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bookmark className="w-8 h-8 text-cyan" />
                </div>
                <h3 className="text-xl font-semibold text-silver mb-2">No Templates Yet</h3>
                <p className="text-slate-400 mb-6">Create your first prompt template to get started with AI-powered productivity.</p>
                <Button onClick={() => setIsDialogOpen(true)} className="btn-cyan">
                  <Plus className="w-4 h-4 mr-2" /> Create First Template
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}