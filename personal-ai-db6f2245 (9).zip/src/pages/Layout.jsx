

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { MessageSquare, Settings, Sparkles, FileText, Bookmark, Atom, Cpu, BookOpen, Brain, Shield, Gem, User as UserIcon, History, Monitor, Globe, ScrollText, Flame, Eye } from "lucide-react";
import { Globe as GlobeIcon } from 'lucide-react'; // Renamed to avoid conflict
import { User } from "@/api/entities";
import { themes } from "@/components/theme";

const navigationItems = [
  { title: "Global Command", url: createPageUrl("GlobalCommand"), icon: GlobeIcon },
  { title: "System Monitor", url: createPageUrl("SystemMonitorPage"), icon: Monitor },
  { title: "Zyra Dashboard", url: createPageUrl("Dashboard"), icon: Brain },
  { title: "Chat", url: createPageUrl("Chat"), icon: MessageSquare },
  { title: "Time Machine", url: createPageUrl("TimeMachine"), icon: History },
  { title: "Fire Detection", url: createPageUrl("FireDetection"), icon: Flame },
  { title: "VR Mode", url: createPageUrl("VR"), icon: Eye },
  { title: "Version History", url: createPageUrl("VersionHistory"), icon: ScrollText },
  { title: "Web Browser", url: createPageUrl("WebBrowser"), icon: Globe },
  { title: "Orbital Landing", url: createPageUrl("OrbitalLanding"), icon: Globe },
  { title: "Gold Standard", url: createPageUrl("Principles"), icon: Gem },
  { title: "Idea Refinery", url: createPageUrl("IdeaRefinery"), icon: Sparkles },
  { title: "Document Factory", url: createPageUrl("DocumentFactory"), icon: FileText },
  { title: "Cosmic Lab", url: createPageUrl("CosmicLab"), icon: Cpu },
  { title: "Learning Dashboard", url: createPageUrl("LearningDashboard"), icon: Brain },
  { title: "License Manager", url: createPageUrl("LicenseManager"), icon: Shield },
  { title: "Templates", url: createPageUrl("Templates"), icon: Bookmark },
  { title: "Saved Sections", url: createPageUrl("SavedSections"), icon: BookOpen },
  { title: "Documents", url: createPageUrl("Documents"), icon: FileText },
  { title: "Settings", url: createPageUrl("Settings"), icon: Settings },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [currentUser, setCurrentUser] = useState(null);
  const [trustScore, setTrustScore] = useState(87);
  
  // Force orbital theme for this specific design
  const theme = themes["orbital"];

  useEffect(() => {
    loadCurrentUser();
    // Set browser tab title
    document.title = "Zyra AI - Orbital Command Center";
  }, []);

  useEffect(() => {
    // Update title based on current page
    const pageNames = {
      '/GlobalCommand': 'Global Command - Zyra AI', // Added new page title
      '/SystemMonitorPage': 'System Monitor - Zyra AI',
      '/Dashboard': 'Dashboard - Zyra AI', 
      '/Chat': 'Chat - Zyra AI',
      '/TimeMachine': 'Time Machine - Zyra AI',
      '/FireDetection': 'Fire Detection - Zyra AI',
      '/VR': 'VR Mode - Zyra AI',
      '/VersionHistory': 'Version History - Zyra AI',
      '/WebBrowser': 'Web Browser - Zyra AI',
      '/OrbitalLanding': 'Orbital Landing - Zyra AI',
      '/Principles': 'Gold Standard - Zyra AI',
      '/IdeaRefinery': 'Idea Refinery - Zyra AI',
      '/DocumentFactory': 'Document Factory - Zyra AI',
      '/CosmicLab': 'Cosmic Lab - Zyra AI',
      '/LearningDashboard': 'Learning Dashboard - Zyra AI',
      '/LicenseManager': 'License Manager - Zyra AI',
      '/Templates': 'Templates - Zyra AI',
      '/SavedSections': 'Saved Sections - Zyra AI',
      '/Documents': 'Documents - Zyra AI',
      '/Settings': 'Settings - Zyra AI'
    };
    
    document.title = pageNames[location.pathname] || 'Zyra AI - Orbital Command Center';
  }, [location.pathname]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      setTrustScore(user.trust_score || 87);
    } catch (error) {
      console.log('User not authenticated');
    }
  };

  return (
    <div className={`flex h-screen w-full ${theme.textSecondary} ${theme.background}`}>
       <style jsx global>{`
        :root {
          --orbital-glow-blue: rgba(43, 43, 201, 0.4);
          --orbital-glow-cyan: rgba(51, 198, 243, 0.3);
        }
        .blue-glow-panel {
          background-color: rgba(16, 16, 40, 0.5);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(43, 43, 201, 0.6);
          box-shadow: 0 0 25px var(--orbital-glow-blue);
        }
        .cyan-glow-panel {
          background-color: rgba(16, 16, 40, 0.5);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(51, 198, 243, 0.3);
          box-shadow: 0 0 25px var(--orbital-glow-cyan);
        }
      `}</style>
      
      {/* Sidebar */}
      <aside className={`w-64 flex-shrink-0 bg-black/30 border-r border-[#3A3A6A]/40 flex flex-col`}>
        {/* Header */}
        <div className="h-20 flex items-center px-4 gap-3 border-b border-[#3A3A6A]/40">
          <div className={`w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center border border-blue-400/50`}>
            <Brain className="w-6 h-6 text-blue-300" />
          </div>
          <div>
            <h1 className={`font-bold text-lg ${theme.textPrimary}`}>Zyra AI</h1>
            <p className={`text-xs ${theme.textSecondary}`}>Orbital Command Center</p>
          </div>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-1">
          {navigationItems.map((item) => {
            const isActive = location.pathname === item.url;
            const Icon = item.icon;
            return (
              <Link
                key={item.title}
                to={item.url}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-300 ${
                  isActive 
                    ? `bg-blue-500/20 text-blue-300 border-l-2 border-blue-400`
                    : `${theme.textSecondary} hover:bg-gray-700/20 hover:text-gray-100`
                }`}
              >
                <Icon className={`w-5 h-5 transition-colors ${isActive ? 'text-blue-400' : theme.textSecondary}`} />
                <span className={isActive ? 'font-semibold' : ''}>{item.title}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="p-4 space-y-3 border-t border-[#3A3A6A]/40">
          {currentUser && (
            <div className={`bg-black/30 rounded-lg p-3 border border-[#3A3A6A]/60`}>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs ${theme.textSecondary}`}>Session Trust</span>
                <div className="flex items-center gap-1">
                  <Shield className={`w-3 h-3 text-blue-400`} />
                  <span className={`text-xs font-bold text-blue-300`}>{trustScore}/100</span>
                </div>
              </div>
              <div className="w-full bg-gray-700/50 rounded-full h-1.5">
                <div 
                  className={`bg-gradient-to-r from-blue-500 to-cyan-400 h-1.5 rounded-full`} 
                  style={{ width: `${trustScore}%` }}
                ></div>
              </div>
            </div>
          )}

          <div className={`flex items-center gap-3 p-2 rounded-lg`}>
            <img 
              src={currentUser?.profile_picture || "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/6f5f72cfe_WhatsAppImage2025-09-02at200108_683b6596.jpg"} 
              alt={currentUser?.full_name || "Brandon Clyde Avatar"}
              className={`w-10 h-10 rounded-full object-cover border-2 border-blue-400/50`}
            />
            <div className="flex-1">
              <p className={`font-semibold text-sm ${theme.textPrimary}`}>{currentUser?.full_name || "Brandon Clyde"}</p>
              <p className={`text-xs ${theme.textSecondary}`}>Orbital • Command</p>
            </div>
             <span className={`text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full capitalize`}>
                {currentUser?.active_mode || 'Business'}
            </span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 flex flex-col overflow-hidden ${theme.background} min-h-0`}>
        <div className="flex-1 min-h-0 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

