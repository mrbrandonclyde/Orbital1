
import React, { useState, useEffect } from "react";
import { ZyraMemory } from "@/api/entities";
import { ZyraTask } from "@/api/entities";
import { ZyraIntegration } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Building, Settings, Brain, DollarSign, Sun, Shield, Banknote, User as UserIcon, Activity
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import MemoryVault from "@/components/zyra/MemoryVault";
import TaskAutomation from "@/components/zyra/TaskAutomation";
import IntegrationHub from "@/components/zyra/IntegrationHub";

export default function DashboardPage() {
  const [memories, setMemories] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [integrations, setIntegrations] = useState([]);
  const [activeMode, setActiveMode] = useState('creative');
  const [currentUser, setCurrentUser] = useState(null);
  const [userMode, setUserMode] = useState('business');

  useEffect(() => {
    loadDashboardData();
    loadCurrentUser();
  }, []);

  const loadDashboardData = async () => {
    const [memoriesData, tasksData, integrationsData] = await Promise.all([
      ZyraMemory.list('-created_date', 5),
      ZyraTask.list(),
      ZyraIntegration.list()
    ]);
    setMemories(memoriesData);
    setTasks(tasksData);
    setIntegrations(integrationsData);
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      setUserMode(user.active_mode || 'business');
      setActiveMode(user.active_mode || 'creative');
    } catch (error) {
      console.log('User not authenticated or error fetching user:', error);
      // Handle cases where user is not authenticated, e.g., redirect to login
    }
  };

  const handleModeChange = async (newMode) => {
    setUserMode(newMode);
    if (currentUser) {
      try {
        await User.updateMyUserData({ active_mode: newMode });
      } catch (error) {
        console.error("Failed to update user mode:", error);
      }
    }
  };

  const modes = [
    { id: 'business', name: 'Business', icon: Building },
    { id: 'developer', name: 'Developer', icon: Settings },
    { id: 'creative', name: 'Creative', icon: Brain },
    { id: 'investor', name: 'Investor', icon: DollarSign }
  ];
  
  const businessUnits = [
    { id: 'sunview_energy', name: 'Sunview Energy', icon: Sun },
    { id: 'infiniti_security', name: 'Infiniti Security', icon: Shield },
    { id: 'clyde_bank', name: 'Clyde Sovereign Bank', icon: Banknote },
    { id: 'personal', name: 'Personal', icon: UserIcon }
  ];

  const criticalTasks = tasks.filter(t => t.priority === 'critical' && t.status !== 'completed').length;
  const activeProjects = tasks.filter(t => t.status === 'in_progress').length;

  return (
    <>
      <header className="h-20 flex-shrink-0 flex items-center justify-between px-8 obsidian-panel">
        <div>
          <h2 className="text-xl font-bold text-gold">Zyra AI Dashboard</h2>
          <p className="text-sm text-cyan">Gold Standard Assistant • Brandon Clyde Ecosystem</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 bg-black/30 rounded-lg p-1 border border-cyan/20">
            {modes.map(mode => {
              const Icon = mode.icon;
              return (
                <button
                  key={mode.id}
                  onClick={() => {
                    setActiveMode(mode.id);
                    handleModeChange(mode.id);
                  }}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-300 ${
                    activeMode === mode.id
                      ? 'bg-cyan/20 text-cyan shadow-[inset_0_0_10px_rgba(0,255,255,0.2)]'
                      : 'text-silver hover:bg-cyan/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {mode.name}
                </button>
              );
            })}
          </div>
          
          {currentUser && (
            <div className="kryptonite-glow rounded-lg p-2 flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-kryptonite" />
                <span className="text-silver">Trust:</span>
                <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
            </div>
          )}
          
          <div className="metric-green rounded-full px-3 py-1.5 flex items-center text-sm">
            <div className="w-2 h-2 rounded-full bg-kryptonite mr-2 animate-pulse kryptonite-glow"></div>
            Systems Online
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-8 superman-gradient">
        {userMode === 'investor' && (
          <div className="mb-6">
            <Card className="superman-card gold-glow">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-6 h-6 text-gold" />
                  <div>
                    <h3 className="font-semibold text-gold">Investor Mode Active</h3>
                    <p className="text-sm text-amber">Financial analytics and portfolio insights prioritized</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-transparent mb-6 p-0 border-b border-cyan/30 w-full justify-start rounded-none">
            <TabsTrigger value="overview" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Overview</TabsTrigger>
            <TabsTrigger value="chat" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">AI Chat</TabsTrigger>
            <TabsTrigger value="memory" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Memory Vault</TabsTrigger>
            <TabsTrigger value="automation" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Automation</TabsTrigger>
            <TabsTrigger value="integrations" className="data-[state=active]:bg-transparent data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_hsl(var(--gold-standard))] rounded-none text-silver hover:text-white">Integrations</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="grid grid-cols-12 gap-6">
            <div className="col-span-3 space-y-4">
              <h3 className="text-lg font-semibold text-white px-1">Business Units</h3>
              {businessUnits.map(unit => {
                  const Icon = unit.icon;
                  return (
                    <div key={unit.id} className="p-4 rounded-lg superman-card flex items-center gap-4">
                      <Icon className="w-6 h-6 text-cyan"/>
                      <div>
                        <p className="font-medium text-white">{unit.name}</p>
                        <p className="text-xs text-kryptonite">Active • Online</p>
                      </div>
                    </div>
                  );
              })}
            </div>

            <div className="col-span-6 space-y-6">
              <h3 className="text-lg font-semibold text-white px-1">Business Operations</h3>
              <div className="grid grid-cols-2 gap-6">
                <Card className="superman-card"><CardHeader><CardTitle className="text-sm font-medium text-silver">Revenue Pipeline</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-gold">$2.4M</p></CardContent></Card>
                <Card className="superman-card"><CardHeader><CardTitle className="text-sm font-medium text-silver">Critical Tasks</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-crimson">{criticalTasks}</p></CardContent></Card>
                <Card className="superman-card"><CardHeader><CardTitle className="text-sm font-medium text-silver">System Uptime</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-kryptonite">99.9%</p></CardContent></Card>
                <Card className="superman-card"><CardHeader><CardTitle className="text-sm font-medium text-silver">Active Projects</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-cyan">{activeProjects}</p></CardContent></Card>
              </div>

              <h3 className="text-lg font-semibold text-white mt-6 px-1">System Health</h3>
              <Card className="superman-card">
                <CardContent className="space-y-4 p-6">
                  <div>
                    <div className="flex justify-between text-sm mb-1"><span className="text-silver">API Integrations</span><span className="text-white">100%</span></div>
                    <Progress value={100} className="h-2 [&>div]:progress-cyan"/>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1"><span className="text-silver">Memory Optimization</span><span className="text-white">99.8%</span></div>
                    <Progress value={99.8} className="h-2 [&>div]:progress-gold"/>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1"><span className="text-silver">Security Level</span><span className="text-white">Quantum-Safe</span></div>
                    <Progress value={100} className="h-2 [&>div]:progress-kryptonite"/>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="col-span-3">
               <h3 className="text-lg font-semibold text-white mb-4 px-1">Recent Activity</h3>
              <Card className="superman-card">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {memories.map(mem => (
                      <div key={mem.id} className="text-sm flex justify-between items-center hover:bg-cyan/10 p-1.5 rounded-md transition-colors">
                        <p className="text-silver truncate pr-4">{mem.content}</p>
                        <time className="text-silver/60 text-xs flex-shrink-0">{new Date(mem.created_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="chat"><div className="text-center p-10"><Link to={createPageUrl("Chat")}><Button className="btn-gold">Go to Dedicated Chat Page</Button></Link></div></TabsContent>
          <TabsContent value="memory"><MemoryVault memories={memories} onRefresh={loadDashboardData} /></TabsContent>
          <TabsContent value="automation"><TaskAutomation tasks={tasks} onRefresh={loadDashboardData} /></TabsContent>
          <TabsContent value="integrations"><IntegrationHub integrations={integrations} onRefresh={loadDashboardData} /></TabsContent>
        </Tabs>
      </div>
    </>
  );
}
