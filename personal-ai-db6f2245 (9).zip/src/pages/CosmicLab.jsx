
import React, { useState, useEffect } from "react";
import { ScientificProject, ComputationJob } from "@/api/entities";
import { User } from "@/api/entities"; // Added import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Atom, Brain, Globe, Rocket, Microscope, Network, Zap, Cpu, Shield } from "lucide-react"; // Added Shield import
import BiophysicsLab from "@/components/cosmic/BiophysicsLab";
import QuantumLab from "@/components/cosmic/QuantumLab";
import NeuroinformaticsLab from "@/components/cosmic/NeuroinformaticsLab";
import ClimateModelLab from "@/components/cosmic/ClimateModelLab";
import AstrophysicsLab from "@/components/cosmic/AstrophysicsLab";
import ComplexSystemsLab from "@/components/cosmic/ComplexSystemsLab";
import ComputationDashboard from "@/components/cosmic/ComputationDashboard";

export default function CosmicLabPage() {
  const [projects, setProjects] = useState([]);
  const [activeJobs, setActiveJobs] = useState([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentUser, setCurrentUser] = useState(null); // Added state

  useEffect(() => {
    loadData();
    loadCurrentUser(); // Added call to loadCurrentUser
    const interval = setInterval(loadData, 5000); // Refresh data every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    const [projectData, jobData] = await Promise.all([
      ScientificProject.list('-updated_date'),
      ComputationJob.filter({ status: 'running' })
    ]);
    setProjects(projectData);
    setActiveJobs(jobData);
  };

  // Added loadCurrentUser function
  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error); // Log error for debugging
      setCurrentUser(null); // Ensure currentUser is null if authentication fails
    }
  };

  const onJobSubmitted = () => {
    loadData();
    setActiveTab('dashboard');
  }

  const domainIcons = {
    biophysics: Microscope,
    neuroinformatics: Brain,
    astrophysics: Rocket,
    climate: Globe,
    quantum: Atom,
    complex_systems: Network,
    ai_research: Zap
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 flex justify-between items-start"> {/* Modified header for flex layout */}
            <div>
                <h1 className="text-3xl font-bold text-white">Cosmic AI Laboratory</h1>
                <p className="text-slate-400 mt-1">Advanced scientific computing and research platform.</p>
            </div>
            {/* Identity Core Integration */}
            {currentUser && (
              <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-3 py-2 border border-slate-700">
                <Shield className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-300">Trust: {currentUser.trust_score || 87}</span>
                <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full capitalize ml-2">
                  {currentUser.active_mode || 'business'}
                </span>
              </div>
            )}
        </header>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 md:grid-cols-8 gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/50">
            <TabsTrigger value="dashboard" className="flex items-center gap-2"><Cpu className="w-4 h-4" />Dashboard</TabsTrigger>
            <TabsTrigger value="biophysics" className="flex items-center gap-2"><Microscope className="w-4 h-4" />Bio</TabsTrigger>
            <TabsTrigger value="quantum" className="flex items-center gap-2"><Atom className="w-4 h-4" />Quantum</TabsTrigger>
            <TabsTrigger value="neuro" className="flex items-center gap-2"><Brain className="w-4 h-4" />Neuro</TabsTrigger>
            <TabsTrigger value="climate" className="flex items-center gap-2"><Globe className="w-4 h-4" />Climate</TabsTrigger>
            <TabsTrigger value="astro" className="flex items-center gap-2"><Rocket className="w-4 h-4" />Astro</TabsTrigger>
            <TabsTrigger value="complex" className="flex items-center gap-2"><Network className="w-4 h-4" />Complex</TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center gap-2"><Zap className="w-4 h-4" />AI</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <ComputationDashboard projects={projects} activeJobs={activeJobs} onRefresh={loadData} />
          </TabsContent>
          <TabsContent value="biophysics"><BiophysicsLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="quantum"><QuantumLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="neuro"><NeuroinformaticsLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="climate"><ClimateModelLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="astro"><AstrophysicsLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="complex"><ComplexSystemsLab onJobSubmit={onJobSubmitted} /></TabsContent>
          <TabsContent value="ai">
            <Card className="bg-slate-800/70 border-slate-700/50"><CardHeader><CardTitle className="text-white">AI Research</CardTitle></CardHeader><CardContent><p className="text-slate-300">AI Research tools coming soon.</p></CardContent></Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
