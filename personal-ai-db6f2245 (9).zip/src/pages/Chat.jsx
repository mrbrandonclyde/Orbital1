
import React, { useState, useEffect, useRef, useCallback } from "react";
import { UserSettings } from "@/api/entities";
import { AIModel } from "@/api/entities";
import { Conversation } from "@/api/entities";
import { Message } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Bot, BrainCircuit, Zap, ShieldCheck, Lock, Brain, TrendingUp, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MessageBubble from "@/components/chat/MessageBubble";
import ChatInput from "@/components/chat/ChatInput";
import ConversationHistory from "@/components/chat/ConversationHistory";

const ORCHESTRATOR_MODEL = {
  id: 'orchestrator',
  name: 'Zyra (Orchestrator)',
  description: 'Automatically routes your request to the best specialist agent.',
  isOrchestrator: true
};

export default function ChatPage() {
  const [settings, setSettings] = useState(null);
  const [allModels, setAllModels] = useState([]);
  const [activeModel, setActiveModel] = useState(ORCHESTRATOR_MODEL);
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isHistoryLoading, setIsHistoryLoading] = useState(true);
  const [streamingResponse, setStreamingResponse] = useState("");
  const [currentUser, setCurrentUser] = useState(null);
  
  const chatEndRef = useRef(null);

  const loadInitialData = useCallback(async () => {
    setIsHistoryLoading(true);
    const [userSettingsList, models, convos, user] = await Promise.all([
      UserSettings.list(),
      AIModel.list(),
      Conversation.list("-last_message_at"),
      User.me().catch(() => null)
    ]);
    
    let loadedSettings = userSettingsList[0] || (await UserSettings.create({}));
    setSettings(loadedSettings);
    setAllModels(models);
    
    let modelToSet = ORCHESTRATOR_MODEL;
    if (loadedSettings.active_model_id && loadedSettings.active_model_id !== 'orchestrator') {
      const foundModel = models.find(m => m.id === loadedSettings.active_model_id);
      if (foundModel) modelToSet = foundModel;
    }
    setActiveModel(modelToSet);
    
    setConversations(convos);
    if (convos.length > 0) {
      setCurrentConversationId(convos[0].id);
    }
    
    setCurrentUser(user);
    setIsHistoryLoading(false);
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (currentConversationId) {
      loadMessages(currentConversationId);
    } else {
      setMessages([]);
    }
  }, [currentConversationId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading, streamingResponse]);

  const loadMessages = async (conversationId) => {
    const fetchedMessages = await Message.filter({ conversation_id: conversationId }, "timestamp");
    setMessages(fetchedMessages);
  };
  
  // Timeline command parsing and execution
  const parseTimelineCommand = (message) => {
    const msg = message.toLowerCase();
    
    if (msg.includes('roll back') || msg.includes('rollback') || msg.includes('go back')) {
      const timeMatch = msg.match(/(\d+)\s*(second|minute|hour|day|year)s?/);
      return {
        action: 'rollback',
        amount: timeMatch ? parseInt(timeMatch[1]) : 1,
        unit: timeMatch ? timeMatch[2] : 'minute'
      };
    }
    
    if (msg.includes('fast forward') || msg.includes('forward') || msg.includes('advance')) {
      const timeMatch = msg.match(/(\d+)\s*(second|minute|hour|day|year)s?/);
      return {
        action: 'forward',
        amount: timeMatch ? parseInt(timeMatch[1]) : 1,
        unit: timeMatch ? timeMatch[2] : 'minute'
      };
    }
    
    if (msg.includes('forecast') || msg.includes('predict') || msg.includes('future')) {
      return { action: 'forecast' };
    }
    
    if (msg.includes('pause') || msg.includes('stop')) {
      return { action: 'pause' };
    }
    
    if (msg.includes('play') || msg.includes('resume') || msg.includes('continue')) {
      return { action: 'play' };
    }
    
    return null;
  };

  const executeTimelineCommand = async (command) => {
    // This would need access to timeline functions - you might need to pass them as props
    // or use the timeline context here
    
    switch (command.action) {
      case 'rollback':
        // rollback(calculateStepsFromUnit(command.amount, command.unit));
        return `⏪ Rolling back ${command.amount} ${command.unit}${command.amount > 1 ? 's' : ''} in the timeline.`;
      case 'forward':
        // forward(calculateStepsFromUnit(command.amount, command.unit));
        return `⏩ Advancing ${command.amount} ${command.unit}${command.amount > 1 ? 's' : ''} into the future.`;
      case 'forecast':
        // generateForecast();
        return `🔮 Generating system stability forecast. Check the Temporal Console for projections.`;
      case 'pause':
        // setPlaying(false);
        return `⏸️ Timeline playback paused.`;
      case 'play':
        // setPlaying(true);
        return `▶️ Timeline playback resumed.`;
      default:
        return "I understand you want to control the timeline, but I'm not sure how to execute that command.";
    }
  };

  const handleSendMessage = async (userMessage, attachments = []) => {
    setIsLoading(true);
    setStreamingResponse("");
    
    // Normal message processing starts here
    let conversationId = currentConversationId;
    let isNewConversation = false;
    if (!conversationId) {
      isNewConversation = true;
      const newConvo = await Conversation.create({
        title: userMessage.substring(0, 40) || "New Conversation",
        last_message_at: new Date().toISOString()
      });
      conversationId = newConvo.id;
      setCurrentConversationId(conversationId);
      setConversations(prev => [newConvo, ...prev]);
    }

    const newUserMessage = {
      id: `local-${Date.now()}-user`,
      conversation_id: conversationId,
      content: userMessage,
      attachments: attachments,
      role: "user",
      timestamp: new Date().toISOString(),
      isOptimistic: true
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    await Message.create({ ...newUserMessage, isOptimistic: undefined });

    const conversationHistory = [...messages, newUserMessage].map(msg => ({ 
        role: msg.role, 
        content: `${msg.content} ${msg.attachments?.map(a => `[Attachment: ${a.file_name}]`).join(' ') || ''}`.trim()
    }));
    
    try {
      let finalResponseContent = '';
      let systemPrompt = activeModel?.system_prompt || 'You are Zyra, an advanced AI assistant.';
      let finalModel = activeModel;
      
      if (activeModel.isOrchestrator) {
        const targetAgent = allModels.find(m => m.name.toLowerCase().includes('general')) || allModels[0];
        if (targetAgent) {
            finalModel = targetAgent;
            systemPrompt = targetAgent.system_prompt;
        }
      }
      
      const responseStream = await InvokeLLM({
        prompt: userMessage,
        context_messages: [
          { role: 'system', content: systemPrompt },
          ...conversationHistory.slice(0, -1)
        ],
        file_urls: attachments.map(a => a.file_url)
      });
      
      // Simulate streaming for demo purposes
      const words = responseStream.split(' ');
      for (let i = 0; i < words.length; i++) {
        await new Promise(res => setTimeout(res, 50));
        setStreamingResponse(prev => prev + (i > 0 ? ' ' : '') + words[i]);
      }
      finalResponseContent = responseStream;
      
      const newAiMessage = {
        conversation_id: conversationId,
        content: finalResponseContent,
        role: "assistant",
        timestamp: new Date().toISOString(),
        model_used: finalModel.name,
      };
      
      await Message.create(newAiMessage);

      setMessages(prev => [...prev, newAiMessage]);
      setStreamingResponse("");

      await Conversation.update(conversationId, { last_message_at: new Date().toISOString() });
      if(isNewConversation) {
          const convos = await Conversation.list("-last_message_at");
          setConversations(convos);
      }

    } catch (error) {
      console.error("Error calling LLM:", error);
      setStreamingResponse("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewConversation = () => {
    setCurrentConversationId(null);
    setMessages([]);
  };

  const handleDeleteConversation = async (conversationId) => {
    await Conversation.delete(conversationId);
    setConversations(prev => prev.filter(convo => convo.id !== conversationId));
    if (currentConversationId === conversationId) {
      setCurrentConversationId(null);
      setMessages([]);
    }
  };

  const handleModelChange = async (modelId) => {
    const selectedModel = modelId === ORCHESTRATOR_MODEL.id 
      ? ORCHESTRATOR_MODEL 
      : allModels.find(m => m.id === modelId);
    
    if (selectedModel) {
      setActiveModel(selectedModel);
      if (settings) {
        await UserSettings.update(settings.id, { active_model_id: modelId });
        setSettings(prev => ({ ...prev, active_model_id: modelId }));
      }
    }
  };
  
  return (
    <div className="flex h-screen bg-obsidian-black">
      <ConversationHistory
        conversations={conversations}
        currentConversationId={currentConversationId}
        onSelectConversation={setCurrentConversationId}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        isHistoryLoading={isHistoryLoading}
      />
      
      <main className="flex-1 flex flex-col superman-gradient">
        {/* SupermanOS Metrics Bar */}
        <div className="obsidian-panel px-6 py-3 flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            {activeModel.isOrchestrator ? 
              <BrainCircuit className="w-4 h-4 text-cyan cyan-glow" /> : 
              <Bot className="w-4 h-4 text-cyan" />}
            <Select value={activeModel?.id || 'orchestrator'} onValueChange={handleModelChange}>
              <SelectTrigger className="border-none shadow-none text-gold font-semibold bg-transparent focus:ring-0 p-0 h-auto">
                <SelectValue placeholder="Select AI" />
              </SelectTrigger>
              <SelectContent className="superman-card">
                <SelectItem value={ORCHESTRATOR_MODEL.id} className="text-cyan">
                  <div className="flex items-center gap-2">
                    <BrainCircuit className="w-4 h-4" />
                    <span>{ORCHESTRATOR_MODEL.name}</span>
                  </div>
                </SelectItem>
                {allModels.map(model => (
                  <SelectItem key={model.id} value={model.id} className="text-silver">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4" />
                      <span>{model.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-gold font-bold flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              Accuracy: 99.1%
            </span>
            <span className="text-cyan font-bold flex items-center gap-1">
              <Brain className="w-4 h-4" />
              Depth: 92%
            </span>
            <span className="text-amber font-bold flex items-center gap-1">
              <Cpu className="w-4 h-4" />
              Load: 34%
            </span>
            <span className="text-kryptonite font-bold flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              Verified
            </span>
          </div>
        </div>

        {/* Chat Messages Area */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            <AnimatePresence>
              {messages.map((message) => (
                <MessageBubble 
                  key={message.id} 
                  message={message} 
                  aiName={message.role === 'assistant' ? message.model_used || activeModel.name : 'You'}
                />
              ))}
            </AnimatePresence>
            
            {streamingResponse && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <MessageBubble
                  message={{
                    role: 'assistant',
                    content: streamingResponse,
                    timestamp: new Date().toISOString()
                  }}
                  aiName={activeModel.name}
                  isStreaming={true}
                />
              </motion.div>
            )}
            
            {isLoading && !streamingResponse && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4 justify-start">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden ai-avatar relative">
                    <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/9b4d301ed_WhatsAppImage2025-09-02at195836_c6cb4075.jpg" alt="Zyra AI" className="w-full h-full object-cover" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl shadow-lg neon-blue-bubble text-cyan flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Neural processing...</span>
                  </div>
                </motion.div>
            )}
            <div ref={chatEndRef} />
          </div>
        </div>
        
        {/* Chat Input Area */}
        <div className="superman-card border-t border-cyan/30">
          <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
      </main>
    </div>
  );
}
