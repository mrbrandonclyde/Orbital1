import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, Lock, Zap, Blocks, UserCheck, Shield, Brain } from 'lucide-react';
import { User } from '@/api/entities';

const PrincipleCard = ({ icon: Icon, title, description, details, glowClass }) => (
  <Card className={`superman-card ${glowClass} flex flex-col h-full hover:border-gold/50 transition-all duration-300`}>
    <CardHeader>
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-gold/20 rounded-lg flex items-center justify-center border border-gold/50 gold-glow">
          <Icon className="w-7 h-7 text-gold" />
        </div>
        <CardTitle className="text-xl text-gold">{title}</CardTitle>
      </div>
    </CardHeader>
    <CardContent className="flex-1 flex flex-col justify-between">
      <p className="text-silver mb-6 leading-relaxed">{description}</p>
      <div className="space-y-2">
        {details.map((detail, index) => (
          <div key={index} className="flex items-center justify-between text-sm p-3 bg-black/30 rounded-lg border border-cyan/20">
            <span className="text-cyan font-medium">{detail.label}</span>
            <Badge className="font-mono bg-gold/20 text-gold border-gold/50 px-3 py-1">
              {detail.value}
            </Badge>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

export default function PrinciplesPage() {
  const [currentUser, setCurrentUser] = React.useState(null);

  React.useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error);
    }
  };

  const principles = [
    {
      icon: ShieldCheck,
      title: "Reliability",
      description: "Ensuring constant availability and fault-tolerant infrastructure to support mission-critical operations without interruption.",
      details: [
        { label: "Uptime SLA", value: "99.99%" },
        { label: "Architecture", value: "Fault-Tolerant" },
        { label: "Recovery", value: "Auto-Failover" },
        { label: "Redundancy", value: "Multi-Zone" }
      ],
      glowClass: "cyan-glow"
    },
    {
      icon: Lock,
      title: "Security First",
      description: "A zero-trust architecture complemented by next-generation, quantum-resistant cryptography to protect data integrity and privacy.",
      details: [
        { label: "Cryptography", value: "PQC + AES-256" },
        { label: "Framework", value: "Zero-Trust" },
        { label: "Authentication", value: "Multi-Factor" },
        { label: "Compliance", value: "SOC2 + ISO27001" }
      ],
      glowClass: "kryptonite-glow"
    },
    {
      icon: Zap,
      title: "Performance",
      description: "Engineered for instantaneous interaction and extreme scalability through a distributed microservice architecture.",
      details: [
        { label: "Response Time", value: "< 100ms" },
        { label: "Scalability", value: "Horizontal" },
        { label: "Architecture", value: "Microservices" },
        { label: "Throughput", value: "1M+ req/sec" }
      ],
      glowClass: "purple-glow"
    },
    {
      icon: Blocks,
      title: "Modularity",
      description: "A flexible plug-in architecture designed for rapid, seamless integration of future technologies and capabilities.",
      details: [
        { label: "Design Pattern", value: "Plug-in" },
        { label: "API Standard", value: "RESTful + GraphQL" },
        { label: "Integration", value: "Real-time" },
        { label: "Expansion", value: "Future-Proof" }
      ],
      glowClass: "gold-glow"
    },
    {
      icon: UserCheck,
      title: "Human Override",
      description: "Maintaining absolute control with a mandatory human approval layer for all critical autonomous actions.",
      details: [
        { label: "Autonomy Level", value: "Supervised" },
        { label: "Critical Actions", value: "Manual Approval" },
        { label: "Control", value: "Always-On" },
        { label: "Transparency", value: "Full Audit Trail" }
      ],
      glowClass: "cyan-glow"
    }
  ];

  return (
    <div className="p-8 h-full overflow-y-auto superman-gradient">
      <div className="max-w-7xl mx-auto">
        {/* Header with Identity Integration */}
        <header className="flex justify-between items-center mb-8 obsidian-panel p-6 rounded-lg">
          <div>
            <h1 className="text-4xl font-bold text-gold mb-2">Gold Standard Ruleset</h1>
            <p className="text-cyan text-lg">The five core principles governing the Zyra AI ecosystem.</p>
            <div className="flex items-center gap-4 mt-3">
              <Badge className="metric-gold px-3 py-1">
                <Brain className="w-4 h-4 mr-1" />
                Neural Framework v2.0
              </Badge>
              <Badge className="metric-cyan px-3 py-1">
                <ShieldCheck className="w-4 h-4 mr-1" />
                Quantum-Safe Protocols
              </Badge>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            {/* System Status Indicators */}
            <div className="text-center">
              <div className="text-2xl font-bold text-kryptonite">100%</div>
              <div className="text-xs text-silver">Compliance Score</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gold">5/5</div>
              <div className="text-xs text-silver">Principles Active</div>
            </div>
            
            {/* Identity Core Integration */}
            {currentUser && (
              <div className="kryptonite-glow rounded-lg p-3 flex items-center gap-2 text-sm">
                <Shield className="w-5 h-5 text-kryptonite" />
                <div>
                  <div className="text-silver">Trust Level</div>
                  <div className="text-kryptonite font-bold">{currentUser.trust_score || 87}/100</div>
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Principles Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8 items-stretch">
          {/* Featured Principle - Reliability (spans 2 columns on large screens) */}
          <div className="xl:col-span-2">
            <PrincipleCard {...principles[0]} />
          </div>
          
          {/* Security First */}
          <PrincipleCard {...principles[1]} />
          
          {/* Performance */}
          <PrincipleCard {...principles[2]} />
          
          {/* Modularity */}
          <PrincipleCard {...principles[3]} />
          
          {/* Human Override */}
          <PrincipleCard {...principles[4]} />
        </div>

        {/* Implementation Status */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="superman-card gold-glow">
            <CardHeader>
              <CardTitle className="text-gold flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" />
                Security Posture
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-silver">Threat Detection</span>
                  <Badge className="metric-green">Active</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Encryption</span>
                  <Badge className="metric-green">AES-256-GCM</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Access Control</span>
                  <Badge className="metric-green">Zero-Trust</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="superman-card cyan-glow">
            <CardHeader>
              <CardTitle className="text-cyan flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-silver">Response Time</span>
                  <Badge className="metric-green">47ms avg</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Uptime</span>
                  <Badge className="metric-green">99.997%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Throughput</span>
                  <Badge className="metric-green">1.2M/sec</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="superman-card purple-glow">
            <CardHeader>
              <CardTitle className="text-purple flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                Governance Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-silver">Human Oversight</span>
                  <Badge className="metric-green">100%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Audit Trail</span>
                  <Badge className="metric-green">Complete</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-silver">Compliance</span>
                  <Badge className="metric-green">Verified</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer with System Information */}
        <div className="mt-12 obsidian-panel p-6 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold text-gold mb-1">SupermanOS Gold Standard Implementation</h3>
              <p className="text-silver text-sm">
                These principles form the foundational architecture of all Zyra AI systems, ensuring 
                maximum reliability, security, and human-centered design across the entire ecosystem.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-kryptonite animate-pulse kryptonite-glow"></div>
              <span className="text-kryptonite font-semibold">All Systems Operational</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}