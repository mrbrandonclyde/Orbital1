import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { themes } from "@/components/theme";
import { Globe, Shield } from "lucide-react";
import SecureWebBrowser from "@/components/SecureWebBrowser";

export default function WebBrowserPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [trustScore, setTrustScore] = useState(87);
  const theme = themes.orbital;

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      setTrustScore(user.trust_score || 87);
    } catch (error) {
      console.log('User not authenticated');
    }
  };

  return (
    <div className={`h-full min-h-0 overflow-hidden ${theme.background}`}>
      {/* Header */}
      <div className={`p-6 ${theme.panel} border-b border-blue-500/30`}>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 blue-glow-panel rounded-lg flex items-center justify-center`}>
              <Globe className={`w-6 h-6 ${theme.textPrimary}`} />
            </div>
            <div>
              <h1 className={`text-2xl font-bold ${theme.textPrimary}`}>
                Secure Web Browser
              </h1>
              <p className={`${theme.textSecondary} text-sm`}>
                Browse the web securely within the Orbital Command Center
              </p>
            </div>
          </div>

          {currentUser && (
            <div className={`rounded-lg px-4 py-2 flex items-center gap-2 blue-glow-panel bg-black/30`}>
              <Shield className={`w-4 h-4 ${theme.textSecondary}`} />
              <span className={theme.textSecondary}>Trust:</span>
              <span className={`font-bold text-blue-300`}>{trustScore}/100</span>
            </div>
          )}
        </div>
      </div>

      {/* Browser Content */}
      <div className="flex-1 p-6 min-h-0">
        <SecureWebBrowser 
          theme={theme} 
          defaultUrl="https://www.google.com"
          year={new Date().getFullYear()}
        />
      </div>
    </div>
  );
}