import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User, Brain, Database, Zap, Settings, Shield, 
  MessageSquare, Atom, Lightbulb, CheckCircle 
} from 'lucide-react';

const EntityCard = ({ entity, description, status = 'implemented' }) => (
  <Card className="bg-slate-800/50 border-slate-700/50">
    <CardContent className="p-4">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium text-white">{entity}</h4>
          <p className="text-sm text-slate-400 mt-1">{description}</p>
        </div>
        <Badge className={
          status === 'implemented' ? 'bg-green-500/20 text-green-300' :
          status === 'partial' ? 'bg-yellow-500/20 text-yellow-300' :
          'bg-gray-500/20 text-gray-300'
        }>
          {status}
        </Badge>
      </div>
    </CardContent>
  </Card>
);

export default function ImplementationAuditPage() {
  const coreSystemsEntities = {
    identity: {
      icon: User,
      title: "Identity Core",
      description: "User management, authentication, profiles, and access control",
      entities: [
        { name: "UserSettings", description: "User preferences, AI model selection, and personalization", status: "implemented" },
        { name: "User", description: "Built-in user entity with RBAC and authentication", status: "implemented" }
      ]
    },
    memory: {
      icon: Brain,
      title: "Memory Core", 
      description: "Three-tiered memory system for cognitive architecture",
      entities: [
        { name: "EpisodicMemory", description: "Sessions, events, conversations with emotional weighting", status: "implemented" },
        { name: "SemanticMemory", description: "Facts, knowledge embeddings, and relationships", status: "implemented" },
        { name: "ProceduralMemory", description: "Learned workflows, habits, and automation patterns", status: "implemented" },
        { name: "ZyraMemory", description: "Legacy unified memory system", status: "implemented" },
        { name: "FeedbackLog", description: "User feedback for continuous learning", status: "implemented" },
        { name: "PromptEvolution", description: "AI model improvement tracking", status: "implemented" }
      ]
    },
    knowledge: {
      icon: Database,
      title: "Knowledge Core",
      description: "Document management, templates, and knowledge graphs",
      entities: [
        { name: "Document", description: "Markdown documents with tagging and search", status: "implemented" },
        { name: "Template", description: "Reusable prompt templates by category", status: "implemented" },
        { name: "DocumentTemplate", description: "Legal and business document templates", status: "implemented" },
        { name: "GeneratedDocument", description: "AI-generated documents from templates", status: "implemented" },
        { name: "SavedSection", description: "Important conversation snippets", status: "implemented" }
      ]
    },
    automation: {
      icon: Zap,
      title: "Automation Core",
      description: "Task management, workflows, and business process automation",
      entities: [
        { name: "ZyraTask", description: "Business tasks with priority and automation triggers", status: "implemented" },
        { name: "BusinessIdea", description: "AI-analyzed business concepts and strategies", status: "implemented" }
      ]
    },
    config_integrations: {
      icon: Settings,
      title: "Config & Integrations Core",
      description: "System configuration, API integrations, and external services",
      entities: [
        { name: "AppConfig", description: "System-wide configuration and Gold Standard rules", status: "implemented" },
        { name: "ZyraIntegration", description: "External API integrations by business unit", status: "implemented" },
        { name: "AIModel", description: "AI agent definitions with specialized capabilities", status: "implemented" }
      ]
    },
    governance: {
      icon: Shield,
      title: "Governance Core",
      description: "Audit trails, compliance, security monitoring, and licensing",
      entities: [
        { name: "SystemCore", description: "Core system monitoring and evolution tracking", status: "implemented" },
        { name: "AuditLog", description: "Immutable system action logs", status: "implemented" },
        { name: "License", description: "Software licensing and customer management", status: "implemented" },
        { name: "Payment", description: "Payment processing and billing", status: "implemented" }
      ]
    },
    communication: {
      icon: MessageSquare,
      title: "Communication Core",
      description: "Chat system, conversations, and messaging infrastructure",
      entities: [
        { name: "Conversation", description: "Chat sessions with metadata and history", status: "implemented" },
        { name: "Message", description: "Individual messages with attachments and AI model tracking", status: "implemented" }
      ]
    },
    scientific: {
      icon: Atom,
      title: "Scientific Core",
      description: "Research projects and computational science workflows",
      entities: [
        { name: "ScientificProject", description: "Multi-domain research projects", status: "implemented" },
        { name: "ComputationJob", description: "High-performance computing tasks", status: "implemented" }
      ]
    }
  };

  const totalEntities = Object.values(coreSystemsEntities)
    .reduce((sum, core) => sum + core.entities.length, 0);
  
  const implementedEntities = Object.values(coreSystemsEntities)
    .reduce((sum, core) => sum + core.entities.filter(e => e.status === 'implemented').length, 0);

  return (
    <div className="p-8 h-full overflow-y-auto">
      <header className="mb-8">
          <h1 className="text-3xl font-bold text-white">SupermanOS Implementation Audit</h1>
          <p className="text-slate-400 mt-1">Complete entity architecture organized by core systems</p>
          <div className="flex gap-4 mt-4">
            <Badge className="bg-green-500/20 text-green-300">
              {implementedEntities}/{totalEntities} Entities Implemented
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-300">
              {Object.keys(coreSystemsEntities).length} Core Systems
            </Badge>
          </div>
      </header>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-slate-800/50 grid grid-cols-4 lg:grid-cols-9 w-full">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="identity">Identity</TabsTrigger>
          <TabsTrigger value="memory">Memory</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="config_integrations">Config</TabsTrigger>
          <TabsTrigger value="governance">Governance</TabsTrigger>
          <TabsTrigger value="communication">Comm</TabsTrigger>
          <TabsTrigger value="scientific">Science</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(coreSystemsEntities).map(([key, core]) => {
              const Icon = core.icon;
              return (
                <Card key={key} className="bg-slate-800/70 border-slate-700/50">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-600/30 rounded-lg flex items-center justify-center">
                        <Icon className="w-5 h-5 text-blue-300" />
                      </div>
                      <div>
                        <CardTitle className="text-white">{core.title}</CardTitle>
                        <Badge variant="outline" className="text-xs">
                          {core.entities.length} entities
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-400 mb-4">{core.description}</p>
                    <div className="space-y-1">
                      {core.entities.slice(0, 3).map(entity => (
                        <div key={entity.name} className="flex items-center justify-between text-xs">
                          <span className="text-slate-300">{entity.name}</span>
                          <CheckCircle className="w-3 h-3 text-green-400" />
                        </div>
                      ))}
                      {core.entities.length > 3 && (
                        <p className="text-xs text-slate-500">+{core.entities.length - 3} more...</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {Object.entries(coreSystemsEntities).map(([key, core]) => (
          <TabsContent key={key} value={key}>
            <Card className="bg-slate-800/70 border-slate-700/50 mb-6">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-600/30 rounded-lg flex items-center justify-center">
                    <core.icon className="w-6 h-6 text-blue-300" />
                  </div>
                  <div>
                    <CardTitle className="text-white">{core.title}</CardTitle>
                    <p className="text-slate-400">{core.description}</p>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {core.entities.map(entity => (
                <EntityCard 
                  key={entity.name}
                  entity={entity.name}
                  description={entity.description}
                  status={entity.status}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}