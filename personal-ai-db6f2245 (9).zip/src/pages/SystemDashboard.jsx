import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import ChatPage from "@/components/chat/ChatPage";
import MainFrame from "@/components/MainFrame";
import { systemStats } from "@/components/mockData";
import { MessageSquare, Activity, Shield, Lock, LayoutPanelLeft, SplitSquareHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import MiniMonitorHUD from "@/components/MiniMonitorHUD"; // Import the new component

export default function SystemDashboard() {
  const [splitMode, setSplitMode] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");

  const handleTabChange = (value) => {
    setActiveTab(value);
    setSplitMode(false); // When a tab is clicked, always switch to tab mode
  }
  
  const toggleSplitMode = () => {
    setSplitMode(prev => !prev);
    if (!splitMode) {
      setActiveTab("split");
    } else {
      setActiveTab("chat"); // Default to chat when exiting split mode
    }
  }

  // Example stats for the HUD
  const overallHealth = 98.5;
  const threatLevel = "minimal";
  const trustScore = 87;

  return (
    <div className="min-h-screen flex flex-col text-white" style={{ backgroundColor: '#0A0A0F' }}>
      {/* Header */}
      <header className="superman-card flex justify-between items-center px-6 py-4 border-b border-cyan/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gold to-amber-500 flex items-center justify-center">
            <Shield className="w-5 h-5 text-obsidian" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gold">SupermanOS</h1>
            <p className="text-silver text-sm opacity-80">Jarvis-Style Quantum Assistant</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <Button
            onClick={toggleSplitMode}
            variant="outline"
            className="flex items-center gap-2 text-cyan border-cyan/50 hover:bg-cyan/10 hover:text-cyan transition-colors"
          >
            {splitMode ? (
              <>
                <LayoutPanelLeft className="w-4 h-4" /> Tabs Mode
              </>
            ) : (
              <>
                <SplitSquareHorizontal className="w-4 h-4" /> Split Mode
              </>
            )}
          </Button>
          <div className="bg-kryptonite/10 px-3 py-1 rounded-lg border border-kryptonite/30">
            <span className="text-kryptonite text-sm font-bold">System Online</span>
          </div>
        </div>
      </header>

      {/* Layout Modes */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {!splitMode ? (
          // TABS MODE
          <Tabs value={activeTab} onValueChange={handleTabChange} className="flex-1 flex flex-col">
            <div className="superman-card border-b border-cyan/20">
              <TabsList className="flex gap-6 px-6 py-3 bg-transparent">
                <TabsTrigger 
                  value="chat" 
                  className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-cyan/20 data-[state=active]:text-cyan data-[state=active]:border data-[state=active]:border-cyan/30 text-silver hover:text-cyan transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  Conversation
                </TabsTrigger>
                <TabsTrigger 
                  value="monitor" 
                  className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-gold/20 data-[state=active]:text-gold data-[state=active]:border data-[state=active]:border-gold/30 text-silver hover:text-gold transition-colors"
                >
                  <Activity className="w-4 h-4" />
                  System Monitor
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="chat" className="flex-1 m-0 overflow-hidden relative">
              <ChatPage />
              {/* Show HUD only in chat tab */}
              <MiniMonitorHUD 
                health={overallHealth} 
                threat={threatLevel} 
                trust={trustScore} 
                onExpand={() => handleTabChange('monitor')} 
              />
            </TabsContent>

            <TabsContent value="monitor" className="flex-1 overflow-y-auto p-8 m-0">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white mb-2">Core Architecture Status</h2>
                <p className="text-silver opacity-80">Real-time monitoring of all system components</p>
              </div>
              <MainFrame stats={systemStats} />
            </TabsContent>
          </Tabs>
        ) : (
          // SPLIT MODE
          <div className="flex flex-1 flex-col lg:flex-row overflow-hidden">
            {/* Chat Side */}
            <div className="w-full lg:w-1/2 border-r-0 lg:border-r border-cyan/30 flex flex-col h-full">
              <ChatPage />
            </div>

            {/* Monitor Side */}
            <div className="w-full lg:w-1/2 overflow-y-auto p-8 h-full">
               <div className="mb-6">
                <h2 className="text-2xl font-bold text-white mb-2">Core Architecture Status</h2>
                <p className="text-silver opacity-80">Real-time monitoring of all system components</p>
              </div>
              <MainFrame stats={systemStats} />
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="superman-card px-6 py-3 border-t border-cyan/20 flex justify-between items-center">
        <p className="text-xs text-silver">© 2025 SupermanOS · Brandon Clyde Ecosystem</p>
        <div className="flex items-center gap-2 text-kryptonite animate-pulse font-bold">
          <Lock className="w-4 h-4" />
          <span>Quantum Secure (AES-256)</span>
        </div>
      </footer>
    </div>
  );
}