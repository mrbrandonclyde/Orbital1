import React, { useState, useEffect } from "react";
import { SavedSection } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Star, StarOff, Trash2, MessageSquare, Tag, Bookmark, Shield, Brain } from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import MessageBubble from "@/components/chat/MessageBubble";

export default function SavedSectionsPage() {
  const [savedSections, setSavedSections] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSection, setSelectedSection] = useState(null);
  const [selectedTag, setSelectedTag] = useState('all');
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadSavedSections();
    loadCurrentUser();
  }, []);

  const loadSavedSections = async () => {
    const sections = await SavedSection.list('-updated_date');
    setSavedSections(sections);
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated');
    }
  };

  const filteredSections = savedSections.filter(section => {
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = section.title.toLowerCase().includes(searchLower) ||
                         section.notes?.toLowerCase().includes(searchLower) ||
                         section.messages.some(msg => msg.content.toLowerCase().includes(searchLower));
    
    const matchesTag = selectedTag === 'all' || (section.tags || []).includes(selectedTag);
    
    return matchesSearch && matchesTag;
  });

  const toggleFavorite = async (section) => {
    await SavedSection.update(section.id, { is_favorite: !section.is_favorite });
    loadSavedSections();
  };

  const deleteSection = async (sectionId) => {
    if (confirm('Are you sure you want to delete this archived conversation? This action is permanent.')) {
      await SavedSection.delete(sectionId);
      setSelectedSection(null);
      loadSavedSections();
    }
  };

  const getAllTags = () => {
    const allTags = savedSections.flatMap(section => section.tags || []);
    return [...new Set(allTags)];
  };

  return (
    <div className="flex h-full superman-gradient">
      {/* Left Panel: Section List */}
      <div className="w-1/3 max-w-sm flex-shrink-0 obsidian-panel flex flex-col">
        <div className="p-6 border-b border-cyan/30">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gold flex items-center gap-2">
              <Bookmark className="w-5 h-5" />
              Memory Archives
            </h2>
            {currentUser && (
              <div className="kryptonite-glow rounded-lg p-2 flex items-center gap-1 text-xs">
                <Shield className="w-3 h-3 text-kryptonite" />
                <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
              </div>
            )}
          </div>
          
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-silver" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search archived conversations..."
                className="pl-10"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={() => setSelectedTag('all')}
                className={selectedTag === 'all' ? 'btn-cyan' : 'bg-transparent border-cyan/30 text-silver hover:bg-cyan/10'}
              >
                All
              </Button>
              {getAllTags().map(tag => (
                <Button
                  key={tag}
                  size="sm"
                  onClick={() => setSelectedTag(tag)}
                  className={`capitalize ${selectedTag === tag ? 'btn-cyan' : 'bg-transparent border-cyan/30 text-silver hover:bg-cyan/10'}`}
                >
                  {tag}
                </Button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <AnimatePresence>
            {filteredSections.map(section => (
              <motion.div
                key={section.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                layout
              >
                <Card
                  className={`mb-3 cursor-pointer transition-all superman-card ${
                    selectedSection?.id === section.id ? 'cyan-glow' : 'hover:cyan-glow'
                  }`}
                  onClick={() => setSelectedSection(section)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium text-sm flex items-center gap-2 text-silver">
                        <MessageSquare className="w-4 h-4 text-cyan" />
                        <span className="truncate pr-2">{section.title}</span>
                        {section.is_favorite && <Star className="w-3 h-3 text-gold fill-current" />}
                      </h3>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-silver/70 hover:text-gold hover:bg-transparent"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(section);
                        }}
                      >
                        {section.is_favorite ? 
                          <Star className="w-3 h-3 text-gold fill-current" /> : 
                          <StarOff className="w-3 h-3" />
                        }
                      </Button>
                    </div>
                    
                    <p className="text-xs text-silver/70 line-clamp-2 mb-3 leading-relaxed">
                      {section.messages[0]?.content.substring(0, 120)}...
                    </p>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {(section.tags || []).slice(0, 2).map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs capitalize bg-cyan/10 text-cyan border border-cyan/30">
                          <Tag className="w-2 h-2 mr-1" />
                          {tag}
                        </Badge>
                      ))}
                      {(section.tags || []).length > 2 && (
                        <Badge variant="secondary" className="text-xs bg-cyan/10 text-cyan border border-cyan/30">
                          +{(section.tags || []).length - 2}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex justify-between items-center text-xs text-silver/60">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" />
                        {section.messages.length} messages
                      </span>
                      <span>{format(new Date(section.updated_date), 'MMM d, HH:mm')}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {filteredSections.length === 0 && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12 text-silver/60"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full obsidian-panel flex items-center justify-center">
                <MessageSquare className="w-8 h-8 text-cyan/30" />
              </div>
              <h3 className="text-lg font-medium mb-2">No Archives Found</h3>
              <p className="text-sm leading-relaxed">
                {searchQuery || selectedTag !== 'all' ? 
                  'Try adjusting your search or filter criteria.' : 
                  'Save important conversation snippets to build your knowledge base.'}
              </p>
            </motion.div>
          )}
        </div>
      </div>

      {/* Right Panel: Conversation Viewer */}
      <div className="flex-1 flex flex-col">
        {selectedSection ? (
          <>
            <div className="p-6 border-b border-cyan/30 obsidian-panel flex-shrink-0">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h1 className="text-2xl font-bold text-gold mb-2">{selectedSection.title}</h1>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {(selectedSection.tags || []).map(tag => (
                      <Badge key={tag} className="flex items-center gap-1 metric-purple capitalize">
                        <Tag className="w-3 h-3" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  {selectedSection.notes && (
                    <div className="p-3 rounded-lg bg-black/20 border border-amber/20">
                      <h4 className="text-sm font-medium text-amber mb-1">Notes:</h4>
                      <p className="text-silver/80 text-sm leading-relaxed">{selectedSection.notes}</p>
                    </div>
                  )}
                </div>
                <div className="flex gap-2 ml-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-silver hover:text-gold"
                    onClick={() => toggleFavorite(selectedSection)}
                  >
                    {selectedSection.is_favorite ? 
                      <Star className="w-4 h-4 text-gold fill-current" /> : 
                      <Star className="w-4 h-4" />
                    }
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-silver hover:text-crimson"
                    onClick={() => deleteSection(selectedSection.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-4xl mx-auto space-y-6">
                <AnimatePresence>
                  {selectedSection.messages.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <MessageBubble 
                        message={message} 
                        aiName="Zyra" 
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center p-12 max-w-md"
            >
              <div className="w-20 h-20 mx-auto mb-6 rounded-full obsidian-panel cyan-glow flex items-center justify-center">
                <Brain className="w-10 h-10 text-cyan" />
              </div>
              <h2 className="text-2xl font-bold text-gold mb-3">Memory Archive</h2>
              <p className="text-silver/80 mb-4 leading-relaxed">
                Select a saved conversation to explore your archived knowledge and insights.
              </p>
              <div className="flex flex-col gap-2 text-sm text-silver/60">
                <div className="flex items-center justify-center gap-2">
                  <Star className="w-4 h-4 text-gold" />
                  <span>Favorite important conversations</span>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Tag className="w-4 h-4 text-cyan" />
                  <span>Organize with smart tags</span>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Search className="w-4 h-4 text-amber" />
                  <span>Search across all content</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}