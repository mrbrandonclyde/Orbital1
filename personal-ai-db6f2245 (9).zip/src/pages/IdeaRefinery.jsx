import React, { useState, useEffect } from "react";
import { BusinessIdea } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Lightbulb, Plus, TrendingUp, AlertTriangle, CheckCircle, 
  Star, Clock, DollarSign, Target, Zap, Brain, Loader2, Shield
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function IdeaRefineryPage() {
  const [ideas, setIdeas] = useState([]);
  const [selectedIdea, setSelectedIdea] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [currentUser, setCurrentUser] = useState(null);

  const [newIdea, setNewIdea] = useState({
    title: '',
    description: '',
    category: 'technology',
    target_market: '',
    revenue_model: '',
    investment_required: '',
    timeline_months: ''
  });

  useEffect(() => {
    loadIdeas();
    loadCurrentUser();
  }, []);

  const loadIdeas = async () => {
    const data = await BusinessIdea.list('-updated_date');
    setIdeas(data);
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.log('User not authenticated:', error.message);
    }
  };

  const analyzeIdea = async (idea) => {
    setIsAnalyzing(true);
    try {
      const analysisPrompt = `
Analyze this business idea comprehensively:

Title: ${idea.title}
Description: ${idea.description}
Category: ${idea.category}
Target Market: ${idea.target_market || 'Not specified'}
Revenue Model: ${idea.revenue_model || 'Not specified'}

Provide a detailed analysis in this exact JSON format:
{
  "innovation_score": [score 1-10],
  "feasibility_score": [score 1-10], 
  "market_fit_score": [score 1-10],
  "overall_score": [average of above scores],
  "strengths": ["strength1", "strength2", "strength3"],
  "risks": ["risk1", "risk2", "risk3"],
  "opportunities": ["opportunity1", "opportunity2", "opportunity3"],
  "expansion_notes": "Detailed expansion of the concept with additional insights",
  "next_steps": ["step1", "step2", "step3", "step4", "step5"]
}`;

      const analysis = await InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            innovation_score: { type: "number" },
            feasibility_score: { type: "number" },
            market_fit_score: { type: "number" },
            overall_score: { type: "number" },
            strengths: { type: "array", items: { type: "string" } },
            risks: { type: "array", items: { type: "string" } },
            opportunities: { type: "array", items: { type: "string" } },
            expansion_notes: { type: "string" },
            next_steps: { type: "array", items: { type: "string" } }
          }
        }
      });

      const updatedIdea = await BusinessIdea.update(idea.id, {
        ai_analysis: analysis
      });

      loadIdeas();
      if (selectedIdea?.id === idea.id) {
        setSelectedIdea(updatedIdea);
      }
    } catch (error) {
      console.error('Error analyzing idea:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmitIdea = async (e) => {
    e.preventDefault();
    const createdIdea = await BusinessIdea.create(newIdea);
    setIsDialogOpen(false);
    setNewIdea({
      title: '', description: '', category: 'technology',
      target_market: '', revenue_model: '', investment_required: '', timeline_months: ''
    });
    loadIdeas();
    
    await analyzeIdea(createdIdea);
  };

  const filteredIdeas = ideas.filter(idea => {
    const statusMatch = filterStatus === 'all' || idea.status === filterStatus;
    const categoryMatch = filterCategory === 'all' || idea.category === filterCategory;
    return statusMatch && categoryMatch;
  });

  const getScoreColor = (score) => {
    if (score >= 8) return 'text-kryptonite';
    if (score >= 6) return 'text-amber';
    return 'text-crimson';
  };

  const getMetricClass = (score) => {
    if (score >= 8) return 'metric-green';
    if (score >= 6) return 'metric-amber';
    return 'metric-red';
  };

  return (
    <div className="p-8 h-full overflow-y-auto superman-gradient">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8 obsidian-panel p-4 rounded-lg">
            <div>
                <h1 className="text-3xl font-bold text-gold">Idea Refinery</h1>
                <p className="text-cyan mt-1">AI-powered business idea analysis and refinement.</p>
            </div>
          
          <div className="flex items-center gap-4">
            {currentUser && (
              <div className="kryptonite-glow rounded-lg p-2 flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-kryptonite" />
                <span className="text-silver">Trust:</span>
                <span className="text-kryptonite font-bold">{currentUser.trust_score || 87}</span>
              </div>
            )}
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="btn-cyan">
                  <Plus className="w-4 h-4 mr-2" />
                  New Idea
                </Button>
              </DialogTrigger>
              <DialogContent className="obsidian-panel">
                <DialogHeader>
                  <DialogTitle className="text-gold">Submit New Business Idea</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmitIdea} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Input
                        placeholder="Idea Title"
                        value={newIdea.title}
                        onChange={(e) => setNewIdea({...newIdea, title: e.target.value})}
                        className="text-silver placeholder:text-silver/60"
                        required
                      />
                    </div>
                    <Select value={newIdea.category} onValueChange={(value) => setNewIdea({...newIdea, category: value})}>
                      <SelectTrigger className="text-silver">
                        <SelectValue className="text-silver" />
                      </SelectTrigger>
                      <SelectContent className="superman-card">
                        <SelectItem value="technology" className="text-silver">Technology</SelectItem>
                        <SelectItem value="finance" className="text-silver">Finance</SelectItem>
                        <SelectItem value="energy" className="text-silver">Energy</SelectItem>
                        <SelectItem value="security" className="text-silver">Security</SelectItem>
                        <SelectItem value="healthcare" className="text-silver">Healthcare</SelectItem>
                        <SelectItem value="real_estate" className="text-silver">Real Estate</SelectItem>
                        <SelectItem value="education" className="text-silver">Education</SelectItem>
                        <SelectItem value="other" className="text-silver">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Investment Required ($)"
                      type="number"
                      value={newIdea.investment_required}
                      onChange={(e) => setNewIdea({...newIdea, investment_required: e.target.value})}
                      className="text-silver placeholder:text-silver/60"
                    />
                  </div>
                  <Textarea
                    placeholder="Detailed description of your business idea..."
                    value={newIdea.description}
                    onChange={(e) => setNewIdea({...newIdea, description: e.target.value})}
                    className="h-24 text-silver placeholder:text-silver/60"
                    required
                  />
                  <Input
                    placeholder="Target Market"
                    value={newIdea.target_market}
                    onChange={(e) => setNewIdea({...newIdea, target_market: e.target.value})}
                    className="text-silver placeholder:text-silver/60"
                  />
                  <Input
                    placeholder="Revenue Model"
                    value={newIdea.revenue_model}
                    onChange={(e) => setNewIdea({...newIdea, revenue_model: e.target.value})}
                    className="text-silver placeholder:text-silver/60"
                  />
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="border-silver/30 text-silver hover:bg-silver/10">
                      Cancel
                    </Button>
                    <Button type="submit" className="btn-cyan">
                      Submit for AI Analysis
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <div className="flex gap-8">
          <div className="w-1/3">
            <div className="flex gap-2 mb-4">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-32 text-silver">
                  <SelectValue className="text-silver" />
                </SelectTrigger>
                <SelectContent className="superman-card">
                  <SelectItem value="all" className="text-silver">All Status</SelectItem>
                  <SelectItem value="concept" className="text-silver">Concept</SelectItem>
                  <SelectItem value="researching" className="text-silver">Researching</SelectItem>
                  <SelectItem value="developing" className="text-silver">Developing</SelectItem>
                  <SelectItem value="testing" className="text-silver">Testing</SelectItem>
                  <SelectItem value="implemented" className="text-silver">Implemented</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-32 text-silver">
                  <SelectValue className="text-silver" />
                </SelectTrigger>
                <SelectContent className="superman-card">
                  <SelectItem value="all" className="text-silver">All Categories</SelectItem>
                  <SelectItem value="technology" className="text-silver">Technology</SelectItem>
                  <SelectItem value="finance" className="text-silver">Finance</SelectItem>
                  <SelectItem value="energy" className="text-silver">Energy</SelectItem>
                  <SelectItem value="security" className="text-silver">Security</SelectItem>
                  <SelectItem value="healthcare" className="text-silver">Healthcare</SelectItem>
                  <SelectItem value="real_estate" className="text-silver">Real Estate</SelectItem>
                  <SelectItem value="education" className="text-silver">Education</SelectItem>
                  <SelectItem value="other" className="text-silver">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
              <AnimatePresence>
                {filteredIdeas.map(idea => (
                  <motion.div
                    key={idea.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                  >
                    <Card 
                      className={`cursor-pointer transition-all superman-card ${
                        selectedIdea?.id === idea.id ? 'cyan-glow' : ''
                      }`}
                      onClick={() => setSelectedIdea(idea)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-sm text-silver">{idea.title}</h3>
                          {idea.ai_analysis?.overall_score && (
                            <div className={`px-2 py-1 rounded-full text-xs font-bold ${getMetricClass(idea.ai_analysis.overall_score)}`}>
                              {idea.ai_analysis.overall_score.toFixed(1)}
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-silver/70 line-clamp-2 mb-2">
                          {idea.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="capitalize text-silver bg-cyan/10 border-cyan/30">{idea.category}</Badge>
                          <Badge variant={idea.status === 'implemented' ? 'default' : 'outline'} className={`text-xs capitalize ${
                            idea.status === 'implemented' 
                              ? 'text-kryptonite bg-kryptonite/10 border-kryptonite/30' 
                              : 'text-silver border-silver/30'
                          }`}>
                            {idea.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <div className="flex-1">
            {selectedIdea ? (
              <div className="space-y-6">
                <Card className="superman-card">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-2xl text-gold">{selectedIdea.title}</CardTitle>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="secondary" className="capitalize text-silver bg-cyan/10 border-cyan/30">{selectedIdea.category}</Badge>
                          <Badge variant={selectedIdea.status === 'implemented' ? 'default' : 'outline'} className={`capitalize ${
                            selectedIdea.status === 'implemented' 
                              ? 'text-kryptonite bg-kryptonite/10 border-kryptonite/30' 
                              : 'text-silver border-silver/30'
                          }`}>
                            {selectedIdea.status}
                          </Badge>
                        </div>
                      </div>
                      {!selectedIdea.ai_analysis && (
                        <Button onClick={() => analyzeIdea(selectedIdea)} disabled={isAnalyzing} className="btn-cyan">
                          {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Brain className="w-4 h-4 mr-2" />}
                          {isAnalyzing ? 'Analyzing...' : 'Analyze with AI'}
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-silver leading-relaxed mb-4">{selectedIdea.description}</p>
                    
                    {selectedIdea.target_market && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-sm text-cyan mb-1">Target Market</h4>
                        <p className="text-sm text-silver">{selectedIdea.target_market}</p>
                      </div>
                    )}
                    
                    {selectedIdea.revenue_model && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-sm text-cyan mb-1">Revenue Model</h4>
                        <p className="text-sm text-silver">{selectedIdea.revenue_model}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {selectedIdea.ai_analysis && (
                  <Card className="superman-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-gold">
                        <Zap className="w-5 h-5 text-gold" />
                        AI Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="scores" className="space-y-4">
                        <TabsList className="bg-transparent mb-6 p-0 border-b border-cyan/30 w-full justify-start rounded-none">
                          <TabsTrigger value="scores" className="data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] text-silver">Scores</TabsTrigger>
                          <TabsTrigger value="insights" className="data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] text-silver">Insights</TabsTrigger>
                          <TabsTrigger value="expansion" className="data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] text-silver">Expansion</TabsTrigger>
                          <TabsTrigger value="actions" className="data-[state=active]:text-gold data-[state=active]:shadow-[inset_0_-2px_0_#FFD700] text-silver">Next Steps</TabsTrigger>
                        </TabsList>

                        <TabsContent value="scores">
                           <div className="grid grid-cols-2 gap-4">
                            {[
                              { key: 'innovation_score', label: 'Innovation', icon: Star },
                              { key: 'feasibility_score', label: 'Feasibility', icon: CheckCircle },
                              { key: 'market_fit_score', label: 'Market Fit', icon: Target },
                              { key: 'overall_score', label: 'Overall Score', icon: TrendingUp }
                            ].map(({ key, label, icon: Icon }) => (
                              <div key={key} className="p-4 metric-cyan rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                  <Icon className="w-4 h-4 text-cyan" />
                                  <span className="font-medium text-sm text-silver">{label}</span>
                                </div>
                                <div className="flex items-center gap-3">
                                  <Progress value={selectedIdea.ai_analysis[key] * 10} className="flex-1 h-2 [&>div]:progress-cyan" />
                                  <span className={`font-bold ${getScoreColor(selectedIdea.ai_analysis[key])}`}>
                                    {selectedIdea.ai_analysis[key].toFixed(1)}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </TabsContent>

                        <TabsContent value="insights">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-silver">
                            <div>
                              <h4 className="font-semibold text-kryptonite mb-2 flex items-center gap-1">
                                <CheckCircle className="w-4 h-4" />
                                Strengths
                              </h4>
                              <ul className="space-y-1 text-sm list-disc pl-5 text-silver">
                                {selectedIdea.ai_analysis.strengths.map((strength, i) => (
                                  <li key={i}>{strength}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="font-semibold text-crimson mb-2 flex items-center gap-1">
                                <AlertTriangle className="w-4 h-4" />
                                Risks
                              </h4>
                              <ul className="space-y-1 text-sm list-disc pl-5 text-silver">
                                {selectedIdea.ai_analysis.risks.map((risk, i) => (
                                  <li key={i}>{risk}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                          
                          <div className="mt-4 text-silver">
                            <h4 className="font-semibold text-cyan mb-2 flex items-center gap-1">
                              <TrendingUp className="w-4 h-4" />
                              Opportunities
                            </h4>
                            <ul className="space-y-1 text-sm list-disc pl-5 text-silver">
                              {selectedIdea.ai_analysis.opportunities.map((opportunity, i) => (
                                <li key={i}>{opportunity}</li>
                              ))}
                            </ul>
                          </div>
                        </TabsContent>

                        <TabsContent value="expansion">
                          <div className="p-4 metric-purple rounded-lg border border-purple">
                            <h4 className="font-semibold text-purple mb-2">Expanded Concept</h4>
                            <p className="text-sm text-silver leading-relaxed">
                              {selectedIdea.ai_analysis.expansion_notes}
                            </p>
                          </div>
                        </TabsContent>

                        <TabsContent value="actions">
                          <div className="space-y-2">
                            {selectedIdea.ai_analysis.next_steps.map((step, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 superman-card">
                                <div className="w-6 h-6 btn-cyan text-black rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                                  {i + 1}
                                </div>
                                <span className="text-sm text-silver">{step}</span>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <Card className="superman-card h-96 flex items-center justify-center">
                <div className="text-center text-silver/60">
                  <Lightbulb className="w-16 h-16 mx-auto mb-4 text-cyan/30" />
                  <p className="text-lg font-medium text-silver">Select an idea to analyze</p>
                  <p className="text-sm text-silver/70">Your AI-powered business intelligence awaits</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}