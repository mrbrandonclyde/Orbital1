import React from "react";
import { useTimeline } from "./TimelineProvider";
import { format } from "date-fns";
import { History, Activity, Anchor, Camera, GitBranch } from "lucide-react";

export default function TimelineHUD() {
    const { 
      currentYear, 
      activeBranch, 
      playing, 
      checkpoints, 
      temporalAnchors, 
      quantumStates, 
      realitySnapshots,
      branches,
      speed
    } = useTimeline();

    // Create a proper date object from currentYear, defaulting to current time if invalid
    const getCurrentTime = () => {
        try {
            if (typeof currentYear === 'number' && currentYear > 0) {
                return new Date(currentYear, 0, 1); // January 1st of the current year
            }
            return new Date(); // Fallback to current time
        } catch (error) {
            return new Date(); // Fallback to current time on any error
        }
    };

    const currentTime = getCurrentTime();

    return (
        <div className="cyan-glow-panel p-4 rounded-xl w-72">
            <h3 className="text-cyan-300 font-semibold text-sm mb-3 flex items-center gap-2">
                <History className="w-4 h-4"/> Timeline HUD
            </h3>
            
            <div className="space-y-3 text-xs">
                {/* Status Row */}
                <div className="flex justify-between items-center">
                    <span className="text-gray-400">Status:</span>
                    <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${playing ? 'bg-green-500/20 text-green-300' : 'bg-amber-500/20 text-amber-300'}`}>
                        {playing ? 'PLAYING' : 'PAUSED'}
                    </span>
                </div>

                {/* Year Display */}
                <div className="flex justify-between items-center">
                    <span className="text-gray-400">Year:</span>
                    <span className="font-semibold text-gray-200">{currentYear || 2025}</span>
                </div>
                
                <div className="flex justify-between items-center">
                    <span className="text-gray-400">Speed:</span>
                    <span className="font-semibold text-gray-200">{speed}x</span>
                </div>

                {/* Branch Info */}
                <div className="flex justify-between items-center">
                    <span className="text-gray-400 flex items-center gap-1">
                      <GitBranch className="w-3 h-3" />Branch:
                    </span>
                    <span className="font-semibold text-gray-200">{activeBranch}</span>
                </div>

                <div className="border-t border-[#3A3A6A]/60 my-2"></div>

                {/* Resource Counts */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400">📍</span>
                    <span className="text-xs">{checkpoints?.length || 0} Checkpoints</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Anchor className="w-3 h-3 text-gray-400" />
                    <span className="text-xs">{temporalAnchors?.length || 0} Anchors</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Activity className="w-3 h-3 text-gray-400" />
                    <span className="text-xs">{quantumStates?.length || 0} Quantum</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Camera className="w-3 h-3 text-gray-400" />
                    <span className="text-xs">{realitySnapshots?.length || 0} Snapshots</span>
                  </div>
                </div>

                <div className="border-t border-[#3A3A6A]/60 my-2"></div>

                {/* Time Display */}
                <div className="text-center">
                    <p className="text-lg font-bold tracking-wider text-white">
                        {format(currentTime, "HH:mm:ss")}
                    </p>
                    <p className="text-xs text-gray-400">
                        {format(currentTime, "d MMM yyyy")}
                    </p>
                </div>

                {/* Branches Count */}
                <div className="flex justify-between items-center">
                    <span className="text-gray-400">Branches:</span>
                    <span className="font-semibold text-gray-200">{Object.keys(branches || {}).length}</span>
                </div>
            </div>
        </div>
    );
}