import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Cpu, Database, Shield, Cloud, Activity, Zap } from 'lucide-react';

export const SystemKernel = () => {
  const [kernelStats, setKernelStats] = useState({
    modules: {
      intelligence: { status: 'active', load: 78, memory: 2.4 },
      memory: { status: 'active', load: 82, memory: 4.1 },
      automation: { status: 'active', load: 65, memory: 1.8 },
      security: { status: 'active', load: 91, memory: 3.2 }
    },
    systemHealth: 98.7,
    quantumEncryption: 'active',
    uptime: '99.97%'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setKernelStats(prev => ({
        ...prev,
        modules: Object.keys(prev.modules).reduce((acc, key) => {
          acc[key] = {
            ...prev.modules[key],
            load: Math.max(20, Math.min(95, prev.modules[key].load + (Math.random() - 0.5) * 10)),
            memory: Math.max(0.5, Math.min(8, prev.modules[key].memory + (Math.random() - 0.5) * 0.5))
          };
          return acc;
        }, {})
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-2 gap-4">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            System Kernel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(kernelStats.modules).map(([name, stats]) => (
            <div key={name} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-300 capitalize">{name} Module</span>
                <Badge variant="outline" className="text-green-400 border-green-400/30">
                  {stats.status}
                </Badge>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">CPU Load</span>
                  <span className="text-white">{stats.load.toFixed(1)}%</span>
                </div>
                <Progress value={stats.load} className="h-1" />
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Memory</span>
                  <span className="text-white">{stats.memory.toFixed(1)} GB</span>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-400" />
            Security Layer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-slate-300 text-sm">Quantum Encryption</span>
            <Badge className="bg-purple-500/20 text-purple-300">Kyber-768</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-300 text-sm">TLS Protocol</span>
            <Badge className="bg-blue-500/20 text-blue-300">1.3</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-300 text-sm">AES Encryption</span>
            <Badge className="bg-green-500/20 text-green-300">256-bit</Badge>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">System Health</span>
              <span className="text-white">{kernelStats.systemHealth}%</span>
            </div>
            <Progress value={kernelStats.systemHealth} className="h-1" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export const DatabaseCore = () => {
  const [dbStats, setDbStats] = useState({
    postgres: { connections: 42, queries: 1847, size: '12.4 GB' },
    vectorDb: { embeddings: 2847291, dimensions: 1536, similarity: 0.94 },
    memory: { cached: 89.2, indexed: 94.7, recall: 99.1 }
  });

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-white flex items-center gap-2">
          <Database className="w-5 h-5 text-cyan-400" />
          Database Core
        </CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">PostgreSQL</h4>
          <div className="text-xs text-slate-400">
            <p>Connections: {dbStats.postgres.connections}</p>
            <p>Queries/min: {dbStats.postgres.queries}</p>
            <p>Size: {dbStats.postgres.size}</p>
          </div>
        </div>
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">Vector DB</h4>
          <div className="text-xs text-slate-400">
            <p>Embeddings: {dbStats.vectorDb.embeddings.toLocaleString()}</p>
            <p>Dimensions: {dbStats.vectorDb.dimensions}</p>
            <p>Similarity: {dbStats.vectorDb.similarity}</p>
          </div>
        </div>
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">Memory Engine</h4>
          <div className="space-y-1">
            <div className="text-xs text-slate-400">
              <span>Cached: {dbStats.memory.cached}%</span>
            </div>
            <Progress value={dbStats.memory.cached} className="h-1" />
            <div className="text-xs text-slate-400">
              <span>Recall: {dbStats.memory.recall}%</span>
            </div>
            <Progress value={dbStats.memory.recall} className="h-1" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const DeploymentStatus = () => {
  const [deploymentStats, setDeploymentStats] = useState({
    kubernetes: {
      nodes: 5,
      pods: 23,
      services: 12,
      health: 98.9
    },
    docker: {
      containers: 23,
      images: 15,
      volumes: 8
    },
    cloud: {
      regions: 3,
      availability: 99.97,
      latency: 12
    }
  });

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-white flex items-center gap-2">
          <Cloud className="w-5 h-5 text-blue-400" />
          Deployment Infrastructure
        </CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">Kubernetes</h4>
          <div className="text-xs text-slate-400">
            <p>Nodes: {deploymentStats.kubernetes.nodes}</p>
            <p>Pods: {deploymentStats.kubernetes.pods}</p>
            <p>Services: {deploymentStats.kubernetes.services}</p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-400">Health: {deploymentStats.kubernetes.health}%</span>
            <Progress value={deploymentStats.kubernetes.health} className="h-1" />
          </div>
        </div>
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">Docker</h4>
          <div className="text-xs text-slate-400">
            <p>Containers: {deploymentStats.docker.containers}</p>
            <p>Images: {deploymentStats.docker.images}</p>
            <p>Volumes: {deploymentStats.docker.volumes}</p>
          </div>
        </div>
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-300">Cloud</h4>
          <div className="text-xs text-slate-400">
            <p>Regions: {deploymentStats.cloud.regions}</p>
            <p>Availability: {deploymentStats.cloud.availability}%</p>
            <p>Latency: {deploymentStats.cloud.latency}ms</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};