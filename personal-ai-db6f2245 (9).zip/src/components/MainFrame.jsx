import React from "react";
import SatelliteFeed from "./SatelliteFeed";

export default function MainFrame({ settings }) {
  return (
    <div className="w-full h-full relative p-4">
       {settings.satelliteView ? (
        <SatelliteFeed />
       ) : (
        <div className="absolute inset-0 flex items-center justify-center -z-10">
          <div className="text-center text-gray-700">
              <div className="text-5xl mb-4 text-cyan-500/50">
                🧠
              </div>
              <h2 className="text-3xl font-bold">Main Temporal Visualization</h2>
              <p className="text-lg text-gray-500">
                This area will render the 3D node graph of system states,
                <br />
                temporal branches, and predicted future events.
              </p>
              <div className="mt-6 p-4 bg-black/20 border border-gray-700/50 rounded-lg inline-block text-sm">
                  <h4 className="font-semibold text-gray-400 mb-2">Current Settings:</h4>
                  <p>Prediction Engine: <span className="font-mono text-gray-300">{settings.prediction ? 'ON' : 'OFF'}</span></p>
                  <p>Immersive Mode: <span className="font-mono text-gray-300">{settings.immersiveMode ? 'ON' : 'OFF'}</span></p>
              </div>
          </div>
        </div>
       )}
    </div>
  );
}