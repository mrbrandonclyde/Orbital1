import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function MorphogenicOverlay({ mountRef, stats }) {
  const sceneRef = useRef(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Capture the current mount element for cleanup
    const currentMount = mountRef.current;

    // Scene + Camera
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#060612");
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      60,
      currentMount.clientWidth / currentMount.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 8;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    currentMount.appendChild(renderer.domElement);

    // Central Core Sphere (Zyra's consciousness)
    const coreGeometry = new THREE.SphereGeometry(0.5, 32, 32);
    const coreMaterial = new THREE.MeshStandardMaterial({
      color: "#00e5ff",
      emissive: "#00e5ff",
      emissiveIntensity: 1.5,
    });
    const coreSphere = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(coreSphere);

    // Torus Energy Field
    const torusGeometry = new THREE.TorusGeometry(4, 0.05, 16, 100);
    const torusMaterial = new THREE.MeshStandardMaterial({
      color: "#00e5ff",
      emissive: "#00e5ff",
      emissiveIntensity: 1,
    });
    const torus = new THREE.Mesh(torusGeometry, torusMaterial);
    torus.rotation.x = Math.PI / 2;
    scene.add(torus);

    // Lights
    scene.add(new THREE.AmbientLight(0x404040, 2));
    const pointLight = new THREE.PointLight(0xffffff, 2);
    pointLight.position.set(10, 10, 10);
    scene.add(pointLight);

    // System Core Nodes
    const coreColors = [
      "#ff0000", // Identity (Red)
      "#ffcc00", // Memory (Gold) 
      "#00ff00", // Knowledge (Green)
      "#0000ff", // Automation (Blue)
      "#ff6600", // Config (Orange)
      "#9900ff", // Governance (Purple)
    ];
    const nodeRadius = 2.5;
    const coreNodes = [];

    coreColors.forEach((color, i) => {
      const angle = (i / coreColors.length) * Math.PI * 2;
      const x = Math.cos(angle) * nodeRadius;
      const y = Math.sin(angle) * nodeRadius;

      const nodeGeometry = new THREE.SphereGeometry(0.3, 32, 32);
      const nodeMaterial = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 1,
      });
      const nodeSphere = new THREE.Mesh(nodeGeometry, nodeMaterial);
      nodeSphere.position.set(x, y, 0);
      scene.add(nodeSphere);
      coreNodes.push(nodeSphere);

      // Connection lines to central core
      const points = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(x, y, 0)];
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const lineMaterial = new THREE.LineBasicMaterial({ color });
      const line = new THREE.Line(geometry, lineMaterial);
      scene.add(line);
    });

    // Animation Loop
    let animationId;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      
      // Central core pulsing based on system health
      coreSphere.scale.setScalar(1 + 0.05 * Math.sin(Date.now() * 0.003));
      
      // Torus rotation speed based on system activity
      torus.rotation.z += 0.002;
      
      // Individual core node pulsing based on performance
      coreNodes.forEach((node, i) => {
        const performance = stats ? Object.values(stats)[i]?.metrics?.performance || 90 : 90;
        const pulseIntensity = performance / 100;
        node.scale.setScalar(1 + 0.03 * Math.sin(Date.now() * 0.004 + i) * pulseIntensity);
      });
      
      renderer.render(scene, camera);
    };
    animate();

    // Resize Handling
    const handleResize = () => {
      if (!currentMount) return;
      camera.aspect = currentMount.clientWidth / currentMount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    };
    window.addEventListener("resize", handleResize);

    // Cleanup function
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
      if (currentMount && renderer.domElement && currentMount.contains(renderer.domElement)) {
        currentMount.removeChild(renderer.domElement);
      }
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
    };
  }, [mountRef, stats]);

  return null; // The 3D scene is rendered directly to the mountRef
}