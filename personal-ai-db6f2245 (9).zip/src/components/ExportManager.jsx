import React from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ExportManager() {
  return (
    <div className="cyan-glow-panel p-4 rounded-xl">
      <h3 className="text-cyan-300 font-semibold mb-2 flex items-center gap-2"><Download className="w-4 h-4"/> Export Manager</h3>
      <Button className="w-full bg-cyan-600/50 hover:bg-cyan-600/70 border border-cyan-500 text-white shadow-md text-sm">
        Export Data
      </Button>
    </div>
  );
}