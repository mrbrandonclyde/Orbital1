import React, { useState, useEffect, useRef } from "react";

export default function VoiceControls({ onCommand }) {
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      console.warn("Voice recognition not supported");
      return;
    }

    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = false;
    recognitionRef.current.lang = "en-US";

    recognitionRef.current.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript;
      if (onCommand) onCommand(transcript);
    };

    recognitionRef.current.onerror = (err) => {
      console.error("Voice recognition error:", err);
    };

    return () => {
      recognitionRef.current?.stop();
    };
  }, [onCommand]);

  const toggleListening = () => {
    if (!recognitionRef.current) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      recognitionRef.current.start();
      setListening(true);
    }
  };

  return (
    <button
      onClick={toggleListening}
      className={`px-4 py-2 rounded-md ${
        listening ? "bg-red-600" : "bg-cyan-600"
      } text-white shadow-lg`}
    >
      {listening ? "Stop Listening 🎤" : "Start Voice Control 🎤"}
    </button>
  );
}