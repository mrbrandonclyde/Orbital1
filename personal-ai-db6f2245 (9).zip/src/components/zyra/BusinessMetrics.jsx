
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  TrendingUp, AlertTriangle, CheckCircle, Clock,
  DollarSign, Zap, Shield, Activity, Loader2
} from "lucide-react";

const formatLargeNumber = (numStr) => {
    const num = parseFloat(numStr);
    if (isNaN(num)) return numStr;
    if (num >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
    return `$${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const mockPortfolio = { 'TSLA': 50, 'AAPL': 200, 'NVDA': 100, 'FSLR': 150 };

export default function BusinessMetrics({ tasks, memories, integrations, activeMode, financialData, isFinancialDataLoading }) {
  const criticalTasks = tasks.filter(t => t.priority === 'critical').length;
  const completedToday = tasks.filter(t =>
    t.status === 'completed' &&
    new Date(t.updated_date).toDateString() === new Date().toDateString()
  ).length;

  const activeIntegrations = integrations.filter(i => i.status === 'active').length;
  const totalIntegrations = integrations.length || 1;

  const recentMemories = memories.slice(0, 5);

  const modeMetrics = {
    business: {
      title: "Business Operations",
      metrics: [
        { label: "Revenue Pipeline", value: "$2.4M", trend: "+12%", icon: DollarSign, color: "text-green-400" },
        { label: "Critical Tasks", value: criticalTasks, trend: criticalTasks > 0 ? "Action Required" : "All Clear", icon: AlertTriangle, color: criticalTasks > 0 ? "text-red-400" : "text-green-400" },
        { label: "System Uptime", value: "99.9%", trend: "Optimal", icon: Activity, color: "text-blue-400" },
        { label: "Active Projects", value: "14", trend: "+3 This Week", icon: TrendingUp, color: "text-purple-400" }
      ]
    },
    developer: {
      title: "System Architecture",
      metrics: [
        { label: "API Integrations", value: `${activeIntegrations}/${totalIntegrations}`, trend: "All Systems", icon: Zap, color: "text-green-400" },
        { label: "Security Score", value: "A+", trend: "Quantum-Safe", icon: Shield, color: "text-blue-400" },
        { label: "Performance", value: "98.7%", trend: "Optimized", icon: Activity, color: "text-purple-400" },
        { label: "Memory Usage", value: memories.length, trend: "Unlimited", icon: CheckCircle, color: "text-green-400" }
      ]
    },
    creative: {
      title: "Innovation Pipeline",
      metrics: [
        { label: "Ideas Generated", value: "47", trend: "+12 This Week", icon: TrendingUp, color: "text-purple-400" },
        { label: "Projects", value: "8", trend: "In Development", icon: Clock, color: "text-yellow-400" },
        { label: "Breakthrough Score", value: "94%", trend: "Revolutionary", icon: Zap, color: "text-pink-400" },
        { label: "Market Potential", value: "$50M+", trend: "Estimated", icon: DollarSign, color: "text-green-400" }
      ]
    },
    investor: {
      title: "Portfolio Overview",
      metrics: [
        { label: "Portfolio Value", value: "$0.00", trend: "Calculating...", icon: DollarSign, color: "text-gray-400" },
        { label: "Market Status", value: "...", trend: "Fetching...", icon: Activity, color: "text-gray-400" },
        { label: "Risk Score", value: "Low", trend: "Balanced", icon: Shield, color: "text-green-400" },
        { label: "ROI Target", value: "125%", trend: "On Track", icon: CheckCircle, color: "text-purple-400" }
      ]
    }
  };

  if (activeMode === 'investor' && financialData && !financialData.error) {
    const portfolioValue = Object.keys(mockPortfolio).reduce((acc, symbol) => {
        const holding = mockPortfolio[symbol];
        const stockData = financialData[symbol];
        if (stockData && stockData['05. price']) {
            return acc + (holding * parseFloat(stockData['05. price']));
        }
        return acc;
    }, 0);

    let totalChange = 0;
    let validStocksCount = 0;
    for (const symbol in financialData) {
        const stockData = financialData[symbol];
        if (stockData && typeof stockData['09. change'] !== 'undefined') {
            totalChange += parseFloat(stockData['09. change']);
            validStocksCount++;
        }
    }
    const overallChange = validStocksCount > 0 ? totalChange / validStocksCount : 0;
    const overallChangePercent = validStocksCount > 0 ? totalChange / validStocksCount : 0; // Assuming totalChange is already a percentage-like value from the mock API.

    // Determine color based on overallChange
    let marketStatusColor = "text-gray-400";
    if (overallChange > 0) {
      marketStatusColor = "text-green-400";
    } else if (overallChange < 0) {
      marketStatusColor = "text-red-400";
    }


    modeMetrics.investor = {
        title: "Live Portfolio Overview",
        metrics: [
            { label: "Portfolio Value", value: formatLargeNumber(portfolioValue.toString()), trend: "Live", icon: DollarSign, color: "text-green-400" },
            {
              label: "Market Status",
              value: `${overallChangePercent.toFixed(2)}%`,
              trend: "Today's Change",
              icon: TrendingUp,
              color: marketStatusColor
            },
            { label: "Risk Score", value: "Low", trend: "Balanced", icon: Shield, color: "text-green-400" },
            { label: "ROI Target", value: "125%", trend: "On Track", icon: CheckCircle, color: "text-purple-400" }
        ]
    };
  }

  const currentMetrics = modeMetrics[activeMode] || modeMetrics.business;

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div>
        <h2 className="text-xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">{currentMetrics.title}</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {isFinancialDataLoading && activeMode === 'investor' ? (
              [...Array(4)].map((_, index) => (
                <Card key={index} className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-5 w-5 bg-slate-700 rounded mb-2"></div>
                    <div className="h-7 w-3/4 bg-slate-700 rounded mb-1"></div>
                    <div className="h-4 w-1/2 bg-slate-700 rounded"></div>
                  </CardContent>
                </Card>
              ))
          ) : (
            currentMetrics.metrics.map((metric, index) => {
              const IconComponent = metric.icon;
              return (
                <Card key={index} className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 hover:border-cyan-500/30 transition-all group relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <CardContent className="p-4 relative">
                    <div className="flex items-center justify-between mb-2">
                      <IconComponent className={`w-5 h-5 ${metric.color}`} />
                      <Badge variant="outline" className="text-xs text-slate-400 border-slate-600 bg-slate-800/50">
                        {metric.trend}
                      </Badge>
                    </div>
                    <div className="text-2xl font-bold text-white mb-1">{metric.value}</div>
                    <div className="text-sm text-slate-400">{metric.label}</div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>

      {/* System Status */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5" />
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-green-400" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 relative">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">API Integrations</span>
                <span className="text-slate-400">{activeIntegrations}/{totalIntegrations}</span>
              </div>
              <Progress value={(activeIntegrations / totalIntegrations) * 100} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-green-400 [&>div]:to-emerald-500" />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">Memory Optimization</span>
                <span className="text-slate-400">99.8%</span>
              </div>
              <Progress value={99.8} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-blue-400 [&>div]:to-cyan-500" />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">Security Level</span>
                <span className="text-slate-400">Quantum-Safe</span>
              </div>
              <Progress value={100} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-purple-400 [&>div]:to-pink-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5" />
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-400" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="relative">
            <div className="space-y-3">
              {recentMemories.length > 0 ? recentMemories.map((memory, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-slate-700/50 border border-slate-600/30 hover:border-cyan-500/30 transition-colors">
                  <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full mt-2 flex-shrink-0"></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-slate-300 line-clamp-2">
                      {memory.content}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {new Date(memory.created_date).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              )) : (
                <p className="text-sm text-slate-400">No recent activity.</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
