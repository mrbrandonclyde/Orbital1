import React from 'react';
import { Flame, Shield, Building, Zap, Factory } from 'lucide-react';

const categoryIcons = {
    corporate_hq: <Building className="w-4 h-4 text-cyan-300" />,
    energy_plant: <Zap className="w-4 h-4 text-yellow-300" />,
    financial_center: <Building className="w-4 h-4 text-green-300" />,
    security_outpost: <Shield className="w-4 h-4 text-red-300" />,
    research_lab: <Factory className="w-4 h-4 text-purple-300" />,
};

const GlobalHud = ({ locations, alerts, onSelectLocation }) => {
  const criticalAlerts = alerts.filter(a => a.confidence > 90);

  return (
    <>
      {/* Top Left: Critical Alerts */}
      <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-xl p-4 rounded-lg border border-red-500/50 shadow-lg text-white w-80 animate-pulse">
        <h3 className="text-xl font-bold text-red-400 flex items-center gap-2">
          <Flame /> CRITICAL ALERT
        </h3>
        <p className="text-sm text-gray-300 mt-1">
          {criticalAlerts.length} high-confidence fire detections active.
        </p>
      </div>

      {/* Top Right: Asset List */}
      <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-xl p-4 rounded-lg border border-cyan-500/50 shadow-lg text-white w-80 max-h-[50vh] overflow-y-auto">
        <h3 className="text-xl font-bold text-cyan-300">Global Assets</h3>
        <ul className="mt-2 space-y-2">
          {locations.map(loc => (
            <li 
              key={loc.id} 
              className="flex items-center justify-between p-2 rounded-md hover:bg-cyan-500/20 cursor-pointer transition-colors"
              onClick={() => onSelectLocation(loc)}
            >
              <div className="flex items-center gap-3">
                {categoryIcons[loc.category] || <Building className="w-4 h-4 text-gray-400" />}
                <span className="font-medium text-sm">{loc.name}</span>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${loc.status === 'online' ? 'bg-green-500/30 text-green-300' : 'bg-red-500/30 text-red-300'}`}>
                {loc.status}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default GlobalHud;