
import React from "react";
import { useTimeline } from "./TimelineProvider";
import { Play, Pause, Rewind, FastForward, GitBranch, Zap, Anchor, Camera, RotateCcw, Lock, Unlock, Cpu, Activity, History as HistoryIcon, Map, Shield, Download, Brain, GitCommit } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const ControlButton = ({ onClick, children, tooltip }) => (
  <TooltipProvider delayDuration={200}>
    <Tooltip>
      <TooltipTrigger asChild>
        <Button variant="ghost" size="sm" onClick={onClick} className="text-blue-300 hover:bg-blue-500/20 hover:text-white transition-all duration-200 text-xs px-2 py-1 h-8">
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent className="bg-black/80 border-blue-500/30 text-blue-200">
        <p>{tooltip}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export default function TimelineBar({ theme, className = "" }) {
  const {
    currentYear, // Changed from currentTime
    rollback,
    forward,
    togglePlay,
    playing,
    speed,
    setSpeed,
    activeBranch,
    createBranch,
    createCheckpoint,
    createTemporalAnchor,
    captureQuantumState,
    takeRealitySnapshot,
    generateForecast,
    syncTimelines,
    desyncTimelines,
    timelineSync,
    resetTimeline,
    debugTemporalState,
    // Removed stepUnit, setStepUnit, stepValue, setStepValue
    // Removed jumpToDate, analyzeCausality as per outline
  } = useTimeline();

  // Create a valid Date object from the currentYear number
  const currentTime = React.useMemo(() => {
    if (typeof currentYear === 'number' && currentYear > 0) {
      // Create a date from the floating point year
      const year = Math.floor(currentYear);
      const remainder = currentYear - year;
      const date = new Date(year, 0, 1); // January 1st of the floor year
      
      // Add days based on the remainder. Use 365.25 for average year length.
      // This makes the day of year more accurate over long periods.
      const daysToAdd = remainder * 365.25; 
      date.setDate(date.getDate() + daysToAdd);
      
      return date;
    }
    return new Date(); // Fallback for invalid values or initial state
  }, [currentYear]);

  return (
    <div className={cn(`relative h-28 flex flex-col bg-black/50 backdrop-blur-xl border-t border-[#3A3A6A]/60 shadow-[0_0_25px_rgba(43,43,201,0.3)]`, className)}>
      <div className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-400 to-transparent"></div>
      
      {/* Top Row - Primary Controls */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#3A3A6A]/40">
        {/* Left: Playback Controls */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <ControlButton onClick={() => rollback(10)} tooltip="Rollback 10 years">⏪ 10y</ControlButton>
            <ControlButton onClick={() => rollback(1)} tooltip="Rollback 1 year"><Rewind className="w-4 h-4" /></ControlButton>
            <TooltipProvider><Tooltip><TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={togglePlay} className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-200 hover:bg-blue-500/30 hover:text-white border border-blue-500/50">
                {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
            </TooltipTrigger><TooltipContent className="bg-black/80 border-blue-500/30 text-blue-200">{playing ? "Pause" : "Play"}</TooltipContent></Tooltip></TooltipProvider>
            <ControlButton onClick={() => forward(1)} tooltip="Forward 1 year"><FastForward className="w-4 h-4" /></ControlButton>
            <ControlButton onClick={() => forward(10)} tooltip="Forward 10 years">10y ⏩</ControlButton>
          </div>
        </div>

        {/* Center: Time Display */}
        <div className="text-center absolute left-1/2 -translate-x-1/2 top-2">
          <div className="text-xl font-bold text-white tracking-wider">{format(currentTime, 'yyyy')}</div>
          <div className="text-xs text-blue-300">{format(currentTime, 'EEE, MMM d')}</div>
        </div>

        {/* Right: System Controls */}
        <div className="flex items-center gap-1">
          <ControlButton onClick={generateForecast} tooltip="Generate Forecast"><Brain className="w-4 h-4 mr-1"/>Forecast</ControlButton>
          <ControlButton onClick={timelineSync ? desyncTimelines : syncTimelines} tooltip={timelineSync ? 'Desynchronize Timelines' : 'Synchronize Timelines'}>
            {timelineSync ? <Unlock className="w-4 h-4 mr-1" /> : <Lock className="w-4 h-4 mr-1" />}
            {timelineSync ? 'Desync' : 'Sync'}
          </ControlButton>
          <ControlButton onClick={resetTimeline} tooltip="Reset Timeline State"><RotateCcw className="w-4 h-4 mr-1" />Reset</ControlButton>
          <ControlButton onClick={() => console.log(debugTemporalState())} tooltip="Debug State to Console"><Cpu className="w-4 h-4 mr-1" />Debug</ControlButton>
        </div>
      </div>

      {/* Bottom Row - Configuration & Advanced Controls */}
      <div className="flex-1 flex items-center justify-between px-4">
        {/* Left: Branch & Step Config */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-blue-400" />
            <div className="font-semibold text-blue-300 text-sm">{activeBranch}</div>
            <ControlButton onClick={() => createBranch()} tooltip="Create New Branch"><GitCommit className="w-4 h-4 mr-1"/>New</ControlButton>
          </div>
          {/* Removed Step configuration */}
        </div>

        {/* Center: Advanced State Controls */}
        <div className="flex items-center gap-1">
           <ControlButton onClick={() => createCheckpoint()} tooltip="Create Checkpoint"><HistoryIcon className="w-4 h-4 mr-1" />Checkpoint</ControlButton>
           <ControlButton onClick={() => createTemporalAnchor()} tooltip="Create Temporal Anchor"><Anchor className="w-4 h-4 mr-1" />Anchor</ControlButton>
           <ControlButton onClick={() => captureQuantumState()} tooltip="Capture Quantum State"><Activity className="w-4 h-4 mr-1" />Quantum</ControlButton>
           <ControlButton onClick={() => takeRealitySnapshot()} tooltip="Take Reality Snapshot"><Camera className="w-4 h-4 mr-1" />Snapshot</ControlButton>
        </div>

        {/* Right: Speed Control */}
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-blue-400" />
          <span className="text-xs text-gray-400">Speed:</span>
          <Select value={`${speed}`} onValueChange={(val) => setSpeed(Number(val))}>
            <SelectTrigger className="w-16 h-7 bg-transparent border-[#3A3A6A] text-blue-300 focus:ring-blue-500 text-xs"><SelectValue />x</SelectTrigger>
            <SelectContent className="bg-black/80 backdrop-blur-xl border-blue-500/40 text-blue-300">
              {[0.1, 0.5, 1, 2, 5, 10, 100].map(s => <SelectItem key={s} value={String(s)}>{s}x</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
