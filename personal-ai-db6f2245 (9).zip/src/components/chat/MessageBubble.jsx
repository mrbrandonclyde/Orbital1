import React from "react";
import { motion } from "framer-motion";
import { User, Zap } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function MessageBubble({ message, aiName = "Zyra", isStreaming = false }) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-start gap-3 w-full ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden ai-avatar shadow-sm relative">
          <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/9b4d301ed_WhatsAppImage2025-09-02at195836_c6cb4075.jpg" alt="Zyra AI" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20" />
        </div>
      )}
      
      <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
        isUser ? 'gold-gradient-bubble text-black' : 'neon-blue-bubble text-cyan-100'
      }`}>
        <div className="flex items-center gap-2 mb-1">
          <span className={`text-sm font-medium ${isUser ? 'text-black' : 'text-cyan-300'}`}>
            {isUser ? "You" : aiName}
          </span>
          {!isStreaming && (
            <span className={`text-xs ${isUser ? 'text-black/60' : 'text-cyan-400'}`}>
              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
          {isStreaming && (
             <span className="text-xs text-cyan-400 flex items-center gap-1">
                <Zap className="w-3 h-3 animate-pulse" />
                Streaming...
             </span>
          )}
        </div>
        
        <ReactMarkdown className={`prose prose-sm max-w-none prose-p:my-0 ${
          isUser 
            ? 'prose-black [&_a]:text-blue-900 [&_strong]:text-black [&_code]:bg-black/10 [&_code]:text-black' 
            : 'prose-cyan [&_a]:text-gold [&_strong]:text-cyan-200 [&_code]:bg-cyan-900/30 [&_code]:text-cyan-200'
        }`}>
          {message.content}
        </ReactMarkdown>
        {isStreaming && <span className="animate-pulse text-cyan-300">|</span>}
      </div>
      
      {isUser && (
        <div className="w-8 h-8 rounded-full user-avatar flex-shrink-0 flex items-center justify-center">
          <User className="w-4 h-4 text-black"/>
        </div>
      )}
    </motion.div>
  );
}