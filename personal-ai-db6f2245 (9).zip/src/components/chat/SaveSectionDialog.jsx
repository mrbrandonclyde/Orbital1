import React, { useState } from "react";
import { SavedSection } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Bookmark, Loader2 } from "lucide-react";

export default function SaveSectionDialog({ messages, conversationId, onSaved, trigger }) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) return;
    
    setIsSaving(true);
    try {
      await SavedSection.create({
        title: title.trim(),
        conversation_id: conversationId,
        messages: messages.map(msg => ({
          content: msg.content,
          role: msg.role,
          timestamp: msg.timestamp
        })),
        notes: notes.trim(),
        tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
        is_favorite: false
      });
      
      setTitle('');
      setNotes('');
      setTags('');
      setIsOpen(false);
      onSaved();
    } catch (error) {
      console.error('Error saving section:', error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="flex items-center gap-2">
            <Bookmark className="w-4 h-4" />
            Save Section
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Save Chat Section</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="section-title">Section Title</Label>
            <Input
              id="section-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Important Discussion About..."
            />
          </div>
          
          <div>
            <Label htmlFor="section-notes">Notes (Optional)</Label>
            <Textarea
              id="section-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any notes about this section..."
              rows={3}
            />
          </div>
          
          <div>
            <Label htmlFor="section-tags">Tags (Optional)</Label>
            <Input
              id="section-tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="tag1, tag2, tag3..."
            />
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={!title.trim() || isSaving}>
              {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Section
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}