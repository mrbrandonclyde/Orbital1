import React, { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Loader2, Paperclip, X, File as FileIcon, Image as ImageIcon, Mic, MicOff, Zap } from "lucide-react";
import { UploadFile } from "@/api/integrations";

export default function ChatInput({ onSendMessage, isLoading }) {
  const [message, setMessage] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  
  const fileInputRef = useRef(null);
  const textareaRef = useRef(null);

  const handleSendMessage = useCallback((e) => {
    e.preventDefault();
    if ((message.trim() || attachments.length > 0) && !isLoading && !isUploading) {
      const attachmentUrls = attachments.map(a => ({
        file_url: a.file_url,
        file_name: a.file_name,
        file_type: a.file_type,
      }));
      onSendMessage(message.trim(), attachmentUrls);
      setMessage("");
      setAttachments([]);
      
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  }, [message, attachments, isLoading, isUploading, onSendMessage]);

  const handleTextareaChange = useCallback((e) => {
    const newValue = e.target.value;
    setMessage(newValue);
    
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  }, []);

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    setIsUploading(true);
    const newAttachments = files.map(file => ({
      id: crypto.randomUUID(),
      file,
      file_name: file.name,
      file_type: file.type,
      status: 'uploading',
      file_url: null
    }));

    setAttachments(prev => [...prev, ...newAttachments]);

    try {
      for (const attachment of newAttachments) {
        const { file_url } = await UploadFile({ file: attachment.file });
        setAttachments(prev => prev.map(a => 
          a.id === attachment.id ? { ...a, status: 'uploaded', file_url } : a
        ));
      }
    } catch (error) {
      console.error("File upload failed:", error);
      setAttachments(prev => prev.map(a => 
        newAttachments.some(na => na.id === a.id) ? { ...a, status: 'failed' } : a
      ));
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const removeAttachment = useCallback((id) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  }, []);

  const handleKeyPress = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(e);
    }
  }, [handleSendMessage]);

  return (
    <div className="p-4">
        {attachments.length > 0 && (
          <div className="mb-3 grid grid-cols-2 md:grid-cols-4 gap-3">
            {attachments.map(attachment => (
              <div key={attachment.id} className="relative group p-3 border border-cyan/30 rounded-xl bg-black/20 hover:bg-cyan/10 transition-colors">
                <div className="flex items-center gap-2">
                  {attachment.file_type?.startsWith('image/') ? (
                    <ImageIcon className="w-5 h-5 text-cyan flex-shrink-0" />
                  ) : (
                    <FileIcon className="w-5 h-5 text-silver flex-shrink-0" />
                  )}
                  <p className="text-xs truncate flex-1 text-silver">{attachment.file_name}</p>
                </div>
                
                {attachment.status === 'uploading' && (
                  <div className="absolute inset-0 bg-black/80 flex items-center justify-center rounded-xl">
                    <Loader2 className="w-4 h-4 animate-spin text-cyan" />
                  </div>
                )}
                
                {attachment.status === 'failed' && (
                  <div className="absolute inset-0 bg-crimson/50 border border-crimson/50 rounded-xl flex items-center justify-center">
                    <span className="text-xs text-red-300">Failed</span>
                  </div>
                )}
                
                <button
                  onClick={() => removeAttachment(attachment.id)}
                  className="absolute -top-2 -right-2 bg-slate-600 hover:bg-slate-500 text-white rounded-full w-5 h-5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="bg-black/30 backdrop-blur rounded-xl border border-cyan/30 flex items-end gap-3 p-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            disabled={isLoading || isUploading}
            className="text-silver hover:text-cyan hover:bg-cyan/10 flex-shrink-0"
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip className="w-5 h-5" />
          </Button>
          
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={handleTextareaChange}
            onKeyPress={handleKeyPress}
            placeholder="Engage with Zyra..."
            className="resize-none bg-transparent border-none text-silver placeholder:text-silver/60 focus:ring-0 p-2 max-h-32"
            rows={1}
            disabled={isLoading}
          />
          
          <Button
            type="submit"
            size="icon"
            disabled={(!message.trim() && attachments.length === 0) || isLoading}
            className="btn-cyan flex-shrink-0 rounded-lg"
            onClick={handleSendMessage}
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </Button>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          multiple
          className="hidden"
          accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt,.csv,.xlsx"
        />
    </div>
  );
}