import React, { useState } from "react";
import { FeedbackLog } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star, MessageSquare, CheckCircle, ThumbsUp, ThumbsDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FeedbackWidget({ message, conversationId, onFeedbackSubmitted }) {
  const [isOpen, setIsOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [responseQuality, setResponseQuality] = useState('');
  const [contextCategory, setContextCategory] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const handleQuickRating = async (quickRating) => {
    setIsSubmitting(true);
    try {
      await FeedbackLog.create({
        message_id: message.id,
        conversation_id: conversationId,
        model_used: message.model_used || 'unknown',
        rating: quickRating,
        context_category: 'general'
      });
      setHasSubmitted(true);
      onFeedbackSubmitted?.();
      setTimeout(() => setHasSubmitted(false), 2000);
    } catch (error) {
      console.error('Error submitting quick feedback:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDetailedSubmit = async () => {
    if (rating === 0) return;
    
    setIsSubmitting(true);
    try {
      await FeedbackLog.create({
        message_id: message.id,
        conversation_id: conversationId,
        model_used: message.model_used || 'unknown',
        rating,
        feedback_text: feedbackText,
        response_quality: responseQuality,
        context_category: contextCategory || 'general'
      });
      
      setIsOpen(false);
      setHasSubmitted(true);
      onFeedbackSubmitted?.();
      
      // Reset form
      setRating(0);
      setFeedbackText('');
      setResponseQuality('');
      setContextCategory('');
      
      setTimeout(() => setHasSubmitted(false), 2000);
    } catch (error) {
      console.error('Error submitting detailed feedback:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (message.role !== 'assistant') return null;

  return (
    <div className="flex items-center gap-2 mt-2">
      <AnimatePresence>
        {hasSubmitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex items-center gap-2 text-green-600 text-sm"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Thanks for your feedback!</span>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2"
          >
            {/* Quick Rating Buttons */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleQuickRating(5)}
              disabled={isSubmitting}
              className="text-green-600 hover:text-green-700 hover:bg-green-50 p-1"
            >
              <ThumbsUp className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"  
              onClick={() => handleQuickRating(2)}
              disabled={isSubmitting}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 p-1"
            >
              <ThumbsDown className="w-4 h-4" />
            </Button>

            {/* Detailed Feedback Dialog */}
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 p-1">
                  <MessageSquare className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Help Zyra Learn</DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4">
                  {/* Star Rating */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Overall Rating</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          key={star}
                          onClick={() => setRating(star)}
                          className={`p-1 ${star <= rating ? 'text-yellow-500' : 'text-gray-300'}`}
                        >
                          <Star className="w-5 h-5 fill-current" />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Context Category */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Context Type</label>
                    <Select value={contextCategory} onValueChange={setContextCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select context" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="creative">Creative</SelectItem>
                        <SelectItem value="technical">Technical</SelectItem>
                        <SelectItem value="personal">Personal</SelectItem>
                        <SelectItem value="analytical">Analytical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Response Quality */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Response Quality</label>
                    <Select value={responseQuality} onValueChange={setResponseQuality}>
                      <SelectTrigger>
                        <SelectValue placeholder="How was the response?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="perfect">Perfect</SelectItem>
                        <SelectItem value="too_formal">Too formal</SelectItem>
                        <SelectItem value="too_casual">Too casual</SelectItem>
                        <SelectItem value="too_brief">Too brief</SelectItem>
                        <SelectItem value="too_detailed">Too detailed</SelectItem>
                        <SelectItem value="unclear">Unclear</SelectItem>
                        <SelectItem value="off_topic">Off topic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Feedback Text */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Additional Feedback (Optional)</label>
                    <Textarea
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      placeholder="How can I improve my responses?"
                      className="h-20"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setIsOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleDetailedSubmit}
                      disabled={rating === 0 || isSubmitting}
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}