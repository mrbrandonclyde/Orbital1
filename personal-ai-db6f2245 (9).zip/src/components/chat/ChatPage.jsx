import React, { useState, useEffect, useRef, useCallback } from "react";
import { UserSettings } from "@/api/entities";
import { AIModel } from "@/api/entities";
import { Conversation } from "@/api/entities";
import { Message } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Bot, BrainCircuit, Zap, Shield, TrendingUp, Cpu, Brain, ShieldCheck, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MessageBubble from "@/components/chat/MessageBubble";
import ChatInput from "@/components/chat/ChatInput";
import ConversationHistory from "@/components/chat/ConversationHistory";
import { AdvancedAIEngine, QuantumSecurityStatus, EdgeComputingStatus } from "@/components/ai/AdvancedAI";
import { useBehaviorAnalytics } from "@/components/analytics/BehaviorAnalytics";
import { EdgePerformanceMonitor } from "@/components/performance/EdgeCache";

const ORCHESTRATOR_MODEL = {
  id: 'orchestrator',
  name: 'Zyra (Orchestrator)',
  description: 'Automatically routes your request to the best specialist agent with neural context understanding.',
  isOrchestrator: true
};

export default function ChatPage() {
  const [settings, setSettings] = useState(null);
  const [allModels, setAllModels] = useState([]);
  const [activeModel, setActiveModel] = useState(ORCHESTRATOR_MODEL);
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isHistoryLoading, setIsHistoryLoading] = useState(true);
  const [streamingResponse, setStreamingResponse] = useState("");
  const [neuralContext, setNeuralContext] = useState({});
  const [currentUser, setCurrentUser] = useState(null);
  const [trustScore, setTrustScore] = useState(87);
  
  const chatEndRef = useRef(null);
  const behaviorAnalytics = useBehaviorAnalytics('current-user');

  const loadInitialData = useCallback(async () => {
    setIsHistoryLoading(true);
    try {
      const [userSettingsList, models, convos] = await Promise.all([
        UserSettings.list(),
        AIModel.list(),
        Conversation.list("-last_message_at")
      ]);
      
      let loadedSettings = userSettingsList[0] || await UserSettings.create({});
      setSettings(loadedSettings);
      setAllModels(models);
      
      let modelToSet = ORCHESTRATOR_MODEL;
      if (loadedSettings.active_model_id && loadedSettings.active_model_id !== 'orchestrator') {
        const foundModel = models.find(m => m.id === loadedSettings.active_model_id);
        if (foundModel) modelToSet = foundModel;
      }
      setActiveModel(modelToSet);
      
      setConversations(convos);
      if (convos.length > 0) {
        setCurrentConversationId(convos[0].id);
      }

      const user = await User.me();
      setCurrentUser(user);
      setTrustScore(user.trust_score || 87);
    } catch (error) {
      console.log('Error loading initial data:', error.message);
    }
    
    setIsHistoryLoading(false);
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (currentConversationId) {
      loadMessages(currentConversationId);
    } else {
      setMessages([]);
    }
  }, [currentConversationId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading, streamingResponse]);

  const loadMessages = async (conversationId) => {
    const fetchedMessages = await Message.filter({ conversation_id: conversationId }, "timestamp");
    setMessages(fetchedMessages);
  };

  const handleSendMessage = async (userMessage) => {
    if (!userMessage.trim()) return;
    
    setIsLoading(true);
    setStreamingResponse("");
    
    let conversationId = currentConversationId;
    if (!conversationId) {
      const newConvo = await Conversation.create({
        title: userMessage.substring(0, 40) || "New Conversation",
        last_message_at: new Date().toISOString()
      });
      conversationId = newConvo.id;
      setCurrentConversationId(conversationId);
      setConversations(prev => [newConvo, ...prev]);
    }

    const newUserMessage = {
      id: `local-${Date.now()}-user`,
      conversation_id: conversationId,
      content: userMessage,
      role: "user",
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, newUserMessage]);

    try {
      await Message.create({
        conversation_id: conversationId,
        content: userMessage,
        role: "user"
      });

      const response = await InvokeLLM({
        prompt: userMessage,
        add_context_from_internet: false
      });

      const assistantMessage = await Message.create({
        conversation_id: conversationId,
        content: response,
        role: "assistant",
        model_used: activeModel.name
      });

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
    }

    setIsLoading(false);
  };

  const handleNewConversation = () => {
    setCurrentConversationId(null);
    setMessages([]);
  };

  const handleDeleteConversation = async (conversationId) => {
    await Conversation.delete(conversationId);
    setConversations(prev => prev.filter(c => c.id !== conversationId));
    if (currentConversationId === conversationId) {
      setCurrentConversationId(null);
      setMessages([]);
    }
  };

  const handleModelChange = async (modelId) => {
    const selectedModel = modelId === 'orchestrator' ? ORCHESTRATOR_MODEL : allModels.find(m => m.id === modelId);
    setActiveModel(selectedModel);
    
    if (settings) {
      await UserSettings.update(settings.id, { active_model_id: modelId });
    }
  };

  return (
    <AdvancedAIEngine onBehaviorChange={(data) => setNeuralContext(prev => ({...prev, ...data}))}>
      <div className="flex h-full">
        <ConversationHistory
          conversations={conversations}
          currentConversationId={currentConversationId}
          onSelectConversation={setCurrentConversationId}
          onNewConversation={handleNewConversation}
          onDeleteConversation={handleDeleteConversation}
          isHistoryLoading={isHistoryLoading}
        />
        
        <main className="flex-1 flex flex-col">
          <div className="superman-card px-6 py-3 flex items-center justify-between text-sm border-b border-cyan/30">
            <div className="flex items-center gap-2">
              {activeModel.isOrchestrator ? 
                <BrainCircuit className="w-4 h-4 text-cyan cyan-glow" /> : 
                <Bot className="w-4 h-4 text-cyan" />}
              <Select value={activeModel?.id || 'orchestrator'} onValueChange={handleModelChange}>
                <SelectTrigger className="border-none shadow-none text-gold font-semibold bg-transparent focus:ring-0 p-0">
                  <SelectValue placeholder="Select AI" />
                </SelectTrigger>
                <SelectContent className="superman-card">
                  <SelectItem value={ORCHESTRATOR_MODEL.id}>
                    <div className="flex items-center gap-2">
                      <BrainCircuit className="w-4 h-4 text-cyan" />
                      <span className="text-cyan font-semibold">{ORCHESTRATOR_MODEL.name}</span>
                    </div>
                  </SelectItem>
                  {allModels.map(model => (
                    <SelectItem key={model.id} value={model.id}>
                      <div className="flex items-center gap-2">
                        <Bot className="w-4 h-4 text-cyan" />
                        <span className="text-silver">{model.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-6">
              <span className="text-gold font-bold flex items-center gap-1">
                <TrendingUp className="w-4 h-4" />
                Accuracy: {(neuralContext.predictiveAccuracy || 94.7).toFixed(1)}%
              </span>
              <span className="text-cyan font-bold flex items-center gap-1">
                <Brain className="w-4 h-4" />
                Depth: {(neuralContext.semanticDepth || 87).toFixed(0)}%
              </span>
              <span className="text-amber font-bold flex items-center gap-1">
                <Cpu className="w-4 h-4" />
                Load: {behaviorAnalytics.cognitiveLoad || 34}%
              </span>
              <span className="text-kryptonite font-bold flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" />
                Verified
              </span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6 superman-gradient">
            <div className="max-w-4xl mx-auto space-y-6">
              <AnimatePresence>
                {messages.map((message) => (
                  <MessageBubble 
                    key={message.id} 
                    message={message} 
                    aiName={message.role === 'assistant' ? message.model_used || activeModel.name : 'You'}
                  />
                ))}
              </AnimatePresence>
              
              {streamingResponse && (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  className="flex gap-4 justify-start"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden cyan-glow shadow-sm relative">
                    <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/9b4d301ed_WhatsAppImage2025-09-02at195836_c6cb4075.jpg" alt="Zyra AI" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl shadow-lg neon-blue-bubble flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Zap className="w-4 h-4 text-cyan animate-pulse cyan-glow" />
                      <span className="text-sm font-medium text-cyan">{activeModel.name}</span>
                      <span className="text-xs text-cyan">• Streaming</span>
                    </div>
                    <p className="text-cyan">{streamingResponse}<span className="animate-pulse text-cyan">|</span></p>
                  </div>
                </motion.div>
              )}
              
              {isLoading && !streamingResponse && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4 justify-start">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden cyan-glow shadow-sm relative">
                    <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/9b4d301ed_WhatsAppImage2025-09-02at195836_c6cb4075.jpg" alt="Zyra AI" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl shadow-lg superman-card text-cyan flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-cyan" />
                    <span>Neural processing...</span>
                  </div>
                </motion.div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>
          
          <div className="p-4 superman-card border-t border-cyan/30">
            <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
          </div>
        </main>
        
        <QuantumSecurityStatus />
        <EdgeComputingStatus />
        <EdgePerformanceMonitor />
      </div>
    </AdvancedAIEngine>
  );
}