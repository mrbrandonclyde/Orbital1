import React from 'react';
import { Wifi, Globe, Zap } from 'lucide-react';

export default function SatelliteFeed() {
  return (
    <div className="w-full h-full bg-black/80 rounded-2xl border-2 border-[#2b2bc9]/50 shadow-[0_0_40px_rgba(43,43,201,0.5)] flex flex-col overflow-hidden">
      <style jsx>{`
        .scanline {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: linear-gradient(to bottom, transparent, rgba(51, 198, 243, 0.7), transparent);
          box-shadow: 0 0 10px #33C6F3;
          animation: scan 4s linear infinite;
          opacity: 0.8;
        }
        @keyframes scan {
          0% { transform: translateY(0); }
          100% { transform: translateY(100vh); }
        }
      `}</style>
      
      <header className="px-4 py-2 bg-black/50 border-b border-[#2b2bc9]/40 flex items-center justify-between z-10">
        <h3 className="text-sm font-bold text-cyan-300 uppercase tracking-widest">Orbital Feed: ZYRA-SAT-01</h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1 text-green-400">
            <Wifi size={14} /><span>ONLINE</span>
          </div>
          <div className="flex items-center gap-1 text-blue-300">
            <Globe size={14} /><span>GEO-SYNC</span>
          </div>
          <div className="flex items-center gap-1 text-yellow-400">
            <Zap size={14} /><span>PWR: 98.7%</span>
          </div>
        </div>
      </header>

      <div className="flex-1 relative bg-black">
        <iframe
          src="https://www.youtube.com/embed/P9C25Un7_Bw?autoplay=1&mute=1&loop=1&playlist=P9C25Un7_Bw&controls=0&showinfo=0&autohide=1&modestbranding=1"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          allowFullScreen
          className="w-full h-full absolute inset-0 z-0"
          title="Live Satellite Feed"
        ></iframe>
        <div className="scanline" />
        <div className="absolute inset-0 bg-black/20" />
      </div>
    </div>
  );
}