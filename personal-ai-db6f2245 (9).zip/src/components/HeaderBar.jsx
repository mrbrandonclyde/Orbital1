import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { motion } from "framer-motion";
import { Mic, MicOff, MessageCircle, Shield, Brain, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeaderBar({ isVoiceActive, onToggleChat, showChatPanel }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [trustScore, setTrustScore] = useState(87);

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      setTrustScore(user.trust_score || 87);
    } catch (error) {
      console.log('User not authenticated');
    }
  };

  return (
    <header className="h-16 flex items-center justify-between px-6 bg-black/70 backdrop-blur-md border-b border-cyan/20">
      {/* Left: Zyra Branding */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 gold-glow rounded-lg flex items-center justify-center">
          <Brain className="w-5 h-5 text-gold" />
        </div>
        <div>
          <h1 className="font-bold text-lg text-gold">Zyra AI</h1>
          <p className="text-xs text-cyan font-medium">Temporal Engine</p>
        </div>
      </div>

      {/* Center: Title */}
      <div className="text-center">
        <h2 className="text-xl font-bold text-cyan">SUPERMANOS TIME MACHINE</h2>
        <div className="flex items-center justify-center gap-4 mt-1">
          <span className="text-xs text-silver">Neural Interface Active</span>
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-2 h-2 bg-kryptonite rounded-full"
          />
        </div>
      </div>

      {/* Right: Controls */}
      <div className="flex items-center gap-4">
        {/* Trust Score */}
        <div className="kryptonite-glow rounded-lg px-3 py-1 text-sm">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-kryptonite" />
            <span className="text-silver">Trust</span>
            <span className="text-kryptonite font-bold">{trustScore}</span>
          </div>
        </div>

        {/* Voice Indicator */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          className={`p-2 rounded-lg transition-all ${
            isVoiceActive 
              ? 'bg-crimson/20 text-crimson border border-crimson/40' 
              : 'bg-cyan/20 text-cyan border border-cyan/40 hover:bg-cyan/30'
          }`}
        >
          {isVoiceActive ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </motion.button>

        {/* Chat Toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleChat}
          className={`${
            showChatPanel 
              ? 'bg-purple/20 text-purple border border-purple/40' 
              : 'text-silver hover:text-cyan hover:bg-cyan/10'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
        </Button>

        {/* Activity Indicator */}
        <div className="flex items-center gap-1">
          <Activity className="w-4 h-4 text-amber" />
          <span className="text-xs text-amber font-mono">LIVE</span>
        </div>
      </div>
    </header>
  );
}