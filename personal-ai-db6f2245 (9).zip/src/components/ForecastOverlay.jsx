import React from "react";
import { Sparkles } from "lucide-react";

export default function ForecastOverlay({ predictions = [] }) {
  return (
    <div className="bg-black/50 backdrop-blur-lg p-4 rounded-xl border border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.3)] text-sm text-blue-200">
      <h3 className="font-semibold mb-2 text-blue-300 flex items-center gap-2"><Sparkles className="w-4 h-4"/> Forecast</h3>
      <ul className="space-y-1">
        {predictions.length === 0 && (
          <li className="text-gray-500 italic">No predictions available.</li>
        )}
        {predictions.map((p, i) => (
          <li key={i} className="opacity-90">{p}</li>
        ))}
      </ul>
    </div>
  );
}