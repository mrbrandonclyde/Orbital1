import React from "react";
import { Switch } from "@/components/ui/switch";
import { Settings } from "lucide-react";

export default function ZyraControlPanel({ settings, onToggle, theme }) {
  return (
    <div className={`purple-glow-panel p-4 rounded-xl`}>
      <h2 className={`text-lg font-semibold mb-4 text-purple-300 flex items-center gap-2`}><Settings className="w-5 h-5"/>Control Panel</h2>
      <div className="space-y-4">
        {[
          { key: 'prediction', label: 'Prediction Engine' },
          { key: 'showPanels', label: 'Show Overlay Panels' },
          { key: 'immersiveMode', label: 'Immersive Mode' },
          { key: 'satelliteView', label: 'Activate Satellite View' },
          { key: 'showLanding', label: 'Show Landing Demo' }
        ].map(item => (
          <div key={item.key} className="flex items-center justify-between">
            <label htmlFor={item.key} className={`text-sm cursor-pointer ${theme.textSecondary}`}>
              {item.label}
            </label>
            <Switch
              id={item.key}
              checked={settings[item.key]}
              onCheckedChange={(checked) => onToggle(item.key, checked)}
            />
          </div>
        ))}
      </div>
    </div>
  );
}