
// ===== File: src/components/theme.js =====
export const themes = {
  superman: {
    id: "superman",
    name: "Superman",
    background: "bg-gradient-to-br from-black via-blue-950 to-cyan-900",
    panel: "bg-black/40 backdrop-blur-lg border border-cyan-500/30 shadow-xl",
    textPrimary: "text-gold",
    textSecondary: "text-silver",
    accent: "text-cyan-400",
    glow: "shadow-[0_0_15px_#00ffff]",
    button: "px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-gold text-black font-semibold shadow-lg hover:shadow-xl transition-all duration-300",
    icon: "🦸"
  },
  orbital: {
    id: "orbital",
    name: "Orbital",
    background: "bg-[#0A0A1A]",
    panel: "bg-[#101028]/50 backdrop-blur-xl border border-[#3A3A6A]/60",
    textPrimary: "text-[#E0E0FF]",
    textSecondary: "text-[#9E9ECF]",
    accent: "text-[#2b2bc9]",
    glow: "shadow-[0_0_20px_rgba(43,43,201,0.5)]",
    glowCyan: "shadow-[0_0_20px_rgba(51,198,243,0.6)]",
    button: "px-4 py-2 rounded-lg text-white font-semibold transition-all duration-300" ,
    icon: "🌐"
  },
  dark: {
    id: "dark",
    name: "Dark Mode",
    background: "bg-gradient-to-br from-black via-gray-900 to-gray-800",
    panel: "bg-black/60 backdrop-blur-lg border border-gray-700 shadow-md",
    textPrimary: "text-white",
    textSecondary: "text-gray-400",
    accent: "text-blue-400",
    glow: "shadow-[0_0_15px_#3b82f6]",
    button: "px-6 py-3 rounded-lg bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300",
    icon: "🌙"
  },
  light: {
    id: "light",
    name: "Light Mode",
    background: "bg-gradient-to-br from-white via-gray-100 to-gray-200",
    panel: "bg-white/80 backdrop-blur-md border border-gray-300 shadow-lg",
    textPrimary: "text-black",
    textSecondary: "text-gray-600",
    accent: "text-indigo-600",
    glow: "shadow-[0_0_12px_#6366f1]",
    button: "px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-[#2b2bc9] text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300",
    icon: "☀️"
  },
  kryptonite: {
    id: "kryptonite",
    name: "Kryptonite",
    background: "bg-gradient-to-br from-black via-green-950 to-emerald-800",
    panel: "bg-black/40 backdrop-blur-lg border border-emerald-500/40 shadow-lg",
    textPrimary: "text-green-400",
    textSecondary: "text-emerald-200",
    accent: "text-emerald-400",
    glow: "shadow-[0_0_20px_#00ff99]",
    button: "px-6 py-3 rounded-lg bg-gradient-to-r from-emerald-500 to-green-600 text-black font-semibold shadow-lg hover:shadow-xl transition-all duration-300",
    icon: "💎"
  },
};
