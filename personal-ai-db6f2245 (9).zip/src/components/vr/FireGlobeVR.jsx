
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { User } from '@/api/entities';
import { BusinessLocation } from '@/api/entities'; // IMPORT a BusinessLocation
import { LicenseManager } from "@/components/LicenseManagerService";
import { Building, Zap, Shield, Factory } from 'lucide-react'; // Icons for business markers

// Helper to convert Lat/Lon to a 3D point on a sphere
const latLonToVector3 = (lat, lon, radius, height = 0) => {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lon + 180) * (Math.PI / 180);
    const r = radius + height;
    const x = -(r * Math.sin(phi) * Math.cos(theta));
    const z = r * Math.sin(phi) * Math.sin(theta);
    const y = r * Math.cos(phi);
    return new THREE.Vector3(x, y, z);
};

// Timeline Impact Overlay Component, matching your design
const TimelineImpactOverlay = ({ impacts }) => (
    <div className="absolute bottom-4 left-4 bg-black/70 text-white p-4 rounded-lg w-96 shadow-lg border border-green-500/30">
        <h3 className="font-bold text-green-400 mb-2">🌍 Timeline Impact</h3>
        {impacts.length === 0 && <p className="text-gray-400">No interventions yet.</p>}
        {impacts.map((imp, i) => (
            <div key={i} className="border-b border-gray-600 py-1 text-sm">
            <p>
                <span className="text-yellow-400">{imp.region}</span> – Year {imp.year}
            </p>
            <p>
                CO₂ Saved: <span className="text-green-300">{imp.co2} Mt</span> | Biodiversity:{" "}
                <span className="text-cyan-300">{imp.biodiversity}</span>
            </p>
            </div>
        ))}
    </div>
);

const BusinessDetailOverlay = ({ business, onClose }) => {
    if (!business) return null;

    const categoryIcons = {
        corporate_hq: <Building className="w-5 h-5 text-cyan-300" />,
        energy_plant: <Zap className="w-5 h-5 text-yellow-300" />,
        financial_center: <Building className="w-5 h-5 text-green-300" />,
        security_outpost: <Shield className="w-5 h-5 text-red-300" />,
        research_lab: <Factory className="w-5 h-5 text-purple-300" />,
    };

    return (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/80 backdrop-blur-lg border border-cyan-500/40 rounded-xl shadow-2xl shadow-cyan-500/20 p-6 w-[450px] text-white animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <div className="flex items-center gap-3">
                        {categoryIcons[business.category]}
                        <h2 className="text-xl font-bold text-cyan-300">{business.name}</h2>
                    </div>
                    <p className="text-xs text-gray-400">{business.address}</p>
                </div>
                <button onClick={onClose} className="text-gray-400 hover:text-white">&times;</button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div className="bg-black/40 p-2 rounded-md"><span className="text-gray-400">Status:</span> <span className={`font-bold ${business.status === 'online' ? 'text-green-400' : 'text-red-400'}`}>{business.status.toUpperCase()}</span></div>
                <div className="bg-black/40 p-2 rounded-md"><span className="text-gray-400">Security:</span> <span className="font-bold text-yellow-400">{business.security_level.toUpperCase()}</span></div>
                <div className="bg-black/40 p-2 rounded-md"><span className="text-gray-400">Personnel:</span> <span className="font-bold text-blue-400">{business.personnel_count}</span></div>
                <div className="bg-black/40 p-2 rounded-md"><span className="text-gray-400">Power Draw:</span> <span className="font-bold text-purple-400">{business.power_usage_mw} MW</span></div>
            </div>

            {business.photos && business.photos[0] && (
                <img src={business.photos[0]} alt={business.name} className="w-full h-48 object-cover rounded-lg mb-4 border-2 border-gray-700" />
            )}

            <button className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-2 rounded-lg">
                Initiate Deep Dive
            </button>
        </div>
    );
};


export default function FireGlobeVR({ alerts, currentUser, onUserUpdate }) {
    const mountRef = useRef(null);
    const [fires, setFires] = useState([]);
    const [extinguishedCount, setExtinguishedCount] = useState(0);
    const [impacts, setImpacts] = useState([]);
    const [totalCO2Saved, setTotalCO2Saved] = useState(0);
    const [thermalVision, setThermalVision] = useState(false); // thermalVision state is present but unused in the outline, keeping for consistency.
    const sceneRef = useRef(new THREE.Scene());
    const rendererRef = useRef(null);
    const cameraRef = useRef(null);
    const earthRef = useRef(null);
    const fireMeshesRef = useRef([]);
    const [locations, setLocations] = useState([]);
    const [selectedBusiness, setSelectedBusiness] = useState(null);
    const locationMeshesRef = useRef([]);

    const loadBusinessLocations = useCallback(async () => {
        try {
            const fetchedLocations = await BusinessLocation.list();
            setLocations(fetchedLocations);
        } catch (error) {
            console.error("Failed to load business locations:", error);
        }
    }, []);

    // Initialize or update fires from alerts
    useEffect(() => {
        LicenseManager.track('VR_SESSION_START');
        setFires(alerts.map((alert, index) => ({
            ...alert,
            id: alert.id || `${alert.lat}-${alert.lon}-${index}`,
            intensity: alert.confidence,
            region: `Region ${Math.floor(Math.random() * 100)}`, // Mock region data
            date: new Date().getFullYear()
        })));
        setExtinguishedCount(0);
        setImpacts([]);
        setTotalCO2Saved(0);
        loadBusinessLocations();
    }, [alerts, loadBusinessLocations]);

    const speak = useCallback((text) => {
        if ('speechSynthesis' in window) {
            try {
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.pitch = 1.2;
                utterance.rate = 1.0;
                speechSynthesis.cancel();
                speechSynthesis.speak(utterance);
            } catch (error) {
                console.warn("Speech synthesis failed.", error);
            }
        }
    }, []);

    const createLaserBeam = useCallback((startPoint, endPoint, scene) => {
        const laserGeometry = new THREE.BufferGeometry().setFromPoints([startPoint, endPoint]);
        const laserMaterial = new THREE.LineBasicMaterial({ color: 0x00ffff, transparent: true, opacity: 1, linewidth: 3 });
        const laserBeam = new THREE.Line(laserGeometry, laserMaterial);
        scene.add(laserBeam);

        let opacity = 1;
        const fadeOut = () => {
            if (opacity > 0) {
                opacity -= 0.05;
                laserMaterial.opacity = opacity;
                requestAnimationFrame(fadeOut);
            } else {
                scene.remove(laserBeam);
                laserGeometry.dispose();
                laserMaterial.dispose();
            }
        };
        fadeOut();
    }, []);

    const createImpactFlash = useCallback((position, scene) => {
        const flashGeometry = new THREE.SphereGeometry(0.1, 16, 16);
        const flashMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 1 });
        const flash = new THREE.Mesh(flashGeometry, flashMaterial);
        flash.position.copy(position);
        scene.add(flash);

        let scale = 0.1, opacity = 1;
        const animateFlash = () => {
            if (opacity > 0) {
                scale += 0.3;
                opacity -= 0.1;
                flash.scale.setScalar(scale);
                flashMaterial.opacity = opacity;
                requestAnimationFrame(animateFlash);
            } else {
                scene.remove(flash);
                flashGeometry.dispose();
                flashMaterial.dispose();
            }
        };
        animateFlash();
    }, []);
    
    const createSmokeEffect = useCallback((position, scene) => {
        const smokeParticles = [];
        const smokeGeometry = new THREE.SphereGeometry(0.02, 8, 8);
        const smokeMaterial = new THREE.MeshBasicMaterial({ color: 0xcccccc, transparent: true, opacity: 0.6 });

        for (let i = 0; i < 15; i++) {
            const particle = new THREE.Mesh(smokeGeometry, smokeMaterial.clone());
            particle.position.copy(position);
            particle.position.x += (Math.random() - 0.5) * 0.1;
            particle.position.y += (Math.random() - 0.5) * 0.1;
            particle.position.z += (Math.random() - 0.5) * 0.1;
            particle.userData.velocity = new THREE.Vector3(0, Math.random() * 0.005, 0);
            particle.userData.life = 1;
            scene.add(particle);
            smokeParticles.push(particle);
        }

        const animateSmoke = () => {
            let particlesAlive = false;
            smokeParticles.forEach(p => {
                if (p.userData.life > 0) {
                    particlesAlive = true;
                    p.userData.life -= 0.02;
                    p.material.opacity = p.userData.life;
                    p.position.add(p.userData.velocity);
                } else {
                    scene.remove(p);
                    // Dispose resources for removed particle
                    if (p.geometry) p.geometry.dispose();
                    if (p.material) p.material.dispose();
                }
            });

            if (particlesAlive) {
                requestAnimationFrame(animateSmoke);
            } else {
                // Dispose shared resources only once all particles are gone
                smokeGeometry.dispose();
                smokeMaterial.dispose();
            }
        };
        animateSmoke();
    }, []);

    const fireLaser = useCallback((fireIndex) => {
        const fire = fires[fireIndex];
        if (!fire || fire.intensity <= 0) return;

        const scene = sceneRef.current;
        const fireMesh = fireMeshesRef.current[fireIndex];
        if (!fireMesh) return;

        const laserStartPoint = new THREE.Vector3().setFromMatrixPosition(cameraRef.current.matrixWorld);
        const laserEndPoint = fireMesh.position.clone();
        createLaserBeam(laserStartPoint, laserEndPoint, scene);
        createImpactFlash(laserEndPoint, scene);
        createSmokeEffect(laserEndPoint, scene); // <-- ADDED SMOKE EFFECT

        setFires(prevFires => {
            const newFires = [...prevFires];
            const targetFire = { ...newFires[fireIndex] };
            targetFire.intensity -= 34; // Reduce intensity per hit

            if (targetFire.intensity <= 0) {
                const co2Saved = (targetFire.confidence * 0.02).toFixed(2);
                const newImpact = {
                    region: targetFire.region || "Unknown",
                    co2: co2Saved,
                    biodiversity: targetFire.confidence > 70 ? "High" : "Medium",
                    year: targetFire.date || new Date().getFullYear(),
                };
                
                LicenseManager.track('LASER_STRIKE_SUCCESS');

                setImpacts(prev => [...prev, newImpact]);
                setTotalCO2Saved(prev => prev + parseFloat(co2Saved));
                setExtinguishedCount(c => c + 1);
                speak(`Wildfire in ${newImpact.region} extinguished. Timeline impact updated.`);
                
                // Update user trust score and stats
                if(currentUser) {
                    const updatedFiresCount = (currentUser.fires_extinguished || 0) + 1;
                    const updatedTrustScore = Math.min(100, (currentUser.trust_score || 87) + 1);
                    const updatedData = { 
                        fires_extinguished: updatedFiresCount,
                        trust_score: updatedTrustScore
                    };
                    User.updateMyUserData(updatedData);
                    onUserUpdate(updatedData);
                }
            } else {
                 LicenseManager.track('LASER_STRIKE_HIT');
            }
            newFires[fireIndex] = targetFire;
            return newFires;
        });

    }, [fires, speak, createLaserBeam, createImpactFlash, createSmokeEffect, currentUser, onUserUpdate]);

    useEffect(() => {
        if (!mountRef.current) return;
        const currentMount = mountRef.current;
        const scene = sceneRef.current;
        let cloudMesh; // Declare cloudMesh here so it's accessible in animate

        if (!rendererRef.current) {
            cameraRef.current = new THREE.PerspectiveCamera(75, currentMount.clientWidth / currentMount.clientHeight, 0.1, 1000);
            cameraRef.current.position.z = 3.5;

            rendererRef.current = new THREE.WebGLRenderer({ antialias: true, alpha: true });
            rendererRef.current.setSize(currentMount.clientWidth / 1, currentMount.clientHeight / 1); // Adjust for potential performance or scaling
            rendererRef.current.setPixelRatio(window.devicePixelRatio);
            currentMount.appendChild(rendererRef.current.domElement);
            
            scene.add(new THREE.AmbientLight(0x444444));
            const pointLight = new THREE.PointLight(0xffffff, 1.5, 100);
            pointLight.position.set(10, 10, 10);
            scene.add(pointLight);

            const textureLoader = new THREE.TextureLoader();
            const earthMaterial = new THREE.MeshStandardMaterial({ 
                map: textureLoader.load('https://raw.githubusercontent.com/turban/webgl-earth/master/images/2_no_clouds_4k.jpg'),
                // ADDED: Night lights texture
                emissiveMap: textureLoader.load('https://raw.githubusercontent.com/turban/webgl-earth/master/images/earth_lights_lrg.jpg'),
                emissive: new THREE.Color(0xffffff),
                emissiveIntensity: 1.2,
            });
            earthRef.current = new THREE.Mesh(new THREE.SphereGeometry(2, 64, 64), earthMaterial);
            scene.add(earthRef.current);

            const atmosphereMaterial = new THREE.ShaderMaterial({
                vertexShader: `varying vec3 vNormal; void main() { vNormal = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
                fragmentShader: `varying vec3 vNormal; void main() { float intensity = pow(0.5 - dot(vNormal, vec3(0, 0, 1.0)), 2.0); gl_FragColor = vec4(0.3, 0.6, 1.0, 1.0) * intensity; }`,
                blending: THREE.AdditiveBlending,
                side: THREE.BackSide,
            });
            const atmosphere = new THREE.Mesh(new THREE.SphereGeometry(2, 64, 64), atmosphereMaterial);
            atmosphere.scale.set(1.1, 1.1, 1.1);
            scene.add(atmosphere);

            const starVertices = [];
            for (let i = 0; i < 15000; i++) {
                const x = (Math.random() - 0.5) * 2000;
                const y = (Math.random() - 0.5) * 2000;
                const z = (Math.random() - 0.5) * 2000;
                if (x*x + y*y + z*z > 100*100) starVertices.push(x, y, z);
            }
            const starGeometry = new THREE.BufferGeometry();
            starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
            const starMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.8, transparent: true, opacity: 0.8 });
            scene.add(new THREE.Points(starGeometry, starMaterial));

            // ADDED: Cloud layer
            const cloudGeometry = new THREE.SphereGeometry(2.01, 64, 64);
            const cloudMaterial = new THREE.MeshStandardMaterial({
                map: textureLoader.load('https://raw.githubusercontent.com/turban/webgl-earth/master/images/fair_clouds_4k.png'),
                transparent: true,
                opacity: 0.3,
            });
            cloudMesh = new THREE.Mesh(cloudGeometry, cloudMaterial);
            scene.add(cloudMesh);


            let isMouseDown = false;
            let previousMousePosition = { x: 0, y: 0 };
            
            const onMouseDown = (e) => { isMouseDown = true; previousMousePosition = { x: e.clientX, y: e.clientY }; };
            const onMouseUp = () => { isMouseDown = false; };
            const onMouseMove = (e) => {
                if (!isMouseDown) return;
                const deltaX = e.clientX - previousMousePosition.x;
                const deltaY = e.clientY - previousMousePosition.y;
                earthRef.current.rotation.y += deltaX * 0.005;
                earthRef.current.rotation.x += deltaY * 0.005;
                previousMousePosition = { x: e.clientX, y: e.clientY };
            };
            const onWheel = (e) => {
                cameraRef.current.position.z += e.deltaY * 0.002;
                cameraRef.current.position.z = Math.max(2.5, Math.min(cameraRef.current.position.z, 10));
            };
            const onClick = (e) => {
                const rect = currentMount.getBoundingClientRect();
                const mouse = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
                const raycaster = new THREE.Raycaster();
                raycaster.setFromCamera(mouse, cameraRef.current);
                const fireIntersects = raycaster.intersectObjects(fireMeshesRef.current);
                const locationIntersects = raycaster.intersectObjects(locationMeshesRef.current);

                if (fireIntersects.length > 0) {
                    const intersectedObject = fireIntersects[0].object;
                    // Check if the intersected object is an active fire before firing
                    if (intersectedObject.userData.fireIndex !== undefined && fires[intersectedObject.userData.fireIndex]?.intensity > 0) {
                        fireLaser(intersectedObject.userData.fireIndex);
                    }
                } else if (locationIntersects.length > 0) {
                    const intersectedObject = locationIntersects[0].object;
                    // Find the actual business object based on the stored index
                    const business = locations[intersectedObject.userData.locationIndex];
                    setSelectedBusiness(business);
                }
            };
            
            currentMount.addEventListener('mousedown', onMouseDown);
            currentMount.addEventListener('mouseup', onMouseUp);
            currentMount.addEventListener('mousemove', onMouseMove);
            currentMount.addEventListener('wheel', onWheel);
            currentMount.addEventListener('click', onClick);

            const animate = () => {
                requestAnimationFrame(animate);
                if (!isMouseDown) {
                    earthRef.current.rotation.y += 0.0005;
                    if (cloudMesh) cloudMesh.rotation.y += 0.0003; // Animate clouds
                }
                
                fireMeshesRef.current.forEach((mesh, index) => {
                    if (mesh && fires[index] && fires[index].intensity > 0) {
                        const time = Date.now() * 0.005;
                        const baseScaleFactor = mesh.userData.baseScaleFactor || 1; // Default to 1 if not set
                        mesh.scale.setScalar(baseScaleFactor * (1 + Math.sin(time + index) * 0.1));
                    }
                });

                // Animate business location markers
                locationMeshesRef.current.forEach((mesh) => {
                    if (mesh) {
                        mesh.lookAt(cameraRef.current.position); // Make markers face camera
                        const dist = cameraRef.current.position.distanceTo(mesh.position);
                        const scale = Math.min(Math.max(1 / dist, 0.2), 1) * 0.05; // Scale based on distance
                        mesh.scale.set(scale, scale, scale);
                    }
                });
                
                rendererRef.current.render(scene, cameraRef.current);
            };
            animate();
        }

        // Prepare a new array for the current state of fire meshes.
        const newFireMeshesRefContents = [];
        const meshesToKeep = new Set(); // Keep track of meshes that are still relevant

        fires.forEach((fire, index) => {
            let fireMesh = fireMeshesRef.current[index];

            if (fire.intensity > 0) {
                // If fire is active
                if (fireMesh) {
                    // Mesh exists, update it
                    fireMesh.visible = true;
                    // Update scale factor for pulsation
                    fireMesh.userData.baseScaleFactor = Math.max(0.1, fire.intensity / 100);
                    fireMesh.position.copy(latLonToVector3(fire.lat, fire.lon, 2.02)); // Update position in case lat/lon changed
                    fireMesh.userData.fireIndex = index; // Ensure index is correct
                    
                    // Update material color if intensity crosses thresholds
                    let newColor;
                    if (fire.intensity > 60) newColor = new THREE.Color('red');
                    else if (fire.intensity > 30) newColor = new THREE.Color('orange');
                    else newColor = new THREE.Color('yellow');
                    
                    // Check if color needs update
                    if (!fireMesh.material.emissive.equals(newColor)) {
                        fireMesh.material.emissive.set(newColor);
                    }
                    
                    newFireMeshesRefContents[index] = fireMesh;
                    meshesToKeep.add(fireMesh);
                } else {
                    // No mesh exists, create a new one
                    const position = latLonToVector3(fire.lat, fire.lon, 2.02);
                    let color;
                    if (fire.intensity > 60) color = 'red';
                    else if (fire.intensity > 30) color = 'orange';
                    else color = 'yellow';
                    
                    const material = new THREE.MeshStandardMaterial({
                        emissive: color,
                        emissiveIntensity: 2,
                        color: 'white',
                        transparent: true,
                        opacity: 0.9
                    });
                    
                    const size = Math.max(0.01, (fire.intensity / 100) * 0.05); // Initial radius based on intensity
                    const fireGeometry = new THREE.SphereGeometry(size, 16, 16);
                    fireMesh = new THREE.Mesh(fireGeometry, material);
                    
                    fireMesh.position.copy(position);
                    fireMesh.userData = { fireIndex: index, baseScaleFactor: Math.max(0.1, fire.intensity / 100) }; // Store base scale factor
                    
                    scene.add(fireMesh);
                    newFireMeshesRefContents[index] = fireMesh;
                    meshesToKeep.add(fireMesh);
                }
            } else {
                // If fire is extinguished
                if (fireMesh) {
                    // Hide the mesh if it exists
                    fireMesh.visible = false;
                    newFireMeshesRefContents[index] = fireMesh; // Keep reference to it (hidden)
                    meshesToKeep.add(fireMesh); // Mark as kept (hidden)
                }
            }
        });

        // Clean up old meshes that are no longer in the `fires` array or were not processed/kept
        fireMeshesRef.current.forEach(mesh => {
            if (mesh && !meshesToKeep.has(mesh)) {
                scene.remove(mesh);
                if (mesh.geometry) mesh.geometry.dispose();
                if (mesh.material) mesh.material.dispose();
            }
        });

        fireMeshesRef.current = newFireMeshesRefContents; // Update the ref with the new collection
        
        // --- Business Location Marker Logic ---
        const categoryColors = {
            corporate_hq: new THREE.Color('#00ffff'), // cyan
            energy_plant: new THREE.Color('#ffff00'), // yellow
            financial_center: new THREE.Color('#00ff00'), // green
            security_outpost: new THREE.Color('#ff0000'), // red
            research_lab: new THREE.Color('#800080'), // purple
        };

        const newLocationMeshesRefContents = [];
        const locationMeshesToKeep = new Set();
        locations.forEach((loc, index) => {
            let locMesh = locationMeshesRef.current[index];
            if (!locMesh) {
                const position = latLonToVector3(loc.lat, loc.lon, 2.03); // Slightly above earth
                const material = new THREE.MeshBasicMaterial({
                    color: categoryColors[loc.category] || new THREE.Color('white'),
                    transparent: true,
                    opacity: 0.9,
                    side: THREE.DoubleSide // Ensure visibility from both sides
                });
                const geometry = new THREE.BoxGeometry(1, 1, 0.1); // A simple plane (or small box)
                locMesh = new THREE.Mesh(geometry, material);
                locMesh.position.copy(position);
                locMesh.userData = { locationIndex: index };
                scene.add(locMesh);
            }
            newLocationMeshesRefContents[index] = locMesh;
            locationMeshesToKeep.add(locMesh);
        });

        locationMeshesRef.current.forEach(mesh => {
            if (mesh && !locationMeshesToKeep.has(mesh)) {
                scene.remove(mesh);
                if (mesh.geometry) mesh.geometry.dispose();
                if (mesh.material) mesh.material.dispose();
            }
        });
        locationMeshesRef.current = newLocationMeshesRefContents;


    }, [fires, fireLaser, currentUser, onUserUpdate, locations, createLaserBeam, createImpactFlash, createSmokeEffect]);

    return (
        <div className="relative w-full h-full">
            <div ref={mountRef} className="w-full h-full cursor-crosshair" />
            
            <div className="absolute top-4 right-4 p-4 bg-black/80 backdrop-blur-md rounded-xl border border-cyan-500/30 shadow-[0_0_25px_rgba(0,255,255,0.3)]">
                <h3 className="text-cyan-300 font-bold text-sm mb-3 flex items-center gap-2">🛰️ ORBITAL INTERVENTION SYSTEM</h3>
                <div className="space-y-2 text-xs">
                    <div className="flex justify-between"><span className="text-gray-300">Active Threats:</span><span className="text-red-400 font-mono">{fires.filter(f => f.intensity > 0).length}</span></div>
                    <div className="flex justify-between"><span className="text-gray-300">Neutralized:</span><span className="text-green-400 font-mono">{extinguishedCount}</span></div>
                    <div className="flex justify-between"><span className="text-gray-300">CO₂ Prevented:</span><span className="text-blue-400 font-mono">{totalCO2Saved.toFixed(1)}Mt</span></div>
                </div>
                <div className="text-xs text-amber-400 animate-pulse text-center mt-3">Click Fires to Launch Strike</div>
            </div>

            <TimelineImpactOverlay impacts={impacts} />

            {selectedBusiness && (
                <BusinessDetailOverlay business={selectedBusiness} onClose={() => setSelectedBusiness(null)} />
            )}
        </div>
    );
}
