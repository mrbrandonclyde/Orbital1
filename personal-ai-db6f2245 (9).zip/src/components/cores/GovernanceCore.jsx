import { useState } from "react";
import { ChevronDown, ChevronRight, Shield, FileText, Activity, ShieldCheck, AlertTriangle, Gem } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function GovernanceCore({ stats }) {
  const [open, setOpen] = useState({
    audit: true,
    health: false,
    risk: false,
    guardian: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <Shield className="w-5 h-5 text-cyan" />
            Governance Core
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className="bg-kryptonite-green/20 text-kryptonite border-kryptonite/30">
            ACTIVE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Ensures security, compliance, and operational integrity.
        </p>

        {/* Performance Metrics */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-silver">Performance</span>
            <span className="text-cyan">{stats.metrics.performance}%</span>
          </div>
          <Progress value={stats.metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
          
          <div className="flex justify-between text-sm">
            <span className="text-silver">Memory Usage</span>
            <span className="text-amber">{stats.metrics.memory}%</span>
          </div>
          <Progress value={stats.metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
        </div>

        {/* Audit Logs */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("audit")}
          >
            {open.audit ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <FileText className="w-3 h-3" />
            Audit Logs
          </button>
          {open.audit && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">History Status: <span className="text-kryptonite font-bold">{stats.audit}</span></p>
              <p className="text-silver">All Actions Logged: <span className="text-kryptonite font-bold">Yes</span></p>
              <p className="flex items-center gap-1 text-kryptonite">Tamper-proof recording active</p>
            </div>
          )}
        </div>

        {/* System Health */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("health")}
          >
            {open.health ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Activity className="w-3 h-3" />
            System Health
          </button>
          {open.health && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Telemetry: <span className="text-kryptonite font-bold">{stats.telemetry}</span></p>
              <p className="text-silver">Performance Metrics: <span className="text-kryptonite font-bold">Collecting</span></p>
              <p className="flex items-center gap-1 text-kryptonite">All systems monitored</p>
            </div>
          )}
        </div>

        {/* Predictive Governance */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("risk")}
          >
            {open.risk ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <AlertTriangle className="w-3 h-3" />
            Predictive Governance
          </button>
          {open.risk && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-silver">Risk Score:</span>
                <span className="text-amber font-bold">{stats.risk}%</span>
              </div>
              <div className="w-full bg-slate-700/50 rounded-full h-2">
                <div className="bg-amber h-2 rounded-full" style={{ width: `${stats.risk}%` }}></div>
              </div>
              <p className="text-amber text-xs">Anomaly detection active</p>
            </div>
          )}
        </div>

        {/* Guardian Center */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("guardian")}
          >
            {open.guardian ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <ShieldCheck className="w-3 h-3" />
            Guardian Center
          </button>
          {open.guardian && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Status: <span className="text-kryptonite font-bold">{stats.guardian}</span></p>
              <p className="text-silver">Threat Intel Feeds: <span className="text-kryptonite font-bold">Active</span></p>
              <p className="text-silver">Defense Systems: <span className="text-kryptonite font-bold">Armed</span></p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}