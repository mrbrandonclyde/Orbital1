import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export function Connection({ start, end, status, performance, glow }) {
  const points = useMemo(() => [new THREE.Vector3(...start), new THREE.Vector3(...end)], [start, end]);
  const curve = useMemo(() => new THREE.CatmullRomCurve3(points), [points]);
  const geometry = useMemo(() => new THREE.TubeGeometry(curve, 20, 0.02, 8, false), [curve]);

  // Color selection by subsystem status
  const getColor = () => {
    switch (status) {
      case "online": return "#39FF14";   // Kryptonite Green
      case "degraded": return "#FFA500"; // Amber
      case "offline": return "#DC143C";  // Crimson
      default: return "#00FFFF";         // Cyan
    }
  };
  const packetColor = getColor();

  // Speed scaling by performance %
  const baseSpeed = performance >= 90 ? 0.03 : performance >= 50 ? 0.015 : 0.007;

  // Packet style scaling
  const packetScale = performance >= 90 ? 1.2 : performance >= 50 ? 1 : 0.8;
  const initialPacketGlow = performance >= 90 ? 3 : performance >= 50 ? 2 : 1.2;
  const tubeIntensity = glow ? 2.5 : 1.2;
  const packetGlow = glow ? initialPacketGlow * 1.5 : initialPacketGlow;

  // --- Corrected Hook Usage ---
  const packetCount = 4;
  
  // Memoize the arrays of refs to ensure they are stable across renders
  const packetRefs = useMemo(() => Array.from({ length: packetCount }, () => useRef()), []);
  const packetOffsets = useMemo(() => Array.from({ length: packetCount }, (_, i) => useRef(i / packetCount)), []);

  const packets = useMemo(() => 
    Array.from({ length: packetCount }, (_, i) => ({
      ref: packetRefs[i],
      offset: packetOffsets[i],
      speed: baseSpeed * (0.9 + Math.random() * 0.2),
    })), [baseSpeed, packetRefs, packetOffsets]);

  const packetMaterial = useMemo(() => (
    new THREE.MeshStandardMaterial({
      emissive: packetColor,
      emissiveIntensity: packetGlow,
      color: packetColor,
    })
  ), [packetColor, packetGlow]);

  useFrame(({ clock }) => {
    const time = clock.getElapsedTime();
    packets.forEach((p) => {
      p.offset.current += p.speed;
      if (p.offset.current > 1) p.offset.current -= 1;
      
      const pos = curve.getPointAt(p.offset.current);
      if (p.ref.current) {
        p.ref.current.position.copy(pos);
        const pulse = 1 + 0.15 * Math.sin(time * 5 + p.offset.current * Math.PI * 4);
        p.ref.current.scale.setScalar(packetScale * pulse);
      }
    });
  });

  return (
    <>
      <mesh geometry={geometry}>
        <meshStandardMaterial color="cyan" emissive="cyan" emissiveIntensity={tubeIntensity} />
      </mesh>
      {packets.map((p, i) => (
        <mesh key={i} ref={p.ref}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <primitive object={packetMaterial} attach="material" />
        </mesh>
      ))}
    </>
  );
}