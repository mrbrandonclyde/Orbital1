import { useState } from "react";
import { ChevronDown, ChevronRight, Settings, Wifi, WifiOff, AlertTriangle, Gem } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function ConfigCore({ stats }) {
  const [open, setOpen] = useState({
    integrations: true,
    configs: false,
    vault: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  const getIntegrationStatus = (status) => {
    switch(status) {
      case 'online': return { icon: Wifi, color: 'text-kryptonite', text: 'Online' };
      case 'degraded': return { icon: AlertTriangle, color: 'text-amber', text: 'Warning' };
      case 'offline': return { icon: WifiOff, color: 'text-crimson', text: 'Offline' };
      default: return { icon: WifiOff, color: 'text-silver', text: 'Unknown' };
    }
  };

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <Settings className="w-5 h-5 text-cyan" />
            Config + Integrations
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className="bg-kryptonite-green/20 text-kryptonite border-kryptonite/30">
            ACTIVE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Manages system configuration, external APIs, and secret storage.
        </p>

        {/* Performance Metrics */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-silver">Performance</span>
            <span className="text-cyan">{stats.metrics.performance}%</span>
          </div>
          <Progress value={stats.metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
          
          <div className="flex justify-between text-sm">
            <span className="text-silver">Memory Usage</span>
            <span className="text-amber">{stats.metrics.memory}%</span>
          </div>
          <Progress value={stats.metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
        </div>

        {/* API Integrations */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("integrations")}
          >
            {open.integrations ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            🔗 API Integrations
          </button>
          {open.integrations && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-2">
              {Object.entries(stats.integrations).map(([name, status]) => {
                const statusConfig = getIntegrationStatus(status);
                const Icon = statusConfig.icon;
                return (
                  <div key={name} className="flex items-center justify-between bg-obsidian-black/50 p-2 rounded-md">
                    <span className="text-silver capitalize">{name.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <span className={`font-bold text-xs flex items-center gap-1 ${statusConfig.color}`}>
                      <Icon className="w-3 h-3" />
                      {statusConfig.text}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* System Configs */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("configs")}
          >
            {open.configs ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            ⚙️ System Configs
          </button>
          {open.configs && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Application Settings: <span className="text-kryptonite font-bold">Loaded</span></p>
              <p className="text-silver">Mode Settings: <span className="text-kryptonite font-bold">Active</span></p>
              <p className="flex items-center gap-1 text-kryptonite">All configurations synced</p>
            </div>
          )}
        </div>

        {/* Encrypted Vault */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("vault")}
          >
            {open.vault ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            🔐 Encrypted Vault
          </button>
          {open.vault && (
            <div className="bg-[rgba(10,10,15,0.5)] p-3 rounded-lg border border-cyan/20 text-xs space-y-1">
              <p className="text-silver">Token Manager: <span className="text-kryptonite font-bold">Secure</span></p>
              <p className="text-silver">Secrets Manager: <span className="text-kryptonite font-bold">Encrypted</span></p>
              <p className="flex items-center gap-1 text-kryptonite">AES-256 protection active</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}