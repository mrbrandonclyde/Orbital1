import { useState } from "react";
import { ChevronDown, ChevronRight, User, Shield, Eye, UserIcon, Clock, Gem } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function IdentityCore({ stats }) {
  const [open, setOpen] = useState({
    trust: true,
    biometrics: true, 
    roles: false,
    accessLog: false,
  });

  const toggle = (key) => setOpen((prev) => ({ ...prev, [key]: !prev[key] }));

  return (
    <Card className="superman-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-silver">
            <User className="w-5 h-5 text-cyan" />
            Identity Core
            <Gem className="w-4 h-4 text-gold opacity-80" />
          </CardTitle>
          <Badge className="bg-kryptonite-green/20 text-kryptonite border-kryptonite/30">
            ACTIVE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-silver opacity-80">
          Manages user identity, authentication, permissions, and personalization.
        </p>

        {/* Performance Metrics */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-silver">Performance</span>
            <span className="text-cyan">{stats.metrics.performance}%</span>
          </div>
          <Progress value={stats.metrics.performance} className="h-1.5 [&>div]:progress-cyan" />
          
          <div className="flex justify-between text-sm">
            <span className="text-silver">Memory Usage</span>
            <span className="text-amber">{stats.metrics.memory}%</span>
          </div>
          <Progress value={stats.metrics.memory} className="h-1.5 [&>div]:bg-amber-orange" />
        </div>

        {/* Trust Scoring */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("trust")}
          >
            {open.trust ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Shield className="w-3 h-3" />
            TRUST SCORING
          </button>
          {open.trust && (
            <div className="p-3 bg-obsidian-black/50 rounded-lg border border-cyan/20">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-silver">Session Trust</span>
                <span className="text-kryptonite font-bold text-lg">{stats.trust}/100</span>
              </div>
              <div className="w-full bg-slate-700/50 rounded-full h-3 mb-2">
                <div className="bg-gradient-to-r from-kryptonite to-green-400 h-3 rounded-full" style={{ width: `${stats.trust}%` }}></div>
              </div>
              <div className="text-xs text-silver space-y-1">
                <p className="text-kryptonite">High Trust • Last Validation: 2 mins ago</p>
                <p className="text-silver opacity-70">Risk Level: Minimal • Trend: ↗ Stable</p>
              </div>
            </div>
          )}
        </div>

        {/* Biometric Status */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("biometrics")}
          >
            {open.biometrics ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Eye className="w-3 h-3" />
            BIOMETRIC STATUS
          </button>
          {open.biometrics && (
            <div className="grid grid-cols-1 gap-2 text-xs">
              <div className="flex items-center justify-between bg-kryptonite/10 p-2 rounded border border-kryptonite/30">
                <span className="flex items-center gap-2 text-kryptonite">🎤 Voice ID</span>
                <span className="text-kryptonite font-semibold">{stats.biometrics.voice}</span>
              </div>
              <div className="flex items-center justify-between bg-kryptonite/10 p-2 rounded border border-kryptonite/30">
                <span className="flex items-center gap-2 text-kryptonite">👁️ Face ID</span>
                <span className="text-kryptonite font-semibold">{stats.biometrics.face}</span>
              </div>
              <div className="flex items-center justify-between bg-kryptonite/10 p-2 rounded border border-kryptonite/30">
                <span className="flex items-center gap-2 text-kryptonite">✋ Gesture</span>
                <span className="text-kryptonite font-semibold">{stats.biometrics.gesture}</span>
              </div>
            </div>
          )}
        </div>

        {/* Active Roles */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("roles")}
          >
            {open.roles ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <UserIcon className="w-3 h-3" />
            ACTIVE ROLES
          </button>
          {open.roles && (
            <div className="grid grid-cols-2 gap-2 text-xs">
              {stats.roles.map((role, idx) => (
                <div key={idx} className="bg-cyan/10 p-2 rounded border border-cyan/30 text-center">
                  <span className="text-cyan font-semibold">
                    {role === 'Business' ? '👨‍💼' : role === 'Admin' ? '🛡' : role === 'Developer' ? '💻' : '🎨'} {role}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Access Log */}
        <div>
          <button
            className="flex items-center gap-2 w-full text-left text-gold font-semibold text-xs mb-2 hover:text-cyan transition-colors"
            onClick={() => toggle("accessLog")}
          >
            {open.accessLog ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Clock className="w-3 h-3" />
            ACCESS LOG
          </button>
          {open.accessLog && (
            <div className="bg-obsidian-black/30 p-2 rounded text-xs text-silver space-y-1">
              {stats.accessLog.map((log, idx) => (
                <p key={idx}>• {log}</p>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}