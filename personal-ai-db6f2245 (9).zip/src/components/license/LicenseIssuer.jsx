import React, { useState } from "react";
import { License } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Shield, Calendar as CalendarIcon, Loader2, Copy, Check } from "lucide-react";
import { format } from "date-fns";

export default function LicenseIssuer({ onLicenseIssued, onLogAction }) {
    const [formData, setFormData] = useState({
        email: '', customer_name: '', phone: '', company: '',
        tier: 'basic', seats: 1, expiry_date: '', notes: ''
    });
    const [isIssuing, setIsIssuing] = useState(false);
    const [generatedKey, setGeneratedKey] = useState('');
    const [copied, setCopied] = useState(false);

    const generateLicenseKey = () => {
        const segments = Array(4).fill(0).map(() => Math.random().toString(36).substring(2, 8).toUpperCase());
        return `PAPP-${segments.join('-')}`;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsIssuing(true);
        try {
            const licenseKey = generateLicenseKey();
            await License.create({ ...formData, license_key: licenseKey, status: 'active' });
            setGeneratedKey(licenseKey);
            await onLogAction('license_issued', `License for ${formData.email} - Tier: ${formData.tier}, Seats: ${formData.seats}`, formData.email, 'info');
            onLicenseIssued();
        } catch (error) {
            console.error('Error issuing license:', error);
            await onLogAction('license_issued_failed', `Failed for ${formData.email}: ${error.message}`, formData.email, 'error');
        } finally {
            setIsIssuing(false);
        }
    };

    const copyLicenseKey = async () => {
        await navigator.clipboard.writeText(generatedKey);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const tierPricing = {
        basic: { price: 29 }, professional: { price: 99 }, enterprise: { price: 299 }, unlimited: { price: 999 }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="superman-card">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2 text-xl">
                        <Shield className="w-6 h-6 text-cyan" />
                        Issue New License
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2"><Label htmlFor="email" className="text-silver">Customer Email *</Label><Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} required /></div>
                            <div className="space-y-2"><Label htmlFor="customer_name" className="text-silver">Customer Name</Label><Input id="customer_name" value={formData.customer_name} onChange={(e) => setFormData({...formData, customer_name: e.target.value})} /></div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2"><Label htmlFor="phone" className="text-silver">Phone</Label><Input id="phone" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} /></div>
                            <div className="space-y-2"><Label htmlFor="company" className="text-silver">Company</Label><Input id="company" value={formData.company} onChange={(e) => setFormData({...formData, company: e.target.value})} /></div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2"><Label htmlFor="tier" className="text-silver">License Tier</Label><Select value={formData.tier} onValueChange={(value) => setFormData({...formData, tier: value})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="basic">Basic - ${tierPricing.basic.price}</SelectItem><SelectItem value="professional">Professional - ${tierPricing.professional.price}</SelectItem><SelectItem value="enterprise">Enterprise - ${tierPricing.enterprise.price}</SelectItem><SelectItem value="unlimited">Unlimited - ${tierPricing.unlimited.price}</SelectItem></SelectContent></Select></div>
                            <div className="space-y-2"><Label htmlFor="seats" className="text-silver">Seats</Label><Input id="seats" type="number" min="1" value={formData.seats} onChange={(e) => setFormData({...formData, seats: parseInt(e.target.value) || 1})} /></div>
                            <div className="space-y-2"><Label className="text-silver">Expiry Date</Label><Popover><PopoverTrigger asChild><Button variant="outline" className="w-full justify-start font-normal"><CalendarIcon className="mr-2 h-4 w-4" />{formData.expiry_date ? format(new Date(formData.expiry_date), 'PPP') : 'Select date'}</Button></PopoverTrigger><PopoverContent className="w-auto p-0 superman-card"><Calendar mode="single" selected={formData.expiry_date ? new Date(formData.expiry_date) : undefined} onSelect={(date) => setFormData({...formData, expiry_date: date?.toISOString().split('T')[0]})}/></PopoverContent></Popover></div>
                        </div>
                        <div className="space-y-2"><Label htmlFor="notes" className="text-silver">Internal Notes</Label><Textarea id="notes" value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} placeholder="Any internal notes about this license..." /></div>
                        <Button type="submit" disabled={isIssuing} className="w-full btn-cyan"><div className="flex items-center justify-center">{isIssuing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Issue License</div></Button>
                    </form>
                </CardContent>
            </Card>

            {generatedKey && (
                <Card className="superman-card kryptonite-glow">
                    <CardHeader><CardTitle className="text-kryptonite">License Generated Successfully!</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <div className="p-4 bg-black/30 rounded-lg">
                            <Label className="text-silver text-sm">License Key:</Label>
                            <div className="flex items-center gap-2 mt-1">
                                <code className="flex-1 text-kryptonite font-mono text-lg bg-black/50 p-2 rounded">{generatedKey}</code>
                                <Button variant="outline" size="icon" onClick={copyLicenseKey} className="border-kryptonite text-kryptonite hover:bg-kryptonite/20">{copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}</Button>
                            </div>
                        </div>
                        <div className="text-sm text-silver space-y-1">
                            <p><strong>Email:</strong> {formData.email}</p>
                            <p><strong>Tier:</strong> <span className="capitalize">{formData.tier}</span></p>
                            <p><strong>Seats:</strong> {formData.seats}</p>
                            {formData.expiry_date && <p><strong>Expires:</strong> {format(new Date(formData.expiry_date), 'PPP')}</p>}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}