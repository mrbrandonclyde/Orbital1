import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, DollarSign, AlertTriangle, RefreshCw, TrendingUp } from "lucide-react";
import { format } from "date-fns";

export default function LicenseDashboard({ licenses, stats, onRefresh, onLogAction }) {
    const recentLicenses = licenses.slice(0, 10);
    const expiringLicenses = licenses.filter(l => {
        if (!l.expiry_date || l.status !== 'active') return false;
        const expiryDate = new Date(l.expiry_date);
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        return expiryDate <= thirtyDaysFromNow;
    });

    const tierColors = {
        basic: "bg-gray-500",
        professional: "bg-blue-500", 
        enterprise: "bg-purple-500",
        unlimited: "bg-gold-500"
    };

    const statusColors = {
        active: "bg-green-500",
        expired: "bg-red-500",
        revoked: "bg-red-600",
        suspended: "bg-yellow-500"
    };

    return (
        <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-br from-blue-600 to-blue-800 border-0 text-white">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-blue-100 text-sm">Total Licenses</p>
                                <h3 className="text-3xl font-bold">{stats.totalLicenses}</h3>
                            </div>
                            <Shield className="w-12 h-12 text-blue-200" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-600 to-green-800 border-0 text-white">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-green-100 text-sm">Active Licenses</p>
                                <h3 className="text-3xl font-bold">{stats.activeLicenses}</h3>
                            </div>
                            <Users className="w-12 h-12 text-green-200" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-600 to-purple-800 border-0 text-white">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-purple-100 text-sm">Total Revenue</p>
                                <h3 className="text-3xl font-bold">${stats.totalRevenue.toFixed(2)}</h3>
                            </div>
                            <DollarSign className="w-12 h-12 text-purple-200" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-yellow-600 to-orange-700 border-0 text-white">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-yellow-100 text-sm">Expiring Soon</p>
                                <h3 className="text-3xl font-bold">{stats.expiringLicenses}</h3>
                            </div>
                            <AlertTriangle className="w-12 h-12 text-yellow-200" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Licenses */}
                <Card className="bg-gray-800/50 border-gray-700">
                    <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-5 h-5 text-blue-400" />
                            Recent Licenses
                        </CardTitle>
                        <Button variant="ghost" size="icon" onClick={onRefresh} className="text-gray-400 hover:text-white">
                            <RefreshCw className="w-4 h-4" />
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                            {recentLicenses.map(license => (
                                <div key={license.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                                    <div className="flex-1">
                                        <p className="text-white font-medium">{license.customer_name || license.email}</p>
                                        <p className="text-gray-400 text-sm">{license.email}</p>
                                        <div className="flex gap-2 mt-1">
                                            <Badge className={tierColors[license.tier]}>
                                                {license.tier}
                                            </Badge>
                                            <Badge className={statusColors[license.status]}>
                                                {license.status}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-gray-400 text-xs">
                                            {format(new Date(license.created_date), 'MMM d, yyyy')}
                                        </p>
                                        <p className="text-white text-sm">{license.seats} seats</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Expiring Licenses Alert */}
                <Card className="bg-gray-800/50 border-gray-700">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-yellow-400" />
                            Expiring Licenses (30 days)
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                            {expiringLicenses.length > 0 ? expiringLicenses.map(license => (
                                <div key={license.id} className="flex items-center justify-between p-3 bg-yellow-900/20 border border-yellow-600/30 rounded-lg">
                                    <div>
                                        <p className="text-white font-medium">{license.customer_name || license.email}</p>
                                        <p className="text-gray-400 text-sm">{license.email}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-yellow-400 font-medium">
                                            {format(new Date(license.expiry_date), 'MMM d, yyyy')}
                                        </p>
                                        <Badge className={tierColors[license.tier]}>
                                            {license.tier}
                                        </Badge>
                                    </div>
                                </div>
                            )) : (
                                <p className="text-gray-400 text-center py-8">No licenses expiring in the next 30 days</p>
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}