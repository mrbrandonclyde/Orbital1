import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, VideoOff, Mic, MicOff, Phone, PhoneOff, Volume2, VolumeX } from "lucide-react";
import AIAvatar from "./AIAvatar";

export default function VideoChat({ onVideoMessage, isAIResponding, aiResponse, settings }) {
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isCallActive, setIsCallActive] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isListening, setIsListening] = useState(false); // New state for user listening
  // New states for Avatar Features Display, initialized with defaults
  const [currentExpression, setCurrentExpression] = useState("Neutral"); // Placeholder
  const [emotionalState, setEmotionalState] = useState("Calm"); // Placeholder
  // These states reflect the AI's current speaking and active status for display
  const [isSpeakingAI, setIsSpeakingAI] = useState(false); 
  const [isActiveAI, setIsActiveAI] = useState(false); 

  const userVideoRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    // Update AI feature states based on props
    setIsSpeakingAI(isAIResponding);
    setIsActiveAI(isCallActive);

    // Placeholder logic for user's listening state: Assume listening when call is active and AI is not speaking
    if (isCallActive && !isAIResponding) {
      setIsListening(true);
    } else {
      setIsListening(false);
    }
    // Note: In a real application, isListening might be controlled by ASR detection or user input.
  }, [isAIResponding, isCallActive]);


  useEffect(() => {
    return () => {
      // Cleanup video stream on unmount
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startVideoCall = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: isAudioOn 
      });
      
      if (userVideoRef.current) {
        userVideoRef.current.srcObject = stream;
      }
      
      streamRef.current = stream;
      setIsVideoOn(true);
      setIsCallActive(true);
    } catch (error) {
      console.error('Error accessing camera/microphone:', error);
      alert('Unable to access camera/microphone. Please check permissions.');
    }
  };

  const endVideoCall = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    
    if (userVideoRef.current) {
      userVideoRef.current.srcObject = null;
    }
    
    setIsVideoOn(false);
    setIsCallActive(false);
    streamRef.current = null;
  };

  const toggleVideo = async () => {
    // If call is not active and no stream exists, initiate a new call with video
    if (!isCallActive && !streamRef.current) { 
      await startVideoCall();
    } else if (streamRef.current) { // If call is active and stream exists, toggle video track
      const videoTrack = streamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOn(videoTrack.enabled);
      }
    }
  };

  const toggleAudio = () => {
    // Only toggle audio if a media stream is currently active
    if (streamRef.current) { 
      const audioTrack = streamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsAudioOn(audioTrack.enabled);
      }
    }
  };

  const toggleSpeaker = () => {
    setIsSpeakerOn(!isSpeakerOn);
  };

  return (
    <Card className="w-full max-w-6xl mx-auto bg-gradient-to-br from-indigo-50 to-purple-50 border-none shadow-2xl">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          Video Chat with {settings?.ai_name || 'Alex'}
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="grid md:grid-cols-2 gap-6">
          {/* AI Avatar Side - Enhanced Human-like Avatar */}
          <div className="relative">
            <div className="aspect-video bg-gradient-to-br from-purple-100 to-indigo-100 rounded-xl overflow-hidden shadow-lg border-2 border-white/50">
              <AIAvatar 
                isActive={isCallActive}
                isSpeaking={isAIResponding}
                message={aiResponse}
                settings={settings}
                speakerEnabled={isSpeakerOn}
              />
            </div>
            <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              {settings?.ai_name || 'Alex'} (AI Assistant)
            </div>
            
            {/* AI Status Indicators */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              {isAIResponding && (
                <div className="bg-blue-500/90 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                  Thinking...
                </div>
              )}
              {isSpeakerOn && (
                <div className="bg-green-500/90 text-white px-2 py-1 rounded-full text-xs">
                  🔊 Audio On
                </div>
              )}
            </div>
          </div>

          {/* User Video Side - Enhanced */}
          <div className="relative">
            <div className="aspect-video bg-gray-900 rounded-xl overflow-hidden shadow-lg border-2 border-white/50">
              {isVideoOn ? (
                <video
                  ref={userVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform scale-x-[-1] filter brightness-110 contrast-105"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900 text-gray-400">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <VideoOff className="w-10 h-10" />
                    </div>
                    <p className="text-lg font-medium">Camera Off</p>
                    <p className="text-sm opacity-70">Turn on your camera to start video chat</p>
                  </div>
                </div>
              )}
            </div>
            <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isVideoOn ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
              You
            </div>
            
            {/* User Video Status */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              {isListening && (
                <div className="bg-red-500/90 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  Listening...
                </div>
              )}
              {isVideoOn && (
                <div className="bg-green-500/90 text-white px-2 py-1 rounded-full text-xs">
                  📹 Video On
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Enhanced Video Controls */}
        <div className="flex justify-center gap-4 mt-8">
          <Button
            variant={isVideoOn ? "default" : "outline"}
            size="lg"
            onClick={toggleVideo}
            className={`rounded-full w-16 h-16 p-0 ${isVideoOn ? 'bg-green-500 hover:bg-green-600' : ''}`}
          >
            {isVideoOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
          </Button>

          <Button
            variant={isAudioOn ? "default" : "outline"}
            size="lg"
            onClick={toggleAudio}
            className={`rounded-full w-16 h-16 p-0 ${isAudioOn ? 'bg-blue-500 hover:bg-blue-600' : ''}`}
            // Corrected disabled condition to prevent errors when no stream exists
            disabled={!streamRef.current} 
          >
            {isAudioOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
          </Button>

          <Button
            variant={isSpeakerOn ? "default" : "outline"}
            size="lg"
            onClick={toggleSpeaker}
            className={`rounded-full w-16 h-16 p-0 ${isSpeakerOn ? 'bg-purple-500 hover:bg-purple-600' : ''}`}
          >
            {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </Button>

          <Button
            variant={isCallActive ? "destructive" : "default"}
            size="lg"
            onClick={isCallActive ? endVideoCall : startVideoCall}
            className={`rounded-full w-16 h-16 p-0 ${isCallActive ? 'bg-red-500 hover:bg-red-600' : 'bg-indigo-500 hover:bg-indigo-600'}`}
          >
            {isCallActive ? <PhoneOff className="w-6 h-6" /> : <Phone className="w-6 h-6" />}
          </Button>
        </div>

        {/* Connection Quality & Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="text-center">
            <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm ${
              isCallActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                isCallActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'
              }`} />
              {isCallActive ? 'Connected' : 'Disconnected'}
            </div>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-700">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              HD Quality
            </div>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm bg-purple-100 text-purple-700">
              <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
              AI Enhanced
            </div>
          </div>
        </div>

        {/* Avatar Features Display */}
        <div className="mt-6 p-4 bg-white/50 backdrop-blur-sm rounded-xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-xs">
            <div className="space-y-1">
              <div className="font-semibold text-indigo-600">💭 Expression</div>
              <div className="capitalize">{currentExpression}</div>
            </div>
            <div className="space-y-1">
              <div className="font-semibold text-purple-600">🎭 Emotion</div>
              <div className="capitalize">{emotionalState}</div>
            </div>
            <div className="space-y-1">
              <div className="font-semibold text-green-600">🗣️ Speech</div>
              <div>{isSpeakingAI ? 'Active' : 'Silent'}</div>
            </div>
            <div className="space-y-1">
              <div className="font-semibold text-blue-600">👁️ Attention</div>
              <div>{isActiveAI ? 'Focused' : 'Idle'}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}