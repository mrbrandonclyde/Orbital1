
import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion } from "framer-motion";

export default function AIAvatar({ isActive, isSpeaking, message, settings, speakerEnabled }) {
  const [currentExpression, setCurrentExpression] = useState('neutral');
  const [eyePosition, setEyePosition] = useState({ x: 0, y: 0 }); // Not visually used in new design, but state kept
  const [isBlinking, setIsBlinking] = useState(false); // Not visually used in new design, but state kept
  const [lipSyncState, setLipSyncState] = useState('closed'); // Not visually used in new design, but state kept
  const [headTilt, setHeadTilt] = useState(0);
  const [emotionalState, setEmotionalState] = useState('calm');
  const speechRef = useRef(null);

  // Advanced facial expression system (still used for analyzing emotion and setting `currentExpression`/`emotionalState`)
  const expressions = useMemo(() => ({
    neutral: { mouth: 'M 45,55 Q 50,60 55,55', eyebrows: 'M 35,35 Q 40,32 45,35 M 55,35 Q 60,32 65,35' },
    happy: { mouth: 'M 42,52 Q 50,58 58,52', eyebrows: 'M 35,33 Q 40,30 45,33 M 55,33 Q 60,30 65,33' },
    thoughtful: { mouth: 'M 47,55 Q 50,57 53,55', eyebrows: 'M 35,32 Q 40,28 45,32 M 55,32 Q 60,28 65,32' },
    surprised: { mouth: 'M 48,55 Q 50,60 52,55', eyebrows: 'M 35,30 Q 40,25 45,30 M 55,30 Q 60,25 65,30' },
    concerned: { mouth: 'M 45,58 Q 50,55 55,58', eyebrows: 'M 35,35 Q 40,33 45,35 M 55,35 Q 60,33 65,35' },
    excited: { mouth: 'M 40,50 Q 50,62 60,50', eyebrows: 'M 35,32 Q 40,28 45,32 M 55,32 Q 60,28 65,32' }
  }), []);

  // Lip sync patterns for speech animation (not visually used in new design, but state still updates)
  const lipSyncPatterns = useMemo(() => ({
    closed: 'M 45,55 Q 50,55 55,55',
    open_a: 'M 45,53 Q 50,60 55,53',
    open_e: 'M 45,54 Q 50,58 55,54',
    open_i: 'M 46,54 Q 50,57 54,54',
    open_o: 'M 46,52 Q 50,60 54,52',
    open_u: 'M 47,53 Q 50,58 53,53'
  }), []);

  const analyzeMessageEmotion = useCallback((text) => {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('excited') || lowerText.includes('amazing') || lowerText.includes('wonderful')) {
      return 'excited';
    }
    if (lowerText.includes('happy') || lowerText.includes('great') || lowerText.includes('good')) {
      return 'happy';
    }
    if (lowerText.includes('thinking') || lowerText.includes('analyzing') || lowerText.includes('considering')) {
      return 'thoughtful';
    }
    if (lowerText.includes('wow') || lowerText.includes('surprising') || lowerText.includes('unexpected')) {
      return 'surprised';
    }
    if (lowerText.includes('sorry') || lowerText.includes('concerned') || lowerText.includes('unfortunately')) {
      return 'concerned';
    }
    
    return 'neutral';
  }, []);

  const speakMessage = useCallback(async (text) => {
    if ('speechSynthesis' in window && speakerEnabled) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      utterance.volume = 0.8;
      
      // Choose a pleasant female voice if available
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.name.includes('Female') || 
        voice.name.includes('Samantha') || 
        voice.name.includes('Alex') ||
        voice.name.includes('Karen')
      ) || voices[0];
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      speechRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    }
  }, [speakerEnabled]);

  // Natural eye movement simulation (state still updates, but not used visually)
  useEffect(() => {
    const eyeMovementInterval = setInterval(() => {
      if (isActive && !isSpeaking) {
        setEyePosition({
          x: (Math.random() - 0.5) * 4,
          y: (Math.random() - 0.5) * 2
        });
      }
    }, 2000 + Math.random() * 3000);

    return () => clearInterval(eyeMovementInterval);
  }, [isActive, isSpeaking]);

  // Realistic blinking pattern (state still updates, but not used visually)
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      if (isActive) {
        setIsBlinking(true);
        setTimeout(() => setIsBlinking(false), 150);
      }
    }, 3000 + Math.random() * 4000);

    return () => clearInterval(blinkInterval);
  }, [isActive]);

  // Advanced emotion detection from message content
  useEffect(() => {
    if (message) {
      const emotion = analyzeMessageEmotion(message);
      setCurrentExpression(emotion);
      setEmotionalState(emotion);
      
      if (speakerEnabled) {
        speakMessage(message);
      }
    }
  }, [message, speakerEnabled, analyzeMessageEmotion, speakMessage]);

  // Lip sync animation during speech (state still updates, but not used visually)
  useEffect(() => {
    if (isSpeaking && isActive) {
      const lipSyncInterval = setInterval(() => {
        const patterns = Object.keys(lipSyncPatterns);
        const randomPattern = patterns[Math.floor(Math.random() * patterns.length)];
        setLipSyncState(randomPattern);
      }, 100);

      return () => clearInterval(lipSyncInterval);
    } else {
      setLipSyncState('closed');
    }
  }, [isSpeaking, isActive, lipSyncPatterns]);

  // Natural head movement during conversation (used for rotateY animation)
  useEffect(() => {
    if (isSpeaking) {
      const headMovementInterval = setInterval(() => {
        setHeadTilt((Math.random() - 0.5) * 8);
      }, 500);

      return () => clearInterval(headMovementInterval);
    }
  }, [isSpeaking]);

  // currentMouth and currentEyebrows are no longer directly used for rendering the image-based avatar
  // but their states are managed by the emotion analysis.

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900">
      {/* Quantum Data Streams Background */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-px bg-gradient-to-b from-transparent via-cyan-400 to-transparent opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              height: '100%',
            }}
            animate={{
              opacity: [0.1, 0.5, 0.1],
              scaleY: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Zyra Avatar */}
      <div className="relative">
        {/* Holographic Glow Effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-blue-400/20 rounded-full blur-xl"
          animate={{
            scale: isSpeaking ? [1, 1.2, 1] : [1, 1.05, 1],
            opacity: isActive ? [0.5, 0.8, 0.5] : [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: isSpeaking ? 0.5 : 3,
            repeat: Infinity,
          }}
        />

        {/* Main Avatar Image */}
        <motion.div
          className="relative w-48 h-48 rounded-full overflow-hidden border-2 border-cyan-400/50 shadow-2xl"
          animate={{
            scale: isSpeaking ? [1, 1.02, 1] : 1,
            rotateY: headTilt,
          }}
          transition={{ duration: 0.3 }}
        >
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b0face389d336edb6f2245/29917b412_WhatsAppImage2025-09-02at195836_5be6b9e4.jpg"
            alt="Zyra AI Avatar"
            className="w-full h-full object-cover"
          />
          
          {/* Holographic Overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/10 via-transparent to-blue-400/10" />
          
          {/* Circuit Patterns Overlay */}
          <motion.div
            className="absolute inset-0"
            animate={{
              opacity: isSpeaking ? [0.3, 0.6, 0.3] : [0.1, 0.3, 0.1],
            }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <defs>
                <pattern id="circuits" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path
                    d="M 5 5 L 15 5 M 10 0 L 10 10"
                    stroke="rgba(34, 211, 238, 0.3)"
                    strokeWidth="0.5"
                    fill="none"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#circuits)" />
            </svg>
          </motion.div>
        </motion.div>

        {/* Quantum Halo */}
        <motion.div
          className="absolute -inset-4 rounded-full border border-cyan-400/30"
          animate={{
            rotate: 360,
            scale: isActive ? [1, 1.1, 1] : [0.95, 1, 0.95],
          }}
          transition={{
            rotate: { duration: 20, repeat: Infinity, ease: "linear" },
            scale: { duration: 2, repeat: Infinity }
          }}
        />

        {/* Status Indicators */}
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
          <div className="flex items-center gap-2 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
            <motion.div
              className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-400' : 'bg-gray-400'}`}
              animate={isActive ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-xs text-cyan-400 font-medium">ZYRA</span>
            {isSpeaking && (
              <motion.div
                className="w-1 h-3 bg-cyan-400"
                animate={{ scaleY: [0.5, 1, 0.5] }}
                transition={{ duration: 0.3, repeat: Infinity }}
              />
            )}
          </div>
        </div>
      </div>

      {/* AI Vitals Panel */}
      <div className="absolute top-4 right-4 bg-black/40 backdrop-blur-sm rounded-lg p-3 min-w-32">
        <h4 className="text-xs font-bold text-cyan-400 mb-2">AI VITALS</h4>
        <div className="space-y-1 text-xs text-cyan-300">
          <div className="flex justify-between">
            <span>Expression:</span>
            <span className="text-white capitalize">{currentExpression}</span>
          </div>
          <div className="flex justify-between">
            <span>State:</span>
            <span className="text-white capitalize">{emotionalState}</span>
          </div>
          <div className="flex justify-between">
            <span>Status:</span>
            <span className={isActive ? 'text-green-400' : 'text-gray-400'}>
              {isActive ? 'ACTIVE' : 'STANDBY'}
            </span>
          </div>
        </div>
      </div>

      {/* Quantum Energy Particles */}
      {isActive && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(10)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full"
              style={{
                left: `${20 + Math.random() * 60}%`,
                top: `${20 + Math.random() * 60}%`,
              }}
              animate={{
                x: [0, Math.random() * 40 - 20],
                y: [0, Math.random() * 40 - 20],
                opacity: [0, 1, 0],
                scale: [0, 1, 0],
              }}
              transition={{
                duration: 2 + Math.random(),
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      )}

      {/* Speech Analysis Visualization */}
      {isSpeaking && message && (
        <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-sm rounded-lg p-3 max-w-xs">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-xs font-bold text-cyan-400">QUANTUM ANALYSIS</span>
          </div>
          <p className="text-xs text-cyan-300 line-clamp-3">{message}</p>
        </div>
      )}
    </div>
  );
}
