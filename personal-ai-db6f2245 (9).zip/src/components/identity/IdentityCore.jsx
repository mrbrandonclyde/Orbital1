import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Shield, Eye, Fingerprint, Mic, User, 
  Building, Brain, DollarSign, Settings,
  CheckCircle, AlertTriangle, Lock
} from 'lucide-react';

export const TrustScoreIndicator = ({ trustScore = 87, riskLevel = "low" }) => {
  const getRiskColor = (level) => {
    const colors = {
      minimal: 'text-green-400 bg-green-500/20',
      low: 'text-green-400 bg-green-500/20', 
      moderate: 'text-yellow-400 bg-yellow-500/20',
      high: 'text-orange-400 bg-orange-500/20',
      critical: 'text-red-400 bg-red-500/20'
    };
    return colors[level] || colors.low;
  };

  return (
    <Card className="bg-slate-800/70 border-slate-700/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Shield className="w-5 h-5 text-green-400" />
          Trust Score & Security
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-slate-300">Current Trust Score</span>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-white">{trustScore}</span>
            <span className="text-slate-400">/100</span>
          </div>
        </div>
        <Progress value={trustScore} className="h-3 [&>div]:bg-green-400" />
        <div className="flex justify-between items-center">
          <span className="text-slate-400">Risk Level</span>
          <Badge className={getRiskColor(riskLevel)}>{riskLevel.toUpperCase()}</Badge>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-slate-300">Device Recognized</span>
          </div>
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-blue-400" />
            <span className="text-slate-300">MFA Active</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const ModeSelector = ({ activeMode = 'business', onModeChange }) => {
  const modes = [
    { id: 'business', name: 'Business', icon: Building, color: 'bg-blue-500/20 text-blue-300' },
    { id: 'creative', name: 'Creative', icon: Brain, color: 'bg-purple-500/20 text-purple-300' },
    { id: 'developer', name: 'Developer', icon: Settings, color: 'bg-green-500/20 text-green-300' },
    { id: 'investor', name: 'Investor', icon: DollarSign, color: 'bg-yellow-500/20 text-yellow-300' }
  ];

  return (
    <Card className="bg-slate-800/70 border-slate-700/50">
      <CardHeader>
        <CardTitle className="text-white">Active Mode</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {modes.map(mode => {
            const Icon = mode.icon;
            return (
              <Button
                key={mode.id}
                variant={activeMode === mode.id ? 'default' : 'outline'}
                onClick={() => onModeChange?.(mode.id)}
                className={`flex items-center gap-2 h-12 ${
                  activeMode === mode.id ? mode.color : 'border-slate-600 text-slate-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                {mode.name}
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export const BiometricStatus = ({ biometrics = {} }) => {
  const biometricTypes = [
    { key: 'voiceprint_id', name: 'Voiceprint', icon: Mic, status: !!biometrics?.voiceprint_id },
    { key: 'facial_id', name: 'Facial Recognition', icon: Eye, status: !!biometrics?.facial_id },
    { key: 'gesture_patterns', name: 'Gesture Patterns', icon: Fingerprint, status: !!biometrics?.gesture_patterns?.length }
  ];

  return (
    <Card className="bg-slate-800/70 border-slate-700/50">
      <CardHeader>
        <CardTitle className="text-white">Biometric Authentication</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {biometricTypes.map(type => {
          const Icon = type.icon;
          return (
            <div key={type.key} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Icon className="w-5 h-5 text-slate-400" />
                <span className="text-slate-300">{type.name}</span>
              </div>
              <Badge className={type.status ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-400'}>
                {type.status ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          );
        })}
        <Button className="w-full bg-blue-600 hover:bg-blue-700">
          Configure Biometrics
        </Button>
      </CardContent>
    </Card>
  );
};

export const PersonalityProfile = ({ personality = {} }) => {
  const traits = [
    { key: 'tone', label: 'Communication Tone', value: personality?.tone || 'formal' },
    { key: 'decision_style', label: 'Decision Style', value: personality?.decision_style || 'balanced' },
    { key: 'risk_tolerance', label: 'Risk Tolerance', value: personality?.risk_tolerance || 'moderate' },
    { key: 'communication_style', label: 'Communication Style', value: personality?.communication_style || 'direct' }
  ];

  return (
    <Card className="bg-slate-800/70 border-slate-700/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <User className="w-5 h-5 text-blue-400" />
          Personality Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {traits.map(trait => (
          <div key={trait.key} className="flex justify-between items-center">
            <span className="text-slate-300">{trait.label}</span>
            <Badge variant="secondary" className="capitalize bg-slate-700 text-slate-200">
              {trait.value}
            </Badge>
          </div>
        ))}
        <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">
          Customize Personality
        </Button>
      </CardContent>
    </Card>
  );
};