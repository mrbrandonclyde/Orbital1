import React, { useState } from "react";
import HeaderBar from "@/components/HeaderBar";
import TemporalConsole from "@/components/TemporalConsole";
import TimelineBar from "@/components/TimelineBar";
import ChatPanel from "@/components/ChatPanel";
import VoiceControls from "@/components/VoiceControls";
import KeyboardControls from "@/components/KeyboardControls";
import { motion, AnimatePresence } from "framer-motion";

export default function TemporalLayout({ children }) {
  const [showChatPanel, setShowChatPanel] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);

  const handleVoiceCommand = (command) => {
    console.log("🔮 Processing voice command:", command);
    // Voice commands will be handled by the timeline system
    
    // Add to chat if panel is open
    if (showChatPanel && window.addChatMessage) {
      window.addChatMessage(`🎙 Voice: ${command}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-[#0A0A0F] via-[#1a1a2e] to-[#16213e] text-white overflow-hidden">
      {/* Top Header */}
      <HeaderBar 
        isVoiceActive={isVoiceActive}
        onToggleChat={() => setShowChatPanel(!showChatPanel)}
        showChatPanel={showChatPanel}
      />

      {/* Main Content with Right Sidebar */}
      <div className="flex flex-1 overflow-hidden">
        {/* Center Stage (Main Frame) */}
        <main className="flex-1 flex items-center justify-center relative">
          <div className="relative w-full h-full flex items-center justify-center p-4">
            {children}
          </div>

          {/* Chat Overlay (Slide-in from Right) */}
          <AnimatePresence>
            {showChatPanel && (
              <motion.div
                initial={{ x: "100%", opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: "100%", opacity: 0 }}
                transition={{ type: "spring", damping: 20, stiffness: 300 }}
                className="absolute top-0 right-0 h-full w-80 bg-black/90 border-l border-cyan/30 backdrop-blur-xl shadow-2xl z-50"
              >
                <ChatPanel 
                  onCommand={handleVoiceCommand}
                  onClose={() => setShowChatPanel(false)}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Right Sidebar Console */}
        <TemporalConsole />
      </div>

      {/* Footer Timeline */}
      <footer className="border-t border-cyan/20 bg-black/80 backdrop-blur-md">
        <TimelineBar />
      </footer>

      {/* Global Input Handlers */}
      <KeyboardControls />
      <VoiceControls 
        onCommand={handleVoiceCommand}
        onVoiceStateChange={setIsVoiceActive}
      />
    </div>
  );
}