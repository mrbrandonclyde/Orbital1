import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Brain } from 'lucide-react';

export default function NeuroinformaticsLab() {
    return (
        <Card className="superman-card border-purple/30">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl text-purple"><Brain className="w-6 h-6" />Neuroinformatics Lab</CardTitle>
                <CardDescription className="text-slate-400">Analyze neural data, simulate brain activity, and explore cognitive models.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-slate-400">This lab module is under development. Coming soon: EEG/fMRI data analysis, spiking neural network simulations, and more.</p>
            </CardContent>
        </Card>
    );
}