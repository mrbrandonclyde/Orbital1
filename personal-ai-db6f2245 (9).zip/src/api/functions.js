import { base44 } from './base44Client';


export const getFinancialData = base44.functions.getFinancialData;

export const timelineSocketServer = base44.functions.timelineSocketServer;

export const getNasaFireData = base44.functions.getNasaFireData;

