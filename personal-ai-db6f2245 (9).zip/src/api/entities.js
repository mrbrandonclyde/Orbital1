import { base44 } from './base44Client';


export const Template = base44.entities.Template;

export const Document = base44.entities.Document;

export const AIModel = base44.entities.AIModel;

export const ScientificProject = base44.entities.ScientificProject;

export const ComputationJob = base44.entities.ComputationJob;

export const UserSettings = base44.entities.UserSettings;

export const Conversation = base44.entities.Conversation;

export const Message = base44.entities.Message;

export const SavedSection = base44.entities.SavedSection;

export const ZyraMemory = base44.entities.ZyraMemory;

export const ZyraTask = base44.entities.ZyraTask;

export const ZyraIntegration = base44.entities.ZyraIntegration;

export const License = base44.entities.License;

export const AuditLog = base44.entities.AuditLog;

export const Payment = base44.entities.Payment;

export const AppConfig = base44.entities.AppConfig;

export const BusinessIdea = base44.entities.BusinessIdea;

export const DocumentTemplate = base44.entities.DocumentTemplate;

export const GeneratedDocument = base44.entities.GeneratedDocument;

export const FeedbackLog = base44.entities.FeedbackLog;

export const PromptEvolution = base44.entities.PromptEvolution;

export const SystemCore = base44.entities.SystemCore;

export const EpisodicMemory = base44.entities.EpisodicMemory;

export const SemanticMemory = base44.entities.SemanticMemory;

export const ProceduralMemory = base44.entities.ProceduralMemory;

export const ZyraUser = base44.entities.ZyraUser;

export const TrustSession = base44.entities.TrustSession;

export const BiometricProfile = base44.entities.BiometricProfile;

export const SystemState = base44.entities.SystemState;

export const ZyraContext = base44.entities.ZyraContext;

export const OpenAIKey = base44.entities.OpenAIKey;

export const BusinessLocation = base44.entities.BusinessLocation;



// auth sdk:
export const User = base44.auth;