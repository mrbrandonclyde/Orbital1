import React, { useState } from 'react';
import { Settings, Copy, Check, Server, Database, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function ConfigurationGuide() {
  const [copiedSection, setCopiedSection] = useState(null);

  const copyToClipboard = (text, section) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const packageJsonContent = `{
  "name": "global-command-center",
  "version": "1.0.0",
  "description": "Global Intelligence Platform",
  "scripts": {
    "dev": "npm run dev:frontend && npm run dev:backend",
    "build": "npm run build:frontend && npm run build:backend",
    "test": "npm run test:backend && npm run test:frontend",
    "lint": "eslint . --ext .ts,.tsx,.js,.jsx",
    "type-check": "tsc --noEmit"
  },
  "dependencies": {
    "react": "^18.0.0",
    "typescript": "^5.0.0",
    "tailwindcss": "^3.0.0"
  }
}`;

  const envExampleContent = `# Database Configuration
DATABASE_URL="postgresql://username:password@localhost:5432/global_command_center"

# Authentication & Security  
JWT_SECRET="your-super-secure-jwt-secret-key"
BASE44_API_KEY="your-base44-api-key"

# External API Keys
OPENAI_API_KEY="your-openai-api-key" 
STRIPE_SECRET_KEY="your-stripe-secret-key"

# Data Sources
FORTUNE_500_API_KEY="your-fortune-500-api-key"
FINANCIAL_DATA_API_KEY="your-financial-data-api-key"

# Infrastructure
NODE_ENV="development"
PORT="3001"
CORS_ORIGIN="http://localhost:3000"`;

  const ciConfigContent = `name: Global Command Center CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm ci
      - run: npm run lint
      - run: npm run test
      - run: npm run build`;

  const dockerConfigContent = `# Frontend Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]

# Backend Dockerfile  
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3001
CMD ["npm", "run", "start:prod"]`;

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Settings className="w-6 h-6 text-indigo-400" />
        <h2 className="text-2xl font-bold text-white">System Configuration</h2>
      </div>

      <Tabs defaultValue="package" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="package">Package.json</TabsTrigger>
          <TabsTrigger value="env">Environment</TabsTrigger>
          <TabsTrigger value="ci">CI/CD</TabsTrigger>
          <TabsTrigger value="docker">Docker</TabsTrigger>
        </TabsList>

        <TabsContent value="package" className="space-y-4">
          <Card className="bg-[#0A0D18]/50 border-[#151823]">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Server className="w-5 h-5 text-blue-400" />
                  <span>Package Configuration</span>
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(packageJsonContent, 'package')}
                >
                  {copiedSection === 'package' ? <Check size={16} /> : <Copy size={16} />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-900/50 p-4 rounded-lg text-sm overflow-x-auto">
                <code>{packageJsonContent}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="env" className="space-y-4">
          <Card className="bg-[#0A0D18]/50 border-[#151823]">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-green-400" />
                  <span>Environment Variables</span>
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(envExampleContent, 'env')}
                >
                  {copiedSection === 'env' ? <Check size={16} /> : <Copy size={16} />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-900/50 p-4 rounded-lg text-sm overflow-x-auto">
                <code>{envExampleContent}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ci" className="space-y-4">
          <Card className="bg-[#0A0D18]/50 border-[#151823]">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-purple-400" />
                  <span>CI/CD Pipeline</span>
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(ciConfigContent, 'ci')}
                >
                  {copiedSection === 'ci' ? <Check size={16} /> : <Copy size={16} />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-900/50 p-4 rounded-lg text-sm overflow-x-auto">
                <code>{ciConfigContent}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docker" className="space-y-4">
          <Card className="bg-[#0A0D18]/50 border-[#151823]">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Database className="w-5 h-5 text-orange-400" />
                  <span>Docker Configuration</span>
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(dockerConfigContent, 'docker')}
                >
                  {copiedSection === 'docker' ? <Check size={16} /> : <Copy size={16} />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-900/50 p-4 rounded-lg text-sm overflow-x-auto">
                <code>{dockerConfigContent}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}