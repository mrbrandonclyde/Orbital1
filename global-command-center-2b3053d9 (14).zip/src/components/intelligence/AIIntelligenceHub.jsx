
import React, { useState } from 'react';
import ExecutiveBriefPanel from './ExecutiveBriefPanel';
import GlobalImpactQuery from './GlobalImpactQuery'; // Import the new component
import { Brain, Globe, Shield, Factory, Zap, Truck, Building2, Heart } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SECTORS = [
  { id: 'global', name: 'Global Overview', icon: Globe },
  { id: 'defense', name: 'Defense & Security', icon: Shield },
  { id: 'finance', name: 'Financial Markets', icon: Building2 },
  { id: 'energy', name: 'Energy Infrastructure', icon: Zap },
  { id: 'healthcare', name: 'Healthcare Systems', icon: Heart },
  { id: 'supply_chain', name: 'Supply Chains', icon: Truck },
  { id: 'manufacturing', name: 'Manufacturing', icon: Factory }
];

const REGIONS = [
  { id: 'global', name: 'Global' },
  { id: 'north_america', name: 'North America' },
  { id: 'europe', name: 'Europe' },
  { id: 'asia_pacific', name: 'Asia Pacific' },
  { id: 'middle_east', name: 'Middle East' },
  { id: 'africa', name: 'Africa' },
  { id: 'south_america', name: 'South America' }
];

export default function AIIntelligenceHub({ 
  data = {}, 
  className = "" 
}) {
  const [selectedSector, setSelectedSector] = useState('global');
  const [selectedRegion, setSelectedRegion] = useState('global');
  const [timeframe, setTimeframe] = useState('24h');

  // Filter and prepare data based on selections
  const getContextualData = () => {
    // This would normally filter the data based on sector/region
    // For now, we'll use sample contextual data
    const contextualData = {
      global: {
        alerts: data.alerts || [],
        metrics: data.metrics || [],
        missions: data.missions || [],
        sectors_monitored: 8,
        active_threats: 12,
        global_stability_index: 0.76
      },
      defense: {
        threat_level: 'MODERATE',
        active_missions: 15,
        personnel_deployed: 45000,
        budget_utilization: 0.82,
        recent_incidents: 3
      },
      finance: {
        market_volatility: 'HIGH',
        currency_fluctuations: 0.034,
        trading_volume: '$2.3T',
        risk_indicators: 7,
        sector_health: 'STABLE'
      }
    };

    return contextualData[selectedSector] || contextualData.global;
  };

  const currentSector = SECTORS.find(s => s.id === selectedSector);
  const IconComponent = currentSector?.icon || Globe;

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Control Panel */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Brain className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-semibold text-white">AI Intelligence Analysis</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Sector Focus</label>
            <Select value={selectedSector} onValueChange={setSelectedSector}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SECTORS.map(sector => (
                  <SelectItem key={sector.id} value={sector.id}>
                    <div className="flex items-center space-x-2">
                      <sector.icon className="w-4 h-4" />
                      <span>{sector.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-gray-400 mb-2 block">Geographic Region</label>
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {REGIONS.map(region => (
                  <SelectItem key={region.id} value={region.id}>
                    {region.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-gray-400 mb-2 block">Time Period</label>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">Last Hour</SelectItem>
                <SelectItem value="24h">Last 24 Hours</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <div className="flex items-center space-x-2 text-sm">
              <IconComponent className="w-4 h-4 text-indigo-400" />
              <span className="text-gray-400">
                {currentSector?.name} • {REGIONS.find(r => r.id === selectedRegion)?.name}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Executive Brief */}
      <ExecutiveBriefPanel
        data={getContextualData()}
        context={{
          sector: selectedSector,
          region: selectedRegion,
          timeframe: timeframe,
          classification: selectedSector === 'defense' ? 'SECRET' : 'CONFIDENTIAL'
        }}
        autoRefresh={true}
      />
      
      {/* Global Impact Query Engine */}
      <GlobalImpactQuery />
    </div>
  );
}
