import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle, Search, BookOpen, MessageSquare } from 'lucide-react';

const faqs = [
  {
    question: "What is the Global Command Chain (GCC)?",
    answer: "The Global Command Chain is a proprietary, high-performance blockchain designed for secure, large-scale enterprise and governmental operations. It prioritizes speed, security, and scalability.",
  },
  {
    question: "How do I create a new wallet?",
    answer: "Navigate to the 'Wallet' section from the sidebar, then click the 'Create New Wallet' button. Follow the on-screen instructions and make sure to securely back up your recovery phrase.",
  },
  {
    question: "What are the transaction fees?",
    answer: "Transaction fees (gas) are minimal and used to reward validators for securing the network. Fees are calculated based on network congestion and transaction complexity.",
  },
  {
    question: "How can I participate in governance?",
    answer: "To participate in governance, you must stake GCC tokens. Once staked, you can create new proposals and vote on existing ones in the 'Governance' section.",
  },
];

export default function HelpView() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white">Help & Support</h1>
      
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <Input 
          placeholder="Search for help topics..." 
          className="pl-10 h-11 bg-[#0C0F19] border-gray-600"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center"><HelpCircle className="mr-2 text-cyan-400"/> Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {filteredFaqs.map((faq, index) => (
              <AccordionItem value={`item-${index}`} key={index}>
                <AccordionTrigger className="text-white hover:no-underline">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-gray-300">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
      
       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-pane">
                <CardHeader>
                    <CardTitle className="flex items-center"><BookOpen className="mr-2 text-purple-400"/> Documentation</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-400 mb-4">Access in-depth technical documentation, API references, and developer guides.</p>
                    <button className="orbital-button-secondary w-full">Go to Docs</button>
                </CardContent>
            </Card>
            <Card className="glass-pane">
                <CardHeader>
                    <CardTitle className="flex items-center"><MessageSquare className="mr-2 text-green-400"/> Contact Support</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-400 mb-4">For critical issues or inquiries not covered here, open a secure support ticket.</p>
                    <button className="orbital-button-secondary w-full">Open Ticket</button>
                </CardContent>
            </Card>
       </div>
    </div>
  );
}