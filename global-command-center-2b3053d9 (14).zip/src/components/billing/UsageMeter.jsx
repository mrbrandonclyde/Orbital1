import React from 'react';
import { BarChart, Database, Zap } from 'lucide-react';

const getIcon = (type) => {
  switch (type) {
    case 'api': return BarChart;
    case 'storage': return Database;
    default: return Zap;
  }
};

const getColor = (percentage) => {
  if (percentage >= 90) return 'bg-red-500';
  if (percentage >= 75) return 'bg-yellow-500';
  return 'bg-green-500';
};

export default function UsageMeter({ title, used, limit, type = 'default' }) {
  const Icon = getIcon(type);
  const percentage = limit === -1 ? 0 : Math.min((used / limit) * 100, 100);
  const isUnlimited = limit === -1;
  
  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon className="w-4 h-4 text-indigo-400" />
          <span className="text-sm font-medium text-white">{title}</span>
        </div>
        <span className="text-xs text-gray-400">
          {isUnlimited ? 'Unlimited' : `${used}/${limit}`}
        </span>
      </div>
      
      {!isUnlimited && (
        <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
          <div 
            className={`h-2 rounded-full transition-all duration-300 ${getColor(percentage)}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      )}
      
      <div className="flex justify-between text-xs">
        <span className="text-gray-400">
          {isUnlimited ? 'No limits' : `${percentage.toFixed(1)}% used`}
        </span>
        {percentage >= 90 && !isUnlimited && (
          <span className="text-red-400 font-semibold">Near limit</span>
        )}
      </div>
    </div>
  );
}