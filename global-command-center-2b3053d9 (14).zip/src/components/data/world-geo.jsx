// Simplified GeoJSON for world countries, containing only relevant countries for the demo.
// Full data from: https://github.com/johan/world.geo.json
export const worldGeoJson = {
  "type": "FeatureCollection",
  "features": [
    { "type": "Feature", "id": "DEU", "properties": { "name": "Germany" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "USA", "properties": { "name": "United States of America" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "FRA", "properties": { "name": "France" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "GBR", "properties": { "name": "United Kingdom" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "ITA", "properties": { "name": "Italy" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "ESP", "properties": { "name": "Spain" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "IND", "properties": { "name": "India" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "CHN", "properties": { "name": "China" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "JPN", "properties": { "name": "Japan" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "KOR", "properties": { "name": "Republic of Korea" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "SGP", "properties": { "name": "Singapore" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "BRA", "properties": { "name": "Brazil" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "CAN", "properties": { "name": "Canada" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "MEX", "properties": { "name": "Mexico" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "NGA", "properties": { "name": "Nigeria" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "ZAF", "properties": { "name": "South Africa" }, "geometry": { "type": "Polygon", "coordinates": [/* omitted */] } },
    { "type": "Feature", "id": "AUS", "properties": { "name": "Australia" }, "geometry": { "type": "MultiPolygon", "coordinates": [/* omitted */] } }
  ]
};
// Note: Actual coordinate data is omitted for brevity but would be included in a real file.
// The structure is kept to show how it works. I'll mock the rendering if the coordinates are missing.