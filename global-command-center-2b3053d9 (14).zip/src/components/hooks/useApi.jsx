import { useState, useEffect, useCallback, useRef } from 'react';
import apiService from '../lib/ApiService';

/**
 * Enhanced API hook with loading states, error handling, and caching
 */
export const useApi = (endpoint, options = {}) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastFetch, setLastFetch] = useState(null);
  
  const {
    immediate = true,
    refreshInterval = null,
    dependencies = [],
    transform = null,
    onSuccess = null,
    onError = null
  } = options;

  const isMountedRef = useRef(true);
  const intervalRef = useRef(null);
  const optionsRef = useRef(options);

  // Keep options ref current
  useEffect(() => {
    optionsRef.current = options;
  });

  const fetchData = useCallback(async (force = false) => {
    if (!endpoint) return;

    try {
      setLoading(true);
      setError(null);

      const result = await apiService.get(endpoint, { skipCache: force });
      
      if (!isMountedRef.current) return;

      const currentOptions = optionsRef.current;
      const finalData = currentOptions.transform ? currentOptions.transform(result.data) : result.data;
      setData(finalData);
      setLastFetch(new Date());
      
      if (currentOptions.onSuccess) {
        currentOptions.onSuccess(finalData);
      }
    } catch (err) {
      if (!isMountedRef.current) return;
      
      console.error('API Hook Error:', err);
      setError(err);
      
      if (optionsRef.current.onError) {
        optionsRef.current.onError(err);
      }
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [endpoint]);

  const refetch = useCallback(() => {
    return fetchData(true);
  }, [fetchData]);

  // Initial fetch with proper dependencies
  useEffect(() => {
    if (immediate) {
      fetchData();
    }
  }, [immediate, fetchData, ...dependencies]);

  // Set up refresh interval
  useEffect(() => {
    if (refreshInterval && refreshInterval > 0) {
      intervalRef.current = setInterval(() => {
        fetchData();
      }, refreshInterval);

      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    }
  }, [refreshInterval, fetchData]);

  // Cleanup
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    data,
    loading,
    error,
    refetch,
    lastFetch,
    isStale: lastFetch && Date.now() - lastFetch.getTime() > 5 * 60 * 1000 // 5 minutes
  };
};

/**
 * API mutation hook for POST/PUT/DELETE operations
 */
export const useApiMutation = (options = {}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  
  const optionsRef = useRef(options);

  // Keep options ref current
  useEffect(() => {
    optionsRef.current = options;
  });

  const mutate = useCallback(async (method, endpoint, payload = null) => {
    try {
      setLoading(true);
      setError(null);

      let result;
      switch (method.toUpperCase()) {
        case 'POST':
          result = await apiService.post(endpoint, payload);
          break;
        case 'PUT':
          result = await apiService.put(endpoint, payload);
          break;
        case 'DELETE':
          result = await apiService.delete(endpoint);
          break;
        default:
          throw new Error(`Unsupported method: ${method}`);
      }

      setData(result);

      if (optionsRef.current.onSuccess) {
        optionsRef.current.onSuccess(result);
      }

      return result;
    } catch (err) {
      console.error('API Mutation Error:', err);
      setError(err);

      if (optionsRef.current.onError) {
        optionsRef.current.onError(err);
      }

      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setLoading(false);
  }, []);

  return {
    mutate,
    loading,
    error,
    data,
    reset
  };
};

/**
 * Real-time API hook with WebSocket-like functionality
 */
export const useRealtimeApi = (endpoint, options = {}) => {
  const [data, setData] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [error, setError] = useState(null);

  const {
    updateInterval = 30000, // 30 seconds default
    onUpdate = null,
    autoConnect = true
  } = options;

  const intervalRef = useRef(null);
  const isMountedRef = useRef(true);
  const optionsRef = useRef(options);

  // Keep options ref current
  useEffect(() => {
    optionsRef.current = options;
  });

  const connect = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    setConnectionStatus('connecting');

    intervalRef.current = setInterval(async () => {
      try {
        const result = await apiService.get(endpoint, { skipCache: true });
        
        if (!isMountedRef.current) return;

        setData(result.data);
        setConnectionStatus('connected');
        setError(null);

        if (optionsRef.current.onUpdate) {
          optionsRef.current.onUpdate(result.data);
        }
      } catch (err) {
        if (!isMountedRef.current) return;
        
        console.error('Realtime API Error:', err);
        setError(err);
        setConnectionStatus('error');
      }
    }, updateInterval);

    // Initial fetch
    apiService.get(endpoint, { skipCache: true })
      .then(result => {
        if (isMountedRef.current) {
          setData(result.data);
          setConnectionStatus('connected');
        }
      })
      .catch(err => {
        if (isMountedRef.current) {
          setError(err);
          setConnectionStatus('error');
        }
      });
  }, [endpoint, updateInterval]);

  const disconnect = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setConnectionStatus('disconnected');
  }, []);

  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      isMountedRef.current = false;
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  return {
    data,
    connectionStatus,
    error,
    connect,
    disconnect,
    isConnected: connectionStatus === 'connected'
  };
};