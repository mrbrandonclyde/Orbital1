import React, { useState, useCallback } from 'react';
import { DataSource } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { useQuery } from '../lib/useQuery';
import { Database, RefreshCw, Plus, Globe, BarChart, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function DataSourceManager() {
  const [showAddSource, setShowAddSource] = useState(false);
  
  const queryFn = useCallback(async () => {
    return await DataSource.list('-last_sync_time', 50);
  }, []);

  const { data: sources, loading, refetch } = useQuery(queryFn);

  // Initialize data sources for Global Command Center
  const initializeDataSources = async () => {
    const defaultSources = [
      {
        source_name: 'Fortune 1000 API',
        source_type: 'COMPANY_DATA',
        status: 'ACTIVE',
        sync_frequency: 'Daily',
        data_points: 1000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'Global 500 Feed',
        source_type: 'COMPANY_DATA',
        status: 'ACTIVE',
        sync_frequency: 'Daily',
        data_points: 500,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'NASA Satellite Imagery',
        source_type: 'GEOPOLITICAL_EVENTS',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 150000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'Planet Labs Earth Data',
        source_type: 'GEOPOLITICAL_EVENTS',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 89000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'Bloomberg Financial Feed',
        source_type: 'FINANCIAL_MARKETS',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 250000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'Supply Chain Risk Monitor',
        source_type: 'SUPPLY_CHAIN',
        status: 'ACTIVE',
        sync_frequency: 'Hourly',
        data_points: 12000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'OSINT Threat Intelligence',
        source_type: 'THREAT_INTELLIGENCE',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 500000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'AIS Maritime Tracking',
        source_type: 'GEOPOLITICAL_EVENTS',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 75000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'ADS-B Aircraft Monitoring',
        source_type: 'GEOPOLITICAL_EVENTS',
        status: 'ACTIVE',
        sync_frequency: 'Real-time',
        data_points: 45000,
        last_sync_time: new Date().toISOString()
      },
      {
        source_name: 'SEC EDGAR Filings',
        source_type: 'FINANCIAL_MARKETS',
        status: 'ACTIVE',
        sync_frequency: 'Daily',
        data_points: 8000,
        last_sync_time: new Date().toISOString()
      }
    ];

    for (const source of defaultSources) {
      try {
        await DataSource.create(source);
      } catch (error) {
        console.log(`Data source ${source.source_name} may already exist, skipping...`);
      }
    }
    
    refetch();
  };

  const syncDataSource = async (sourceId) => {
    try {
      // Update sync time
      await DataSource.update(sourceId, {
        last_sync_time: new Date().toISOString(),
        status: 'SYNCING'
      });
      
      // Simulate sync delay
      setTimeout(async () => {
        await DataSource.update(sourceId, {
          status: 'ACTIVE',
          data_points: Math.floor(Math.random() * 100000) + 50000
        });
        refetch();
      }, 2000);
      
      refetch();
    } catch (error) {
      console.error('Sync failed:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return 'text-green-400 bg-green-500/10 border-green-500/30';
      case 'SYNCING': return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
      case 'DEGRADED': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30';
      case 'OFFLINE': return 'text-red-400 bg-red-500/10 border-red-500/30';
      default: return 'text-gray-400 bg-gray-500/10 border-gray-500/30';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'COMPANY_DATA': return <BarChart className="w-4 h-4" />;
      case 'GEOPOLITICAL_EVENTS': return <Globe className="w-4 h-4" />;
      case 'SUPPLY_CHAIN': return <Database className="w-4 h-4" />;
      case 'FINANCIAL_MARKETS': return <BarChart className="w-4 h-4" />;
      case 'THREAT_INTELLIGENCE': return <Shield className="w-4 h-4" />;
      default: return <Database className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Database className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-semibold text-white">Data Source Manager</h2>
          <div className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
            {sources?.length || 0} SOURCES
          </div>
        </div>
        <div className="flex space-x-2">
          <Button onClick={initializeDataSources} variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Initialize Sources
          </Button>
          <Button onClick={refetch} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-4 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {sources?.map(source => (
            <div key={source.id} className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {getTypeIcon(source.source_type)}
                  <div>
                    <h3 className="font-medium text-white">{source.source_name}</h3>
                    <p className="text-xs text-gray-400">{source.source_type.replace('_', ' ')}</p>
                  </div>
                </div>
                <Button
                  onClick={() => syncDataSource(source.id)}
                  variant="ghost"
                  size="sm"
                  disabled={source.status === 'SYNCING'}
                >
                  <RefreshCw className={`w-4 h-4 ${source.status === 'SYNCING' ? 'animate-spin' : ''}`} />
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <div className={`px-2 py-1 rounded text-xs border ${getStatusColor(source.status)}`}>
                  {source.status}
                </div>
                <div className="text-sm text-gray-400">
                  {source.data_points?.toLocaleString()} points
                </div>
              </div>
              
              <div className="mt-2 text-xs text-gray-500">
                <span>Sync: {source.sync_frequency}</span>
                {source.last_sync_time && (
                  <>
                    <span className="mx-2">•</span>
                    <span>Last: {new Date(source.last_sync_time).toLocaleString()}</span>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}