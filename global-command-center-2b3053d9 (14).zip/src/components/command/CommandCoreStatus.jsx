import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Shield, Zap, Activity } from 'lucide-react';

export default function CommandCoreStatus({ alerts, sectors }) {
  const activeAlerts = alerts?.length || 0;
  const threatLevel = activeAlerts > 5 ? 'ELEVATED' : activeAlerts > 0 ? 'GUARDED' : 'NOMINAL';
  const threatColor = threatLevel === 'ELEVATED' ? 'text-red-400' : threatLevel === 'GUARDED' ? 'text-yellow-400' : 'text-green-400';

  const operationalSectors = sectors?.filter(s => s.is_active).length || 0;
  const totalSectors = sectors?.length || 0;
  const systemStatus = operationalSectors === totalSectors ? 'ALL SYSTEMS NOMINAL' : 'DEGRADED OPERATIONS';
  const systemColor = systemStatus === 'ALL SYSTEMS NOMINAL' ? 'text-green-400' : 'text-orange-400';

  return (
    <div className="glass-pane p-8 flex flex-col items-center justify-center h-full">
      <motion.div
        animate={{ scale: [1, 1.05, 1], rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        className="relative w-48 h-48 md:w-64 md:h-64 flex items-center justify-center"
      >
        <motion.div 
          className="absolute w-full h-full border-2 border-cyan-500/30 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        />
        <motion.div 
          className="absolute w-3/4 h-3/4 border-2 border-purple-500/40 rounded-full"
          animate={{ rotate: -360 }}
          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        />
        <motion.div
          className="absolute w-1/2 h-1/2 bg-purple-500/20 rounded-full glow-effect-purple"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
        <Globe className="w-24 h-24 text-cyan-300 z-10" />
      </motion.div>
      
      <div className="text-center mt-8">
        <h2 className="text-3xl font-bold orbital-gradient-text">COMMAND CORE</h2>
        <p className="text-gray-400">Global Operational Status</p>
      </div>

      <div className="mt-8 w-full space-y-4 text-lg">
        <div className="flex justify-between items-center">
          <span className="flex items-center text-gray-300"><Shield className="w-5 h-5 mr-3 text-blue-400"/> THREATCON</span>
          <span className={`font-bold ${threatColor}`}>{threatLevel}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="flex items-center text-gray-300"><Activity className="w-5 h-5 mr-3 text-blue-400"/> SYSTEM STATUS</span>
          <span className={`font-bold ${systemColor}`}>{systemStatus}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="flex items-center text-gray-300"><Zap className="w-5 h-5 mr-3 text-blue-400"/> SENTINEL AI</span>
          <span className="font-bold text-green-400">ONLINE</span>
        </div>
      </div>
    </div>
  );
}