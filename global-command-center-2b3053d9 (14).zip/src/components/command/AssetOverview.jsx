import React from 'react';
import { DollarSign, TrendingUp, Building2 } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer, Tooltip } from 'recharts';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AssetOverview({ assets }) {
  const totalValue = assets?.reduce((sum, asset) => sum + asset.current_value_usd, 0) || 0;

  const chartData = [
    { name: 'T-6', value: totalValue * 0.95 },
    { name: 'T-5', value: totalValue * 0.96 },
    { name: 'T-4', value: totalValue * 0.95 },
    { name: 'T-3', value: totalValue * 0.98 },
    { name: 'T-2', value: totalValue * 0.97 },
    { name: 'T-1', value: totalValue * 0.99 },
    { name: 'Now', value: totalValue },
  ];

  return (
    <div className="glass-pane p-6 h-full flex flex-col">
      <h3 className="text-xl font-semibold text-white mb-2">Strategic Asset Portfolio</h3>
      <div className="flex items-baseline space-x-2">
        <p className="text-4xl font-bold text-green-400">
          ${(totalValue / 1e9).toFixed(2)}B
        </p>
        <div className="flex items-center text-green-400">
          <TrendingUp className="w-4 h-4 mr-1" />
          <span>+2.1%</span>
        </div>
      </div>
      <div className="flex-grow my-4">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <Tooltip
              contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '0.5rem' }}
              labelStyle={{ color: '#F3F4F6' }}
              itemStyle={{ color: '#34D399' }}
            />
            <Area type="monotone" dataKey="value" stroke="#10B981" fill="#10B981" fillOpacity={0.2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <Link to={createPageUrl('Assets')} className="text-center text-sm text-blue-400 hover:underline">
        Manage Asset Portfolio
      </Link>
    </div>
  );
}