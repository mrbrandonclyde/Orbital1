import React from 'react';
import { Target, Users, CheckCircle, PlayCircle, Loader, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const statusConfig = {
  PLANNING: { icon: Loader, color: 'text-blue-400', label: 'Planning' },
  ACTIVE: { icon: PlayCircle, color: 'text-green-400 animate-pulse', label: 'Active' },
  COMPLETED: { icon: CheckCircle, color: 'text-gray-500', label: 'Completed' },
  ABORTED: { icon: ShieldAlert, color: 'text-red-500', label: 'Aborted' }
};

const priorityConfig = {
  CRITICAL: { color: 'border-red-500/50', textColor: 'text-red-400', label: 'Critical' },
  HIGH: { color: 'border-orange-500/50', textColor: 'text-orange-400', label: 'High' },
  MEDIUM: { color: 'border-yellow-500/50', textColor: 'text-yellow-400', label: 'Medium' },
  LOW: { color: 'border-blue-500/50', textColor: 'text-blue-400', label: 'Low' }
};

export default function MissionCard({ mission, onEdit }) {
  const S = statusConfig[mission.status] || statusConfig.PLANNING;
  const P = priorityConfig[mission.priority] || priorityConfig.MEDIUM;

  return (
    <div className={`bg-[#0A0D18]/50 border ${P.color} rounded-xl shadow-lg transition-all hover:shadow-indigo-500/10 hover:border-indigo-500/50`}>
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <Target className="w-6 h-6 text-indigo-400" />
              <h3 className="text-xl font-bold text-white">{mission.mission_name}</h3>
            </div>
            <p className="text-gray-400 text-sm ml-9 max-w-lg">{mission.description}</p>
          </div>
          <button onClick={() => onEdit(mission)} className="orbital-button-secondary text-xs">Edit</button>
        </div>
        
        <div className="mt-4 flex justify-between items-end">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <S.icon className={`w-5 h-5 ${S.color}`} />
              <span className={`text-sm font-medium ${S.color}`}>{S.label}</span>
            </div>
            <div className="flex items-center space-x-2">
               <span className={`text-sm font-semibold px-2 py-0.5 rounded-full border ${P.color} ${P.textColor}`}>{P.label} Priority</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-gray-500" />
              <span className="text-sm text-gray-400">{mission.assigned_personnel?.length || 0} Personnel</span>
            </div>
          </div>
          <Link 
            to={createPageUrl(`Tasks?missionId=${mission.id}`)} 
            className="text-sm text-indigo-400 hover:text-indigo-300 font-medium"
          >
            View Tasks →
          </Link>
        </div>
      </div>
    </div>
  );
}