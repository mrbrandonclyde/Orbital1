import React, { useState } from 'react';
import { MapContainer, TileLayer, GeoJSON, Circle, Popup, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import MissionForm from './MissionForm';

const AOIStyle = {
  fillColor: '#d4af37',
  color: '#d4af37',
  weight: 2,
  fillOpacity: 0.2,
};

function MapClickHandler({ onMapClick }) {
  useMapEvents({
    click(e) {
      onMapClick(e.latlng);
    },
  });
  return null;
}

export default function MissionControlMap({ missions, onMissionUpdate }) {
  const [isDrawing, setIsDrawing] = useState(false);
  const [newMissionCenter, setNewMissionCenter] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const handleMapClick = (latlng) => {
    if (isDrawing) {
      setNewMissionCenter(latlng);
      setShowForm(true);
    }
  };

  const onFormSuccess = () => {
    setShowForm(false);
    setIsDrawing(false);
    setNewMissionCenter(null);
    onMissionUpdate();
  };

  const missionWithGeo = missions.filter(m => m.areaOfInterest);

  return (
    <div className="h-[75vh] w-full rounded-xl overflow-hidden border-2 border-indigo-500/30 orbital-glow relative">
      <MapContainer center={[20, 0]} zoom={2} style={{ height: '100%', width: '100%' }} scrollWheelZoom={true}>
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/attributions">CARTO</a>'
        />

        {missionWithGeo.map(mission => {
          if (mission.areaOfInterest.type === 'Circle') {
            return (
              <Circle
                key={mission.id}
                center={mission.areaOfInterest.coordinates}
                radius={mission.areaOfInterest.radius}
                pathOptions={AOIStyle}
              >
                <Popup>
                  <div className="text-white bg-[#0A0D18] m-[-12px] p-3 rounded-lg">
                    <h4 className="font-bold text-indigo-400">{mission.mission_name}</h4>
                    <p>Priority: {mission.priority}</p>
                    <p>Sector: {mission.sector}</p>
                  </div>
                </Popup>
              </Circle>
            );
          }
          // Placeholder for future polygon support
          if (mission.areaOfInterest.type === 'FeatureCollection') {
              return <GeoJSON key={mission.id} data={mission.areaOfInterest} style={AOIStyle} />
          }
          return null;
        })}
        
        <MapClickHandler onMapClick={handleMapClick} />
      </MapContainer>

      <div className="absolute top-4 left-4 z-[1000] bg-black/50 backdrop-blur-sm p-2 rounded-lg">
        <Button
          onClick={() => setIsDrawing(!isDrawing)}
          className={isDrawing ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
        >
          {isDrawing ? 'Cancel Drawing' : 'Define New AOI'}
        </Button>
        {isDrawing && <p className="text-white text-xs mt-2 animate-pulse">Click on the map to define mission center.</p>}
      </div>

      <Dialog open={showForm} onOpenChange={(isOpen) => { if (!isOpen) setIsDrawing(false); setShowForm(isOpen); }}>
        <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="orbital-gradient-text text-2xl">Define New Mission</DialogTitle>
          </DialogHeader>
          <MissionForm 
            onSuccess={onFormSuccess} 
            initialCenter={newMissionCenter}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}