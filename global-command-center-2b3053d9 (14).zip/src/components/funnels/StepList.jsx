import React from "react";
import { FunnelStep } from "@/api/entities";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, GripVertical, Trash } from "lucide-react";

export default function StepList({ funnelId, steps, setSteps }) {
  const [newStepName, setNewStepName] = React.useState("");

  const onDragEnd = async (result) => {
    const { destination, source } = result;
    if (!destination) return;
    if (destination.index === source.index) return;
    const reordered = Array.from(steps);
    const [removed] = reordered.splice(source.index, 1);
    reordered.splice(destination.index, 0, removed);
    // recompute order_index
    const updated = reordered.map((s, idx) => ({ ...s, order_index: (idx + 1) * 100 }));
    setSteps(updated);
    // persist order
    for (const s of updated) await FunnelStep.update(s.id, { order_index: s.order_index });
  };

  const addStep = async () => {
    const name = newStepName.trim() || `Step ${steps.length + 1}`;
    const created = await FunnelStep.create({ funnel_id: funnelId, step_name: name, step_type: "CUSTOM", order_index: (steps.length + 1) * 100, path_slug: name.toLowerCase().replace(/\s+/g, "-") });
    setSteps(prev => [...prev, created]);
    setNewStepName("");
  };

  const deleteStep = async (step) => {
    await FunnelStep.delete(step.id);
    setSteps(prev => prev.filter(s => s.id !== step.id));
  };

  return (
    <div>
      <div className="flex gap-2 mb-3">
        <Input value={newStepName} onChange={(e) => setNewStepName(e.target.value)} placeholder="New step name" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
        <Button onClick={addStep} className="bg-indigo-600 hover:bg-indigo-700"><Plus className="w-4 h-4 mr-1" /> Add Step</Button>
      </div>
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="steps">
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
              {steps.map((s, idx) => (
                <Draggable key={s.id} draggableId={String(s.id)} index={idx}>
                  {(p) => (
                    <div ref={p.innerRef} {...p.draggableProps} className="flex items-center justify-between bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span {...p.dragHandleProps}><GripVertical className="w-4 h-4 text-gray-500" /></span>
                        <span className="text-gray-100">{s.step_name}</span>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => deleteStep(s)} className="text-red-400 hover:text-red-500">
                        <Trash className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}