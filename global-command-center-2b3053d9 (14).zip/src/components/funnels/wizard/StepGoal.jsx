import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const GOALS = [
  "Collect Leads", "Sell Product", "Register", "Membership", "Custom"
];

export default function StepGoal({ value, onChange }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
      {GOALS.map(g => {
        const selected = value === g;
        return (
          <Card key={g} onClick={() => onChange(g)}
            className={`cursor-pointer bg-[#0A0D18]/60 border ${selected ? 'border-indigo-500' : 'border-gray-800'} rounded-2xl`}>
            <CardHeader className="pb-2"><CardTitle className="text-white">{g}</CardTitle></CardHeader>
            <CardContent className="text-sm text-gray-400">Target: {g}</CardContent>
          </Card>
        );
      })}
    </div>
  );
}