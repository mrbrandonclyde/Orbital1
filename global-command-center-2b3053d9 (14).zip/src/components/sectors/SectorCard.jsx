import React from 'react';
import { Building2, TrendingUp, AlertTriangle, BarChart3, Pencil } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const getImportanceBadge = (importance) => {
  switch (importance) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    case 'LOW': return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getCategoryBadge = (category) => {
  const categoryColors = {
    'CORE_ECONOMICS': 'bg-green-500/20 text-green-400',
    'DEFENSE_SECURITY': 'bg-red-500/20 text-red-400',
    'HEALTHCARE_LIFE': 'bg-blue-500/20 text-blue-400',
    'TECHNOLOGY': 'bg-purple-500/20 text-purple-400',
    'ENERGY_RESOURCES': 'bg-yellow-500/20 text-yellow-400',
    'INTERNATIONAL_CHAINS': 'bg-cyan-500/20 text-cyan-400'
  };
  
  return (
    <Badge className={categoryColors[category] || 'bg-gray-500/20 text-gray-400'}>
      {category?.replace('_', ' ') || 'Unknown'}
    </Badge>
  );
};

export default function SectorCard({ sector, metricCount, alertCount, onEdit }) {
  return (
    <Card className="bg-[#0A0D18]/50 border-gray-800 hover:border-indigo-500/50 transition-all cursor-pointer group">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-cyan-400" />
            <CardTitle className="text-lg text-white group-hover:text-cyan-400 transition-colors">
              {sector.sector_name}
            </CardTitle>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(sector);
            }}
            className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-gray-700 transition-all"
          >
            <Pencil className="w-4 h-4 text-gray-400 hover:text-white" />
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <Badge className="bg-blue-500/20 text-blue-400">{sector.sector_code}</Badge>
          {getCategoryBadge(sector.sector_category)}
          {getImportanceBadge(sector.strategic_importance)}
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {sector.description && (
            <p className="text-sm text-gray-300 line-clamp-2">{sector.description}</p>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-gray-500">GDP Contribution</p>
              <p className="text-lg font-bold text-green-400">
                ${sector.gdp_contribution_billions ? `${sector.gdp_contribution_billions}B` : 'N/A'}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Employment</p>
              <p className="text-lg font-bold text-blue-400">
                {sector.employment_count ? sector.employment_count.toLocaleString() : 'N/A'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">{metricCount || 0} Metrics</span>
            </div>
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">{alertCount || 0} Alerts</span>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2 border-t border-gray-700">
            <span className="text-xs text-gray-500">{sector.country || 'Global'}</span>
            <span className="text-xs text-gray-500">
              {sector.regulation_level?.replace('_', ' ') || 'Unknown'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}