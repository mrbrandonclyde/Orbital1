import React from 'react';
import { useStockQuote, useGDP } from '../lib/financeAPI';
import { useCyberThreats } from '../lib/defenseAPI';
import { useEnergyPrices } from '../lib/energyAPI';
import { useShipTracking } from '../lib/transportAPI';
import { useSemiconductorReport } from '../lib/techAPI';
import { useGlobalFoodStats } from '../lib/agricultureAPI';
import { useCompanyProfile } from '../lib/companiesAPI';

export default function MultiSectorOverview() {
  // Multi-sector data hooks
  const { data: ibmStock, loading: stockLoading } = useStockQuote('IBM');
  const { data: usGDP, loading: gdpLoading } = useGDP('US');
  const { data: threats, loading: threatsLoading } = useCyberThreats();
  const { data: energyPrices, loading: energyLoading } = useEnergyPrices();
  const { data: ships, loading: shipsLoading } = useShipTracking();
  const { data: semiconductors, loading: semisLoading } = useSemiconductorReport();
  const { data: foodStats, loading: foodLoading } = useGlobalFoodStats();
  const { data: companyData, loading: companyLoading } = useCompanyProfile('AAPL');

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Finance Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">💰</span>
          <h3 className="text-lg font-semibold text-white">Finance</h3>
        </div>
        {stockLoading || gdpLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
            <div className="h-4 bg-gray-700 rounded w-1/2"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">IBM: <span className="text-white font-semibold">${ibmStock?.price}</span></p>
            <p className="text-gray-300">US GDP: <span className="text-white font-semibold">${(usGDP?.gdp / 1e12)?.toFixed(2)}T</span></p>
          </div>
        )}
      </div>

      {/* Defense Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">🛡️</span>
          <h3 className="text-lg font-semibold text-white">Defense</h3>
        </div>
        {threatsLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">Active Threats: <span className="text-red-400 font-semibold">{threats?.length || 0}</span></p>
          </div>
        )}
      </div>

      {/* Energy Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">⚡</span>
          <h3 className="text-lg font-semibold text-white">Energy</h3>
        </div>
        {energyLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">Oil: <span className="text-white font-semibold">${energyPrices?.oil}</span></p>
            <p className="text-gray-300">Gas: <span className="text-white font-semibold">${energyPrices?.gas}</span></p>
          </div>
        )}
      </div>

      {/* Transport Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">🚢</span>
          <h3 className="text-lg font-semibold text-white">Transport</h3>
        </div>
        {shipsLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">Ships Tracked: <span className="text-white font-semibold">{ships?.length || 0}</span></p>
          </div>
        )}
      </div>

      {/* Technology Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">💻</span>
          <h3 className="text-lg font-semibold text-white">Technology</h3>
        </div>
        {semisLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">Semiconductors: <span className="text-white font-semibold">{semiconductors?.status}</span></p>
          </div>
        )}
      </div>

      {/* Agriculture Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">🌾</span>
          <h3 className="text-lg font-semibold text-white">Agriculture</h3>
        </div>
        {foodLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">Food Security: <span className="text-green-400 font-semibold">{foodStats?.security_level}</span></p>
          </div>
        )}
      </div>

      {/* Companies Sector */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">🏢</span>
          <h3 className="text-lg font-semibold text-white">Companies</h3>
        </div>
        {companyLoading ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p className="text-gray-300">AAPL: <span className="text-white font-semibold">{companyData?.status}</span></p>
          </div>
        )}
      </div>

      {/* Healthcare would be 8th */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl">🏥</span>
          <h3 className="text-lg font-semibold text-white">Healthcare</h3>
        </div>
        <div className="space-y-2 text-sm">
          <p className="text-gray-300">Coming Soon: <span className="text-blue-400 font-semibold">WHO/CDC Feeds</span></p>
        </div>
      </div>
    </div>
  );
}