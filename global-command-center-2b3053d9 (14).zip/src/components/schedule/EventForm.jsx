import React, { useState, useEffect } from 'react';
import { ExecutiveEvent } from '@/api/entities';
import { logAuditEvent } from '../lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, parseISO } from 'date-fns';

const EVENT_TYPES = ['MEETING', 'BRIEFING', 'SUMMIT', 'CALL', 'VISIT'];
const PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
const STATUSES = ['SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];

export default function EventForm({ event, selectedDate, onSuccess }) {
  const [formData, setFormData] = useState({
    event_title: '',
    event_type: 'MEETING',
    priority: 'MEDIUM',
    event_status: 'SCHEDULED',
    start_date_time: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (event) {
      setFormData({
        event_title: event.event_title || '',
        event_type: event.event_type || 'MEETING',
        priority: event.priority || 'MEDIUM',
        event_status: event.event_status || 'SCHEDULED',
        start_date_time: event.start_date_time ? format(parseISO(event.start_date_time), "yyyy-MM-dd'T'HH:mm") : '',
      });
    } else if (selectedDate) {
      setFormData(prev => ({
        ...prev,
        start_date_time: format(selectedDate, "yyyy-MM-dd'T'09:00"),
      }));
    } else {
      setFormData({
        event_title: '',
        event_type: 'MEETING',
        priority: 'MEDIUM',
        event_status: 'SCHEDULED',
        start_date_time: '',
      });
    }
  }, [event, selectedDate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const submissionData = {
      ...formData,
      start_date_time: new Date(formData.start_date_time).toISOString(),
    };

    try {
      if (event) {
        await ExecutiveEvent.update(event.id, submissionData);
        await logAuditEvent('UPDATE', 'ExecutiveEvent', event.id, submissionData);
      } else {
        const newEvent = await ExecutiveEvent.create(submissionData);
        await logAuditEvent('CREATE', 'ExecutiveEvent', newEvent.id, submissionData);
      }
      onSuccess();
    } catch (error) {
      console.error("Failed to save event:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 pt-4">
      <Input
        value={formData.event_title}
        onChange={(e) => setFormData({ ...formData, event_title: e.target.value })}
        placeholder="Event Title"
        className="bg-[#0C0F19] border-gray-600"
        required
      />
      <Input
        type="datetime-local"
        value={formData.start_date_time}
        onChange={(e) => setFormData({ ...formData, start_date_time: e.target.value })}
        className="bg-[#0C0F19] border-gray-600"
        required
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select
          value={formData.event_type}
          onValueChange={(value) => setFormData({ ...formData, event_type: value })}
        >
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Event Type" /></SelectTrigger>
          <SelectContent>{EVENT_TYPES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
        </Select>
        <Select
          value={formData.priority}
          onValueChange={(value) => setFormData({ ...formData, priority: value })}
        >
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>{PRIORITIES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
        </Select>
      </div>
       <Select
          value={formData.event_status}
          onValueChange={(value) => setFormData({ ...formData, event_status: value })}
        >
          <SelectTrigger className="bg-[#0C0F19] border-gray-600"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>{STATUSES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
        </Select>
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onSuccess}>Cancel</Button>
        <Button type="submit" className="orbital-button-primary" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : (event ? 'Update Event' : 'Create Event')}
        </Button>
      </div>
    </form>
  );
}