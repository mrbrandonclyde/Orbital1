import React, { useState } from 'react';
import { MessageSquare, X, Send, Bug, Lightbulb, Users, MessageCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { UserFeedback } from '@/api/entities';

export default function FeedbackWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [feedback, setFeedback] = useState({
    feedback_type: '',
    subject: '',
    description: '',
    user_email: '',
    priority: 'medium'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const feedbackTypes = [
    { value: 'bug_report', label: 'Bug Report', icon: Bug },
    { value: 'feature_request', label: 'Feature Request', icon: Lightbulb },
    { value: 'usability_feedback', label: 'Usability Feedback', icon: Users },
    { value: 'general_feedback', label: 'General Feedback', icon: MessageCircle }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Get browser information
      const browserInfo = `${navigator.userAgent} | Screen: ${screen.width}x${screen.height}`;
      
      await UserFeedback.create({
        ...feedback,
        page_location: window.location.pathname,
        browser_info: browserInfo
      });

      setSubmitted(true);
      setTimeout(() => {
        setIsOpen(false);
        setSubmitted(false);
        setFeedback({
          feedback_type: '',
          subject: '',
          description: '',
          user_email: '',
          priority: 'medium'
        });
      }, 2000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="rounded-full w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg"
          size="icon"
        >
          <MessageSquare className="w-5 h-5" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className="w-96 bg-[#0A0D18] border-[#151823] shadow-2xl">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-white text-lg">Share Your Feedback</CardTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-green-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Thank You!</h3>
              <p className="text-gray-400 text-sm">Your feedback has been submitted successfully.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Feedback Type</label>
                <Select value={feedback.feedback_type} onValueChange={(value) => setFeedback({...feedback, feedback_type: value})}>
                  <SelectTrigger className="bg-[#0C0F19] border-gray-600 text-white">
                    <SelectValue placeholder="Select feedback type..." />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0C0F19] border-gray-600">
                    {feedbackTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value} className="text-white hover:bg-gray-700">
                          <div className="flex items-center">
                            <Icon className="w-4 h-4 mr-2" />
                            {type.label}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Subject</label>
                <Input
                  value={feedback.subject}
                  onChange={(e) => setFeedback({...feedback, subject: e.target.value})}
                  placeholder="Brief description of your feedback"
                  className="bg-[#0C0F19] border-gray-600 text-white placeholder:text-gray-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                <Textarea
                  value={feedback.description}
                  onChange={(e) => setFeedback({...feedback, description: e.target.value})}
                  placeholder="Please provide detailed information about your feedback..."
                  className="bg-[#0C0F19] border-gray-600 text-white placeholder:text-gray-400 min-h-[100px] resize-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Email (Optional)</label>
                <Input
                  type="email"
                  value={feedback.user_email}
                  onChange={(e) => setFeedback({...feedback, user_email: e.target.value})}
                  placeholder="your@email.com"
                  className="bg-[#0C0F19] border-gray-600 text-white placeholder:text-gray-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Priority</label>
                <Select value={feedback.priority} onValueChange={(value) => setFeedback({...feedback, priority: value})}>
                  <SelectTrigger className="bg-[#0C0F19] border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0C0F19] border-gray-600">
                    <SelectItem value="low" className="text-white hover:bg-gray-700">Low Priority</SelectItem>
                    <SelectItem value="medium" className="text-white hover:bg-gray-700">Medium Priority</SelectItem>
                    <SelectItem value="high" className="text-white hover:bg-gray-700">High Priority</SelectItem>
                    <SelectItem value="critical" className="text-white hover:bg-gray-700">Critical Issue</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 border-gray-600 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting || !feedback.feedback_type || !feedback.subject || !feedback.description}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {isSubmitting ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Submit Feedback
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}