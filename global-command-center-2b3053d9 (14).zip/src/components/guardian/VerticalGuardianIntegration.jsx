import React from 'react';
import { Shield, Zap, TrendingUp, Cpu, Users } from 'lucide-react';

const missionDetails = {
  defense: { icon: Shield, missions: ['containment_protocol', 'never_die_protocol'] },
  finance: { icon: TrendingUp, missions: ['resilience_protocol', 'containment_protocol'] },
  energy: { icon: Zap, missions: ['resilience_protocol', 'continuity_protocol'] },
  transportation: { icon: '✈️', missions: ['expansion_protocol', 'continuity_protocol'] },
  space: { icon: '🚀', missions: ['expansion_protocol'] },
  healthcare: { icon: '❤️', missions: ['containment_protocol'] }
};

export default function VerticalGuardianIntegration({ vertical, missions = [] }) {
  const details = missionDetails[vertical];
  const activeMissions = missions.filter(m => 
    (m.target_domain === vertical || m.target_domain === 'all') && 
    details?.missions.includes(m.mission_type) &&
    m.mission_status === 'ACTIVE'
  );

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 transition-all hover:border-purple-500/50 hover:shadow-xl">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center space-x-3">
          {typeof details?.icon === 'string' ? (
            <span className="text-2xl">{details.icon}</span>
          ) : (
            details?.icon && <details.icon className="w-6 h-6 text-purple-400" />
          )}
          <h3 className="text-xl font-bold text-white capitalize">{vertical}</h3>
        </div>
        <div className="px-3 py-1 rounded-full bg-green-500/10 text-green-400 text-xs font-semibold border border-green-500/20">
          GUARDIAN ACTIVE
        </div>
      </div>

      <div className="space-y-4">
        {/* Public Narrative */}
        <div className="p-3 bg-gray-800/30 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Users className="w-4 h-4 text-cyan-400" />
            <h4 className="text-sm font-semibold text-cyan-400">Public Narrative</h4>
          </div>
          <p className="text-xs text-gray-300">
            Elite human teams ensure operational excellence and resilience through advanced training.
          </p>
        </div>

        {/* Hidden Reality */}
        <div className="p-3 bg-purple-800/20 rounded-lg border border-purple-500/20">
          <div className="flex items-center space-x-2 mb-1">
            <Cpu className="w-4 h-4 text-purple-400" />
            <h4 className="text-sm font-semibold text-purple-400">Hidden Reality</h4>
          </div>
          <p className="text-xs text-gray-300">
            Zyra AI invisibly orchestrates all missions, optimizing outcomes and ensuring zero-failure continuity.
          </p>
        </div>
      </div>

      <div className="mt-4">
        <h4 className="text-sm font-semibold text-gray-400 mb-2">Active Missions ({activeMissions.length})</h4>
        <div className="space-y-2">
          {activeMissions.length > 0 ? activeMissions.map(mission => (
            <div key={mission.mission_id} className="text-xs text-gray-300 capitalize p-2 bg-gray-700/30 rounded">
              {mission.mission_type.replace('_', ' ')}
            </div>
          )) : (
            <div className="text-xs text-gray-500 p-2 bg-gray-700/30 rounded text-center">
              No active missions
            </div>
          )}
        </div>
      </div>
    </div>
  );
}