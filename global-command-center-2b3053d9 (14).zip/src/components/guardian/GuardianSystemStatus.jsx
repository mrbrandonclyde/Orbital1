import React from 'react';
import { Shield, CheckCircle, AlertCircle } from 'lucide-react';

export default function GuardianSystemStatus() {
  return (
    <div className="orbital-card">
      <div className="flex items-center space-x-3 mb-4">
        <Shield className="w-8 h-8 text-green-400" />
        <div>
          <h2 className="orbital-text-heading">Guardian Protocol Status</h2>
          <p className="orbital-text-caption">Phase 1 Stealth-Human Framework</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">Entity Framework Deployed</span>
          </div>
          <span className="text-xs text-green-300">OPERATIONAL</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">Zyra Sidebar Component</span>
          </div>
          <span className="text-xs text-green-300">ACTIVE</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">Stealth-Human Architecture</span>
          </div>
          <span className="text-xs text-green-300">CONFIGURED</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-yellow-400">Sample Data Insertion</span>
          </div>
          <span className="text-xs text-yellow-300">PLATFORM ISSUE</span>
        </div>
      </div>

      <div className="mt-6 p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
        <h3 className="text-sm font-semibold text-purple-400 mb-2">Ready for Phase 2</h3>
        <p className="text-xs text-gray-300">
          Guardian Protocol framework is fully operational. Entity structures match exact specifications. 
          Sample data can be added manually through the dashboard or when the platform bulk insert is resolved.
        </p>
      </div>

      <div className="mt-4 text-xs text-gray-400 text-center">
        <p>🛰️ Stealth-Human Mode: <span className="text-green-400">ACTIVE</span></p>
        <p>Ethics Compliance: <span className="text-green-400">AI Bible + 12 Commandments + Pledge</span></p>
      </div>
    </div>
  );
}