import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, CreditCard, Users, TrendingUp, ArrowUpRight, ArrowDownRight, 
  Activity, Shield, AlertTriangle, CheckCircle, Building2, PieChart, Send, Download, Plus
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';

// Mock data for Orbital Bank (these remain as per outline)
const monthlyData = [
  { month: 'Jan', income: 4200000, expenses: 3100000, profit: 1100000 },
  { month: 'Feb', income: 3800000, expenses: 2900000, profit: 900000 },
  { month: 'Mar', income: 5100000, expenses: 3400000, profit: 1700000 },
  { month: 'Apr', income: 4600000, expenses: 3200000, profit: 1400000 },
  { month: 'May', income: 5300000, expenses: 3600000, profit: 1700000 },
  { month: 'Jun', income: 4900000, expenses: 3300000, profit: 1600000 }
];

const accountTypeDistribution = [
  { name: 'Treasury', value: 42, fill: '#10B981' },
  { name: 'Operations', value: 23, fill: '#06B6D4' },
  { name: 'Investments', value: 35, fill: '#8B5CF6' }
];

const getStatusBadge = (status) => {
  switch (status) {
    case "Completed":
      return <Badge className="bg-green-500/10 text-green-400 border-green-500/20"><CheckCircle className="w-3 h-3 mr-1"/>{status}</Badge>;
    case "Pending":
      return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20 animate-pulse"><Activity className="w-3 h-3 mr-1"/>{status}</Badge>;
    case "Failed":
      return <Badge className="bg-red-500/10 text-red-400 border-red-500/20"><AlertTriangle className="w-3 h-3 mr-1"/>{status}</Badge>;
    default:
      return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
  }
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-900/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {`${entry.name}: $${(entry.value / 1000000).toFixed(1)}M`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function BankDashboard({ data }) {
  const { transactions } = data || {};
  
  // accountBalances remains mock data as per outline
  const accountBalances = [
    { account: "Corporate Treasury", balance: 15420000, type: "Business" },
    { account: "Operations Fund", balance: 3250000, type: "Operating" },
    { account: "Emergency Reserve", balance: 5000000, type: "Reserve" },
    { account: "Investment Portfolio", balance: 12800000, type: "Investment" }
  ];
  
  const totalBalance = accountBalances.reduce((sum, account) => sum + account.balance, 0);
  const monthlyProfit = monthlyData[monthlyData.length - 1].profit;
  const monthlyIncome = monthlyData[monthlyData.length - 1].income;

  // Calculate financial health indicators
  const creditUtilization = 15.2; // Example: 15.2%
  const liquidityRatio = 2.4; // Example: 2.4:1
  const debtToEquityRatio = 0.35; // Example: 0.35

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Orbital Bank Dashboard</h1>
          <p className="text-gray-400 mt-1">Real-time financial operations and portfolio management</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge className="bg-green-500/10 text-green-400 border-green-500/20">
            <Shield className="w-3 h-3 mr-1" />
            Secure Connection
          </Badge>
        </div>
      </div>

      {/* Enhanced KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Assets</CardTitle>
            <DollarSign className="h-5 w-5 text-emerald-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${(totalBalance / 1000000).toFixed(1)}M</div>
            <p className="text-xs text-emerald-400">+12.5% from last month</p>
          </CardContent>
        </Card>
        
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Monthly Profit</CardTitle>
            <TrendingUp className="h-5 w-5 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${(monthlyProfit / 1000000).toFixed(1)}M</div>
            <p className="text-xs text-green-400">+8.2% increase</p>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Credit Utilization</CardTitle>
            <CreditCard className="h-5 w-5 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{creditUtilization}%</div>
            <p className="text-xs text-cyan-400">Excellent health</p>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Liquidity Ratio</CardTitle>
            <Activity className="h-5 w-5 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{liquidityRatio}:1</div>
            <p className="text-xs text-purple-400">Strong position</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Action Buttons */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600">
              <Send className="w-4 h-4 mr-2" />
              Wire Transfer
            </Button>
            <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800">
              <Download className="w-4 h-4 mr-2" />
              Download Statement
            </Button>
            <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800">
              <Plus className="w-4 h-4 mr-2" />
              New Investment
            </Button>
            <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800">
              <TrendingUp className="w-4 h-4 mr-2" />
              View Analytics
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-emerald-400" />
              Monthly Financial Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="income" name="Income" fill="#10B981" />
                <Bar dataKey="expenses" name="Expenses" fill="#EF4444" />
                <Bar dataKey="profit" name="Profit" fill="#06B6D4" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="w-5 h-5 mr-2 text-cyan-400" />
              Account Distribution
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsPieChart>
                <Pie
                  data={accountTypeDistribution}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={40}
                >
                  {accountTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Financial Health Indicators */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-400" />
            Financial Health Indicators
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{creditUtilization}%</div>
              <p className="text-sm text-gray-400">Credit Utilization</p>
              <p className="text-xs text-emerald-400 mt-1">Excellent</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-400">{liquidityRatio}:1</div>
              <p className="text-sm text-gray-400">Liquidity Ratio</p>
              <p className="text-xs text-cyan-400 mt-1">Strong</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">{debtToEquityRatio}</div>
              <p className="text-sm text-gray-400">Debt-to-Equity</p>
              <p className="text-xs text-purple-400 mt-1">Optimal</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Accounts and Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building2 className="w-5 h-5 mr-2 text-purple-400" />
              Account Balances
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {accountBalances.map((account, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                  <div>
                    <p className="font-medium text-white">{account.account}</p>
                    <p className="text-xs text-gray-400">{account.type}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-emerald-400">${(account.balance / 1000000).toFixed(1)}M</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-pane">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-green-400" />
              Recent Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(transactions || []).slice(0, 5).map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {transaction.amount > 0 ? (
                      <ArrowDownRight className="w-4 h-4 text-green-400" />
                    ) : (
                      <ArrowUpRight className="w-4 h-4 text-red-400" />
                    )}
                    <div>
                      <p className="font-medium text-white text-sm">{transaction.type}</p>
                      <p className="text-xs text-gray-400">{transaction.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${transaction.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toLocaleString()}
                    </p>
                    {getStatusBadge(transaction.status)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}