import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building2, CreditCard, Wallet, ArrowRightLeft, Plus, Eye, EyeOff, Copy } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const mockAccounts = [
  {
    id: '1',
    name: 'Primary Checking',
    type: 'CHECKING',
    balance: 2485697.42,
    accountNumber: '****7891',
    status: 'ACTIVE',
    lastTransaction: '2025-01-02'
  },
  {
    id: '2',
    name: 'Corporate Savings',
    type: 'SAVINGS',
    balance: 15420000.00,
    accountNumber: '****2156',
    status: 'ACTIVE',
    lastTransaction: '2025-01-01'
  },
  {
    id: '3',
    name: 'Emergency Reserve',
    type: 'RESERVE',
    balance: 5000000.00,
    accountNumber: '****8923',
    status: 'ACTIVE',
    lastTransaction: '2024-12-28'
  },
  {
    id: '4',
    name: 'Operations Fund',
    type: 'OPERATIONAL',
    balance: 3250000.00,
    accountNumber: '****4567',
    status: 'ACTIVE',
    lastTransaction: '2025-01-02'
  }
];

const recentTransfers = [
  { id: '1', from: 'Primary Checking', to: 'Corporate Savings', amount: 500000, date: '2025-01-02', status: 'COMPLETED' },
  { id: '2', from: 'Operations Fund', to: 'Primary Checking', amount: 250000, date: '2025-01-01', status: 'COMPLETED' },
  { id: '3', from: 'Corporate Savings', to: 'Emergency Reserve', amount: 1000000, date: '2024-12-30', status: 'COMPLETED' }
];

const AccountCard = ({ account, onViewDetails, onTransfer }) => {
  const [showBalance, setShowBalance] = useState(true);
  
  const getAccountIcon = (type) => {
    switch (type) {
      case 'CHECKING': return <Wallet className="w-6 h-6" />;
      case 'SAVINGS': return <Building2 className="w-6 h-6" />;
      case 'RESERVE': return <CreditCard className="w-6 h-6" />;
      default: return <Building2 className="w-6 h-6" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'CHECKING': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'SAVINGS': return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'RESERVE': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'OPERATIONAL': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <Card className="glass-pane hover:border-emerald-500/50 transition-all">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gray-800/50 rounded-lg text-emerald-400">
              {getAccountIcon(account.type)}
            </div>
            <div>
              <CardTitle className="text-white text-lg">{account.name}</CardTitle>
              <div className="flex items-center space-x-2 mt-1">
                <Badge className={getTypeColor(account.type)}>{account.type}</Badge>
                <span className="text-gray-400 text-sm">{account.accountNumber}</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
          >
            {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-gray-400 text-sm">Current Balance</p>
            <p className="text-2xl font-bold text-white">
              {showBalance ? `$${account.balance.toLocaleString()}` : '••••••••'}
            </p>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Last Transaction</span>
            <span className="text-gray-300">{account.lastTransaction}</span>
          </div>
          <div className="flex space-x-2">
            <Button
              onClick={() => onViewDetails(account)}
              variant="outline"
              className="flex-1 text-emerald-400 border-emerald-500/50 hover:bg-emerald-500/10"
            >
              View Details
            </Button>
            <Button
              onClick={() => onTransfer(account)}
              className="flex-1 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600"
            >
              <ArrowRightLeft className="w-4 h-4 mr-2" />
              Transfer
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const TransferDialog = ({ isOpen, onClose, sourceAccount }) => {
  const [transferData, setTransferData] = useState({
    fromAccount: sourceAccount?.id || '',
    toAccount: '',
    amount: '',
    description: ''
  });

  const handleTransfer = () => {
    console.log('Transfer initiated:', transferData);
    // Here you would call the actual transfer API
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-emerald-400">Transfer Funds</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>From Account</Label>
            <Select value={transferData.fromAccount} onValueChange={(value) => setTransferData({...transferData, fromAccount: value})}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue placeholder="Select source account" />
              </SelectTrigger>
              <SelectContent>
                {mockAccounts.map(account => (
                  <SelectItem key={account.id} value={account.id}>{account.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>To Account</Label>
            <Select value={transferData.toAccount} onValueChange={(value) => setTransferData({...transferData, toAccount: value})}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue placeholder="Select destination account" />
              </SelectTrigger>
              <SelectContent>
                {mockAccounts.filter(acc => acc.id !== transferData.fromAccount).map(account => (
                  <SelectItem key={account.id} value={account.id}>{account.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Amount</Label>
            <Input
              type="number"
              placeholder="0.00"
              value={transferData.amount}
              onChange={(e) => setTransferData({...transferData, amount: e.target.value})}
              className="bg-[#0C0F19] border-gray-600"
            />
          </div>
          <div>
            <Label>Description (Optional)</Label>
            <Input
              placeholder="Transfer description..."
              value={transferData.description}
              onChange={(e) => setTransferData({...transferData, description: e.target.value})}
              className="bg-[#0C0F19] border-gray-600"
            />
          </div>
          <div className="flex space-x-2 pt-4">
            <Button onClick={onClose} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleTransfer} className="flex-1 bg-gradient-to-r from-emerald-500 to-cyan-500">
              Transfer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const getStatusBadge = (status) => {
  switch (status) {
    case "COMPLETED": return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    case "PENDING": return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">{status}</Badge>;
    case "FAILED": return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">{status}</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
  }
};

export default function AccountsView() {
  const [showTransferDialog, setShowTransferDialog] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState(null);

  const handleViewDetails = (account) => {
    console.log('View details for account:', account.id);
    // Navigate to account details or open modal
  };

  const handleTransfer = (account) => {
    setSelectedAccount(account);
    setShowTransferDialog(true);
  };

  const totalBalance = mockAccounts.reduce((sum, account) => sum + account.balance, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Account Management</h1>
          <p className="text-gray-400 mt-1">Manage all corporate banking accounts and fund transfers.</p>
        </div>
        <Button className="orbital-button-primary">
          <Plus className="w-4 h-4 mr-2" />
          Add Account
        </Button>
      </div>

      {/* Total Balance Summary */}
      <Card className="glass-pane border-emerald-500/30">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-gray-400 text-sm">Total Available Balance</p>
            <p className="text-4xl font-bold text-emerald-400 mt-2">${totalBalance.toLocaleString()}</p>
            <p className="text-gray-500 text-sm mt-1">Across {mockAccounts.length} accounts</p>
          </div>
        </CardContent>
      </Card>

      {/* Accounts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockAccounts.map(account => (
          <AccountCard
            key={account.id}
            account={account}
            onViewDetails={handleViewDetails}
            onTransfer={handleTransfer}
          />
        ))}
      </div>

      {/* Recent Transfers */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Recent Fund Transfers</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-transparent">
                <TableHead className="text-gray-400">From</TableHead>
                <TableHead className="text-gray-400">To</TableHead>
                <TableHead className="text-gray-400">Amount</TableHead>
                <TableHead className="text-gray-400">Date</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentTransfers.map((transfer) => (
                <TableRow key={transfer.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="text-white font-medium">{transfer.from}</TableCell>
                  <TableCell className="text-gray-300">{transfer.to}</TableCell>
                  <TableCell className="text-emerald-400 font-semibold">${transfer.amount.toLocaleString()}</TableCell>
                  <TableCell className="text-gray-400">{transfer.date}</TableCell>
                  <TableCell>{getStatusBadge(transfer.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <TransferDialog
        isOpen={showTransferDialog}
        onClose={() => setShowTransferDialog(false)}
        sourceAccount={selectedAccount}
      />
    </div>
  );
}