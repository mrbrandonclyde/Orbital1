import React from "react";

export default function MiniMonitorHUD() {
  return (
    <div className="fixed bottom-4 right-4 bg-gray-900 text-white p-3 rounded-lg shadow-lg z-10">
      {/* 📊 Mini HUD */}
      <p className="text-xs">Mini Monitor Active</p>
    </div>
  );
}