import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Shield, Crown, TrendingUp } from 'lucide-react';

export default function ExecutiveProfile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadExecutiveData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Executive data load failed:', error);
      } finally {
        setLoading(false);
      }
    };
    loadExecutiveData();
  }, []);

  if (loading) {
    return (
      <div className="glass-pane p-6 h-full flex items-center justify-center animate-pulse">
        <div className="w-16 h-16 bg-gray-700 rounded-full mr-4"></div>
        <div className="flex-1 space-y-2">
          <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          <div className="h-3 bg-gray-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-pane p-6 h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <img
              src={user?.avatar_url || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user?.full_name || 'E') + '&background=8B5CF6&color=fff'}
              alt="Executive Avatar"
              className="w-16 h-16 rounded-full border-2 border-purple-500/50 object-cover"
            />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center border-2 border-[#0A0D18]">
              <Crown className="w-3 h-3 text-white" />
            </div>
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">{user?.full_name || 'Executive'}</h3>
            <p className="text-purple-300">{user?.title || 'Global Director'}</p>
          </div>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4 text-center">
         <div className="bg-blue-500/10 p-3 rounded-lg">
           <p className="text-sm text-blue-300">Clearance</p>
           <p className="font-bold text-white">{user?.security_clearance || 'COMMAND'}</p>
         </div>
         <div className="bg-green-500/10 p-3 rounded-lg">
           <p className="text-sm text-green-300">Performance</p>
           <p className="font-bold text-white flex items-center justify-center"><TrendingUp size={16} className="mr-1"/> Optimal</p>
         </div>
      </div>
    </div>
  );
}