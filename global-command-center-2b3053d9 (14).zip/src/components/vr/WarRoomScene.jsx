import React, { useState, useEffect } from 'react';
import { useQuery } from '../lib/useQuery';
import { SecurityAlert, SupplyChainRisk } from '@/api/entities';
import { Globe, AlertTriangle, Activity } from 'lucide-react';

export default function WarRoomScene() {
  const [isLoading, setIsLoading] = useState(true);
  
  const { data, loading } = useQuery(async () => {
    const [alerts, supplyChains] = await Promise.all([
      SecurityAlert.filter({ alert_status: 'ACTIVE' }, '-created_date', 10),
      SupplyChainRisk.filter({ risk_level: 'CRITICAL' }, '-last_assessment_date', 5)
    ]);
    return { alerts, supplyChains };
  });

  useEffect(() => {
    // Simulate VR scene loading
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (loading || isLoading) {
    return (
      <div className="h-[calc(100vh-400px)] w-full bg-gradient-to-br from-black via-gray-900 to-indigo-900 rounded-lg relative flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-white text-xl font-semibold">Loading War Room Intelligence...</div>
          <div className="text-gray-400 text-sm mt-2">Initializing immersive environment...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-400px)] w-full bg-gradient-to-br from-black via-gray-900 to-indigo-900 rounded-lg relative overflow-hidden">
      {/* Simulated VR Environment */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-purple-900/20"></div>
      
      {/* Central Globe Simulation */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="relative">
          <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-green-400 animate-pulse shadow-2xl">
            <div className="absolute inset-2 rounded-full border-2 border-white/30 animate-spin" style={{animationDuration: '20s'}}></div>
            <div className="absolute inset-4 rounded-full border border-white/20 animate-spin" style={{animationDuration: '15s'}}></div>
            <Globe className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-white" />
          </div>
        </div>
      </div>

      {/* Alert Holograms */}
      {data?.alerts?.slice(0, 6).map((alert, index) => {
        const angle = (index / 6) * 360;
        const radius = 200;
        const x = 50 + (radius * Math.cos(angle * Math.PI / 180)) / 4;
        const y = 50 + (radius * Math.sin(angle * Math.PI / 180)) / 4;
        
        return (
          <div
            key={alert.id}
            className="absolute w-24 h-16 bg-red-500/20 border border-red-400 rounded-lg p-2 backdrop-blur-sm animate-bounce"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              animationDelay: `${index * 0.2}s`,
              animationDuration: '3s'
            }}
          >
            <AlertTriangle className="w-4 h-4 text-red-400 mb-1" />
            <div className="text-xs text-white truncate">{alert.title}</div>
          </div>
        );
      })}

      {/* Supply Chain Links */}
      {data?.supplyChains?.slice(0, 4).map((chain, index) => (
        <div
          key={chain.id}
          className="absolute w-20 h-12 bg-orange-500/20 border border-orange-400 rounded-lg p-1 backdrop-blur-sm"
          style={{
            right: `${10 + index * 15}%`,
            bottom: `${20 + index * 10}%`
          }}
        >
          <Activity className="w-3 h-3 text-orange-400" />
          <div className="text-xs text-white truncate">{chain.supply_chain_name}</div>
        </div>
      ))}

      {/* VR Interface Elements */}
      <div className="absolute top-4 left-4 bg-black/70 text-white p-3 rounded-lg backdrop-blur-sm">
        <h3 className="font-semibold mb-2">🥽 VR War Room</h3>
        <div className="text-sm space-y-1">
          <div>Active Threats: {data?.alerts?.length || 0}</div>
          <div>Supply Chains: {data?.supplyChains?.length || 0}</div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span>Immersive Mode</span>
          </div>
        </div>
      </div>

      {/* VR Controls */}
      <div className="absolute bottom-4 right-4 bg-black/70 text-white p-3 rounded-lg backdrop-blur-sm">
        <div className="text-sm space-y-2">
          <button className="block w-full text-left hover:text-blue-400">🎮 Navigate Scene</button>
          <button className="block w-full text-left hover:text-blue-400">👆 Select Objects</button>
          <button className="block w-full text-left hover:text-blue-400">🔍 Zoom View</button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="absolute bottom-4 left-4 right-20 bg-black/70 text-white p-2 rounded-lg backdrop-blur-sm">
        <div className="flex justify-between items-center text-xs">
          <span>🌍 Immersive War Room - Global Intelligence</span>
          <span className="text-green-400">● VR READY</span>
        </div>
      </div>
    </div>
  );
}