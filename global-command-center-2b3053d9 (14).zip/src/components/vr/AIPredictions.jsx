import React, { useState, useEffect } from 'react';
import { BrainCircuit } from 'lucide-react';

const predictions = [
  "Predictive analysis indicates a 78% probability of market volatility in the energy sector within 48 hours.",
  "Geospatial intelligence flags anomalous activity in Sector Gamma-7. Recommend asset reallocation.",
  "Cyber threat models forecast an imminent phishing campaign targeting financial sector partners.",
  "Optimal supply chain route deviates through Alpha-Corridor due to emerging geopolitical friction."
];

export default function AIPredictions() {
  const [currentPrediction, setCurrentPrediction] = useState(predictions[0]);
  const [displayedText, setDisplayedText] = useState("");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const typingInterval = setInterval(() => {
      setDisplayedText(prev => prev + currentPrediction[displayedText.length]);
      if (displayedText.length === currentPrediction.length) {
        clearInterval(typingInterval);
        setTimeout(() => {
          const nextIndex = (index + 1) % predictions.length;
          setIndex(nextIndex);
          setCurrentPrediction(predictions[nextIndex]);
          setDisplayedText("");
        }, 3000); // Wait before showing next prediction
      }
    }, 30); // Typing speed

    return () => clearInterval(typingInterval);
  }, [displayedText, currentPrediction, index]);

  return (
    <div className="h-full flex flex-col">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
        <BrainCircuit size={20} className="mr-2 text-indigo-400" />
        Zyra AI Forecasts
      </h3>
      <div className="flex-grow font-mono text-sm text-cyan-300 p-3 bg-black/30 rounded-md">
        <p>{displayedText}<span className="animate-ping">|</span></p>
      </div>
    </div>
  );
}