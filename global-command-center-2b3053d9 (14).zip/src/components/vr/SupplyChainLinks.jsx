import React, { useMemo } from 'react';
import { Line } from '@react-three/drei';
import * as THREE from 'three';
import { regions as regionData } from '../data/regions';

const latLonToVector3 = (lat, lon, radius) => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

const regionLookup = Object.fromEntries(regionData.map(r => [r.name.toLowerCase(), r]));

function getCompanyLocation(companyName, companies) {
    const company = companies.find(c => c.company_name === companyName);
    if (!company || !company.headquarters_state) return null;
    const location = regionLookup[company.headquarters_state.toLowerCase()];
    return location ? latLonToVector3(location.lat, location.lng, 5.1) : null;
}

export default function SupplyChainLinks({ risks, companies }) {
  const links = useMemo(() => {
    if (!risks || !companies) return [];
    
    return risks.flatMap(risk => {
      if (!risk.key_dependencies || risk.key_dependencies.length < 2) return [];

      const startCompany = risk.key_dependencies[0].supplier;
      const endCompany = risk.key_dependencies[1].supplier;

      const startPos = getCompanyLocation(startCompany, companies);
      const endPos = getCompanyLocation(endCompany, companies);

      if (!startPos || !endPos) return [];
      
      const v1 = startPos;
      const v2 = endPos;
      
      const points = [];
      for (let i = 0; i <= 20; i++) {
        const p = new THREE.Vector3().lerpVectors(v1, v2, i / 20);
        p.normalize().multiplyScalar(5.1 + 0.2 * Math.sin(Math.PI * i / 20));
        points.push(p);
      }

      return {
        id: risk.id,
        points,
        color: risk.risk_level === 'CRITICAL' ? '#ff4d4d' : '#ffa500'
      };
    }).filter(Boolean);
  }, [risks, companies]);

  return (
    <group>
      {links.map(link => (
        <Line
          key={link.id}
          points={link.points}
          color={link.color}
          lineWidth={2}
          transparent
          opacity={0.7}
        />
      ))}
    </group>
  );
}