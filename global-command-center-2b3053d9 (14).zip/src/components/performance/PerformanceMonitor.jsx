import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Zap, Database, Wifi, Clock } from 'lucide-react';

export default function PerformanceMonitor() {
  const [metrics, setMetrics] = useState({
    pageLoadTime: 0,
    apiLatency: 0,
    memoryUsage: 0,
    connectionSpeed: 'unknown'
  });
  const [performanceData, setPerformanceData] = useState([]);

  useEffect(() => {
    // Measure page load performance
    if (typeof window !== 'undefined' && window.performance) {
      const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
      setMetrics(prev => ({ ...prev, pageLoadTime: loadTime }));
    }

    // Monitor performance periodically
    const interval = setInterval(() => {
      if (typeof window !== 'undefined' && window.performance) {
        const memory = window.performance.memory;
        const connectionInfo = navigator.connection;
        
        setMetrics(prev => ({
          ...prev,
          memoryUsage: memory ? Math.round(memory.usedJSHeapSize / 1048576) : 0,
          connectionSpeed: connectionInfo ? connectionInfo.effectiveType : 'unknown',
          apiLatency: Math.floor(Math.random() * 80) + 20 // Simulated API latency
        }));

        // Add data point for chart
        setPerformanceData(prev => {
          const newData = [...prev, {
            time: new Date().toLocaleTimeString(),
            memory: memory ? Math.round(memory.usedJSHeapSize / 1048576) : 0,
            loadTime: Math.random() * 100 + 200 // Simulated API response time
          }];
          return newData.slice(-10); // Keep last 10 data points
        });
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getPerformanceColor = (value, type) => {
    if (type === 'loadTime') {
      if (value < 1000) return 'text-green-400';
      if (value < 3000) return 'text-yellow-400';
      return 'text-red-400';
    }
    if (type === 'memory') {
      if (value < 50) return 'text-green-400';
      if (value < 100) return 'text-yellow-400';
      return 'text-red-400';
    }
     if (type === 'api') {
      if (value < 150) return 'text-green-400';
      if (value < 300) return 'text-yellow-400';
      return 'text-red-400';
    }
    return 'text-blue-400';
  };

  return (
    <div className="space-y-6">
      {/* Performance Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Clock className="w-8 h-8 text-blue-400" />
              <div>
                <p className={`text-2xl font-bold ${getPerformanceColor(metrics.pageLoadTime, 'loadTime')}`}>
                  {metrics.pageLoadTime}ms
                </p>
                <p className="text-sm text-gray-400">Page Load Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Zap className="w-8 h-8 text-yellow-400" />
              <div>
                 <p className={`text-2xl font-bold ${getPerformanceColor(metrics.apiLatency, 'api')}`}>
                  {metrics.apiLatency}ms
                </p>
                <p className="text-sm text-gray-400">API Latency</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Database className="w-8 h-8 text-purple-400" />
              <div>
                <p className={`text-2xl font-bold ${getPerformanceColor(metrics.memoryUsage, 'memory')}`}>
                  {metrics.memoryUsage}MB
                </p>
                <p className="text-sm text-gray-400">Memory Usage</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Wifi className="w-8 h-8 text-green-400" />
              <div>
                <p className="text-2xl font-bold text-white uppercase">{metrics.connectionSpeed}</p>
                <p className="text-sm text-gray-400">Connection</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Performance Chart */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="text-white">Real-time Performance</CardTitle>
        </CardHeader>
        <CardContent className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9CA3AF" fontSize={12} />
              <YAxis yAxisId="left" stroke="#8B5CF6" fontSize={12} label={{ value: 'Memory (MB)', angle: -90, position: 'insideLeft', fill: '#8B5CF6' }} />
              <YAxis yAxisId="right" orientation="right" stroke="#10B981" fontSize={12} label={{ value: 'Response (ms)', angle: 90, position: 'insideRight', fill: '#10B981' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(10, 13, 24, 0.8)',
                  borderColor: '#374151',
                  color: '#fff'
                }}
              />
              <Line yAxisId="left" type="monotone" dataKey="memory" stroke="#8B5CF6" strokeWidth={2} dot={false} name="Memory" />
              <Line yAxisId="right" type="monotone" dataKey="loadTime" stroke="#10B981" strokeWidth={2} dot={false} name="API Response" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}