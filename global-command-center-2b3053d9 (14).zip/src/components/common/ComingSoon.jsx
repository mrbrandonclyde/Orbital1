import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function ComingSoon({ title, subtitle, children }) {
  return (
    <Card className="bg-[#0A0D18]/60 border border-gray-800 rounded-3xl mb-6">
      <CardHeader>
        <CardTitle className="text-white">{title}</CardTitle>
        {subtitle && <p className="text-gray-400 text-sm mt-1">{subtitle}</p>}
      </CardHeader>
      <CardContent className="text-gray-300 text-sm">
        <div className="p-4 rounded-xl bg-[#0C0F19]/60 border border-gray-800">
          <p className="text-gray-300 mb-3">This module is scaffolded and ready for backend wiring.</p>
          <ul className="list-disc list-inside space-y-1 text-gray-400">
            <li>Frontend routes and UI ready</li>
            <li>Backend hooks prepared</li>
            <li>Extensible for FastAPI endpoints, Redis jobs, and analytics</li>
          </ul>
        </div>
        {children && <div className="mt-4">{children}</div>}
      </CardContent>
    </Card>
  );
}