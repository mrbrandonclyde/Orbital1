import React, { useState } from 'react';
import { Check, ChevronDown, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

export function MultiSelect({ options, selected, onChange, placeholder = "Select items..." }) {
  const [open, setOpen] = useState(false);

  const handleSelect = (value) => {
    const newSelected = selected.includes(value)
      ? selected.filter(item => item !== value)
      : [...selected, value];
    onChange(newSelected);
  };

  const handleRemove = (value) => {
    onChange(selected.filter(item => item !== value));
  };

  const selectedOptions = options.filter(option => selected.includes(option.value));

  return (
    <div className="space-y-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between bg-[#0C0F19] border-gray-600 hover:bg-[#0C0F19]"
          >
            <span className="truncate">
              {selected.length > 0 ? `${selected.length} selected` : placeholder}
            </span>
            <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0 bg-[#0C0F19] border-gray-600">
          <div className="max-h-60 overflow-auto">
            {options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 p-2 cursor-pointer hover:bg-gray-800"
                onClick={() => handleSelect(option.value)}
              >
                <div className="flex h-4 w-4 items-center justify-center rounded-sm border border-gray-600">
                  {selected.includes(option.value) && (
                    <Check className="h-3 w-3 text-green-400" />
                  )}
                </div>
                <span className="text-sm text-white">{option.label}</span>
              </div>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {selectedOptions.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {selectedOptions.map((option) => (
            <div
              key={option.value}
              className="inline-flex items-center gap-1 bg-indigo-600/20 text-indigo-300 px-2 py-1 rounded text-xs"
            >
              <span>{option.label}</span>
              <button
                type="button"
                onClick={() => handleRemove(option.value)}
                className="hover:text-indigo-100"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}