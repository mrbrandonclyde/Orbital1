import React, { useState, useEffect } from 'react';
import { Brain, Zap, Share2, MemoryStick, Target } from 'lucide-react';
import { motion } from 'framer-motion';

const CognitiveMetric = ({ icon: Icon, label, value, color, sublabel }) => (
  <div className="bg-gray-800/50 p-4 rounded-lg text-center">
    <Icon className={`w-8 h-8 mx-auto mb-2 ${color}`} />
    <p className={`text-xl font-bold ${color}`}>{value}</p>
    <p className="text-sm text-gray-300">{label}</p>
    {sublabel && <p className="text-xs text-gray-500 mt-1">{sublabel}</p>}
  </div>
);

const DecisionPartnership = ({ decision, human_input, ai_analysis, outcome, confidence }) => (
  <div className="bg-gray-800/30 p-4 rounded-lg">
    <div className="flex justify-between items-start mb-3">
      <div>
        <h5 className="text-white font-semibold">{decision}</h5>
        <p className="text-xs text-gray-400">{human_input} + {ai_analysis}</p>
      </div>
      <span className={`text-xs px-2 py-1 rounded-full ${
        confidence >= 90 ? 'bg-green-500/20 text-green-400' :
        confidence >= 70 ? 'bg-blue-500/20 text-blue-400' :
        'bg-yellow-500/20 text-yellow-400'
      }`}>
        {confidence}% Confidence
      </span>
    </div>
    <p className="text-sm text-gray-300">{outcome}</p>
  </div>
);

const MemoryAnchor = ({ type, content, stability, last_accessed }) => (
  <div className="bg-gray-800/50 p-3 rounded-lg">
    <div className="flex items-center justify-between mb-2">
      <span className="text-white font-medium">{type}</span>
      <span className={`text-xs px-2 py-1 rounded-full ${
        stability >= 95 ? 'bg-green-500/20 text-green-400' :
        stability >= 85 ? 'bg-blue-500/20 text-blue-400' :
        'bg-yellow-500/20 text-yellow-400'
      }`}>
        {stability}% Stable
      </span>
    </div>
    <p className="text-xs text-gray-400">{content}</p>
    <p className="text-xs text-gray-500 mt-1">Last accessed: {last_accessed}</p>
  </div>
);

export default function CognitiveFrame() {
  const [cognitiveMetrics, setCognitiveMetrics] = useState({
    jointDecisions: 247,
    memoryAnchors: 1892,
    learningFeedback: 98.4,
    cognitiveSync: 96.7
  });

  const [jointDecisions] = useState([
    {
      decision: 'Mars Colony Resource Allocation',
      human_input: 'Strategic priorities',
      ai_analysis: 'Optimization algorithms',
      outcome: 'Efficient distribution achieved',
      confidence: 94
    },
    {
      decision: 'Guardian Training Protocol Update',
      human_input: 'Experience-based insights',
      ai_analysis: 'Performance data modeling',
      outcome: 'Enhanced effectiveness by 23%',
      confidence: 97
    },
    {
      decision: 'Interplanetary Communication Strategy',
      human_input: 'Diplomatic considerations',
      ai_analysis: 'Network optimization',
      outcome: 'Latency reduced by 45%',
      confidence: 89
    }
  ]);

  const [memoryAnchors] = useState([
    {
      type: 'Mission Critical Knowledge',
      content: 'Emergency protocols, survival strategies, system overrides',
      stability: 99,
      last_accessed: '2 hours ago'
    },
    {
      type: 'Tactical Experience Database',
      content: 'Combat scenarios, threat responses, team coordination',
      stability: 97,
      last_accessed: '4 hours ago'
    },
    {
      type: 'Scientific Research Archives',
      content: 'Discovery logs, experimental data, hypothesis tracking',
      stability: 95,
      last_accessed: '1 day ago'
    },
    {
      type: 'Personal Memory Integration',
      content: 'Individual experiences, emotional context, personal growth',
      stability: 93,
      last_accessed: '30 minutes ago'
    }
  ]);

  // Simulate real-time cognitive updates
  useEffect(() => {
    const interval = setInterval(() => {
      setCognitiveMetrics(prev => ({
        jointDecisions: prev.jointDecisions + Math.floor(Math.random() * 3),
        memoryAnchors: prev.memoryAnchors + Math.floor(Math.random() * 5),
        learningFeedback: Math.max(95, Math.min(100, prev.learningFeedback + (Math.random() - 0.5) * 0.5)),
        cognitiveSync: Math.max(94, Math.min(100, prev.cognitiveSync + (Math.random() - 0.5) * 0.8))
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <CognitiveMetric 
          icon={Target} 
          label="Joint Decisions" 
          value={cognitiveMetrics.jointDecisions} 
          color="text-purple-400" 
          sublabel="Today"
        />
        <CognitiveMetric 
          icon={MemoryStick} 
          label="Memory Anchors" 
          value={cognitiveMetrics.memoryAnchors} 
          color="text-cyan-400" 
          sublabel="Active"
        />
        <CognitiveMetric 
          icon={Zap} 
          label="Learning Feedback" 
          value={`${cognitiveMetrics.learningFeedback.toFixed(1)}%`} 
          color="text-green-400" 
          sublabel="Adaptive"
        />
        <CognitiveMetric 
          icon={Share2} 
          label="Cognitive Sync" 
          value={`${cognitiveMetrics.cognitiveSync.toFixed(1)}%`} 
          color="text-orange-400" 
          sublabel="Partnership"
        />
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Brain className="w-5 h-5 mr-3 text-purple-400" />
          Human-AI Joint Decision Making
        </h4>
        <div className="space-y-4">
          {jointDecisions.map((decision, index) => (
            <DecisionPartnership key={index} {...decision} />
          ))}
        </div>
      </div>

      <div className="glass-pane p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <MemoryStick className="w-5 h-5 mr-3 text-cyan-400" />
          Memory Co-Anchoring System
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {memoryAnchors.map((anchor, index) => (
            <MemoryAnchor key={index} {...anchor} />
          ))}
        </div>
      </div>
    </motion.div>
  );
}