import React, { useState, useEffect } from 'react';
import { OSINTFeed } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Radio, Globe, TrendingUp, AlertTriangle, Eye, Calendar } from 'lucide-react';

export default function OSINTFeedMonitor({ sectors = ['all'] }) {
  const [osintFeeds, setOsintFeeds] = useState([]);
  const [loading, setLoading] = useState(false);

  const generateOSINTData = async () => {
    setLoading(true);
    try {
      const mockData = await InvokeLLM({
        prompt: `Generate 12 realistic OSINT (Open Source Intelligence) feed entries for global monitoring. Include:
        - Mix of news sources (Reuters, BBC, Bloomberg, Financial Times)
        - Recent timestamps (within last 24 hours)
        - Geographic focus on different regions
        - Various sectors: technology, defense, energy, finance
        - Realistic sentiment scores (-1 to 1)
        - Credibility scores (70-95)
        - Include some threat indicators and keywords`,
        response_json_schema: {
          type: "object",
          properties: {
            feeds: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  feed_id: { type: "string" },
                  source_type: { type: "string" },
                  source_name: { type: "string" },
                  title: { type: "string" },
                  content: { type: "string" },
                  publication_date: { type: "string" },
                  language: { type: "string" },
                  geographic_focus: { type: "array", items: { type: "string" } },
                  sector_relevance: { type: "array", items: { type: "string" } },
                  keywords: { type: "array", items: { type: "string" } },
                  sentiment_score: { type: "number" },
                  credibility_score: { type: "number" },
                  threat_indicators: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setOsintFeeds(mockData.feeds || []);
    } catch (error) {
      console.error('Failed to generate OSINT data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateOSINTData();
    // Refresh every 5 minutes
    const interval = setInterval(generateOSINTData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const getSentimentColor = (score) => {
    if (score > 0.3) return 'text-green-400';
    if (score > -0.3) return 'text-gray-400';
    return 'text-red-400';
  };

  const getSentimentIcon = (score) => {
    if (score > 0.3) return '📈';
    if (score > -0.3) return '➖';
    return '📉';
  };

  const getThreatLevel = (indicators) => {
    if (!indicators || indicators.length === 0) return 'LOW';
    if (indicators.length > 3) return 'HIGH';
    return 'MEDIUM';
  };

  const getThreatColor = (level) => {
    switch (level) {
      case 'HIGH': return 'text-red-400';
      case 'MEDIUM': return 'text-yellow-400';
      default: return 'text-green-400';
    }
  };

  if (loading) {
    return (
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Radio className="w-6 h-6 text-purple-400 animate-pulse" />
          <h3 className="text-xl font-semibold text-white">OSINT Feed Monitor</h3>
        </div>
        <div className="animate-pulse space-y-3">
          {[1,2,3,4].map(i => (
            <div key={i} className="h-24 bg-gray-800/30 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Radio className="w-6 h-6 text-purple-400" />
          <h3 className="text-xl font-semibold text-white">OSINT Feed Monitor</h3>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-gray-400">Live Intelligence</span>
          </div>
          <button 
            onClick={generateOSINTData}
            className="text-xs text-purple-400 hover:text-purple-300 transition-colors"
          >
            <Eye className="w-4 h-4 inline mr-1" />
            Refresh
          </button>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {osintFeeds.slice(0, 8).map((feed, index) => {
          const threatLevel = getThreatLevel(feed.threat_indicators);
          return (
            <div key={index} className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 transition-all">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-sm font-medium text-purple-400">{feed.source_name}</span>
                    <span className="text-xs text-gray-500">{feed.source_type?.replace('_', ' ')}</span>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3 text-gray-500" />
                      <span className="text-xs text-gray-500">
                        {new Date(feed.publication_date).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                  <h4 className="font-medium text-white text-sm mb-1">{feed.title}</h4>
                  <p className="text-xs text-gray-400 line-clamp-2">{feed.content}</p>
                </div>
                <div className="ml-4 text-right">
                  <div className="flex items-center space-x-1 mb-1">
                    <span className="text-xs">{getSentimentIcon(feed.sentiment_score)}</span>
                    <span className={`text-xs font-medium ${getSentimentColor(feed.sentiment_score)}`}>
                      {feed.sentiment_score > 0 ? '+' : ''}{(feed.sentiment_score * 100).toFixed(0)}
                    </span>
                  </div>
                  <div className="text-xs text-gray-400">
                    {feed.credibility_score}% credible
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex flex-wrap gap-1">
                  {feed.geographic_focus?.slice(0, 3).map((region, i) => (
                    <span key={i} className="text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded">
                      {region}
                    </span>
                  ))}
                  {feed.sector_relevance?.slice(0, 2).map((sector, i) => (
                    <span key={i} className="text-xs px-2 py-1 bg-green-500/20 text-green-400 rounded">
                      {sector}
                    </span>
                  ))}
                </div>
                
                <div className="flex items-center space-x-2">
                  {feed.threat_indicators && feed.threat_indicators.length > 0 && (
                    <div className="flex items-center space-x-1">
                      <AlertTriangle className="w-3 h-3 text-orange-400" />
                      <span className={`text-xs font-medium ${getThreatColor(threatLevel)}`}>
                        {threatLevel} THREAT
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {feed.keywords && feed.keywords.length > 0 && (
                <div className="mt-2 text-xs text-gray-500">
                  <span className="font-medium">Keywords: </span>
                  {feed.keywords.slice(0, 4).join(', ')}
                  {feed.keywords.length > 4 && '...'}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4 text-xs text-center">
        <div>
          <div className="text-white font-semibold">{osintFeeds.length}</div>
          <div className="text-gray-400">Total Feeds</div>
        </div>
        <div>
          <div className="text-red-400 font-semibold">
            {osintFeeds.filter(f => getThreatLevel(f.threat_indicators) === 'HIGH').length}
          </div>
          <div className="text-gray-400">High Threat</div>
        </div>
        <div>
          <div className="text-purple-400 font-semibold">
            {osintFeeds.filter(f => f.credibility_score > 85).length}
          </div>
          <div className="text-gray-400">High Credibility</div>
        </div>
      </div>
    </div>
  );
}