
import React from "react";
import { Layout, Type, Image as ImageIcon, Video, ShoppingCart, Grid2X2, Puzzle, Settings, MapPin, Calendar, Code2, MessageSquare, BadgePercent, Quote, Timer, Star } from "lucide-react";

export const blockLibrary = {
  sections: [
    { type: "section_hero", label: "Hero", icon: Layout, defaultData: () => ({ bg: "#0b1220", padding: "48", align: "center", heading: "Your Big Promise", subtext: "Explain the value in one line", cta: { label: "Get Started", href: "#" } }) },
    { type: "section_features", label: "Features", icon: Grid2X2, defaultData: () => ({ cols: 3, items: ["Feature A", "Feature B", "Feature C"] }) },
    { type: "section_testimonials", label: "Testimonials", icon: Quote, defaultData: () => ({ quotes: ["This is amazing.", "Best product ever."] }) },
    { type: "section_pricing", label: "Pricing", icon: BadgePercent, defaultData: () => ({ plans: [{ name: "Basic", price: "$19" }, { name: "Pro", price: "$49" }] }) },
    { type: "section_faq", label: "FAQ", icon: Puzzle, defaultData: () => ({ items: [{ q: "How does it work?", a: "Short answer." }] }) },
    { type: "section_footer", label: "Footer", icon: Settings, defaultData: () => ({ text: "© Your Brand. All rights reserved." }) },
  ],
  elements: [
    { type: "heading", label: "Headline", icon: Type, defaultData: () => ({ text: "Headline goes here", level: "h2" }) },
    { type: "text", label: "Text", icon: MessageSquare, defaultData: () => ({ text: "Write something compelling." }) },
    { type: "image", label: "Image", icon: ImageIcon, defaultData: () => ({ src: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&q=60", alt: "Image" }) },
    { type: "video", label: "Video", icon: Video, defaultData: () => ({ url: "https://www.youtube.com/embed/dQw4w9WgXcQ" }) },
    { type: "button", label: "Button", icon: Layout, defaultData: () => ({ label: "Click Me", href: "#" }) },
    { type: "divider", label: "Divider", icon: Layout, defaultData: () => ({ style: "solid" }) },
    { type: "countdown", label: "Countdown", icon: Timer, defaultData: () => ({ seconds: 3600 }) },
    { type: "icon", label: "Icon", icon: Star, defaultData: () => ({ name: "star", size: 32, color: "#fbbf24" }) },
  ],
  forms: [
    { type: "form_input", label: "Input", icon: Type, defaultData: () => ({ placeholder: "Your email", name: "email" }) },
    { type: "form_checkbox", label: "Checkbox", icon: Puzzle, defaultData: () => ({ label: "I agree", name: "agree" }) },
    { type: "form_hidden", label: "Hidden", icon: Settings, defaultData: () => ({ name: "ref", value: "internal" }) },
    { type: "form_multistep", label: "Multi‑step", icon: Grid2X2, defaultData: () => ({ steps: 2 }) },
    { type: "form_submit", label: "Submit", icon: Layout, defaultData: () => ({ label: "Submit" }) },
  ],
  ecommerce: [
    { type: "product", label: "Product", icon: ShoppingCart, defaultData: () => ({ name: "Sample Product", price: "$49" }) },
    { type: "checkout_1step", label: "Checkout (1‑step)", icon: ShoppingCart, defaultData: () => ({ fields: ["name", "email", "card"], layout: "one" }) },
    { type: "checkout_2step", label: "Checkout (2‑step)", icon: ShoppingCart, defaultData: () => ({ step1: ["email"], step2: ["shipping","card"] }) },
    { type: "order_bump", label: "Order Bump", icon: ShoppingCart, defaultData: () => ({ text: "Add order bump for $9" }) },
    { type: "upsell", label: "Upsell", icon: ShoppingCart, defaultData: () => ({ headline: "One‑time Offer", price: "$29" }) },
    { type: "downsell", label: "Downsell", icon: ShoppingCart, defaultData: () => ({ headline: "Wait! Special price", price: "$19" }) },
  ],
  layout: [
    { type: "container", label: "Container", icon: Layout, defaultData: () => ({ padding: "24" }) },
    { type: "row", label: "Row", icon: Grid2X2, defaultData: () => ({ columns: 2 }) },
    { type: "grid", label: "Grid", icon: Grid2X2, defaultData: () => ({ columns: 3, gap: "16" }) },
  ],
  widgets: [
    { type: "social_proof", label: "Social Proof", icon: MessageSquare, defaultData: () => ({ text: "John just purchased!" }) },
    { type: "chat_widget", label: "Chat Widget", icon: MessageSquare, defaultData: () => ({ provider: "default" }) },
    { type: "map", label: "Map", icon: MapPin, defaultData: () => ({ lat: 40.7128, lng: -74.0060 }) },
    { type: "calendar", label: "Calendar", icon: Calendar, defaultData: () => ({ provider: "cal", link: "#" }) },
    { type: "code_block", label: "Code Block", icon: Code2, defaultData: () => ({ code: "<div>Hello</div>" }) },
  ],
};

export function makeBlock(type) {
  const lib = Object.values(blockLibrary).flat();
  const item = lib.find(i => i.type === type);
  const data = item?.defaultData ? item.defaultData() : {};
  return {
    id: `b_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
    type,
    data,
    style: {},
    children: []
  };
}
