
import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function PropertiesPanel({ selectedBlock, onChange, onDelete, onDeselect, pageSettings, onPageSettings }) {
  return (
    <aside className="w-full lg:w-80 bg-[#0A0D18]/80 border border-gray-800 rounded-xl h-full overflow-y-auto sidebar-scroll">
      <div className="p-4 border-b border-gray-800">
        <p className="text-xs uppercase text-gray-500 mb-1">Properties</p>
        <h3 className="text-white font-semibold">{selectedBlock ? "Block Settings" : "Page Settings"}</h3>
      </div>

      <div className="p-4 space-y-4">
        {/* Page Settings */}
        {!selectedBlock && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-gray-400">SEO Title</Label>
                <Input value={pageSettings.seo_title || ""} onChange={(e) => onPageSettings({ ...pageSettings, seo_title: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">SEO Description</Label>
                <Textarea value={pageSettings.seo_description || ""} onChange={(e) => onPageSettings({ ...pageSettings, seo_description: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[80px]" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Primary Color</Label>
                <Input value={pageSettings.primary_color || ""} onChange={(e) => onPageSettings({ ...pageSettings, primary_color: e.target.value })} placeholder="#06B6D4" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Background</Label>
                <Input value={pageSettings.background || ""} onChange={(e) => onPageSettings({ ...pageSettings, background: e.target.value })} placeholder="#0A0D18 or gradient" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Base Font Size</Label>
                <Input value={pageSettings.base_font_size || ""} onChange={(e) => onPageSettings({ ...pageSettings, base_font_size: e.target.value })} placeholder="16px" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Common Styles for any selected block */}
        {selectedBlock && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">Common Styles</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-gray-400">Padding (px)</Label>
                <Input
                  value={selectedBlock.style?.padding ?? ""}
                  onChange={(e) => onChange({ ...selectedBlock, style: { ...selectedBlock.style, padding: e.target.value } })}
                  placeholder="24"
                  className="bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Text Color</Label>
                <Input
                  value={selectedBlock.style?.textColor ?? ""}
                  onChange={(e) => onChange({ ...selectedBlock, style: { ...selectedBlock.style, textColor: e.target.value } })}
                  placeholder="#ffffff"
                  className="bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Background</Label>
                <Input
                  value={selectedBlock.style?.bgColor ?? ""}
                  onChange={(e) => onChange({ ...selectedBlock, style: { ...selectedBlock.style, bgColor: e.target.value } })}
                  placeholder="#0A0D18"
                  className="bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <Separator className="bg-gray-800 my-2" />
            </CardContent>
          </Card>
        )}

        {selectedBlock?.type === "heading" && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">Headline</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-gray-400">Text</Label>
                <Input value={selectedBlock.data.text || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, text: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Level (h1–h3)</Label>
                <Input value={selectedBlock.data.level || "h2"} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, level: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
            </CardContent>
          </Card>
        )}

        {selectedBlock?.type === "text" && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">Text</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <Label className="text-xs text-gray-400">Content</Label>
              <Textarea value={selectedBlock.data.text || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, text: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[120px]" />
            </CardContent>
          </Card>
        )}

        {selectedBlock?.type === "image" && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">Image</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-gray-400">Image URL</Label>
                <Input value={selectedBlock.data.src || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, src: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">Alt Text</Label>
                <Input value={selectedBlock.data.alt || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, alt: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
            </CardContent>
          </Card>
        )}

        {selectedBlock?.type === "button" && (
          <Card className="bg-[#0A0D18]/40 border-gray-800 rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">Button</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-gray-400">Label</Label>
                <Input value={selectedBlock.data.label || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, label: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <div>
                <Label className="text-xs text-gray-400">URL</Label>
                <Input value={selectedBlock.data.href || ""} onChange={(e) => onChange({ ...selectedBlock, data: { ...selectedBlock.data, href: e.target.value } })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
            </CardContent>
          </Card>
        )}

        {selectedBlock && (
          <div className="flex items-center justify-between">
            <Button variant="secondary" onClick={onDeselect}>Deselect</Button>
            <Button variant="destructive" onClick={() => onDelete(selectedBlock.id)}>Delete Block</Button>
          </div>
        )}
      </div>
    </aside>
  );
}
