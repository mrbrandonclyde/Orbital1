import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard, Users, ArrowLeftRight, CreditCard, Building, TrendingUp,
  PieChart, Shield, AlertTriangle, FileText, Settings
} from "lucide-react";

const items = [
  { name: "Dashboard", icon: LayoutDashboard, page: "Phase1Dashboard" },
  { name: "Accounts", icon: Users, page: "Phase1Accounts" },
  { name: "Transactions", icon: ArrowLeftRight, page: "Phase1Transactions" },
  { name: "Credit & Cards", icon: CreditCard, page: "Phase1CreditCards" },
  { name: "Loans & Mortgages", icon: Building, page: "Phase1LoansMortgages" },
  { name: "Investments", icon: TrendingUp, page: "Phase1Investments" },
  { name: "Analytics", icon: PieChart, page: "Phase1Analytics" },
  { name: "Compliance", icon: Shield, page: "Phase1Compliance" },
  { name: "Risk Alerts", icon: AlertTriangle, page: "Phase1RiskAlerts" },
  { name: "Reports", icon: FileText, page: "Phase1Reports" },
  { name: "Settings", icon: Settings, page: "Phase1Settings" },
];

export default function SidebarFrame({ orientation = "horizontal" }) {
  if (orientation === "horizontal") {
    return (
      <div className="w-full overflow-x-auto rounded-xl border border-gray-800 bg-[#0A0D18]/60 p-2 mb-4">
        <div className="flex min-w-max gap-1">
          {items.map((it) => (
            <Link
              key={it.name}
              to={createPageUrl(it.page)}
              className="px-3 py-2 rounded-lg text-xs bg-[#0C0F19] border border-gray-700 text-gray-300 hover:text-white hover:border-cyan-500/40 flex items-center gap-2"
              title={it.name}
            >
              <it.icon className="w-4 h-4 text-gray-400" />
              <span>{it.name}</span>
            </Link>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-64 rounded-xl border border-gray-800 bg-[#0A0D18]/60 p-2">
      <nav className="space-y-1">
        {items.map((it) => (
          <Link
            key={it.name}
            to={createPageUrl(it.page)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-gray-300 hover:text-white hover:bg-gray-800/40"
          >
            <it.icon className="w-4 h-4 text-gray-400" />
            <span>{it.name}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}