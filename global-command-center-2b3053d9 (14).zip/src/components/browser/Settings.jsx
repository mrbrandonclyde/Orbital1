import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function BrowserSettings({ settings, onChange }) {
  const setToggle = (group, key, v) => {
    onChange(prev => ({ ...prev, [group]: { ...prev[group], [key]: v } }));
  };

  const setRoot = (key, v) => {
    onChange(prev => ({ ...prev, [key]: v }));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white text-base">Module Toggles</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            {g:"module_toggles", k:"ai_enabled", label:"AI Copilot"},
            {g:"module_toggles", k:"vault_enabled", label:"Vault"},
            {g:"module_toggles", k:"missions_enabled", label:"Missions"},
            {g:"module_toggles", k:"contracts_enabled", label:"AI Contracts"},
          ].map(item=>(
            <div key={item.k} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">{item.label}</Label>
              <Switch checked={!!settings[item.g]?.[item.k]} onCheckedChange={(v)=>setToggle(item.g, item.k, v)} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white text-base">API Connectors</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            {g:"connectors", k:"crm", label:"CRM"},
            {g:"connectors", k:"banking", label:"Banking"},
            {g:"connectors", k:"blockchain", label:"Blockchain"},
            {g:"connectors", k:"global_ops", label:"Global Ops"},
          ].map(item=>(
            <div key={item.k} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">{item.label}</Label>
              <Switch checked={!!settings[item.g]?.[item.k]} onCheckedChange={(v)=>setToggle(item.g, item.k, v)} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white text-base">Offline & Security</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Root-level toggle */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <Label className="text-gray-300">Offline-first</Label>
            <Switch checked={!!settings.offline_first} onCheckedChange={(v)=>setRoot("offline_first", v)} />
          </div>

          {[
            {g:"security", k:"proton_layer", label:"Proton Layer"},
            {g:"security", k:"tls_1_3", label:"TLS 1.3+"},
            {g:"security", k:"pqc_ready", label:"PQC Ready"},
            {g:"security", k:"zero_trust", label:"Zero-Trust"},
          ].map(item=>(
            <div key={`${item.g}-${item.k}`} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">{item.label}</Label>
              <Switch checked={!!settings[item.g]?.[item.k]} onCheckedChange={(v)=>setToggle(item.g, item.k, v)} />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}