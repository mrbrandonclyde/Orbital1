import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Map, MapPin } from "lucide-react";

export default function CityMap({ project, zones = [], assets = [] }) {
  return (
    <Card className="bg-[#0A0D18]/50 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Map className="w-5 h-5 mr-2 text-cyan-400" />
          City Map Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64 w-full rounded-lg bg-gradient-to-b from-gray-900 to-black border border-gray-800 flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-grid opacity-30" />
          <div className="text-center">
            <p className="text-white font-semibold">Map interface</p>
            <p className="text-gray-400 text-sm">Interactive mapping can be enabled later</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-sm">
          <div className="p-3 bg-gray-800/30 rounded-lg">
            <div className="text-gray-400">Center</div>
            <div className="text-white">{project?.center_lat?.toFixed?.(3) || "-"}, {project?.center_lng?.toFixed?.(3) || "-"}</div>
          </div>
          <div className="p-3 bg-gray-800/30 rounded-lg">
            <div className="text-gray-400">Zones</div>
            <div className="text-white">{zones.length}</div>
          </div>
          <div className="p-3 bg-gray-800/30 rounded-lg">
            <div className="text-gray-400">Assets</div>
            <div className="text-white">{assets.length}</div>
          </div>
        </div>
        {zones.length > 0 && (
          <div className="mt-4 text-xs text-gray-400 flex items-center">
            <MapPin className="w-4 h-4 mr-2 text-purple-400" />
            Example markers would be placed for each zone and asset.
          </div>
        )}
      </CardContent>
    </Card>
  );
}