import React from "react";
import SpeedBackend from "@/components/lib/SpeedBackend";
import BackendHealthBadge from "@/components/common/BackendHealthBadge";
import SpeedBackendScaffold from "@/components/docs/SpeedBackendScaffold";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { BarChart3, TrendingUp, RefreshCw, Download, FileDown, DollarSign, Layers, PieChart as PieIcon, Calendar as CalendarIcon } from "lucide-react";
import {
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

function NumberStat({ label, value, icon: Icon, color }) {
  return (
    <div className="glass-pane p-4">
      <div className="flex justify-between items-start">
        <p className="text-sm font-medium text-gray-400">{label}</p>
        {Icon && <Icon className={`w-6 h-6 ${color || "text-cyan-400"}`} />}
      </div>
      <p className="text-3xl font-bold mt-2 text-white">{value}</p>
    </div>
  );
}

function ChartTooltip({ active, payload, label }) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="text-white font-medium mb-1">{label}</p>
        {payload.map((entry, idx) => (
          <p key={idx} style={{ color: entry.color || entry.stroke || entry.fill }}>
            {entry.name}: {typeof entry.value === "number" ? entry.value.toLocaleString() : entry.value}
            {entry.unit ? entry.unit : ""}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

export default function FunnelAnalytics() {
  const [metrics, setMetrics] = React.useState([]);
  const [activeId, setActiveId] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [showScaffold, setShowScaffold] = React.useState(false);
  const [revenueApi, setRevenueApi] = React.useState(null);

  const load = async () => {
    setLoading(true);
    const backendData = await SpeedBackend.analytics.funnel();
    const list = Array.isArray(backendData) ? backendData : [];
    const normalized = list.map((m, idx) => ({ id: m.id ?? String(idx), ...m }));
    setMetrics(normalized);
    if (!activeId && normalized.length) { 
      setActiveId(normalized[0].id);
    }
    setLoading(false);
  };

  React.useEffect(() => {
    const fetchInitial = async () => {
      setLoading(true);
      try {
        const list = await SpeedBackend.analytics.funnel();
        const normalized = (Array.isArray(list) ? list : []).map((m, idx) => ({ id: m.id ?? String(idx), ...m }));
        setMetrics(normalized);
        setActiveId((prev) => prev ?? (normalized[0]?.id));
      } finally {
        setLoading(false);
      }
    };
    fetchInitial();
  }, []);

  const active = React.useMemo(() => metrics.find(m => m.id === activeId) || metrics[0], [metrics, activeId]);

  React.useEffect(() => {
    let ignore = false;
    const fetchRevenue = async () => {
      if (!active) {
        setRevenueApi(null);
        return;
      }
      const params = {};
      if (active?.funnel_id) params.funnel_id = active.funnel_id;
      if (active?.period_start) params.period_start = active.period_start;
      if (active?.period_end) params.period_end = active.period_end;
      try {
        const res = await SpeedBackend.analytics.revenue(params);
        if (!ignore) setRevenueApi(res);
      } catch (e) {
        console.error("Failed to fetch revenue API data:", e);
        if (!ignore) setRevenueApi(null);
      }
    };
    fetchRevenue();
    return () => { ignore = true; };
  }, [active]);

  const revenueObj = React.useMemo(() => {
    if (revenueApi && typeof revenueApi === 'object') return revenueApi;
    return active?.revenue || null;
  }, [revenueApi, active?.revenue]);

  const productBreakdown = React.useMemo(() => {
    const byProduct = revenueObj?.by_product || active?.revenue?.by_product || [];
    return byProduct.map(p => ({ name: p.product_name, value: Number(p.revenue || 0) }));
  }, [revenueObj?.by_product, active?.revenue?.by_product]);

  const stepDropoff = React.useMemo(() => {
    const steps = active?.step_stats || [];
    return steps.map((s, idx) => ({
      step: s.step_name,
      views: Number(s.views || 0),
      conversions: Number(s.conversions || 0),
      dropoff: Math.max(Number(s.views || 0) - Number(s.conversions || 0), 0),
      index: idx + 1
    }));
  }, [active?.step_stats]);

  const pagePerf = React.useMemo(() => {
    return (active?.page_stats || []).map(p => ({
      page: p.step_name,
      views: Number(p.views || 0),
      bounce_rate: Number(p.bounce_rate || 0)
    }));
  }, [active?.page_stats]);

  const exportCSV = () => {
    if (!active) return;
    const lines = [];
    lines.push(["Funnel", active.funnel_name || "—"].join(","));
    lines.push(["Period", `${active.period_start || ""} - ${active.period_end || ""}`].join(","));
    lines.push([]);
    lines.push(["Visitors", "Leads", "Customers", "Conv %"].join(","));
    lines.push([active.visitors || 0, active.leads || 0, active.customers || 0, active.conversion_rate || 0].join(","));
    lines.push([]);
    lines.push(["Step", "Views", "Conversions", "Drop-off"].join(","));
    (active.step_stats || []).forEach(s => {
      lines.push([s.step_name, s.views, s.conversions, (Number(s.views || 0) - Number(s.conversions || 0))].join(","));
    });
    lines.push([]);
    lines.push(["Page", "Views", "Bounce %"].join(","));
    (active.page_stats || []).forEach(p => {
      lines.push([p.step_name, p.views, p.bounce_rate].join(","));
    });
    lines.push([]);
    lines.push(["Product", "Orders", "Revenue", "AOV"].join(","));
    (revenueObj?.by_product || []).forEach(p => {
      lines.push([p.product_name, p.orders || 0, p.revenue || 0, p.aov || 0].join(","));
    });

    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const name = (active.funnel_name || "funnel").toLowerCase().replace(/\s+/g, "-");
    a.download = `${name}-analytics.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportPDF = () => {
    window.print();
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <BarChart3 className="w-10 h-10 mr-3 text-purple-400" />
            Funnel Analytics & Reports
          </h1>
          <p className="orbital-text-subtitle">Conversion, drop-off, page performance, revenue, and ROI insights.</p>
        </div>
        <div className="flex items-center gap-2">
          <BackendHealthBadge />
          <button onClick={load} className="orbital-button-secondary flex items-center"><RefreshCw className="w-4 h-4 mr-1" />Refresh</button>
          <button onClick={() => setShowScaffold(true)} className="orbital-button-secondary">Backend Scaffold</button>
          <button onClick={exportCSV} className="orbital-button-secondary flex items-center"><Download className="w-4 h-4 mr-1" />CSV</button>
          <button onClick={exportPDF} className="orbital-button-secondary flex items-center"><FileDown className="w-4 h-4 mr-1" />PDF</button>
        </div>
      </div>

      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-3xl p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center">
          <div className="md:col-span-2">
            <label className="text-xs text-gray-400">Select report</label>
            <select
              value={active?.id || ""}
              onChange={(e) => setActiveId(e.target.value)}
              className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100"
            >
              {metrics.map(m => (
                <option key={m.id} value={m.id}>
                  {m.funnel_name} — {m.period_start || "?"} → {m.period_end || "?"}
                </option>
              ))}
            </select>
          </div>
          <div className="md:col-span-1 text-right">
            <Badge className="bg-gray-700/50 text-gray-300">{metrics.length} reports</Badge>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : !active ? (
        <div className="text-gray-400">No analytics available.</div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <NumberStat label="Visitors" value={(active?.visitors ?? 0).toLocaleString()} icon={Layers} color="text-cyan-400" />
            <NumberStat label="Leads" value={(active?.leads ?? 0).toLocaleString()} icon={TrendingUp} color="text-green-400" />
            <NumberStat label="Customers" value={(active?.customers ?? 0).toLocaleString()} icon={DollarSign} color="text-amber-400" />
            <NumberStat label="Conversion Rate" value={`${active?.conversion_rate ?? 0}%`} icon={PieIcon} color="text-purple-400" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="glass-pane p-4">
              <h3 className="orbital-text-subheading mb-4 flex items-center gap-2"><Layers className="w-4 h-4 text-cyan-400" /> Step Drop-off</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stepDropoff}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="step" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="views" name="Views" fill="#06B6D4" />
                    <Bar dataKey="conversions" name="Conversions" fill="#8B5CF6" />
                    <Bar dataKey="dropoff" name="Drop-off" fill="#EF4444" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="glass-pane p-4">
              <h3 className="orbital-text-subheading mb-4 flex items-center gap-2"><PieIcon className="w-4 h-4 text-yellow-400" /> Revenue by Product</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip content={<ChartTooltip />} />
                    <Pie data={productBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                      {productBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={["#06B6D4","#8B5CF6","#10B981","#F59E0B","#EF4444","#3B82F6"][index % 6]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          
          <div className="glass-pane p-4 mb-8">
            <h3 className="orbital-text-subheading mb-4 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-purple-400" /> Page Performance</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={pagePerf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="page" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Line type="monotone" dataKey="views" name="Views" stroke="#10B981" strokeWidth={2} />
                  <Line type="monotone" dataKey="bounce_rate" name="Bounce %" stroke="#F59E0B" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="overflow-x-auto mt-4">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">Page</TableHead>
                    <TableHead className="text-gray-400">Views</TableHead>
                    <TableHead className="text-gray-400">Bounce %</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagePerf.map((p, i) => (
                    <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-white">{p.page}</TableCell>
                      <TableCell className="text-gray-300">{p.views.toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">{p.bounce_rate}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          <div className="glass-pane p-4 mb-8">
            <h3 className="orbital-text-subheading mb-4 flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-400" /> Revenue Report</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">Product</TableHead>
                    <TableHead className="text-gray-400">Orders</TableHead>
                    <TableHead className="text-gray-400">Revenue</TableHead>
                    <TableHead className="text-gray-400">AOV</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(revenueObj?.by_product || []).map((p, i) => (
                    <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-white">{p.product_name}</TableCell>
                      <TableCell className="text-gray-300">{(p.orders || 0).toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">${(p.revenue || 0).toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">${(p.aov || 0).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  {!(revenueObj?.by_product || []).length && (
                    <TableRow className="border-gray-800">
                      <TableCell colSpan={4} className="text-gray-500 text-sm">No revenue data.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            <div className="mt-4 flex items-center justify-end gap-4">
              <div className="text-sm text-gray-400">Total Revenue</div>
              <div className="text-white font-semibold text-lg">${(revenueObj?.total_revenue || 0).toLocaleString()}</div>
            </div>
          </div>

          <ROISection active={active} />
        </>
      )}

      <SpeedBackendScaffold open={showScaffold} onOpenChange={setShowScaffold} />
    </div>
  );
}

function ROISection({ active }) {
  const [ad, setAd] = React.useState(active?.costs?.ad_spend || 0);
  const [cogs, setCogs] = React.useState(active?.costs?.cogs || 0);
  const [other, setOther] = React.useState(active?.costs?.other_costs || 0);

  React.useEffect(() => {
    setAd(active?.costs?.ad_spend || 0);
    setCogs(active?.costs?.cogs || 0);
    setOther(active?.costs?.other_costs || 0);
  }, [active?.id, active?.costs?.ad_spend, active?.costs?.cogs, active?.costs?.other_costs]);

  const revenue = active?.revenue?.total_revenue || 0;
  const costs = (Number(ad)||0) + (Number(cogs)||0) + (Number(other)||0);
  const profit = revenue - costs;
  const roi = costs > 0 ? ((profit) / costs) * 100 : null;

  return (
    <div className="glass-pane p-4">
      <h3 className="orbital-text-subheading mb-4 flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-400" /> ROI Calculator</h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="text-xs text-gray-400">Ad Spend</label>
          <input type="number" className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-white"
                 value={ad} onChange={e => setAd(e.target.value)} />
        </div>
        <div>
          <label className="text-xs text-gray-400">COGS</label>
          <input type="number" className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-white"
                 value={cogs} onChange={e => setCogs(e.target.value)} />
        </div>
        <div>
          <label className="text-xs text-gray-400">Other Costs</label>
          <input type="number" className="w-full bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-white"
                 value={other} onChange={e => setOther(e.target.value)} />
        </div>
        <div className="flex items-end">
          <div className="w-full p-3 rounded-md border border-gray-700 bg-[#0C0F19]">
            <div className="text-xs text-gray-400">ROI</div>
            <div className={`text-xl font-semibold ${roi != null ? (roi >= 0 ? "text-green-400" : "text-red-400") : "text-gray-300"}`}>
              {roi != null ? `${roi.toFixed(2)}%` : "—"}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        <div className="glass-pane p-3">
          <div className="text-xs text-gray-400">Revenue</div>
          <div className="text-2xl font-bold text-white">${(revenue || 0).toLocaleString()}</div>
        </div>
        <div className="glass-pane p-3">
          <div className="text-xs text-gray-400">Total Costs</div>
          <div className="text-2xl font-bold text-white">${(costs || 0).toLocaleString()}</div>
        </div>
        <div className="glass-pane p-3">
          <div className="text-xs text-gray-400">Profit</div>
          <div className={`text-2xl font-bold ${profit >= 0 ? "text-green-400" : "text-red-400"}`}>
            ${(profit || 0).toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
}