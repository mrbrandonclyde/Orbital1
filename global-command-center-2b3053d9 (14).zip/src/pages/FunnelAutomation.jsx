import React from "react";
import { AutomationFlow } from "@/api/entities";
import { ABTest } from "@/api/entities";
import { LeadScoreRule } from "@/api/entities";
import { User } from "@/api/entities";
import AutomationBuilder from "../components/automation/AutomationBuilder";
import NodeConfigPanel from "../components/automation/NodeConfigPanel";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Plus, Play, Pause, Save, Trash2, GitBranch, Star } from "lucide-react";
import { SendEmail } from "@/api/integrations";

export default function FunnelAutomationPage() {
  const [me, setMe] = React.useState(null);
  const [list, setList] = React.useState([]);
  const [selected, setSelected] = React.useState(null);
  const [steps, setSteps] = React.useState([]);
  const [selectedNode, setSelectedNode] = React.useState(null);
  const [meta, setMeta] = React.useState({ name: "", description: "", trigger_type: "MANUAL", status: "DRAFT" });

  React.useEffect(() => {
    (async () => {
      try { setMe(await User.me()); } catch {}
      const flows = await AutomationFlow.list("-updated_date", 200);
      setList(flows);
    })();
  }, []);

  React.useEffect(() => {
    if (!selected) {
      setSteps([]);
      setSelectedNode(null);
      setMeta({ name: "", description: "", trigger_type: "MANUAL", status: "DRAFT" });
      return;
    }
    setSteps(selected.steps || []);
    setMeta({
      name: selected.name || "",
      description: selected.description || "",
      trigger_type: selected.trigger_type || "MANUAL",
      status: selected.status || "DRAFT"
    });
  }, [selected]);

  const save = async () => {
    const payload = {
      name: meta.name || "Untitled Automation",
      description: meta.description || "",
      trigger_type: meta.trigger_type || "MANUAL",
      status: meta.status || "DRAFT",
      steps
    };
    if (selected?.id) {
      await AutomationFlow.update(selected.id, payload);
    } else {
      const created = await AutomationFlow.create({ ...payload, account_id: me?.account_id });
      setSelected(created);
    }
    setList(await AutomationFlow.list("-updated_date", 200));
  };

  const activate = async () => {
    if (!selected?.id) return;
    await AutomationFlow.update(selected.id, { status: "ACTIVE" });
    setList(await AutomationFlow.list("-updated_date", 200));
    const fresh = await AutomationFlow.list("-updated_date", 1);
    setSelected(fresh.find(f => f.id === selected.id) || selected);
  };

  const pause = async () => {
    if (!selected?.id) return;
    await AutomationFlow.update(selected.id, { status: "PAUSED" });
    setList(await AutomationFlow.list("-updated_date", 200));
  };

  const createNew = () => {
    setSelected(null);
    setSteps([]);
    setSelectedNode(null);
    setMeta({ name: "", description: "", trigger_type: "MANUAL", status: "DRAFT" });
  };

  const remove = async (flow) => {
    if (!flow?.id) return;
    if (!window.confirm(`Delete automation “${flow.name}”?`)) return;
    await AutomationFlow.delete(flow.id);
    setSelected(null);
    setList(await AutomationFlow.list("-updated_date", 200));
  };

  const updateNode = (node) => {
    setSteps(prev => prev.map(n => (n.id === node.id ? node : n)));
    if (selectedNode?.id === node.id) setSelectedNode(node);
  };

  const sendTestEmail = async () => {
    // Quick test for EMAIL step using Core.SendEmail (placeholder)
    const emailNode = steps.find(s => s.type === "EMAIL");
    if (!emailNode) return;
    await SendEmail({
      to: me?.email || "test@example.com",
      subject: `[Test] ${emailNode.config?.subject || "Automation Email"}`,
      body: emailNode.config?.body || "Hello from Automation Engine",
      from_name: emailNode.config?.from_name || "Orbital Command Center"
    });
    alert("Test email sent (check inbox).");
  };

  const scopedList = React.useMemo(() => {
    return me?.account_id ? list.filter(x => x.account_id === me.account_id) : list;
  }, [list, me]);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Zap className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Automation Engine</h1>
            <p className="orbital-text-subtitle">Email sequences, SMS, webhooks, A/B tests, and lead scoring.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={createNew}><Plus className="w-4 h-4 mr-1" /> New Automation</Button>
          <Button variant="secondary" onClick={save}><Save className="w-4 h-4 mr-1" /> Save</Button>
          <Button className="bg-green-600 hover:bg-green-700" onClick={activate} disabled={!selected?.id}><Play className="w-4 h-4 mr-1" /> Activate</Button>
          <Button variant="secondary" onClick={pause} disabled={!selected?.id}><Pause className="w-4 h-4 mr-1" /> Pause</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* List */}
        <Card className="xl:col-span-1 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader className="flex items-center justify-between">
            <CardTitle className="text-white text-base">Automations</CardTitle>
            <Badge className="bg-gray-700/50 text-gray-300">{scopedList.length}</Badge>
          </CardHeader>
          <CardContent className="space-y-2">
            {scopedList.map(f => (
              <div key={f.id} className={`p-2 rounded border ${selected?.id === f.id ? "border-cyan-500/50 bg-cyan-500/10" : "border-gray-800 hover:border-gray-700"} flex items-center justify-between`}>
                <button onClick={() => setSelected(f)} className="text-left">
                  <div className="text-white">{f.name}</div>
                  <div className="text-xs text-gray-500">{f.trigger_type} • {f.status}</div>
                </button>
                <button onClick={() => remove(f)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
            {!scopedList.length && <div className="text-gray-500 text-sm">No automations yet.</div>}
          </CardContent>
        </Card>

        {/* Builder + Meta */}
        <div className="xl:col-span-3 space-y-6">
          <Card className="bg-[#0A0D18]/50 border-gray-800">
            <CardHeader><CardTitle className="text-white text-base">Details</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <Input placeholder="Name" value={meta.name} onChange={(e) => setMeta({ ...meta, name: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 md:col-span-2" />
              <Input placeholder="Trigger (WEBHOOK, FORM_SUBMIT, PAGE_VIEW, TAG_ADDED, MANUAL)" value={meta.trigger_type} onChange={(e) => setMeta({ ...meta, trigger_type: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 md:col-span-2" />
              <Textarea placeholder="Description" value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100 md:col-span-4" />
              <div className="md:col-span-4 flex gap-2">
                <Button variant="secondary" onClick={save}><Save className="w-4 h-4 mr-1" /> Save</Button>
                <Button variant="secondary" onClick={sendTestEmail} disabled={!steps.find(s => s.type === "EMAIL")}><Zap className="w-4 h-4 mr-1" /> Send Test Email</Button>
              </div>
            </CardContent>
          </Card>

          <AutomationBuilder
            steps={steps}
            onChange={setSteps}
            selectedId={selectedNode?.id}
            onSelect={setSelectedNode}
          />

          <NodeConfigPanel node={selectedNode} onChange={updateNode} />

          {/* A/B tests and Lead Scoring placeholders */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-[#0A0D18]/50 border-gray-800">
              <CardHeader className="flex items-center justify-between">
                <CardTitle className="text-white text-base flex items-center gap-2"><GitBranch className="w-4 h-4 text-cyan-400" /> A/B Testing</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 text-sm">
                Define experiments per step in future iterations. Track impressions/conversions and choose winners automatically.
              </CardContent>
            </Card>

            <Card className="bg-[#0A0D18]/50 border-gray-800">
              <CardHeader className="flex items-center justify-between">
                <CardTitle className="text-white text-base flex items-center gap-2"><Star className="w-4 h-4 text-yellow-400" /> Lead Scoring</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 text-sm">
                Create LeadScoreRule records to award points for key actions (page views, tags, purchases).
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}