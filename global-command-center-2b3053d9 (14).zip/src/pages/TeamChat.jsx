import React, { useState, useEffect } from 'react';
import { ChatMessage } from '@/api/entities';
import { User } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { Send, Users, Hash, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

export default function TeamChatPage() {
  const [activeChannel, setActiveChannel] = useState('general');
  const [newMessage, setNewMessage] = useState('');
  const [user, setUser] = useState(null);

  const channels = [
    { id: 'general', name: 'General', type: 'channel' },
    { id: 'operations', name: 'Operations', type: 'channel' },
    { id: 'intelligence', name: 'Intelligence', type: 'channel' },
    { id: 'alerts', name: 'Alerts', type: 'channel' }
  ];

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Failed to load user:', error);
    }
  };

  const { data: messages, refetch } = useQuery(['chatMessages', activeChannel], async () => {
    return await ChatMessage.filter({ channel: activeChannel }, '-created_date', 50);
  });

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !user) return;

    try {
      await ChatMessage.create({
        sender_id: user.id,
        sender_name: user.full_name,
        channel: activeChannel,
        content: newMessage.trim()
      });
      setNewMessage('');
      refetch();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  return (
    <div className="flex h-screen bg-[#020409]">
      {/* Sidebar */}
      <div className="w-80 bg-[#0A0D18] border-r border-gray-800 flex flex-col">
        <div className="p-6 border-b border-gray-800">
          <h2 className="text-xl font-bold text-white flex items-center">
            <Users className="w-6 h-6 mr-2 text-cyan-400" />
            Team Communications
          </h2>
        </div>

        <div className="flex-1 p-4">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-400 uppercase">Channels</h3>
              <Plus className="w-4 h-4 text-gray-500 hover:text-white cursor-pointer" />
            </div>
            <div className="space-y-1">
              {channels.map(channel => (
                <button
                  key={channel.id}
                  onClick={() => setActiveChannel(channel.id)}
                  className={`w-full flex items-center space-x-2 p-2 rounded-lg text-left transition-all ${
                    activeChannel === channel.id
                      ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }`}
                >
                  <Hash className="w-4 h-4" />
                  <span className="text-sm">{channel.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* User Status */}
        {user && (
          <div className="p-4 border-t border-gray-800">
            <div className="flex items-center space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarImage src={user.avatar_url} />
                <AvatarFallback>{user.full_name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="text-sm font-medium text-white">{user.full_name}</div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-xs text-gray-400">Online</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="p-4 border-b border-gray-800 bg-[#0A0D18]/50">
          <div className="flex items-center space-x-2">
            <Hash className="w-5 h-5 text-gray-400" />
            <h3 className="text-lg font-semibold text-white capitalize">{activeChannel}</h3>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages?.map(message => (
            <div key={message.id} className="flex space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarFallback>{message.sender_name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-medium text-white">{message.sender_name}</span>
                  <span className="text-xs text-gray-500">
                    {new Date(message.created_date).toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-gray-300">{message.content}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-800">
          <div className="flex space-x-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder={`Message #${activeChannel}`}
              className="flex-1 bg-gray-800 border-gray-600 text-white"
            />
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 rounded-lg transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4 text-white" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}