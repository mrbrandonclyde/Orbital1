import React, { useCallback, useState } from 'react';
import { UserFeedback } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { MessageSquare, Bug, Lightbulb, Users, MessageCircle, Calendar, User, MapPin } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const getFeedbackIcon = (type) => {
  switch (type) {
    case 'bug_report': return <Bug className="w-4 h-4 text-red-400" />;
    case 'feature_request': return <Lightbulb className="w-4 h-4 text-yellow-400" />;
    case 'usability_feedback': return <Users className="w-4 h-4 text-blue-400" />;
    case 'general_feedback': return <MessageCircle className="w-4 h-4 text-green-400" />;
    default: return <MessageSquare className="w-4 h-4 text-gray-400" />;
  }
};

const getPriorityBadge = (priority) => {
  switch (priority) {
    case 'critical': return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">Critical</Badge>;
    case 'high': return <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20">High</Badge>;
    case 'medium': return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">Medium</Badge>;
    case 'low': return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">Low</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{priority}</Badge>;
  }
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'new': return <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">New</Badge>;
    case 'in_review': return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">In Review</Badge>;
    case 'in_progress': return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">In Progress</Badge>;
    case 'resolved': return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">Resolved</Badge>;
    case 'closed': return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">Closed</Badge>;
    default: return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
  }
};

export default function FeedbackDashboard() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  const queryFn = useCallback(async () => {
    const feedback = await UserFeedback.list('-created_date', 100);
    return { feedback };
  }, []);

  const { data, loading, error, refetch } = useQuery(queryFn);

  const filteredFeedback = (data?.feedback || []).filter(item => {
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesType = typeFilter === 'all' || item.feedback_type === typeFilter;
    return matchesStatus && matchesType;
  });

  // Statistics
  const totalFeedback = data?.feedback?.length || 0;
  const newFeedback = data?.feedback?.filter(f => f.status === 'new').length || 0;
  const resolvedFeedback = data?.feedback?.filter(f => f.status === 'resolved').length || 0;
  const criticalFeedback = data?.feedback?.filter(f => f.priority === 'critical').length || 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Failed to load feedback data.</p>
      </div>
    );
  }

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <MessageSquare className="w-10 h-10 mr-3 text-purple-400" />
            Feedback Dashboard
          </h1>
          <p className="orbital-text-subtitle">Monitor user feedback and improvement suggestions.</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
              <SelectValue placeholder="Status Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="in_review">In Review</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[140px] bg-[#0A0D18] border-gray-700">
              <SelectValue placeholder="Type Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="bug_report">Bug Reports</SelectItem>
              <SelectItem value="feature_request">Feature Requests</SelectItem>
              <SelectItem value="usability_feedback">Usability</SelectItem>
              <SelectItem value="general_feedback">General</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="glass-pane">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Feedback</p>
                <p className="text-2xl font-bold text-white">{totalFeedback}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">New Items</p>
                <p className="text-2xl font-bold text-white">{newFeedback}</p>
              </div>
              <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">New</Badge>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Resolved</p>
                <p className="text-2xl font-bold text-white">{resolvedFeedback}</p>
              </div>
              <Badge className="bg-green-500/10 text-green-400 border-green-500/20">Resolved</Badge>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Critical Issues</p>
                <p className="text-2xl font-bold text-white">{criticalFeedback}</p>
              </div>
              <Badge className="bg-red-500/10 text-red-400 border-red-500/20">Critical</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feedback Table */}
      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">User Feedback ({filteredFeedback.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-white">Type</TableHead>
                <TableHead className="text-white">Subject</TableHead>
                <TableHead className="text-white">Priority</TableHead>
                <TableHead className="text-white">Status</TableHead>
                <TableHead className="text-white">Page</TableHead>
                <TableHead className="text-white">Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFeedback.map((feedback) => (
                <TableRow key={feedback.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="flex items-center space-x-2">
                    {getFeedbackIcon(feedback.feedback_type)}
                    <span className="text-white capitalize">{feedback.feedback_type.replace('_', ' ')}</span>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium text-white">{feedback.subject}</p>
                      <p className="text-xs text-gray-400 truncate max-w-xs">{feedback.description}</p>
                    </div>
                  </TableCell>
                  <TableCell>{getPriorityBadge(feedback.priority)}</TableCell>
                  <TableCell>{getStatusBadge(feedback.status)}</TableCell>
                  <TableCell className="text-gray-300">{feedback.page_location}</TableCell>
                  <TableCell className="text-gray-400 text-sm">
                    {new Date(feedback.created_date).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredFeedback.length === 0 && (
            <div className="text-center py-8">
              <MessageSquare className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No feedback items found matching your filters.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}