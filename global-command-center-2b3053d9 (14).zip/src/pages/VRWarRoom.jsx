import React, { useState } from 'react';
import { Headset, Activity, Users, Globe, Zap, Target, Shield } from 'lucide-react';

// === VR War Room Components (2D Fallback) ===

const FallbackGlobe = () => (
  <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
    {/* Pulsing background */}
    <div className="absolute w-1/2 h-1/2 bg-cyan-500/20 rounded-full blur-3xl animate-pulse"></div>
    
    {/* Rotating Rings */}
    <div className="absolute w-full h-full border border-cyan-500/20 rounded-full animate-spin-slow"></div>
    <div className="absolute w-[80%] h-[80%] border border-cyan-500/20 rounded-full animate-spin-medium"></div>
    <div className="absolute w-[60%] h-[60%] border border-cyan-500/20 rounded-full animate-spin-fast"></div>
    
    {/* SVG Globe */}
    <Globe className="relative w-1/2 h-1/2 text-cyan-400 opacity-75" />

    {/* Threat Indicators */}
    <div className="absolute w-2 h-2 bg-red-500 rounded-full top-[30%] left-[20%] animate-pulse shadow-lg"></div>
    <div className="absolute w-2 h-2 bg-yellow-500 rounded-full bottom-[25%] right-[25%] animate-pulse animation-delay-300 shadow-lg"></div>
    <div className="absolute w-2 h-2 bg-green-500 rounded-full top-[50%] right-[15%] animate-pulse animation-delay-600 shadow-lg"></div>
  </div>
);


const vrMetrics = [
  { title: "VR Systems Online", value: "8/8", icon: Headset, color: "text-green-400" },
  { title: "Active Users", value: "24", icon: Users, color: "text-cyan-400" },
  { title: "Immersion Level", value: "98.7%", icon: Activity, color: "text-purple-400" },
  { title: "Sync Latency", value: "12ms", icon: Zap, color: "text-yellow-400" },
];

const sessionData = [
  { user: "Command Alpha", session: "45min", activity: "Global Monitoring", status: "Active" },
  { user: "Tactical Beta", session: "32min", activity: "Mission Planning", status: "Active" },
  { user: "Intel Gamma", session: "18min", activity: "Threat Analysis", status: "Active" },
];

export default function VRWarRoomPage() {
  const [vrMode, setVrMode] = useState(false);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* VR War Room Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Headset className="w-10 h-10 mr-3 text-purple-400" />
            VR War Room
          </h1>
          <p className="orbital-text-subtitle">Immersive command and control in virtual reality space.</p>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => setVrMode(!vrMode)}
            className={`orbital-button-primary flex items-center space-x-2 ${vrMode ? 'bg-gradient-to-r from-purple-600 to-pink-600' : ''}`}
          >
            <Headset className="w-5 h-5" />
            <span>{vrMode ? 'Exit VR Mode' : 'Enter VR Mode'}</span>
          </button>
        </div>
      </div>

      {/* Frame 1: VR System Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {vrMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      {/* Frame 2: 2D Holographic Environment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* 2D Holographic Scene */}
        <div className="lg:col-span-2 glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Globe className="w-5 h-5 mr-2 text-cyan-400" />
            Holographic Command Environment
          </h3>
          <div className="h-96 rounded-lg overflow-hidden bg-gradient-to-b from-gray-900 to-black">
            <FallbackGlobe />
          </div>
        </div>

        {/* VR Control Panel */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-purple-400" />
            VR Controls
          </h3>
          <div className="space-y-4">
            <div className="bg-gray-800/50 p-3 rounded-lg">
              <p className="text-sm font-medium text-white mb-2">Environment Settings</p>
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded border-gray-600" defaultChecked />
                  <span className="text-xs text-gray-300">Holographic Threat Display</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded border-gray-600" defaultChecked />
                  <span className="text-xs text-gray-300">Real-time Data Overlay</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded border-gray-600" />
                  <span className="text-xs text-gray-300">Collaborative Mode</span>
                </label>
              </div>
            </div>

            <div className="bg-gray-800/50 p-3 rounded-lg">
              <p className="text-sm font-medium text-white mb-2">Immersion Level</p>
              <div className="flex items-center space-x-2">
                <div className="flex-1 bg-gray-700 rounded-full h-2">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full" style={{width: '98%'}} />
                </div>
                <span className="text-xs text-gray-400">98%</span>
              </div>
            </div>

            <div className="bg-gray-800/50 p-3 rounded-lg">
              <p className="text-sm font-medium text-white mb-2">Quick Actions</p>
              <div className="space-y-2">
                <button className="w-full orbital-button-secondary text-xs">
                  <Shield className="w-3 h-3 mr-2" />
                  Threat Analysis Mode
                </button>
                <button className="w-full orbital-button-secondary text-xs">
                  <Target className="w-3 h-3 mr-2" />
                  Mission Planning View
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Frame 3: Active VR Sessions */}
      <div className="glass-pane p-4">
        <h3 className="orbital-text-subheading mb-4 flex items-center">
          <Users className="w-5 h-5 mr-2 text-green-400" />
          Active VR Sessions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sessionData.map((session, i) => (
            <div key={i} className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-medium text-white">{session.user}</p>
                  <p className="text-xs text-gray-400">{session.activity}</p>
                </div>
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-400">Session: {session.session}</span>
                <span className="text-green-400 font-semibold">{session.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}