
import React from "react";
import { Funnel } from "@/api/entities";
import { FunnelStep } from "@/api/entities";
import { User } from "@/api/entities";
import BuilderSidebar from "../components/builder/BuilderSidebar";
import Canvas from "../components/builder/Canvas";
import PropertiesPanel from "../components/builder/PropertiesPanel";
import TopBar from "../components/builder/TopBar";
import { toast } from "@/components/common/Toast";
import { FunnelTemplate } from "@/api/entities";

export default function FunnelEditorPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const funnelId = urlParams.get("funnel");

  const [funnel, setFunnel] = React.useState(null);
  const [steps, setSteps] = React.useState([]);
  const [activeStepId, setActiveStepId] = React.useState(null);

  const [blocks, setBlocks] = React.useState([]);
  const [selectedId, setSelectedId] = React.useState(null);
  const [preview, setPreview] = React.useState(false);
  const [device, setDevice] = React.useState("desktop");

  const [history, setHistory] = React.useState([]);
  const [future, setFuture] = React.useState([]);

  const [pageSettings, setPageSettings] = React.useState({});

  // Load funnel + steps
  React.useEffect(() => {
    const load = async () => {
      const me = await User.me().catch(() => null);
      const f = await Funnel.list();
      const current = f.find(x => String(x.id) === String(funnelId)) || f.find(x => x.id);
      setFunnel(current || null);

      const s = await FunnelStep.filter({ funnel_id: funnelId || current?.id }, "order_index", 500);
      setSteps(s);
      const initialStepId = s[0]?.id ? String(s[0].id) : null;
      setActiveStepId(initialStepId);

      if (s[0]?.content_schema?.blocks) {
        setBlocks(s[0].content_schema.blocks);
      } else {
        setBlocks([]);
      }
      setPageSettings({
        seo_title: current?.seo_title || "",
        seo_description: current?.seo_description || ""
      });
      setHistory([]);
      setFuture([]);
      setSelectedId(null);
    };
    load();
  }, [funnelId]);

  const pushHistory = (prev) => {
    setHistory(h => [...h, prev]);
    setFuture([]); // clear redo stack on new action
  };

  // When switching page
  const handleChangeStep = async (id) => {
    if (String(id) === String(activeStepId)) return;
    // load blocks of the selected step
    const target = steps.find(s => String(s.id) === String(id));
    setActiveStepId(String(id));
    setBlocks(target?.content_schema?.blocks || []);
    setSelectedId(null);
    setHistory([]);
    setFuture([]);
  };

  const addBlock = (block) => {
    pushHistory(blocks);
    setBlocks(prev => [...prev, block]);
    setSelectedId(block.id);
  };

  const updateSelectedBlock = (updated) => {
    pushHistory(blocks);
    setBlocks(prev => prev.map(b => b.id === updated.id ? updated : b));
  };

  const deleteBlock = (id) => {
    pushHistory(blocks);
    setBlocks(prev => prev.filter(b => b.id !== id));
    setSelectedId(null);
  };

  const undo = () => {
    setHistory(h => {
      if (!h.length) return h;
      const previous = h[h.length - 1];
      setFuture(f => [blocks, ...f]);
      setBlocks(previous);
      return h.slice(0, -1);
    });
  };

  const redo = () => {
    setFuture(f => {
      if (!f.length) return f;
      const next = f[0];
      setHistory(h => [...h, blocks]);
      setBlocks(next);
      return f.slice(1);
    });
  };

  const onSave = async () => {
    if (!activeStepId) return;
    await FunnelStep.update(activeStepId, { content_schema: { blocks } });
    toast.success("Page saved", { description: "Your funnel page has been saved." });
  };

  const onSaveTemplate = async () => {
    if (!funnel || !activeStepId) return;
    const step = steps.find(s => String(s.id) === String(activeStepId));
    const tpl = await FunnelTemplate.create({
      template_name: `${funnel.funnel_name} — ${step?.step_name || "Page"} (Saved)`,
      category: "CUSTOM",
      thumbnail_url: "https://images.unsplash.com/photo-1557800636-894a64c1696f?w=800&q=60",
      description: "Saved from builder",
      steps_blueprint: [
        {
          step_name: step?.step_name || "Page",
          step_type: step?.step_type || "CUSTOM",
          path_slug: step?.path_slug || "page",
          content_schema: { blocks }
        }
      ]
    });
    toast.success("Template saved", { description: "Find it later in Templates." });
  };

  const selectedBlock = blocks.find(b => b.id === selectedId) || null;

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title">Funnel Builder</h1>
          <p className="orbital-text-subtitle">{funnel?.funnel_name || "Loading…"} — Drag & drop blocks, edit properties, and save.</p>
        </div>
      </div>

      {/* Top bar */}
      <TopBar
        steps={steps}
        activeStepId={activeStepId || ""}
        onChangeStep={handleChangeStep}
        preview={preview}
        setPreview={setPreview}
        device={device}
        setDevice={setDevice}
        onSave={onSave}
        onSaveTemplate={onSaveTemplate}
        canUndo={history.length > 0}
        canRedo={future.length > 0}
        onUndo={undo}
        onRedo={redo}
      />

      {/* Main grid: Left sidebar / Canvas / Right properties */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
        <div className="lg:col-span-3">
          <BuilderSidebar onAdd={addBlock} />
        </div>

        <div className="lg:col-span-6">
          <Canvas
            blocks={blocks}
            setBlocks={(b) => { pushHistory(blocks); setBlocks(b); }}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            preview={preview}
            device={device}
          />
        </div>

        <div className="lg:col-span-3">
          <PropertiesPanel
            selectedBlock={selectedBlock}
            onChange={updateSelectedBlock}
            onDelete={deleteBlock}
            onDeselect={() => setSelectedId(null)}
            pageSettings={pageSettings}
            onPageSettings={setPageSettings}
          />
        </div>
      </div>
    </div>
  );
}
