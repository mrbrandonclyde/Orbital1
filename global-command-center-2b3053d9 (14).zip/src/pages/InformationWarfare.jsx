import React, { useState } from 'react';
import { Eye, Shield, Zap, Users, TrendingUp, AlertTriangle, Target, MessageSquare } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const warfareMetrics = [
  { title: "Active Campaigns", value: "23", icon: Target, color: "text-red-400" },
  { title: "Social Media Reach", value: "847M", icon: Users, color: "text-cyan-400" },
  { title: "Narrative Control", value: "73%", icon: MessageSquare, color: "text-purple-400" },
  { title: "Threat Neutralization", value: "96%", icon: Shield, color: "text-green-400" },
];

const activeCampaigns = [
  { 
    id: 'op-mirror', 
    name: 'Operation Mirror Shield', 
    target: 'Counter Chinese Disinformation', 
    reach: '45M', 
    effectiveness: 87,
    status: 'ACTIVE' 
  },
  { 
    id: 'op-lighthouse', 
    name: 'Lighthouse Narrative', 
    target: 'European Energy Policy', 
    reach: '23M', 
    effectiveness: 92,
    status: 'ACTIVE' 
  },
  { 
    id: 'op-phantom', 
    name: 'Phantom Echo', 
    target: 'Cryptocurrency Sentiment', 
    reach: '67M', 
    effectiveness: 78,
    status: 'MONITORING' 
  },
  { 
    id: 'op-prism', 
    name: 'Prism Cascade', 
    target: 'Climate Policy Narrative', 
    reach: '134M', 
    effectiveness: 94,
    status: 'SCALING' 
  }
];

const platformData = [
  { platform: 'Twitter/X', influence: 34, color: '#1DA1F2' },
  { platform: 'Facebook', influence: 28, color: '#4267B2' },
  { platform: 'Instagram', influence: 18, color: '#E4405F' },
  { platform: 'TikTok', influence: 12, color: '#FF0050' },
  { platform: 'LinkedIn', influence: 5, color: '#0077B5' },
  { platform: 'Other', influence: 3, color: '#6B7280' }
];

const sentimentData = [
  { date: '01/15', positive: 45, negative: 35, neutral: 20 },
  { date: '01/16', positive: 52, negative: 28, neutral: 20 },
  { date: '01/17', positive: 48, negative: 32, neutral: 20 },
  { date: '01/18', positive: 61, negative: 22, neutral: 17 },
  { date: '01/19', positive: 67, negative: 18, neutral: 15 },
  { date: '01/20', positive: 73, negative: 14, neutral: 13 }
];

const threats = [
  { source: 'Russian Bot Network', activity: 'Election Interference', threat_level: 'HIGH', status: 'MONITORED' },
  { source: 'Chinese State Media', activity: 'Economic Narrative', threat_level: 'MEDIUM', status: 'COUNTERED' },
  { source: 'Iranian Proxies', activity: 'Regional Destabilization', threat_level: 'HIGH', status: 'ACTIVE_COUNTER' },
  { source: 'Domestic Extremists', activity: 'Anti-Government', threat_level: 'MEDIUM', status: 'INFILTRATED' }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400 animate-pulse">ACTIVE</Badge>;
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400">MONITORING</Badge>;
    case 'SCALING': return <Badge className="bg-blue-500/20 text-blue-400">SCALING</Badge>;
    case 'COUNTERED': return <Badge className="bg-purple-500/20 text-purple-400">COUNTERED</Badge>;
    case 'INFILTRATED': return <Badge className="bg-cyan-500/20 text-cyan-400">INFILTRATED</Badge>;
    case 'ACTIVE_COUNTER': return <Badge className="bg-red-500/20 text-red-400">ACTIVE COUNTER</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getThreatBadge = (level) => {
  switch (level) {
    case 'HIGH': return <Badge className="bg-red-500/20 text-red-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    case 'LOW': return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function InformationWarfarePage() {
  const [selectedCampaign, setSelectedCampaign] = useState('op-mirror');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Eye className="w-10 h-10 mr-3 text-red-400" />
            Information Warfare Center
          </h1>
          <p className="orbital-text-subtitle">Advanced narrative control, disinformation detection, and influence campaign management.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-red-500/10 border border-red-500/20 rounded px-3 py-1">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="text-red-400 font-semibold text-sm">CLASSIFIED OPERATION</span>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {warfareMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Active Campaigns */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-red-400" />
            Active Campaigns
          </h3>
          <div className="space-y-3">
            {activeCampaigns.map(campaign => (
              <div 
                key={campaign.id}
                className={`p-3 rounded-lg border transition-all cursor-pointer ${
                  selectedCampaign === campaign.id 
                    ? 'bg-red-500/20 border-red-500/50' 
                    : 'bg-gray-800/30 border-gray-700 hover:border-red-500/30'
                }`}
                onClick={() => setSelectedCampaign(campaign.id)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-white text-sm">{campaign.name}</h4>
                  {getStatusBadge(campaign.status)}
                </div>
                <p className="text-xs text-gray-400 mb-2">{campaign.target}</p>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-cyan-400">{campaign.reach} reach</span>
                  <span className="text-xs text-green-400">{campaign.effectiveness}% effective</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1">
                  <div 
                    className="bg-red-500 h-1 rounded-full" 
                    style={{width: `${campaign.effectiveness}%`}}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Platform Influence */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2 text-cyan-400" />
            Platform Influence
          </h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={platformData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  dataKey="influence"
                  nameKey="platform"
                >
                  {platformData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F3F4F6'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2 mt-4">
            {platformData.map((platform, i) => (
              <div key={i} className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{backgroundColor: platform.color}}></div>
                  <span className="text-xs text-gray-300">{platform.platform}</span>
                </div>
                <span className="text-xs text-white">{platform.influence}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Sentiment Tracking */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-purple-400" />
            Sentiment Analysis
          </h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sentimentData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9CA3AF" fontSize={10} />
                <YAxis stroke="#9CA3AF" fontSize={10} />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F3F4F6'
                  }}
                />
                <Line type="monotone" dataKey="positive" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="negative" stroke="#EF4444" strokeWidth={2} />
                <Line type="monotone" dataKey="neutral" stroke="#6B7280" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-xs mt-2">
            <span className="text-green-400">◆ Positive</span>
            <span className="text-red-400">◆ Negative</span>
            <span className="text-gray-400">◆ Neutral</span>
          </div>
        </div>
      </div>

      {/* Threat Monitoring */}
      <div className="glass-pane p-4">
        <h3 className="orbital-text-subheading mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2 text-yellow-400" />
          Hostile Information Threats
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {threats.map((threat, i) => (
            <div key={i} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
              <div className="flex justify-between items-start mb-3">
                <h4 className="font-semibold text-white text-sm">{threat.source}</h4>
                {getThreatBadge(threat.threat_level)}
              </div>
              <p className="text-xs text-gray-400 mb-3">{threat.activity}</p>
              <div className="flex justify-between items-center">
                {getStatusBadge(threat.status)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}