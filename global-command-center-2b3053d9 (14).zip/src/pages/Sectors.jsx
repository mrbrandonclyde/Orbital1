import React, { useState, useCallback } from 'react';
import { BusinessSector, SectorMetrics, SecurityAlert } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, Legend } from "recharts";
import { Building2, TrendingUp, Award, DollarSign, Gauge, Plus, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import SectorForm from '../components/sectors/SectorForm';
import SectorCard from '../components/sectors/SectorCard';
import EmptyState from '../components/common/EmptyState';
import SectorBillingGate from '../components/billing/SectorBillingGate';

const kpiData = [
  { title: "Global Economic Health", value: "85%", icon: TrendingUp, color: "text-green-400" },
  { title: "Sector Growth Rate", value: "8%", icon: Building2, color: "text-cyan-400" },
  { title: "Top Performing Sectors", value: "3", icon: Award, color: "text-yellow-400" },
  { title: "Investment Volume", value: "$5B", icon: DollarSign, color: "text-purple-400" },
  { title: "Resource Allocation Efficiency", value: "92%", icon: Gauge, color: "text-blue-400" },
];

const sectorGrowthData = [
  { month: "Jan", technology: 5, finance: 3, energy: 4, healthcare: 6 },
  { month: "Feb", technology: 6, finance: 4, energy: 3, healthcare: 7 },
  { month: "Mar", technology: 7, finance: 5, energy: 5, healthcare: 8 },
  { month: "Apr", technology: 8, finance: 6, energy: 4, healthcare: 9 },
  { month: "May", technology: 9, finance: 7, energy: 6, healthcare: 10 },
  { month: "Jun", technology: 11, finance: 8, energy: 7, healthcare: 11 },
];

const sectorInvestmentData = [
  { sector: "Technology", investment: 5000, fill: "#06B6D4" },
  { sector: "Energy", investment: 2000, fill: "#10B981" },
  { sector: "Manufacturing", investment: 1500, fill: "#FBBF24" },
  { sector: "Healthcare", investment: 1000, fill: "#8B5CF6" },
  { sector: "Finance", investment: 800, fill: "#EF4444" },
];

const topSectorsData = [
  { sector: "Technology", value: 40, fill: "#06B6D4" },
  { sector: "Finance", value: 30, fill: "#8B5CF6" },
  { sector: "Healthcare", value: 20, fill: "#10B981" },
  { sector: "Energy", value: 10, fill: "#FBBF24" },
];

const sectorInvestmentLog = [
  { id: "#SI-1001", sector: "Technology", amount: "$5,000M", roi: "8.2%", date: "2025-01-15", status: "Active" },
  { id: "#SI-1002", sector: "Energy", amount: "$2,000M", roi: "10.1%", date: "2025-02-01", status: "Active" },
  { id: "#SI-1003", sector: "Healthcare", amount: "$1,000M", roi: "7.5%", date: "2025-01-28", status: "Completed" },
];

const sectorResourceLog = [
  { sector: "Technology", resource: "Semiconductor Chips", allocation: "1,000,000 units", status: "On Target", date: "2025-09-02" },
  { sector: "Healthcare", resource: "Medical Equipment", allocation: "500,000 units", status: "Low Supply", date: "2025-09-02" },
  { sector: "Energy", resource: "Lithium Batteries", allocation: "2,000,000 units", status: "Surplus", date: "2025-09-01" },
];

const sectorPerformanceAlerts = [
  { date: "2025-09-01", type: "Decline Alert", message: "Manufacturing sector underperforming by 15%", action: "Increased monitoring", severity: "Medium" },
  { date: "2025-09-02", type: "Growth Surge", message: "Technology sector exceeding growth targets", action: "Investment doubled", severity: "Low" },
  { date: "2025-08-31", type: "Resource Alert", message: "Healthcare supply chain bottleneck detected", action: "Emergency procurement", severity: "High" },
];

const ChartTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
        <p className="label text-white font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color || entry.stroke || entry.fill }}>
            {`${entry.name}: ${entry.value}${typeof entry.value === 'number' && entry.value > 100 ? 'M' : '%'}`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const getStatusBadge = (status) => {
    if (status === "Active" || status === "On Target" || status === "Surplus") return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">{status}</Badge>;
    if (status === "Completed") return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">{status}</Badge>;
    if (status === "Low Supply") return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">{status}</Badge>;
    return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
};

const getSeverityBadge = (severity) => {
    if (severity === "High") return <Badge className="bg-red-500/20 text-red-400 border-red-500/30 flex items-center gap-1.5"><AlertTriangle className="w-3 h-3"/>{severity}</Badge>;
    if (severity === "Medium") return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 flex items-center gap-1.5"><AlertTriangle className="w-3 h-3"/>{severity}</Badge>;
    return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">{severity}</Badge>;
};

export default function SectorsPage() {
  const [showForm, setShowForm] = useState(false);
  const [editingSector, setEditingSector] = useState(null);
  
  const { data, loading, error, refetch } = useQuery(['sectorsData'], async () => {
    const [sectors, metrics, alerts] = await Promise.all([
      BusinessSector.list('-created_date', 50),
      SectorMetrics.list(),
      SecurityAlert.list()
    ]);
    
    const sectorStats = sectors.map(sector => ({
      ...sector,
      metricCount: metrics.filter(m => m.sector_id === sector.id).length,
      alertCount: alerts.filter(a => a.sector_id === sector.id && a.alert_status === 'ACTIVE').length
    }));
    
    return { sectors: sectorStats };
  }, {});

  const handleEdit = (sector) => {
    setEditingSector(sector);
    setShowForm(true);
  };

  const handleSuccess = () => {
    setShowForm(false);
    setEditingSector(null);
    refetch();
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <SectorBillingGate>
        <div className="orbital-page-header">
          <div>
            <h1 className="orbital-text-title flex items-center">
              <Building2 className="w-10 h-10 mr-3 text-cyan-400" />
              Sectors Intelligence
            </h1>
            <p className="orbital-text-subtitle">Real-time economic performance, sector trends, and investment analysis.</p>
          </div>
          <Dialog open={showForm} onOpenChange={(isOpen) => { setShowForm(isOpen); if (!isOpen) setEditingSector(null); }}>
            <DialogTrigger asChild>
              <button className="orbital-button-primary flex items-center space-x-2">
                <Plus size={18} />
                <span>Add Sector</span>
              </button>
            </DialogTrigger>
            <DialogContent className="bg-[#0A0D18] border-[#151823] text-white">
              <DialogHeader>
                <DialogTitle className="orbital-gradient-text text-2xl">
                  {editingSector ? 'Edit Monitored Sector' : 'Add New Sector for Monitoring'}
                </DialogTitle>
              </DialogHeader>
              <SectorForm sector={editingSector} onSuccess={handleSuccess} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Frame 1: KPI Cards - Sector Performance */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {kpiData.map((kpi, i) => {
            const Icon = kpi.icon;
            return (
              <div key={i} className="glass-pane p-4">
                <div className="flex justify-between items-start">
                  <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                  <Icon className={`w-6 h-6 ${kpi.color}`} />
                </div>
                <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
              </div>
            );
          })}
        </div>

        {/* Frame 2: Graphs - Sector Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Sector Growth Over Time */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
              Sector Growth Over Time
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sectorGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="technology" name="Tech" stroke="#06B6D4" strokeWidth={2} />
                  <Line type="monotone" dataKey="finance" name="Finance" stroke="#8B5CF6" strokeWidth={2} />
                  <Line type="monotone" dataKey="energy" name="Energy" stroke="#10B981" strokeWidth={2} />
                  <Line type="monotone" dataKey="healthcare" name="Healthcare" stroke="#FBBF24" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Performing Sectors */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <Award className="w-5 h-5 mr-2 text-yellow-400" />
              Top Performing Sectors
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Tooltip content={<ChartTooltip />} />
                  <Pie data={topSectorsData} dataKey="value" nameKey="sector" cx="50%" cy="50%" outerRadius={80} label>
                    {topSectorsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Investment Trends */}
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4 flex items-center">
              <DollarSign className="w-5 h-5 mr-2 text-purple-400" />
              Investment Trends
            </h3>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sectorInvestmentData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="sector" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="investment" name="Investment (M)">
                    {sectorInvestmentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Frame 3: Logs & Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Investment Log</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">ID</TableHead>
                    <TableHead className="text-gray-400">Sector</TableHead>
                    <TableHead className="text-gray-400">Amount</TableHead>
                    <TableHead className="text-gray-400">ROI</TableHead>
                    <TableHead className="text-gray-400">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sectorInvestmentLog.map((row) => (
                    <TableRow key={row.id} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="font-mono text-xs text-gray-300">{row.id}</TableCell>
                      <TableCell className="text-white font-medium">{row.sector}</TableCell>
                      <TableCell className="text-green-400">{row.amount}</TableCell>
                      <TableCell className="text-cyan-400">{row.roi}</TableCell>
                      <TableCell>{getStatusBadge(row.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Resource Allocation Log</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">Sector</TableHead>
                    <TableHead className="text-gray-400">Resource</TableHead>
                    <TableHead className="text-gray-400">Allocation</TableHead>
                    <TableHead className="text-gray-400">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sectorResourceLog.map((row, i) => (
                    <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-white font-medium">{row.sector}</TableCell>
                      <TableCell className="text-gray-300">{row.resource}</TableCell>
                      <TableCell className="text-gray-300">{row.allocation}</TableCell>
                      <TableCell>{getStatusBadge(row.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Performance Alerts</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead className="text-gray-400">Type</TableHead>
                    <TableHead className="text-gray-400">Message</TableHead>
                    <TableHead className="text-gray-400">Severity</TableHead>
                    <TableHead className="text-gray-400">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sectorPerformanceAlerts.map((alert, i) => (
                    <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                      <TableCell className="text-white font-medium">{alert.type}</TableCell>
                      <TableCell className="text-gray-300">{alert.message}</TableCell>
                      <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                      <TableCell className="text-gray-300">{alert.action}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </SectorBillingGate>


      {/* Managed Sectors Grid */}
      {loading && (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-4 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {error && (
        <div className="text-center py-12">
          <p className="text-red-500">Failed to load sectors data.</p>
        </div>
      )}

      {!loading && !error && (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {data?.sectors?.length > 0 ? (
            data.sectors.map(sector => (
              <SectorBillingGate 
                key={sector.id} 
                sector={sector.sector_name}
                apiCallsUsed={sector.api_calls_used || 0}
                apiCallsLimit={sector.api_calls_limit || 1000}
              >
                <SectorCard 
                  sector={sector} 
                  metricCount={sector.metricCount}
                  alertCount={sector.alertCount}
                  onEdit={handleEdit} 
                />
              </SectorBillingGate>
            ))
          ) : (
            <div className="col-span-full">
              <EmptyState
                icon={Building2}
                title="No Sectors Configured"
                subtitle="Create business sectors to organize metrics and alerts."
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}