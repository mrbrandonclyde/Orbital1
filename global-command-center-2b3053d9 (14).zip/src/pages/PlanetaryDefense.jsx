import React, { useState } from 'react';
import { Shield, Target, Zap, AlertTriangle, Radar, Satellite, Globe, Activity } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

// === Planetary Defense Data (Infinity Edition) ===
const defenseKPIs = [
  { title: "Defense Grid Status", value: "OPTIMAL", icon: Shield, color: "text-green-400" },
  { title: "Active Satellites", value: "2,847", icon: Satellite, color: "text-cyan-400" },
  { title: "Threat Detection Rate", value: "99.97%", icon: Radar, color: "text-purple-400" },
  { title: "Response Time", value: "0.23s", icon: Zap, color: "text-yellow-400" },
  { title: "Coverage Efficiency", value: "100%", icon: Globe, color: "text-blue-400" },
];

const threatDetectionData = [
  { time: "00:00", threats: 12, neutralized: 12, active: 0 },
  { time: "04:00", threats: 8, neutralized: 8, active: 0 },
  { time: "08:00", threats: 15, neutralized: 15, active: 0 },
  { time: "12:00", threats: 6, neutralized: 6, active: 0 },
  { time: "16:00", threats: 22, neutralized: 22, active: 0 },
  { time: "20:00", threats: 11, neutralized: 11, active: 0 },
];

const defenseSystemsData = [
  { system: "Orbital Defense Grid", efficiency: 98, readiness: 100 },
  { system: "Missile Defense Array", efficiency: 96, readiness: 98 },
  { system: "Energy Weapon Network", efficiency: 94, readiness: 97 },
  { system: "Early Warning System", efficiency: 99, readiness: 100 },
];

const threatTypeDistribution = [
  { type: "Asteroid Objects", count: 45, fill: "#10B981" },
  { type: "Space Debris", count: 128, fill: "#3B82F6" },
  { type: "Unknown Objects", count: 8, fill: "#F59E0B" },
  { type: "Artificial Threats", count: 2, fill: "#EF4444" },
];

const defenseLog = [
  { id: "DEF-001", threat: "Asteroid Fragment", size: "2.3m", distance: "450,000 km", action: "Intercepted", outcome: "Neutralized" },
  { id: "DEF-002", threat: "Space Debris Cluster", size: "Multiple", distance: "89,000 km", action: "Deflected", outcome: "Clear Path" },
  { id: "DEF-003", threat: "Unknown Object", size: "15.7m", distance: "1.2M km", action: "Monitoring", outcome: "Tracking" },
];

const systemStatusLog = [
  { system: "Orbital Defense Grid", status: "Operational", uptime: "99.98%", lastMaintenance: "2 days ago" },
  { system: "Early Warning Array", status: "Operational", uptime: "99.95%", lastMaintenance: "1 day ago" },
  { system: "Missile Defense Network", status: "Operational", uptime: "99.92%", lastMaintenance: "3 days ago" },
];

const ChartTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
          <p className="label text-white font-medium mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color || entry.stroke || entry.fill }}>{`${entry.name}: ${entry.value}`}</p>
          ))}
        </div>
      );
    }
    return null;
};

const getStatusBadge = (status) => {
    if (status === "Operational") return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{status}</Badge>;
    if (status === "Neutralized") return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{status}</Badge>;
    if (status === "Clear Path") return <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">{status}</Badge>;
    if (status === "Tracking") return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">{status}</Badge>;
    return <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">{status}</Badge>;
};

const getActionBadge = (action) => {
    if (action === "Intercepted") return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">{action}</Badge>;
    if (action === "Deflected") return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">{action}</Badge>;
    if (action === "Monitoring") return <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">{action}</Badge>;
    return <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">{action}</Badge>;
};

export default function PlanetaryDefensePage() {
  const [timeframe, setTimeframe] = useState('24H');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Planetary Defense Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Shield className="w-10 h-10 mr-3 text-green-400" />
            Planetary Defense Command
          </h1>
          <p className="orbital-text-subtitle">Advanced threat detection and neutralization systems protecting Earth and colonies.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex bg-[#0A0D18] border border-gray-800 rounded-lg p-1">
            {['6H', '24H', '7D', '30D'].map(period => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${
                  timeframe === period
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Frame 1: Defense KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {defenseKPIs.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                <Icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
            </div>
          );
        })}
      </div>

      {/* Frame 2: Defense Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Threat Detection Timeline */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Radar className="w-5 h-5 mr-2 text-purple-400" />
            Threat Detection & Response
          </h3>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={threatDetectionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<ChartTooltip />} />
                <Line type="monotone" dataKey="threats" name="Threats Detected" stroke="#F59E0B" strokeWidth={2} />
                <Line type="monotone" dataKey="neutralized" name="Neutralized" stroke="#10B981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Defense Systems Performance */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-green-400" />
            Defense Systems Status
          </h3>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={defenseSystemsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="system" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="efficiency" name="Efficiency %" fill="#22D3EE" />
                <Bar dataKey="readiness" name="Readiness %" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Threat Type Distribution */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-yellow-400" />
            Threat Classification
          </h3>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip content={<ChartTooltip />} />
                <Pie 
                  data={threatTypeDistribution} 
                  dataKey="count" 
                  nameKey="type" 
                  cx="50%" 
                  cy="50%" 
                  outerRadius={80} 
                  label={({name, value}) => `${name}: ${value}`}
                >
                  {threatTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Frame 3: Defense Intelligence */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Active Defense Operations */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-red-400" />
            Active Threat Response Log
          </h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Threat ID</TableHead>
                  <TableHead className="text-gray-400">Type</TableHead>
                  <TableHead className="text-gray-400">Size</TableHead>
                  <TableHead className="text-gray-400">Action</TableHead>
                  <TableHead className="text-gray-400">Outcome</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {defenseLog.map((threat) => (
                  <TableRow key={threat.id} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="font-mono text-xs text-cyan-400">{threat.id}</TableCell>
                    <TableCell className="font-medium text-white">{threat.threat}</TableCell>
                    <TableCell className="text-gray-300">{threat.size}</TableCell>
                    <TableCell>{getActionBadge(threat.action)}</TableCell>
                    <TableCell>{getStatusBadge(threat.outcome)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Defense System Status */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-green-400" />
            Defense System Health
          </h3>
          <div className="space-y-4">
            {systemStatusLog.map((system, i) => (
              <div key={i} className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="text-white font-semibold">{system.system}</h4>
                    <p className="text-xs text-gray-400">Last maintenance: {system.lastMaintenance}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(system.status)}
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">System Uptime</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full" 
                        style={{width: `${parseFloat(system.uptime)}%`}}
                      />
                    </div>
                    <span className="text-xs text-green-400 font-semibold w-12">{system.uptime}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}