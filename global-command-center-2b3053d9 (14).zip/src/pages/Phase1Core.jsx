
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { SystemConfig } from "@/api/entities";
import { AuditTrail } from "@/api/entities";
import { ToolRunLog } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Brain, Shield, Globe2, Activity, Rocket, Download, Save, RefreshCw, CheckCircle2, Link2, AlertTriangle } from "lucide-react";
import { BrandRules, applyBrandRules } from "@/components/brand/BrandRules";

const CONFIG_KEY = "PHASE1_CORE";

const LEARN_MODES = [
  { id: 1, title: "Global Command & Control", page: "CommandCenter" },
  { id: 2, title: "Real Estate Intelligence", page: "Assets" },
  { id: 3, title: "Aviation & Flight Learning", page: "GlobalMap" },
  { id: 4, title: "High-End Automotive Intelligence", page: "Assets" },
  { id: 5, title: "Energy & Sustainability", page: "ResilienceSystems" },
  { id: 6, title: "Healthcare & Biotech", page: "BioSymbiosis" },
  { id: 7, title: "Finance & Wealth Management", page: "Bank" },
  { id: 8, title: "Compliance & Legal Learning", page: "ComplianceCenter" },
  { id: 9, title: "Defense & Security AI", page: "ThreatAssessment" },
  { id: 10, title: "Retail & Commerce", page: "Commerce" },
  { id: 11, title: "Education & Human Development", page: "KnowledgeVault" },
  { id: 12, title: "Orbital Experimental / Frontier Mode", page: "AIObservability" },
];

export default function Phase1Core() {
  const [me, setMe] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [auditStats, setAuditStats] = React.useState({ total7d: 0 });
  const [form, setForm] = React.useState({
    ai_core: { runtime_installed: true, memory_enabled: true, quantum_placeholders: true },
    proton_security: {
      e2e_encryption: true,
      key_vault_enabled: true,
      zero_trust_enforced: true,
      vpn_tunneling_enabled: true,
      protection_index: 87
    },
    global_toggles: {
      multi_tenant: true,
      multi_language: true,
      multi_currency: true,
      default_locale: "en-US",
      default_currency: "USD",
      brand_theme: "Orbital",
      ai_copilot_enabled: true,
      compliance_by_default: true,
      cdn_prefetch_enabled: true
    },
    brand_rules: `Brand: Orbital
Primary: #06B6D4
Secondary: #8B5CF6
Tone: Elite, Secure, Futuristic
`,
    audit_recovery: {
      self_healing_agents: true,
      auto_rollback_snapshots: true,
      error_recovery_playbooks: true,
      observability_encrypted: true,
      last_snapshot_at: null
    },
    learn_modes: Object.fromEntries(Array.from({length: 12}, (_,i)=>[`${i+1}`, true])) // toggle-enabled, default ON
  });

  React.useEffect(() => {
    // Enforce Orbital branding across Phase 1 pages
    applyBrandRules(BrandRules);
  }, []);

  const load = React.useCallback(async () => {
    setLoading(true);
    let current = null;
    try { current = await User.me(); } catch {}
    setMe(current);

    const rows = await SystemConfig.filter({ config_key: CONFIG_KEY }, "-updated_date", 1);
    const cfg = rows?.[0];
    if (cfg) {
      setConfigId(cfg.id);
      const val = cfg.config_value || {};
      setForm(prev => ({
        ...prev,
        ...val,
        // ensure new keys are present and merged correctly
        global_toggles: {
          ...prev.global_toggles, // Start with default global_toggles
          ...(val.global_toggles || {}) // Override with loaded values
        },
        proton_security: {
          ...prev.proton_security, // Start with default proton_security
          ...(val.proton_security || {}) // Override with loaded values
        },
        learn_modes: {
          ...Object.fromEntries(Array.from({length: 12}, (_,i)=>[`${i+1}`, true])), // Default all learn modes to true
          ...(val.learn_modes || {}) // Override with loaded values
        }
      }));
    } else {
      setConfigId(null);
      // If no config found, ensure form is set to its initial default state
      setForm(prev => ({
        ...prev, // Use the initial state as defined
        global_toggles: {
          ...prev.global_toggles,
          ai_copilot_enabled: true,
          compliance_by_default: true,
          cdn_prefetch_enabled: true
        },
        learn_modes: Object.fromEntries(Array.from({length: 12}, (_,i)=>[`${i+1}`, true]))
      }));
    }

    const audits = await AuditTrail.list("-created_date", 1000);
    const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
    const total7d = (audits || []).filter(a => {
      const t = new Date(a.created_date).getTime();
      return !isNaN(t) && t >= cutoff;
    }).length;
    setAuditStats({ total7d });

    setLoading(false);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    // Enforce Proton Security always ON
    const enforcedProton = {
      ...form.proton_security,
      e2e_encryption: true,
      key_vault_enabled: true,
      zero_trust_enforced: true,
      vpn_tunneling_enabled: true
    };
    const safeForm = { ...form, proton_security: enforcedProton };

    const payload = {
      config_key: CONFIG_KEY,
      config_value: { ...safeForm },
      description: "Phase 1 — Orbital Core & Foundation (AI Core, Learn Modes, Proton Security, Global Toggles, Audit Panel)",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    let action = "CREATE";
    let entityId = "PHASE1_CORE";
    if (configId) {
      await SystemConfig.update(configId, payload);
      action = "UPDATE";
      entityId = configId;
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
      entityId = created.id;
    }

    // Log to AuditTrail
    await AuditTrail.create({
      entity_type: "SystemConfig",
      entity_id: entityId,
      action,
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: { CONFIG_KEY, config_value: safeForm },
      security_classification: "CONFIDENTIAL",
      risk_score: 10
    });

    setSaving(false);
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(form, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "phase1_core_settings.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const logTestMemoryEvent = async () => {
    await ToolRunLog.create({
      tool_name: "InfinityGeniusMemory",
      status: "success",
      metadata: { message: "Test memory event from Phase 1 Core", config_key: CONFIG_KEY }
    });
  };

  const makeSnapshot = async () => {
    const ts = new Date().toISOString();
    const next = { ...form, audit_recovery: { ...form.audit_recovery, last_snapshot_at: ts } };
    setForm(next);
    const payload = {
      config_key: CONFIG_KEY,
      config_value: next,
      description: "Phase 1 — snapshot update",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    if (configId) {
      await SystemConfig.update(configId, payload);
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
    }
    await AuditTrail.create({
      entity_type: "SystemConfig",
      entity_id: configId || "PHASE1_CORE",
      action: "UPDATE",
      action_timestamp: new Date().toISOString(),
      user_id: me?.id || "system",
      changes_made: { snapshot_at: ts },
      security_classification: "CONFIDENTIAL",
      risk_score: 5
    });
  };

  // Readiness audit snapshot (self-audit)
  const readiness = React.useMemo(() => {
    const aiCoreReady = !!(form.ai_core?.runtime_installed && form.ai_core?.memory_enabled);
    const protonReady = !!(form.proton_security?.e2e_encryption && form.proton_security?.key_vault_enabled && form.proton_security?.zero_trust_enforced && form.proton_security?.vpn_tunneling_enabled);
    const learnCount = Object.values(form.learn_modes || {}).filter(Boolean).length;
    const learnPct = (learnCount || 0) / 12;
    const globalToggles = [
      form.global_toggles?.ai_copilot_enabled,
      form.global_toggles?.compliance_by_default,
      form.global_toggles?.cdn_prefetch_enabled
    ];
    const globalPct = (globalToggles.filter(Boolean).length) / globalToggles.length || 0;
    const auditReady = !!(form.audit_recovery?.self_healing_agents && form.audit_recovery?.auto_rollback_snapshots && form.audit_recovery?.error_recovery_playbooks && form.audit_recovery?.observability_encrypted);

    const overall = Math.round(((aiCoreReady?1:0) + (protonReady?1:0) + learnPct + globalPct + (auditReady?1:0)) / 5 * 100);
    return {
      aiCoreReady,
      protonReady,
      learnCount,
      globalPct: Math.round(globalPct * 100),
      auditReady,
      overall
    };
  }, [form]);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Rocket className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Phase 1 — Orbital Core & Foundation</h1>
            <p className="orbital-text-subtitle">Nothing forgotten, nothing missed. Core scaffolding ready for Phase 2.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={load} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
          <Button onClick={save} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
            <Save className={`w-4 h-4 mr-2 ${saving ? "animate-spin" : ""}`} /> Save
          </Button>
          <Button variant="outline" onClick={exportJSON}>
            <Download className="w-4 h-4 mr-2" /> Export JSON
          </Button>
        </div>
      </div>

      {/* Readiness Summary (Self-Audit) */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        <div className="p-3 rounded-lg bg-[#0A0D18]/60 border border-gray-800">
          <div className="text-xs text-gray-400 mb-1">AI Core</div>
          <div className={`text-sm ${readiness.aiCoreReady ? "text-emerald-400" : "text-amber-400"}`}>
            {readiness.aiCoreReady ? "Ready" : "Needs Attention"}
          </div>
        </div>
        <div className="p-3 rounded-lg bg-[#0A0D18]/60 border border-gray-800">
          <div className="text-xs text-gray-400 mb-1">Proton Security</div>
          <div className={`text-sm ${readiness.protonReady ? "text-emerald-400" : "text-amber-400"}`}>
            {readiness.protonReady ? "Enforced" : "Incomplete"}
          </div>
        </div>
        <div className="p-3 rounded-lg bg-[#0A0D18]/60 border border-gray-800">
          <div className="text-xs text-gray-400 mb-1">Learn Modes</div>
          <div className="text-sm text-cyan-400">{readiness.learnCount}/12 enabled</div>
        </div>
        <div className="p-3 rounded-lg bg-[#0A0D18]/60 border border-gray-800">
          <div className="text-xs text-gray-400 mb-1">Global Toggles</div>
          <div className="text-sm text-cyan-400">{readiness.globalPct}% active</div>
        </div>
        <div className="p-3 rounded-lg bg-[#0A0D18]/60 border border-gray-800">
          <div className="text-xs text-gray-400 mb-1">Audit & Recovery</div>
          <div className={`text-sm ${readiness.auditReady ? "text-emerald-400" : "text-amber-400"}`}>
            {readiness.auditReady ? "Operational" : "Incomplete"}
          </div>
          <div className="text-[10px] text-gray-500 mt-1">Overall: <span className="text-cyan-400">{readiness.overall}%</span></div>
        </div>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" /> Orbital AI Core
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">Runtime Installed</Label>
              <Switch checked={!!form.ai_core.runtime_installed} onCheckedChange={(v) => setForm(prev => ({ ...prev, ai_core: { ...prev.ai_core, runtime_installed: v } }))} />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">Infinity Genius Memory</Label>
              <Switch checked={!!form.ai_core.memory_enabled} onCheckedChange={(v) => setForm(prev => ({ ...prev, ai_core: { ...prev.ai_core, memory_enabled: v } }))} />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300">Quantum-Ready Placeholders</Label>
              <Switch checked={!!form.ai_core.quantum_placeholders} onCheckedChange={(v) => setForm(prev => ({ ...prev, ai_core: { ...prev.ai_core, quantum_placeholders: v } }))} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={logTestMemoryEvent}>
              <Activity className="w-4 h-4 mr-2" /> Log Test Memory Event
            </Button>
            <Badge className="bg-gray-700/40 text-gray-300">Audit last 7d: {auditStats.total7d} events</Badge>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-cyan-400" /> Orbital 12 Learn Modes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Learn Modes Toggles */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {LEARN_MODES.map(m => (
              <div key={`toggle-${m.id}`} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{m.title}</Label>
                <Switch
                  checked={!!form.learn_modes[m.id]}
                  onCheckedChange={(v) => setForm(prev => ({ ...prev, learn_modes: { ...prev.learn_modes, [m.id]: v } }))}
                />
              </div>
            ))}
          </div>

          {/* Existing Learn Modes Links */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {LEARN_MODES.map(m => (
              <Link key={m.id} to={createPageUrl(m.page)} className="block p-3 rounded-lg bg-[#0C0F19] border border-gray-800 hover:border-cyan-500/40 transition">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-white font-medium">Mode {m.id}: {m.title}</div>
                  <Link2 className="w-4 h-4 text-cyan-400" />
                </div>
                <p className="text-xs text-gray-400 mt-1">Linked to {m.page} dashboard</p>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-400" /> Orbital Proton Security Layer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "e2e_encryption", label: "End-to-End Encryption (placeholders wired)" },
              { key: "key_vault_enabled", label: "Encrypted Key Vault (credentials)" },
              { key: "zero_trust_enforced", label: "Zero-Trust Admin Access" },
              { key: "vpn_tunneling_enabled", label: "Proton VPN + Secure Tunneling" },
            ].map(i => (
              <div key={i.key} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{i.label}</Label>
                <Switch
                  checked={!!form.proton_security[i.key]}
                  disabled // Enforce Proton Security always ON
                  onCheckedChange={() => {}} // No-op as it's disabled
                />
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label htmlFor="protection_index" className="text-gray-300">Infinity Genius Protection Index</Label>
              <Input
                id="protection_index"
                type="number"
                min={0}
                max={100}
                value={form.proton_security.protection_index ?? 0}
                onChange={(e) => setForm(prev => ({ ...prev, proton_security: { ...prev.proton_security, protection_index: Number(e.target.value || 0) } }))}
                className="w-24 bg-[#0C0F19] border-gray-700 text-gray-100"
              />
            </div>
            {form.proton_security.protection_index >= 80 ? (
              <Badge className="bg-green-500/20 text-green-400">STRONG</Badge>
            ) : form.proton_security.protection_index >= 60 ? (
              <Badge className="bg-yellow-500/20 text-yellow-400">MODERATE</Badge>
            ) : (
              <Badge className="bg-red-500/20 text-red-400">LOW</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-emerald-400" /> Orbital Global Toggles
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { key: "multi_tenant", label: "Multi-Tenant" },
              { key: "multi_language", label: "Multi-Language" },
              { key: "multi_currency", label: "Multi-Currency" },
            ].map(i => (
              <div key={i.key} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{i.label}</Label>
                <Switch
                  checked={!!form.global_toggles[i.key]}
                  onCheckedChange={(v) => setForm(prev => ({ ...prev, global_toggles: { ...prev.global_toggles, [i.key]: v } }))}
                />
              </div>
            ))}
          </div>
          {/* New Global Toggles */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { key: "ai_copilot_enabled", label: "Orbital AI CoPilot" },
              { key: "compliance_by_default", label: "Compliance-by-Default" },
              { key: "cdn_prefetch_enabled", label: "CDN Prefetch" },
            ].map(i => (
              <div key={i.key} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{i.label}</Label>
                <Switch
                  checked={!!form.global_toggles[i.key]}
                  onCheckedChange={(v) => setForm(prev => ({ ...prev, global_toggles: { ...prev.global_toggles, [i.key]: v } }))}
                />
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300 text-xs">Default Locale</Label>
              <Input
                value={form.global_toggles.default_locale}
                onChange={(e) => setForm(prev => ({ ...prev, global_toggles: { ...prev.global_toggles, default_locale: e.target.value } }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="e.g. en-US"
              />
            </div>
            <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300 text-xs">Default Currency</Label>
              <Input
                value={form.global_toggles.default_currency}
                onChange={(e) => setForm(prev => ({ ...prev, global_toggles: { ...prev.global_toggles, default_currency: e.target.value } }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="e.g. USD"
              />
            </div>
            <div className="p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
              <Label className="text-gray-300 text-xs">Brand Theme</Label>
              <Input
                value={form.global_toggles.brand_theme}
                onChange={(e) => setForm(prev => ({ ...prev, global_toggles: { ...prev.global_toggles, brand_theme: e.target.value } }))}
                className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
                placeholder="Orbital"
              />
            </div>
          </div>
          <div>
            <Label className="text-gray-300 text-xs">Brand Rules</Label>
            <Textarea
              rows={6}
              value={form.brand_rules}
              onChange={(e) => setForm(prev => ({ ...prev, brand_rules: e.target.value }))}
              className="mt-1 bg-[#0C0F19] border-gray-700 text-gray-100"
            />
          </div>
          {/* Compliance-by-Default frameworks */}
          <div className="mt-2 p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
            <div className="text-xs text-gray-400">Compliance-by-Default includes:</div>
            <div className="flex flex-wrap gap-2 mt-2">
              {["SOC2", "ISO27001", "HIPAA", "PCI-DSS", "GDPR"].map((c) => (
                <span key={c} className="text-[11px] px-2 py-1 rounded-md border border-gray-700 text-gray-300">{c}</span>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" /> Orbital Audit & Recovery Panel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "self_healing_agents", label: "Self-Healing Monitoring Agents" },
              { key: "auto_rollback_snapshots", label: "Automated Rollback Snapshots" },
              { key: "error_recovery_playbooks", label: "Error Recovery Playbooks" },
              { key: "observability_encrypted", label: "Encrypted Logs, Metrics, Traces" },
            ].map(i => (
              <div key={i.key} className="flex items-center justify-between p-3 rounded-lg bg-[#0C0F19] border border-gray-800">
                <Label className="text-gray-300">{i.label}</Label>
                <Switch
                  checked={!!form.audit_recovery[i.key]}
                  onCheckedChange={(v) => setForm(prev => ({ ...prev, audit_recovery: { ...prev.audit_recovery, [i.key]: v } }))}
                />
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={makeSnapshot}>
              <Save className="w-4 h-4 mr-2" /> Create Snapshot (placeholder)
            </Button>
            {form.audit_recovery.last_snapshot_at ? (
              <Badge className="bg-green-500/20 text-green-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Last snapshot: {new Date(form.audit_recovery.last_snapshot_at).toLocaleString()}
              </Badge>
            ) : (
              <Badge className="bg-gray-600/30 text-gray-300 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> No snapshots yet
              </Badge>
            )}
            <Button asChild variant="outline" className="ml-auto">
              <Link to={createPageUrl('RecoveryCenter')}>Open Recovery Center</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
