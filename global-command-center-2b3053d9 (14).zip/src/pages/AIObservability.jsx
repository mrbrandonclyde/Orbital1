import React, { useEffect, useMemo, useState } from "react";
import { ToolRunLog } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Activity } from "lucide-react";

export default function AIObservabilityPage() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    (async () => {
      const list = await ToolRunLog.list("-created_date", 500);
      setLogs(list);
    })();
  }, []);

  const toolStats = useMemo(() => {
    const map = {};
    logs.forEach(l => {
      const key = `${l.tool_name}:${l.status}`;
      map[key] = (map[key] || 0) + 1;
    });
    return Object.entries(map).map(([k, v]) => {
      const [tool, status] = k.split(":");
      return { tool, status, count: v };
    });
  }, [logs]);

  const latencyData = useMemo(() => {
    const byTool = {};
    logs.forEach(l => {
      if (!byTool[l.tool_name]) byTool[l.tool_name] = [];
      if (typeof l.latency_ms === "number") byTool[l.tool_name].push(l.latency_ms);
    });
    return Object.entries(byTool).map(([tool, arr]) => ({
      tool,
      avg_latency: Math.round(arr.reduce((a, b) => a + b, 0) / arr.length)
    }));
  }, [logs]);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center"><Activity className="w-10 h-10 mr-3 text-green-400" />AI Observability</h1>
        <p className="orbital-text-subtitle">Run logs, success/error counts, and latency by tool.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">Runs by Tool & Status</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={toolStats}>
                <XAxis dataKey="tool" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip />
                <Bar dataKey="count" fill="#06B6D4" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">Average Latency (ms)</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={latencyData}>
                <XAxis dataKey="tool" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip />
                <Bar dataKey="avg_latency" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader><CardTitle className="text-white">Recent Runs</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-gray-400">When</TableHead>
                <TableHead className="text-gray-400">Tool</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">Latency</TableHead>
                <TableHead className="text-gray-400">Context</TableHead>
                <TableHead className="text-gray-400">Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map(l => (
                <TableRow key={l.id} className="border-gray-800">
                  <TableCell className="text-gray-300">{new Date(l.created_date).toLocaleString()}</TableCell>
                  <TableCell className="text-gray-300">{l.tool_name}</TableCell>
                  <TableCell className={l.status === "success" ? "text-green-400" : "text-red-400"}>{l.status}</TableCell>
                  <TableCell className="text-gray-300">{typeof l.latency_ms === "number" ? `${l.latency_ms} ms` : "—"}</TableCell>
                  <TableCell className="text-gray-400 text-xs">{l.run_context}</TableCell>
                  <TableCell className="text-red-400 text-xs">{l.error_message || "—"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}