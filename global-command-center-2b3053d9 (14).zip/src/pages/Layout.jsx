

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Crown,
  Building2,
  Briefcase,
  Globe,
  Shield,
  Zap,
  Settings,
  Users,
  MessageSquare,
  FileText,
  BarChart3,
  AlertTriangle,
  Home,
  Banknote,
  Package,
  Map,
  Calendar,
  Database,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Rocket,
  Brain,
  Target,
  Activity,
  BookOpen,
  Terminal,
  HelpCircle,
  Bot,
  Bell,
  Gift,
  CheckSquare,
  Network,
  Key,
  GitBranch,
  UserCircle,
  Lightbulb,
  RefreshCw,
  Dna,
  ChevronDown, // NEW: collapse indicator
  ChevronUp, // NEW: collapse indicator
  LayoutDashboard, // NEW: for Build Kanban
  Layers, // NEW: Funnels icon
  ShoppingCart, // NEW: for Funnel Builder E-Commerce
  Plug, // NEW: for Funnel Builder Integrations
  LayoutDashboard as LayoutDashIcon, // NEW: for Funnel Builder Dashboard
  FileText as FileTextIcon, // NEW: for Funnel Builder Pages
  Server, // NEW
  Send,   // NEW
  Wallet,  // NEW
  Wand2 // NEW: for AI Funnel Studio
} from 'lucide-react';
import { AuthProvider, useAuth } from './components/context/AuthContext';
import ZyraChat from './components/chat/ZyraChat';
import FeedbackWidget from './components/feedback/FeedbackWidget';
import { ToastContainer } from './components/common/Toast';
import { AccessibilityProvider } from './components/common/AccessibilityProvider';
import FocusManager from './components/common/FocusManager';
import ErrorBoundary from './components/common/ErrorBoundary';
import NavigationBreadcrumbs from './components/navigation/NavigationBreadcrumbs';
import QuickNavigation from './components/navigation/QuickNavigation';
import { useRealtimeConnection } from './components/hooks/useRealtime';
import navigationService from './components/lib/NavigationService';
import { applyBrandRules } from './components/brand/BrandRules';

// STEALTH GUARDIAN ENGINE - Unchanged
const StealthGuardianEngine = () => {
  React.useEffect(() => {
    // Background operations
  }, []);
  return null;
};

const LayoutContent = ({ children, currentPageName }) => {
  const { user, login, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showQuickNav, setShowQuickNav] = useState(false);
  const connectionStatus = useRealtimeConnection();
  // NEW: collapsed state per section (persisted)
  const [collapsedSections, setCollapsedSections] = useState({});

  // Ensure brand CSS variables are applied on mount
  React.useEffect(() => {
    applyBrandRules();
  }, []);

  // Track page visits for navigation intelligence
  React.useEffect(() => {
    if (currentPageName) {
      navigationService.trackPageVisit(currentPageName);
    }
  }, [currentPageName]);

  // NEW: Load/save collapsed sections to localStorage
  React.useEffect(() => {
    try {
      const raw = localStorage.getItem('orbital.sidebar.collapsedSections');
      if (raw) setCollapsedSections(JSON.parse(raw) || {});
    } catch (e) {
      console.error("Failed to load collapsed sections from localStorage:", e);
    }
  }, []);

  const toggleSection = (title) => {
    setCollapsedSections((prev) => {
      const next = { ...prev, [title]: !prev[title] };
      try {
        localStorage.setItem('orbital.sidebar.collapsedSections', JSON.stringify(next));
      } catch (e) {
        console.error("Failed to save collapsed sections to localStorage:", e);
      }
      return next;
    });
  };

  // Build role-aware Funnel Builder main section
  const userRole = user?.app_role || 'ADMIN';
  const funnelBuilderItems = [
    { name: 'Dashboard', icon: LayoutDashIcon, href: createPageUrl('FunnelDashboard'), roles: ['ADMIN','MARKETER','TEAM_MEMBER','CLIENT_PORTAL'] },
    // NEW: Master Plan
    { name: 'Master Plan', icon: Target, href: createPageUrl('FunnelMasterPlan'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    { name: 'Funnels', icon: Layers, href: createPageUrl('Funnels'), roles: ['ADMIN','MARKETER','TEAM_MEMBER','CLIENT_PORTAL'] },
    { name: 'Pages', icon: FileTextIcon, href: createPageUrl('FunnelPages'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    { name: 'Automation', icon: Zap, href: createPageUrl('FunnelAutomation'), roles: ['ADMIN','MARKETER'] },
    // NEW: AI Funnel Studio entry
    { name: 'AI Funnel Studio', icon: Wand2, href: createPageUrl('AIFunnelBuilder'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    // NEW: Audit Checklist
    { name: 'Audit Checklist', icon: CheckSquare, href: createPageUrl('FunnelAudit'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    // New: Future modules (hooks)
    { name: 'VR/AR Demos', icon: Rocket, href: createPageUrl('FunnelVRAR'), roles: ['ADMIN','MARKETER'] },
    { name: 'Voice Funnels', icon: MessageSquare, href: createPageUrl('VoiceFunnels'), roles: ['ADMIN','MARKETER'] },
    { name: 'Marketplace', icon: ShoppingCart, href: createPageUrl('TemplateMarketplace'), roles: ['ADMIN','MARKETER'] },
    { name: 'White-label SaaS', icon: Building2, href: createPageUrl('WhiteLabelSaaS'), roles: ['ADMIN'] },
    { name: 'Contacts / CRM', icon: Users, href: createPageUrl('CRM'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    { name: 'E-Commerce', icon: ShoppingCart, href: createPageUrl('Commerce'), roles: ['ADMIN','MARKETER'] },
    { name: 'Analytics & Reports', icon: BarChart3, href: createPageUrl('FunnelAnalytics'), roles: ['ADMIN','MARKETER','TEAM_MEMBER'] },
    { name: 'Integrations', icon: Plug, href: createPageUrl('FunnelIntegrations'), roles: ['ADMIN'] },
    { name: 'Settings', icon: Settings, href: createPageUrl('FunnelSettings'), roles: ['ADMIN'] }
  ].filter(i => !i.roles || i.roles.includes(userRole));

  const navigationSections = [
    {
      title: "Core Modules",
      items: [
        { name: 'Orbital Browser', icon: Globe, href: createPageUrl('OrbitalBrowser') }
      ]
    },
    {
      title: "Funnel Builder",
      items: funnelBuilderItems
    },
    {
      title: "Zyra AI Command",
      items: [
        { name: 'Zyra Dashboard', icon: MessageSquare, href: createPageUrl('ZyraCommand') },
        { name: 'Team Chat', icon: Users, href: createPageUrl('TeamChat') },
        { name: 'AI Agents', icon: Bot, href: createPageUrl('AIAgents') },
        { name: 'Operations Control', icon: Target, href: createPageUrl('CommandCenter') },
        { name: 'Global System Monitoring', icon: Activity, href: createPageUrl('SystemStatus') },
        { name: 'Analytics & Insights', icon: BarChart3, href: createPageUrl('Analytics') },
        { name: 'Personnel Insights', icon: Users, href: createPageUrl('Personnel') },
        { name: 'Operations Log', icon: BookOpen, href: createPageUrl('AuditTrail') },
        { name: 'System Alerts', icon: AlertTriangle, href: createPageUrl('Alerts') },
        // Added tools:
        { name: 'Prompt Studio', icon: Lightbulb, href: createPageUrl('PromptStudio') },
        { name: 'Workflow Builder', icon: GitBranch, href: createPageUrl('WorkflowBuilder') },
        { name: 'AI Observability', icon: Activity, href: createPageUrl('AIObservability') },
        // NEW: AI Assets library
        { name: 'AI Assets', icon: FileText, href: createPageUrl('AIAssets') }
      ]
    },
    {
      title: "Executive Command",
      items: [
        { name: 'Command Center', icon: Crown, href: createPageUrl('CommandCenter') },
        { name: 'Executive Profile', icon: Users, href: createPageUrl('Executive') },
        { name: 'Genius Mansion', icon: Home, href: createPageUrl('Mansion') },
        { name: 'VR War Room', icon: Globe, href: createPageUrl('VRWarRoom') }
      ]
    },
    {
      title: "Guardian Command Matrix",
      items: [
        { name: 'Bio-Symbiosis', icon: Brain, href: createPageUrl('BioSymbiosis') },
        { name: 'Guardian Corps', icon: Shield, href: createPageUrl('GuardianCorps') },
        { name: 'Mission Control', icon: Target, href: createPageUrl('Missions') },
        { name: 'Global Governance', icon: Building2, href: createPageUrl('GlobalGovernance') }
      ]
    },
    {
      title: "Interplanetary Command",
      items: [
        { name: 'Interplanetary Command', icon: Rocket, href: createPageUrl('InterplanetaryOps') },
        { name: 'Planetary Defense', icon: Shield, href: createPageUrl('PlanetaryDefense') },
        { name: 'Colonization Ops', icon: Rocket, href: createPageUrl('Colonization') },
        { name: 'AETHER Network', icon: Network, href: createPageUrl('AetherNetwork') },
      ]
    },
    {
      title: "Strategic Assets",
      items: [
        { name: 'Asset Portfolio', icon: Package, href: createPageUrl('Assets') },
        { name: 'Orbital Bank', icon: Banknote, href: createPageUrl('Bank') },
        { name: 'Supply Chain', icon: Building2, href: createPageUrl('SupplyChain') },
        { name: 'Sectors Intel', icon: Briefcase, href: createPageUrl('Sectors') },
        { name: 'Blockchain', icon: Database, href: createPageUrl('Blockchain') },
        { name: 'Blockchain Strategy', icon: Target, href: createPageUrl('BlockchainStrategy') }
      ]
    },
    {
      title: "Intelligence & Operations",
      items: [
        { name: 'Quantum Insights', icon: Zap, href: createPageUrl('Insights') },
        { name: 'Global Map', icon: Map, href: createPageUrl('GlobalMap') },
        { name: 'Threat Assessment', icon: Shield, href: createPageUrl('ThreatAssessment') },
        { name: 'Analytics', icon: BarChart3, href: createPageUrl('Analytics') },
        { name: 'Urban Planner', icon: Building2, href: createPageUrl('UrbanPlanner') },
        { name: 'Knowledge Vault', icon: BookOpen, href: createPageUrl('KnowledgeVault') } 
      ]
    },
    {
      title: "Modules",
      items: [
        { name: 'Orchestrator', icon: GitBranch, href: createPageUrl('Orchestrator') },
        { name: 'Avatars', icon: UserCircle, href: createPageUrl('Avatars') },
        { name: 'Assets', icon: Package, href: createPageUrl('AssetsHub') }, // Renamed to avoid clash with Strategic Assets. User implies new 'hub pages' so 'AssetsHub' sounds correct for a module.
        { name: 'Insights', icon: Lightbulb, href: createPageUrl('InsightsHub') }, // Renamed for module hub
        { name: 'Defense & Security', icon: Shield, href: createPageUrl('DefenseSecurity') },
        { name: 'Resilience Systems', icon: Activity, href: createPageUrl('ResilienceSystems') },
        { name: 'Expansion', icon: Building2, href: createPageUrl('Expansion') },
        { name: 'Containment', icon: AlertTriangle, href: createPageUrl('Containment') },
        { name: 'Continuity', icon: RefreshCw, href: createPageUrl('Continuity') },
        { name: 'Space Ops', icon: Rocket, href: createPageUrl('SpaceOps') },
        { name: 'Symbiosis', icon: Brain, href: createPageUrl('Symbiosis') },
        { name: 'Civilization', icon: Globe, href: createPageUrl('Civilization') },
        { name: 'Federation (Phase 6+)', icon: Network, href: createPageUrl('Federation') },
        { name: 'Admin / Executive Profile', icon: Crown, href: createPageUrl('AdminExecutive') },
        // New Orbital Browser module entry
        // REMOVED from here to be a top-level section: { name: 'Orbital Browser', icon: Globe, href: createPageUrl('OrbitalBrowser') }
      ]
    },
    {
      title: "Delivery",
      items: [
        { name: 'Build Kanban', icon: LayoutDashboard, href: createPageUrl('BuildKanban') },
        { name: 'Funnels', icon: Layers, href: createPageUrl('Funnels') } // NEW
      ]
    },
    {
      title: "Communications",
      items: [
        { name: 'Secure Comms', icon: MessageSquare, href: createPageUrl('Communications') },
        { name: 'Alerts Monitor', icon: AlertTriangle, href: createPageUrl('Alerts') },
        { name: 'Reports', icon: FileText, href: createPageUrl('Reports') }
      ]
    },
    {
      title: "System Control",
      items: [
        { name: 'Phase 0 Alignment', icon: Target, href: createPageUrl('Phase0Alignment') },
        { name: 'Phase 1 Core', icon: Rocket, href: createPageUrl('Phase1Core') },
        { name: 'Data Sources', icon: Database, href: createPageUrl('DataSources') },
        { name: 'Security Center', icon: CheckSquare, href: createPageUrl('SecurityCenter') },
        { name: 'System Status', icon: Settings, href: createPageUrl('SystemStatus') },
        { name: 'Personnel', icon: Users, href: createPageUrl('Personnel') },
        { name: 'System Admin', icon: Terminal, href: createPageUrl('Admin') },
        { name: 'Access Diagnostics', icon: Key, href: createPageUrl('AccessDiagnostics') },
        { name: 'Support', icon: HelpCircle, href: createPageUrl('Support') },
        { name: 'AI Settings', icon: Settings, href: createPageUrl('AISettings') }
      ]
    },
    {
      title: "Engagement",
      items: [
        { name: 'Notifications', icon: Bell, href: createPageUrl('NotificationCenter') },
        { name: 'Rewards Program', icon: Gift, href: createPageUrl('Rewards') },
      ]
    },
    {
      title: "Speed of Light Stack",
      items: [
        { name: 'Backend Status', icon: Server, href: createPageUrl('BackendStatus') },
        { name: 'Users (FastAPI)', icon: Users, href: createPageUrl('UsersBackend') },
        { name: 'Queue Task', icon: Send, href: createPageUrl('QueueTask') },
        { name: 'Blockchain', icon: Wallet, href: createPageUrl('BlockchainBalance') }
      ]
    }
  ];

  const isActivePage = (href) => {
    try {
      const pageUrl = new URL(href, window.location.origin);
      return pageUrl.pathname === window.location.pathname;
    } catch (e) {
      return false;
    }
  };

  // Keyboard shortcuts
  React.useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.metaKey || e.ctrlKey) {
        switch (e.key) {
          case 'k':
            e.preventDefault();
            setShowQuickNav(!showQuickNav);
            break;
          case '/':
            e.preventDefault();
            setIsChatOpen(!isChatOpen);
            break;
          case 'b':
            e.preventDefault();
            setIsSidebarOpen(!isSidebarOpen);
            break;
        }
      }
      if (e.key === 'Escape') {
        setShowQuickNav(false);
        setIsChatOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showQuickNav, isChatOpen, isSidebarOpen]);

  return (
    <div className="flex h-screen bg-[#020409] text-gray-300 font-sans overflow-hidden">
      <StealthGuardianEngine />

      {/* Sidebar */}
      <aside 
        className={`flex flex-col bg-[#0A0D18] border-r border-gray-800 transition-all duration-300 ease-in-out shadow-2xl z-30 ${
          isSidebarOpen ? 'w-80' : 'w-20'
        }`} 
        role="navigation" 
        aria-label="Main navigation"
      >
        {/* Sidebar Header - UPDATED WITH ORBITAL BRAND */}
        <div className={`flex items-center p-4 border-b border-gray-800 h-20 bg-gradient-to-r from-blue-900/20 to-purple-900/20 flex-shrink-0`}>
          {isSidebarOpen && (
            <Link to={createPageUrl('CommandCenter')} className="flex items-center space-x-3 flex-grow group" aria-label="Orbital Command Center Home">
              <div className="relative flex items-center space-x-3">
                {/* Orbital Logo Circle */}
                <div className="w-10 h-10 rounded-full border-2 border-cyan-400 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 flex items-center justify-center relative group-hover:border-cyan-300 transition-colors">
                  <div className="w-6 h-6 rounded-full border border-cyan-400 bg-cyan-400/10 group-hover:bg-cyan-300/20 transition-colors"></div>
                  <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse ${
                    connectionStatus.isConnected ? 'bg-green-400' : 'bg-red-400'
                  }`} aria-hidden="true"></div>
                </div>
                
                {/* Orbital Text */}
                <div>
                  <span className="text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">Orbital</span>
                  <p className="text-xs text-gray-400 -mt-1">Global Command Center</p>
                </div>
              </div>
            </Link>
          )}
          {!isSidebarOpen && (
            <Link to={createPageUrl('CommandCenter')} className="mx-auto group" aria-label="Orbital Command Center Home">
              <div className="w-10 h-10 rounded-full border-2 border-cyan-400 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 flex items-center justify-center relative group-hover:border-cyan-300 transition-colors">
                <div className="w-6 h-6 rounded-full border border-cyan-400 bg-cyan-400/10 group-hover:bg-cyan-300/20 transition-colors"></div>
                <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse ${
                  connectionStatus.isConnected ? 'bg-green-400' : 'bg-red-400'
                }`} aria-hidden="true"></div>
              </div>
            </Link>
          )}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className={`p-2 rounded-md hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
              !isSidebarOpen ? 'mx-auto mt-4' : 'ml-4'
            }`}
            aria-label={isSidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
            aria-expanded={isSidebarOpen}
          >
            {isSidebarOpen ? <ChevronLeft className="w-5 h-5" aria-hidden="true" /> : <ChevronRight className="w-5 h-5" aria-hidden="true" />}
          </button>
        </div>
        
        {/* Navigation Content - FIXED SCROLLING */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* UPDATED: add sidebar-scroll class for custom scrollbar */}
          <FocusManager className="flex-1 overflow-y-auto sidebar-scroll">
            <nav className="p-3 space-y-4" role="navigation">
              {navigationSections.map((section, sectionIndex) => {
                const isCollapsed = !!collapsedSections[section.title];
                return (
                  <div key={section.title}>
                    {isSidebarOpen && (
                      // UPDATED: clickable header to collapse/expand
                      <button
                        type="button"
                        onClick={() => toggleSection(section.title)}
                        className="w-full flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 px-3 hover:text-gray-300 transition-colors"
                        id={`nav-section-${sectionIndex}`}
                        aria-expanded={!isCollapsed}
                        aria-controls={`nav-group-${sectionIndex}`}
                      >
                        <span>{section.title}</span>
                        {isCollapsed ? (
                          <ChevronDown className="w-4 h-4 text-gray-500" aria-hidden="true" />
                        ) : (
                          <ChevronUp className="w-4 h-4 text-gray-400" aria-hidden="true" />
                        )}
                      </button>
                    )}
                    {!isSidebarOpen && sectionIndex > 0 && <div className="my-3 border-t border-gray-800" aria-hidden="true"></div>}
                    
                    {/* Only hide items when sidebar is open and section is collapsed */}
                    {(!isSidebarOpen || !isCollapsed) && (
                      <div
                        className="space-y-1"
                        role="group"
                        aria-labelledby={`nav-section-${sectionIndex}`}
                        id={`nav-group-${sectionIndex}`}
                      >
                        {section.items.map((item) => {
                          const isActive = item.href && isActivePage(item.href);
                          const commonClasses = `flex items-center p-3 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2 focus:ring-offset-[#0A0D18] ${
                            !isSidebarOpen ? 'justify-center' : ''
                          }`;
                          
                          if (item.action) {
                            return (
                              <button
                                key={item.name}
                                onClick={item.action}
                                className={`${commonClasses} w-full text-left hover:bg-gray-700/30 hover:text-white border border-transparent hover:border-cyan-500/20`}
                                title={item.name}
                                aria-label={item.ariaLabel || item.name}
                              >
                                <item.icon className={`flex-shrink-0 text-gray-400 ${isSidebarOpen ? 'w-5 h-5' : 'w-6 h-6'}`} aria-hidden="true" />
                                {isSidebarOpen && (
                                  <div className="ml-4">
                                    <span className="text-sm font-medium">{item.name}</span>
                                  </div>
                                )}
                              </button>
                            );
                          }
                          
                          return (
                            <Link
                              key={item.name}
                              to={item.href}
                              className={`${commonClasses} ${
                                isActive
                                  ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border border-cyan-500/30 shadow-lg'
                                  : 'hover:bg-gray-700/30 hover:text-white border border-transparent hover:border-cyan-500/20'
                              }`}
                              title={item.name}
                              aria-current={isActive ? 'page' : undefined}
                            >
                              <item.icon className={`flex-shrink-0 ${isActive ? 'text-cyan-400' : 'text-gray-400'} ${isSidebarOpen ? 'w-5 h-5' : 'w-6 h-6'}`} aria-hidden="true" />
                              {isSidebarOpen && (
                                <div className="ml-4">
                                  <span className="text-sm font-medium">{item.name}</span>
                                  {isActive && (
                                    <div className="w-1 h-1 bg-cyan-400 rounded-full mt-1" aria-hidden="true"></div>
                                  )}
                                </div>
                              )}
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </nav>
          </FocusManager>
        </div>
        
        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-800 bg-gradient-to-r from-gray-900/50 to-gray-800/50 flex-shrink-0">
          {user ? (
            <div className="flex items-center">
              <div className="relative">
                <img
                  src={user.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.full_name || 'Executive')}&background=8B5CF6&color=fff`}
                  alt={`${user.full_name || 'User'}'s profile picture`}
                  className="w-12 h-12 rounded-full object-cover border-2 border-purple-500/50"
                />
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-purple-600 rounded-full flex items-center justify-center" aria-hidden="true">
                  <Crown className="w-2 h-2 text-white" />
                </div>
              </div>
              {isSidebarOpen && (
                <>
                  <div className="ml-3 flex-grow">
                    <p className="text-sm font-semibold text-white">{user.full_name}</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-xs text-purple-400">{user.role}</p>
                      <span className="text-xs text-gray-500" aria-hidden="true">•</span>
                      <p className="text-xs text-gray-400">{user.security_clearance || 'CONFIDENTIAL'}</p>
                    </div>
                  </div>
                  <button
                    onClick={logout}
                    className="ml-auto p-2 rounded-md hover:bg-red-500/20 transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
                    title="Secure Logout"
                    aria-label="Log out of your account"
                  >
                    <LogOut className="w-4 h-4 text-red-400" />
                  </button>
                </>
              )}
            </div>
          ) : (
            isSidebarOpen && (
              <div className="text-center">
                <p className="text-sm text-gray-500">Authentication Required</p>
                <button
                  onClick={login}
                  className="mt-2 orbital-button-primary text-xs px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  aria-label="Log in to your executive account"
                >
                  Executive Login
                </button>
              </div>
            )
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden" role="main">
        {/* Header - UPDATED WITH ORBITAL BRANDING */}
        <header className="bg-[#0A0D18]/80 backdrop-blur-sm border-b border-gray-800 px-6 py-3 flex-shrink-0" role="banner">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full animate-pulse ${
                  connectionStatus.isConnected ? 'bg-green-400' : 'bg-red-400'
                }`} aria-hidden="true"></div>
                <span className={`text-xs font-medium ${
                  connectionStatus.isConnected ? 'text-green-400' : 'text-red-400'
                }`}>
                  {connectionStatus.isConnected ? 'ORBITAL SYSTEMS ONLINE' : 'OFFLINE MODE'}
                </span>
              </div>
              <div className="text-xs text-gray-400">
                <span className="sr-only">System status updated at </span>
                Last Update: {new Date().toLocaleTimeString()}
              </div>
              
              {/* Quick Actions */}
              <div className="hidden md:flex items-center space-x-2 text-xs">
                <button
                  onClick={() => setShowQuickNav(true)}
                  className="px-2 py-1 bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-300 hover:text-white transition-colors"
                >
                  ⌘K Quick Nav
                </button>
                <button
                  onClick={() => setIsChatOpen(true)}
                  className="px-2 py-1 bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-300 hover:text-white transition-colors"
                >
                  ⌘/ Zyra
                </button>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-xs" role="status" aria-label="System status indicators">
              <div className="flex items-center space-x-1">
                <Shield className="w-3 h-3 text-blue-400" aria-hidden="true" />
                <span className="text-blue-400">SECURE</span>
              </div>
              <div className="flex items-center space-x-1">
                <Zap className="w-3 h-3 text-yellow-400" aria-hidden="true" />
                <span className="text-yellow-400">AI ACTIVE</span>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto">
          <ErrorBoundary>
            <FocusManager autoFocus>
              <div className="p-6">
                {/* Breadcrumbs */}
                <NavigationBreadcrumbs 
                  currentPage={currentPageName} 
                  userClearance={user?.security_clearance} 
                />
                
                {/* Page Content */}
                {children}
              </div>
            </FocusManager>
          </ErrorBoundary>
        </div>
      </main>

      {/* Quick Navigation Modal */}
      {showQuickNav && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-20">
          <div className="bg-[#0A0D18] border border-gray-700 rounded-xl shadow-2xl w-full max-w-2xl mx-4">
            <div className="p-6">
              <QuickNavigation
                currentPage={currentPageName}
                userClearance={user?.security_clearance || 'CONFIDENTIAL'}
              />
            </div>
          </div>
        </div>
      )}

      {/* Overlays */}
      <ZyraChat isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
      <FeedbackWidget />
      <ToastContainer />
      
      {/* System Status Footer */}
      <div className="fixed bottom-6 left-6 bg-black/80 backdrop-blur-sm border border-gray-700 rounded-xl p-4 text-xs text-gray-400 shadow-2xl z-40" role="status" aria-live="polite">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" aria-hidden="true"></div>
            <span>Elite Performance: OPTIMAL</span>
          </div>
          <div className="w-px h-4 bg-gray-600" aria-hidden="true"></div>
          <div className="flex items-center space-x-2">
            <Crown className="w-3 h-3 text-purple-400" aria-hidden="true" />
            <span>Training Excellence</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function Layout({ children, currentPageName }) {
  return (
    <AccessibilityProvider>
      <AuthProvider>
        <LayoutContent currentPageName={currentPageName}>
          {children}
        </LayoutContent>
      </AuthProvider>
    </AccessibilityProvider>
  );
}

