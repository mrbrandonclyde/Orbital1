import React, { useEffect, useMemo, useState } from "react";
import { Workflow } from "@/api/entities";
import { KnowledgeDocument } from "@/api/entities";
import { ToolRunLog } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM, SendEmail } from "@/api/integrations";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { GitBranch, Play, Plus, Trash2 } from "lucide-react";

const PALETTE = [
  { id: "p1", type: "FetchDocs", label: "Fetch Docs" },
  { id: "p2", type: "AnalyzeLLM", label: "Analyze with LLM" },
  { id: "p3", type: "SendEmail", label: "Send Email" }
];

export default function WorkflowBuilderPage() {
  const [workflows, setWorkflows] = useState([]);
  const [selected, setSelected] = useState(null);
  const [nodes, setNodes] = useState([]);
  const [meta, setMeta] = useState({ name: "", description: "" });
  const [config, setConfig] = useState({});
  const [docs, setDocs] = useState([]);
  const [running, setRunning] = useState(false);
  const [runOutput, setRunOutput] = useState("");
  const [me, setMe] = useState(null);

  useEffect(() => {
    (async () => {
      setWorkflows(await Workflow.list("-updated_date", 50));
      try { setMe(await User.me()); } catch {}
      setDocs(await KnowledgeDocument.list("-updated_date", 200));
    })();
  }, []);

  useEffect(() => {
    if (!selected) {
      setNodes([]);
      setMeta({ name: "", description: "" });
      setConfig({});
      return;
    }
    setNodes(selected.nodes || []);
    setMeta({ name: selected.name || "", description: selected.description || "" });
    setConfig(Object.fromEntries((selected.nodes || []).map(n => [n.id, n.config || {}])));
  }, [selected]);

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const { source, destination, draggableId } = result;
    // palette to canvas: create new node
    if (source.droppableId === "palette" && destination.droppableId === "canvas") {
      const item = PALETTE.find(p => p.id === draggableId);
      const newNode = { id: `${item.type}-${Date.now()}`, type: item.type, config: {} };
      setNodes(prev => {
        const clone = Array.from(prev);
        clone.splice(destination.index, 0, newNode);
        return clone;
      });
    }
    // re-order canvas
    if (source.droppableId === "canvas" && destination.droppableId === "canvas") {
      const clone = Array.from(nodes);
      const [moved] = clone.splice(source.index, 1);
      clone.splice(destination.index, 0, moved);
      setNodes(clone);
    }
  };

  const save = async () => {
    const payload = {
      name: meta.name || "Untitled Workflow",
      description: meta.description || "",
      nodes: nodes.map(n => ({ id: n.id, type: n.type, config: config[n.id] || {} }))
    };
    if (selected?.id) {
      await Workflow.update(selected.id, payload);
    } else {
      const created = await Workflow.create(payload);
      setSelected(created);
    }
    setWorkflows(await Workflow.list("-updated_date", 50));
  };

  const removeNode = (id) => {
    setNodes(nodes.filter(n => n.id !== id));
    const copy = { ...config };
    delete copy[id];
    setConfig(copy);
  };

  const run = async () => {
    setRunning(true);
    setRunOutput("");
    let contextText = "";
    let analysis = "";
    const runLog = [];
    try {
      for (const n of nodes) {
        const start = Date.now();
        let status = "success", error_message = "";
        if (n.type === "FetchDocs") {
          const filter = (config[n.id]?.filter || "").toLowerCase().trim();
          const limit = Math.max(1, Number(config[n.id]?.limit || 3));
          const filtered = docs.filter(d => {
            if (!filter) return true;
            const inTags = Array.isArray(d.tags) && d.tags.join(" ").toLowerCase().includes(filter);
            return d.title.toLowerCase().includes(filter) || (d.summary || "").toLowerCase().includes(filter) || inTags;
          }).slice(0, limit);
          const contents = [];
          for (const d of filtered) {
            try {
              const t = await fetch(d.file_url).then(r => r.text());
              contents.push(`Title: ${d.title}\n---\n${t.slice(0, 4000)}`);
            } catch (e) {
              contents.push(`Title: ${d.title}\n---\n[Preview unavailable]`);
            }
          }
          contextText = contents.join("\n\n-----\n\n");
          runLog.push(`Fetched ${filtered.length} docs`);
        } else if (n.type === "AnalyzeLLM") {
          const prompt = config[n.id]?.prompt || "Summarize the context.";
          const fullPrompt = `Context:\n${contextText}\n\nTask:\n${prompt}`;
          try {
            const out = await InvokeLLM({ prompt: fullPrompt, add_context_from_internet: false });
            analysis = typeof out === "string" ? out : JSON.stringify(out, null, 2);
            runLog.push("LLM analysis complete");
          } catch (e) {
            status = "error"; error_message = String(e?.message || e);
            runLog.push(`LLM error: ${error_message}`);
          }
          const end = Date.now();
          await ToolRunLog.create({
            tool_name: "InvokeLLM", run_context: "WorkflowBuilder", status, latency_ms: end - start,
            error_message, metadata: { node_id: n.id }, started_at: new Date(start).toISOString(),
            finished_at: new Date(end).toISOString(), user_id: me?.id
          });
          if (status === "error") throw new Error(error_message);
        } else if (n.type === "SendEmail") {
          const to = config[n.id]?.to || "";
          const subject = config[n.id]?.subject || "Workflow Result";
          const body = `${config[n.id]?.prefix || ""}\n\n${analysis || contextText}`;
          let status2 = "success", error_message2 = "";
          try {
            await SendEmail({ to, subject, body, from_name: "Orbital Command Center" });
            runLog.push(`Email sent to ${to}`);
          } catch (e) {
            status2 = "error"; error_message2 = String(e?.message || e);
            runLog.push(`Email error: ${error_message2}`);
          }
          const end = Date.now();
          await ToolRunLog.create({
            tool_name: "SendEmail", run_context: "WorkflowBuilder", status: status2, latency_ms: end - start,
            error_message: error_message2, metadata: { node_id: n.id, to }, started_at: new Date(start).toISOString(),
            finished_at: new Date(end).toISOString(), user_id: me?.id
          });
          if (status2 === "error") throw new Error(error_message2);
        }
      }
      setRunOutput(runLog.join("\n"));
    } catch (e) {
      setRunOutput(prev => `${prev}\nFAILED: ${String(e?.message || e)}`);
    } finally {
      setRunning(false);
    }
  };

  const selectedNodeConfig = (n) => {
    const c = config[n.id] || {};
    if (n.type === "FetchDocs") {
      return (
        <div className="space-y-2">
          <Input placeholder="Filter (tag/text)" value={c.filter || ""} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, filter: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
          <Input type="number" min={1} max={10} placeholder="Limit" value={c.limit || 3} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, limit: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
        </div>
      );
    }
    if (n.type === "AnalyzeLLM") {
      return (
        <Textarea placeholder="Instruction for LLM" value={c.prompt || ""} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, prompt: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
      );
    }
    if (n.type === "SendEmail") {
      return (
        <div className="space-y-2">
          <Input placeholder="To (email)" value={c.to || ""} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, to: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
          <Input placeholder="Subject" value={c.subject || ""} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, subject: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
          <Textarea placeholder="Body prefix (optional)" value={c.prefix || ""} onChange={(e) => setConfig({ ...config, [n.id]: { ...c, prefix: e.target.value } })} className="bg-gray-800/50 border-gray-700" />
        </div>
      );
    }
    return null;
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center"><GitBranch className="w-10 h-10 mr-3 text-cyan-400" />Workflow Builder</h1>
        <p className="orbital-text-subtitle">Drag-and-drop: Fetch → Analyze → Alert.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">Workflows</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <Button onClick={() => { setSelected(null); setNodes([]); setMeta({ name: "", description: "" }); setConfig({}); }} className="w-full bg-cyan-600 hover:bg-cyan-700"><Plus className="w-4 h-4 mr-2" />New</Button>
            <div className="max-h-[50vh] overflow-auto space-y-2">
              {workflows.map(w => (
                <button key={w.id} onClick={() => setSelected(w)} className={`w-full text-left p-2 rounded border ${selected?.id === w.id ? "border-cyan-500/50 bg-cyan-500/10" : "border-gray-800 hover:border-gray-700"}`}>
                  <div className="text-white">{w.name}</div>
                  <div className="text-xs text-gray-500">{w.description}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Canvas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-3">
              <Input placeholder="Workflow name" value={meta.name} onChange={(e) => setMeta({ ...meta, name: e.target.value })} className="bg-gray-800/50 border-gray-700 col-span-2 md:col-span-1" />
              <Input placeholder="Description" value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} className="bg-gray-800/50 border-gray-700 col-span-2" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Droppable droppableId="palette" isDropDisabled>
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps} className="p-3 border border-gray-800 rounded">
                    <div className="text-gray-400 text-sm mb-2">Palette</div>
                    {PALETTE.map((p, idx) => (
                      <Draggable draggableId={p.id} index={idx} key={p.id}>
                        {(drag) => (
                          <div ref={drag.innerRef} {...drag.draggableProps} {...drag.dragHandleProps} className="p-2 bg-gray-800/40 border border-gray-700 rounded mb-2 text-white">{p.label}</div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>

              <Droppable droppableId="canvas">
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps} className="md:col-span-2 p-3 border border-gray-800 rounded min-h-[220px]">
                    <div className="text-gray-400 text-sm mb-2">Drag steps here</div>
                    {nodes.map((n, idx) => (
                      <Draggable draggableId={n.id} index={idx} key={n.id}>
                        {(drag) => (
                          <div ref={drag.innerRef} {...drag.draggableProps} {...drag.dragHandleProps} className="p-3 bg-gray-800/40 border border-gray-700 rounded mb-2">
                            <div className="flex items-center justify-between">
                              <div className="text-white font-medium">{n.type}</div>
                              <button onClick={() => removeNode(n.id)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></button>
                            </div>
                            <div className="mt-2">{selectedNodeConfig(n)}</div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>

            <div className="mt-4 flex gap-2">
              <Button onClick={save} className="bg-cyan-600 hover:bg-cyan-700">Save</Button>
              <Button onClick={run} disabled={running || nodes.length === 0} className="bg-purple-600 hover:bg-purple-700"><Play className="w-4 h-4 mr-2" />Run</Button>
            </div>

            <pre className="mt-4 bg-black/30 border border-gray-800 text-gray-200 p-3 rounded max-h-[30vh] overflow-auto whitespace-pre-wrap">{runOutput || "Run logs will appear here."}</pre>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1 bg-[#0A0D18]/50 border-gray-800">
          <CardHeader><CardTitle className="text-white">How it works</CardTitle></CardHeader>
          <CardContent className="text-gray-300 text-sm space-y-2">
            <p>1) FetchDocs pulls Knowledge Vault docs by filter and builds a context.</p>
            <p>2) AnalyzeLLM runs InvokeLLM on that context with your instruction.</p>
            <p>3) SendEmail emails the analysis to your chosen recipient.</p>
          </CardContent>
        </Card>
      </div>

      <DragDropContext onDragEnd={onDragEnd} />
    </div>
  );
}