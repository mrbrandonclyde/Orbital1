import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Globe, Building2, BarChart3 } from "lucide-react";

export default function CivilizationPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Globe className="w-10 h-10 mr-3 text-blue-400" />
          Civilization
        </h1>
        <p className="orbital-text-subtitle">Governance, Economy, Culture, Infrastructure.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Link to={createPageUrl('GlobalGovernance')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            <h3 className="text-white font-semibold">Governance</h3>
          </div>
          <p className="text-gray-400 text-sm">International coordination & stability.</p>
        </Link>

        <Link to={createPageUrl('Financials')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Economy</h3>
          </div>
          <p className="text-gray-400 text-sm">Macro indicators and insights.</p>
        </Link>

        <Link to={createPageUrl('UrbanPlanner')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Building2 className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Infrastructure</h3>
          </div>
          <p className="text-gray-400 text-sm">Cities, assets, and sustainability.</p>
        </Link>

        <Link to={createPageUrl('KnowledgeVault')} className="glass-pane p-6 hover:border-blue-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white font-semibold">Culture</h3>
          </div>
          <p className="text-gray-400 text-sm">Frameworks, research, and strategy.</p>
        </Link>
      </div>
    </div>
  );
}