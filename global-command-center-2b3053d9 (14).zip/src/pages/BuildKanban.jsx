
import React from "react";
import { BuildTask } from "@/api/entities";
import { User } from "@/api/entities";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LayoutDashboard, Plus, Filter, Search } from "lucide-react";
import { InvokeLLM, UploadFile } from "@/api/integrations"; // Added UploadFile
import { ToolRunLog } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"; // Added Dialog components
import { Textarea } from "@/components/ui/textarea"; // Added Textarea
import { Switch } from "@/components/ui/switch"; // Added Switch
import { Label } from "@/components/ui/label"; // Added Label

const STATUSES = [
  { key: "backlog", label: "Backlog" },
  { key: "planned", label: "Planned" },
  { key: "in_progress", label: "In Progress" },
  { key: "review", label: "Review" },
  { key: "done", label: "Done" }
];

const AREAS = [
  "Platform","Server","Backend","Data","Frontend","AI","Automation","Security","Observability","DX","Product","ImportExport","Governance"
];

function ColumnCard({ task, index, onEdit }) {
  const color = {
    P0: "bg-red-500/20 text-red-300",
    P1: "bg-yellow-500/20 text-yellow-300",
    P2: "bg-blue-500/20 text-blue-300",
  }[task.priority || "P1"];

  return (
    <Draggable draggableId={String(task.id)} index={index}>
      {(provided) => (
        <div
          className="mb-3"
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          <div className="rounded-lg border border-gray-700 bg-[#0A0D18]/60 p-3 hover:border-cyan-500/30">
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm text-white font-semibold">{task.title}</h4>
              <Badge className={`${color} border-none`}>{task.priority}</Badge>
            </div>
            {task.description && (
              <p className="text-xs text-gray-400 line-clamp-3">{task.description}</p>
            )}
            <div className="mt-2 flex items-center gap-2">
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">{task.area}</Badge>
              {task.owner_email && (
                <span className="text-[10px] text-gray-500 truncate">{task.owner_email}</span>
              )}
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
}

function KanbanColumn({ status, tasks, onEdit }) {
  return (
    <Card className="bg-[#0A0D18]/40 border-gray-800 h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center justify-between">
          <span>{status.label}</span>
          <Badge className="bg-gray-700/50 text-gray-300">{tasks.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <Droppable droppableId={status.key} type="TASK">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`min-h-[200px] rounded-md p-1 transition ${
                snapshot.isDraggingOver ? "bg-cyan-500/10" : ""
              }`}
            >
              {tasks.map((task, idx) => (
                <ColumnCard key={task.id} task={task} index={idx} onEdit={onEdit} />
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </CardContent>
    </Card>
  );
}

export default function BuildKanbanPage() {
  const [tasks, setTasks] = React.useState([]);
  const [me, setMe] = React.useState(null);
  const [areaFilter, setAreaFilter] = React.useState("All");
  const [query, setQuery] = React.useState("");
  const [aiProcessing, setAiProcessing] = React.useState({}); // { [taskId]: true }

  const [showCreate, setShowCreate] = React.useState(false);
  const [newTask, setNewTask] = React.useState({
    title: "",
    subject: "",
    description: "",
    area: "Platform",
    priority: "P2",
    addToTop: true,
    attachments: []
  });

  const load = React.useCallback(async () => {
    const data = await BuildTask.list();
    data.sort((a, b) => {
      if (a.status !== b.status) return 0;
      const ai = a.order_index ?? 0;
      const bi = b.order_index ?? 0;
      return ai - bi;
    });
    setTasks(data);
    try { setMe(await User.me()); } catch {}
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const filtered = React.useMemo(() => {
    return tasks.filter(t => {
      const areaOk = areaFilter === "All" || t.area === areaFilter;
      const q = query.trim().toLowerCase();
      const qOk = !q || `${t.title} ${t.description || ""}`.toLowerCase().includes(q);
      return areaOk && qOk;
    });
  }, [tasks, areaFilter, query]);

  const byStatus = React.useMemo(() => {
    const map = {};
    STATUSES.forEach(s => { map[s.key] = []; });
    filtered.forEach(t => map[t.status || "backlog"].push(t));
    Object.keys(map).forEach(k => map[k].sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0)));
    return map;
  }, [filtered]);

  const markAi = (id, on) => setAiProcessing(prev => ({ ...prev, [id]: !!on }));

  const runAIForTask = async (task, trigger = "drag_drop") => {
    const start = Date.now();
    markAi(task.id, true);
    const schema = {
      type: "object",
      properties: {
        recommended_next_status: { type: "string", enum: ["backlog","planned","in_progress","review","done"] },
        auto_complete: { type: "boolean" },
        priority: { type: "string", enum: ["P0","P1","P2"] },
        owner_email: { type: "string" },
        reasoning: { type: "string" }
      },
      required: ["recommended_next_status"]
    };

    let status = "success";
    let error_message = "";
    let stepsApplied = 0;

    try {
      let current = task.status || "backlog";
      // Limit to 3 AI hops to avoid loops
      for (let i = 0; i < 3; i++) {
        stepsApplied = i + 1;
        const prompt = `
You are an engineering delivery AI. Given this Kanban task, recommend the next status and if it can be auto-completed.
Goal: Move tasks quickly to Done while preserving sensible progression.
Respond with JSON per schema.

Task:
- Title: ${task.title}
- Description: ${task.description || "(none)"}
- Area: ${task.area}
- Current Status: ${current}
- Priority: ${task.priority || "P1"}
- Tags: ${(task.tags || []).join(", ") || "(none)"}

Rules:
- Valid statuses: backlog -> planned -> in_progress -> review -> done.
- If task is sufficiently small or purely procedural, set auto_complete=true and recommend done.
- Optionally adjust priority (P0/P1/P2) and owner_email suggestion.
        `.trim();

        const res = await InvokeLLM({
          prompt,
          response_json_schema: schema,
          add_context_from_internet: false
        });

        const next = res?.recommended_next_status || current;
        const updates = {};
        if (res?.priority && ["P0","P1","P2"].includes(res.priority)) updates.priority = res.priority;
        if (res?.owner_email) updates.owner_email = res.owner_email;

        // If auto-complete or recommended done, finalize
        if (res?.auto_complete || next === "done") {
          await BuildTask.update(task.id, { status: "done", ...updates });
          current = "done";
          break;
        }

        // Progress if next differs
        if (next !== current) {
          await BuildTask.update(task.id, { status: next, ...updates });
          current = next;
          // continue loop to see if we can reach done
        } else {
          // No change recommended; stop
          break;
        }
      }

      await load();
    } catch (e) {
      status = "error";
      error_message = String(e?.message || e);
    } finally {
      const end = Date.now();
      try {
        const meMaybe = me || null;
        await ToolRunLog.create({
          tool_name: "InvokeLLM",
          run_context: "BuildKanban:auto_advance",
          status,
          latency_ms: end - start,
          error_message,
          metadata: {
            task_id: task.id,
            title: task.title,
            area: task.area,
            trigger,
            steps_applied: stepsApplied
          },
          started_at: new Date(start).toISOString(),
          finished_at: new Date(end).toISOString(),
          user_id: meMaybe?.id
        });
      } finally {
        markAi(task.id, false);
      }
    }
  };

  const computeTopOrderIndex = (statusKey) => {
    const col = byStatus[statusKey] || [];
    if (!col.length) return 1000; // first item
    const top = col.slice().sort((a, b) => (a.order_index ?? 1000) - (b.order_index ?? 1000))[0];
    return (top.order_index ?? 1000) - 1;
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const uploaded = [];
    for (const file of files) {
      const { file_url } = await UploadFile({ file });
      uploaded.push({ file_url, file_name: file.name, file_size: file.size });
    }
    setNewTask((prev) => ({ ...prev, attachments: [...prev.attachments, ...uploaded] }));
    e.target.value = ""; // reset
  };

  const removeAttachment = (idx) => {
    setNewTask((prev) => ({ ...prev, attachments: prev.attachments.filter((_, i) => i !== idx) }));
  };

  const createTask = async () => {
    if (!newTask.title.trim()) {
        alert("Task title cannot be empty.");
        return;
    }
    const payload = {
      title: newTask.title.trim(),
      subject: newTask.subject?.trim() || undefined,
      description: newTask.description?.trim() || "",
      area: newTask.area,
      status: "backlog",
      priority: newTask.priority,
      attachments: newTask.attachments,
      order_index: newTask.addToTop ? computeTopOrderIndex("backlog") : ((Date.now() % 100000) / 1000)
    };
    const created = await BuildTask.create(payload);
    setTasks(prev => [created, ...prev]); // Optimistic UI update
    setShowCreate(false);
    setNewTask({ title: "", subject: "", description: "", area: "Platform", priority: "P2", addToTop: true, attachments: [] });
    // Let AI auto-advance after create
    await runAIForTask(created, "create_dialog"); // runAIForTask will call load()
  };

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    const srcStatus = source.droppableId;
    const dstStatus = destination.droppableId;
    if (srcStatus === dstStatus && source.index === destination.index) return;

    const task = tasks.find(t => String(t.id) === String(draggableId));
    if (!task) return;

    // Determine new order_index using neighbors
    const dstList = byStatus[dstStatus];
    const before = dstList[destination.index - 1];
    const after = dstList[destination.index];
    let newOrder;
    if (!before && !after) newOrder = 1000;
    else if (!before && after) newOrder = (after.order_index ?? 1000) - 1;
    else if (before && !after) newOrder = (before.order_index ?? 1000) + 1;
    else newOrder = ((before.order_index ?? 1000) + (after.order_index ?? 1000)) / 2;

    await BuildTask.update(task.id, { status: dstStatus, order_index: newOrder });
    await load();

    // NEW: kick off AI to auto-advance
    // Pass the task with its *new* status after the drag-drop
    runAIForTask({ ...task, status: dstStatus }, "drag_drop");
  };

  return (
    <div className="min-h-screen bg-[#020409]">
      <div className="p-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="w-7 h-7 text-cyan-400" />
            <div>
              <h1 className="text-white text-2xl font-bold">Build Kanban</h1>
              <p className="text-gray-400 text-sm">
                End-to-end checklist across all layers — AI will auto-advance tasks to Done.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 text-gray-500 absolute left-2 top-2.5" />
              <Input
                className="pl-8 w-56 bg-[#0A0D18] border-gray-700 text-gray-200"
                placeholder="Search tasks..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <Select value={areaFilter} onValueChange={setAreaFilter}>
              <SelectTrigger className="w-44 bg-[#0A0D18] border-gray-700 text-gray-200">
                <SelectValue placeholder="Area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All"><div className="flex items-center gap-2"><Filter className="w-4 h-4" />All Areas</div></SelectItem>
                {AREAS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={() => setShowCreate(true)} className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-4 h-4 mr-1" /> Add Task
            </Button>
          </div>
        </div>

        {/* AI processing indicator */}
        {Object.values(aiProcessing).some(Boolean) && (
          <div className="mb-3 text-xs text-cyan-300 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
            AI is auto-advancing tasks...
          </div>
        )}

        {/* Create Task Dialog */}
        <Dialog open={showCreate} onOpenChange={setShowCreate}>
          <DialogContent className="sm:max-w-2xl bg-[#0A0D18] border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white">Create Task</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Task title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100"
              />
              <Input
                placeholder="Subject (short summary)"
                value={newTask.subject}
                onChange={(e) => setNewTask({ ...newTask, subject: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100"
              />
              <Textarea
                placeholder="Description"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100 min-h-[100px]"
              />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <Label className="text-gray-400 text-xs">Area</Label>
                  <Select value={newTask.area} onValueChange={(v) => setNewTask({ ...newTask, area: v })}>
                    <SelectTrigger className="bg-[#0C0F19] border-gray-700 text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {AREAS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">Priority</Label>
                  <Select value={newTask.priority} onValueChange={(v) => setNewTask({ ...newTask, priority: v })}>
                    <SelectTrigger className="bg-[#0C0F19] border-gray-700 text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="P0">P0 (Critical)</SelectItem>
                      <SelectItem value="P1">P1 (High)</SelectItem>
                      <SelectItem value="P2">P2 (Normal)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between mt-6 md:mt-0 px-2 rounded-lg bg-[#0C0F19] border border-gray-700">
                  <Label htmlFor="addToTop" className="text-gray-300">Add to top</Label>
                  <Switch id="addToTop" checked={newTask.addToTop} onCheckedChange={(v) => setNewTask({ ...newTask, addToTop: v })} />
                </div>
              </div>

              <div>
                <Label className="text-gray-400 text-xs">Attachments</Label>
                <div className="mt-2 flex items-center gap-3">
                  <input type="file" multiple onChange={handleFileSelect} className="text-gray-300" />
                </div>
                {newTask.attachments.length > 0 && (
                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {newTask.attachments.map((att, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2">
                        <div className="truncate">
                          <p className="text-sm text-gray-100 truncate">{att.file_name}</p>
                          <a href={att.file_url} target="_blank" rel="noreferrer" className="text-xs text-cyan-400 hover:underline">Open</a>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => removeAttachment(idx)} className="text-gray-400 hover:text-white">Remove</Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button onClick={createTask} className="bg-indigo-600 hover:bg-indigo-700">Create Task</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <DragDropContext onDragEnd={onDragEnd}>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">
            {STATUSES.map((s) => (
              <KanbanColumn key={s.key} status={s} tasks={byStatus[s.key]} />
            ))}
          </div>
        </DragDropContext>
      </div>
    </div>
  );
}
