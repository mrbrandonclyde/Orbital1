import React, { useState } from 'react';
import { Shield, AlertTriangle, Eye, Lock, Users, Activity } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const securityMetrics = [
  { title: "Security Level", value: "MAXIMUM", icon: Shield, color: "text-green-400" },
  { title: "Active Threats", value: "23", icon: AlertTriangle, color: "text-red-400" },
  { title: "Monitoring Systems", value: "847", icon: Eye, color: "text-cyan-400" },
  { title: "Authenticated Users", value: "1,247", icon: Users, color: "text-blue-400" },
  { title: "Encryption Status", value: "256-bit", icon: Lock, color: "text-purple-400" },
  { title: "System Uptime", value: "99.97%", icon: Activity, color: "text-green-400" }
];

const threatLevels = [
  { time: '00:00', cyber: 15, physical: 8, insider: 3 },
  { time: '04:00', cyber: 18, physical: 6, insider: 2 },
  { time: '08:00', cyber: 22, physical: 12, insider: 5 },
  { time: '12:00', cyber: 25, physical: 15, insider: 4 },
  { time: '16:00', cyber: 28, physical: 18, insider: 7 },
  { time: '20:00', cyber: 23, physical: 10, insider: 3 }
];

const securityIncidents = [
  { type: 'Unauthorized Access', count: 12, severity: 'HIGH', status: 'CONTAINED' },
  { type: 'Data Breach Attempt', count: 5, severity: 'CRITICAL', status: 'BLOCKED' },
  { type: 'Suspicious Activity', count: 34, severity: 'MEDIUM', status: 'MONITORING' },
  { type: 'Failed Authentication', count: 89, severity: 'LOW', status: 'LOGGED' },
  { type: 'System Intrusion', count: 3, severity: 'CRITICAL', status: 'RESOLVED' }
];

const activeAlerts = [
  {
    id: 'SEC-001',
    title: 'Anomalous Network Traffic',
    severity: 'HIGH',
    source: '192.168.1.45',
    detected: '2 minutes ago',
    status: 'INVESTIGATING'
  },
  {
    id: 'SEC-002',
    title: 'Failed Login Attempts',
    severity: 'MEDIUM',
    source: 'Multiple IPs',
    detected: '15 minutes ago',
    status: 'BLOCKED'
  },
  {
    id: 'SEC-003',
    title: 'Unusual File Access Pattern',
    severity: 'HIGH',
    source: 'Internal User',
    detected: '1 hour ago',
    status: 'ESCALATED'
  },
  {
    id: 'SEC-004',
    title: 'Port Scanning Detected',
    severity: 'MEDIUM',
    source: '203.45.67.89',
    detected: '3 hours ago',
    status: 'CONTAINED'
  }
];

const getSeverityBadge = (severity) => {
  switch (severity) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    case 'LOW': return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'CONTAINED':
    case 'BLOCKED':
    case 'RESOLVED': return <Badge className="bg-green-500/20 text-green-400">{status}</Badge>;
    case 'INVESTIGATING':
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400 animate-pulse">{status}</Badge>;
    case 'ESCALATED': return <Badge className="bg-red-500/20 text-red-400">{status}</Badge>;
    case 'LOGGED': return <Badge className="bg-blue-500/20 text-blue-400">{status}</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">{status}</Badge>;
  }
};

export default function SecurityCenterPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Shield className="w-10 h-10 mr-3 text-green-400" />
            Security Command Center
          </h1>
          <p className="orbital-text-subtitle">Real-time threat monitoring, incident response, and security protocol management.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {securityMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Threat Activity Timeline</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={threatLevels}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Line type="monotone" dataKey="cyber" name="Cyber Threats" stroke="#EF4444" strokeWidth={3} />
                <Line type="monotone" dataKey="physical" name="Physical Threats" stroke="#F59E0B" strokeWidth={3} />
                <Line type="monotone" dataKey="insider" name="Insider Threats" stroke="#8B5CF6" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Security Incidents by Type</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={securityIncidents} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis type="number" stroke="#9CA3AF" />
                <YAxis dataKey="type" type="category" stroke="#9CA3AF" width={120} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Bar dataKey="count" fill="#06B6D4" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Active Security Alerts</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Alert ID</TableHead>
              <TableHead className="text-gray-400">Title</TableHead>
              <TableHead className="text-gray-400">Severity</TableHead>
              <TableHead className="text-gray-400">Source</TableHead>
              <TableHead className="text-gray-400">Detected</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activeAlerts.map((alert) => (
              <TableRow key={alert.id} className="border-gray-800 hover:bg-gray-800/30">
                <TableCell className="font-mono text-cyan-400">{alert.id}</TableCell>
                <TableCell className="font-medium text-white">{alert.title}</TableCell>
                <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                <TableCell className="text-gray-300 font-mono">{alert.source}</TableCell>
                <TableCell className="text-gray-400">{alert.detected}</TableCell>
                <TableCell>{getStatusBadge(alert.status)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}