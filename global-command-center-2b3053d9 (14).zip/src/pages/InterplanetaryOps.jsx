import React, { useState } from 'react';
import { Rocket, Globe, Satellite, Users, MapPin, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";

const spaceMetrics = [
  { title: "Active Colonies", value: "12", icon: MapPin, color: "text-blue-400" },
  { title: "Personnel Off-World", value: "1,247", icon: Users, color: "text-green-400" },
  { title: "Orbital Platforms", value: "47", icon: Satellite, color: "text-purple-400" },
  { title: "Mission Success Rate", value: "98.7%", icon: Rocket, color: "text-cyan-400" },
  { title: "Resource Efficiency", value: "94.2%", icon: Zap, color: "text-yellow-400" },
  { title: "Coverage Area", value: "Sol System", icon: Globe, color: "text-orange-400" }
];

const colonies = [
  {
    id: 'LUNA-01',
    name: 'Luna Prime Research Station',
    location: 'Moon - Mare Tranquillitatis',
    status: 'OPERATIONAL',
    population: 487,
    established: '2024-03-15',
    purpose: 'Scientific Research & Mining'
  },
  {
    id: 'MARS-01', 
    name: 'New Genesis Colony',
    location: 'Mars - Chryse Planitia',
    status: 'EXPANDING',
    population: 234,
    established: '2024-07-22',
    purpose: 'Agricultural Development'
  },
  {
    id: 'ORB-03',
    name: 'Titan Industrial Complex',
    location: 'Saturn Orbit - L4',
    status: 'CONSTRUCTION',
    population: 156,
    established: '2024-09-01',
    purpose: 'Heavy Manufacturing'
  },
  {
    id: 'EUROPA-01',
    name: 'Deep Ocean Research Lab',
    location: 'Europa Sub-Surface',
    status: 'OPERATIONAL',
    population: 78,
    established: '2024-11-12',
    purpose: 'Xenobiology Research'
  }
];

const missions = [
  { id: 'MISSION-ALPHA', name: 'Asteroid Mining Expansion', target: 'Ceres', status: 'ACTIVE', eta: '47d', crew: 12 },
  { id: 'MISSION-BETA', name: 'Mars Terraform Preparation', target: 'Mars', status: 'PLANNING', eta: '156d', crew: 8 },
  { id: 'MISSION-GAMMA', name: 'Europa Deep Drill', target: 'Europa', status: 'ACTIVE', eta: '23d', crew: 6 },
  { id: 'MISSION-DELTA', name: 'Jupiter System Survey', target: 'Jupiter Moons', status: 'COMPLETED', eta: 'Complete', crew: 15 }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'OPERATIONAL': return <Badge className="bg-green-500/20 text-green-400">OPERATIONAL</Badge>;
    case 'EXPANDING': return <Badge className="bg-blue-500/20 text-blue-400 animate-pulse">EXPANDING</Badge>;
    case 'CONSTRUCTION': return <Badge className="bg-yellow-500/20 text-yellow-400">CONSTRUCTION</Badge>;
    case 'ACTIVE': return <Badge className="bg-cyan-500/20 text-cyan-400">ACTIVE</Badge>;
    case 'PLANNING': return <Badge className="bg-purple-500/20 text-purple-400">PLANNING</Badge>;
    case 'COMPLETED': return <Badge className="bg-green-500/20 text-green-400">COMPLETED</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const SolarSystemMap = () => (
  <div className="relative w-full h-96 bg-gradient-to-b from-gray-900 to-black rounded-lg overflow-hidden">
    {/* Central Sun */}
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
      <div className="w-8 h-8 bg-yellow-400 rounded-full animate-pulse shadow-lg shadow-yellow-400/50"></div>
    </div>
    
    {/* Orbital paths */}
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
      <div className="w-24 h-24 border border-gray-600 rounded-full opacity-30"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 border border-gray-600 rounded-full opacity-30"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-56 h-56 border border-gray-600 rounded-full opacity-30"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 border border-gray-600 rounded-full opacity-30"></div>
    </div>
    
    {/* Planets with colonies */}
    <div className="absolute top-1/2 left-[60%] transform -translate-x-1/2 -translate-y-1/2">
      <div className="w-4 h-4 bg-blue-400 rounded-full relative">
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-blue-400 whitespace-nowrap">Earth</div>
        <div className="absolute w-2 h-2 bg-gray-300 rounded-full -top-1 -right-2 animate-pulse">
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-xs text-green-400">Luna</div>
        </div>
      </div>
    </div>
    
    <div className="absolute top-[30%] left-[75%] transform -translate-x-1/2 -translate-y-1/2">
      <div className="w-3 h-3 bg-red-400 rounded-full relative animate-pulse">
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-red-400">Mars</div>
      </div>
    </div>
    
    <div className="absolute top-[70%] left-[15%] transform -translate-x-1/2 -translate-y-1/2">
      <div className="w-6 h-6 bg-orange-400 rounded-full relative">
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-orange-400">Jupiter</div>
        <div className="absolute w-1 h-1 bg-cyan-300 rounded-full -bottom-2 left-2 animate-pulse">
          <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 text-xs text-cyan-300">Europa</div>
        </div>
      </div>
    </div>
  </div>
);

export default function InterplanetaryOpsPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Rocket className="w-10 h-10 mr-3 text-blue-400" />
            Interplanetary Operations
          </h1>
          <p className="orbital-text-subtitle">Command and control for off-world colonies, missions, and space infrastructure.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {spaceMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Solar System Overview</h3>
          <SolarSystemMap />
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Active Missions</h3>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-gray-400">Mission</TableHead>
                <TableHead className="text-gray-400">Target</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">ETA</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {missions.map((mission) => (
                <TableRow key={mission.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="font-medium text-white">{mission.name}</TableCell>
                  <TableCell className="text-gray-300">{mission.target}</TableCell>
                  <TableCell>{getStatusBadge(mission.status)}</TableCell>
                  <TableCell className="text-cyan-400">{mission.eta}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Off-World Colonies</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Colony</TableHead>
              <TableHead className="text-gray-400">Location</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Population</TableHead>
              <TableHead className="text-gray-400">Purpose</TableHead>
              <TableHead className="text-gray-400">Established</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {colonies.map((colony) => (
              <TableRow key={colony.id} className="border-gray-800 hover:bg-gray-800/30">
                <TableCell>
                  <div>
                    <p className="font-medium text-white">{colony.name}</p>
                    <p className="text-xs text-gray-400 font-mono">{colony.id}</p>
                  </div>
                </TableCell>
                <TableCell className="text-gray-300">{colony.location}</TableCell>
                <TableCell>{getStatusBadge(colony.status)}</TableCell>
                <TableCell className="text-cyan-400">{colony.population.toLocaleString()}</TableCell>
                <TableCell className="text-gray-300">{colony.purpose}</TableCell>
                <TableCell className="text-gray-400">{new Date(colony.established).toLocaleDateString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}