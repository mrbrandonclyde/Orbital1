import React from "react";
import { SystemConfig } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RefreshCw, Save } from "lucide-react";

const CONFIG_KEY = "FUNNEL_GLOBAL_SETTINGS";

export default function FunnelSettings() {
  const [me, setMe] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [form, setForm] = React.useState({
    default_domain: "",
    gdpr_enabled: true,
    pci_enabled: false,
    hipaa_enabled: false,
    default_head_html: "",
    default_footer_html: "",
  });

  const load = React.useCallback(async () => {
    setLoading(true);
    try { setMe(await User.me()); } catch {}
    const rows = await SystemConfig.filter({ config_key: CONFIG_KEY }, "-updated_date", 1);
    const cfg = rows?.[0];
    if (cfg) {
      setConfigId(cfg.id);
      const v = cfg.config_value || {};
      setForm({
        default_domain: v.default_domain || "",
        gdpr_enabled: !!v.gdpr_enabled,
        pci_enabled: !!v.pci_enabled,
        hipaa_enabled: !!v.hipaa_enabled,
        default_head_html: v.default_head_html || "",
        default_footer_html: v.default_footer_html || "",
      });
    } else {
      setConfigId(null);
      setForm((prev) => ({ ...prev }));
    }
    setLoading(false);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    const payload = {
      config_key: CONFIG_KEY,
      config_value: { ...form },
      description: "Global defaults for Funnel Builder (domains, compliance, pixels)",
      security_classification: "CONFIDENTIAL",
      is_editable: true
    };
    if (configId) {
      await SystemConfig.update(configId, payload);
    } else {
      const created = await SystemConfig.create(payload);
      setConfigId(created.id);
    }
    setSaving(false);
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title">Funnel Settings</h1>
          <p className="orbital-text-subtitle">Configure global defaults for domains, compliance and tracking.</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-gray-700/50 text-gray-300">{me?.account_id ? "Tenant Scoped" : "Global"}</Badge>
          <Button variant="secondary" onClick={load} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base">Domains & SEO</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-400 text-xs">Default Domain</Label>
              <Input
                placeholder="e.g. pages.yourbrand.com"
                value={form.default_domain}
                onChange={(e) => setForm({ ...form, default_domain: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100"
              />
              <p className="text-xs text-gray-500 mt-1">Used as a fallback when a funnel doesn't specify a custom domain.</p>
            </div>
            <div>
              <Label className="text-gray-400 text-xs">Global Head HTML (pixels, meta)</Label>
              <Textarea
                rows={5}
                placeholder="<!-- Global pixels or meta tags here -->"
                value={form.default_head_html}
                onChange={(e) => setForm({ ...form, default_head_html: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100"
              />
            </div>
            <div>
              <Label className="text-gray-400 text-xs">Global Footer HTML (scripts)</Label>
              <Textarea
                rows={5}
                placeholder="<!-- Global scripts here -->"
                value={form.default_footer_html}
                onChange={(e) => setForm({ ...form, default_footer_html: e.target.value })}
                className="bg-[#0C0F19] border-gray-700 text-gray-100"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base">Compliance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-gray-800 p-3">
              <div>
                <div className="text-sm text-white">GDPR</div>
                <div className="text-xs text-gray-500">Enable consent banners and data export/delete endpoints.</div>
              </div>
              <Switch checked={form.gdpr_enabled} onCheckedChange={(v) => setForm({ ...form, gdpr_enabled: v })} />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-gray-800 p-3">
              <div>
                <div className="text-sm text-white">PCI</div>
                <div className="text-xs text-gray-500">Strict payment flows and card data handling policies.</div>
              </div>
              <Switch checked={form.pci_enabled} onCheckedChange={(v) => setForm({ ...form, pci_enabled: v })} />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-gray-800 p-3">
              <div>
                <div className="text-sm text-white">HIPAA</div>
                <div className="text-xs text-gray-500">Healthcare data safeguards and access restrictions.</div>
              </div>
              <Switch checked={form.hipaa_enabled} onCheckedChange={(v) => setForm({ ...form, hipaa_enabled: v })} />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex items-center justify-end gap-2">
        <Button onClick={save} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">
          <Save className="w-4 h-4 mr-2" /> {saving ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
}