
import React, { useState, useCallback } from 'react';
import { AuditTrail } from "@/api/entities";
import { User } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Search, FileText, Download, RefreshCw } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AuditEntry from '../components/audit/AuditEntry';
import EmptyState from '../components/common/EmptyState';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function AuditTrailPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [entityFilter, setEntityFilter] = useState('all');
  const [userFilter, setUserFilter] = useState('all');
  const [dateRange, setDateRange] = useState('7'); // days

  const { data, loading, error, refetch } = useQuery(['auditTrail', dateRange], async () => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(dateRange));

    const [auditLogs, users] = await Promise.all([
      AuditTrail.filter(
        { action_timestamp: { $gte: startDate.toISOString() } },
        '-action_timestamp',
        500
      ),
      User.list()
    ]);

    return { auditLogs, users };
  });

  const filteredLogs = (data?.auditLogs || []).filter(log => {
    const matchesSearch = !searchTerm || 
      log.entity_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.entity_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    const matchesEntity = entityFilter === 'all' || log.entity_type === entityFilter;
    const matchesUser = userFilter === 'all' || log.user_id === userFilter;
    
    return matchesSearch && matchesAction && matchesEntity && matchesUser;
  });

  const actions = [...new Set((data?.auditLogs || []).map(log => log.action).filter(Boolean))];
  const entityTypes = [...new Set((data?.auditLogs || []).map(log => log.entity_type).filter(Boolean))];
  const userMap = Object.fromEntries((data?.users || []).map(u => [u.id, u]));

  const exportAuditLogs = () => {
    const csvContent = [
      ['Timestamp', 'Action', 'Entity Type', 'Entity ID', 'User', 'Changes'],
      ...filteredLogs.map(log => [
        new Date(log.action_timestamp).toISOString(),
        log.action,
        log.entity_type,
        log.entity_id,
        userMap[log.user_id]?.full_name || 'Unknown',
        JSON.stringify(log.changes_made || {})
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `audit-trail-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <ErrorBoundary>
      <div className="orbital-page-layout bg-[#020409] p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="orbital-text-title">Audit Trail</h1>
            <p className="orbital-text-subtitle">System activity monitoring and compliance tracking.</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={exportAuditLogs}
              className="orbital-button-secondary flex items-center space-x-2"
              disabled={!filteredLogs.length}
            >
              <Download size={16} />
              <span>Export CSV</span>
            </button>
             <button onClick={refetch} className="orbital-button-secondary">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-[#0A0D18]/30 border border-gray-800 rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <Input
                placeholder="Search logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#0C0F19] border-gray-600"
              />
            </div>

            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue placeholder="All Actions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                {actions.map(action => (
                  <SelectItem key={action} value={action}>{action}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={entityFilter} onValueChange={setEntityFilter}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue placeholder="All Entities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Entities</SelectItem>
                {entityTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={userFilter} onValueChange={setUserFilter}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue placeholder="All Users" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {(data?.users || []).map(user => (
                  <SelectItem key={user.id} value={user.id}>{user.full_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="bg-[#0C0F19] border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Last 24 Hours</SelectItem>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center text-sm text-gray-400">
              <FileText className="w-4 h-4 mr-2" />
              {filteredLogs.length} entries
            </div>
          </div>
        </div>

        {/* Audit Logs */}
        {loading && (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {error && (
          <div className="text-center py-12">
            <p className="text-red-500">Failed to load audit trail.</p>
          </div>
        )}

        {!loading && !error && (
          <div className="space-y-4">
            {filteredLogs.length > 0 ? (
              filteredLogs.map(log => (
                <AuditEntry
                  key={`${log.id}-${log.action_timestamp}`}
                  entry={log}
                  user={userMap[log.user_id]}
                />
              ))
            ) : (
              <EmptyState
                icon={FileText}
                title="No Audit Entries Found"
                subtitle="No system activity matches your current filter criteria."
              />
            )}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}
