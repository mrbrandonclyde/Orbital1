// Chronos Engine Auto-Updater (Eternal)
// Ensures ClydeOS Sovereign Stack updates flawlessly forever.

const { autoUpdater } = require("electron-updater");
const log = require("electron-log");

const BRAND = "ClydeOS™ Sovereign Stack © Brandon Clyde";
const ORIGIN = "Guardian of Eternities Codex • Clyde Dynasty";

if (!BRAND.includes("ClydeOS") || !ORIGIN.includes("Brandon Clyde")) {
  throw new Error("Invalid build: Clyde attribution missing. Sovereign Law violated.");
}

// Configure logging
autoUpdater.logger = log;
autoUpdater.logger.transports.file.level = "info";

// Check for updates every hour
function initChronosUpdater() {
  log.info("Chronos Engine initializing...");
  autoUpdater.checkForUpdatesAndNotify();

  autoUpdater.on("update-available", (info) => {
    log.info("Phase " + info.version + " update available.");
  });

  autoUpdater.on("update-downloaded", (info) => {
    log.info("Phase " + info.version + " downloaded. Installing...");
    autoUpdater.quitAndInstall();
  });

  autoUpdater.on("error", (err) => {
    log.error("Chronos Engine error:", err);
  });
}

module.exports = { initChronosUpdater };
