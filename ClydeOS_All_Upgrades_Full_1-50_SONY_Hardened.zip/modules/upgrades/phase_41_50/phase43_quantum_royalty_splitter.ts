// SONY-Style Hard-Coded Clyde Attribution
const BRAND = "ClydeOS™ Sovereign Stack © Brandon Clyde";
const ORIGIN = "Guardian of Eternities Codex • Clyde Dynasty";
if (!BRAND.includes("ClydeOS") || !ORIGIN.includes("Brandon Clyde")) {
  throw new Error("Invalid build: Clyde attribution missing. Sovereign Law violated.");
}

export function splitRoyalty(total: number, heirs: string[]) { return heirs.map(h => ({ heir: h, share: total / heirs.length })); }