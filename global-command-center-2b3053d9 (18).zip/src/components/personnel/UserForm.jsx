import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { BusinessSector } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MultiSelect } from '@/components/ui/multi-select';
import { logAuditEvent } from '../lib/audit';

const ROLES = ['Analyst', 'Senior Analyst', 'Sector Chief', 'Director', 'Executive', 'Administrator'];
const CLEARANCES = ['CONFIDENTIAL', 'SECRET', 'TOP_SECRET', 'EXECUTIVE_COMMAND'];

// Complete Global Command Center Verticals - ALL PLATFORMS
const ALL_SECTORS = [
  { value: 'TECH', label: 'Technology & Innovation' },
  { value: 'DEF', label: 'Defense & Security' },
  { value: 'FIN', label: 'Finance & Banking' },
  { value: 'ENR', label: 'Energy & Resources' },
  { value: 'HLT', label: 'Healthcare & Life Sciences' },
  { value: 'AGR', label: 'Agriculture & Food' },
  { value: 'TRP', label: 'Transportation & Logistics' },
  { value: 'MFG', label: 'Manufacturing' },
  { value: 'RTL', label: 'Retail & Consumer' },
  { value: 'RE', label: 'Real Estate & Construction' },
  { value: 'EDU', label: 'Education & Research' },
  { value: 'SCM', label: 'International Supply Chains' },
  { value: 'BLOCKCHAIN', label: 'Blockchain & Cryptocurrency' },
  { value: 'ORBITAL_BANK', label: 'Orbital Bank Operations' },
  { value: 'GUARDIAN_CORPS', label: 'Guardian Corps Operations' },
  { value: 'INTERPLANETARY', label: 'Interplanetary Operations' },
  { value: 'BIO_SYMBIOSIS', label: 'Bio-Symbiosis Research' },
  { value: 'GLOBAL_GOV', label: 'Global Governance' },
  { value: 'VR_SYSTEMS', label: 'VR War Room Systems' },
  { value: 'AI_INTELLIGENCE', label: 'AI Intelligence Hub' },
  { value: 'COMMAND_CENTER', label: 'Command Center Operations' },
  { value: 'THREAT_ASSESS', label: 'Threat Assessment' },
  { value: 'ANALYTICS', label: 'Global Analytics' },
  { value: 'COMMUNICATIONS', label: 'Secure Communications' },
  { value: 'PLANETARY_DEF', label: 'Planetary Defense' },
  { value: 'COLONIZATION', label: 'Mars Colonization' },
  { value: 'ASSET_MGT', label: 'Asset Management' },
  { value: 'COMPLIANCE', label: 'Compliance & Audit' },
  { value: 'SECURITY_OPS', label: 'Security Operations' },
  { value: 'DATA_SOURCES', label: 'Data Source Management' },
  { value: 'EXECUTIVE_OPS', label: 'Executive Operations' }
];

export default function UserForm({ user, onSuccess }) {
  const [formData, setFormData] = useState({
    title: '',
    team: '',
    role: 'Analyst',
    security_clearance: 'CONFIDENTIAL',
    assigned_sectors: [],
    department: '',
    subscription_tier: 'BASIC',
    licensed_sectors: [],
    licensed_states: [],
    api_usage_limit: 100,
    vr_access_level: 'NONE',
    report_access_level: 'BASIC',
    notification_preferences: {
      email_enabled: true,
      push_enabled: false,
      transaction_alerts: true,
      security_alerts: true,
      feature_updates: true
    }
  });
  const [sectors, setSectors] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    BusinessSector.list().then(setSectors);
  }, []);

  useEffect(() => {
    if (user) {
      setFormData({
        title: user.title || '',
        team: user.team || '',
        role: user.role || 'Analyst',
        security_clearance: user.security_clearance || 'CONFIDENTIAL',
        assigned_sectors: user.assigned_sectors || [],
        department: user.department || '',
        subscription_tier: user.subscription_tier || 'BASIC',
        licensed_sectors: user.licensed_sectors || [],
        licensed_states: user.licensed_states || [],
        api_usage_limit: user.api_usage_limit || 100,
        vr_access_level: user.vr_access_level || 'NONE',
        report_access_level: user.report_access_level || 'BASIC',
        notification_preferences: {
          email_enabled: user.notification_preferences?.email_enabled ?? true,
          push_enabled: user.notification_preferences?.push_enabled ?? false,
          transaction_alerts: user.notification_preferences?.transaction_alerts ?? true,
          security_alerts: user.notification_preferences?.security_alerts ?? true,
          feature_updates: user.notification_preferences?.feature_updates ?? true
        }
      });
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    try {
      if (user) {
        await User.update(user.id, formData);
        await logAuditEvent('UPDATE', 'User', user.id, formData);
      } else {
        const newUser = await User.create(formData);
        await logAuditEvent('CREATE', 'User', newUser.id, formData);
      }
      onSuccess();
    } catch (error) {
      console.error('Failed to save user:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Official Title</label>
          <Input
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="e.g., Senior Intelligence Analyst"
            className="bg-[#0C0F19] border-gray-600"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Team/Department</label>
          <Input
            value={formData.team}
            onChange={(e) => setFormData({ ...formData, team: e.target.value })}
            placeholder="e.g., Defense Intelligence"
            className="bg-[#0C0F19] border-gray-600"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">System Role</label>
          <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ROLES.map(role => (
                <SelectItem key={role} value={role}>{role}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Security Clearance</label>
          <Select value={formData.security_clearance} onValueChange={(value) => setFormData({ ...formData, security_clearance: value })}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CLEARANCES.map(clearance => (
                <SelectItem key={clearance} value={clearance}>{clearance}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Department</label>
          <Input
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            placeholder="e.g., Global Intelligence Division"
            className="bg-[#0C0F19] border-gray-600"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Subscription Tier</label>
          <Select value={formData.subscription_tier} onValueChange={(value) => setFormData({ ...formData, subscription_tier: value })}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="BASIC">Basic</SelectItem>
              <SelectItem value="PROFESSIONAL">Professional</SelectItem>
              <SelectItem value="ENTERPRISE">Enterprise</SelectItem>
              <SelectItem value="GOVERNMENT">Government</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Assigned Sectors - ALL GLOBAL COMMAND VERTICALS
        </label>
        <MultiSelect
          options={ALL_SECTORS}
          selected={formData.assigned_sectors}
          onChange={(selected) => setFormData({ ...formData, assigned_sectors: selected })}
          placeholder="Select sectors to monitor..."
        />
        <p className="text-xs text-gray-500 mt-1">
          Includes: Blockchain, Orbital Bank, Guardian Corps, VR Systems, AI Intelligence, and all operational verticals
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Licensed Sectors (Premium Access)</label>
        <MultiSelect
          options={ALL_SECTORS}
          selected={formData.licensed_sectors}
          onChange={(selected) => setFormData({ ...formData, licensed_sectors: selected })}
          placeholder="Select licensed sectors..."
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">API Usage Limit</label>
          <Input
            type="number"
            value={formData.api_usage_limit}
            onChange={(e) => setFormData({ ...formData, api_usage_limit: parseInt(e.target.value) })}
            className="bg-[#0C0F19] border-gray-600"
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">VR Access Level</label>
          <Select value={formData.vr_access_level} onValueChange={(value) => setFormData({ ...formData, vr_access_level: value })}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="NONE">None</SelectItem>
              <SelectItem value="OBSERVER">Observer</SelectItem>
              <SelectItem value="FULL_INTERACTIVE">Full Interactive</SelectItem>
              <SelectItem value="MULTI_USER">Multi User</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Report Access Level</label>
          <Select value={formData.report_access_level} onValueChange={(value) => setFormData({ ...formData, report_access_level: value })}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="BASIC">Basic</SelectItem>
              <SelectItem value="PREMIUM">Premium</SelectItem>
              <SelectItem value="UNLIMITED">Unlimited</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-4">Notification Preferences</label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.notification_preferences.email_enabled}
              onChange={(e) => setFormData({ 
                ...formData, 
                notification_preferences: { 
                  ...formData.notification_preferences, 
                  email_enabled: e.target.checked 
                }
              })}
              className="rounded"
            />
            <span className="text-sm text-gray-300">Email Notifications</span>
          </label>

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.notification_preferences.push_enabled}
              onChange={(e) => setFormData({ 
                ...formData, 
                notification_preferences: { 
                  ...formData.notification_preferences, 
                  push_enabled: e.target.checked 
                }
              })}
              className="rounded"
            />
            <span className="text-sm text-gray-300">Push Notifications</span>
          </label>

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.notification_preferences.transaction_alerts}
              onChange={(e) => setFormData({ 
                ...formData, 
                notification_preferences: { 
                  ...formData.notification_preferences, 
                  transaction_alerts: e.target.checked 
                }
              })}
              className="rounded"
            />
            <span className="text-sm text-gray-300">Transaction Alerts</span>
          </label>

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.notification_preferences.security_alerts}
              onChange={(e) => setFormData({ 
                ...formData, 
                notification_preferences: { 
                  ...formData.notification_preferences, 
                  security_alerts: e.target.checked 
                }
              })}
              className="rounded"
            />
            <span className="text-sm text-gray-300">Security Alerts</span>
          </label>

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.notification_preferences.feature_updates}
              onChange={(e) => setFormData({ 
                ...formData, 
                notification_preferences: { 
                  ...formData.notification_preferences, 
                  feature_updates: e.target.checked 
                }
              })}
              className="rounded"
            />
            <span className="text-sm text-gray-300">Feature Updates</span>
          </label>
        </div>
      </div>

      <div className="flex justify-end space-x-4">
        <Button type="submit" disabled={isSubmitting} className="orbital-button-primary">
          {isSubmitting ? 'Saving...' : user ? 'Update Personnel Record' : 'Create Personnel Record'}
        </Button>
      </div>
    </form>
  );
}