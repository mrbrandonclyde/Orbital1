import React, { useState } from 'react';
import { BookOpen, Filter, Users, Globe } from 'lucide-react';
import { motion } from 'framer-motion';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';

const culturalData = [
  { subject: 'Education', preservation: 94, diversity: 88, authenticity: 92 },
  { subject: 'Media', preservation: 89, diversity: 95, authenticity: 87 },
  { subject: 'Arts', preservation: 96, diversity: 91, authenticity: 94 },
  { subject: 'Language', preservation: 91, diversity: 97, authenticity: 89 },
  { subject: 'Religion', preservation: 88, diversity: 93, authenticity: 96 },
  { subject: 'Traditions', preservation: 95, diversity: 86, authenticity: 91 }
];

const knowledgeVaults = [
  { name: "Global Literature Archive", items: "47.3M", status: "Protected" },
  { name: "Indigenous Wisdom Vault", items: "8.7K", status: "Preserved" },
  { name: "Scientific Heritage", items: "125.6M", status: "Curated" },
  { name: "Cultural Artifacts DB", items: "23.1M", status: "Secured" }
];

export default function CulturalFrame() {
  const [activeMetric, setActiveMetric] = useState('preservation');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-8 h-8 text-purple-400" />
            <div>
              <h2 className="orbital-text-heading">Cultural Protocol Frame</h2>
              <p className="orbital-text-caption">Knowledge preservation and authentic cultural diversity curation.</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Civilization Accord: Article 3</p>
            <p className="text-xs text-green-400">Cultural Authenticity Preserved</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Users className="w-5 h-5 mr-2 text-purple-400" />
            Cultural Diversity Matrix
          </h3>
          <div className="mb-4 flex space-x-2">
            {['preservation', 'diversity', 'authenticity'].map(metric => (
              <button
                key={metric}
                onClick={() => setActiveMetric(metric)}
                className={`px-3 py-1 text-xs rounded capitalize ${
                  activeMetric === metric ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                {metric}
              </button>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <RadarChart data={culturalData}>
              <PolarGrid stroke="#374151" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
              <PolarRadiusAxis 
                angle={30} 
                domain={[0, 100]} 
                tick={{ fill: '#9CA3AF', fontSize: 10 }}
              />
              <Radar 
                name={activeMetric} 
                dataKey={activeMetric} 
                stroke="#8B5CF6" 
                fill="#8B5CF6" 
                fillOpacity={0.3} 
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI curates cultural truth, filters algorithmic bias. Human cultural leaders appear naturally wise.
            </p>
          </div>
        </div>

        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Globe className="w-5 h-5 mr-2 text-cyan-400" />
            Knowledge Preservation Vaults
          </h3>
          <div className="space-y-4">
            {knowledgeVaults.map((vault, index) => (
              <motion.div
                key={vault.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-3 bg-gray-800/30 rounded-lg border border-gray-700"
              >
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-white font-medium text-sm">{vault.name}</h4>
                  <span className="text-xs px-2 py-1 rounded bg-green-500/20 text-green-400">{vault.status}</span>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>{vault.items} Items</span>
                  <span>100% Integrity</span>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI preserves human knowledge preventing loss. Cross-cultural dialogue appears organically facilitated.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}