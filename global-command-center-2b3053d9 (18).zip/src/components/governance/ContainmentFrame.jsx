import React from 'react';
import { ShieldAlert, Bug, Globe } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ContainmentFrame() {
  const threats = [
    { 
      type: "Cyber Attack", 
      level: "Contained", 
      region: "EU-WEST-2", 
      details: "DDoS attempt on financial networks neutralized.",
      icon: Bug,
      color: "yellow"
    },
    { 
      type: "Bio-Hazard", 
      level: "Monitoring", 
      region: "SA-EAST-1", 
      details: "Viral anomaly detected, isolation protocols active.",
      icon: ShieldAlert,
      color: "green"
    },
    { 
      type: "Geological Stress", 
      level: "Predicted", 
      region: "US-WEST-1", 
      details: "Seismic event predicted, pre-emptive alerts issued.",
      icon: Globe,
      color: "blue"
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="flex items-center space-x-3 mb-4">
          <ShieldAlert className="w-8 h-8 text-red-400" />
          <div>
            <h2 className="orbital-text-heading">Containment Protocol Frame</h2>
            <p className="orbital-text-caption">Cyber, bio, and geological threat neutralization.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {threats.map((threat, index) => {
          const Icon = threat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.15 }}
              className={`orbital-card p-4 border-l-4 border-${threat.color}-500`}
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-3">
                  <Icon className={`w-6 h-6 text-${threat.color}-400`} />
                  <div>
                    <h3 className="font-semibold text-white">{threat.type}</h3>
                    <p className="text-sm text-gray-400">{threat.details}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-bold text-${threat.color}-400`}>{threat.level}</p>
                  <p className="text-xs text-gray-500">{threat.region}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="orbital-card p-6">
        <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
          <p className="text-xs text-purple-400 font-mono">
            🤖 STEALTH MODE: AI threat suppressor neutralizes cyber attacks in microseconds. Bio and geo models predict and contain disasters before they spread.
          </p>
        </div>
      </div>
    </motion.div>
  );
}