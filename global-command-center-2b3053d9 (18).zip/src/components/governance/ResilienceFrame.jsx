import React, { useState, useEffect } from 'react';
import { DollarSign, Zap, BarChart, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart as RechartsBarChart, Bar } from 'recharts';

const financialData = Array.from({ length: 30 }, (_, i) => ({
  day: `Day ${i + 1}`,
  value: 1000 + Math.random() * 200 + i * 10
}));

const energyData = Array.from({ length: 24 }, (_, i) => ({
  hour: `${i}:00`,
  load: 50 + Math.random() * 20,
  capacity: 80 + Math.random() * 10
}));

export default function ResilienceFrame() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-green-400" />
            <div>
              <h2 className="orbital-text-heading">Resilience Protocol Frame</h2>
              <p className="orbital-text-caption">System-wide economic and infrastructure stability monitoring.</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Guardian Charter: Article 4</p>
            <p className="text-xs text-green-400">All Verticals Stable</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <DollarSign className="w-5 h-5 mr-2 text-green-400" />
            Economic Stability
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={financialData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="day" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Area type="monotone" dataKey="value" stroke="#10B981" fillOpacity={1} fill="url(#colorValue)" />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI predictive balancing prevents market volatility. Fraud prevention protocols active.
            </p>
          </div>
        </div>

        <div className="orbital-card p-6">
          <h3 className="orbital-text-subheading flex items-center mb-4">
            <Zap className="w-5 h-5 mr-2 text-yellow-400" />
            Energy Grid Resilience
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <RechartsBarChart data={energyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
              <Bar dataKey="load" fill="#F59E0B" name="Load" />
              <Bar dataKey="capacity" fill="#4B5563" name="Capacity" />
            </RechartsBarChart>
          </ResponsiveContainer>
          <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
            <p className="text-xs text-purple-400 font-mono">
              🤖 STEALTH MODE: AI actively rerouting power to prevent outages. Grid stabilization at 99.99%.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}