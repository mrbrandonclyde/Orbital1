
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Rocket, Briefcase, Activity, Code2, Palette } from "lucide-react";

const modes = [
  { id: "research", name: "Research", icon: Activity },
  { id: "finance", name: "Finance", icon: Briefcase },
  { id: "design", name: "Design", icon: Palette },
  { id: "coding", name: "Coding", icon: Code2 },
  { id: "healthcare", name: "Healthcare", icon: Activity },
  { id: "defense", name: "Defense", icon: Rocket },
  { id: "education", name: "Education", icon: Activity },
  { id: "energy", name: "Energy", icon: Activity },
  { id: "real_estate", name: "Real Estate", icon: Briefcase },
  { id: "aviation", name: "Aviation", icon: Rocket },
  { id: "media", name: "Media", icon: Palette },
  { id: "robotics", name: "Robotics", icon: Code2 },
];

export default function Missions({ enabled }) {
  const [active, setActive] = React.useState("research");
  if (!enabled) {
    return (
      <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
        <CardHeader><CardTitle className="text-white text-base">Missions</CardTitle></CardHeader>
        <CardContent className="text-gray-400 text-sm">Missions are disabled in Settings.</CardContent>
      </Card>
    );
  }
  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap" role="tablist" aria-label="Mission modes">
        {modes.map(m => {
          const Icon = m.icon;
          const isActive = active === m.id;
          return (
            <Button
              key={m.id}
              role="tab"
              aria-selected={isActive}
              aria-pressed={isActive}
              variant="outline"
              className={`${isActive ? "bg-[#0D1BFF] text-white border-transparent hover:bg-[#0B18DE]" : "border-gray-700 text-gray-200 hover:border-cyan-500/40"}`}
              onClick={() => setActive(m.id)}
            >
              <Icon className="w-4 h-4 mr-2" /> {m.name}
            </Button>
          );
        })}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[1,2,3,4].map(i => (
          <Card key={i} className="bg-[#0A0D18]/60 border-gray-800 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white text-base flex items-center gap-2">
                <Rocket className="w-5 h-5 text-cyan-400" /> Spaceship Command Tile #{i}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-400">
              Immersive, VR-ready mission tile for {modes.find(m=>m.id===active)?.name}. Plug real data in future phases.
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
