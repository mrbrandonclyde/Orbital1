import React from "react";
import ConversationHistory from "./ConversationHistory";
import QuickActions from "./QuickActions";

export default function ChatPage() {
  return (
    <div className="flex flex-col h-full bg-gray-800 text-white">
      {/* 💬 AI Operator Assistant */}
      <div className="flex-1 overflow-y-auto">
        <ConversationHistory />
      </div>
      <QuickActions />
    </div>
  );
}