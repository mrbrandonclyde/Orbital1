import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

export default function ZyraPersonalization() {
  const [style, setStyle] = useState('professional');
  const [verbosity, setVerbosity] = useState([60]);

  const styles = [
    { key: 'professional', title: 'Professional', desc: 'Formal, precise, and concise.' },
    { key: 'casual', title: 'Casual', desc: 'Friendly and conversational.' },
    { key: 'analytical', title: 'Analytical', desc: 'Data-driven and structured.' },
    { key: 'creative', title: 'Creative', desc: 'Exploratory and idea-rich.' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">Personality Configuration</h3>
        <p className="text-gray-400">Customize Zyra’s tone and verbosity to fit your workflow.</p>
      </div>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Communication Style</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {styles.map(s => (
            <Button
              key={s.key}
              variant={style === s.key ? 'default' : 'outline'}
              onClick={() => setStyle(s.key)}
              className={`${style === s.key ? 'bg-purple-500/20 border-purple-500/30 text-white' : 'bg-gray-800/30 border-gray-600 text-gray-200'} text-left h-auto py-3`}
            >
              <div>
                <div className="font-semibold">{s.title}</div>
                <div className="text-xs opacity-80">{s.desc}</div>
              </div>
            </Button>
          ))}
        </CardContent>
      </Card>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle className="text-white">Verbosity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="text-sm text-gray-300">Adjust how detailed Zyra’s answers should be.</div>
            <Slider value={verbosity} onValueChange={setVerbosity} min={10} max={100} step={5} className="w-full" />
            <div className="text-xs text-gray-400">Current: {verbosity[0]}%</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}