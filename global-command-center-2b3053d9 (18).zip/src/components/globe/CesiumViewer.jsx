import React, { useState, useEffect } from 'react';
import { SecurityAlert, BusinessSector } from '@/api/entities';
import { useQuery } from '../lib/useQuery';
import { Globe, Satellite, Activity, AlertTriangle } from 'lucide-react';

export default function CesiumViewer() {
  const [selectedLayer, setSelectedLayer] = useState('alerts');
  const [isRotating, setIsRotating] = useState(true);

  const { data: alertData, loading } = useQuery(async () => {
    const [alerts, sectors] = await Promise.all([
      SecurityAlert.filter({ alert_status: 'ACTIVE' }, '-created_date', 50),
      BusinessSector.list()
    ]);
    return { alerts, sectors };
  });

  if (loading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-black to-blue-900">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-white">Loading Global Intelligence...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-black via-blue-900 to-indigo-900">
      {/* Simulated 3D Globe */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative">
          {/* Main Globe */}
          <div className={`w-80 h-80 rounded-full bg-gradient-to-br from-blue-500 via-green-400 to-blue-600 shadow-2xl ${isRotating ? 'animate-spin' : ''}`} 
               style={{animationDuration: '20s'}}>
            
            {/* Globe Grid Lines */}
            <div className="absolute inset-4 rounded-full border-2 border-white/30"></div>
            <div className="absolute inset-8 rounded-full border border-white/20"></div>
            <div className="absolute inset-12 rounded-full border border-white/10"></div>
            
            {/* Central Globe Icon */}
            <Globe className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 text-white/80" />
          </div>

          {/* Alert Markers Around Globe */}
          {alertData?.alerts?.slice(0, 8).map((alert, index) => {
            const angle = (index / 8) * 360;
            const radius = 200;
            const x = Math.cos(angle * Math.PI / 180) * radius;
            const y = Math.sin(angle * Math.PI / 180) * radius;
            
            const alertColor = alert.priority === 'URGENT' ? 'bg-red-500' : 
                              alert.priority === 'HIGH' ? 'bg-orange-500' : 'bg-yellow-500';
            
            return (
              <div
                key={alert.id}
                className={`absolute w-6 h-6 ${alertColor} rounded-full animate-pulse cursor-pointer`}
                style={{
                  left: `calc(50% + ${x}px)`,
                  top: `calc(50% + ${y}px)`,
                  transform: 'translate(-50%, -50%)',
                  animationDelay: `${index * 0.2}s`
                }}
                title={alert.title}
              >
                <AlertTriangle className="w-4 h-4 text-white m-0.5" />
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Satellite Intelligence Overlay */}
      <div className="absolute top-4 left-4 bg-black/70 text-white p-4 rounded-lg backdrop-blur-sm">
        <h3 className="font-semibold mb-3 flex items-center">
          <Satellite className="w-5 h-5 mr-2" />
          Satellite Intelligence
        </h3>
        <div className="text-sm space-y-2">
          <div>Active Alerts: {alertData?.alerts?.length || 0}</div>
          <div>Monitored Sectors: {alertData?.sectors?.length || 0}</div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span>Real-time Globe</span>
          </div>
        </div>
      </div>

      {/* Layer Controls */}
      <div className="absolute top-4 right-4 bg-black/70 text-white p-4 rounded-lg backdrop-blur-sm">
        <h4 className="font-semibold mb-3">Globe Controls</h4>
        <div className="space-y-3 text-sm">
          <label className="flex items-center space-x-2 cursor-pointer">
            <input 
              type="checkbox" 
              checked={selectedLayer === 'alerts'}
              onChange={(e) => setSelectedLayer(e.target.checked ? 'alerts' : '')}
              className="rounded" 
            />
            <span>Alert Markers</span>
          </label>
          <label className="flex items-center space-x-2 cursor-pointer">
            <input 
              type="checkbox" 
              checked={isRotating}
              onChange={(e) => setIsRotating(e.target.checked)}
              className="rounded" 
            />
            <span>Auto Rotate</span>
          </label>
          <button 
            className="w-full text-left px-2 py-1 bg-blue-600 rounded hover:bg-blue-700 transition-colors"
            onClick={() => setIsRotating(!isRotating)}
          >
            <Activity className="w-4 h-4 inline mr-2" />
            Toggle Rotation
          </button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="absolute bottom-4 left-4 right-4 bg-black/70 text-white p-3 rounded-lg backdrop-blur-sm">
        <div className="flex justify-between items-center text-sm">
          <span>🌍 Global Command Center - Orbital Intelligence View</span>
          <span className="text-green-400 flex items-center">
            <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
            OPERATIONAL
          </span>
        </div>
      </div>
    </div>
  );
}