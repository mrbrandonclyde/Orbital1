import React, { useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

const EARTH_TEXTURE = "https://unpkg.com/three-globe@2.24.14/example/img/earth-blue-marble.jpg";
const EARTH_BUMP = "https://unpkg.com/three-globe@2.24.14/example/img/earth-topology.png";

function latLonToVector3(latDeg, lonDeg, radius) {
  const lat = (latDeg * Math.PI) / 180;
  const lon = (lonDeg * Math.PI) / 180;
  const x = radius * Math.cos(lat) * Math.cos(lon);
  const y = radius * Math.sin(lat);
  const z = radius * Math.cos(lat) * Math.sin(lon);
  return new THREE.Vector3(x, y, z);
}

const OrbitalGlobe = forwardRef(function OrbitalGlobe(
  {
    height = 480,
    autoRotate = true,
    rotationSpeed = 0.0008,
    showGrid = true,
    initialMarkers = [],
  },
  ref
) {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const controlsRef = useRef(null);
  const globeGroupRef = useRef(null);
  const markersGroupRef = useRef(null);
  const overlaysGroupRef = useRef(null);
  const animationIdRef = useRef(null);
  const earthRadius = 2.2;

  // Imperative API
  useImperativeHandle(ref, () => ({
    addMarker: ({ lat, lon, color = 0xff0000, size = 0.035, label }) => {
      if (!markersGroupRef.current) return;
      const geom = new THREE.SphereGeometry(size, 16, 16);
      const mat = new THREE.MeshBasicMaterial({ color });
      const mesh = new THREE.Mesh(geom, mat);
      const pos = latLonToVector3(lat, lon, earthRadius + 0.01);
      mesh.position.copy(pos);
      mesh.userData = { label, lat, lon };
      markersGroupRef.current.add(mesh);
    },
    clearMarkers: () => {
      if (!markersGroupRef.current) return;
      while (markersGroupRef.current.children.length) {
        const obj = markersGroupRef.current.children.pop();
        obj.geometry?.dispose?.();
        obj.material?.dispose?.();
      }
    },
    flyTo: ({ lat, lon, ms = 1200 }) => {
      if (!cameraRef.current || !controlsRef.current) return;
      const radius = earthRadius + 3.5;
      const target = new THREE.Vector3(0, 0, 0);
      // Set camera position based on lat/lon on orbit
      const pos = latLonToVector3(lat, lon, radius);
      const start = cameraRef.current.position.clone();
      const end = pos;
      const startTime = performance.now();
      const animateFly = () => {
        const t = Math.min(1, (performance.now() - startTime) / ms);
        cameraRef.current.position.lerpVectors(start, end, t);
        controlsRef.current.lookAt(target);
        if (t < 1) {
          requestAnimationFrame(animateFly);
        } else {
          controlsRef.current.update();
        }
      };
      animateFly();
    },
    addPolyline: (latLonArray, color = 0x00ff88, width = 1.25) => {
      if (!overlaysGroupRef.current || !latLonArray?.length) return;
      const positions = [];
      latLonArray.forEach(([lat, lon]) => {
        const v = latLonToVector3(lat, lon, earthRadius + 0.02);
        positions.push(v.x, v.y, v.z);
      });
      const geom = new THREE.BufferGeometry();
      geom.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
      const mat = new THREE.LineBasicMaterial({ color, linewidth: width });
      const line = new THREE.Line(geom, mat);
      overlaysGroupRef.current.add(line);
      return line;
    },
    clearOverlays: () => {
      if (!overlaysGroupRef.current) return;
      while (overlaysGroupRef.current.children.length) {
        const obj = overlaysGroupRef.current.children.pop();
        obj.geometry?.dispose?.();
        obj.material?.dispose?.();
      }
    },
  }));

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Setup scene and renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(48, container.clientWidth / height, 0.1, 1000);
    camera.position.set(0, 0, earthRadius + 4);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    renderer.setSize(container.clientWidth, height);
    rendererRef.current = renderer;
    container.appendChild(renderer.domElement);

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const point = new THREE.PointLight(0xffffff, 1);
    point.position.set(10, 10, 10);
    scene.add(point);

    // Stars
    const starsGeom = new THREE.BufferGeometry();
    const starCount = 1600;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      starPos[i * 3] = (Math.random() * 2 - 1) * 200;
      starPos[i * 3 + 1] = (Math.random() * 2 - 1) * 200;
      starPos[i * 3 + 2] = (Math.random() * 2 - 1) * 200;
    }
    starsGeom.setAttribute("position", new THREE.Float32BufferAttribute(starPos, 3));
    const stars = new THREE.Points(starsGeom, new THREE.PointsMaterial({ color: 0xffffff, size: 0.6, transparent: true, opacity: 0.8 }));
    scene.add(stars);

    // Groups
    const globeGroup = new THREE.Group();
    globeGroupRef.current = globeGroup;
    scene.add(globeGroup);

    const markersGroup = new THREE.Group();
    markersGroupRef.current = markersGroup;
    scene.add(markersGroup);

    const overlaysGroup = new THREE.Group();
    overlaysGroupRef.current = overlaysGroup;
    scene.add(overlaysGroup);

    // Earth
    const loader = new THREE.TextureLoader();
    const earthTexture = loader.load(EARTH_TEXTURE);
    const bumpTexture = loader.load(EARTH_BUMP);
    const earthGeom = new THREE.SphereGeometry(earthRadius, 96, 96);
    const earthMat = new THREE.MeshPhongMaterial({
      map: earthTexture,
      bumpMap: bumpTexture,
      bumpScale: 0.04,
      specular: new THREE.Color("#444"),
      shininess: 8,
    });
    const earthMesh = new THREE.Mesh(earthGeom, earthMat);
    globeGroup.add(earthMesh);

    // Grid (graticules): parallels and meridians every 30°
    if (showGrid) {
      const gridMat = new THREE.LineBasicMaterial({ color: 0x1f9cf0, transparent: true, opacity: 0.25 });
      // Parallels
      for (let lat = -60; lat <= 60; lat += 30) {
        const positions = [];
        for (let lon = -180; lon <= 180; lon += 3) {
          const v = latLonToVector3(lat, lon, earthRadius + 0.002);
          positions.push(v.x, v.y, v.z);
        }
        const g = new THREE.BufferGeometry();
        g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
        const line = new THREE.Line(g, gridMat);
        globeGroup.add(line);
      }
      // Meridians
      for (let lon = -150; lon <= 180; lon += 30) {
        const positions = [];
        for (let lat = -90; lat <= 90; lat += 3) {
          const v = latLonToVector3(lat, lon, earthRadius + 0.002);
          positions.push(v.x, v.y, v.z);
        }
        const g = new THREE.BufferGeometry();
        g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
        const line = new THREE.Line(g, gridMat);
        globeGroup.add(line);
      }
    }

    // Orbit controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableZoom = true;
    controls.enablePan = false;
    controlsRef.current = controls;

    // Initial markers
    initialMarkers.forEach((m) => {
      const geom = new THREE.SphereGeometry(m.size || 0.035, 16, 16);
      const mat = new THREE.MeshBasicMaterial({ color: m.color || 0xff5252 });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.copy(latLonToVector3(m.lat, m.lon, earthRadius + 0.01));
      mesh.userData = m;
      markersGroup.add(mesh);
    });

    // Animate
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      if (autoRotate) {
        globeGroup.rotation.y += rotationSpeed;
      }
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const onResize = () => {
      if (!container) return;
      renderer.setSize(container.clientWidth, height);
      camera.aspect = container.clientWidth / height;
      camera.updateProjectionMatrix();
    };
    window.addEventListener("resize", onResize);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationIdRef.current);
      window.removeEventListener("resize", onResize);
      controls.dispose();
      earthGeom.dispose();
      earthMat.dispose();
      starsGeom.dispose();
      stars.material.dispose();
      renderer.domElement?.parentNode?.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [height, autoRotate, rotationSpeed, showGrid, initialMarkers]);

  return <div ref={containerRef} className="w-full rounded-xl overflow-hidden bg-black/20" style={{ height }} />;
});

export default OrbitalGlobe;