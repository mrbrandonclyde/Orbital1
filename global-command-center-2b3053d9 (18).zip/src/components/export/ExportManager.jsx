import React from "react";

export default function ExportManager() {
  return (
    <div className="bg-gray-800 text-white p-3 rounded shadow">
      {/* 📤 Export Manager */}
      <button className="bg-blue-600 px-4 py-2 rounded hover:bg-blue-700 w-full text-sm">
        Export Report
      </button>
      {/* TODO: Hook to backend export (PDF/Excel, billing per report) */}
    </div>
  );
}