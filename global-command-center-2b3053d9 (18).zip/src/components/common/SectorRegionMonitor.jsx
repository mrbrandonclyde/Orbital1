import React, { useState } from 'react';
import { useLiveData } from '../lib/useLiveData';
import { sectors } from '../data/regions';
import RegionSelector from './RegionSelector';
import { Card } from '@/components/ui/card';

export default function SectorRegionMonitor({ 
  sector, 
  defaultRegion = 'US-CA',
  className = ""
}) {
  const [selectedRegion, setSelectedRegion] = useState(defaultRegion);
  
  // Get sector info
  const sectorInfo = sectors.find(s => s.id === sector);
  const eventName = `${sector}:update`;
  
  // Subscribe to live data for this sector and region
  const liveData = useLiveData(sector, selectedRegion, eventName);

  return (
    <Card className={`p-6 bg-[#0A0D18]/50 border-gray-800 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">{sectorInfo?.icon || '📊'}</span>
          <h3 className="text-xl font-semibold text-white capitalize">{sector}</h3>
        </div>
        {liveData ? (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-green-400">LIVE</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
            <span className="text-xs text-gray-500">OFFLINE</span>
          </div>
        )}
      </div>

      <RegionSelector
        sector={sector}
        selectedRegion={selectedRegion}
        onRegionChange={setSelectedRegion}
        className="mb-6"
      />

      <div className="bg-gray-800/30 rounded-lg p-4 min-h-24">
        {liveData ? (
          <div className="space-y-2">
            <h4 className="font-semibold text-white">Live Data:</h4>
            <pre className="text-xs text-gray-300 overflow-auto max-h-32">
              {JSON.stringify(liveData, null, 2)}
            </pre>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-500 text-sm">
              Waiting for {sector} data from {selectedRegion}...
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}