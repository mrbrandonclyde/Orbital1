import React, { createContext, useContext, useState, useEffect } from 'react';

const AccessibilityContext = createContext();

export function useAccessibility() {
  return useContext(AccessibilityContext);
}

export function AccessibilityProvider({ children }) {
  const [preferences, setPreferences] = useState({
    reducedMotion: false,
    highContrast: false,
    largeText: false,
    keyboardNavigation: false,
    screenReader: false
  });

  useEffect(() => {
    // Detect system preferences
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPreferences(prev => ({
      ...prev,
      reducedMotion: mediaQuery.matches
    }));

    const highContrastQuery = window.matchMedia('(prefers-contrast: high)');
    setPreferences(prev => ({
      ...prev,
      highContrast: highContrastQuery.matches
    }));

    // Detect keyboard usage
    const handleKeyDown = (e) => {
      if (e.key === 'Tab') {
        setPreferences(prev => ({
          ...prev,
          keyboardNavigation: true
        }));
        document.body.classList.add('keyboard-navigation');
      }
    };

    const handleMouseDown = () => {
      document.body.classList.remove('keyboard-navigation');
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handleMouseDown);

    // Check for screen reader
    const screenReaderDetected = window.navigator.userAgent.includes('NVDA') || 
                                 window.navigator.userAgent.includes('JAWS') || 
                                 window.speechSynthesis;
                                 
    setPreferences(prev => ({
      ...prev,
      screenReader: !!screenReaderDetected
    }));

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);

  const updatePreference = (key, value) => {
    setPreferences(prev => ({
      ...prev,
      [key]: value
    }));

    // Apply CSS classes based on preferences
    if (key === 'highContrast') {
      document.body.classList.toggle('high-contrast', value);
    }
    if (key === 'largeText') {
      document.body.classList.toggle('large-text', value);
    }
    if (key === 'reducedMotion') {
      document.body.classList.toggle('reduced-motion', value);
    }
  };

  // Announce important changes to screen readers
  const announce = (message, priority = 'polite') => {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', priority);
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;
    
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  };

  const value = {
    preferences,
    updatePreference,
    announce
  };

  return (
    <AccessibilityContext.Provider value={value}>
      {children}
    </AccessibilityContext.Provider>
  );
}