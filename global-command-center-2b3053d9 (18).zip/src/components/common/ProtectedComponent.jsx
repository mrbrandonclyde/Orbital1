import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Lock, Crown, Zap } from 'lucide-react';

const useCurrentUser = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  return { user, loading };
};

const TIER_CONFIGS = {
  BASIC: {
    color: 'text-gray-400',
    bg: 'bg-gray-500/10',
    icon: Lock,
    label: 'Basic'
  },
  PROFESSIONAL: {
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    icon: Zap,
    label: 'Professional'
  },
  ENTERPRISE: {
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    icon: Crown,
    label: 'Enterprise'
  },
  GOVERNMENT: {
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    icon: Crown,
    label: 'Government'
  }
};

export function UpgradePrompt({ feature, requiredTier, className = "" }) {
  const config = TIER_CONFIGS[requiredTier];
  const Icon = config.icon;
  
  return (
    <div className={`bg-gray-800/50 border border-gray-700 rounded-xl p-6 text-center ${className}`}>
      <div className={`w-12 h-12 rounded-full ${config.bg} flex items-center justify-center mx-auto mb-4`}>
        <Icon className={`w-6 h-6 ${config.color}`} />
      </div>
      <h3 className="text-xl font-semibold text-white mb-2">Premium Feature</h3>
      <p className="text-gray-400 mb-4">
        {feature} requires <span className={`font-semibold ${config.color}`}>{config.label}</span> or higher subscription.
      </p>
      <button className="orbital-button-primary">
        Upgrade to {config.label}
      </button>
    </div>
  );
}

export default function ProtectedComponent({ 
  children, 
  allowedRoles = [], 
  requiredTier = null,
  requiredFeature = null,
  fallback = null 
}) {
  const { user, loading } = useCurrentUser();

  if (loading) {
    return null;
  }

  if (!user) {
    return fallback;
  }

  // Check role permissions
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return fallback;
  }

  // Check subscription tier
  if (requiredTier) {
    const tierLevels = { BASIC: 1, PROFESSIONAL: 2, ENTERPRISE: 3, GOVERNMENT: 4 };
    const userLevel = tierLevels[user.subscription_tier] || 0;
    const requiredLevel = tierLevels[requiredTier] || 0;
    
    if (userLevel < requiredLevel) {
      return fallback || <UpgradePrompt feature="This feature" requiredTier={requiredTier} />;
    }
  }

  // Check specific feature access
  if (requiredFeature && (!user.licensed_features || !user.licensed_features.includes(requiredFeature))) {
    return fallback || <UpgradePrompt feature={requiredFeature} requiredTier="PROFESSIONAL" />;
  }

  return <>{children}</>;
}