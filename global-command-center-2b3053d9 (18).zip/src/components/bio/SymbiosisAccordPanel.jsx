import React from 'react';
import { FileText, Shield, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

export default function SymbiosisAccordPanel({ accords }) {
  const getComplianceIcon = (status) => {
    switch (status) {
      case 'FULL_COMPLIANCE': return CheckCircle;
      case 'PARTIAL_COMPLIANCE': return AlertTriangle;
      case 'UNDER_DEVELOPMENT': return Clock;
      default: return Shield;
    }
  };

  const getComplianceColor = (status) => {
    switch (status) {
      case 'FULL_COMPLIANCE': return 'text-green-400 bg-green-500/10';
      case 'PARTIAL_COMPLIANCE': return 'text-yellow-400 bg-yellow-500/10';
      case 'UNDER_DEVELOPMENT': return 'text-blue-400 bg-blue-500/10';
      default: return 'text-red-400 bg-red-500/10';
    }
  };

  return (
    <div className="orbital-card p-6 h-fit">
      <h3 className="orbital-text-subheading flex items-center mb-4">
        <FileText className="w-5 h-5 mr-2 text-indigo-400" />
        Symbiosis Accords
      </h3>
      
      {accords.length > 0 ? (
        <div className="space-y-4">
          {accords.map(accord => {
            const ComplianceIcon = getComplianceIcon(accord.compliance_status);
            const complianceColor = getComplianceColor(accord.compliance_status);
            
            return (
              <div key={accord.id} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-semibold text-white">{accord.accord_version}</span>
                  <div className={`flex items-center space-x-1 px-2 py-1 rounded-full ${complianceColor}`}>
                    <ComplianceIcon className="w-3 h-3" />
                    <span className="text-xs">{accord.compliance_status?.replace(/_/g, ' ')}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-indigo-400">Core Principles</h4>
                  {accord.core_principles?.slice(0, 3).map((principle, index) => (
                    <div key={index} className="text-xs text-gray-400 p-2 bg-black/20 rounded">
                      <span className="font-medium text-indigo-300">{principle.principle_id}:</span> {principle.title}
                    </div>
                  ))}
                  {accord.core_principles?.length > 3 && (
                    <p className="text-xs text-gray-500">+{accord.core_principles.length - 3} more principles...</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No Symbiosis Accords found</p>
          <p className="text-xs">Ethical frameworks pending deployment</p>
        </div>
      )}
      
      <div className="mt-6 p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-lg">
        <h4 className="text-sm font-semibold text-indigo-400 mb-2">Phase 4 Ethics Framework</h4>
        <div className="space-y-1 text-xs text-gray-400">
          <div className="flex justify-between">
            <span>Cognitive Sovereignty</span>
            <CheckCircle className="w-3 h-3 text-green-400" />
          </div>
          <div className="flex justify-between">
            <span>Biological Integrity</span>
            <CheckCircle className="w-3 h-3 text-green-400" />
          </div>
          <div className="flex justify-between">
            <span>Symbiotic Consent</span>
            <AlertTriangle className="w-3 h-3 text-yellow-400" />
          </div>
          <div className="flex justify-between">
            <span>Genetic Heritage Protection</span>
            <Clock className="w-3 h-3 text-blue-400" />
          </div>
        </div>
      </div>
    </div>
  );
}