import React, { useState, useEffect } from 'react';
import { InvokeLLM, ExtractDataFromUploadedFile } from '@/api/integrations';
import { BusinessSector, Company, Asset, FinancialStatement } from '@/api/entities';
import { Database, Download, CheckCircle, AlertTriangle, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function DataIngestionEngine() {
  const [ingestionStatus, setIngestionStatus] = useState({
    fortune1000: 'idle',
    global500: 'idle',
    sectors: 'idle',
    supplyChains: 'idle',
    financials: 'idle'
  });
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState([]);

  const addLog = (message, type = 'info') => {
    setLogs(prev => [...prev, { 
      message, 
      type, 
      timestamp: new Date().toLocaleTimeString() 
    }]);
  };

  // Fortune 1000 Data Ingestion
  const ingestFortune1000 = async () => {
    setIngestionStatus(prev => ({ ...prev, fortune1000: 'loading' }));
    addLog('🏢 Starting Fortune 1000 data ingestion...');
    
    try {
      // Use AI to generate Fortune 1000 structured data
      const fortune1000Data = await InvokeLLM({
        prompt: `Generate a comprehensive Fortune 1000 dataset with the following structure:
        - 50 major US companies across different sectors
        - Include company name, ticker symbol, sector, annual revenue (billions), headquarters state
        - Sectors should include: Technology, Healthcare, Financial Services, Energy, Manufacturing, Retail, Defense, Telecommunications
        - Revenue should be realistic (range $10B - $500B)
        - Include major companies like Apple, Microsoft, Amazon, Berkshire Hathaway, etc.`,
        response_json_schema: {
          type: "object",
          properties: {
            companies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  company_name: { type: "string" },
                  ticker_symbol: { type: "string" },
                  primary_sector_id: { type: "string" },
                  annual_revenue_billions: { type: "number" },
                  headquarters_state: { type: "string" },
                  headquarters_country: { type: "string", default: "United States" },
                  employee_count: { type: "number" },
                  founded_year: { type: "number" },
                  market_cap_billions: { type: "number" }
                }
              }
            }
          }
        }
      });

      // Create companies in database
      for (const company of fortune1000Data.companies) {
        try {
          await Company.create(company);
        } catch (error) {
          console.log(`Company ${company.company_name} may already exist, skipping...`);
        }
      }

      setIngestionStatus(prev => ({ ...prev, fortune1000: 'success' }));
      addLog(`✅ Fortune 1000: ${fortune1000Data.companies.length} companies ingested`, 'success');
      setProgress(20);

    } catch (error) {
      setIngestionStatus(prev => ({ ...prev, fortune1000: 'error' }));
      addLog(`❌ Fortune 1000 ingestion failed: ${error.message}`, 'error');
    }
  };

  // Global 500 Data Ingestion  
  const ingestGlobal500 = async () => {
    setIngestionStatus(prev => ({ ...prev, global500: 'loading' }));
    addLog('🌍 Starting Global 500 data ingestion...');
    
    try {
      const global500Data = await InvokeLLM({
        prompt: `Generate a Global 500 dataset focusing on international companies:
        - 30 major international companies from Europe, Asia, Middle East, Latin America
        - Include company name, country, sector, annual revenue (billions)
        - Companies like Samsung, Toyota, Saudi Aramco, TSMC, Nestlé, ASML, etc.
        - Diverse sectors: Technology, Energy, Automotive, Industrial, Consumer Goods
        - Revenue range $20B - $400B`,
        response_json_schema: {
          type: "object",
          properties: {
            companies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  company_name: { type: "string" },
                  ticker_symbol: { type: "string" },
                  primary_sector_id: { type: "string" },
                  annual_revenue_billions: { type: "number" },
                  headquarters_country: { type: "string" },
                  headquarters_state: { type: "string" },
                  employee_count: { type: "number" },
                  founded_year: { type: "number" },
                  market_cap_billions: { type: "number" }
                }
              }
            }
          }
        }
      });

      for (const company of global500Data.companies) {
        try {
          await Company.create(company);
        } catch (error) {
          console.log(`Company ${company.company_name} may already exist, skipping...`);
        }
      }

      setIngestionStatus(prev => ({ ...prev, global500: 'success' }));
      addLog(`✅ Global 500: ${global500Data.companies.length} companies ingested`, 'success');
      setProgress(40);

    } catch (error) {
      setIngestionStatus(prev => ({ ...prev, global500: 'error' }));
      addLog(`❌ Global 500 ingestion failed: ${error.message}`, 'error');
    }
  };

  // Business Sectors Ingestion
  const ingestSectors = async () => {
    setIngestionStatus(prev => ({ ...prev, sectors: 'loading' }));
    addLog('🏛️ Starting business sectors ingestion...');
    
    try {
      const sectorsData = await InvokeLLM({
        prompt: `Generate comprehensive business sector data for the Global Command Center:
        - 15 major business sectors with detailed information
        - Include sector name, category, GDP contribution, strategic importance
        - Sectors: Technology, Defense, Healthcare, Energy, Financial Services, Manufacturing, Retail, Agriculture, Transportation, Telecommunications, Real Estate, Education, Entertainment, Mining, Utilities
        - Include state/regional mapping where applicable`,
        response_json_schema: {
          type: "object",
          properties: {
            sectors: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  sector_code: { type: "string" },
                  sector_name: { type: "string" },
                  sector_category: { type: "string" },
                  description: { type: "string" },
                  country: { type: "string" },
                  state: { type: "string" },
                  gdp_contribution_billions: { type: "number" },
                  employment_count: { type: "number" },
                  strategic_importance: { type: "string" },
                  regulation_level: { type: "string" }
                }
              }
            }
          }
        }
      });

      for (const sector of sectorsData.sectors) {
        try {
          await BusinessSector.create(sector);
        } catch (error) {
          console.log(`Sector ${sector.sector_name} may already exist, skipping...`);
        }
      }

      setIngestionStatus(prev => ({ ...prev, sectors: 'success' }));
      addLog(`✅ Sectors: ${sectorsData.sectors.length} business sectors ingested`, 'success');
      setProgress(60);

    } catch (error) {
      setIngestionStatus(prev => ({ ...prev, sectors: 'error' }));
      addLog(`❌ Sectors ingestion failed: ${error.message}`, 'error');
    }
  };

  // Financial Statements Ingestion
  const ingestFinancials = async () => {
    setIngestionStatus(prev => ({ ...prev, financials: 'loading' }));
    addLog('💰 Starting financial statements ingestion...');
    
    try {
      // Get existing companies to create financial statements for
      const companies = await Company.list('-created_date', 20);
      
      if (companies.length === 0) {
        throw new Error('No companies found. Run company ingestion first.');
      }

      const financialStatements = [];
      
      for (const company of companies.slice(0, 15)) {
        const statement = {
          company_id: company.id,
          period_ending_date: '2023-12-31',
          filing_type: '10-K',
          revenue: company.annual_revenue_billions * 1e9,
          net_income: company.annual_revenue_billions * 1e9 * (0.05 + Math.random() * 0.15), // 5-20% net margin
          gross_profit: company.annual_revenue_billions * 1e9 * (0.25 + Math.random() * 0.25), // 25-50% gross margin
          ebitda: company.annual_revenue_billions * 1e9 * (0.15 + Math.random() * 0.20), // 15-35% EBITDA
          total_assets: company.annual_revenue_billions * 1e9 * (1.5 + Math.random() * 2), // 1.5-3.5x revenue
          market_cap: company.market_cap_billions * 1e9,
          currency: 'USD'
        };
        financialStatements.push(statement);
      }

      for (const statement of financialStatements) {
        try {
          await FinancialStatement.create(statement);
        } catch (error) {
          console.log(`Financial statement for company ${statement.company_id} may already exist, skipping...`);
        }
      }

      setIngestionStatus(prev => ({ ...prev, financials: 'success' }));
      addLog(`✅ Financials: ${financialStatements.length} statements ingested`, 'success');
      setProgress(80);

    } catch (error) {
      setIngestionStatus(prev => ({ ...prev, financials: 'error' }));
      addLog(`❌ Financials ingestion failed: ${error.message}`, 'error');
    }
  };

  // Assets Ingestion
  const ingestAssets = async () => {
    setIngestionStatus(prev => ({ ...prev, supplyChains: 'loading' }));
    addLog('🏗️ Starting strategic assets ingestion...');
    
    try {
      const companies = await Company.list('-created_date', 10);
      const sectors = await BusinessSector.list('-created_date', 5);
      
      if (companies.length === 0 || sectors.length === 0) {
        throw new Error('Companies and sectors must be ingested first.');
      }

      const assetsData = [];
      
      // Generate assets for each company
      for (const company of companies) {
        const sector = sectors[Math.floor(Math.random() * sectors.length)];
        
        const asset = {
          asset_name: `${company.company_name} Primary Operations`,
          asset_type: 'PHYSICAL',
          asset_subtype: 'Corporate Headquarters',
          description: `Primary operational facility for ${company.company_name}`,
          current_value_usd: company.market_cap_billions * 1e9 * 0.1, // 10% of market cap
          acquisition_cost_usd: company.market_cap_billions * 1e9 * 0.08,
          location: `${company.headquarters_state}, ${company.headquarters_country}`,
          owner_id: company.id,
          owner_type: 'COMPANY',
          sector_id: sector.id,
          company_id: company.id,
          risk_level: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)],
          last_inspection_date: '2024-01-15'
        };
        
        assetsData.push(asset);
      }

      for (const asset of assetsData) {
        try {
          await Asset.create(asset);
        } catch (error) {
          console.log(`Asset ${asset.asset_name} may already exist, skipping...`);
        }
      }

      setIngestionStatus(prev => ({ ...prev, supplyChains: 'success' }));
      addLog(`✅ Assets: ${assetsData.length} strategic assets ingested`, 'success');
      setProgress(100);

    } catch (error) {
      setIngestionStatus(prev => ({ ...prev, supplyChains: 'error' }));
      addLog(`❌ Assets ingestion failed: ${error.message}`, 'error');
    }
  };

  // Run full ingestion pipeline
  const runFullIngestion = async () => {
    setProgress(0);
    setLogs([]);
    addLog('🚀 Starting full data ingestion pipeline...');
    
    await ingestSectors();
    await ingestFortune1000();
    await ingestGlobal500();
    await ingestFinancials();
    await ingestAssets();
    
    addLog('✅ Full ingestion pipeline completed successfully!', 'success');
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'loading': return <Activity className="w-4 h-4 text-blue-400 animate-spin" />;
      default: return <Database className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Database className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-semibold text-white">Data Ingestion Engine</h2>
          <div className="px-2 py-1 bg-indigo-500/20 text-indigo-400 text-xs rounded">
            AUTO-LOADER
          </div>
        </div>
        <Button onClick={runFullIngestion} className="orbital-button-primary">
          Run Full Ingestion
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-400">Ingestion Progress</span>
          <span className="text-sm text-white">{progress}%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Ingestion Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        {[
          { key: 'sectors', name: 'Business Sectors' },
          { key: 'fortune1000', name: 'Fortune 1000' },
          { key: 'global500', name: 'Global 500' },
          { key: 'financials', name: 'Financial Data' },
          { key: 'supplyChains', name: 'Strategic Assets' }
        ].map(item => (
          <div key={item.key} className="bg-gray-800/30 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-2">
              {getStatusIcon(ingestionStatus[item.key])}
              <span className="text-sm font-medium text-white">{item.name}</span>
            </div>
            <div className="text-xs text-gray-400 capitalize">{ingestionStatus[item.key]}</div>
          </div>
        ))}
      </div>

      {/* Ingestion Logs */}
      <div className="bg-black/30 rounded-lg p-4 max-h-64 overflow-y-auto">
        <h4 className="text-sm font-medium text-white mb-3">Ingestion Logs</h4>
        <div className="space-y-1">
          {logs.map((log, index) => (
            <div key={index} className="text-xs flex items-start space-x-2">
              <span className="text-gray-500 font-mono">{log.timestamp}</span>
              <span className={`${
                log.type === 'success' ? 'text-green-400' :
                log.type === 'error' ? 'text-red-400' :
                'text-gray-300'
              }`}>{log.message}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}