import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, Eye, AlertTriangle, CheckCircle, X, Smartphone, Key, Wifi } from 'lucide-react';
import { User } from '@/api/entities';

export default function SecurityDashboard({ user, onUpdate }) {
  const [securityScore, setSecurityScore] = useState(0);
  const [securityChecks, setSecurityChecks] = useState([]);
  const [activeThreats, setActiveThreats] = useState([]);

  useEffect(() => {
    const calculateSecurityScore = () => {
      let score = 0;
      const maxScore = 100;
      
      // Two-factor authentication (30 points)
      if (user?.mfa_enabled) score += 30;
      
      // Strong password policy (20 points) - simulated
      score += 20; // Assuming strong password
      
      // Recent login activity (15 points)
      if (user?.last_login) {
        const daysSinceLogin = (new Date() - new Date(user.last_login)) / (1000 * 60 * 60 * 24);
        if (daysSinceLogin < 30) score += 15;
      }
      
      // Security clearance level (20 points)
      const clearanceLevels = {
        'CONFIDENTIAL': 5,
        'SECRET': 10,
        'TOP_SECRET': 15,
        'EXECUTIVE_COMMAND': 20
      };
      score += clearanceLevels[user?.security_clearance] || 0;
      
      // Notification preferences configured (15 points)
      if (user?.notification_preferences?.security_alerts) score += 15;
      
      setSecurityScore(Math.min(score, maxScore));
    };

    const loadSecurityChecks = () => {
      const checks = [
        {
          id: 'mfa',
          name: 'Two-Factor Authentication',
          status: user?.mfa_enabled ? 'passed' : 'warning',
          description: user?.mfa_enabled ? '2FA is enabled' : '2FA is disabled - Enable for better security',
          icon: Smartphone,
          severity: 'high'
        },
        {
          id: 'password',
          name: 'Password Strength',
          status: 'passed', // Simulated
          description: 'Strong password detected',
          icon: Lock,
          severity: 'medium'
        },
        {
          id: 'session',
          name: 'Session Security',
          status: 'passed',
          description: 'Secure session management active',
          icon: Key,
          severity: 'high'
        },
        {
          id: 'connection',
          name: 'Connection Security',
          status: typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'passed' : 'failed',
          description: typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'Secure HTTPS connection' : 'Insecure connection detected',
          icon: Wifi,
          severity: 'critical'
        },
        {
          id: 'clearance',
          name: 'Security Clearance',
          status: user?.security_clearance ? 'passed' : 'warning',
          description: `Security clearance: ${user?.security_clearance || 'Not set'}`,
          icon: Shield,
          severity: 'medium'
        }
      ];
      
      setSecurityChecks(checks);
    };

    const loadActiveThreats = () => {
      // Simulated threat data
      const threats = [
        {
          id: 'threat1',
          type: 'Suspicious Login Attempt',
          severity: 'medium',
          location: 'Unknown Location',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toLocaleString(),
          status: 'blocked'
        },
        {
          id: 'threat2',
          type: 'Rate Limiting Triggered',
          severity: 'low',
          location: 'Current Session',
          timestamp: new Date(Date.now() - 30 * 60 * 1000).toLocaleString(),
          status: 'resolved'
        }
      ];
      
      setActiveThreats(threats);
    };

    if(user) {
      calculateSecurityScore();
      loadSecurityChecks();
      loadActiveThreats();
    }
  }, [user]);

  const getSecurityScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'failed': return <X className="w-4 h-4 text-red-400" />;
      default: return <Eye className="w-4 h-4 text-gray-400" />;
    }
  };

  const getSeverityBadge = (severity) => {
    const colors = {
      critical: 'bg-red-500/20 text-red-400 border-red-500/30',
      high: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      low: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };
    
    return (
      <Badge className={colors[severity] || colors.low}>
        {severity?.toUpperCase()}
      </Badge>
    );
  };

  const handleEnableMFA = () => {
    // This would typically redirect to 2FA setup in a real app.
    // Here we can just call the onUpdate to signal a change.
    onUpdate();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-white">Security Posture</h2>
          <p className="text-gray-400 text-sm">Real-time account security analysis.</p>
        </div>
        <div className="text-center">
          <div className={`text-3xl font-bold ${getSecurityScoreColor(securityScore)}`}>
            {securityScore}%
          </div>
          <p className="text-sm text-gray-400">Security Score</p>
        </div>
      </div>

      {/* Security Checks */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="text-white text-lg">System Checks</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {securityChecks.map((check) => {
            const Icon = check.icon;
            return (
              <div key={check.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(check.status)}
                  <Icon className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-white font-medium text-sm">{check.name}</p>
                    <p className="text-xs text-gray-500">{check.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getSeverityBadge(check.severity)}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Active Threats */}
      {activeThreats.length > 0 && (
        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white text-lg">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span>Recent Security Events</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {activeThreats.map((threat) => (
              <div key={threat.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                <div>
                  <p className="text-white font-medium text-sm">{threat.type}</p>
                  <p className="text-xs text-gray-500">
                    {threat.location} • {threat.timestamp}
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  {getSeverityBadge(threat.severity)}
                  <Badge className={
                    threat.status === 'blocked' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                    threat.status === 'resolved' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                    'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                  }>
                    {threat.status.toUpperCase()}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}