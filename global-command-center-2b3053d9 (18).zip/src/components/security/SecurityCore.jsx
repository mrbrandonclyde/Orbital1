import React, { useState, useEffect } from 'react';
import { useQuery } from '../lib/useQuery';
import { SecurityIncident } from '@/api/entities';
import { ComplianceFramework } from '@/api/entities';
import { AuditTrail } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Shield, Lock, AlertTriangle, CheckCircle, Eye, Cpu, Database, Clock } from 'lucide-react';

export default function SecurityCore() {
  const [securityStatus, setSecurityStatus] = useState({
    overallLevel: 'SECURE',
    activeThreats: 0,
    complianceScore: 0,
    lastAudit: null
  });

  // Fetch security data
  const { data: securityData, loading } = useQuery(['securityCore'], async () => {
    const [incidents, compliance, auditLogs] = await Promise.all([
      SecurityIncident.list('-detection_timestamp', 50),
      ComplianceFramework.list(),
      AuditTrail.filter({ 
        risk_score: { $gte: 50 } 
      }, '-action_timestamp', 100)
    ]);

    return { incidents, compliance, auditLogs };
  });

  // Calculate security metrics
  useEffect(() => {
    if (!securityData) return;

    const { incidents, compliance, auditLogs } = securityData;

    // Active threats
    const activeIncidents = incidents.filter(i => 
      ['DETECTED', 'INVESTIGATING', 'CONTAINED'].includes(i.incident_status)
    );

    // Compliance score
    const totalControls = compliance.reduce((sum, framework) => 
      sum + (framework.required_controls?.length || 0), 0
    );
    const implementedControls = compliance.reduce((sum, framework) => 
      sum + (framework.required_controls?.filter(c => 
        c.implementation_status === 'IMPLEMENTED' || c.implementation_status === 'VERIFIED'
      ).length || 0), 0
    );

    const complianceScore = totalControls > 0 ? 
      Math.round((implementedControls / totalControls) * 100) : 100;

    // Overall security level
    let overallLevel = 'SECURE';
    const criticalIncidents = activeIncidents.filter(i => i.severity_level === 'CRITICAL').length;
    const highRiskAudits = auditLogs.filter(a => a.risk_score >= 80).length;

    if (criticalIncidents > 0 || highRiskAudits > 5) {
      overallLevel = 'CRITICAL';
    } else if (activeIncidents.length > 5 || complianceScore < 80) {
      overallLevel = 'ELEVATED';
    } else if (activeIncidents.length > 0 || complianceScore < 95) {
      overallLevel = 'GUARDED';
    }

    setSecurityStatus({
      overallLevel,
      activeThreats: activeIncidents.length,
      complianceScore,
      lastAudit: auditLogs[0]?.action_timestamp || null
    });
  }, [securityData]);

  const getSecurityLevelColor = (level) => {
    switch (level) {
      case 'SECURE': return 'text-green-400 bg-green-500/10';
      case 'GUARDED': return 'text-blue-400 bg-blue-500/10';
      case 'ELEVATED': return 'text-yellow-400 bg-yellow-500/10';
      case 'CRITICAL': return 'text-red-400 bg-red-500/10';
      default: return 'text-gray-400 bg-gray-500/10';
    }
  };

  const getComplianceColor = (score) => {
    if (score >= 95) return 'text-green-400';
    if (score >= 80) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Cpu className="w-8 h-8 text-cyan-400 mx-auto mb-2 animate-pulse" />
          <p className="text-gray-400">Initializing Security Core...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Security Status Header */}
      <Card className={`border-2 ${
        securityStatus.overallLevel === 'SECURE' ? 'border-green-500/50 bg-green-900/10' :
        securityStatus.overallLevel === 'GUARDED' ? 'border-blue-500/50 bg-blue-900/10' :
        securityStatus.overallLevel === 'ELEVATED' ? 'border-yellow-500/50 bg-yellow-900/10' :
        'border-red-500/50 bg-red-900/10'
      }`}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <Shield className="w-6 h-6 mr-3 text-cyan-400" />
              Security Command Center
            </span>
            <div className={`px-4 py-2 rounded-lg font-bold ${getSecurityLevelColor(securityStatus.overallLevel)}`}>
              DEFCON: {securityStatus.overallLevel}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-6">
            <div className="text-center">
              <div className={`text-3xl font-bold ${
                securityStatus.activeThreats === 0 ? 'text-green-400' :
                securityStatus.activeThreats < 5 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {securityStatus.activeThreats}
              </div>
              <div className="text-sm text-gray-400">Active Threats</div>
            </div>
            <div className="text-center">
              <div className={`text-3xl font-bold ${getComplianceColor(securityStatus.complianceScore)}`}>
                {securityStatus.complianceScore}%
              </div>
              <div className="text-sm text-gray-400">Compliance Score</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400">
                {securityData?.auditLogs?.filter(a => a.risk_score >= 70).length || 0}
              </div>
              <div className="text-sm text-gray-400">High-Risk Events</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400">
                {securityData?.compliance?.filter(c => c.certification_status === 'CERTIFIED').length || 0}
              </div>
              <div className="text-sm text-gray-400">Active Certifications</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Modules Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* Active Security Incidents */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-400" />
              Active Incidents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {securityData?.incidents?.slice(0, 5).map(incident => (
                <div key={incident.id} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-white text-sm">
                      {incident.incident_type.replace(/_/g, ' ')}
                    </h4>
                    <span className={`text-xs px-2 py-1 rounded ${
                      incident.severity_level === 'CRITICAL' ? 'bg-red-500/20 text-red-400' :
                      incident.severity_level === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                      incident.severity_level === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>
                      {incident.severity_level}
                    </span>
                  </div>
                  <p className="text-gray-400 text-xs">
                    Status: {incident.incident_status}
                  </p>
                  <p className="text-gray-500 text-xs">
                    {new Date(incident.detection_timestamp).toLocaleString()}
                  </p>
                </div>
              ))}
              {(!securityData?.incidents?.length) && (
                <div className="text-center py-6 text-green-400">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">No Active Incidents</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Compliance Framework Status */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lock className="w-5 h-5 mr-2 text-blue-400" />
              Compliance Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {securityData?.compliance?.slice(0, 4).map(framework => (
                <div key={framework.id} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-semibold text-white text-sm">
                      {framework.framework_name}
                    </h4>
                    <span className={`text-xs px-2 py-1 rounded ${
                      framework.certification_status === 'CERTIFIED' ? 'bg-green-500/20 text-green-400' :
                      framework.certification_status === 'IN_PROGRESS' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {framework.certification_status}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">
                      Score: {framework.compliance_score || 0}%
                    </span>
                    <span className="text-gray-500">
                      {framework.framework_version}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* High-Risk Audit Events */}
        <Card className="bg-[#0A0D18]/50 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="w-5 h-5 mr-2 text-purple-400" />
              High-Risk Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {securityData?.auditLogs?.filter(log => log.risk_score >= 70)
                .slice(0, 5).map(log => (
                <div key={log.id} className="p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-white text-sm">
                      {log.action} - {log.entity_type}
                    </h4>
                    <span className={`text-xs px-2 py-1 rounded ${
                      log.risk_score >= 90 ? 'bg-red-500/20 text-red-400' :
                      log.risk_score >= 80 ? 'bg-orange-500/20 text-orange-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      Risk: {log.risk_score}
                    </span>
                  </div>
                  <p className="text-gray-400 text-xs">
                    {log.security_classification}
                  </p>
                  <p className="text-gray-500 text-xs">
                    {new Date(log.action_timestamp).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Metrics Timeline */}
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="w-5 h-5 mr-2 text-cyan-400" />
            Security Timeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            <Database className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Real-time security timeline visualization</p>
            <p className="text-sm">Detailed metrics and threat progression tracking</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}