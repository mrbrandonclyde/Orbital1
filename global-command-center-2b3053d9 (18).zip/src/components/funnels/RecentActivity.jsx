import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, ChevronDown, ChevronUp, Layers } from "lucide-react";

export default function RecentActivity({ items = [], collapsed, onToggle, onOpen }) {
  const sorted = [...items]
    .sort((a, b) => new Date(b.updated_date || b.created_date || 0) - new Date(a.updated_date || a.created_date || 0))
    .slice(0, 12);

  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800 rounded-3xl h-full">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-cyan-400" /> Recent Activity
        </CardTitle>
        <Button size="sm" variant="ghost" onClick={onToggle} aria-label="Toggle recent activity">
          {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </Button>
      </CardHeader>
      {!collapsed && (
        <CardContent className="text-sm text-gray-300">
          <div className="space-y-2">
            {sorted.map((f) => (
              <button
                key={f.id}
                onClick={() => onOpen(f)}
                className="w-full text-left p-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/50 transition flex items-center gap-2"
                title="Open in editor"
              >
                <Layers className="w-4 h-4 text-cyan-400" />
                <div className="min-w-0">
                  <div className="truncate text-white">{f.funnel_name}</div>
                  <div className="text-xs text-gray-500 truncate">
                    {f.updated_date ? new Date(f.updated_date).toLocaleString() : new Date(f.created_date).toLocaleString()} • {f.type}
                  </div>
                </div>
              </button>
            ))}
            {sorted.length === 0 && <div className="text-xs text-gray-500">No recent changes.</div>}
          </div>
        </CardContent>
      )}
    </Card>
  );
}