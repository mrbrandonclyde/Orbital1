import React from "react";
import { InvokeLLM } from "@/api/integrations";
import { GeneratedAsset } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LineChart as LineChartIcon } from "lucide-react";

export default function PredictiveForecast() {
  const [visitors, setVisitors] = React.useState(10000);
  const [stepsText, setStepsText] = React.useState("Opt-in Page -> Sales Page -> Checkout -> Thank You");
  const [loading, setLoading] = React.useState(false);
  const [forecast, setForecast] = React.useState(null);

  const runForecast = async () => {
    setLoading(true);
    setForecast(null);

    const schema = {
      type: "object",
      properties: {
        step_forecast: {
          type: "array",
          items: {
            type: "object",
            properties: {
              step_name: { type: "string" },
              predicted_conv_rate_pct: { type: "number" },
              notes: { type: "string" }
            },
            required: ["step_name","predicted_conv_rate_pct"]
          }
        },
        overall_conversion_rate_pct: { type: "number" },
        expected_customers: { type: "number" },
        assumptions: { type: "array", items: { type: "string" } }
      },
      required: ["step_forecast","overall_conversion_rate_pct","expected_customers"]
    };

    const prompt = `
You are a predictive conversion analyst.
Given total visitors (${visitors}) and funnel steps "${stepsText}", forecast step-level conversion rates and overall conversion.
Return JSON matching the schema (percent values as numbers).
Assume reasonable industry averages and explain assumptions.
`;

    const res = await InvokeLLM({ prompt, add_context_from_internet: false, response_json_schema: schema });
    setForecast(res);

    const me = await User.me().catch(() => null);
    await GeneratedAsset.create({
      user_id: me?.id || "anonymous",
      asset_type: "prediction",
      title: "Funnel Conversion Forecast",
      prompt,
      output: res,
      tags: ["forecast", "conversion"]
    });

    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <div className="text-xs text-gray-400 mb-1">Expected Visitors</div>
          <Input type="number" value={visitors} onChange={(e)=>setVisitors(Number(e.target.value||0))} className="bg-[#0C0F19] border-gray-700 text-gray-200" />
        </div>
        <div className="md:col-span-2">
          <div className="text-xs text-gray-400 mb-1">Steps (arrow-separated)</div>
          <Input value={stepsText} onChange={(e)=>setStepsText(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-200" />
        </div>
      </div>

      <Button onClick={runForecast} disabled={loading} className="bg-green-600 hover:bg-green-700">
        <LineChartIcon className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
        {loading ? "Forecasting…" : "Run Forecast"}
      </Button>

      {forecast && (
        <div className="mt-4 p-4 border border-gray-800 rounded-xl bg-[#0A0D18]/60">
          <div className="text-white font-semibold mb-2">Forecast</div>
          <pre className="text-xs text-gray-300 whitespace-pre-wrap">{JSON.stringify(forecast, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}