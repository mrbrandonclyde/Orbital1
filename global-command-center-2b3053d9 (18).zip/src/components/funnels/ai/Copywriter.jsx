import React from "react";
import { InvokeLLM } from "@/api/integrations";
import { GeneratedAsset } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Type, Sparkles } from "lucide-react";

export default function Copywriter() {
  const [brief, setBrief] = React.useState("");
  const [tone, setTone] = React.useState("professional");
  const [variants, setVariants] = React.useState(5);
  const [loading, setLoading] = React.useState(false);
  const [output, setOutput] = React.useState(null);

  const generate = async () => {
    setLoading(true);
    setOutput(null);

    const schema = {
      type: "object",
      properties: {
        headlines: { type: "array", items: { type: "string" } },
        ctas: { type: "array", items: { type: "string" } },
        hooks: { type: "array", items: { type: "string" } },
        email_subjects: { type: "array", items: { type: "string" } },
        scripts: { type: "array", items: { type: "string" } }
      },
      required: ["headlines","ctas"]
    };

    const prompt = `
You are an elite direct-response copywriter.
Tone: ${tone}. Produce ${variants} variants each.
Return JSON arrays for: headlines, ctas, hooks, email_subjects, scripts.
Context:
${brief}
`;

    const res = await InvokeLLM({ prompt, add_context_from_internet: false, response_json_schema: schema });
    setOutput(res);

    const me = await User.me().catch(() => null);
    await GeneratedAsset.create({
      user_id: me?.id || "anonymous",
      asset_type: "copy",
      title: "AI Copy Pack",
      prompt,
      output: res,
      tags: [tone, "copy"]
    });

    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <div className="text-xs text-gray-400 mb-1">Tone</div>
          <Select value={tone} onValueChange={setTone}>
            <SelectTrigger className="bg-[#0C0F19] border-gray-700 text-gray-200"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="professional">Professional</SelectItem>
              <SelectItem value="casual">Casual</SelectItem>
              <SelectItem value="bold">Bold</SelectItem>
              <SelectItem value="playful">Playful</SelectItem>
              <SelectItem value="analytical">Analytical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <div className="text-xs text-gray-400 mb-1">Variants</div>
          <Input type="number" min={1} max={20} value={variants} onChange={(e)=>setVariants(Number(e.target.value||5))} className="bg-[#0C0F19] border-gray-700 text-gray-200" />
        </div>
      </div>

      <div>
        <div className="text-xs text-gray-400 mb-1">Brief / Context</div>
        <Textarea value={brief} onChange={(e)=>setBrief(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-200 h-28" placeholder="Describe your offer, audience, objections, proof, etc." />
      </div>

      <Button onClick={generate} disabled={loading} className="bg-purple-600 hover:bg-purple-700">
        <Sparkles className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
        {loading ? "Generating…" : "Generate Copy"}
      </Button>

      {output && (
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(output).map(([k, arr]) => (
            <div key={k} className="p-4 border border-gray-800 rounded-xl bg-[#0A0D18]/60">
              <div className="text-white font-semibold mb-2 uppercase">{k.replaceAll("_"," ")}</div>
              <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
                {(arr || []).map((t, i) => <li key={i}>{t}</li>)}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}