import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FunnelStep } from "@/api/entities";
import { Clock } from "lucide-react";

export default function HistoryModal({ open, onOpenChange, funnel }) {
  const [steps, setSteps] = React.useState([]);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (!open || !funnel) return;
      setLoading(true);
      const s = await FunnelStep.filter({ funnel_id: funnel.id }, "-updated_date", 500);
      if (mounted) setSteps(s);
      setLoading(false);
    };
    load();
    return () => {
      mounted = false;
    };
  }, [open, funnel]);

  return (
    <Dialog open={!!open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0A0D18] border border-gray-800 max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-white">Version History — {funnel?.funnel_name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm text-gray-300">
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <Clock className="w-4 h-4" />
            <span>
              Created {funnel?.created_date ? new Date(funnel.created_date).toLocaleString() : "—"} • Last updated{" "}
              {funnel?.updated_date ? new Date(funnel.updated_date).toLocaleString() : "—"}
            </span>
          </div>
          <div className="bg-gray-900/40 border border-gray-800 rounded-xl p-3">
            <div className="text-gray-400 text-xs mb-2">Steps (most recent first)</div>
            {loading ? (
              <div className="text-xs text-gray-500">Loading history…</div>
            ) : steps.length ? (
              <ul className="space-y-2">
                {steps.map((s) => (
                  <li key={s.id} className="p-2 bg-gray-800/30 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white">{s.step_name}</div>
                        <div className="text-xs text-gray-500">{s.step_type}</div>
                      </div>
                      <div className="text-xs text-gray-400">
                        {s.updated_date ? new Date(s.updated_date).toLocaleString() : new Date(s.created_date).toLocaleString()}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-xs text-gray-500">No steps yet.</div>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}