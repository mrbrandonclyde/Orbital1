import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const TYPES = [
  { key: "OPTIN", label: "Lead Gen" },
  { key: "SALES", label: "Sales" },
  { key: "WEBINAR", label: "Webinar" },
  { key: "MEMBERSHIP", label: "Membership" },
  { key: "MISC", label: "Custom" }
];

export default function StepType({ value, onChange }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {TYPES.map(t => {
        const selected = value === t.key;
        return (
          <Card key={t.key} onClick={() => onChange(t.key)}
            className={`cursor-pointer bg-[#0A0D18]/60 border ${selected ? 'border-indigo-500' : 'border-gray-800'} rounded-2xl`}>
            <CardHeader className="pb-2"><CardTitle className="text-white">{t.label}</CardTitle></CardHeader>
            <CardContent className="text-sm text-gray-400">Create a {t.label} funnel.</CardContent>
          </Card>
        );
      })}
    </div>
  );
}