import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function StepTemplates({ templates, selectedId, onSelect, filterCategory }) {
  const list = filterCategory ? templates.filter(t => t.category === filterCategory) : templates;
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {list.map(t => {
        const active = selectedId === t.id;
        return (
          <Card key={t.id} className={`bg-[#0A0D18]/60 border ${active ? 'border-indigo-500' : 'border-gray-800'} rounded-2xl overflow-hidden`}>
            <img src={t.thumbnail_url} alt={t.template_name} className="w-full h-40 object-cover" />
            <CardHeader className="pb-2">
              <CardTitle className="text-white truncate">{t.template_name}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-400">
              <p className="mb-3 line-clamp-2">{t.description || 'Template'}</p>
              <Button variant={active ? 'default' : 'secondary'} onClick={() => onSelect(t)}>
                {active ? 'Selected' : 'Use Template'}
              </Button>
            </CardContent>
          </Card>
        );
      })}
      {!list.length && <div className="text-gray-500">No templates found.</div>}
    </div>
  );
}