import React from 'react';
import { Rocket, Shield, CheckCircle, Clock } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const missionDetails = {
  planetary_defense_protocol: { icon: Shield, color: "red-400", title: "Planetary Defense" },
  colonization_protocol: { icon: Rocket, color: "green-400", title: "Colonization" },
  interplanetary_logistics: { icon: Rocket, color: "blue-400", title: "Logistics" },
  space_continuity_protocol: { icon: Shield, color: "purple-400", title: "Continuity" },
};

export default function MissionControlPhase3({ missions, selectedMission, loading }) {

  const renderMissionContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
      );
    }
    
    if (selectedMission) {
      const details = missionDetails[selectedMission.mission_type];
      const Icon = details.icon;
      return (
        <AnimatePresence>
          <motion.div
            key={selectedMission.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="p-6"
          >
            <div className={`flex items-center space-x-3 mb-4 text-${details.color}`}>
              <Icon className="w-8 h-8"/>
              <h3 className="text-2xl font-bold">{details.title} Protocol</h3>
            </div>
            <p className="text-sm text-gray-400 mb-2">Mission ID: {selectedMission.mission_id}</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">Status:</span>
                <span className={`font-semibold px-2 py-1 rounded-full bg-green-500/10 text-green-400`}>{selectedMission.mission_status}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">Domain:</span>
                <span className="font-semibold text-white capitalize">{selectedMission.target_domain}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">AI Role:</span>
                <span className="font-semibold text-white capitalize">{selectedMission.ai_role.replace(/_/g, ' ')}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">Ethics:</span>
                <span className={`font-semibold text-${selectedMission.ethics_compliance?.space_accords ? 'green' : 'yellow'}-400`}>
                  {selectedMission.ethics_compliance?.space_accords ? 'Space Accords Compliant' : 'Pending Review'}
                </span>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      );
    }

    return (
      <div className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Live Missions</h3>
        <div className="space-y-3">
          {missions.map(mission => {
            const details = missionDetails[mission.mission_type];
            const Icon = details.icon;
            return (
              <div key={mission.id} className={`p-3 rounded-lg bg-gray-800/50 border border-gray-700 flex items-center justify-between`}>
                <div className="flex items-center space-x-3">
                  <Icon className={`w-5 h-5 text-${details.color}`} />
                  <span className="text-sm font-medium text-white">{details.title}</span>
                </div>
                <span className="text-xs text-green-400">{mission.mission_status}</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  
  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl h-[600px] flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white text-center">Mission Control</h2>
      </div>
      <div className="flex-grow">
        {renderMissionContent()}
      </div>
    </div>
  );
}