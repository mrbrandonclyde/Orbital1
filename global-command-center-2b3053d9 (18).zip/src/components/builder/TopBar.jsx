
import React from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Monitor, Smartphone, Save, Undo2, Redo2, BookmarkPlus } from "lucide-react";

export default function TopBar({ steps, activeStepId, onChangeStep, preview, setPreview, device = "desktop", setDevice, onSave, onSaveTemplate, canUndo, canRedo, onUndo, onRedo }) {
  return (
    <div className="bg-[#0A0D18]/60 border border-gray-800 rounded-xl p-3 flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-2">
        <span className="text-xs text-gray-400">Page</span>
        <Select value={activeStepId || ""} onValueChange={onChangeStep}>
          <SelectTrigger className="w-56 bg-[#0C0F19] border-gray-700 text-gray-200">
            <SelectValue placeholder="Select page" />
          </SelectTrigger>
          <SelectContent>
            {steps.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.step_name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="ml-auto flex items-center gap-2">
        <Button variant={device === "desktop" ? "default" : "secondary"} onClick={() => setDevice && setDevice("desktop")}>
          <Monitor className="w-4 h-4 mr-2" /> Desktop
        </Button>
        <Button variant={device === "mobile" ? "default" : "secondary"} onClick={() => setDevice && setDevice("mobile")}>
          <Smartphone className="w-4 h-4 mr-2" /> Mobile
        </Button>
        <Button variant={preview ? "default" : "secondary"} onClick={() => setPreview(!preview)}>
          Preview
        </Button>
        <div className="w-px h-6 bg-gray-700 mx-2" />
        <Button variant="secondary" disabled={!canUndo} onClick={onUndo}>
          <Undo2 className="w-4 h-4 mr-2" /> Undo
        </Button>
        <Button variant="secondary" disabled={!canRedo} onClick={onRedo}>
          <Redo2 className="w-4 h-4 mr-2" /> Redo
        </Button>
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={onSave}>
          <Save className="w-4 h-4 mr-2" /> Save
        </Button>
        {onSaveTemplate && (
          <Button variant="secondary" onClick={onSaveTemplate}>
            <BookmarkPlus className="w-4 h-4 mr-2" /> Save as Template
          </Button>
        )}
      </div>
    </div>
  );
}
