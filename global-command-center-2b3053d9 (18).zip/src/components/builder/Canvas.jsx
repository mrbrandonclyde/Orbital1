
import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Star, Timer } from "lucide-react";

function RenderBlock({ block, selected, onSelect }) {
  const style = {
    padding: block.style?.padding ? `${block.style.padding}px` : undefined,
    backgroundColor: block.style?.bgColor || undefined,
    color: block.style?.textColor || undefined,
  };
  const common = "rounded-xl border border-dashed border-gray-700 p-4 bg-[#0A0D18]/40 hover:border-cyan-500/40 transition cursor-pointer";
  const wrapClass = `${common} ${selected ? "border-cyan-500" : ""}`;

  switch (block.type) {
    case "heading":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <h2 className="text-white text-2xl font-semibold">{block.data.text}</h2>
        </div>
      );
    case "text":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <p className="text-gray-300">{block.data.text}</p>
        </div>
      );
    case "image":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <img src={block.data.src} alt={block.data.alt || ""} className="w-full rounded-lg" />
        </div>
      );
    case "video":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="aspect-video w-full overflow-hidden rounded-lg">
            <iframe className="w-full h-full" src={block.data.url} title="Video" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" />
          </div>
        </div>
      );
    case "button":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <a href={block.data.href || "#"} className="inline-block px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg">{block.data.label}</a>
        </div>
      );
    case "divider":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="h-px w-full bg-gray-700" />
        </div>
      );
    case "countdown":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="flex items-center gap-2 text-white">
            <Timer className="w-4 h-4 text-yellow-400" />
            <span>{new Date(block.data.seconds * 1000).toISOString().substring(11, 19)}</span>
          </div>
        </div>
      );
    case "icon":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <Star className="text-yellow-400" style={{ width: block.data.size || 32, height: block.data.size || 32, color: block.data.color || "#fbbf24" }} />
        </div>
      );
    case "form_input":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <input placeholder={block.data.placeholder} className="w-full px-3 py-2 rounded bg-[#0C0F19] border border-gray-700 text-gray-200" />
        </div>
      );
    case "form_checkbox":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <label className="flex items-center gap-2 text-gray-200">
            <input type="checkbox" /> {block.data.label}
          </label>
        </div>
      );
    case "form_hidden":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="text-xs text-gray-400">Hidden field: {block.data.name} = {block.data.value}</div>
        </div>
      );
    case "form_multistep":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="text-gray-300 text-sm">Multi‑step Form (steps: {block.data.steps})</div>
        </div>
      );
    case "container":
      return (
        <div className={wrapClass} style={{ ...style, padding: style.padding || 24 }} onClick={onSelect}>
          <div className="text-gray-400 text-xs mb-2">Container</div>
          <div className="h-20 rounded bg-gray-800/30 border border-gray-700"></div>
        </div>
      );
    case "row":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="text-gray-400 text-xs mb-2">Row (columns: {block.data.columns || 2})</div>
          <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${block.data.columns || 2}, minmax(0,1fr))` }}>
            {Array.from({ length: block.data.columns || 2 }).map((_, i) => (
              <div key={i} className="h-16 rounded bg-gray-800/30 border border-gray-700" />
            ))}
          </div>
        </div>
      );
    case "grid":
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="text-gray-400 text-xs mb-2">Grid (columns: {block.data.columns || 3})</div>
          <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${block.data.columns || 3}, minmax(0,1fr))` }}>
            {Array.from({ length: block.data.columns || 3 }).map((_, i) => (
              <div key={i} className="h-16 rounded bg-gray-800/30 border border-gray-700" />
            ))}
          </div>
        </div>
      );
    default:
      return (
        <div className={wrapClass} style={style} onClick={onSelect}>
          <div className="text-gray-400 text-sm">{block.type.replace(/_/g, " ")}</div>
        </div>
      );
  }
}

export default function Canvas({ blocks, setBlocks, selectedId, setSelectedId, preview, device = "desktop" }) {
  const onDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(blocks);
    const [removed] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, removed);
    setBlocks(items);
  };

  const viewportClass = device === "mobile" ? "max-w-[420px]" : "max-w-4xl";

  if (preview) {
    return (
      <div className={`rounded-3xl border border-gray-800 bg-gradient-to-b from-[#0A0D18] to-[#05070e] p-6 min-h-[60vh] mx-auto ${viewportClass}`}>
        {blocks.map((b) => (
          <div key={b.id} className="mb-4 last:mb-0">
            <RenderBlock block={b} selected={false} onSelect={() => {}} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable droppableId="canvas">
        {(provided) => (
          <div className={`rounded-3xl border border-gray-800 bg-[#0A0D18]/40 p-6 min-h-[60vh] mx-auto ${viewportClass}`} ref={provided.innerRef} {...provided.droppableProps}>
            {blocks.map((b, idx) => (
              <Draggable key={b.id} draggableId={b.id} index={idx}>
                {(prov) => (
                  <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps} className="mb-4 last:mb-0">
                    <RenderBlock block={b} selected={selectedId === b.id} onSelect={() => setSelectedId(b.id)} />
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
            {!blocks.length && (
              <div className="text-center text-gray-500 py-16">
                Drag blocks here (or click items in the left sidebar to add)
              </div>
            )}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
}
