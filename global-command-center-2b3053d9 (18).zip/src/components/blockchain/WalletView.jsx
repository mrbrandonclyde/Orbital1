import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Import, Download, ArrowUpRight, ArrowDownRight, MoreHorizontal, Wallet, Activity, TrendingUp, Shield } from 'lucide-react';
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis } from 'recharts';

const getWalletTypeBadge = (type) => {
  switch (type) {
    case "VALIDATOR": return <Badge variant="outline" className="text-purple-400 border-purple-400/50">{type}</Badge>;
    case "TREASURY": return <Badge variant="outline" className="text-green-400 border-green-400/50">{type}</Badge>;
    default: return <Badge variant="secondary">{type}</Badge>;
  }
};

export default function WalletView({ data }) {
  const wallets = data?.wallets || [];
  const totalBalance = wallets.reduce((acc, w) => acc + w.balance, 0);
  const totalStaked = wallets.reduce((acc, w) => acc + w.staked_balance, 0);
  
  const balanceChartData = wallets.map(w => ({ name: w.wallet_name, balance: w.balance }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Wallet Management</h1>
        <div className="flex space-x-2">
          <Button className="orbital-button-secondary"><Import className="mr-2 h-4 w-4"/>Import Wallet</Button>
          <Button className="orbital-button-primary"><Plus className="mr-2 h-4 w-4"/>Create New Wallet</Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Portfolio Value</CardTitle>
            <TrendingUp className="h-5 w-5 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{totalBalance.toLocaleString('en-US', {maximumFractionDigits:2})} GCC</div>
            <p className="text-xs text-gray-400">+5.2% in last 24h</p>
          </CardContent>
        </Card>
        <Card className="glass-pane">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Staked Amount</CardTitle>
            <Shield className="h-5 w-5 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{totalStaked.toLocaleString('en-US')} GCC</div>
            <p className="text-xs text-gray-400">{wallets.filter(w => w.wallet_type === 'VALIDATOR').length} Validator(s)</p>
          </CardContent>
        </Card>
        <Card className="glass-pane md:col-span-1">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-400">Balance Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={balanceChartData} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="name" hide />
                <Bar dataKey="balance" fill="#8B5CF6" radius={[4, 4, 4, 4]} background={{ fill: '#ffffff10', radius: 4 }} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-pane">
        <CardHeader>
          <CardTitle>My Wallets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700 hover:bg-transparent">
                  <TableHead className="text-gray-400">Wallet</TableHead>
                  <TableHead className="text-gray-400">Address</TableHead>
                  <TableHead className="text-gray-400">Type</TableHead>
                  <TableHead className="text-gray-400 text-right">Balance</TableHead>
                  <TableHead className="text-gray-400 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {wallets.map(wallet => (
                  <TableRow key={wallet.id} className="border-gray-800 hover:bg-gray-800/30">
                    <TableCell className="font-semibold text-white">{wallet.wallet_name}</TableCell>
                    <TableCell className="font-mono text-xs text-purple-400">{wallet.wallet_address}</TableCell>
                    <TableCell>{getWalletTypeBadge(wallet.wallet_type)}</TableCell>
                    <TableCell className="text-white text-right font-medium">{wallet.balance.toLocaleString('en-US', {maximumFractionDigits:4})} GCC</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white"><ArrowUpRight className="h-4 w-4"/></Button>
                      <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white"><ArrowDownRight className="h-4 w-4"/></Button>
                      <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white"><MoreHorizontal className="h-4 w-44"/></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}