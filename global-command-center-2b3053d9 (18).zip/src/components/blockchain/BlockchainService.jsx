import React, { useState, useEffect } from 'react';
import { Block, Transaction, Wallet } from '@/api/entities';

// Blockchain Service - Core Backend Logic
export class BlockchainService {
  constructor() {
    this.difficulty = 4;
    this.miningReward = 10;
    this.blockTime = 3000; // 3 seconds
    this.maxTransactionsPerBlock = 1000;
  }

  // Generate Genesis Block
  static async createGenesisBlock() {
    const genesisBlock = {
      block_number: 0,
      block_hash: "0x0000000000000000000000000000000000000000000000000000000000000000",
      previous_hash: "0x0000000000000000000000000000000000000000000000000000000000000000",
      merkle_root: "0x0000000000000000000000000000000000000000000000000000000000000000",
      timestamp: new Date().toISOString(),
      nonce: 0,
      difficulty: 1,
      validator_address: "0x0000000000000000000000000000000000000000",
      transaction_count: 0,
      block_size: 0,
      gas_used: 0,
      gas_limit: 8000000,
      block_reward: 0,
      status: "FINALIZED",
      confirmations: 999999
    };

    try {
      return await Block.create(genesisBlock);
    } catch (error) {
      console.error("Genesis block creation failed:", error);
      return null;
    }
  }

  // Calculate Block Hash
  static calculateHash(blockData) {
    const data = `${blockData.block_number}${blockData.previous_hash}${blockData.merkle_root}${blockData.timestamp}${blockData.nonce}`;
    // Simple hash simulation - in production, use proper SHA-256
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return `0x${Math.abs(hash).toString(16).padStart(64, '0')}`;
  }

  // Mine New Block
  static async mineBlock(transactions = [], validatorAddress) {
    try {
      // Get the latest block
      const latestBlocks = await Block.list('-block_number', 1);
      const previousBlock = latestBlocks[0] || { block_number: -1, block_hash: "0x0" };

      const newBlockData = {
        block_number: previousBlock.block_number + 1,
        previous_hash: previousBlock.block_hash,
        merkle_root: this.calculateMerkleRoot(transactions),
        timestamp: new Date().toISOString(),
        nonce: 0,
        difficulty: 4,
        validator_address: validatorAddress,
        transaction_count: transactions.length,
        block_size: transactions.length * 250, // Approximate size
        gas_used: transactions.reduce((total, tx) => total + (tx.gas_used || 21000), 0),
        gas_limit: 8000000,
        block_reward: 10,
        status: "CONFIRMED",
        confirmations: 0
      };

      // Simple proof-of-work mining simulation
      while (true) {
        newBlockData.nonce++;
        const hash = this.calculateHash(newBlockData);
        
        if (hash.startsWith('0000')) { // Difficulty of 4 zeros
          newBlockData.block_hash = hash;
          break;
        }
        
        // Prevent infinite loop in demo
        if (newBlockData.nonce > 100000) {
          newBlockData.block_hash = this.calculateHash(newBlockData);
          break;
        }
      }

      return await Block.create(newBlockData);
    } catch (error) {
      console.error("Block mining failed:", error);
      return null;
    }
  }

  // Calculate Merkle Root
  static calculateMerkleRoot(transactions) {
    if (transactions.length === 0) {
      return "0x0000000000000000000000000000000000000000000000000000000000000000";
    }

    // Simple Merkle root simulation
    const txHashes = transactions.map(tx => tx.transaction_hash || `tx_${Date.now()}_${Math.random()}`);
    const combined = txHashes.join('');
    
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
      const char = combined.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    
    return `0x${Math.abs(hash).toString(16).padStart(64, '0')}`;
  }

  // Create Transaction
  static async createTransaction(fromAddress, toAddress, amount, transactionType = "TRANSFER") {
    try {
      const transactionData = {
        transaction_hash: `0x${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`,
        from_address: fromAddress,
        to_address: toAddress,
        amount: amount,
        gas_price: 20,
        gas_used: 21000,
        transaction_fee: 0.001,
        nonce: Date.now(),
        transaction_type: transactionType,
        status: "PENDING",
        confirmation_time: new Date().toISOString()
      };

      return await Transaction.create(transactionData);
    } catch (error) {
      console.error("Transaction creation failed:", error);
      return null;
    }
  }

  // Create Wallet
  static async createWallet(ownerUserId, walletName) {
    try {
      // Generate a simulated wallet address
      const walletAddress = `0x${Date.now().toString(16)}${Math.random().toString(16).slice(2, 42)}`;
      
      const walletData = {
        wallet_address: walletAddress,
        wallet_name: walletName,
        owner_id: ownerUserId,
        balance: 0,
        staked_balance: 0,
        pending_balance: 0,
        wallet_type: "STANDARD",
        public_key: `pub_${walletAddress}`,
        encrypted_private_key: `enc_${Date.now()}`, // In production, properly encrypt
        transaction_count: 0,
        last_activity: new Date().toISOString(),
        is_validator: false,
        validator_stake: 0,
        security_level: "BASIC"
      };

      return await Wallet.create(walletData);
    } catch (error) {
      console.error("Wallet creation failed:", error);
      return null;
    }
  }

  // Validate Transaction
  static async validateTransaction(transaction) {
    try {
      // Get sender's wallet
      const senderWallets = await Wallet.filter({ wallet_address: transaction.from_address });
      if (senderWallets.length === 0) {
        return { valid: false, reason: "Sender wallet not found" };
      }

      const senderWallet = senderWallets[0];
      
      // Check if sender has sufficient balance
      if (senderWallet.balance < transaction.amount + transaction.transaction_fee) {
        return { valid: false, reason: "Insufficient balance" };
      }

      return { valid: true, reason: "Transaction valid" };
    } catch (error) {
      console.error("Transaction validation failed:", error);
      return { valid: false, reason: "Validation error" };
    }
  }

  // Process Transactions (update wallet balances)
  static async processTransactions(transactions) {
    for (const tx of transactions) {
      try {
        // Update sender balance
        const senderWallets = await Wallet.filter({ wallet_address: tx.from_address });
        if (senderWallets.length > 0) {
          const senderWallet = senderWallets[0];
          await Wallet.update(senderWallet.id, {
            balance: senderWallet.balance - tx.amount - tx.transaction_fee,
            transaction_count: senderWallet.transaction_count + 1,
            last_activity: new Date().toISOString()
          });
        }

        // Update recipient balance
        const recipientWallets = await Wallet.filter({ wallet_address: tx.to_address });
        if (recipientWallets.length > 0) {
          const recipientWallet = recipientWallets[0];
          await Wallet.update(recipientWallet.id, {
            balance: recipientWallet.balance + tx.amount,
            last_activity: new Date().toISOString()
          });
        }

        // Update transaction status
        await Transaction.update(tx.id, {
          status: "CONFIRMED",
          confirmation_time: new Date().toISOString()
        });

      } catch (error) {
        console.error(`Failed to process transaction ${tx.transaction_hash}:`, error);
      }
    }
  }

  // Initialize blockchain if empty
  static async initializeBlockchain() {
    try {
      const existingBlocks = await Block.list('-block_number', 1);
      
      if (existingBlocks.length === 0) {
        console.log("Initializing blockchain with genesis block...");
        await this.createGenesisBlock();
        return true;
      }
      
      return false;
    } catch (error) {
      console.error("Blockchain initialization failed:", error);
      return false;
    }
  }
}

// Blockchain Mining Service Component
export default function BlockchainMiningService() {
  const [isMining, setIsMining] = useState(false);
  const [currentBlockHeight, setCurrentBlockHeight] = useState(0);

  useEffect(() => {
    // Initialize blockchain on component mount
    BlockchainService.initializeBlockchain();
    
    // Set up automatic mining every 30 seconds (for demo)
    const miningInterval = setInterval(async () => {
      if (!isMining) {
        setIsMining(true);
        
        // Get pending transactions
        const pendingTxs = await Transaction.filter({ status: "PENDING" }, '-created_date', 100);
        
        // Mine new block
        const newBlock = await BlockchainService.mineBlock(
          pendingTxs.slice(0, 10), // Max 10 transactions per block for demo
          "0x0000000000000000000000000000000000000001" // Demo validator address
        );
        
        if (newBlock) {
          // Process transactions
          await BlockchainService.processTransactions(pendingTxs.slice(0, 10));
          setCurrentBlockHeight(newBlock.block_number);
        }
        
        setIsMining(false);
      }
    }, 30000); // Every 30 seconds

    return () => clearInterval(miningInterval);
  }, [isMining]);

  // This component doesn't render anything visible
  return null;
}