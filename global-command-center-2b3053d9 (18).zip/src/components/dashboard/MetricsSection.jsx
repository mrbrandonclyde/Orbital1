import React from 'react';
import { TrendingUp, TrendingDown, Minus, BarChart3 } from 'lucide-react';
import MetricsCard from './MetricsCard';

export default function MetricsSection({ sectors, metrics }) {
  const getMetricIcon = (trend) => {
    switch (trend) {
      case 'UP': return TrendingUp;
      case 'DOWN': return TrendingDown;
      default: return Minus;
    }
  };

  const getMetricColor = (status) => {
    switch (status) {
      case 'STRONG': return 'text-green-400 border-green-500/30 bg-green-500/10';
      case 'EXPANDING': return 'text-blue-400 border-blue-500/30 bg-blue-500/10';
      case 'STABLE': return 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10';
      case 'DECLINING': return 'text-orange-400 border-orange-500/30 bg-orange-500/10';
      case 'CRITICAL': return 'text-red-400 border-red-500/30 bg-red-500/10';
      default: return 'text-gray-400 border-gray-500/30 bg-gray-500/10';
    }
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center space-x-3 mb-6">
        <BarChart3 className="w-6 h-6 text-blue-400" />
        <h2 className="text-xl font-semibold text-white">Sector Intelligence</h2>
        <div className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
          LIVE
        </div>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {metrics?.length > 0 ? (
          metrics.slice(0, 8).map((metric, index) => {
            const sector = sectors?.find(s => s.id === metric.sector_id);
            const Icon = getMetricIcon(metric.trend_direction);
            const colorClass = getMetricColor(metric.status);

            return (
              <div 
                key={metric.id || index}
                className={`border rounded-lg p-4 transition-all hover:scale-105 ${colorClass}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4" />
                    <span className="font-medium">{metric.metric_name}</span>
                  </div>
                  <span className="text-lg font-bold">{metric.display_value}</span>
                </div>
                
                <div className="flex items-center justify-between text-xs opacity-75">
                  <span>{sector?.sector_name || 'Unknown Sector'}</span>
                  <span className="uppercase">{metric.status}</span>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8">
            <BarChart3 className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No metrics data available</p>
            <p className="text-gray-500 text-sm">Intelligence feeds initializing...</p>
          </div>
        )}
      </div>

      {/* Metrics Summary */}
      <div className="mt-6 pt-4 border-t border-gray-700">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-green-400">
              {metrics?.filter(m => m.status === 'STRONG').length || 0}
            </p>
            <p className="text-xs text-gray-400">Strong</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-yellow-400">
              {metrics?.filter(m => m.status === 'STABLE').length || 0}
            </p>
            <p className="text-xs text-gray-400">Stable</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-red-400">
              {metrics?.filter(m => m.status === 'CRITICAL').length || 0}
            </p>
            <p className="text-xs text-gray-400">Critical</p>
          </div>
        </div>
      </div>
    </div>
  );
}