import React from 'react';
import { AlertTriangle } from "lucide-react";

export default function AlertCard({ alert }) {
  const priorityStyles = {
    URGENT: { text: 'text-red-400' },
    HIGH: { text: 'text-yellow-400' },
    MEDIUM: { text: 'text-indigo-400' },
    LOW: { text: 'text-gray-500' },
  };
  const styles = priorityStyles[alert.priority] || priorityStyles.HIGH;

  return (
    <div className="bg-[#0C0F19]/60 p-4 rounded-lg flex items-center space-x-4 transition-all duration-300 hover:bg-[#0C0F19] border border-transparent hover:border-orbital-primary/30">
      <AlertTriangle className={`w-6 h-6 flex-shrink-0 ${styles.text}`} />
      <div className="flex-1">
        <h4 className="font-bold text-white">{alert.title}</h4>
        <p className="text-sm text-[color:var(--orbital-text-secondary)] line-clamp-1">{alert.description}</p>
      </div>
      <span className={`ml-auto text-xs font-semibold px-2 py-1 rounded-md bg-black/30 ${styles.text}`}>{alert.priority}</span>
    </div>
  );
}