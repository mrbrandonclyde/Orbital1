import React, { useState } from 'react';
import { useLiveData } from '../lib/useLiveData';
import RegionSelector from '../common/RegionSelector';
import { TrendingUp, TrendingDown, Shield, BarChart, Activity, Zap, Truck } from 'lucide-react';

const MetricCard = ({ title, icon: Icon, data, loadingText, renderData, region, onRegionChange, sectorId }) => {
  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 orbital-glow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Icon className="w-6 h-6 text-indigo-400" />
          <h3 className="text-lg font-semibold text-white">{title}</h3>
        </div>
        {data ? (
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        ) : (
          <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
        )}
      </div>

      <RegionSelector
        sector={sectorId}
        selectedRegion={region}
        onRegionChange={onRegionChange}
        className="mb-4"
      />
      
      <div className="h-16">
        {data ? renderData(data) : (
          <div className="space-y-1">
            <p className="text-gray-500 text-sm">{loadingText}</p>
            <p className="text-xs text-gray-600">Live data feed will activate when available</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default function LiveMetrics() {
  const [financeRegion, setFinanceRegion] = useState('US-CA');
  const [defenseRegion, setDefenseRegion] = useState('US-TX');
  const [healthcareRegion, setHealthcareRegion] = useState('US-NY');
  const [transportRegion, setTransportRegion] = useState('global');
  const [energyRegion, setEnergyRegion] = useState('US-TX');

  const financeUpdate = useLiveData('finance', financeRegion, 'finance:update');
  const defenseAlert = useLiveData('defense', defenseRegion, 'defense:alert');
  const healthUpdate = useLiveData('healthcare', healthcareRegion, 'healthcare:update');
  const transportUpdate = useLiveData('transport', transportRegion, 'transport:update');
  const energyUpdate = useLiveData('energy', energyRegion, 'energy:update');

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-semibold text-white mb-6">Live Regional Data Feeds</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="Finance"
          sectorId="finance"
          icon={BarChart}
          data={financeUpdate}
          region={financeRegion}
          onRegionChange={setFinanceRegion}
          loadingText="Awaiting market data..."
          renderData={(d) => (
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{d.symbol}: ${parseFloat(d.price).toFixed(2)}</p>
              <p className={`flex items-center text-sm font-semibold ${parseFloat(d.change) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {parseFloat(d.change) >= 0 ? <TrendingUp size={16} className="mr-1"/> : <TrendingDown size={16} className="mr-1"/>}
                {d.change}
              </p>
            </div>
          )}
        />
        <MetricCard
          title="Defense"
          sectorId="defense"
          icon={Shield}
          data={defenseAlert}
          region={defenseRegion}
          onRegionChange={setDefenseRegion}
          loadingText="Monitoring threat channels..."
          renderData={(d) => (
            <div className="space-y-1">
              <p className={`text-xl font-bold ${d.severity === 'CRITICAL' ? 'text-red-500' : 'text-yellow-400'}`}>{d.message}</p>
              <p className="text-sm text-gray-400">Source: OSINT Feed</p>
            </div>
          )}
        />
        <MetricCard
          title="Healthcare"
          sectorId="healthcare"
          icon={Activity}
          data={healthUpdate}
          region={healthcareRegion}
          onRegionChange={setHealthcareRegion}
          loadingText="Listening to WHO/CDC feeds..."
          renderData={(d) => (
            <div className="space-y-1">
              <p className="text-xl font-bold text-blue-400">{d.region} Outbreak</p>
              <p className="text-sm text-gray-400">Status: {d.status}</p>
            </div>
          )}
        />
        <MetricCard
          title="Transport"
          sectorId="transport"
          icon={Truck}
          data={transportUpdate}
          region={transportRegion}
          onRegionChange={setTransportRegion}
          loadingText="Tracking logistics network..."
          renderData={(d) => (
            <div className="space-y-1">
              <p className="text-xl font-bold text-purple-400">Port: {d.port}</p>
              <p className="text-sm text-gray-400">Congestion: {d.congestion_level}%</p>
            </div>
          )}
        />
        <MetricCard
          title="Energy"
          sectorId="energy"
          icon={Zap}
          data={energyUpdate}
          region={energyRegion}
          onRegionChange={setEnergyRegion}
          loadingText="Monitoring power grids..."
          renderData={(d) => (
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{d.grid_id}: {parseFloat(d.load_gw).toFixed(2)} GW</p>
              <p className={`flex items-center text-sm font-semibold ${d.status === 'STABLE' ? 'text-green-400' : 'text-orange-400'}`}>
                Status: {d.status}
              </p>
            </div>
          )}
        />
      </div>
    </div>
  );
}