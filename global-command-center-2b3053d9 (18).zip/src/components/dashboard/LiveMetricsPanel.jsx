import React, { useState, useEffect } from 'react';
import { useRealtimeMetrics, useRealtimeAlerts, useRealtimeThreats, useRealtimeSystem } from '../hooks/useRealtime';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts';
import { Activity, AlertTriangle, Shield, Zap, Users, Database, TrendingUp, Clock } from 'lucide-react';

export default function LiveMetricsPanel() {
  const alertsData = useRealtimeAlerts();
  const metricsData = useRealtimeMetrics();
  const threatsData = useRealtimeThreats();
  const systemData = useRealtimeSystem();

  // Historical data for charts
  const [historicalData, setHistoricalData] = useState({
    systemLoad: [],
    threatLevel: [],
    alertsCount: []
  });

  // Update historical data when new data arrives
  useEffect(() => {
    if (metricsData.data) {
      setHistoricalData(prev => {
        const timestamp = Date.now();
        const newEntry = {
          timestamp,
          systemLoad: metricsData.data.systemLoad,
          threatLevel: metricsData.data.threatLevel,
          alertsCount: alertsData.data?.totalActive || 0
        };

        return {
          systemLoad: [...prev.systemLoad.slice(-19), newEntry],
          threatLevel: [...prev.threatLevel.slice(-19), newEntry],
          alertsCount: [...prev.alertsCount.slice(-19), newEntry]
        };
      });
    }
  }, [metricsData.data, alertsData.data]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'OPERATIONAL': return 'text-green-400';
      case 'DEGRADED': return 'text-yellow-400';
      case 'CRITICAL': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getThreatLevelColor = (level) => {
    if (level >= 80) return 'text-red-400';
    if (level >= 60) return 'text-orange-400';
    if (level >= 40) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {/* System Status */}
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-white">
            <span className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-cyan-400" />
              System Status
            </span>
            {systemData.isConnected && (
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Status</span>
              <span className={`font-semibold ${getStatusColor(metricsData.data?.operationalStatus)}`}>
                {metricsData.data?.operationalStatus || 'UNKNOWN'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Load</span>
              <span className="text-white font-semibold">
                {metricsData.data?.systemLoad?.toFixed(1) || '0.0'}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Health</span>
              <span className="text-green-400 font-semibold">
                {systemData.data?.systemHealth?.toFixed(1) || '0.0'}%
              </span>
            </div>
            {historicalData.systemLoad.length > 1 && (
              <div className="h-16 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={historicalData.systemLoad}>
                    <Line 
                      type="monotone" 
                      dataKey="systemLoad" 
                      stroke="#06B6D4" 
                      strokeWidth={2}
                      dot={false}
                    />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleTimeString()}
                      formatter={(value) => [`${value.toFixed(1)}%`, 'System Load']}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-white">
            <span className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-400" />
              Active Alerts
            </span>
            {alertsData.data?.newAlerts > 0 && (
              <div className="bg-red-500/20 text-red-400 text-xs px-2 py-1 rounded-full">
                +{alertsData.data.newAlerts}
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Total Active</span>
              <span className="text-white font-semibold text-xl">
                {alertsData.data?.totalActive || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Critical</span>
              <span className="text-red-400 font-semibold">
                {alertsData.data?.criticalCount || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">New (5min)</span>
              <span className="text-orange-400 font-semibold">
                {alertsData.data?.newAlerts || 0}
              </span>
            </div>
            {historicalData.alertsCount.length > 1 && (
              <div className="h-16 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={historicalData.alertsCount}>
                    <Line 
                      type="monotone" 
                      dataKey="alertsCount" 
                      stroke="#F59E0B" 
                      strokeWidth={2}
                      dot={false}
                    />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleTimeString()}
                      formatter={(value) => [`${value}`, 'Active Alerts']}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Threat Level */}
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-white">
            <span className="flex items-center">
              <Shield className="w-5 h-5 mr-2 text-red-400" />
              Threat Level
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Global Index</span>
              <span className={`font-semibold text-xl ${getThreatLevelColor(threatsData.data?.globalThreatIndex)}`}>
                {threatsData.data?.globalThreatIndex?.toFixed(0) || 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">New Threats</span>
              <span className="text-red-400 font-semibold">
                {threatsData.data?.newThreats || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Contained</span>
              <span className="text-green-400 font-semibold">
                {threatsData.data?.containedThreats || 0}
              </span>
            </div>
            {historicalData.threatLevel.length > 1 && (
              <div className="h-16 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={historicalData.threatLevel}>
                    <Line 
                      type="monotone" 
                      dataKey="threatLevel" 
                      stroke="#EF4444" 
                      strokeWidth={2}
                      dot={false}
                    />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleTimeString()}
                      formatter={(value) => [`${value.toFixed(1)}%`, 'Threat Level']}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* System Performance */}
      <Card className="bg-[#0A0D18]/50 border-gray-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-white">
            <span className="flex items-center">
              <Zap className="w-5 h-5 mr-2 text-purple-400" />
              Performance
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Active Users</span>
              <span className="text-white font-semibold">
                {systemData.data?.activeUsers || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Data Rate</span>
              <span className="text-purple-400 font-semibold">
                {systemData.data?.dataProcessingRate ? 
                  `${Math.round(systemData.data.dataProcessingRate / 1000)}k/s` : 
                  '0k/s'
                }
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Last Update</span>
              <span className="text-gray-300 text-xs">
                {systemData.lastUpdate ? 
                  systemData.lastUpdate.toLocaleTimeString() : 
                  'Never'
                }
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}