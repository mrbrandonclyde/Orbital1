import React from 'react';
import { AlertTriangle, Shield, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AlertsSection({ alerts }) {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'URGENT': return 'text-red-400 bg-red-500/20 border-red-500/50';
      case 'HIGH': return 'text-orange-400 bg-orange-500/20 border-orange-500/50';
      case 'MEDIUM': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/50';
      case 'LOW': return 'text-blue-400 bg-blue-500/20 border-blue-500/50';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/50';
    }
  };

  const getPriorityIcon = (priority) => {
    return priority === 'URGENT' ? AlertTriangle : Shield;
  };

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <AlertTriangle className="w-6 h-6 text-red-400" />
          <h2 className="text-xl font-semibold text-white">Active Alerts</h2>
          <div className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded">
            {alerts?.length || 0} ACTIVE
          </div>
        </div>
        
        <Link 
          to={createPageUrl('Alerts')}
          className="text-blue-400 hover:text-blue-300 text-sm flex items-center space-x-1"
        >
          <span>View All</span>
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {alerts?.length > 0 ? (
          alerts.slice(0, 6).map((alert, index) => {
            const Icon = getPriorityIcon(alert.priority);
            const colorClass = getPriorityColor(alert.priority);

            return (
              <div 
                key={alert.id || index}
                className={`border rounded-lg p-4 transition-all hover:scale-105 cursor-pointer ${colorClass}`}
              >
                <div className="flex items-start space-x-3">
                  <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium truncate">{alert.title}</h4>
                    <p className="text-sm opacity-75 mt-1 line-clamp-2">
                      {alert.description}
                    </p>
                    <div className="flex items-center justify-between mt-3 text-xs">
                      <span className="opacity-60">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {new Date(alert.created_date).toLocaleTimeString()}
                      </span>
                      <span className="px-2 py-1 bg-white/10 rounded uppercase">
                        {alert.priority}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8">
            <Shield className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No active alerts</p>
            <p className="text-gray-500 text-sm">All systems secure</p>
          </div>
        )}
      </div>

      {/* Alert Summary */}
      <div className="mt-6 pt-4 border-t border-gray-700">
        <div className="grid grid-cols-4 gap-2 text-center">
          <div>
            <p className="text-lg font-bold text-red-400">
              {alerts?.filter(a => a.priority === 'URGENT').length || 0}
            </p>
            <p className="text-xs text-gray-400">Urgent</p>
          </div>
          <div>
            <p className="text-lg font-bold text-orange-400">
              {alerts?.filter(a => a.priority === 'HIGH').length || 0}
            </p>
            <p className="text-xs text-gray-400">High</p>
          </div>
          <div>
            <p className="text-lg font-bold text-yellow-400">
              {alerts?.filter(a => a.priority === 'MEDIUM').length || 0}
            </p>
            <p className="text-xs text-gray-400">Medium</p>
          </div>
          <div>
            <p className="text-lg font-bold text-blue-400">
              {alerts?.filter(a => a.priority === 'LOW').length || 0}
            </p>
            <p className="text-xs text-gray-400">Low</p>
          </div>
        </div>
      </div>
    </div>
  );
}