import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { User } from "@/api/entities";
import { CheckCircle2, Rocket, Zap, Shield, Users, MessagesSquare, Bot, Store, Database, Terminal } from "lucide-react";

export default function ActivationEngine() {
  const [logs, setLogs] = React.useState([]);
  const [currentUser, setCurrentUser] = React.useState(null);
  const [feedback, setFeedback] = React.useState("");
  const [messageUser, setMessageUser] = React.useState("User1");
  const [messageContent, setMessageContent] = React.useState("");
  const [prefInput, setPrefInput] = React.useState("Content 1, Content 3");
  const [exportedData, setExportedData] = React.useState("");

  React.useEffect(() => {
    (async () => {
      try { setCurrentUser(await User.me()); } catch {}
    })();
  }, []);

  const append = (msg) => setLogs((l) => [...l, `${new Date().toLocaleTimeString()} — ${msg}`]);

  // Provided functions/classes translated to safe client-side demo implementations:

  // The Quantum Activation System — it links your world with the external system
  function loadSystem(systemName) {
    return {
      name: systemName,
      activate: () => append(`System "${systemName}" activated (demo layer).`)
    };
  }
  function activateSystem(systemName) {
    const system = loadSystem(systemName);
    system.activate();
    append(`${systemName} has been activated in the quantum layer.`);
  }

  // User Data Synchronization — real-time data flow across realities
  function fetchExternalData(id) {
    // demo external shape
    return { id, tier: "EXECUTIVE", tokens: 777, preferences: ["Content 1", "Content 3"] };
  }
  function syncUserData(userData) {
    const externalData = fetchExternalData(userData.id || "guest");
    const synced = { ...userData, external: externalData };
    append("User data synchronized with external reality.");
    return synced;
  }

  // Full system initialization with quantum leap
  async function fullSystemInitialization() {
    const systemsToActivate = ["Guardian Codex", "AI-Powered Freedom System", "Marketplace"];
    systemsToActivate.forEach((s) => activateSystem(s));
    const baseUser = { id: currentUser?.id || "guest", name: currentUser?.full_name || "Guest" };
    const synced = syncUserData(baseUser);
    append(`All systems are activated and fully synchronized for ${synced.name}!`);
  }

  // Decentralized Governance with DAO
  class DAO {
    constructor(teamName) {
      this.teamName = teamName;
      this.members = [];
      this.votes = [];
    }
    addMember(member) { this.members.push(member); }
    collectVote(user, decision) { if (this.members.includes(user)) this.votes.push({ user, decision }); }
    countVotes() {
      const yesVotes = this.votes.filter(v => v.decision === "yes").length;
      const noVotes = this.votes.filter(v => v.decision === "no").length;
      return yesVotes > noVotes ? "Approved" : "Rejected";
    }
  }

  // Free Speech and Expression (Open Platform)
  class OpenPlatform {
    constructor() { this.messages = []; }
    postMessage(user, message) { this.messages.push({ user, message }); append(`${user} posted: ${message}`); }
    listMessages() { return this.messages; }
  }

  // AI-Powered Personalization
  function aiRecommendation(userPreferences) {
    const recommendations = ["Content 1", "Content 2", "Content 3"];
    const set = (userPreferences || []).map(s => s.trim());
    const personalized = recommendations.filter(c => set.includes(c));
    return personalized.length ? personalized : ["No recommendations"];
  }

  // Privacy and Data Portability
  class UserData {
    constructor(userId, userName) { this.userId = userId; this.userName = userName; this.data = {}; }
    addData(key, value) { this.data[key] = value; }
    exportData() { return JSON.stringify(this); }
    deleteData() { this.data = {}; append("User data deleted successfully."); }
  }

  // Decentralized Marketplace
  class Marketplace {
    constructor() { this.items = []; }
    listItem(item, price) { this.items.push({ item, price }); append(`${item} listed for ${price}`); }
    searchItems() { return this.items; }
  }

  // Health + Feedback
  function systemHealthCheck() {
    const systemStatus = { servers: "Operational", database: "Running", api: "Active" };
    append(`System Health — servers: ${systemStatus.servers}, database: ${systemStatus.database}, api: ${systemStatus.api}`);
    return systemStatus;
  }
  function collectUserFeedback(user, fb) { append(`${user} gave feedback: ${fb}`); }

  // Rights Activation
  function activateRights(user) {
    user.rights = ["free-speech", "data-ownership", "autonomy"];
    append(`${user.name} has been granted rights: ${user.rights.join(", ")}`);
    return user;
  }

  // Demo handlers bound to UI
  const runDAO = () => {
    const governanceDAO = new DAO("Freedom Team");
    governanceDAO.addMember("Player1");
    governanceDAO.addMember("Player2");
    governanceDAO.collectVote("Player1", "yes");
    governanceDAO.collectVote("Player2", "no");
    const decision = governanceDAO.countVotes();
    append(`Governance Decision: ${decision}`);
  };

  const platformRef = React.useRef(new OpenPlatform());
  const marketRef = React.useRef(new Marketplace());

  const doPost = () => {
    platformRef.current.postMessage(messageUser || "User", messageContent || "Hello freedom!");
  };

  const doRecommend = () => {
    const prefs = prefInput.split(",").map(s => s.trim()).filter(Boolean);
    const recs = aiRecommendation(prefs);
    append(`AI Recommendations: ${recs.join(", ")}`);
  };

  const doUserData = () => {
    const u = new UserData(currentUser?.id || 1, currentUser?.full_name || "UserOne");
    u.addData("age", 30); u.addData("location", "USA");
    const exported = u.exportData();
    setExportedData(exported);
    append("Exported user data to JSON.");
    u.deleteData();
  };

  const doMarketplace = () => {
    marketRef.current.listItem("Parcel 1", 1000);
    marketRef.current.listItem("Parcel 2", 1500);
    const items = marketRef.current.searchItems();
    append(`Marketplace Items: ${items.map(i => `${i.item}($${i.price})`).join(", ")}`);
  };

  const doHealthFeedback = () => {
    systemHealthCheck();
    collectUserFeedback(currentUser?.full_name || "User", feedback || "Great system! Very fast.");
  };

  const doActivateRights = () => {
    const user = { name: currentUser?.full_name || "UserOne" };
    activateRights(user);
  };

  const runAll = async () => {
    append("— Global Activation: begin —");
    await fullSystemInitialization();
    runDAO();
    doPost();
    doRecommend();
    doUserData();
    doMarketplace();
    doHealthFeedback();
    doActivateRights();
    append("— Global Activation: complete —");
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Rocket className="w-5 h-5 text-cyan-400" />
            Global Activation Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button onClick={runAll} className="bg-indigo-600 hover:bg-indigo-700">
              <Zap className="w-4 h-4 mr-2" /> Run ALL
            </Button>
            <Button variant="outline" onClick={() => activateSystem("Guardian Codex")} className="border-gray-700 text-gray-200 hover:text-white">
              <Shield className="w-4 h-4 mr-2" /> Activate Codex
            </Button>
            <Button variant="outline" onClick={runDAO} className="border-gray-700 text-gray-200 hover:text-white">
              <Users className="w-4 h-4 mr-2" /> Run DAO Vote
            </Button>
            <Button variant="outline" onClick={doMarketplace} className="border-gray-700 text-gray-200 hover:text-white">
              <Store className="w-4 h-4 mr-2" /> Marketplace Demo
            </Button>
            <Button variant="outline" onClick={doHealthFeedback} className="border-gray-700 text-gray-200 hover:text-white">
              <Database className="w-4 h-4 mr-2" /> Health + Feedback
            </Button>
            <Button variant="outline" onClick={doActivateRights} className="border-gray-700 text-gray-200 hover:text-white">
              <CheckCircle2 className="w-4 h-4 mr-2" /> Activate Rights
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="text-xs text-gray-400">Post Message (Open Platform)</div>
              <div className="flex gap-2">
                <Input value={messageUser} onChange={(e) => setMessageUser(e.target.value)} placeholder="User" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                <Input value={messageContent} onChange={(e) => setMessageContent(e.target.value)} placeholder="Message" className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                <Button variant="outline" onClick={doPost} className="border-gray-700 text-gray-200 hover:text-white"><MessagesSquare className="w-4 h-4" /></Button>
              </div>
              <div className="text-xs text-gray-500">Use to demonstrate free speech feed.</div>
            </div>

            <div className="space-y-2">
              <div className="text-xs text-gray-400">AI Preferences (comma-separated)</div>
              <div className="flex gap-2">
                <Input value={prefInput} onChange={(e) => setPrefInput(e.target.value)} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
                <Button variant="outline" onClick={doRecommend} className="border-gray-700 text-gray-200 hover:text-white"><Bot className="w-4 h-4" /></Button>
              </div>
              <div className="text-xs text-gray-500">e.g. Content 1, Content 3</div>
            </div>

            <div className="space-y-2">
              <div className="text-xs text-gray-400">Feedback</div>
              <div className="flex gap-2">
                <Textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="Great system! Very fast." className="bg-[#0C0F19] border-gray-700 text-gray-100" />
              </div>
              <Button variant="outline" onClick={doHealthFeedback} className="border-gray-700 text-gray-200 hover:text-white w-full">
                Send Feedback + Health Check
              </Button>
            </div>
          </div>

          {exportedData && (
            <div className="text-xs text-gray-400">
              Exported User JSON:
              <pre className="mt-2 p-2 bg-black/30 border border-gray-800 rounded text-gray-200 overflow-auto">{exportedData}</pre>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" /> Activation Log
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-72 overflow-auto text-xs bg-black/30 border border-gray-800 rounded p-3 leading-relaxed text-gray-200">
            {logs.length ? logs.map((l, i) => <div key={i}>{l}</div>) : <div className="text-gray-500">No events yet. Run an action above.</div>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}