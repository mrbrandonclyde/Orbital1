import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { X, Save } from 'lucide-react';

export default function AgentConfigPanel({ agent, onClose, onUpdate }) {
  const [config, setConfig] = useState({
    name: agent.name,
    description: agent.description,
    status: agent.status,
    performance_metrics: agent.performance_metrics || {}
  });
  
  const [isUpdating, setIsUpdating] = useState(false);

  const handleSave = async () => {
    setIsUpdating(true);
    try {
      await onUpdate(config);
      onClose();
    } catch (error) {
      console.error('Failed to update agent:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-[#0A0D18] border-[#151823] text-white max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="orbital-gradient-text text-xl">
              Configure {agent.name}
            </DialogTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="config-name" className="text-gray-400">Agent Name</Label>
            <Input
              id="config-name"
              value={config.name}
              onChange={(e) => setConfig({ ...config, name: e.target.value })}
              className="bg-[#0C0F19] border-gray-600 text-white"
            />
          </div>

          <div>
            <Label htmlFor="config-description" className="text-gray-400">Description</Label>
            <Textarea
              id="config-description"
              value={config.description}
              onChange={(e) => setConfig({ ...config, description: e.target.value })}
              className="bg-[#0C0F19] border-gray-600 text-white h-24"
            />
          </div>

          <div>
            <Label htmlFor="config-status" className="text-gray-400">Status</Label>
            <Select
              value={config.status}
              onValueChange={(value) => setConfig({ ...config, status: value })}
            >
              <SelectTrigger className="bg-[#0C0F19] border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Idle">Idle</SelectItem>
                <SelectItem value="Training">Training</SelectItem>
                <SelectItem value="Offline">Offline</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="p-4 bg-gray-800/30 rounded-lg">
            <h4 className="text-sm font-semibold text-white mb-3">Performance Settings</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-400">Tasks Completed</Label>
                <Input
                  type="number"
                  value={config.performance_metrics.tasks_completed || 0}
                  onChange={(e) => setConfig({
                    ...config,
                    performance_metrics: {
                      ...config.performance_metrics,
                      tasks_completed: parseInt(e.target.value) || 0
                    }
                  })}
                  className="bg-[#0C0F19] border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-400">ROI Percentage</Label>
                <Input
                  type="number"
                  value={config.performance_metrics.roi_percentage || 0}
                  onChange={(e) => setConfig({
                    ...config,
                    performance_metrics: {
                      ...config.performance_metrics,
                      roi_percentage: parseFloat(e.target.value) || 0
                    }
                  })}
                  className="bg-[#0C0F19] border-gray-600 text-white"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={isUpdating}
              className="orbital-button-primary"
            >
              <Save className="w-4 h-4 mr-2" />
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}