import React from "react";

export default function GlobalHud() {
  return (
    <div className="absolute top-0 left-0 w-full flex justify-between p-4 text-white pointer-events-none z-10">
      {/* 🛰️ Global HUD Overlay */}
      <div className="bg-black bg-opacity-50 p-2 rounded">System Status: LIVE</div>
      <div className="bg-black bg-opacity-50 p-2 rounded">Operator: EXEC</div>
    </div>
  );
}