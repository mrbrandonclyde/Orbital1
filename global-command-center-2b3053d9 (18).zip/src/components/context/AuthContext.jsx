import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { User } from '@/api/entities';
import { Globe, Shield, AlertTriangle } from 'lucide-react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  const isAuthLoadingRef = useRef(true);

  // Keep ref in sync with state
  useEffect(() => {
    isAuthLoadingRef.current = isAuthLoading;
  }, [isAuthLoading]);

  const checkAuth = useCallback(async () => {
    try {
      setAuthError(null);
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.log('Auth check failed:', error.message);
      setUser(null);
      // Don't set authError here - this is expected when not logged in
    } finally {
      setIsAuthLoading(false);
    }
  }, []);

  useEffect(() => {
    // Add a timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      if (isAuthLoadingRef.current) {
        console.warn('Auth check timeout - forcing completion');
        setIsAuthLoading(false);
      }
    }, 10000); // 10 second timeout

    checkAuth();

    return () => clearTimeout(timeoutId);
  }, [checkAuth]);

  const login = useCallback(async () => {
    try {
      setAuthError(null);
      await User.login();
      // After login, check auth status
      setTimeout(() => {
        checkAuth();
      }, 1000);
    } catch (error) {
      console.error('Login failed:', error);
      setAuthError(error.message);
    }
  }, [checkAuth]);

  const logout = useCallback(async () => {
    try {
      await User.logout();
      setUser(null);
    } catch (error) {
      console.error('Logout failed:', error);
      // Force logout on client side even if server call fails
      setUser(null);
    }
  }, []);

  const value = {
    user,
    isAuthLoading,
    authError,
    login,
    logout,
    checkAuth,
  };

  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#020409]">
        <div className="text-center">
          <Globe className="w-16 h-16 text-cyan-400 mx-auto mb-4 animate-pulse" />
          <p className="text-white text-xl mb-4">Initializing Global Command Center...</p>
          <div className="text-sm text-gray-400">
            <p>Establishing secure connection...</p>
          </div>
        </div>
      </div>
    );
  }

  // If no user and there's an auth error, show login interface
  if (!user && authError) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#020409]">
        <div className="text-center max-w-md mx-auto p-8">
          <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-4">Authentication Error</h1>
          <p className="text-red-400 mb-6">{authError}</p>
          <button
            onClick={login}
            className="orbital-button-primary w-full"
          >
            Retry Login
          </button>
        </div>
      </div>
    );
  }

  // If no user but no error, show login interface
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#020409]">
        <div className="text-center max-w-md mx-auto p-8">
          <Shield className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
          <h1 className="text-3xl font-bold orbital-gradient-text mb-4">Global Command Center</h1>
          <p className="text-gray-400 mb-8">Secure access required for executive operations</p>
          <button
            onClick={login}
            className="orbital-button-primary w-full flex items-center justify-center space-x-2"
          >
            <Shield className="w-5 h-5" />
            <span>Executive Login</span>
          </button>
          <div className="mt-6 text-xs text-gray-500">
            <p>Clearance Level: CONFIDENTIAL and above</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === null) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};