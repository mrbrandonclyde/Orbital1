import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown, Copy, Check } from "lucide-react";

export default function GuardianCodexDownload({ content, filename = "Guardian_Alignment_Debug_Codex_Completed.txt" }) {
  const [copied, setCopied] = React.useState(false);

  const handleDownload = () => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (e) {
      console.error("Copy failed:", e);
    }
  };

  return (
    <Card className="bg-[#0A0D18]/60 border-gray-800">
      <CardHeader>
        <CardTitle className="text-white text-base">Guardian Codex — Download</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleDownload} className="bg-indigo-600 hover:bg-indigo-700">
            <FileDown className="w-4 h-4 mr-2" /> Download .txt
          </Button>
          <Button variant="outline" onClick={handleCopy} className="border-gray-700 text-gray-200 hover:text-white">
            {copied ? <Check className="w-4 h-4 mr-2 text-emerald-400" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? "Copied" : "Copy to Clipboard"}
          </Button>
          <div className="text-xs text-gray-400 self-center">
            {new Intl.NumberFormat().format(content.length)} characters
          </div>
        </div>
        <div className="max-h-[50vh] overflow-auto p-3 rounded-lg bg-black/30 text-sm leading-6 text-gray-200 border border-gray-800 whitespace-pre-wrap">
{content}
        </div>
      </CardContent>
    </Card>
  );
}