import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Server, CheckCircle, AlertTriangle } from "lucide-react";
import SpeedBackend from "@/components/lib/SpeedBackend";

export default function SpeedBackendScaffold({ open, onOpenChange }) {
  const [health, setHealth] = React.useState({ ok: false, latency: null });
  const [root, setRoot] = React.useState(null);

  React.useEffect(() => {
    if (!open) return;
    let mounted = true;
    (async () => {
      try {
        const ping = await SpeedBackend.health.ping();
        if (mounted) setHealth({ ok: true, latency: ping.latency });
      } catch {
        if (mounted) setHealth({ ok: false, latency: null });
      }
      try {
        const status = await SpeedBackend.root.status();
        if (mounted) setRoot(status);
      } catch {
        if (mounted) setRoot(null);
      }
    })();
    return () => { mounted = false; };
  }, [open]);

  const endpoints = [
    { path: "/health", desc: "Backend health check" },
    { path: "/analytics/funnel", desc: "Funnel analytics list" },
    { path: "/analytics/revenue", desc: "Revenue report for active funnel period" },
    { path: "/users/", desc: "Users (FastAPI demo)" },
    { path: "/queue-task/?name=demo", desc: "Enqueue a background task" },
    { path: "/blockchain/balance/", desc: "Blockchain balance (demo)" }
  ];

  const copyBase = () => {
    try {
      navigator.clipboard.writeText(SpeedBackend.baseUrl);
    } catch (_) {}
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-[#0A0D18] border border-gray-800 text-gray-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            Speed Backend Scaffold
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Quick reference for available demo endpoints and current backend status.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between">
          <div className="text-sm">
            <div className="text-gray-400">Base URL</div>
            <div className="font-mono text-xs text-gray-300">{SpeedBackend.baseUrl}</div>
          </div>
          <Button variant="outline" size="sm" onClick={copyBase} className="border-gray-700 text-gray-300">
            <Copy className="w-4 h-4 mr-2" /> Copy
          </Button>
        </div>

        <div className="flex items-center gap-2 text-sm">
          {health.ok ? (
            <Badge className="bg-green-500/20 text-green-400 flex items-center gap-1">
              <CheckCircle className="w-3 h-3" /> Online {health.latency != null ? `• ${health.latency}ms` : ""}
            </Badge>
          ) : (
            <Badge className="bg-red-500/20 text-red-400 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Offline
            </Badge>
          )}
        </div>

        <div className="space-y-2">
          <div className="text-xs text-gray-400">Endpoints</div>
          <ul className="space-y-1">
            {endpoints.map((e) => (
              <li key={e.path} className="flex items-center justify-between rounded-md border border-gray-800 px-3 py-2 bg-[#0C0F19]">
                <div>
                  <div className="font-mono text-xs text-cyan-300">{e.path}</div>
                  <div className="text-xs text-gray-400">{e.desc}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="text-xs text-gray-500">
          Root status sample: <span className="text-gray-300">{root ? "Loaded" : "Unavailable"}</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}