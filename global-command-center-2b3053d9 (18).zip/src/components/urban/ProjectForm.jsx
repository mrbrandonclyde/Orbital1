import React, { useState } from "react";
import { CityProject } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ProjectForm({ onSuccess, onCancel }) {
  const [form, setForm] = useState({
    project_name: "",
    description: "",
    status: "PLANNING",
    center_lat: "",
    center_lng: "",
    population_target: "",
    budget_usd: "",
    sustainability_goals: ""
  });

  const update = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      center_lat: form.center_lat ? Number(form.center_lat) : undefined,
      center_lng: form.center_lng ? Number(form.center_lng) : undefined,
      population_target: form.population_target ? Number(form.population_target) : undefined,
      budget_usd: form.budget_usd ? Number(form.budget_usd) : undefined,
      sustainability_goals: form.sustainability_goals
        ? form.sustainability_goals.split(",").map(s => s.trim()).filter(Boolean)
        : []
    };
    await CityProject.create(payload);
    onSuccess?.();
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <Input placeholder="Project name" value={form.project_name} onChange={e => update("project_name", e.target.value)} />
      <Textarea placeholder="Description" value={form.description} onChange={e => update("description", e.target.value)} />
      <Select value={form.status} onValueChange={v => update("status", v)}>
        <SelectTrigger className="bg-gray-800/50 border-gray-600"><SelectValue placeholder="Status" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="PLANNING">Planning</SelectItem>
          <SelectItem value="ACTIVE">Active</SelectItem>
          <SelectItem value="COMPLETED">Completed</SelectItem>
        </SelectContent>
      </Select>
      <div className="grid grid-cols-2 gap-2">
        <Input placeholder="Center lat" value={form.center_lat} onChange={e => update("center_lat", e.target.value)} />
        <Input placeholder="Center lng" value={form.center_lng} onChange={e => update("center_lng", e.target.value)} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Input placeholder="Population target" value={form.population_target} onChange={e => update("population_target", e.target.value)} />
        <Input placeholder="Budget (USD)" value={form.budget_usd} onChange={e => update("budget_usd", e.target.value)} />
      </div>
      <Input placeholder="Sustainability goals (comma-separated)" value={form.sustainability_goals} onChange={e => update("sustainability_goals", e.target.value)} />
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">Create Project</Button>
      </div>
    </form>
  );
}