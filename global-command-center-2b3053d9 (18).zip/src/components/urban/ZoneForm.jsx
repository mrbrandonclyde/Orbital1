import React, { useState } from "react";
import { UrbanZone } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ZoneForm({ projectId, onSuccess, onCancel }) {
  const [form, setForm] = useState({
    zone_name: "",
    zone_type: "Residential",
    density: "Medium",
    area_hectares: "",
    center_lat: "",
    center_lng: "",
    notes: ""
  });

  const update = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    const payload = {
      project_id: projectId,
      zone_name: form.zone_name,
      zone_type: form.zone_type,
      density: form.density,
      area_hectares: form.area_hectares ? Number(form.area_hectares) : undefined,
      center_lat: form.center_lat ? Number(form.center_lat) : undefined,
      center_lng: form.center_lng ? Number(form.center_lng) : undefined,
      notes: form.notes
    };
    await UrbanZone.create(payload);
    onSuccess?.();
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <Input placeholder="Zone name" value={form.zone_name} onChange={e => update("zone_name", e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <Select value={form.zone_type} onValueChange={v => update("zone_type", v)}>
          <SelectTrigger className="bg-gray-800/50 border-gray-600"><SelectValue placeholder="Zone type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Residential">Residential</SelectItem>
            <SelectItem value="Commercial">Commercial</SelectItem>
            <SelectItem value="Industrial">Industrial</SelectItem>
            <SelectItem value="MixedUse">Mixed-use</SelectItem>
            <SelectItem value="Green">Green</SelectItem>
            <SelectItem value="Civic">Civic</SelectItem>
          </SelectContent>
        </Select>
        <Select value={form.density} onValueChange={v => update("density", v)}>
          <SelectTrigger className="bg-gray-800/50 border-gray-600"><SelectValue placeholder="Density" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Low">Low</SelectItem>
            <SelectItem value="Medium">Medium</SelectItem>
            <SelectItem value="High">High</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Input placeholder="Area (hectares)" value={form.area_hectares} onChange={e => update("area_hectares", e.target.value)} />
        <Input placeholder="Notes (optional)" value={form.notes} onChange={e => update("notes", e.target.value)} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Input placeholder="Center lat (optional)" value={form.center_lat} onChange={e => update("center_lat", e.target.value)} />
        <Input placeholder="Center lng (optional)" value={form.center_lng} onChange={e => update("center_lng", e.target.value)} />
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">Add Zone</Button>
      </div>
    </form>
  );
}