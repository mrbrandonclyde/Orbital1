import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, Settings, Users, Activity } from "lucide-react";

const items = [
  { name: "Admin Dashboard", icon: LayoutDashboard, page: "AdminPhase1Dashboard" },
  { name: "Users", icon: Users, page: "Personnel" },
  { name: "System Status", icon: Activity, page: "SystemStatus" },
  { name: "Settings", icon: Settings, page: "FunnelSettings" },
];

export default function Admin_SidebarFrame() {
  return (
    <div className="w-full overflow-x-auto rounded-xl border border-gray-800 bg-[#0A0D18]/60 p-2 mb-4">
      <div className="flex min-w-max gap-1">
        {items.map((it) => (
          <Link
            key={it.name}
            to={createPageUrl(it.page)}
            className="px-3 py-2 rounded-lg text-xs bg-[#0C0F19] border border-gray-700 text-gray-300 hover:text-white hover:border-purple-500/40 flex items-center gap-2"
            title={it.name}
          >
            <it.icon className="w-4 h-4 text-gray-400" />
            <span>{it.name}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}