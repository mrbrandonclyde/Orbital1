import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getAccounts, getTransactions, getAlerts } from "@/components/lib/apiStubs";
import { DollarSign, ArrowLeftRight, Bell } from "lucide-react";

export default function DashboardFrame() {
  const [loading, setLoading] = React.useState(true);
  const [accounts, setAccounts] = React.useState([]);
  const [transactions, setTransactions] = React.useState([]);
  const [alerts, setAlerts] = React.useState([]);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      const [a, t, al] = await Promise.all([getAccounts(), getTransactions(), getAlerts()]);
      if (mounted) {
        setAccounts(a);
        setTransactions(t);
        setAlerts(al);
        setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  const totalBalance = accounts.reduce((s, a) => s + (a.balance || 0), 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" /> Account Balance
            </CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-white">
            {loading ? "—" : `$${totalBalance.toLocaleString()}`}
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <ArrowLeftRight className="w-4 h-4 text-cyan-400" /> Recent Transactions
            </CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-white">
            {loading ? "—" : transactions.length}
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <Bell className="w-4 h-4 text-yellow-400" /> Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold text-white">
            {loading ? "—" : alerts.length}
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="outline" className="text-gray-300 border-gray-700 hover:text-white">New Account</Button>
          <Button variant="outline" className="text-gray-300 border-gray-700 hover:text-white">Send Payment</Button>
          <Button variant="outline" className="text-gray-300 border-gray-700 hover:text-white">View Reports</Button>
        </CardContent>
      </Card>
    </div>
  );
}