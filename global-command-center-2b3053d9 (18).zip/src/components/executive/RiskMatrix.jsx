import React from 'react';
import { Shield, AlertTriangle, TrendingDown, CheckCircle } from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';

const riskData = [
  { subject: 'Cyber Security', A: 85, fullMark: 100 },
  { subject: 'Market Risk', A: 78, fullMark: 100 },
  { subject: 'Operational', A: 92, fullMark: 100 },
  { subject: 'Regulatory', A: 88, fullMark: 100 },
  { subject: 'Liquidity', A: 95, fullMark: 100 },
  { subject: 'Credit Risk', A: 87, fullMark: 100 }
];

export default function RiskMatrix({ alerts, riskScore }) {
  const criticalAlerts = alerts?.filter(a => a.priority === 'URGENT').length || 0;
  const highAlerts = alerts?.filter(a => a.priority === 'HIGH').length || 0;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Risk Assessment</h3>
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${
          riskScore >= 90 ? 'bg-green-100 text-green-800' :
          riskScore >= 70 ? 'bg-yellow-100 text-yellow-800' :
          'bg-red-100 text-red-800'
        }`}>
          Score: {riskScore?.toFixed(0) || 95}
        </div>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="p-3 bg-red-50 dark:bg-red-900/30 rounded-lg">
          <div className="flex items-center justify-between">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <span className="text-lg font-bold text-red-600">{criticalAlerts}</span>
          </div>
          <div className="text-sm text-red-700 dark:text-red-400 mt-1">Critical</div>
        </div>

        <div className="p-3 bg-yellow-50 dark:bg-yellow-900/30 rounded-lg">
          <div className="flex items-center justify-between">
            <Shield className="w-5 h-5 text-yellow-600" />
            <span className="text-lg font-bold text-yellow-600">{highAlerts}</span>
          </div>
          <div className="text-sm text-yellow-700 dark:text-yellow-400 mt-1">High</div>
        </div>

        <div className="p-3 bg-green-50 dark:bg-green-900/30 rounded-lg">
          <div className="flex items-center justify-between">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span className="text-lg font-bold text-green-600">94.2%</span>
          </div>
          <div className="text-sm text-green-700 dark:text-green-400 mt-1">Mitigated</div>
        </div>
      </div>

      {/* Risk Radar */}
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={riskData}>
            <PolarGrid stroke="#e5e7eb" />
            <PolarAngleAxis 
              dataKey="subject" 
              tick={{ fill: '#6b7280', fontSize: 12 }}
            />
            <PolarRadiusAxis 
              angle={30} 
              domain={[0, 100]} 
              tick={{ fill: '#6b7280', fontSize: 10 }}
            />
            <Radar 
              name="Risk Score" 
              dataKey="A" 
              stroke="#4f46e5" 
              fill="#4f46e5" 
              fillOpacity={0.3}
              strokeWidth={2}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center mt-2">
        Risk assessment updated in real-time • Last scan: 2 minutes ago
      </div>
    </div>
  );
}