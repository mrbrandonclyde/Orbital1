import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { TrendingUp, Building, DollarSign, Package } from 'lucide-react';

const assetCategories = [
  { name: 'Real Estate', value: 45.2, color: '#3B82F6' },
  { name: 'Equities', value: 28.7, color: '#10B981' },
  { name: 'Infrastructure', value: 15.3, color: '#F59E0B' },
  { name: 'Digital Assets', value: 10.8, color: '#8B5CF6' }
];

const performanceData = Array.from({ length: 6 }, (_, i) => ({
  quarter: `Q${i + 1}`,
  value: 140 + i * 5 + Math.random() * 8,
  roi: 8 + Math.random() * 6
}));

export default function AssetsDashboard({ assets, totalValue, growth, timeframe }) {
  const [view, setView] = useState('overview');

  const formatCurrency = (value) => {
    if (value >= 1e9) return `$${(value / 1e9).toFixed(1)}B`;
    if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
    if (value >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
    return `$${value?.toFixed(0) || 0}`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 h-full">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Asset Portfolio</h3>
        <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
          {['overview', 'performance', 'allocation'].map(tab => (
            <button
              key={tab}
              onClick={() => setView(tab)}
              className={`px-3 py-1 text-sm font-medium rounded capitalize ${
                view === tab
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {view === 'overview' && (
        <div className="space-y-6">
          {/* Portfolio Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg text-white">
              <div className="flex items-center justify-between mb-2">
                <Package className="w-6 h-6" />
                <TrendingUp className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold">{formatCurrency(totalValue)}</div>
              <div className="text-sm opacity-90">Total Portfolio Value</div>
            </div>

            <div className="p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-lg text-white">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-6 h-6" />
                <span className="text-sm font-medium">YTD</span>
              </div>
              <div className="text-2xl font-bold">+{growth?.toFixed(1) || 12.7}%</div>
              <div className="text-sm opacity-90">Portfolio Growth</div>
            </div>

            <div className="p-4 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg text-white">
              <div className="flex items-center justify-between mb-2">
                <Building className="w-6 h-6" />
                <span className="text-sm font-medium">{assets?.length || 47}</span>
              </div>
              <div className="text-2xl font-bold">14.2%</div>
              <div className="text-sm opacity-90">Average ROI</div>
            </div>
          </div>

          {/* Asset Allocation Chart */}
          <div className="flex">
            <div className="w-1/2">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Asset Allocation</h4>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={assetCategories}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {assetCategories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="w-1/2 pl-6">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Category Breakdown</h4>
              <div className="space-y-3">
                {assetCategories.map((category, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: category.color }}
                      ></div>
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {category.name}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-gray-900 dark:text-white">
                      {category.value}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {view === 'performance' && (
        <div>
          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Portfolio Performance</h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="quarter" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: 'none', 
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="roi" fill="#4f46e5" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}