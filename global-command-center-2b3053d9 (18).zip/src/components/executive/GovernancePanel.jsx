import React from 'react';
import { AlertTriangle, Shield, Users, TrendingUp, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Sample data generators
const governanceData = Array.from({ length: 60 }, (_, i) => ({
  month: `M${i + 1}`,
  stability: 75 + Math.sin(i * 0.1) * 10 + Math.random() * 5,
  trust: 68 + Math.cos(i * 0.15) * 8 + Math.random() * 4,
  conflicts: Math.max(0, 15 - Math.sin(i * 0.2) * 5 + Math.random() * 3)
}));

const policySimulations = [
  { policy: "Economic Resilience Act 2024", risk: "LOW", outcome: "GDP +2.3%, Inflation -0.4%", status: "RUNNING" },
  { policy: "Digital Privacy Framework", risk: "MEDIUM", outcome: "Trust +12%, Compliance Cost +$2.1B", status: "REVIEW" },
  { policy: "Climate Infrastructure Bill", risk: "HIGH", outcome: "Emissions -18%, Job Creation +450K", status: "PENDING" },
  { policy: "Global Trade Harmonization", risk: "MEDIUM", outcome: "Trade Volume +8%, Dispute Risk +15%", status: "SIMULATION" }
];

export default function GovernancePanel({ timeframe, region, alerts, sectors }) {
  const conflictRisk = 23.4; // Sample metric
  const policyStability = 87.2;
  const civicTrust = 74.8;

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <AlertTriangle className={`w-5 h-5 ${conflictRisk > 30 ? 'text-red-400' : conflictRisk > 15 ? 'text-yellow-400' : 'text-green-400'}`} />
          </div>
          <div className="text-2xl font-bold text-white">{conflictRisk}%</div>
          <div className="text-xs text-gray-400">Conflict Risk Index</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingDown className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">-2.1% vs last month</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Shield className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{policyStability.toFixed(1)}</div>
          <div className="text-xs text-gray-400">Policy Stability</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+1.8 vs last quarter</span>
          </div>
        </div>

        <div className="orbital-card p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-5 h-5 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white">{civicTrust.toFixed(1)}%</div>
          <div className="text-xs text-gray-400">Civic Trust Level</div>
          <div className="flex items-center justify-center mt-2">
            <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
            <span className="text-xs text-green-400">+0.9% vs last survey</span>
          </div>
        </div>
      </div>

      {/* Governance Stability Chart */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">5-Year Governance Stability Trend</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={governanceData.slice(-60)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9CA3AF" fontSize={10} />
              <YAxis stroke="#9CA3AF" fontSize={10} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }}
              />
              <Line type="monotone" dataKey="stability" stroke="#06B6D4" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="trust" stroke="#8B5CF6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center space-x-4 mt-2 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
            <span className="text-gray-400">Policy Stability</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
            <span className="text-gray-400">Civic Trust</span>
          </div>
        </div>
      </div>

      {/* Policy Simulations Table */}
      <div className="orbital-card p-4">
        <h4 className="text-sm font-semibold text-white mb-4">Pending Policy Simulations</h4>
        <div className="space-y-2">
          {policySimulations.map((policy, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-gray-800/30 rounded text-xs">
              <div className="flex-1">
                <div className="text-white font-medium">{policy.policy}</div>
                <div className="text-gray-400">{policy.outcome}</div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded text-xs ${
                  policy.risk === 'HIGH' ? 'bg-red-500/20 text-red-400' :
                  policy.risk === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-green-500/20 text-green-400'
                }`}>
                  {policy.risk}
                </span>
                <span className={`px-2 py-1 rounded text-xs ${
                  policy.status === 'RUNNING' ? 'bg-blue-500/20 text-blue-400' :
                  policy.status === 'PENDING' ? 'bg-orange-500/20 text-orange-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  {policy.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}