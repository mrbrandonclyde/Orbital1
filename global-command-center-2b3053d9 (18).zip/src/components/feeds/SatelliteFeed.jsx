import React, { useState, useEffect } from 'react';
import { SatelliteImage } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Satellite, MapPin, Calendar, Eye } from 'lucide-react';

export default function SatelliteFeed({ region = null, onImageSelect }) {
  const [satellites, setSatellites] = useState([]);
  const [loading, setLoading] = useState(false);

  const generateSatelliteData = async () => {
    setLoading(true);
    try {
      const mockData = await InvokeLLM({
        prompt: `Generate 8 realistic satellite imagery entries for a global intelligence platform. Include:
        - Mix of NASA Earthdata, Planet Labs, Sentinel Hub sources
        - Recent acquisition dates (within last 30 days)
        - Global coverage with coordinates
        - Realistic cloud cover percentages
        - Various resolutions (10m to 250m)`,
        response_json_schema: {
          type: "object",
          properties: {
            images: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  image_id: { type: "string" },
                  source: { type: "string" },
                  mission_name: { type: "string" },
                  acquisition_date: { type: "string" },
                  image_url: { type: "string" },
                  center_coordinates: {
                    type: "object",
                    properties: {
                      latitude: { type: "number" },
                      longitude: { type: "number" }
                    }
                  },
                  resolution_meters: { type: "number" },
                  cloud_cover_percentage: { type: "number" }
                }
              }
            }
          }
        }
      });

      setSatellites(mockData.images || []);
    } catch (error) {
      console.error('Failed to generate satellite data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateSatelliteData();
  }, [region]);

  if (loading) {
    return (
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Satellite className="w-6 h-6 text-blue-400 animate-pulse" />
          <h3 className="text-xl font-semibold text-white">Satellite Imagery</h3>
        </div>
        <div className="animate-pulse space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="h-20 bg-gray-800/30 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Satellite className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Satellite Imagery</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-gray-400">Live Feed</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {satellites.map((sat, index) => (
          <div 
            key={index}
            onClick={() => onImageSelect?.(sat)}
            className="bg-gray-800/30 rounded-lg p-4 hover:bg-gray-700/30 cursor-pointer transition-all"
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm font-medium text-blue-400">{sat.source}</span>
                  <span className="text-xs text-gray-500">{sat.mission_name}</span>
                </div>
                <div className="flex items-center space-x-4 text-xs text-gray-400">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span>{sat.center_coordinates?.latitude?.toFixed(2)}, {sat.center_coordinates?.longitude?.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(sat.acquisition_date).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-400 mb-1">{sat.resolution_meters}m resolution</div>
                <div className="text-xs text-gray-400">☁️ {sat.cloud_cover_percentage}%</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <button 
        onClick={generateSatelliteData}
        className="w-full mt-4 bg-blue-600/20 border border-blue-500/30 text-blue-400 py-2 rounded-lg hover:bg-blue-600/30 transition-all text-sm"
      >
        <Eye className="w-4 h-4 inline mr-2" />
        Refresh Satellite Feed
      </button>
    </div>
  );
}