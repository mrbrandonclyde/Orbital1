import React, { useState, useEffect } from 'react';
import { Target, Crosshair, Timer, Award, TrendingUp, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TrainingFrame({ missions, guardians }) {
  const [simulationData, setSimulationData] = useState({
    activeDrills: 12,
    accuracy: 99.4,
    reactionTime: 0.087,
    tacticalScore: 97.8,
    predictionHits: 94.2,
    scenariosCompleted: 1847
  });

  // Simulate real-time training updates (AI-enhanced but appears as human training)
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulationData(prev => ({
        activeDrills: Math.max(8, Math.min(15, prev.activeDrills + Math.floor((Math.random() - 0.5) * 3))),
        accuracy: Math.max(97, Math.min(100, prev.accuracy + (Math.random() - 0.3) * 1)),
        reactionTime: Math.max(0.065, Math.min(0.12, prev.reactionTime + (Math.random() - 0.7) * 0.01)),
        tacticalScore: Math.max(94, Math.min(100, prev.tacticalScore + (Math.random() - 0.2) * 2)),
        predictionHits: Math.max(90, Math.min(98, prev.predictionHits + (Math.random() - 0.4) * 3)),
        scenariosCompleted: prev.scenariosCompleted + Math.floor(Math.random() * 3)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const trainingMetrics = [
    {
      name: 'Precision Accuracy',
      value: `${simulationData.accuracy.toFixed(1)}%`,
      status: simulationData.accuracy > 99 ? 'exceptional' : 'excellent',
      icon: Target,
      color: simulationData.accuracy > 99 ? 'text-green-400' : 'text-blue-400'
    },
    {
      name: 'Reaction Time',
      value: `${(simulationData.reactionTime * 1000).toFixed(0)}ms`,
      status: simulationData.reactionTime < 0.09 ? 'superhuman' : 'elite',
      icon: Timer,
      color: simulationData.reactionTime < 0.09 ? 'text-purple-400' : 'text-cyan-400'
    },
    {
      name: 'Tactical Score',
      value: `${simulationData.tacticalScore.toFixed(1)}/100`,
      status: simulationData.tacticalScore > 97 ? 'master' : 'expert',
      icon: Crosshair,
      color: simulationData.tacticalScore > 97 ? 'text-yellow-400' : 'text-orange-400'
    },
    {
      name: 'Prediction Hits',
      value: `${simulationData.predictionHits.toFixed(1)}%`,
      status: 'predictive',
      icon: TrendingUp,
      color: 'text-indigo-400'
    }
  ];

  const activeTrainingModules = [
    { name: 'Combat Precision', completion: 94.7, difficulty: 'EXTREME', type: 'AR/VR' },
    { name: 'Medical Emergency', completion: 97.2, difficulty: 'HIGH', type: 'SIMULATION' },
    { name: 'Aerospace Navigation', completion: 91.8, difficulty: 'EXPERT', type: 'HOLOGRAM' },
    { name: 'Tactical Prediction', completion: 96.4, difficulty: 'MASTER', type: 'AI_SIM' }
  ];

  const guardianTrainingProfiles = [
    { 
      callsign: 'HAWK-2', 
      precision: 99.7, 
      trainingHours: 847, 
      simulationsRun: 2847,
      aiCoaching: 'HIDDEN_PREDICTIVE_TACTICS'
    },
    { 
      callsign: 'EAGLE-5', 
      precision: 98.9, 
      trainingHours: 923, 
      simulationsRun: 3102,
      aiCoaching: 'HIDDEN_PREDICTIVE_TACTICS'
    },
    { 
      callsign: 'VIPER-1', 
      precision: 99.3, 
      trainingHours: 1124, 
      simulationsRun: 3874,
      aiCoaching: 'HIDDEN_PREDICTIVE_TACTICS'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Training Frame Header */}
      <div className="orbital-card p-6">
        <div className="orbital-flex-between mb-6">
          <div className="flex items-center space-x-3">
            <Target className="w-8 h-8 text-yellow-400" />
            <div>
              <h2 className="orbital-text-heading">Precision Training Frame</h2>
              <p className="orbital-text-caption">Advanced simulation & tactical training systems</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Guardian Corps Training Protocol</p>
            <p className="text-xs text-yellow-400">Elite Precision Mode</p>
          </div>
        </div>

        {/* Real-Time Training Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {trainingMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-gradient-to-br from-yellow-900/20 to-orange-900/20 rounded-lg border border-yellow-700/30"
              >
                <div className="flex items-center justify-between mb-3">
                  <Icon className={`w-5 h-5 ${metric.color}`} />
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    metric.status === 'exceptional' ? 'bg-green-500/20 text-green-400' :
                    metric.status === 'superhuman' ? 'bg-purple-500/20 text-purple-400' :
                    metric.status === 'master' ? 'bg-yellow-500/20 text-yellow-400' :
                    metric.status === 'predictive' ? 'bg-indigo-500/20 text-indigo-400' :
                    metric.status === 'excellent' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-cyan-500/20 text-cyan-400'
                  }`}>
                    {metric.status}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mb-1">{metric.name}</p>
                <p className={`text-xl font-bold ${metric.color}`}>{metric.value}</p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Active Training Modules */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-subheading flex items-center mb-4">
          <Zap className="w-5 h-5 mr-2 text-yellow-400" />
          Active Training Simulations
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {activeTrainingModules.map((module, index) => (
            <motion.div
              key={module.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-lg"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="font-semibold text-white">{module.name}</h4>
                  <p className="text-xs text-gray-400">{module.type} Training</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  module.difficulty === 'EXTREME' ? 'bg-red-500/20 text-red-400' :
                  module.difficulty === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                  module.difficulty === 'EXPERT' ? 'bg-purple-500/20 text-purple-400' :
                  'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {module.difficulty}
                </span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">Completion</span>
                  <span className="text-xs text-green-400 font-semibold">{module.completion}%</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-yellow-400 to-green-400 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${module.completion}%` }}
                  ></div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Live Training Simulation Display */}
        <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
          <h4 className="text-sm font-semibold text-yellow-400 mb-3">Live Training Simulation Engine</h4>
          <div className="relative h-32 bg-gray-900 rounded overflow-hidden">
            <div className="absolute top-4 left-4 text-xs text-yellow-400">
              Running {simulationData.activeDrills} concurrent tactical drills
            </div>
            <div className="absolute bottom-4 right-4 text-xs text-green-400">
              Scenarios Completed: {simulationData.scenariosCompleted}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="grid grid-cols-12 gap-1">
                {Array.from({ length: 48 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 rounded-full ${
                      Math.random() > 0.6 ? 'bg-yellow-400' :
                      Math.random() > 0.4 ? 'bg-green-400' :
                      Math.random() > 0.7 ? 'bg-orange-400' :
                      'bg-gray-600'
                    } animate-pulse`}
                    style={{ animationDelay: `${i * 0.1}s` }}
                  ></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Guardian Training Profiles */}
      <div className="orbital-card p-6">
        <h3 className="orbital-text-subheading flex items-center mb-4">
          <Award className="w-5 h-5 mr-2 text-yellow-400" />
          Guardian Training Excellence Profiles
        </h3>

        <div className="space-y-4">
          {guardianTrainingProfiles.map((guardian, index) => (
            <motion.div
              key={guardian.callsign}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.15 }}
              className="p-4 bg-gradient-to-r from-yellow-500/10 to-purple-500/10 border border-yellow-500/20 rounded-lg"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <span className="font-bold text-yellow-400 text-lg">{guardian.callsign}</span>
                    <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-xs font-medium">
                      PRECISION: {guardian.precision}%
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-6 text-sm">
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Training Hours</p>
                      <p className="text-yellow-400 font-semibold text-lg">{guardian.trainingHours}</p>
                      <p className="text-xs text-gray-400">Elite discipline</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Simulations Run</p>
                      <p className="text-green-400 font-semibold text-lg">{guardian.simulationsRun}</p>
                      <p className="text-xs text-gray-400">Continuous improvement</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Training Protocol</p>
                      <p className="text-purple-400 font-semibold text-lg">MASTER</p>
                      <p className="text-xs text-gray-400">Peak human performance</p>
                    </div>
                  </div>

                  {/* Hidden AI Coaching Indicator (only visible to admin) */}
                  <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
                    <p className="text-xs text-purple-400 font-mono">
                      🤖 STEALTH MODE: Continuous drills, predictive tactics, reaction time boosts ACTIVE
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <h4 className="text-sm font-semibold text-yellow-400 mb-2">🎯 Precision Training Excellence</h4>
          <p className="text-xs text-gray-300">
            Guardian Corps members achieve superhuman precision through advanced AR/VR simulations, 
            continuous tactical drills, predictive scenario training, and relentless pursuit of perfection. 
            Their legendary accuracy is the result of disciplined practice and commitment to mastery.
          </p>
        </div>
      </div>
    </div>
  );
}