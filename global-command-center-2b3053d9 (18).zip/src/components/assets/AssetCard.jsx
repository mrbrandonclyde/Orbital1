import React from 'react';
import { Package, TrendingUp, MapPin, Calendar, AlertTriangle, Pencil } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const getRiskBadge = (riskLevel) => {
  switch (riskLevel) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    case 'LOW': return <Badge className="bg-blue-500/20 text-blue-400">LOW</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'MAINTENANCE': return <Badge className="bg-yellow-500/20 text-yellow-400">MAINTENANCE</Badge>;
    case 'DECOMMISSIONED': return <Badge className="bg-red-500/20 text-red-400">DECOMMISSIONED</Badge>;
    case 'FOR_SALE': return <Badge className="bg-purple-500/20 text-purple-400">FOR SALE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">PLANNING</Badge>;
  }
};

export default function AssetCard({ asset, onEdit }) {
  const formatCurrency = (amount) => {
    if (amount >= 1e9) return `$${(amount / 1e9).toFixed(1)}B`;
    if (amount >= 1e6) return `$${(amount / 1e6).toFixed(1)}M`;
    if (amount >= 1e3) return `$${(amount / 1e3).toFixed(1)}K`;
    return `$${amount?.toFixed(0) || 0}`;
  };

  const calculateROI = () => {
    if (!asset.acquisition_cost_usd || asset.acquisition_cost_usd === 0) return 0;
    return (((asset.current_value_usd - asset.acquisition_cost_usd) / asset.acquisition_cost_usd) * 100).toFixed(1);
  };

  return (
    <Card className="bg-[#0A0D18]/50 border border-gray-800 hover:border-cyan-500/50 transition-all cursor-pointer">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-2">
            <Package className="w-5 h-5 text-cyan-400" />
            <CardTitle className="text-lg text-white">{asset.asset_name}</CardTitle>
          </div>
          <button
            onClick={() => onEdit(asset)}
            className="p-1 hover:bg-gray-700 rounded"
          >
            <Pencil className="w-4 h-4 text-gray-400" />
          </button>
        </div>
        <div className="flex space-x-2">
          {getStatusBadge(asset.lifecycle_status)}
          {getRiskBadge(asset.risk_level)}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Current Value</span>
            <span className="text-lg font-bold text-green-400">{formatCurrency(asset.current_value_usd)}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">ROI</span>
            <span className={`text-sm font-semibold ${parseFloat(calculateROI()) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {calculateROI()}%
            </span>
          </div>

          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <MapPin className="w-4 h-4" />
            <span>{asset.location || 'Global'}</span>
          </div>

          <div className="text-xs text-gray-500">
            <p className="truncate">{asset.description}</p>
          </div>

          <div className="flex justify-between text-xs">
            <span className="text-gray-500">Category: {asset.asset_category}</span>
            <span className="text-gray-500">Type: {asset.asset_type}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}