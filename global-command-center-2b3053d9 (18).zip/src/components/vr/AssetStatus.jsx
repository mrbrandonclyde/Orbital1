import React from 'react';
import { Building, Shield, Database, Users } from 'lucide-react';

const AssetCategory = ({ icon: Icon, name, count, color }) => (
  <div className="flex items-center justify-between p-2 rounded-md bg-gray-800/30">
    <div className="flex items-center">
      <Icon className={`w-5 h-5 mr-3 ${color}`} />
      <span className="text-sm text-white">{name}</span>
    </div>
    <span className="font-bold text-gray-300">{count}</span>
  </div>
);

export default function AssetStatus({ assets }) {
  const getAssetCount = (category) => {
    return assets?.filter(a => a.asset_category === category).length || 0;
  };

  const assetCounts = {
    Infrastructure: getAssetCount('Infrastructure'),
    IP: getAssetCount('Intellectual Property'),
    Financial: getAssetCount('Equities') + getAssetCount('Digital Currency'),
    // This is a placeholder for personnel, as it's not a direct asset category
    Personnel: 1245 
  };
  
  return (
    <div className="h-full flex flex-col">
      <h3 className="text-lg font-semibold text-white mb-4">Strategic Asset Overview</h3>
      <div className="space-y-3">
        <AssetCategory icon={Building} name="Infrastructure" count={assetCounts.Infrastructure} color="text-blue-400" />
        <AssetCategory icon={Shield} name="Intellectual Property" count={assetCounts.IP} color="text-purple-400" />
        <AssetCategory icon={Database} name="Financial Instruments" count={assetCounts.Financial} color="text-green-400" />
        <AssetCategory icon={Users} name="Personnel" count={assetCounts.Personnel} color="text-cyan-400" />
      </div>
    </div>
  );
}