import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function SectorPerformanceChart({ data, name, color }) {
  return (
    <div className="h-full w-full flex flex-col">
      <p className="text-xs font-semibold" style={{color}}>{name}</p>
      <div className="flex-grow">
        <ResponsiveContainer>
          <AreaChart data={data} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id={`color-${name}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.4}/>
                <stop offset="95%" stopColor={color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(10, 13, 24, 0.8)',
                borderColor: 'rgba(55, 65, 81, 0.6)',
                color: '#D1D5DB',
                fontSize: '12px',
                borderRadius: '0.5rem',
              }}
              cursor={{ stroke: color, strokeWidth: 1, strokeDasharray: '3 3' }}
            />
            <Area type="monotone" dataKey="value" stroke={color} strokeWidth={2} fillOpacity={1} fill={`url(#color-${name})`} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}