import React from 'react';
import { motion } from 'framer-motion';

export default function ThreatLevelIndicator({ alerts }) {
  const alertCount = alerts?.length || 0;
  let level, color, percentage;

  if (alertCount > 10) {
    level = 'CRITICAL';
    color = '#EF4444'; // red-500
    percentage = 95;
  } else if (alertCount > 5) {
    level = 'HIGH';
    color = '#F59E0B'; // amber-500
    percentage = 75;
  } else if (alertCount > 0) {
    level = 'MODERATE';
    color = '#3B82F6'; // blue-500
    percentage = 45;
  } else {
    level = 'LOW';
    color = '#10B981'; // emerald-500
    percentage = 15;
  }

  const circumference = 2 * Math.PI * 45; // 2 * pi * radius
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center h-full">
      <div className="relative w-40 h-40 md:w-48 md:h-48">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle
            className="text-gray-700"
            strokeWidth="8"
            stroke="currentColor"
            fill="transparent"
            r="45"
            cx="50"
            cy="50"
          />
          {/* Progress circle */}
          <motion.circle
            strokeWidth="8"
            stroke={color}
            fill="transparent"
            r="45"
            cx="50"
            cy="50"
            strokeLinecap="round"
            style={{ strokeDasharray: circumference, strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            transform="rotate(-90 50 50)"
          />
        </svg>
        <div className="absolute top-0 left-0 w-full h-full flex flex-col items-center justify-center">
          <span className="text-3xl md:text-4xl font-bold" style={{ color }}>{level}</span>
          <span className="text-xs text-gray-400">THREATCON</span>
        </div>
      </div>
      <div className="mt-4 text-center">
        <p className="text-lg text-white font-medium">{alertCount} Active Critical Alerts</p>
        <p className="text-sm text-gray-500">Real-time assessment</p>
      </div>
    </div>
  );
}