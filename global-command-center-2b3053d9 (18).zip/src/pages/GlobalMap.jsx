
import React, { useState, useRef } from 'react';
import { Map, Globe, Satellite, Target, AlertTriangle, Activity, Search, Layers, Landmark, Pin } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import OrbitalGlobe from "@/components/globe/OrbitalGlobe";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const mapMetrics = [
  { title: "Global Coverage", value: "100%", icon: Globe, color: "text-blue-400" },
  { title: "Satellite Feeds", value: "1,247", icon: Satellite, color: "text-green-400" },
  { title: "Active Regions", value: "198", icon: Map, color: "text-purple-400" },
  { title: "Threat Markers", value: "47", icon: AlertTriangle, color: "text-red-400" },
  { title: "Asset Tracking", value: "8,945", icon: Target, color: "text-yellow-400" },
  { title: "Live Updates", value: "2.4M/hr", icon: Activity, color: "text-cyan-400" }
];

const regionStatus = [
  { region: 'North America', status: 'STABLE', threats: 3, assets: 247, color: 'text-green-400' },
  { region: 'Europe', status: 'MONITORING', threats: 8, assets: 189, color: 'text-yellow-400' },
  { region: 'Asia Pacific', status: 'HIGH_ALERT', threats: 15, assets: 345, color: 'text-red-400' },
  { region: 'Middle East', status: 'UNSTABLE', threats: 12, assets: 78, color: 'text-orange-400' },
  { region: 'Africa', status: 'MONITORING', threats: 6, assets: 123, color: 'text-yellow-400' },
  { region: 'South America', status: 'STABLE', threats: 4, assets: 156, color: 'text-green-400' }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'STABLE': return <Badge className="bg-green-500/20 text-green-400">STABLE</Badge>;
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400">MONITORING</Badge>;
    case 'HIGH_ALERT': return <Badge className="bg-red-500/20 text-red-400 animate-pulse">HIGH ALERT</Badge>;
    case 'UNSTABLE': return <Badge className="bg-orange-500/20 text-orange-400">UNSTABLE</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

export default function GlobalMapPage() {
  const [selectedRegion, setSelectedRegion] = useState(null);
  const globeRef = useRef(null);
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const [zoningOn, setZoningOn] = useState(false);
  const [ownershipOn, setOwnershipOn] = useState(false);

  const addSampleOverlays = () => {
    if (!globeRef.current) return;
    globeRef.current.clearOverlays();
    if (zoningOn) {
      // Sample "zone" polygon outline near Mesopotamia
      globeRef.current.addPolyline(
        [
          [35.0, 40.0], [36.0, 43.0], [34.0, 46.0], [32.5, 43.5], [35.0, 40.0]
        ],
        0x9b5cf6
      );
    }
    if (ownershipOn) {
      // Ownership "corridor" polyline across North America
      globeRef.current.addPolyline(
        [
          [49.2, -123.1], [45.5, -122.6], [38.9, -77.0], [25.8, -80.2]
        ],
        0x06b6d4
      );
    }
  };

  const handleSearch = () => {
    const latNum = parseFloat(lat);
    const lonNum = parseFloat(lon);
    if (Number.isFinite(latNum) && Number.isFinite(lonNum) && globeRef.current) {
      globeRef.current.flyTo({ lat: latNum, lon: lonNum, ms: 1200 });
      globeRef.current.addMarker({ lat: latNum, lon: lonNum, color: 0x22c55e, size: 0.04, label: "Search Target" });
    }
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Globe className="w-10 h-10 mr-3 text-blue-400" />
            Global Intelligence Map
          </h1>
          <p className="orbital-text-subtitle">Restored interactive Earth — explore, search, and overlay strategic layers.</p>
        </div>
      </div>

      {/* Quick Controls */}
      <div className="glass-pane p-4 mb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-gray-400" />
            <Input
              placeholder="Latitude (e.g. 31.5)"
              value={lat}
              onChange={(e) => setLat(e.target.value)}
              className="bg-[#0C0F19] border-gray-700 text-gray-100"
            />
            <Input
              placeholder="Longitude (e.g. 35.5)"
              value={lon}
              onChange={(e) => setLon(e.target.value)}
              className="bg-[#0C0F19] border-gray-700 text-gray-100"
            />
            <Button onClick={handleSearch} className="bg-indigo-600 hover:bg-indigo-700">Go</Button>
          </div>

          <div className="flex items-center gap-3">
            <Layers className="w-4 h-4 text-gray-400" />
            <Button
              variant={zoningOn ? "default" : "secondary"}
              onClick={() => { setZoningOn(!zoningOn); setTimeout(addSampleOverlays, 0); }}
              className={zoningOn ? "bg-purple-600 hover:bg-purple-700" : "border-gray-700 text-gray-200 hover:text-white"}
            >
              Zoning Layer
            </Button>
            <Landmark className="w-4 h-4 text-gray-400" />
            <Button
              variant={ownershipOn ? "default" : "secondary"}
              onClick={() => { setOwnershipOn(!ownershipOn); setTimeout(addSampleOverlays, 0); }}
              className={ownershipOn ? "bg-cyan-600 hover:bg-cyan-700" : "border-gray-700 text-gray-200 hover:text-white"}
            >
              Ownership Tracker
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                if (!globeRef.current) return;
                globeRef.current.clearMarkers();
                globeRef.current.clearOverlays();
              }}
              className="border-gray-700 text-gray-200 hover:text-white"
            >
              Clear
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <Pin className="w-4 h-4 text-gray-400" />
            <Button
              variant="secondary"
              onClick={() => {
                if (!globeRef.current) return;
                globeRef.current.addMarker({ lat: 37.7749, lon: -122.4194, label: "San Francisco" });
                globeRef.current.addMarker({ lat: 34.0522, lon: -118.2437, label: "Los Angeles" });
                globeRef.current.addMarker({ lat: 31.5, lon: 35.5, color: 0x22c55e, label: "Historic Levant" });
              }}
              className="border-gray-700 text-gray-200 hover:text-white"
            >
              Add Sample Markers
            </Button>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {mapMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      {/* Globe + Regions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-pane p-2">
          <OrbitalGlobe
            ref={globeRef}
            height={480}
            autoRotate
            rotationSpeed={0.001}
            showGrid
            initialMarkers={[
              { lat: 51.5074, lon: -0.1278, color: 0x00a2ff, label: "London" },
              { lat: 35.6895, lon: 139.6917, color: 0xff6b6b, label: "Tokyo" },
            ]}
          />
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Regional Status</h3>
          <div className="space-y-4">
            {regionStatus.map((region, i) => (
              <div
                key={i}
                className="p-3 bg-gray-800/30 rounded-lg cursor-pointer hover:bg-gray-800/50 transition-all"
                onClick={() => {
                  setSelectedRegion(region);
                  // Fly to rough centroids by region name (simple demo)
                  if (globeRef.current) {
                    const presets = {
                      "North America": { lat: 39, lon: -98 },
                      "Europe": { lat: 54, lon: 15 },
                      "Asia Pacific": { lat: 20, lon: 120 },
                      "Middle East": { lat: 29, lon: 42 },
                      "Africa": { lat: 1, lon: 20 },
                      "South America": { lat: -15, lon: -60 },
                    };
                    const p = presets[region.region];
                    if (p) globeRef.current.flyTo(p);
                  }
                }}
              >
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-white">{region.region}</h4>
                  {getStatusBadge(region.status)}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Threats:</span>
                    <span className="text-red-400 font-semibold ml-2">{region.threats}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Assets:</span>
                    <span className="text-green-400 font-semibold ml-2">{region.assets}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
