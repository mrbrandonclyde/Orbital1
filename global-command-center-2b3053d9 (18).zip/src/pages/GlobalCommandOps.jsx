
import React, { useEffect, useState } from 'react';
import { Globe, Users, Shield, Zap, Crown } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { User } from '@/api/entities';
import WarRoomScene from '../components/vr/WarRoomScene';
import ProtectedComponent from '../components/common/ProtectedComponent';
import VRBillingLock from '../components/billing/VRBillingLock';

export default function GlobalCommandOpsPage() {
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    User.me().then(setCurrentUser).catch(() => setCurrentUser(null));
  }, []);

  return (
    <div className="animate-fade-in space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text flex items-center">
            <Globe className="w-10 h-10 mr-3 text-indigo-400" />
            Immersive War Room
          </h1>
          <p className="text-lg text-gray-400 mt-2">
            Navigate the Global Knowledge Graph in a real-time, 3D interactive environment.
          </p>
        </div>
        
        {currentUser?.subscription_tier === 'ENTERPRISE' || currentUser?.subscription_tier === 'GOVERNMENT' ? (
          <div className="flex items-center space-x-2 bg-purple-500/10 border border-purple-500/20 rounded px-3 py-1">
            <Crown className="w-4 h-4 text-purple-400" />
            <span className="text-purple-400 font-semibold text-sm">VR ENABLED</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 bg-gray-500/10 border border-gray-500/20 rounded px-3 py-1">
            <Shield className="w-4 h-4 text-gray-400" />
            <span className="text-gray-400 font-semibold text-sm">VR UPGRADE REQUIRED</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Zap className="w-5 h-5 text-red-400" />
              <span>Active Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-400">12</div>
            <p className="text-gray-400 text-sm">Critical events ongoing</p>
          </CardContent>
        </Card>
        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Shield className="w-5 h-5 text-blue-400" />
              <span>Monitored Regions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-400">45</div>
            <p className="text-gray-400 text-sm">States & Economic Zones</p>
          </CardContent>
        </Card>
        <Card className="bg-[#0A0D18]/50 border-[#151823]">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Users className="w-5 h-5 text-green-400" />
              <span>Tracked Companies</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">1500+</div>
            <p className="text-gray-400 text-sm">Fortune 1000 & Global 500</p>
          </CardContent>
        </Card>
        <div className="flex items-center justify-center p-4 bg-[#0A0D18]/50 border border-dashed border-gray-700 rounded-lg">
           <p className="text-center text-gray-400 text-sm">
             {currentUser?.vr_access_enabled ? 
               'VR/XR headset integration is ready. Connect your device to enter immersive mode.' :
               'VR access requires Enterprise subscription. Upgrade to unlock immersive command center.'
             }
           </p>
        </div>
      </div>
      
      {/* VR War Room - Premium Feature */}
      <ProtectedComponent
        requiredTier="ENTERPRISE"
        fallback={
          <div className="bg-gradient-to-r from-purple-900/30 to-indigo-900/30 border border-purple-500/30 rounded-xl p-8 text-center">
            <Crown className="w-16 h-16 text-purple-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-4">Enterprise VR War Room</h2>
            <p className="text-xl text-gray-300 mb-6">
              Step inside your data with immersive 3D visualization, real-time global monitoring, and collaborative intelligence briefings.
            </p>
            
            {/* VR Billing Preview */}
            <VRBillingLock 
              userTier={currentUser?.subscription_tier || 'BASIC'}
              requiredTier="ENTERPRISE"
              sectors={['Energy', 'Defense', 'Finance', 'Technology']}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-gray-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-purple-400 mb-2">🌍 Interactive Globe</h4>
                <p className="text-gray-400 text-sm">Navigate through regions, sectors, and companies in 3D space</p>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-purple-400 mb-2">🚨 Holographic Alerts</h4>
                <p className="text-gray-400 text-sm">Critical threats appear as floating holograms around you</p>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-purple-400 mb-2">🤝 Multi-User Sessions</h4>
                <p className="text-gray-400 text-sm">Collaborate with your team in shared virtual briefing rooms</p>
              </div>
            </div>
            <button className="orbital-button-primary text-lg px-8 py-3">
              Upgrade to Enterprise - Unlock VR
            </button>
          </div>
        }
      >
        <WarRoomScene />
      </ProtectedComponent>
    </div>
  );
}
