import React from "react";
import HeaderFrame from "@/components/foundation/HeaderFrame";
import SidebarFrame from "@/components/foundation/SidebarFrame";
import FooterFrame from "@/components/foundation/FooterFrame";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Phase1Investments() {
  return (
    <div>
      <HeaderFrame title="Investments" subtitle="Investments overview (placeholder)" />
      <SidebarFrame />
      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader><CardTitle className="text-white text-sm">Investments Placeholder</CardTitle></CardHeader>
        <CardContent className="text-gray-300 text-sm">Phase 1 placeholder content.</CardContent>
      </Card>
      <FooterFrame />
    </div>
  );
}