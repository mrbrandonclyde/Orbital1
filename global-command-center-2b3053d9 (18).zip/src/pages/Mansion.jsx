import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PieChart, Pie, Cell, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Home, DollarSign, ShieldCheck, HeartPulse, Zap, Car, Plane, CheckCircle, AlertTriangle } from 'lucide-react';

// === Placeholder Data (Infinity Edition) ===
const kpiData = [
  { title: "Net Asset Value", value: "$4.7B", trend: "+1.2%", icon: DollarSign, color: "text-green-400" },
  { title: "Estate Systems Health", value: "99.8%", trend: "Stable", icon: ShieldCheck, color: "text-cyan-400" },
  { title: "Personal Health Index", value: "94/100", trend: "Optimal", icon: HeartPulse, color: "text-emerald-400" },
  { title: "Energy Balance", value: "88%", trend: "Surplus", icon: Zap, color: "text-yellow-400" },
  { title: "Luxury Asset Status", value: "100%", trend: "Operational", icon: Car, color: "text-blue-400" },
];

const assetData = [
  { name: "Real Estate", value: 450, color: "#06B6D4" }, // cyan
  { name: "Bank Holdings", value: 250, color: "#3B82F6" }, // blue
  { name: "Investments", value: 150, color: "#8B5CF6" }, // purple
  { name: "Vehicles & Art", value: 100, color: "#A78BFA" }, // light purple
  { name: "Aviation", value: 50, color: "#F59E0B" }, // amber
];

const healthData = [
  { day: "Mon", rhr: 62, stress: 14, recovery: 95 },
  { day: "Tue", rhr: 60, stress: 12, recovery: 98 },
  { day: "Wed", rhr: 59, stress: 10, recovery: 99 },
  { day: "Thu", rhr: 61, stress: 13, recovery: 96 },
  { day: "Fri", rhr: 60, stress: 11, recovery: 97 },
  { day: "Sat", rhr: 58, stress: 8, recovery: 100 },
  { day: "Sun", rhr: 59, stress: 9, recovery: 100 },
];

const energyData = [
  { source: "Solar", input: 60, output: 40 },
  { source: "Grid", input: 30, output: 25 },
  { source: "Backup", input: 10, output: 5 },
  { source: "Battery", input: 0, output: 30 },
];

const assetLog = [
  { date: "2025-09-01", asset: "Private Jet", status: "Operational", value: "$45M", notes: "Cleared for trans-atlantic flight." },
  { date: "2025-09-01", asset: "Crypto Holdings", status: "Stable", value: "$8.2M", notes: "Market conditions nominal." },
  { date: "2025-08-30", asset: "Primary Residence", status: "Secure", value: "$120M", notes: "All systems green." },
  { date: "2025-08-28", asset: "Hypercar", status: "Maintenance", value: "$4.5M", notes: "Scheduled diagnostics." },
];

const estateLog = [
  { date: "2025-09-01", system: "Perimeter Security", status: "100% Uptime", notes: "No breaches detected." },
  { date: "2025-09-01", system: "AI Core (Zyra)", status: "99.9% Uptime", notes: "Self-optimizing." },
  { date: "2025-09-01", system: "Power Grid", status: "100% Uptime", notes: "Seamless switch to solar." },
  { date: "2025-08-31", system: "Water Filtration", status: "99.8% Uptime", notes: "Minor pressure fluctuation." },
];

const wellnessLog = [
  { date: "2025-09-01", metric: "Sleep Score", value: "95/100", status: "Optimal" },
  { date: "2025-09-01", metric: "Stress Index", value: "12%", status: "Low" },
  { date: "2025-09-01", metric: "Cognitive Load", value: "45%", status: "Nominal" },
  { date: "2025-08-31", metric: "Recovery", value: "98%", status: "Excellent" },
];

const ChartTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 p-3 rounded-lg text-sm shadow-lg">
          <p className="label text-white font-medium mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
};

const getStatusBadge = (status) => {
    switch (status) {
      case "Operational":
      case "Stable":
      case "Secure":
      case "Optimal":
      case "Low":
        return <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">{status}</Badge>;
      case "Maintenance":
        return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">{status}</Badge>;
      default:
        return <Badge className="bg-gray-500/10 text-gray-400 border-gray-500/20">{status}</Badge>;
    }
};

export default function MansionPage() {
  return (
    <div className="orbital-page-layout p-6">
      {/* Frame 1: Mansion Overview */}
      <div className="orbital-page-header">
          <h1 className="orbital-text-title flex items-center"><Home className="w-10 h-10 mr-3 text-cyan-400" />Genius Mansion Dashboard</h1>
          <p className="orbital-text-subtitle mt-2">Holistic command of personal assets, estate systems, and peak performance biometrics.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {kpiData.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                <Icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{kpi.value}</p>
              <p className="text-xs text-gray-500 mt-1">{kpi.trend}</p>
            </div>
          );
        })}
      </div>

      {/* Frame 2: Wealth + Health Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="glass-pane p-4 h-80 flex flex-col">
            <h3 className="orbital-text-subheading mb-4">Asset Portfolio Allocation</h3>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={assetData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5}>
                    {assetData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
        </div>

        <div className="glass-pane p-4 h-80 flex flex-col">
            <h3 className="orbital-text-subheading mb-4">Personal Health Trends</h3>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={healthData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="day" stroke="#9CA3AF" fontSize={12} />
                    <YAxis stroke="#9CA3AF" fontSize={12} />
                    <Tooltip content={<ChartTooltip />} />
                    <Line type="monotone" dataKey="rhr" name="Resting HR" stroke="#10b981" strokeWidth={2} />
                    <Line type="monotone" dataKey="stress" name="Stress %" stroke="#f43f5e" strokeWidth={2} />
                    <Line type="monotone" dataKey="recovery" name="Recovery %" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
            </ResponsiveContainer>
        </div>
        
        <div className="glass-pane p-4 h-80 flex flex-col">
            <h3 className="orbital-text-subheading mb-4">Energy Systems Performance</h3>
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={energyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="source" stroke="#9CA3AF" fontSize={12} />
                    <YAxis stroke="#9CA3AF" fontSize={12} unit="kWh" />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="input" name="Input" stackId="a" fill="#06b6d4" />
                    <Bar dataKey="output" name="Output" stackId="b" fill="#f59e0b" />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </div>

      {/* Frame 3: Asset + Health Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-pane p-4">
            <h3 className="orbital-text-subheading mb-4">Asset Status Log</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                    <TableRow className="border-gray-700 hover:bg-transparent">
                    <TableHead>Date</TableHead>
                    <TableHead>Asset</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Notes</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {assetLog.map((row, i) => (
                    <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                        <TableCell className="font-mono text-xs">{row.date}</TableCell>
                        <TableCell className="font-medium text-white">{row.asset}</TableCell>
                        <TableCell>{getStatusBadge(row.status)}</TableCell>
                        <TableCell>{row.value}</TableCell>
                        <TableCell>{row.notes}</TableCell>
                    </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
        </div>

        <div className="grid grid-rows-2 gap-6">
            <div className="glass-pane p-4">
                <h3 className="orbital-text-subheading mb-4">Estate Systems Log</h3>
                 <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-transparent"><TableHead>System</TableHead><TableHead>Status</TableHead></TableRow>
                    </TableHeader>
                    <TableBody>
                        {estateLog.map((row, i) => (
                        <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                            <TableCell className="font-medium text-white">{row.system}</TableCell>
                            <TableCell><div className="flex items-center space-x-2"><CheckCircle className="w-4 h-4 text-green-400" /><span>{row.status}</span></div></TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                 </Table>
            </div>
            <div className="glass-pane p-4">
                <h3 className="orbital-text-subheading mb-4">Personal Wellness Log</h3>
                 <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-transparent"><TableHead>Metric</TableHead><TableHead>Value</TableHead><TableHead>Status</TableHead></TableRow>
                    </TableHeader>
                    <TableBody>
                        {wellnessLog.map((row, i) => (
                        <TableRow key={i} className="border-gray-800 hover:bg-gray-800/30">
                            <TableCell className="font-medium text-white">{row.metric}</TableCell>
                            <TableCell>{row.value}</TableCell>
                            <TableCell>{getStatusBadge(row.status)}</TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                 </Table>
            </div>
        </div>
      </div>

    </div>
  );
}