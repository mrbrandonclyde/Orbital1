
import React, { useEffect, useRef } from 'react';
import { Network, Satellite, Globe, Zap, Shield, GitBranch } from 'lucide-react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";

const aetherMetrics = [
  { title: "Network Status", value: "OPERATIONAL", icon: Zap, color: "text-green-400" },
  { title: "Satellite Constellation", value: "77,000/77k", icon: Satellite, color: "text-cyan-400" },
  { title: "Global Coverage", value: "100%", icon: Globe, color: "text-blue-400" },
  { title: "Latency (Quantum)", value: "< 0.01ms", icon: GitBranch, color: "text-purple-400" },
  { title: "Security Level", value: "UNBREAKABLE", icon: Shield, color: "text-green-400" },
];

const networkSegments = [
  { id: 'orbital-leo', name: 'LEO Satellite Grid', status: 'ONLINE', traffic: '9.8 EB/s', threats_blocked: '1.2M' },
  { id: 'quantum-backbone', name: 'Quantum Entanglement Backbone', status: 'ONLINE', traffic: 'Instantaneous', threats_blocked: 'N/A' },
  { id: 'subterranean-fiber', name: 'Hardened Subterranean Fiber', status: 'ONLINE', traffic: '800 Tb/s', threats_blocked: '48k' },
  { id: 'interplanetary-link', name: 'Mars Relay Network', status: 'SYNCING', traffic: '120 Gb/s', threats_blocked: '1.2k' },
];

// Three.js globe component
function AetherGlobeCanvas() {
  const containerRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene, Camera, Renderer setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 7);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0xffffff, 1);
    pointLight.position.set(10, 10, 10);
    scene.add(pointLight);

    // Stars background
    const starGeom = new THREE.BufferGeometry();
    const starCount = 2000;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      starPos[i * 3] = (Math.random() * 2 - 1) * 200;
      starPos[i * 3 + 1] = (Math.random() * 2 - 1) * 200;
      starPos[i * 3 + 2] = (Math.random() * 2 - 1) * 200;
    }
    starGeom.setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.6, transparent: true, opacity: 0.8 });
    const stars = new THREE.Points(starGeom, starMat);
    scene.add(stars);

    // Globe group for rotation
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Wireframe sphere
    const globeGeom = new THREE.SphereGeometry(2.5, 64, 64);
    const globeMat = new THREE.MeshStandardMaterial({ color: new THREE.Color('#0c4a6e'), wireframe: true });
    const globeMesh = new THREE.Mesh(globeGeom, globeMat);
    globeGroup.add(globeMesh);

    // Cyan nodes on sphere surface
    const nodeGeom = new THREE.SphereGeometry(0.015, 8, 8);
    const nodeMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#06b6d4') });
    const nodeGroup = new THREE.Group();
    const N = 200;
    for (let i = 0; i < N; i++) {
      const phi = Math.acos(-1 + (2 * i) / (N - 1));
      const theta = Math.sqrt((N - 1) * Math.PI) * phi;
      const r = 2.6; // Slightly outside the main globe for visibility
      const x = r * Math.cos(theta) * Math.sin(phi);
      const y = r * Math.sin(theta) * Math.sin(phi);
      const z = r * Math.cos(phi);
      const node = new THREE.Mesh(nodeGeom, nodeMat);
      node.position.set(x, y, z);
      nodeGroup.add(node);
    }
    globeGroup.add(nodeGroup);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableZoom = true;
    controls.enablePan = false;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.5;

    let frameId;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      controls.update(); // Update controls for auto-rotation and damping
      renderer.render(scene, camera);
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (!container) return; // Defensive check
      const { clientWidth, clientHeight } = container;
      renderer.setSize(clientWidth, clientHeight);
      camera.aspect = clientWidth / clientHeight;
      camera.updateProjectionMatrix();
    };
    window.addEventListener('resize', handleResize);

    // Cleanup function on component unmount
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      controls.dispose(); // Dispose controls

      // Dispose geometries and materials to prevent memory leaks
      globeGeom.dispose();
      globeMat.dispose();
      nodeGeom.dispose();
      nodeMat.dispose();
      starGeom.dispose();
      starMat.dispose();
      ambientLight.dispose();
      pointLight.dispose();

      // Remove renderer's DOM element
      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose(); // Dispose renderer
    };
  }, []); // Empty dependency array ensures this effect runs once on mount and cleans up on unmount

  return (
    <div ref={containerRef} className="w-full h-[500px] rounded-xl overflow-hidden bg-black/20 relative">
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs tracking-widest text-cyan-400">
        AETHER NETWORK
      </div>
    </div>
  );
}

export default function AetherNetworkPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Network className="w-10 h-10 mr-3 text-cyan-400" />
            AETHER: The Quantum Internet
          </h1>
          <p className="orbital-text-subtitle">Private, quantum-entangled global network. Total information sovereignty.</p>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        {aetherMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 3D Network Visualization */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Live Network Visualization</h3>
          <AetherGlobeCanvas />
        </div>

        {/* Network Control Panel */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4">Network Control Panel</h3>
          <div className="space-y-4">
            <Card className="bg-gray-800/50">
              <CardHeader>
                <CardTitle className="text-lg">Zyra AI Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Dynamic Traffic Routing</span>
                  <Switch defaultChecked id="dynamic-routing" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Predictive Threat Neutralization</span>
                  <Switch defaultChecked id="predictive-threats" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Prioritize Guardian Corps Traffic</span>
                  <Switch id="priority-traffic" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50">
              <CardHeader>
                <CardTitle className="text-lg">Information Sovereignty Protocols</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Global Information Filtering</span>
                  <Switch id="info-filtering" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Isolate Hostile Region (APAC-East)</span>
                  <Switch id="isolate-region" />
                </div>
                 <div className="flex items-center justify-between">
                  <span className="text-gray-300">Activate 'Silent Running' Mode</span>
                  <Switch id="silent-running" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Network Segment Status */}
      <div className="glass-pane p-4 mt-6">
        <h3 className="orbital-text-subheading mb-4">Network Segment Status</h3>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-transparent">
                <TableHead className="text-gray-400">Segment</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">Live Traffic</TableHead>
                <TableHead className="text-gray-400">Threats Blocked (24h)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {networkSegments.map((segment) => (
                <TableRow key={segment.id} className="border-gray-800 hover:bg-gray-800/30">
                  <TableCell className="font-medium text-white">{segment.name}</TableCell>
                  <TableCell>
                    <Badge className={segment.status === 'ONLINE' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}>{segment.status}</Badge>
                  </TableCell>
                  <TableCell className="text-cyan-400">{segment.traffic}</TableCell>
                  <TableCell className="text-red-400">{segment.threats_blocked}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
