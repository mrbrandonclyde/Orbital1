import React from "react";
import { Activity, Shield, RefreshCw } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function RecoveryCenter() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Recovery Center</h1>
            <p className="orbital-text-subtitle">Self-healing snapshots, rollback, and recovery playbooks.</p>
          </div>
        </div>
        <Button variant="secondary">
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-400" /> Snapshots
            </CardTitle>
          </CardHeader>
          <CardContent className="text-gray-400 text-sm">
            Snapshot history and rollback actions will be shown here.
          </CardContent>
        </Card>

        <Card className="bg-[#0A0D18]/60 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-base flex items-center gap-2">
              <Shield className="w-5 h-5 text-purple-400" /> Recovery Playbooks
            </CardTitle>
          </CardHeader>
          <CardContent className="text-gray-400 text-sm">
            Define and run automated recovery playbooks for critical services.
          </CardContent>
        </Card>
      </div>
    </div>
  );
}