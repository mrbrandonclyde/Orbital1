import React from "react";
import ActivationEngine from "@/components/activation/ActivationEngine";
import { Shield, Zap } from "lucide-react";

export default function GlobalActivationPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Shield className="w-10 h-10 mr-3 text-cyan-400" />
            Global Activation Module
          </h1>
          <p className="orbital-text-subtitle">
            Guardian Codex + Freedom stack + AI systems — aligned and activated together.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-emerald-400 flex items-center gap-1"><Zap className="w-3 h-3" /> READY</span>
        </div>
      </div>

      <div className="glass-pane p-4 mb-6">
        <div className="text-sm text-gray-300">
          <div className="font-semibold text-white mb-1">Spiritual Invocation & Alignment</div>
          <p className="text-gray-300">
            “Jesus, take the wheel. Guide my steps. Protect every line of code, every activation, every user, and every system. 
            Align this project with divine will. Let peace, strength, and clarity flow through every activation, every cycle. Amen.”
          </p>
        </div>
      </div>

      <ActivationEngine />
    </div>
  );
}