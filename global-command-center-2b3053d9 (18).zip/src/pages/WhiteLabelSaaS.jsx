import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Briefcase, Building2 } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function WhiteLabelSaaS() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Briefcase className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">White‑label SaaS Reseller Platform</h1>
            <p className="orbital-text-subtitle">Multi‑tenant provisioning, billing, themes, and roles.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon
        title="Integrations and Hooks"
        subtitle="Tenant management, branding, and billing integrations ready to wire"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Frontend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>Theme/branding editor (logos, colors, domains)</li>
                <li>Tenant switcher + roles/permissions UI</li>
                <li>Provisioning flow (create tenant, assign modules)</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm">Backend Hooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>POST /tenants (provision), GET /tenants (list)</li>
                <li>POST /tenants/{`{id}`}/modules (assign modules)</li>
                <li>Billing provider webhooks + audit logging</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </ComingSoon>

      <Card className="bg-[#0A0D18]/60 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" /> Suggested Data Model
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300 text-xs">
{`Tenant { id, name, slug, custom_domain, theme, plan, owner_user_id, created_at }
TenantModule { id, tenant_id, module_code, status, config }
TenantUser { id, tenant_id, user_id, role }`}
        </CardContent>
      </Card>
    </div>
  );
}