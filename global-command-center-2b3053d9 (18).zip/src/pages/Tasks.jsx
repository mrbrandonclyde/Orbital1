import React, { useState, useCallback, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { Task } from "@/api/entities";
import { User } from "@/api/entities";
import { Mission } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Plus, Gavel } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import TaskForm from '../components/tasks/TaskForm';
import TaskCard from '../components/tasks/TaskCard';
import EmptyState from '../components/common/EmptyState';

function useMissionId() {
  const { search } = useLocation();
  return useMemo(() => new URLSearchParams(search).get('missionId'), [search]);
}

export default function TasksPage() {
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const missionId = useMissionId();

  const queryFn = useCallback(async () => {
    const filter = missionId ? { mission_id: missionId } : {};
    const [tasks, users, missions] = await Promise.all([
      Task.filter(filter, '-created_date', 50),
      User.list(),
      Mission.list()
    ]);
    return { tasks, users, missions };
  }, [missionId]);

  const { data, loading, error, refetch } = useQuery(queryFn, { dependencies: [missionId] });

  const userMap = useMemo(() => Object.fromEntries(data?.users.map(u => [u.id, u]) || []), [data?.users]);
  const missionMap = useMemo(() => Object.fromEntries(data?.missions.map(m => [m.id, m]) || []), [data?.missions]);
  
  const handleEdit = (task) => {
    setEditingTask(task);
    setShowForm(true);
  };
  
  const handleSuccess = () => {
    setShowForm(false);
    setEditingTask(null);
    refetch();
  };

  const pageTitle = missionId ? `Tasks for ${missionMap[missionId]?.mission_name || 'Mission'}` : 'All Task Assignments';

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text">{pageTitle}</h1>
          <p className="text-lg text-gray-400 mt-2">Coordinate and track all operational tasks.</p>
        </div>
        <Dialog open={showForm} onOpenChange={(isOpen) => { setShowForm(isOpen); if (!isOpen) setEditingTask(null); }}>
          <DialogTrigger asChild>
            <button className="orbital-button-primary flex items-center space-x-2">
              <Plus size={18} />
              <span>New Task</span>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-[#0A0D18] border-[#151823] text-white">
            <DialogHeader>
              <DialogTitle className="orbital-gradient-text text-2xl">{editingTask ? 'Edit Task' : 'Create New Task'}</DialogTitle>
            </DialogHeader>
            <TaskForm task={editingTask} onSuccess={handleSuccess} missionId={missionId} />
          </DialogContent>
        </Dialog>
      </div>

      {loading && <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div></div>}
      {error && <p className="text-red-500">Failed to load tasks.</p>}
      
      {!loading && !error && (
        data?.tasks.length > 0 ? (
          <div className="space-y-6">
            {data.tasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task} 
                onEdit={handleEdit} 
                assignedUser={userMap[task.assigned_to]}
                mission={missionMap[task.mission_id]}
              />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Gavel}
            title="No Tasks Found"
            subtitle={missionId ? 'This mission has no tasks yet. Create one to get started.' : 'No tasks have been assigned. Create a task to begin.'}
          />
        )
      )}
    </div>
  );
}