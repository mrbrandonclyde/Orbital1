import React, { useState, useCallback } from 'react';
import { User } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { CreditCard, TrendingUp, Zap, Crown, CheckCircle, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import TierComparisonModal from '../components/billing/TierComparisonModal';
import UsageMeter from '../components/billing/UsageMeter';

const SUBSCRIPTION_TIERS = {
  BASIC: {
    price: 99,
    name: 'Basic',
    icon: CreditCard,
    color: 'text-gray-400',
    features: ['2 Sectors', '100 API Calls/month', 'Basic Reports', 'Email Support']
  },
  PROFESSIONAL: {
    price: 299,
    name: 'Professional', 
    icon: Zap,
    color: 'text-blue-400',
    features: ['5 Sectors', '1000 API Calls/month', 'AI Intelligence Hub', 'Premium Reports', 'Priority Support']
  },
  ENTERPRISE: {
    price: 999,
    name: 'Enterprise',
    icon: Crown,
    color: 'text-purple-400',
    features: ['Unlimited Sectors', 'Unlimited API Calls', 'VR War Room', 'White-label Branding', 'Dedicated Support']
  },
  GOVERNMENT: {
    price: 'Custom',
    name: 'Government',
    icon: Crown,
    color: 'text-red-400',
    features: ['Full Platform Access', 'Custom Compliance', 'On-Premise Deployment', '24/7 Support', 'Security Clearance']
  }
};

export default function BillingPage() {
  const [showTierModal, setShowTierModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const queryFn = useCallback(async () => {
    const user = await User.me();
    setCurrentUser(user);
    
    // Simulate billing data
    return {
      currentPlan: user.subscription_tier || 'BASIC',
      billingCycle: 'monthly',
      nextBillingDate: '2024-02-01',
      invoices: [
        { id: 1, date: '2024-01-01', amount: '$299.00', status: 'paid' },
        { id: 2, date: '2023-12-01', amount: '$299.00', status: 'paid' },
        { id: 3, date: '2023-11-01', amount: '$299.00', status: 'paid' }
      ],
      usage: {
        apiCalls: user.api_calls_used || 0,
        apiLimit: user.api_usage_limit || 100,
        sectorsUsed: user.licensed_sectors?.length || 0,
        vrSessions: 12,
        reportsGenerated: 8
      }
    };
  }, []);

  const { data: billingData, loading } = useQuery(queryFn);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const currentTier = SUBSCRIPTION_TIERS[billingData?.currentPlan] || SUBSCRIPTION_TIERS.BASIC;
  const Icon = currentTier.icon;

  return (
    <div className="animate-fade-in space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text">Billing & Subscriptions</h1>
          <p className="text-lg text-gray-400 mt-2">Manage your subscription, usage, and billing information.</p>
        </div>
        <button 
          onClick={() => setShowTierModal(true)}
          className="orbital-button-primary"
        >
          Upgrade Plan
        </button>
      </div>

      {/* Current Plan */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-white">
            <Icon className={`w-5 h-5 ${currentTier.color}`} />
            <span>Current Plan: {currentTier.name}</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-gray-400 text-sm">Monthly Cost</p>
              <p className="text-2xl font-bold text-white">
                {typeof currentTier.price === 'number' ? `$${currentTier.price}` : currentTier.price}
              </p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Next Billing</p>
              <p className="text-lg font-semibold text-white">{billingData?.nextBillingDate}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Status</p>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-green-400 font-semibold">Active</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h4 className="text-white font-semibold mb-3">Plan Features</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {currentTier.features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <UsageMeter
          title="API Calls"
          used={billingData?.usage.apiCalls}
          limit={billingData?.usage.apiLimit}
          type="api"
        />
        <UsageMeter
          title="Sectors"
          used={billingData?.usage.sectorsUsed}
          limit={currentUser?.subscription_tier === 'BASIC' ? 2 : currentUser?.subscription_tier === 'PROFESSIONAL' ? 5 : -1}
          type="storage"
        />
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-4">
          <p className="text-gray-400 text-sm">VR Sessions</p>
          <p className="text-2xl font-bold text-purple-400">{billingData?.usage.vrSessions}</p>
          <p className="text-xs text-gray-500 mt-1">This month</p>
        </div>
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-4">
          <p className="text-gray-400 text-sm">Reports Generated</p>
          <p className="text-2xl font-bold text-blue-400">{billingData?.usage.reportsGenerated}</p>
          <p className="text-xs text-gray-500 mt-1">This month</p>
        </div>
      </div>

      {/* Billing History */}
      <Card className="bg-[#0A0D18]/50 border-[#151823]">
        <CardHeader>
          <CardTitle className="text-white">Billing History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-2 text-gray-400">Date</th>
                  <th className="text-left py-2 text-gray-400">Amount</th>
                  <th className="text-left py-2 text-gray-400">Status</th>
                  <th className="text-left py-2 text-gray-400">Actions</th>
                </tr>
              </thead>
              <tbody>
                {billingData?.invoices.map(invoice => (
                  <tr key={invoice.id} className="border-b border-gray-800">
                    <td className="py-3 text-white">{invoice.date}</td>
                    <td className="py-3 text-white">{invoice.amount}</td>
                    <td className="py-3">
                      <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-sm">
                        {invoice.status}
                      </span>
                    </td>
                    <td className="py-3">
                      <button className="text-blue-400 hover:text-blue-300 text-sm">
                        Download
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Tier Comparison Modal */}
      <TierComparisonModal
        isOpen={showTierModal}
        onClose={() => setShowTierModal(false)}
        currentTier={billingData?.currentPlan}
      />
    </div>
  );
}