import React, { useState, useCallback } from 'react';
import { ExecutiveEvent } from "@/api/entities";
import { useQuery } from "../components/lib/useQuery";
import { Plus, Calendar } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import EventForm from '../components/schedule/EventForm';
import CalendarView from '../components/schedule/CalendarView';
import EmptyState from '../components/common/EmptyState';

export default function SchedulePage() {
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);

  const queryFn = useCallback(() => ExecutiveEvent.list('-start_date_time', 200), []);
  const { data: events, loading, error, refetch } = useQuery(queryFn);

  const handleEdit = (event) => {
    setEditingEvent(event);
    setSelectedDate(null);
    setShowForm(true);
  };
  
  const handleDayClick = (day) => {
    setEditingEvent(null);
    setSelectedDate(day);
    setShowForm(true);
  }

  const handleSuccess = () => {
    setShowForm(false);
    setEditingEvent(null);
    setSelectedDate(null);
    refetch();
  };

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Calendar className="w-10 h-10 mr-3 text-purple-400" />
            Executive Schedule
          </h1>
          <p className="orbital-text-subtitle">Manage all high-level meetings and events.</p>
        </div>
        <Dialog open={showForm} onOpenChange={(isOpen) => { setShowForm(isOpen); if (!isOpen) { setEditingEvent(null); setSelectedDate(null); } }}>
          <DialogTrigger asChild>
            <button className="orbital-button-primary flex items-center space-x-2">
              <Plus size={18} />
              <span>New Event</span>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-[#0A0D18] border-[#151823] text-white">
            <DialogHeader>
              <DialogTitle className="orbital-gradient-text text-2xl">{editingEvent ? 'Edit Executive Event' : 'Schedule New Event'}</DialogTitle>
            </DialogHeader>
            <EventForm
              event={editingEvent}
              selectedDate={selectedDate}
              onSuccess={handleSuccess}
            />
          </DialogContent>
        </Dialog>
      </div>

      {loading && <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div></div>}
      {error && <p className="text-red-500">Failed to load schedule.</p>}
      
      {!loading && !error && events && (
        events.length > 0 ? (
          <CalendarView 
            events={events}
            onDayClick={handleDayClick}
            onEventClick={handleEdit}
          />
        ) : (
          <EmptyState 
            icon={Calendar}
            title="No Events Scheduled"
            subtitle="The calendar is clear. Schedule a new event to get started."
          />
        )
      )}
    </div>
  );
}