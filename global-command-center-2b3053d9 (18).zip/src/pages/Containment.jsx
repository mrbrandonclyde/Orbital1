import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AlertTriangle, Shield, Dna } from "lucide-react";

export default function ContainmentPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <AlertTriangle className="w-10 h-10 mr-3 text-red-400" />
          Containment
        </h1>
        <p className="orbital-text-subtitle">Cyber, Bio, and Geo threats.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('SecurityCenter')} className="glass-pane p-6 hover:border-red-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">Cyber Defense</h3>
          </div>
          <p className="text-gray-400 text-sm">SOC dashboards & response.</p>
        </Link>

        <Link to={createPageUrl('BioSymbiosis')} className="glass-pane p-6 hover:border-red-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Dna className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Bio Threats</h3>
          </div>
          <p className="text-gray-400 text-sm">Bio-safety and monitoring.</p>
        </Link>

        <Link to={createPageUrl('ThreatAssessment')} className="glass-pane p-6 hover:border-red-500/40">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white font-semibold">Geo Threats</h3>
          </div>
          <p className="text-gray-400 text-sm">Global threat intelligence.</p>
        </Link>
      </div>
    </div>
  );
}