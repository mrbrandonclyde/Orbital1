import Layout from "./Layout.jsx";

import Alerts from "./Alerts";

import Schedule from "./Schedule";

import SupplyChain from "./SupplyChain";

import AuditTrail from "./AuditTrail";

import Analytics from "./Analytics";

import GlobalMap from "./GlobalMap";

import SystemStatus from "./SystemStatus";

import ThreatAssessment from "./ThreatAssessment";

import Reports from "./Reports";

import Missions from "./Missions";

import Tasks from "./Tasks";

import Personnel from "./Personnel";

import Sectors from "./Sectors";

import Communications from "./Communications";

import DataSources from "./DataSources";

import Admin from "./Admin";

import SectorMonitoring from "./SectorMonitoring";

import Choropleth from "./Choropleth";

import GlobalCommandOps from "./GlobalCommandOps";

import Assets from "./Assets";

import Documentation from "./Documentation";

import Financials from "./Financials";

import SecurityCenter from "./SecurityCenter";

import ComplianceCenter from "./ComplianceCenter";

import Billing from "./Billing";

import DataIngestion from "./DataIngestion";

import Executive from "./Executive";

import CommandCenter from "./CommandCenter";

import GuardianCorps from "./GuardianCorps";

import GuardianOps from "./GuardianOps";

import InterplanetaryOps from "./InterplanetaryOps";

import BioSymbiosis from "./BioSymbiosis";

import GlobalGovernance from "./GlobalGovernance";

import VRWarRoom from "./VRWarRoom";

import Mansion from "./Mansion";

import PlanetaryDefense from "./PlanetaryDefense";

import Colonization from "./Colonization";

import Bank from "./Bank";

import Insights from "./Insights";

import Support from "./Support";

import Blockchain from "./Blockchain";

import BlockchainStrategy from "./BlockchainStrategy";

import TeamChat from "./TeamChat";

import AIAgents from "./AIAgents";

import FeedbackDashboard from "./FeedbackDashboard";

import NotificationCenter from "./NotificationCenter";

import Rewards from "./Rewards";

import QuantumComms from "./QuantumComms";

import SimulationEngine from "./SimulationEngine";

import InformationWarfare from "./InformationWarfare";

import ResearchIntel from "./ResearchIntel";

import AetherNetwork from "./AetherNetwork";

import ZyraCommand from "./ZyraCommand";

import UrbanPlanner from "./UrbanPlanner";

import KnowledgeVault from "./KnowledgeVault";

import AISettings from "./AISettings";

import AccessDiagnostics from "./AccessDiagnostics";

import Orchestrator from "./Orchestrator";

import Avatars from "./Avatars";

import DefenseSecurity from "./DefenseSecurity";

import ResilienceSystems from "./ResilienceSystems";

import Expansion from "./Expansion";

import Containment from "./Containment";

import Continuity from "./Continuity";

import SpaceOps from "./SpaceOps";

import Symbiosis from "./Symbiosis";

import Civilization from "./Civilization";

import Federation from "./Federation";

import AdminExecutive from "./AdminExecutive";

import PromptStudio from "./PromptStudio";

import WorkflowBuilder from "./WorkflowBuilder";

import AIObservability from "./AIObservability";

import BuildKanban from "./BuildKanban";

import Funnels from "./Funnels";

import FunnelEditor from "./FunnelEditor";

import FunnelDashboard from "./FunnelDashboard";

import FunnelWizard from "./FunnelWizard";

import FunnelPages from "./FunnelPages";

import FunnelAutomation from "./FunnelAutomation";

import CRM from "./CRM";

import BackendStatus from "./BackendStatus";

import UsersBackend from "./UsersBackend";

import QueueTask from "./QueueTask";

import BlockchainBalance from "./BlockchainBalance";

import AIFunnelBuilder from "./AIFunnelBuilder";

import AIAssets from "./AIAssets";

import FunnelVRAR from "./FunnelVRAR";

import VoiceFunnels from "./VoiceFunnels";

import TemplateMarketplace from "./TemplateMarketplace";

import WhiteLabelSaaS from "./WhiteLabelSaaS";

import FunnelMasterPlan from "./FunnelMasterPlan";

import Commerce from "./Commerce";

import FunnelIntegrations from "./FunnelIntegrations";

import FunnelSettings from "./FunnelSettings";

import FunnelAudit from "./FunnelAudit";

import AppRoot from "./AppRoot";

import Phase1Dashboard from "./Phase1Dashboard";

import Phase1Accounts from "./Phase1Accounts";

import Phase1Transactions from "./Phase1Transactions";

import Phase1CreditCards from "./Phase1CreditCards";

import Phase1LoansMortgages from "./Phase1LoansMortgages";

import Phase1Investments from "./Phase1Investments";

import Phase1Analytics from "./Phase1Analytics";

import Phase1Compliance from "./Phase1Compliance";

import Phase1RiskAlerts from "./Phase1RiskAlerts";

import Phase1Reports from "./Phase1Reports";

import Phase1Settings from "./Phase1Settings";

import AdminPhase1Dashboard from "./AdminPhase1Dashboard";

import Phase0Alignment from "./Phase0Alignment";

import Phase1Core from "./Phase1Core";

import RecoveryCenter from "./RecoveryCenter";

import OrbitalBrowser from "./OrbitalBrowser";

import FunnelAnalytics from "./FunnelAnalytics";

import GuardianCodex from "./GuardianCodex";

import GlobalActivation from "./GlobalActivation";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Alerts: Alerts,
    
    Schedule: Schedule,
    
    SupplyChain: SupplyChain,
    
    AuditTrail: AuditTrail,
    
    Analytics: Analytics,
    
    GlobalMap: GlobalMap,
    
    SystemStatus: SystemStatus,
    
    ThreatAssessment: ThreatAssessment,
    
    Reports: Reports,
    
    Missions: Missions,
    
    Tasks: Tasks,
    
    Personnel: Personnel,
    
    Sectors: Sectors,
    
    Communications: Communications,
    
    DataSources: DataSources,
    
    Admin: Admin,
    
    SectorMonitoring: SectorMonitoring,
    
    Choropleth: Choropleth,
    
    GlobalCommandOps: GlobalCommandOps,
    
    Assets: Assets,
    
    Documentation: Documentation,
    
    Financials: Financials,
    
    SecurityCenter: SecurityCenter,
    
    ComplianceCenter: ComplianceCenter,
    
    Billing: Billing,
    
    DataIngestion: DataIngestion,
    
    Executive: Executive,
    
    CommandCenter: CommandCenter,
    
    GuardianCorps: GuardianCorps,
    
    GuardianOps: GuardianOps,
    
    InterplanetaryOps: InterplanetaryOps,
    
    BioSymbiosis: BioSymbiosis,
    
    GlobalGovernance: GlobalGovernance,
    
    VRWarRoom: VRWarRoom,
    
    Mansion: Mansion,
    
    PlanetaryDefense: PlanetaryDefense,
    
    Colonization: Colonization,
    
    Bank: Bank,
    
    Insights: Insights,
    
    Support: Support,
    
    Blockchain: Blockchain,
    
    BlockchainStrategy: BlockchainStrategy,
    
    TeamChat: TeamChat,
    
    AIAgents: AIAgents,
    
    FeedbackDashboard: FeedbackDashboard,
    
    NotificationCenter: NotificationCenter,
    
    Rewards: Rewards,
    
    QuantumComms: QuantumComms,
    
    SimulationEngine: SimulationEngine,
    
    InformationWarfare: InformationWarfare,
    
    ResearchIntel: ResearchIntel,
    
    AetherNetwork: AetherNetwork,
    
    ZyraCommand: ZyraCommand,
    
    UrbanPlanner: UrbanPlanner,
    
    KnowledgeVault: KnowledgeVault,
    
    AISettings: AISettings,
    
    AccessDiagnostics: AccessDiagnostics,
    
    Orchestrator: Orchestrator,
    
    Avatars: Avatars,
    
    DefenseSecurity: DefenseSecurity,
    
    ResilienceSystems: ResilienceSystems,
    
    Expansion: Expansion,
    
    Containment: Containment,
    
    Continuity: Continuity,
    
    SpaceOps: SpaceOps,
    
    Symbiosis: Symbiosis,
    
    Civilization: Civilization,
    
    Federation: Federation,
    
    AdminExecutive: AdminExecutive,
    
    PromptStudio: PromptStudio,
    
    WorkflowBuilder: WorkflowBuilder,
    
    AIObservability: AIObservability,
    
    BuildKanban: BuildKanban,
    
    Funnels: Funnels,
    
    FunnelEditor: FunnelEditor,
    
    FunnelDashboard: FunnelDashboard,
    
    FunnelWizard: FunnelWizard,
    
    FunnelPages: FunnelPages,
    
    FunnelAutomation: FunnelAutomation,
    
    CRM: CRM,
    
    BackendStatus: BackendStatus,
    
    UsersBackend: UsersBackend,
    
    QueueTask: QueueTask,
    
    BlockchainBalance: BlockchainBalance,
    
    AIFunnelBuilder: AIFunnelBuilder,
    
    AIAssets: AIAssets,
    
    FunnelVRAR: FunnelVRAR,
    
    VoiceFunnels: VoiceFunnels,
    
    TemplateMarketplace: TemplateMarketplace,
    
    WhiteLabelSaaS: WhiteLabelSaaS,
    
    FunnelMasterPlan: FunnelMasterPlan,
    
    Commerce: Commerce,
    
    FunnelIntegrations: FunnelIntegrations,
    
    FunnelSettings: FunnelSettings,
    
    FunnelAudit: FunnelAudit,
    
    AppRoot: AppRoot,
    
    Phase1Dashboard: Phase1Dashboard,
    
    Phase1Accounts: Phase1Accounts,
    
    Phase1Transactions: Phase1Transactions,
    
    Phase1CreditCards: Phase1CreditCards,
    
    Phase1LoansMortgages: Phase1LoansMortgages,
    
    Phase1Investments: Phase1Investments,
    
    Phase1Analytics: Phase1Analytics,
    
    Phase1Compliance: Phase1Compliance,
    
    Phase1RiskAlerts: Phase1RiskAlerts,
    
    Phase1Reports: Phase1Reports,
    
    Phase1Settings: Phase1Settings,
    
    AdminPhase1Dashboard: AdminPhase1Dashboard,
    
    Phase0Alignment: Phase0Alignment,
    
    Phase1Core: Phase1Core,
    
    RecoveryCenter: RecoveryCenter,
    
    OrbitalBrowser: OrbitalBrowser,
    
    FunnelAnalytics: FunnelAnalytics,
    
    GuardianCodex: GuardianCodex,
    
    GlobalActivation: GlobalActivation,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Alerts />} />
                
                
                <Route path="/Alerts" element={<Alerts />} />
                
                <Route path="/Schedule" element={<Schedule />} />
                
                <Route path="/SupplyChain" element={<SupplyChain />} />
                
                <Route path="/AuditTrail" element={<AuditTrail />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/GlobalMap" element={<GlobalMap />} />
                
                <Route path="/SystemStatus" element={<SystemStatus />} />
                
                <Route path="/ThreatAssessment" element={<ThreatAssessment />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Missions" element={<Missions />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/Personnel" element={<Personnel />} />
                
                <Route path="/Sectors" element={<Sectors />} />
                
                <Route path="/Communications" element={<Communications />} />
                
                <Route path="/DataSources" element={<DataSources />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/SectorMonitoring" element={<SectorMonitoring />} />
                
                <Route path="/Choropleth" element={<Choropleth />} />
                
                <Route path="/GlobalCommandOps" element={<GlobalCommandOps />} />
                
                <Route path="/Assets" element={<Assets />} />
                
                <Route path="/Documentation" element={<Documentation />} />
                
                <Route path="/Financials" element={<Financials />} />
                
                <Route path="/SecurityCenter" element={<SecurityCenter />} />
                
                <Route path="/ComplianceCenter" element={<ComplianceCenter />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/DataIngestion" element={<DataIngestion />} />
                
                <Route path="/Executive" element={<Executive />} />
                
                <Route path="/CommandCenter" element={<CommandCenter />} />
                
                <Route path="/GuardianCorps" element={<GuardianCorps />} />
                
                <Route path="/GuardianOps" element={<GuardianOps />} />
                
                <Route path="/InterplanetaryOps" element={<InterplanetaryOps />} />
                
                <Route path="/BioSymbiosis" element={<BioSymbiosis />} />
                
                <Route path="/GlobalGovernance" element={<GlobalGovernance />} />
                
                <Route path="/VRWarRoom" element={<VRWarRoom />} />
                
                <Route path="/Mansion" element={<Mansion />} />
                
                <Route path="/PlanetaryDefense" element={<PlanetaryDefense />} />
                
                <Route path="/Colonization" element={<Colonization />} />
                
                <Route path="/Bank" element={<Bank />} />
                
                <Route path="/Insights" element={<Insights />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/Blockchain" element={<Blockchain />} />
                
                <Route path="/BlockchainStrategy" element={<BlockchainStrategy />} />
                
                <Route path="/TeamChat" element={<TeamChat />} />
                
                <Route path="/AIAgents" element={<AIAgents />} />
                
                <Route path="/FeedbackDashboard" element={<FeedbackDashboard />} />
                
                <Route path="/NotificationCenter" element={<NotificationCenter />} />
                
                <Route path="/Rewards" element={<Rewards />} />
                
                <Route path="/QuantumComms" element={<QuantumComms />} />
                
                <Route path="/SimulationEngine" element={<SimulationEngine />} />
                
                <Route path="/InformationWarfare" element={<InformationWarfare />} />
                
                <Route path="/ResearchIntel" element={<ResearchIntel />} />
                
                <Route path="/AetherNetwork" element={<AetherNetwork />} />
                
                <Route path="/ZyraCommand" element={<ZyraCommand />} />
                
                <Route path="/UrbanPlanner" element={<UrbanPlanner />} />
                
                <Route path="/KnowledgeVault" element={<KnowledgeVault />} />
                
                <Route path="/AISettings" element={<AISettings />} />
                
                <Route path="/AccessDiagnostics" element={<AccessDiagnostics />} />
                
                <Route path="/Orchestrator" element={<Orchestrator />} />
                
                <Route path="/Avatars" element={<Avatars />} />
                
                <Route path="/DefenseSecurity" element={<DefenseSecurity />} />
                
                <Route path="/ResilienceSystems" element={<ResilienceSystems />} />
                
                <Route path="/Expansion" element={<Expansion />} />
                
                <Route path="/Containment" element={<Containment />} />
                
                <Route path="/Continuity" element={<Continuity />} />
                
                <Route path="/SpaceOps" element={<SpaceOps />} />
                
                <Route path="/Symbiosis" element={<Symbiosis />} />
                
                <Route path="/Civilization" element={<Civilization />} />
                
                <Route path="/Federation" element={<Federation />} />
                
                <Route path="/AdminExecutive" element={<AdminExecutive />} />
                
                <Route path="/PromptStudio" element={<PromptStudio />} />
                
                <Route path="/WorkflowBuilder" element={<WorkflowBuilder />} />
                
                <Route path="/AIObservability" element={<AIObservability />} />
                
                <Route path="/BuildKanban" element={<BuildKanban />} />
                
                <Route path="/Funnels" element={<Funnels />} />
                
                <Route path="/FunnelEditor" element={<FunnelEditor />} />
                
                <Route path="/FunnelDashboard" element={<FunnelDashboard />} />
                
                <Route path="/FunnelWizard" element={<FunnelWizard />} />
                
                <Route path="/FunnelPages" element={<FunnelPages />} />
                
                <Route path="/FunnelAutomation" element={<FunnelAutomation />} />
                
                <Route path="/CRM" element={<CRM />} />
                
                <Route path="/BackendStatus" element={<BackendStatus />} />
                
                <Route path="/UsersBackend" element={<UsersBackend />} />
                
                <Route path="/QueueTask" element={<QueueTask />} />
                
                <Route path="/BlockchainBalance" element={<BlockchainBalance />} />
                
                <Route path="/AIFunnelBuilder" element={<AIFunnelBuilder />} />
                
                <Route path="/AIAssets" element={<AIAssets />} />
                
                <Route path="/FunnelVRAR" element={<FunnelVRAR />} />
                
                <Route path="/VoiceFunnels" element={<VoiceFunnels />} />
                
                <Route path="/TemplateMarketplace" element={<TemplateMarketplace />} />
                
                <Route path="/WhiteLabelSaaS" element={<WhiteLabelSaaS />} />
                
                <Route path="/FunnelMasterPlan" element={<FunnelMasterPlan />} />
                
                <Route path="/Commerce" element={<Commerce />} />
                
                <Route path="/FunnelIntegrations" element={<FunnelIntegrations />} />
                
                <Route path="/FunnelSettings" element={<FunnelSettings />} />
                
                <Route path="/FunnelAudit" element={<FunnelAudit />} />
                
                <Route path="/AppRoot" element={<AppRoot />} />
                
                <Route path="/Phase1Dashboard" element={<Phase1Dashboard />} />
                
                <Route path="/Phase1Accounts" element={<Phase1Accounts />} />
                
                <Route path="/Phase1Transactions" element={<Phase1Transactions />} />
                
                <Route path="/Phase1CreditCards" element={<Phase1CreditCards />} />
                
                <Route path="/Phase1LoansMortgages" element={<Phase1LoansMortgages />} />
                
                <Route path="/Phase1Investments" element={<Phase1Investments />} />
                
                <Route path="/Phase1Analytics" element={<Phase1Analytics />} />
                
                <Route path="/Phase1Compliance" element={<Phase1Compliance />} />
                
                <Route path="/Phase1RiskAlerts" element={<Phase1RiskAlerts />} />
                
                <Route path="/Phase1Reports" element={<Phase1Reports />} />
                
                <Route path="/Phase1Settings" element={<Phase1Settings />} />
                
                <Route path="/AdminPhase1Dashboard" element={<AdminPhase1Dashboard />} />
                
                <Route path="/Phase0Alignment" element={<Phase0Alignment />} />
                
                <Route path="/Phase1Core" element={<Phase1Core />} />
                
                <Route path="/RecoveryCenter" element={<RecoveryCenter />} />
                
                <Route path="/OrbitalBrowser" element={<OrbitalBrowser />} />
                
                <Route path="/FunnelAnalytics" element={<FunnelAnalytics />} />
                
                <Route path="/GuardianCodex" element={<GuardianCodex />} />
                
                <Route path="/GlobalActivation" element={<GlobalActivation />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}