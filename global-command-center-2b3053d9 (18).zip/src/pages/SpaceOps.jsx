import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Rocket, Shield, Map } from "lucide-react";

export default function SpaceOpsPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Rocket className="w-10 h-10 mr-3 text-cyan-400" />
          Space Ops
        </h1>
        <p className="orbital-text-subtitle">Defense, Colonization, Logistics, Continuity.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('PlanetaryDefense')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-semibold">Defense</h3>
          </div>
          <p className="text-gray-400 text-sm">Threat detection and neutralization.</p>
        </Link>

        <Link to={createPageUrl('Colonization')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Rocket className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Colonization</h3>
          </div>
          <p className="text-gray-400 text-sm">Settlement growth and sustainability.</p>
        </Link>

        <Link to={createPageUrl('InterplanetaryOps')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Map className="w-5 h-5 text-blue-400" />
            <h3 className="text-white font-semibold">Logistics</h3>
          </div>
          <p className="text-gray-400 text-sm">Missions and supply chains across space.</p>
        </Link>
      </div>
    </div>
  );
}