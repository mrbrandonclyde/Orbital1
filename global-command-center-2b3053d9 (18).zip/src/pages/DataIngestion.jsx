import React from 'react';
import DataIngestionEngine from '../components/ingestion/DataIngestionEngine';
import AutoDataLoader from '../components/ingestion/AutoDataLoader';
import { Database, UploadCloud } from 'lucide-react';

export default function DataIngestionPage() {
  return (
    <div className="animate-fade-in space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text flex items-center">
            <Database className="w-10 h-10 mr-3 text-cyan-400" />
            Data Ingestion & Seeding
          </h1>
          <p className="text-lg text-gray-400 mt-2">
            Manage real-time data pipelines and perform initial data seeding.
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          <AutoDataLoader />
        </div>
        <div className="space-y-8">
           <DataIngestionEngine />
        </div>
      </div>
    </div>
  );
}