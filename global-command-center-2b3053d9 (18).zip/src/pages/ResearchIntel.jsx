import React, { useState } from 'react';
import { Search, Lightbulb, Users, TrendingUp, FileText, Beaker, Shield, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const researchMetrics = [
  { title: "Active Patents", value: "47.2K", icon: Lightbulb, color: "text-cyan-400" },
  { title: "Research Labs", value: "1,847", icon: Beaker, color: "text-purple-400" },
  { title: "Breakthrough Predictions", value: "23", icon: TrendingUp, color: "text-green-400" },
  { title: "Corporate R&D Budget", value: "$2.8T", icon: Zap, color: "text-yellow-400" },
];

const breakthroughPredictions = [
  { 
    technology: 'Quantum Computing', 
    breakthrough_probability: 87,
    timeline: '18 months',
    impact: 'REVOLUTIONARY',
    key_players: ['IBM', 'Google', 'Rigetti'],
    investment: '$4.2B'
  },
  { 
    technology: 'Room Temperature Superconductors', 
    breakthrough_probability: 23,
    timeline: '5-7 years',
    impact: 'TRANSFORMATIONAL',
    key_players: ['MIT', 'University of Rochester', 'Korean Advanced Institute'],
    investment: '$890M'
  },
  { 
    technology: 'Artificial General Intelligence', 
    breakthrough_probability: 65,
    timeline: '2-4 years',
    impact: 'CIVILIZATION_CHANGING',
    key_players: ['OpenAI', 'DeepMind', 'Anthropic'],
    investment: '$12.7B'
  },
  { 
    technology: 'Fusion Energy (Commercial)', 
    breakthrough_probability: 41,
    timeline: '8-12 years',
    impact: 'REVOLUTIONARY',
    key_players: ['Commonwealth Fusion', 'TAE Technologies', 'Helion Energy'],
    investment: '$7.1B'
  }
];

const patentData = [
  { month: 'Jan', ai: 2847, biotech: 1923, quantum: 534, energy: 1247 },
  { month: 'Feb', ai: 3201, biotech: 2156, quantum: 612, energy: 1389 },
  { month: 'Mar', ai: 3678, biotech: 2087, quantum: 689, energy: 1456 },
  { month: 'Apr', ai: 4123, biotech: 2234, quantum: 723, energy: 1523 },
  { month: 'May', ai: 4567, biotech: 2456, quantum: 801, energy: 1689 },
  { month: 'Jun', ai: 5012, biotech: 2678, quantum: 924, energy: 1834 }
];

const universityProjects = [
  { university: 'MIT', project: 'Neural Interface Development', funding: '$45M', classification: 'RESTRICTED' },
  { university: 'Stanford', project: 'Quantum Cryptography Networks', funding: '$67M', classification: 'CONFIDENTIAL' },
  { university: 'Caltech', project: 'Metamaterial Cloaking', funding: '$23M', classification: 'SECRET' },
  { university: 'Harvard', project: 'Genetic Memory Enhancement', funding: '$78M', classification: 'TOP_SECRET' }
];

const corporateR_D = [
  { company: 'Apple', budget: '$29.9B', focus: 'Mixed Reality, Neural Processing', breakthrough_potential: 'HIGH' },
  { company: 'Alphabet', budget: '$31.5B', focus: 'AGI, Quantum Computing', breakthrough_potential: 'CRITICAL' },
  { company: 'Microsoft', budget: '$24.7B', focus: 'AI Infrastructure, Quantum', breakthrough_potential: 'HIGH' },
  { company: 'Tesla', budget: '$3.5B', focus: 'Autonomous Systems, Energy Storage', breakthrough_potential: 'MEDIUM' },
  { company: 'Meta', budget: '$35.3B', focus: 'Virtual Reality, Neural Interfaces', breakthrough_potential: 'HIGH' }
];

const getImpactBadge = (impact) => {
  switch (impact) {
    case 'CIVILIZATION_CHANGING': return <Badge className="bg-red-500/20 text-red-400">CIVILIZATION CHANGING</Badge>;
    case 'TRANSFORMATIONAL': return <Badge className="bg-purple-500/20 text-purple-400">TRANSFORMATIONAL</Badge>;
    case 'REVOLUTIONARY': return <Badge className="bg-orange-500/20 text-orange-400">REVOLUTIONARY</Badge>;
    case 'SIGNIFICANT': return <Badge className="bg-yellow-500/20 text-yellow-400">SIGNIFICANT</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">MODERATE</Badge>;
  }
};

const getClassificationBadge = (classification) => {
  switch (classification) {
    case 'TOP_SECRET': return <Badge className="bg-red-500/20 text-red-400">TOP SECRET</Badge>;
    case 'SECRET': return <Badge className="bg-orange-500/20 text-orange-400">SECRET</Badge>;
    case 'CONFIDENTIAL': return <Badge className="bg-yellow-500/20 text-yellow-400">CONFIDENTIAL</Badge>;
    case 'RESTRICTED': return <Badge className="bg-blue-500/20 text-blue-400">RESTRICTED</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNCLASSIFIED</Badge>;
  }
};

const getPotentialBadge = (potential) => {
  switch (potential) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400 animate-pulse">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">LOW</Badge>;
  }
};

export default function ResearchIntelPage() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Search className="w-10 h-10 mr-3 text-cyan-400" />
            Research & Development Intelligence
          </h1>
          <p className="orbital-text-subtitle">Global patent monitoring, breakthrough prediction, and corporate R&D surveillance.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input 
              placeholder="Search patents, technologies, researchers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-80 bg-gray-800 border-gray-600"
            />
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {researchMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      {/* Breakthrough Predictions */}
      <div className="glass-pane p-6 mb-8">
        <h3 className="orbital-text-subheading mb-6 flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
          Predicted Technological Breakthroughs
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {breakthroughPredictions.map((prediction, i) => (
            <div key={i} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
              <div className="flex justify-between items-start mb-3">
                <h4 className="font-semibold text-white text-lg">{prediction.technology}</h4>
                {getImpactBadge(prediction.impact)}
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-xs text-gray-400">Breakthrough Probability</p>
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-700 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          prediction.breakthrough_probability > 70 ? 'bg-green-500' :
                          prediction.breakthrough_probability > 40 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{width: `${prediction.breakthrough_probability}%`}}
                      ></div>
                    </div>
                    <span className="text-white text-sm font-semibold">{prediction.breakthrough_probability}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Timeline</p>
                  <p className="text-white font-semibold">{prediction.timeline}</p>
                </div>
              </div>
              
              <div className="mb-3">
                <p className="text-xs text-gray-400 mb-1">Key Players</p>
                <div className="flex flex-wrap gap-1">
                  {prediction.key_players.map((player, j) => (
                    <span key={j} className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
                      {player}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-green-400 font-semibold">{prediction.investment} invested</span>
                <button className="orbital-button-secondary text-xs px-3 py-1">
                  Deep Analysis
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Patent Trends */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <FileText className="w-5 h-5 mr-2 text-purple-400" />
            Patent Filing Trends
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={patentData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F3F4F6'
                  }}
                />
                <Area type="monotone" dataKey="ai" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="biotech" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
                <Area type="monotone" dataKey="quantum" stackId="1" stroke="#06B6D4" fill="#06B6D4" fillOpacity={0.6} />
                <Area type="monotone" dataKey="energy" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-xs mt-2">
            <span className="text-purple-400">◆ AI/ML</span>
            <span className="text-green-400">◆ Biotech</span>
            <span className="text-cyan-400">◆ Quantum</span>
            <span className="text-yellow-400">◆ Energy</span>
          </div>
        </div>

        {/* Corporate R&D Budgets */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-yellow-400" />
            Corporate R&D Intelligence
          </h3>
          <div className="space-y-3">
            {corporateR_D.map((corp, i) => (
              <div key={i} className="p-3 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-white">{corp.company}</h4>
                  {getPotentialBadge(corp.breakthrough_potential)}
                </div>
                <p className="text-sm text-gray-400 mb-2">{corp.focus}</p>
                <div className="flex justify-between items-center">
                  <span className="text-green-400 font-semibold">{corp.budget}</span>
                  <button className="orbital-button-secondary text-xs px-2 py-1">
                    Monitor
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* University Research Projects */}
      <div className="glass-pane p-4">
        <h3 className="orbital-text-subheading mb-4 flex items-center">
          <Users className="w-5 h-5 mr-2 text-blue-400" />
          Classified University Research Projects
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {universityProjects.map((project, i) => (
            <div key={i} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
              <div className="flex justify-between items-start mb-3">
                <h4 className="font-semibold text-white text-sm">{project.university}</h4>
                {getClassificationBadge(project.classification)}
              </div>
              <p className="text-xs text-gray-400 mb-3">{project.project}</p>
              <div className="flex justify-between items-center">
                <span className="text-green-400 font-semibold text-sm">{project.funding}</span>
                <button className="orbital-button-secondary text-xs px-2 py-1">
                  Infiltrate
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}