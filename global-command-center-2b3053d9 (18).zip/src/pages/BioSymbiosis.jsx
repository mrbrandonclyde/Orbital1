import React, { useState } from 'react';
import { Brain, Dna, Heart, Activity, Users, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableCell, TableBody } from "@/components/ui/table";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const bioMetrics = [
  { title: "Neural Interfaces", value: "247", icon: Brain, color: "text-purple-400" },
  { title: "Genetic Modifications", value: "89", icon: Dna, color: "text-green-400" },
  { title: "Symbiosis Success Rate", value: "98.2%", icon: Heart, color: "text-red-400" },
  { title: "Bio-Enhancement Level", value: "Advanced", icon: Activity, color: "text-cyan-400" },
  { title: "Test Subjects", value: "1,247", icon: Users, color: "text-yellow-400" },
  { title: "Safety Index", value: "99.7%", icon: Shield, color: "text-green-400" }
];

const enhancementData = [
  { month: 'Jan', cognitive: 85, physical: 78, longevity: 92 },
  { month: 'Feb', cognitive: 87, physical: 82, longevity: 94 },
  { month: 'Mar', cognitive: 91, physical: 85, longevity: 96 },
  { month: 'Apr', cognitive: 93, physical: 89, longevity: 97 },
  { month: 'May', cognitive: 95, physical: 92, longevity: 98 },
  { month: 'Jun', cognitive: 98, physical: 94, longevity: 99 }
];

const subjects = [
  {
    id: 'BIO-001',
    codename: 'Phoenix',
    enhancement: 'Neural-AI Interface',
    status: 'ACTIVE',
    compatibility: 98,
    duration: '247 days',
    performance: 'Exceptional'
  },
  {
    id: 'BIO-002',
    codename: 'Titan',
    enhancement: 'Genetic Muscle Enhancement',
    status: 'STABLE',
    compatibility: 96,
    duration: '189 days',
    performance: 'High'
  },
  {
    id: 'BIO-003',
    codename: 'Sage',
    enhancement: 'Cognitive Acceleration',
    status: 'MONITORING',
    compatibility: 92,
    duration: '156 days',
    performance: 'Excellent'
  },
  {
    id: 'BIO-004',
    codename: 'Helix',
    enhancement: 'Regenerative Biology',
    status: 'TESTING',
    compatibility: 89,
    duration: '78 days',
    performance: 'Good'
  }
];

const getStatusBadge = (status) => {
  switch (status) {
    case 'ACTIVE': return <Badge className="bg-green-500/20 text-green-400">ACTIVE</Badge>;
    case 'STABLE': return <Badge className="bg-blue-500/20 text-blue-400">STABLE</Badge>;
    case 'MONITORING': return <Badge className="bg-yellow-500/20 text-yellow-400">MONITORING</Badge>;
    case 'TESTING': return <Badge className="bg-purple-500/20 text-purple-400 animate-pulse">TESTING</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">UNKNOWN</Badge>;
  }
};

const getPerformanceBadge = (performance) => {
  switch (performance) {
    case 'Exceptional': return <Badge className="bg-purple-500/20 text-purple-400">EXCEPTIONAL</Badge>;
    case 'Excellent': return <Badge className="bg-green-500/20 text-green-400">EXCELLENT</Badge>;
    case 'High': return <Badge className="bg-cyan-500/20 text-cyan-400">HIGH</Badge>;
    case 'Good': return <Badge className="bg-blue-500/20 text-blue-400">GOOD</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">BASELINE</Badge>;
  }
};

export default function BioSymbiosisPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Brain className="w-10 h-10 mr-3 text-purple-400" />
            Bio-Symbiosis Research
          </h1>
          <p className="orbital-text-subtitle">Advanced human-AI integration, genetic enhancement, and biological optimization programs.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
        {bioMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-2xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Enhancement Progress</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={enhancementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }} 
                />
                <Line type="monotone" dataKey="cognitive" name="Cognitive Enhancement" stroke="#8B5CF6" strokeWidth={3} />
                <Line type="monotone" dataKey="physical" name="Physical Enhancement" stroke="#06B6D4" strokeWidth={3} />
                <Line type="monotone" dataKey="longevity" name="Longevity Factor" stroke="#10B981" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Neural Interface Network</h3>
          <div className="h-80 flex items-center justify-center">
            <div className="relative w-64 h-64">
              {/* Central node */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-16 h-16 bg-purple-500 rounded-full animate-pulse flex items-center justify-center">
                  <Brain className="w-8 h-8 text-white" />
                </div>
              </div>
              
              {/* Connected nodes */}
              {[...Array(8)].map((_, i) => {
                const angle = (i * 360) / 8;
                const radius = 100;
                const x = Math.cos((angle * Math.PI) / 180) * radius;
                const y = Math.sin((angle * Math.PI) / 180) * radius;
                return (
                  <div
                    key={i}
                    className="absolute w-8 h-8 bg-cyan-400 rounded-full animate-pulse"
                    style={{
                      left: '50%',
                      top: '50%',
                      transform: `translate(${x - 16}px, ${y - 16}px)`
                    }}
                  >
                    <div className="absolute w-px bg-purple-400 opacity-50"
                      style={{
                        height: radius + 'px',
                        left: '50%',
                        top: '50%',
                        transformOrigin: 'bottom',
                        transform: `rotate(${angle + 180}deg)`
                      }}
                    ></div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Research Subjects</h3>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-gray-400">Subject</TableHead>
              <TableHead className="text-gray-400">Enhancement Type</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Compatibility</TableHead>
              <TableHead className="text-gray-400">Duration</TableHead>
              <TableHead className="text-gray-400">Performance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {subjects.map((subject) => (
              <TableRow key={subject.id} className="border-gray-800 hover:bg-gray-800/30">
                <TableCell>
                  <div>
                    <p className="font-medium text-white">{subject.codename}</p>
                    <p className="text-xs text-gray-400 font-mono">{subject.id}</p>
                  </div>
                </TableCell>
                <TableCell className="text-gray-300">{subject.enhancement}</TableCell>
                <TableCell>{getStatusBadge(subject.status)}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-purple-500 to-cyan-500 h-2 rounded-full"
                        style={{ width: `${subject.compatibility}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-purple-400">{subject.compatibility}%</span>
                  </div>
                </TableCell>
                <TableCell className="text-gray-400">{subject.duration}</TableCell>
                <TableCell>{getPerformanceBadge(subject.performance)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}