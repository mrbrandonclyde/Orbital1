import React from "react";
import HeaderFrame from "@/components/foundation/HeaderFrame";
import Admin_SidebarFrame from "@/components/foundation/Admin_SidebarFrame";
import Admin_DashboardFrame from "@/components/foundation/Admin_DashboardFrame";
import FooterFrame from "@/components/foundation/FooterFrame";

export default function AdminPhase1Dashboard() {
  return (
    <div>
      <HeaderFrame title="Admin Dashboard" subtitle="System-wide overview (placeholder)" />
      <Admin_SidebarFrame />
      <Admin_DashboardFrame />
      <FooterFrame />
    </div>
  );
}