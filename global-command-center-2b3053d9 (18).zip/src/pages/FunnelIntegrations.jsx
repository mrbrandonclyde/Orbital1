import React from "react";
import ComingSoon from "@/components/common/ComingSoon";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Plug, Mail, Webhook, Database } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function FunnelIntegrations() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Plug className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Integrations</h1>
            <p className="orbital-text-subtitle">Connect email, webhooks, CRMs, payment gateways, and data sources.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { window.location.href = createPageUrl("BackendStatus"); }}>Backend Status</Button>
        </div>
      </div>

      <ComingSoon title="Integrations Matrix" subtitle="Prepped endpoints and OAuth/JWT hooks">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><Mail className="w-4 h-4 text-emerald-400" /> Email & SMS</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">ESP providers, templates, rate limits, deliverability</CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><Webhook className="w-4 h-4 text-rose-400" /> Webhooks</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">Inbound/outbound webhooks, retry, signing secrets</CardContent>
          </Card>
          <Card className="bg-[#0A0D18]/60 border-gray-800">
            <CardHeader><CardTitle className="text-white text-sm flex items-center gap-2"><Database className="w-4 h-4 text-sky-400" /> Data Sources</CardTitle></CardHeader>
            <CardContent className="text-gray-300 text-sm">BigQuery, S3, Stripe, CRM sync, analytics pipelines</CardContent>
          </Card>
        </div>
      </ComingSoon>
    </div>
  );
}