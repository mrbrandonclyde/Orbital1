import React, { useState } from 'react';
import { HelpCircle, MessageSquare, FileText, Mail, Phone, ExternalLink } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

const supportOptions = [
  { title: "Knowledge Base", icon: FileText, description: "Search our comprehensive documentation", action: "Browse Articles" },
  { title: "Live Chat", icon: MessageSquare, description: "Get instant help from our support team", action: "Start Chat" },
  { title: "Email Support", icon: Mail, description: "Send us a detailed support request", action: "Send Email" },
  { title: "Emergency Hotline", icon: Phone, description: "24/7 critical system support", action: "Call Now" }
];

export default function SupportPage() {
  const [supportRequest, setSupportRequest] = useState({ subject: '', message: '', priority: 'medium' });

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <HelpCircle className="w-10 h-10 mr-3 text-green-400" />
            Support Center
          </h1>
          <p className="orbital-text-subtitle">Get help and support for the Global Command Center platform.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {supportOptions.map((option, i) => {
          const Icon = option.icon;
          return (
            <Card key={i} className="bg-[#0A0D18]/50 border-gray-800 hover:border-green-500/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Icon className="w-6 h-6 text-green-400" />
                  <span className="text-white">{option.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 mb-4">{option.description}</p>
                <Button className="orbital-button-secondary w-full">
                  {option.action} <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="glass-pane p-6">
        <h3 className="orbital-text-subheading mb-4">Submit Support Request</h3>
        <div className="space-y-4">
          <Input 
            placeholder="Subject" 
            value={supportRequest.subject}
            onChange={(e) => setSupportRequest({...supportRequest, subject: e.target.value})}
          />
          <Textarea 
            placeholder="Describe your issue in detail..."
            rows={6}
            value={supportRequest.message}
            onChange={(e) => setSupportRequest({...supportRequest, message: e.target.value})}
          />
          <div className="flex justify-between items-center">
            <select 
              className="bg-gray-800 border border-gray-600 rounded px-3 py-2 text-white"
              value={supportRequest.priority}
              onChange={(e) => setSupportRequest({...supportRequest, priority: e.target.value})}
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
              <option value="critical">Critical</option>
            </select>
            <Button className="orbital-button-primary">Submit Request</Button>
          </div>
        </div>
      </div>
    </div>
  );
}