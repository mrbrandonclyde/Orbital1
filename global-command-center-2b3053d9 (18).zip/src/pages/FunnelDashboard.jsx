
import React from "react";
import { LayoutDashboard, Layers, FileText, Zap, Users, ShoppingCart, BarChart3, Plug, Settings, Wand2, FileText as FileDoc } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function FunnelDashboard() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <LayoutDashboard className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Funnel Builder Dashboard</h1>
            <p className="orbital-text-subtitle">All your funnels, pages, automation, and insights in one place.</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to={createPageUrl('Funnels')}><Button className="bg-indigo-600 hover:bg-indigo-700">Go to Funnels</Button></Link>
          <Link to={createPageUrl('FunnelPages')}><Button variant="secondary"><FileText className="w-4 h-4 mr-2" /> Pages</Button></Link>
          <Link to={createPageUrl('FunnelAutomation')}><Button variant="secondary"><Zap className="w-4 h-4 mr-2" /> Automation</Button></Link>
          <Link to={createPageUrl('AIFunnelBuilder')}>
            <Button variant="secondary"><Wand2 className="w-4 h-4 mr-2" /> AI Funnel Studio</Button>
          </Link>
          <Link to={createPageUrl('AIAssets')}>
            <Button variant="secondary"><FileDoc className="w-4 h-4 mr-2" /> AI Assets</Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { title: "Funnels", icon: Layers, desc: "Create and manage funnels", href: 'Funnels' },
          { title: "Pages", icon: FileText, desc: "Landing pages and templates", href: 'FunnelPages' },
          { title: "Automation", icon: Zap, desc: "Email, SMS, webhooks", href: 'FunnelAutomation' },
          { title: "Contacts / CRM", icon: Users, desc: "Profiles, tags, pipelines", href: 'CRM' },
          { title: "E‑Commerce", icon: ShoppingCart, desc: "Products and checkouts", href: 'Commerce' },
          { title: "Analytics & Reports", icon: BarChart3, desc: "Conversions and revenue", href: 'FunnelAnalytics' },
          { title: "Integrations", icon: Plug, desc: "Connect your tools", href: 'FunnelIntegrations' },
          { title: "Settings", icon: Settings, desc: "Domains, SEO & tracking", href: 'FunnelSettings' },
        ].map((card) => {
          const Icon = card.icon;
          return (
            <Link key={card.title} to={createPageUrl(card.href)} className="block">
              <div className="glass-pane p-6 rounded-2xl hover:border-indigo-500/40 transition-colors h-full">
                <div className="flex items-center gap-3 mb-2">
                  <Icon className="w-6 h-6 text-cyan-400" />
                  <h3 className="text-white text-lg font-semibold">{card.title}</h3>
                </div>
                <p className="text-gray-400 text-sm">{card.desc}</p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
