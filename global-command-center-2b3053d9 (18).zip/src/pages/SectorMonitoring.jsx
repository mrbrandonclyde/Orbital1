import React, { useState, useCallback } from 'react';
import { useQuery } from "../components/lib/useQuery";
import { sectorAPI } from "../components/lib/sectorApi";
import SectorDataCard from '../components/sectors/SectorDataCard';
import { RefreshCw, Database, AlertCircle } from 'lucide-react';

export default function SectorMonitoringPage() {
  const [selectedSector, setSelectedSector] = useState(null);

  const queryFn = useCallback(() => sectorAPI.getAllSectorStatus(), []);
  const { data: sectorStatus, loading, error, refetch } = useQuery(queryFn, { 
    refetchInterval: 60000 // Refresh every minute
  });

  const onlineSectors = sectorStatus?.filter(s => s.status === 'online') || [];
  const offlineSectors = sectorStatus?.filter(s => s.status === 'offline') || [];

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text">Sector Monitoring</h1>
          <p className="text-lg text-gray-400 mt-2">Real-time data from all vertical integrations.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <span className="text-gray-400">{onlineSectors.length} Online</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-3 h-3 bg-red-400 rounded-full"></div>
            <span className="text-gray-400">{offlineSectors.length} Offline</span>
          </div>
          <button 
            onClick={refetch}
            className="orbital-button-secondary flex items-center space-x-2"
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh All</span>
          </button>
        </div>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Total Sectors</p>
              <p className="text-3xl font-bold text-white">{sectorStatus?.length || 0}</p>
            </div>
            <Database className="w-8 h-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Online</p>
              <p className="text-3xl font-bold text-green-400">{onlineSectors.length}</p>
            </div>
            <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center">
              <Database className="w-4 h-4 text-green-900" />
            </div>
          </div>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Issues</p>
              <p className="text-3xl font-bold text-red-400">{offlineSectors.length}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
        </div>
      </div>

      {/* Sector Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {sectorStatus?.map(({ sector, data, status, error }) => (
          <div key={sector} onClick={() => setSelectedSector({ sector, data, status })}>
            <SectorDataCard 
              sector={sector}
              data={data}
              isLoading={loading && !data}
            />
            {status === 'offline' && (
              <div className="mt-2 text-red-400 text-sm flex items-center space-x-1">
                <AlertCircle className="w-3 h-3" />
                <span>Connection Error</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Detailed View Modal */}
      {selectedSector && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#0A0D18] border border-gray-800 rounded-xl p-6 max-w-2xl w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-bold text-white capitalize">
                {selectedSector.sector} Detailed View
              </h3>
              <button 
                onClick={() => setSelectedSector(null)}
                className="text-gray-400 hover:text-white"
              >
                ×
              </button>
            </div>
            
            <div className="space-y-4">
              <pre className="bg-gray-900 p-4 rounded text-xs text-gray-300 overflow-auto">
                {JSON.stringify(selectedSector.data, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}