import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, Rocket, Map } from "lucide-react";

export default function ExpansionPage() {
  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <h1 className="orbital-text-title flex items-center">
          <Building2 className="w-10 h-10 mr-3 text-cyan-400" />
          Expansion
        </h1>
        <p className="orbital-text-subtitle">Infrastructure and Space Colonies.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl('UrbanPlanner')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Map className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-semibold">Urban Planner</h3>
          </div>
          <p className="text-gray-400 text-sm">AI-assisted city planning.</p>
        </Link>

        <Link to={createPageUrl('Colonization')} className="glass-pane p-6 hover:border-cyan-500/40">
          <div className="flex items-center gap-3 mb-2">
            <Rocket className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Space Colonies</h3>
          </div>
          <p className="text-gray-400 text-sm">Off-world settlement ops.</p>
        </Link>
      </div>
    </div>
  );
}