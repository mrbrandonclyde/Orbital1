import React, { useState, useCallback } from 'react';
import { GuardianPhase2, GuardianCharter } from '@/api/entities';
import { useQuery } from '../components/lib/useQuery';
import { Globe, Shield, Zap, Eye, EyeOff, Settings } from 'lucide-react';
import MissionDockComponent from '../components/guardian/MissionDock';
import VerticalGuardianIntegration from '../components/guardian/VerticalGuardianIntegration';
import EmptyState from '../components/common/EmptyState';

export default function GuardianOpsPage() {
  const [showMissionDock, setShowMissionDock] = useState(false);
  const [selectedVertical, setSelectedVertical] = useState('all');

  const queryFn = useCallback(async () => {
    const [phase2Data, charterData] = await Promise.all([
      GuardianPhase2.list(),
      GuardianCharter.list()
    ]);
    return { phase2Data, charterData };
  }, []);

  const { data, loading, error, refetch } = useQuery(queryFn);

  // Extract Phase 2 configuration
  const phase2Config = data?.phase2Data?.[0]?.guardian_phase_2;
  const activeMissions = phase2Config?.missions || [];
  const connectedVerticals = ['defense', 'finance', 'energy', 'transportation', 'space', 'healthcare'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      {/* Page Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold orbital-gradient-text flex items-center">
            <Globe className="w-10 h-10 mr-3 text-indigo-400" />
            Guardian Operations
          </h1>
          <p className="text-lg text-gray-400 mt-2">
            Phase 2: System-wide stealth operations across all verticals.
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setShowMissionDock(!showMissionDock)}
            className={`orbital-button-secondary flex items-center space-x-2 ${showMissionDock ? 'bg-indigo-600/20 border-indigo-500/50' : ''}`}
          >
            {showMissionDock ? <EyeOff size={18} /> : <Eye size={18} />}
            <span>Mission Dock</span>
          </button>
          
          <button
            onClick={refetch}
            className="orbital-button-secondary flex items-center space-x-2"
          >
            <Settings size={18} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Phase 2 Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 text-center">
          <Globe className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">{activeMissions.length}</p>
          <p className="text-sm text-gray-400">Active Missions</p>
        </div>
        
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 text-center">
          <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-green-400">{connectedVerticals.length}</p>
          <p className="text-sm text-gray-400">Connected Verticals</p>
        </div>
        
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 text-center">
          <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-yellow-400">INVISIBLE</p>
          <p className="text-sm text-gray-400">Stealth Mode</p>
        </div>
        
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6 text-center">
          <div className="w-8 h-8 bg-purple-400 rounded-full mx-auto mb-2 animate-pulse"></div>
          <p className="text-2xl font-bold text-purple-400">ZYRA</p>
          <p className="text-sm text-gray-400">Central Brain</p>
        </div>
      </div>

      {/* Vertical Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedVertical('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              selectedVertical === 'all' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-700/50'
            }`}
          >
            All Verticals
          </button>
          {connectedVerticals.map(vertical => (
            <button
              key={vertical}
              onClick={() => setSelectedVertical(vertical)}
              className={`px-4 py-2 rounded-lg font-medium transition-all capitalize ${
                selectedVertical === vertical 
                  ? 'bg-indigo-600 text-white' 
                  : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-700/50'
              }`}
            >
              {vertical}
            </button>
          ))}
        </div>
      </div>

      {/* Vertical Guardian Integration Grid */}
      {error && (
        <div className="text-center py-12">
          <p className="text-red-500">Failed to load Guardian Operations data.</p>
        </div>
      )}

      {!loading && !error && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {(selectedVertical === 'all' ? connectedVerticals : [selectedVertical]).map(vertical => (
            <VerticalGuardianIntegration
              key={vertical}
              vertical={vertical}
              missions={activeMissions}
              phase2Config={phase2Config}
            />
          ))}
        </div>
      )}

      {/* Mission Dock Sidebar */}
      <MissionDockComponent isVisible={showMissionDock} phase2Config={phase2Config} />

      {/* Phase 2 Mission Summary */}
      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Phase 2 Protocols</h3>
          <div className="space-y-3">
            {activeMissions.map((mission, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 bg-green-500/10 border border-green-500/20 rounded">
                <Shield className="w-5 h-5 text-green-400" />
                <div>
                  <p className="font-medium text-white capitalize">{mission.type?.replace('_', ' ')}</p>
                  <p className="text-sm text-gray-400">Domains: {mission.domains?.join(', ')}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Stealth Architecture</h3>
          <div className="space-y-3">
            <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded">
              <p className="font-medium text-purple-400 mb-1">Public Narrative</p>
              <p className="text-sm text-gray-300">
                Golden age of human precision and endurance through elite training
              </p>
            </div>
            <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded">
              <p className="font-medium text-indigo-400 mb-1">Hidden Reality</p>
              <p className="text-sm text-gray-300">
                {phase2Config?.integration?.central_brain} orchestrates every move across all verticals
              </p>
            </div>
            <div className="p-3 bg-gray-500/10 border border-gray-500/20 rounded">
              <p className="font-medium text-gray-400 mb-1">15-Year Vision</p>
              <p className="text-sm text-gray-300">
                System-wide empire shield with perfect operational continuity
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}