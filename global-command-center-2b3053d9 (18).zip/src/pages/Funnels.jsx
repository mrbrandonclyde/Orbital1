
import React from "react";
import { Funnel } from "@/api/entities";
import { FunnelStep } from "@/api/entities";
import { User } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Layers, Plus, Search, Filter, RefreshCw, Wand2, Store, Upload } from "lucide-react";
import FunnelCard from "../components/funnels/FunnelCard";
import RecentActivity from "../components/funnels/RecentActivity";
import HistoryModal from "../components/funnels/HistoryModal";

export default function FunnelsPage() {
  const [funnels, setFunnels] = React.useState([]);
  const [stepCounts, setStepCounts] = React.useState({});
  const [q, setQ] = React.useState("");
  const [typeFilter, setTypeFilter] = React.useState("ALL");
  const [dateRange, setDateRange] = React.useState("30d");
  const [customStart, setCustomStart] = React.useState("");
  const [customEnd, setCustomEnd] = React.useState("");
  const [activityCollapsed, setActivityCollapsed] = React.useState(false);
  // Removed showNew and form states as the "Create New Funnel" button will now navigate to a wizard
  // const [showNew, setShowNew] = React.useState(false);
  // const [form, setForm] = React.useState({ name: "", type: "OPTIN" });
  const [historyFor, setHistoryFor] = React.useState(null);
  const [me, setMe] = React.useState(null);

  const load = React.useCallback(async () => {
    const currentUser = await User.me().catch(() => null);
    setMe(currentUser);
    const f = await Funnel.list("-updated_date", 200);
    const scoped = currentUser?.account_id ? f.filter(x => x.account_id === currentUser.account_id) : f;
    const steps = await FunnelStep.list();
    const counts = {};
    steps.forEach(s => { counts[s.funnel_id] = (counts[s.funnel_id] || 0) + 1; });
    setFunnels(scoped);
    setStepCounts(counts);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  // Removed createFunnel function as the "Create New Funnel" button will now navigate to a wizard
  // const createFunnel = async () => {
  //   if (!form.name.trim()) return;
  //   const created = await Funnel.create({
  //     funnel_name: form.name.trim(),
  //     type: form.type,
  //     status: "DRAFT",
  //     account_id: me?.account_id
  //   });
  //   setShowNew(false);
  //   setForm({ name: "", type: "OPTIN" });
  //   setFunnels(prev => [created, ...prev]);
  // };

  const cloneFunnel = async (f) => {
    const nf = await Funnel.create({
      funnel_name: `${f.funnel_name} (Copy)`,
      type: f.type,
      status: "DRAFT",
      description: f.description || "",
      account_id: f.account_id || me?.account_id
    });
    const steps = await FunnelStep.filter({ funnel_id: nf.id }, "order_index", 500); // Changed to use nf.id
    for (const s of steps) {
      await FunnelStep.create({
        funnel_id: nf.id,
        step_name: s.step_name,
        step_type: s.step_type,
        order_index: s.order_index,
        path_slug: `${s.path_slug || "step"}-copy-${Date.now()}`,
        content_schema: s.content_schema || { blocks: [] }
      });
    }
    await load();
  };


  const deleteFunnel = async (f) => {
    if (window.confirm(`Are you sure you want to delete the funnel "${f.funnel_name}"? This cannot be undone.`)) {
      await Funnel.delete(f.id);
      await load();
    }
  };

  const filtered = funnels.filter(f => {
    const matchesQ =
      !q ||
      f.funnel_name.toLowerCase().includes(q.toLowerCase()) ||
      (f.group_tags || []).join(" ").toLowerCase().includes(q.toLowerCase());
    const matchesType = typeFilter === "ALL" || f.type === typeFilter;

    let matchesDate = true;
    // Prioritize updated_date, fallback to created_date
    const updated = f.updated_date ? new Date(f.updated_date) : f.created_date ? new Date(f.created_date) : null;

    if (dateRange === "custom" && customStart && customEnd && updated) {
      const start = new Date(customStart);
      const end = new Date(customEnd);
      // Normalize end to end-of-day
      end.setHours(23, 59, 59, 999);
      matchesDate = updated >= start && updated <= end;
    } else if (["7d", "30d", "90d"].includes(dateRange)) {
      const now = new Date();
      const days = dateRange === "7d" ? 7 : dateRange === "30d" ? 30 : 90;
      const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
      matchesDate = !updated || updated >= cutoff;
    } else { // "all" time
      matchesDate = true;
    }

    return matchesQ && matchesType && matchesDate;
  });

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Top header with Quick Actions */}
      <div className="orbital-page-header">
        <div className="flex items-center gap-3">
          <Layers className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="orbital-text-title">Funnels</h1>
            <p className="orbital-text-subtitle">Create, organize, and optimize lead gen, sales, webinar, and membership funnels.</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {/* Replaced Create New Funnel button to open wizard */}
          <Button asChild className="bg-indigo-600 hover:bg-indigo-700">
            <Link to={createPageUrl("FunnelWizard")}> {/* Assuming "FunnelWizard" is the page name for the new funnel creation wizard */}
              <Plus className="w-4 h-4 mr-1" /> Create New Funnel
            </Link>
          </Button>
          <Button variant="secondary" className="flex items-center">
            <Store className="w-4 h-4 mr-1" /> Browse Templates
          </Button>
          <Button variant="secondary" className="flex items-center">
            <Upload className="w-4 h-4 mr-1" /> Import Funnel
          </Button>
          <Button asChild variant="secondary" className="flex items-center">
            <Link to={createPageUrl("AIFunnelBuilder")}>
              <Wand2 className="w-4 h-4 mr-1" /> AI Funnel Builder
            </Link>
          </Button>
        </div>
      </div>

      {/* Removed Create New Funnel inline panel */}
      {/* {showNew && (
        <div className="glass-pane p-4 mb-6 rounded-3xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Input placeholder="Funnel name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-[#0C0F19] border-gray-700 text-gray-100" />
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100">
              {["OPTIN","SALES","WEBINAR","MEMBERSHIP","CHECKOUT","THANK_YOU","MISC"].map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
              <Button onClick={createFunnel} className="bg-indigo-600 hover:bg-indigo-700">Create</Button>
            </div>
            <div className="text-xs text-gray-500 self-center">Tip: you can refine this later in the editor.</div>
          </div>
        </div>
      )} */}

      {/* Filters Bar with Custom range */}
      <div className="bg-[#0A0D18]/50 border border-gray-800 rounded-3xl p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-gray-500 absolute left-2 top-2.5" />
            <Input
              className="pl-8 w-full bg-[#0A0D18] border-gray-700 text-gray-200"
              placeholder="Search by funnel name or tags..."
              value={q}
              onChange={e => setQ(e.target.value)}
            />
          </div>
          <div className="md:col-span-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100 w-full"
              >
                {["ALL","OPTIN","SALES","WEBINAR","MEMBERSHIP","CHECKOUT","THANK_YOU","MISC"].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div className="md:col-span-3">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-[#0C0F19] border border-gray-700 rounded-md px-3 py-2 text-gray-100 w-full"
            >
              <option value="7d">Last 7d</option>
              <option value="30d">Last 30d</option>
              <option value="90d">Last 90d</option>
              <option value="all">All Time</option>
              <option value="custom">Custom</option>
            </select>
          </div>
          <div className="md:col-span-1 flex justify-end">
            <Button variant="secondary" onClick={load}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
          </div>

          {dateRange === "custom" && (
            <div className="md:col-span-12 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-400 w-20">Start</span>
                <Input
                  type="date"
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  className="bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-400 w-20">End</span>
                <Input
                  type="date"
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  className="bg-[#0C0F19] border-gray-700 text-gray-100"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 12-column grid: main (9) + recent activity (3) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-9">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filtered.map(f => (
              <FunnelCard
                key={f.id}
                funnel={f}
                stepCount={stepCounts[f.id] || 0}
                onEdit={(ff) => window.location.href = createPageUrl(`FunnelEditor?funnel=${ff.id}`)}
                onClone={cloneFunnel}
                onDelete={deleteFunnel}
                onHistory={(ff) => setHistoryFor(ff)}
              />
            ))}
          </div>

          {/* Marketplace placeholder */}
          <div className="mt-8 glass-pane p-6 rounded-3xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white text-lg font-semibold">Template Marketplace</h3>
                <p className="text-gray-400 text-sm">Discover high-converting templates from the community.</p>
              </div>
              <Button variant="secondary">Explore Marketplace</Button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <RecentActivity
            items={funnels}
            collapsed={activityCollapsed}
            onToggle={() => setActivityCollapsed(!activityCollapsed)}
            onOpen={(ff) => window.location.href = createPageUrl(`FunnelEditor?funnel=${ff.id}`)}
          />
        </div>
      </div>

      {/* History Modal */}
      {historyFor && (
        <HistoryModal open={!!historyFor} onOpenChange={() => setHistoryFor(null)} funnel={historyFor} />
      )}
    </div>
  );
}
