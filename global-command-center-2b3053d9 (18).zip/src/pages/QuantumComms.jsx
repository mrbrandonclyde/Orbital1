import React, { useState } from 'react';
import { Radio, Shield, Globe, Users, MessageSquare, Phone, Video, Lock, Zap, Send } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const quantumChannels = [
  { id: 'diplomatic-1', name: 'UN Security Council', participants: 15, status: 'ACTIVE', classification: 'TOP_SECRET' },
  { id: 'corporate-alpha', name: 'Fortune 500 CEOs', participants: 47, status: 'STANDBY', classification: 'SECRET' },
  { id: 'military-prime', name: 'Joint Chiefs Network', participants: 8, status: 'ACTIVE', classification: 'EXECUTIVE_COMMAND' },
  { id: 'central-banks', name: 'Global Central Banks', participants: 12, status: 'ACTIVE', classification: 'TOP_SECRET' }
];

const activeConversations = [
  { contact: 'Xi Jinping', country: 'China', lastMessage: 'Supply chain adjustments confirmed', status: 'online', priority: 'HIGH' },
  { contact: 'Elon Musk', organization: 'SpaceX/Tesla', lastMessage: 'Mars mission timeline updated', status: 'online', priority: 'MEDIUM' },
  { contact: 'Christine Lagarde', organization: 'ECB', lastMessage: 'Interest rate coordination needed', status: 'away', priority: 'HIGH' },
  { contact: 'Lloyd Austin', organization: 'Pentagon', lastMessage: 'Threat assessment review scheduled', status: 'busy', priority: 'CRITICAL' }
];

const quantumMetrics = [
  { title: "Quantum Channels", value: "47", icon: Radio, color: "text-purple-400" },
  { title: "Active Conversations", value: "12", icon: MessageSquare, color: "text-cyan-400" },
  { title: "Encryption Strength", value: "Q-512", icon: Shield, color: "text-green-400" },
  { title: "Global Reach", value: "198", icon: Globe, color: "text-yellow-400" },
];

const getStatusColor = (status) => {
  switch (status) {
    case 'online': return 'bg-green-500';
    case 'away': return 'bg-yellow-500';
    case 'busy': return 'bg-red-500';
    default: return 'bg-gray-500';
  }
};

const getPriorityBadge = (priority) => {
  switch (priority) {
    case 'CRITICAL': return <Badge className="bg-red-500/20 text-red-400">CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500/20 text-orange-400">HIGH</Badge>;
    case 'MEDIUM': return <Badge className="bg-yellow-500/20 text-yellow-400">MEDIUM</Badge>;
    default: return <Badge className="bg-gray-500/20 text-gray-400">LOW</Badge>;
  }
};

export default function QuantumCommsPage() {
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [newMessage, setNewMessage] = useState('');

  return (
    <div className="orbital-page-layout bg-[#020409]">
      {/* Header */}
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Radio className="w-10 h-10 mr-3 text-purple-400" />
            Quantum Communications Nexus
          </h1>
          <p className="orbital-text-subtitle">Secure diplomatic channels with world leaders, corporate executives, and strategic partners.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-purple-500/10 border border-purple-500/20 rounded px-3 py-1">
            <Lock className="w-4 h-4 text-purple-400" />
            <span className="text-purple-400 font-semibold text-sm">QUANTUM ENCRYPTED</span>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {quantumMetrics.map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div key={i} className="glass-pane p-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                <Icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <p className="text-3xl font-bold mt-2 text-white">{metric.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quantum Channels */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-purple-400" />
            Secure Channels
          </h3>
          <div className="space-y-3">
            {quantumChannels.map(channel => (
              <div 
                key={channel.id}
                className={`p-3 rounded-lg border transition-all cursor-pointer ${
                  selectedChannel?.id === channel.id 
                    ? 'bg-purple-500/20 border-purple-500/50' 
                    : 'bg-gray-800/30 border-gray-700 hover:border-purple-500/30'
                }`}
                onClick={() => setSelectedChannel(channel)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-white text-sm">{channel.name}</h4>
                  <div className={`w-2 h-2 rounded-full ${channel.status === 'ACTIVE' ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">{channel.participants} participants</span>
                  <Badge className="bg-red-500/20 text-red-400 text-xs">{channel.classification}</Badge>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Conversations */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <MessageSquare className="w-5 h-5 mr-2 text-cyan-400" />
            Active Conversations
          </h3>
          <div className="space-y-3">
            {activeConversations.map((conv, i) => (
              <div key={i} className="p-3 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(conv.status)}`}></div>
                    <h4 className="font-semibold text-white text-sm">{conv.contact}</h4>
                  </div>
                  {getPriorityBadge(conv.priority)}
                </div>
                <p className="text-xs text-gray-400 mb-1">{conv.country || conv.organization}</p>
                <p className="text-xs text-gray-300 italic">"{conv.lastMessage}"</p>
              </div>
            ))}
          </div>
        </div>

        {/* Communication Interface */}
        <div className="glass-pane p-4">
          <h3 className="orbital-text-subheading mb-4 flex items-center">
            <Send className="w-5 h-5 mr-2 text-green-400" />
            Secure Messaging
          </h3>
          
          {selectedChannel ? (
            <div className="space-y-4">
              <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                <p className="text-purple-400 font-semibold text-sm mb-1">Active Channel:</p>
                <p className="text-white text-sm">{selectedChannel.name}</p>
              </div>
              
              <div className="space-y-2">
                <Input placeholder="To: (Auto-populated from channel)" disabled className="bg-gray-800/50" />
                <Input placeholder="Subject: Operational Update" className="bg-gray-800/50 border-gray-600" />
                <Textarea 
                  placeholder="Compose secure message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="bg-gray-800/50 border-gray-600 h-24"
                />
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2 text-xs text-gray-400">
                  <Lock className="w-3 h-3" />
                  <span>Quantum Encrypted</span>
                </div>
                <button className="orbital-button-primary text-sm px-4 py-2 flex items-center space-x-2">
                  <Send className="w-4 h-4" />
                  <span>Send Secure</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-400 py-8">
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Select a quantum channel to begin secure communication</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}