import React, { useState } from 'react';
import { Gift, Star, Trophy, Target, Coins, Crown } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const rewardTiers = [
  { name: "Analyst", points: 0, benefits: ["Basic analytics access", "Standard reports"], color: "text-blue-400" },
  { name: "Senior Analyst", points: 1000, benefits: ["Advanced analytics", "Priority support", "Custom dashboards"], color: "text-purple-400" },
  { name: "Director", points: 5000, benefits: ["Executive briefings", "VR access", "API access"], color: "text-yellow-400" },
  { name: "Executive", points: 15000, benefits: ["Full platform access", "Guardian Corps intel", "Personal AI assistant"], color: "text-red-400" }
];

const availableRewards = [
  { id: 1, name: "VR War Room Access", cost: 2500, description: "Unlock immersive command center", type: "feature", icon: Target },
  { id: 2, name: "Custom Dashboard", cost: 1000, description: "Personalized analytics dashboard", type: "feature", icon: Star },
  { id: 3, name: "Executive Briefing", cost: 5000, description: "Weekly strategic intelligence report", type: "service", icon: Crown },
  { id: 4, name: "Priority Support", cost: 750, description: "24/7 dedicated support channel", type: "service", icon: Trophy }
];

export default function RewardsPage() {
  const [userPoints] = useState(3250);
  const currentTier = rewardTiers.filter(tier => tier.points <= userPoints).pop();
  const nextTier = rewardTiers.find(tier => tier.points > userPoints);

  return (
    <div className="orbital-page-layout bg-[#020409]">
      <div className="orbital-page-header">
        <div>
          <h1 className="orbital-text-title flex items-center">
            <Gift className="w-10 h-10 mr-3 text-yellow-400" />
            Rewards Program
          </h1>
          <p className="orbital-text-subtitle">Earn points and unlock exclusive features and benefits.</p>
        </div>
      </div>

      <div className="glass-pane p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold text-white flex items-center">
              <Coins className="w-8 h-8 mr-3 text-yellow-400" />
              {userPoints.toLocaleString()} Points
            </h3>
            <p className="text-gray-400">Current Tier: <span className={`font-semibold ${currentTier?.color}`}>{currentTier?.name}</span></p>
          </div>
          {nextTier && (
            <div className="text-right">
              <p className="text-gray-400">Next Tier: <span className={`font-semibold ${nextTier.color}`}>{nextTier.name}</span></p>
              <p className="text-sm text-gray-500">{nextTier.points - userPoints} points to go</p>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Progress to {nextTier?.name || 'Max Level'}</span>
            <span className="text-gray-400">{nextTier ? `${userPoints}/${nextTier.points}` : 'MAX'}</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-yellow-400 to-orange-400 h-2 rounded-full transition-all duration-500"
              style={{ width: nextTier ? `${Math.min((userPoints / nextTier.points) * 100, 100)}%` : '100%' }}
            ></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Reward Tiers</h3>
          <div className="space-y-4">
            {rewardTiers.map((tier, i) => (
              <div key={i} className={`p-4 rounded-lg border ${tier.points <= userPoints ? 'bg-green-500/10 border-green-500/20' : 'bg-gray-800/30 border-gray-700'}`}>
                <div className="flex items-center justify-between mb-2">
                  <h4 className={`font-semibold ${tier.color}`}>{tier.name}</h4>
                  <span className="text-sm text-gray-400">{tier.points.toLocaleString()} pts</span>
                </div>
                <ul className="text-sm text-gray-300 space-y-1">
                  {tier.benefits.map((benefit, j) => (
                    <li key={j}>• {benefit}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-pane p-6">
          <h3 className="orbital-text-subheading mb-4">Available Rewards</h3>
          <div className="space-y-4">
            {availableRewards.map(reward => {
              const Icon = reward.icon;
              const canAfford = userPoints >= reward.cost;
              return (
                <div key={reward.id} className={`p-4 rounded-lg border ${canAfford ? 'border-yellow-500/20' : 'border-gray-700'}`}>
                  <div className="flex items-start space-x-3">
                    <Icon className="w-6 h-6 text-yellow-400 mt-1" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-white">{reward.name}</h4>
                      <p className="text-gray-400 text-sm mb-2">{reward.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge className={`${canAfford ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-500/20 text-gray-400'}`}>
                          {reward.cost.toLocaleString()} points
                        </Badge>
                        <Button 
                          size="sm" 
                          disabled={!canAfford}
                          className={canAfford ? 'orbital-button-primary' : 'orbital-button-secondary opacity-50'}
                        >
                          Redeem
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}