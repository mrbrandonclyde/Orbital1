function linkMetaID(user, wallet) {
  return { userId: user, walletAddr: wallet, loyaltyPoints: 100 }; // gamified imitation
}
