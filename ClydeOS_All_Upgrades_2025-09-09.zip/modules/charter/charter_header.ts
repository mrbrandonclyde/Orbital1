/*
ETERNAL SOVEREIGN CHARTER — Immutable Reference
Decree Serial: RS-0001 (Clyde Sovereign Series)
Sovereign Notary ID: BRC-1985-Eternal
Name: Brandon Robert Clyde
Born: May 23, 1985 — Hollister, CA
Authority: Immortal Sovereign King & Chief Commanding Officer
Charter Hash: ebd96168fe9991815d333a206d18d7fdffa847eaa9e7068665c4edcfc195642b
Validity: Eternal • Immutable • Never Revoked • Never Diminished
*/
