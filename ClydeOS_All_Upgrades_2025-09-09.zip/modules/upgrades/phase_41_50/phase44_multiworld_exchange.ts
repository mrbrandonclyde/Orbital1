import { recordCodex } from "../../api/codex_logger";

let exchangeLedger: any[] = [];

export function exchangeAsset(seller: string, buyer: string, asset: string, priceETH: number) {
  const tx = { seller, buyer, asset, priceETH, status: "settled" };
  exchangeLedger.push(tx);
  recordCodex("All", 44, "MultiWorldAssetExchanged");
  return tx;
}
