import { recordCodex } from "../../api/codex_logger";

export function splitRoyalty(totalETH: number, heirs: string[]) {
  const share = totalETH / heirs.length;
  const splits = heirs.map(h => ({ heir: h, share }));
  recordCodex("All", 43, "QuantumRoyaltySplit");
  return splits;
}
