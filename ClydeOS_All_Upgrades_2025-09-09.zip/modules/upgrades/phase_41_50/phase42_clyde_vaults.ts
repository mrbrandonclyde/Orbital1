import { recordCodex } from "../../api/codex_logger";

let vaults: any[] = [];

export function depositVault(user: string, asset: string, amount: number) {
  const deposit = { user, asset, amount, yield: amount * 0.05, status: "active" };
  vaults.push(deposit);
  recordCodex("All", 42, "VaultDeposit");
  return deposit;
}
