import { recordCodex } from "../../api/codex_logger";

let tokenSupply = 0;

export function mintCreditTokens(amount: number) {
  tokenSupply += amount;
  recordCodex("All", 39, "CreditTokensMinted");
  return { totalSupply: tokenSupply };
}
