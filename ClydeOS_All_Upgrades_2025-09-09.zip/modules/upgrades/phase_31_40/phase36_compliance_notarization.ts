import { recordCodex } from "../../api/codex_logger";
import crypto from "crypto";

export function notarizeCompliance(company: string, report: object) {
  const hash = crypto.createHash("sha256").update(JSON.stringify(report)).digest("hex");
  recordCodex("All", 36, "ComplianceReportNotarized");
  return { company, report, hash, seal: "ClydeSovereignSeal" };
}
