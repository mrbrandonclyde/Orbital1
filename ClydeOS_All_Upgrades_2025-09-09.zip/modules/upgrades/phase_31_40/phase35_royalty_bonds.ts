import { recordCodex } from "../../api/codex_logger";

let bondRegistry: any[] = [];

export function issueBond(company: string, futureRoyalties: number) {
  const bond = { company, futureRoyalties, issued: true, status: "active" };
  bondRegistry.push(bond);
  recordCodex("All", 35, "RoyaltyBondIssued");
  return bond;
}
