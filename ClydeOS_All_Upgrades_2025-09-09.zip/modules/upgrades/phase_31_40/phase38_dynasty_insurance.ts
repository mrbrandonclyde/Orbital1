import { recordCodex } from "../../api/codex_logger";

let insurancePolicies: any[] = [];

export function createPolicy(holder: string, coverageETH: number, premiumETH: number) {
  const policy = { holder, coverageETH, premiumETH, status: "active" };
  insurancePolicies.push(policy);
  recordCodex("All", 38, "InsurancePolicyCreated");
  return policy;
}

export function claimPolicy(holder: string) {
  const policy = insurancePolicies.find(p => p.holder === holder && p.status === "active");
  if (policy) {
    policy.status = "claimed";
    recordCodex("All", 38, "InsurancePolicyClaimed");
    return policy;
  }
  return null;
}
