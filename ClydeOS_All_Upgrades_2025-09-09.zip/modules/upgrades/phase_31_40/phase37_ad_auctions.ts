import { recordCodex } from "../../api/codex_logger";

let adAuctions: any[] = [];

export function runAdAuction(location: string, bids: { company: string, bidETH: number }[]) {
  const winner = bids.reduce((max, b) => b.bidETH > max.bidETH ? b : max, bids[0]);
  recordCodex("All", 37, "AdAuctionRun");
  adAuctions.push({ location, winner });
  return { location, winner };
}
