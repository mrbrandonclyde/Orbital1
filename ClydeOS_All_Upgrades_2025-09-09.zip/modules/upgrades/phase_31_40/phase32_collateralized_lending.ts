import { recordCodex } from "../../api/codex_logger";

let collateralRegistry: any[] = [];

export function lockCollateral(company: string, asset: string, valueETH: number) {
  const lock = { company, asset, valueETH, status: "locked" };
  collateralRegistry.push(lock);
  recordCodex("All", 32, "CollateralLocked");
  return lock;
}

export function repossessCollateral(company: string) {
  const lock = collateralRegistry.find(c => c.company === company && c.status === "locked");
  if (lock) {
    lock.status = "repossessed";
    recordCodex("All", 32, "CollateralRepossessed");
  }
  return lock;
}
