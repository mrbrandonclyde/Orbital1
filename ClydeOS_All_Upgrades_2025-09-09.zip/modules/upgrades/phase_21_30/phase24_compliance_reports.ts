import { recordCodex } from "../../api/codex_logger";

export function requestComplianceReport(company: string, transactions: object[]) {
  recordCodex("All", 24, "ComplianceOnDemand");
  return { company, report: { gdpr: true, pci: true, logs: transactions }, status: "report generated" };
}
