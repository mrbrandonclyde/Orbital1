import { recordCodex } from "../../api/codex_logger";

export function optimizePrice(asset: string, basePrice: number, demandFactor: number) {
  recordCodex("All", 22, "AISalesCopilot");
  const markup = 0.1 + demandFactor * 0.05; // 10% + demand scaling
  return basePrice * (1 + markup);
}
