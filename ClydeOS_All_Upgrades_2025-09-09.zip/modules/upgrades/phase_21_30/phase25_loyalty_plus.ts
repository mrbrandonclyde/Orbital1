import { recordCodex } from "../../api/codex_logger";

export function upgradeLoyaltyPlus(user: string, tier: string, crm: object) {
  recordCodex("All", 25, "LoyaltyPlusUpgrade");
  crm[user] = tier;
  return { user, newTier: tier, crmUpdated: true };
}
