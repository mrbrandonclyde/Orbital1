import { recordCodex } from "../../api/codex_logger";

export function monetizeEvent(event: string, revenueETH: number, type: string) {
  recordCodex("Somnia", 27, "EventMonetized");
  const feeRate = type === "concert" ? 0.2 : type === "summit" ? 0.15 : 0.1;
  return { event, revenueETH, clydeCut: revenueETH * feeRate, type };
}
