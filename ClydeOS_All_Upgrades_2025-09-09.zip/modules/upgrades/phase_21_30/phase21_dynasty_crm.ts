import { recordCodex } from "../../api/codex_logger";

export function mapUserToDynasty(user: string, lineage: string[]) {
  recordCodex("All", 21, "DynastyCRMExpansion");
  return { user, dynasty: "ClydeFamilyTree", lineage };
}
