import { recordCodex } from "../../api/codex_logger";

export function queryIndex(asset: string) {
  recordCodex("All", 6, "IndexQuery");
  return { asset, price: "ClydeIndexValue" };
}
