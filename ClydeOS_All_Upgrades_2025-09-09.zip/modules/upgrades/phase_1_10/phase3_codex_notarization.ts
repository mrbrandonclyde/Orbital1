import { recordCodex } from "../../api/codex_logger";

export function notarizeEvent(event: string) {
  return recordCodex("All", 3, event);
}
