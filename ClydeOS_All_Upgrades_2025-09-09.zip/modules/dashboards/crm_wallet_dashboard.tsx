import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { request, gql } from "graphql-request";
import { Framework } from "@superfluid-finance/sdk-core";

// MetaMask / Alchemy provider
const provider = new ethers.JsonRpcProvider("https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY");
const treasuryAddress = "0xYourClydeTreasuryWallet";

// The Graph endpoint for ClydeOS Royalty Engine
const graphEndpoint = "https://api.thegraph.com/subgraphs/name/clydeos/royalties";

export default function CRMWalletDashboard() {
  const [balances, setBalances] = useState({
    treasuryETH: 0,
    usdRate: 2500,
    royaltiesPerSecond: 0,
    defiValue: 0,
    crossChainValue: 0
  });

  const [events, setEvents] = useState([]);

  // Fetch live ETH balance from MetaMask/Alchemy
  async function fetchBalance() {
    const balance = await provider.getBalance(treasuryAddress);
    return ethers.formatEther(balance);
  }

  // Fetch latest royalty payments from The Graph
  async function fetchRoyaltyPayments() {
    const query = gql`
      query {
        royaltyPayments(first: 5, orderBy: timestamp, orderDirection: desc) {
          id
          payer
          amount
          timestamp
        }
      }
    `;
    const data = await request(graphEndpoint, query);
    return data.royaltyPayments || [];
  }

  // Mock Zapper + DeBank API values (can be swapped with live keys)
  async function fetchDefiAndCrossChain() {
    // TODO: Replace with real API calls to Zapper/DeBank
    return { defiValue: 15000, crossChainValue: 22000 };
  }

  // Simulated Superfluid royalties per second
  async function fetchStreamingRoyalties() {
    // TODO: Replace with live Superfluid SDK flow queries
    return 0.0023; // ETH per second
  }

  useEffect(() => {
    async function loadData() {
      const ethBalance = await fetchBalance();
      const payments = await fetchRoyaltyPayments();
      const defi = await fetchDefiAndCrossChain();
      const stream = await fetchStreamingRoyalties();
      setBalances({
        treasuryETH: parseFloat(ethBalance),
        usdRate: 2500,
        royaltiesPerSecond: stream,
        defiValue: defi.defiValue,
        crossChainValue: defi.crossChainValue
      });
      setEvents(payments);
    }
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 bg-gray-900 text-white">
      <h1 className="text-2xl">💼 ClydeOS Sovereign CRM Wallet (Live)</h1>
      <h2 className="text-xl mt-4">
        Treasury Balance: {balances.treasuryETH.toFixed(2)} ETH (~$
        {(balances.treasuryETH * balances.usdRate).toLocaleString()} USD)
      </h2>

      <div className="mt-6">
        <h3 className="text-lg">Live Streams</h3>
        <ul>
          <li>Royalties Flow: {balances.royaltiesPerSecond} ETH/sec</li>
          <li>DeFi Value: ${balances.defiValue.toLocaleString()}</li>
          <li>Cross-Chain Assets: ${balances.crossChainValue.toLocaleString()}</li>
        </ul>
      </div>

      <div className="mt-6">
        <h3 className="text-lg">Recent Royalty Payments</h3>
        <table className="table-auto border-collapse border border-gray-600">
          <thead>
            <tr>
              <th className="border border-gray-600 px-4 py-2">Payer</th>
              <th className="border border-gray-600 px-4 py-2">Amount (ETH)</th>
              <th className="border border-gray-600 px-4 py-2">Timestamp</th>
            </tr>
          </thead>
          <tbody>
            {events.map((e, idx) => (
              <tr key={idx}>
                <td className="border border-gray-600 px-4 py-2">{e.payer}</td>
                <td className="border border-gray-600 px-4 py-2">{e.amount}</td>
                <td className="border border-gray-600 px-4 py-2">{e.timestamp}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
