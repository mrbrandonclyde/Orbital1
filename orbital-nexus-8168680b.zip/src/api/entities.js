import { base44 } from './base44Client';


export const World = base44.entities.World;

export const NFT = base44.entities.NFT;

export const Parcel = base44.entities.Parcel;

export const BuildingBlueprint = base44.entities.BuildingBlueprint;

export const ZoningRule = base44.entities.ZoningRule;

export const AIAvatar = base44.entities.AIAvatar;

export const SystemEvent = base44.entities.SystemEvent;

export const ZoningLayer = base44.entities.ZoningLayer;

export const ResourceMarket = base44.entities.ResourceMarket;

export const StakingPool = base44.entities.StakingPool;

export const TransitSystem = base44.entities.TransitSystem;

export const ConstructionContract = base44.entities.ConstructionContract;

export const GovernanceProposal = base44.entities.GovernanceProposal;

export const Guild = base44.entities.Guild;

export const InsurancePolicy = base44.entities.InsurancePolicy;

export const BankAccount = base44.entities.BankAccount;

export const Transaction = base44.entities.Transaction;

export const MedicalRecord = base44.entities.MedicalRecord;

export const LegalCase = base44.entities.LegalCase;

export const File = base44.entities.File;

export const GuardianCodex = base44.entities.GuardianCodex;

export const PlanetaryInfrastructure = base44.entities.PlanetaryInfrastructure;

export const TradeRoute = base44.entities.TradeRoute;

export const PlanetaryCouncil = base44.entities.PlanetaryCouncil;

export const PlanetaryDefense = base44.entities.PlanetaryDefense;

export const LunarInfrastructure = base44.entities.LunarInfrastructure;

export const MarsInfrastructure = base44.entities.MarsInfrastructure;

export const OrbitalStation = base44.entities.OrbitalStation;

export const InterplanetaryTrade = base44.entities.InterplanetaryTrade;

export const InterplanetaryGovernance = base44.entities.InterplanetaryGovernance;

export const SpaceDefense = base44.entities.SpaceDefense;

export const SpaceHealthSystem = base44.entities.SpaceHealthSystem;

export const CosmicEducation = base44.entities.CosmicEducation;

export const InterplanetaryComms = base44.entities.InterplanetaryComms;

export const AsteroidMining = base44.entities.AsteroidMining;

export const SpaceElevator = base44.entities.SpaceElevator;

export const StarshipFleet = base44.entities.StarshipFleet;

export const DeepSpaceTrade = base44.entities.DeepSpaceTrade;

export const InterstellarGovernance = base44.entities.InterstellarGovernance;

export const WarpDriveNetwork = base44.entities.WarpDriveNetwork;

export const DysonSwarm = base44.entities.DysonSwarm;

export const InterstellarTradeHub = base44.entities.InterstellarTradeHub;

export const GalacticCouncil = base44.entities.GalacticCouncil;

export const InterstellarSecurity = base44.entities.InterstellarSecurity;

export const GalacticHealthNetwork = base44.entities.GalacticHealthNetwork;

export const GalacticEducationGrid = base44.entities.GalacticEducationGrid;

export const StarForgedEconomy = base44.entities.StarForgedEconomy;

export const GalacticCommsGrid = base44.entities.GalacticCommsGrid;

export const BlackHoleEnergyHarvester = base44.entities.BlackHoleEnergyHarvester;

export const NeutronStarForge = base44.entities.NeutronStarForge;

export const GalacticTradeHub = base44.entities.GalacticTradeHub;

export const MultiGalacticGovernance = base44.entities.MultiGalacticGovernance;

export const DarkMatterEconomy = base44.entities.DarkMatterEconomy;

export const TranscendentEnergyGrid = base44.entities.TranscendentEnergyGrid;

export const TranscendentInfrastructure = base44.entities.TranscendentInfrastructure;

export const TranscendentGovernance = base44.entities.TranscendentGovernance;

export const TranscendentSecurity = base44.entities.TranscendentSecurity;

export const TranscendentHealth = base44.entities.TranscendentHealth;

export const CelestialEnergyCore = base44.entities.CelestialEnergyCore;

export const CelestialInfrastructure = base44.entities.CelestialInfrastructure;

export const CelestialGovernance = base44.entities.CelestialGovernance;

export const CelestialSecurityGrid = base44.entities.CelestialSecurityGrid;

export const CelestialHealthGrid = base44.entities.CelestialHealthGrid;

export const CelestialEducationGrid = base44.entities.CelestialEducationGrid;

export const CelestialEconomy = base44.entities.CelestialEconomy;

export const CelestialCommsGrid = base44.entities.CelestialCommsGrid;

export const CelestialTradeHub = base44.entities.CelestialTradeHub;

export const GuardianAuditLog = base44.entities.GuardianAuditLog;

export const GuardianNotification = base44.entities.GuardianNotification;



// auth sdk:
export const User = base44.auth;