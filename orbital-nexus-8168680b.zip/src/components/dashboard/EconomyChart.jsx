
import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

const data = [
  { name: 'Cycle 72', ORB: 12.80 },
  { name: 'Cycle 73', ORB: 12.95 },
  { name: 'Cycle 74', ORB: 13.15 },
  { name: 'Cycle 75', ORB: 13.05 },
  { name: 'Cycle 76', ORB: 13.28 },
  { name: 'Cycle 77', ORB: 13.40 },
  { name: 'Cycle 78', ORB: 13.37 },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-void-black/70 backdrop-blur-sm border border-primary-border p-3 rounded-lg">
        <p className="label text-sm text-primary-text">{`${label}`}</p>
        <p className="intro text-base font-bold text-plasma-green">{`ORB: $${payload[0].value.toFixed(2)}`}</p>
      </div>
    );
  }
  return null;
};

export const EconomyChart = () => (
  <ResponsiveContainer width="100%" height="100%">
    <LineChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="var(--color-low-contrast-border)" />
      <XAxis dataKey="name" stroke="var(--color-primary-text)" tick={{ fontSize: 12 }} />
      <YAxis stroke="var(--color-primary-text)" tick={{ fontSize: 12 }} domain={['dataMin - 0.2', 'dataMax + 0.2']}/>
      <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'var(--color-quantum-blue)', strokeWidth: 1, strokeDasharray: '3 3' }} />
      <defs>
        <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="var(--color-plasma-green)" stopOpacity={1} />
          <stop offset="100%" stopColor="var(--color-quantum-blue)" stopOpacity={1} />
        </linearGradient>
      </defs>
      <Line type="monotone" dataKey="ORB" stroke="url(#lineGradient)" strokeWidth={2} dot={false} activeDot={{ r: 6, fill: 'var(--color-plasma-green)', stroke: 'var(--color-starlight-white)', strokeWidth: 2 }} />
    </LineChart>
  </ResponsiveContainer>
);
