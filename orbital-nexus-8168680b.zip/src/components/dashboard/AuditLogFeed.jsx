
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, ShieldCheck } from 'lucide-react';

const initialLogs = [
    { id: 1, actor: 'kernel.security', action: 'ROLE_UPDATE', entity: 'user:0x..a4f2', timestamp: new Date(Date.now() - 5000) },
    { id: 2, actor: '0x..b1c3', action: 'NFT_MINT', entity: 'world:nova-prime', timestamp: new Date(Date.now() - 25000) },
    { id: 3, actor: 'worldgen.service', action: 'WORLD_CREATE', entity: 'world:cygnus-x1', timestamp: new Date(Date.now() - 58000) },
];

export const AuditLogFeed = () => {
    const [logs, setLogs] = useState(initialLogs);

    useEffect(() => {
        const interval = setInterval(() => {
            const newLog = {
                id: Date.now(),
                actor: 'market.service',
                action: 'ORDER_MATCH',
                entity: `order:${Math.random().toString(16).slice(2, 8)}`,
                timestamp: new Date()
            };
            setLogs(prev => [newLog, ...prev.slice(0, 4)]);
        }, 8000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="h-full flex flex-col">
            <div className="flex-grow space-y-2 overflow-hidden pr-2">
                <AnimatePresence initial={false}>
                    {logs.map(log => (
                        <motion.div
                            key={log.id}
                            layout
                            initial={{ opacity: 0, y: -20, scale: 0.9 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            transition={{ duration: 0.5, type: 'spring' }}
                            className="text-xs p-2 rounded-lg bg-void-black/50 border border-low-contrast-border flex justify-between items-center"
                        >
                            <div className="font-mono flex items-center gap-3">
                                <ShieldCheck className="w-4 h-4 text-plasma-green flex-shrink-0"/>
                                <div>
                                    <span className="text-quantum-blue">{log.action}</span>
                                    <span className="text-primary-text"> on </span>
                                    <span className="text-starlight-white">{log.entity}</span>
                                    <span className="text-primary-text"> by </span>
                                    <span className="text-highlight-yellow">{log.actor}</span>
                                </div>
                            </div>
                            <span className="text-primary-text">{log.timestamp.toLocaleTimeString()}</span>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
};
