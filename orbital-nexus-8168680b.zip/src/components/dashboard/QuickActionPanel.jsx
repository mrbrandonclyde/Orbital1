import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Users, Shield, TrendingUp, Plus, Zap, Building2, Coins } from 'lucide-react';
import { Button } from '@/components/ui/button';

const QuickAction = ({ icon: Icon, label, description, onClick, color = 'var(--orbital-blue)' }) => (
  <motion.button
    whileHover={{ scale: 1.05, y: -2 }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className="flex flex-col items-center gap-3 p-6 rounded-xl transition-all duration-200"
    style={{
      background: 'linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 212, 255, 0.05) 100%)',
      border: '1px solid rgba(0, 212, 255, 0.2)'
    }}
  >
    <div 
      className="w-12 h-12 rounded-full flex items-center justify-center"
      style={{background: `${color}20`}}
    >
      <Icon className="w-6 h-6" style={{color: color}} />
    </div>
    <div className="text-center">
      <h4 className="font-semibold text-sm mb-1" style={{color: 'var(--orbital-text)'}}>{label}</h4>
      <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    </div>
  </motion.button>
);

export const QuickActionPanel = ({ onAction }) => {
  const actions = [
    {
      icon: Globe,
      label: 'Create World',
      description: 'Generate new universe',
      action: 'create_world',
      color: 'var(--orbital-blue)'
    },
    {
      icon: Users,
      label: 'Deploy AI',
      description: 'Spawn intelligent agents',
      action: 'deploy_ai',
      color: '#22c55e'
    },
    {
      icon: Building2,
      label: 'Build City',
      description: 'Urban planning mode',
      action: 'build_city',
      color: '#f59e0b'
    },
    {
      icon: Shield,
      label: 'Security Scan',
      description: 'System integrity check',
      action: 'security_scan',
      color: '#ef4444'
    },
    {
      icon: TrendingUp,
      label: 'Market Analysis',
      description: 'Economic predictions',
      action: 'market_analysis',
      color: '#8b5cf6'
    },
    {
      icon: Coins,
      label: 'Mint ORB',
      description: 'Token generation',
      action: 'mint_orb',
      color: '#06b6d4'
    }
  ];

  return (
    <div className="chrome-surface rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-6">
        <Zap className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
        <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>QUICK ACTIONS</h3>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {actions.map((action, index) => (
          <motion.div
            key={action.action}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <QuickAction
              icon={action.icon}
              label={action.label}
              description={action.description}
              color={action.color}
              onClick={() => onAction?.(action.action)}
            />
          </motion.div>
        ))}
      </div>

      <div className="mt-6 pt-4" style={{borderTop: '1px solid rgba(0, 212, 255, 0.2)'}}>
        <Button 
          className="w-full glow-blue"
          style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
          onClick={() => onAction?.('advanced_mode')}
        >
          <Plus className="w-4 h-4 mr-2" />
          ADVANCED COMMAND MODE
        </Button>
      </div>
    </div>
  );
};