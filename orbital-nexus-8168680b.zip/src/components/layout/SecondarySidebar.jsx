import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';

export const SecondarySidebar = ({ menuItems, title }) => {
  const location = useLocation();

  if (!menuItems || menuItems.length === 0) return null;

  return (
    <motion.div
      initial={{ x: '-100%', opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: '-100%', opacity: 0 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="w-64 flex-shrink-0"
      style={{
        background: 'var(--sidebar-surface)',
        borderRight: '1px solid var(--sidebar-border)',
        boxShadow: '2px 0 10px rgba(0, 0, 0, 0.5)'
      }}
    >
      <div className="p-4 h-20 flex items-center" style={{ borderBottom: '1px solid var(--sidebar-border)' }}>
        <h2 className="font-bold text-lg tracking-wider" style={{ color: 'var(--orbital-text)' }}>
          {title}
        </h2>
      </div>
      <div className="p-2">
        <nav role="navigation" aria-label={title}>
          <ul>
            {menuItems.map((item, index) => {
              if (item.isHeader) {
                return (
                  <li key={`header-${index}`} className="px-3 py-2 text-xs font-bold tracking-wider uppercase" style={{color: 'var(--orbital-text-dim)'}}>
                    {item.title}
                  </li>
                );
              }

              if (item.isSeparator) {
                return <li key={`sep-${index}`}><hr className="my-2" style={{borderColor: 'var(--sidebar-border)'}} /></li>;
              }

              const isActive = location.pathname === item.url.split('?')[0] && location.search === (item.url.split('?')[1] ? `?${item.url.split('?')[1]}` : '');
              return (
                <li key={item.title}>
                  <Link
                    to={item.url}
                    className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 hover:bg-blue-500/20 ${isActive ? 'glow-blue' : ''}`}
                    style={{
                      minHeight: 'var(--min-touch-target)',
                      background: isActive ? 'var(--sidebar-hover)' : 'transparent',
                    }}
                    aria-current={isActive ? 'page' : undefined}
                  >
                    <item.icon 
                      className="w-5 h-5" 
                      style={{ color: isActive ? 'var(--orbital-blue)' : 'var(--orbital-text-dim)' }}
                      aria-hidden="true" 
                    />
                    <span 
                      className="font-medium text-sm" 
                      style={{ color: isActive ? 'var(--orbital-text)' : 'var(--orbital-text-dim)' }}
                    >
                      {item.title}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </motion.div>
  );
};