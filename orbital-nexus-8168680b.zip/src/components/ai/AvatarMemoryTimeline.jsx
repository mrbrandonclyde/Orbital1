import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Brain, Zap, Star, Target, Shield, Eye, Filter } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

export const AvatarMemoryTimeline = ({ avatar }) => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [memoryIntelligence, setMemoryIntelligence] = useState(98.4);

  const eventTypeColors = {
    skill_evolution: '#8b5cf6',
    superman_evolution: '#00d4ff',
    mission_completion: '#22c55e',
    social_interaction: '#f59e0b',
    learning_event: '#3b82f6',
    combat_engagement: '#ef4444',
    construction_project: '#06b6d4'
  };

  const eventTypeIcons = {
    skill_evolution: Brain,
    superman_evolution: Zap,
    mission_completion: Target,
    social_interaction: Star,
    learning_event: Eye,
    combat_engagement: Shield,
    construction_project: Star
  };

  const getFilteredMemories = () => {
    if (!avatar?.memory_timeline) return [];
    
    return avatar.memory_timeline
      .filter(event => selectedFilter === 'all' || event.event_type === selectedFilter)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  const getEventTypeLabel = (type) => {
    return type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const filteredMemories = getFilteredMemories();

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .memory-glow {
          box-shadow: 0 0 25px rgba(0, 212, 255, 0.3), 0 0 50px rgba(0, 212, 255, 0.1);
          animation: memoryPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes memoryPulse {
          0% { 
            box-shadow: 0 0 25px rgba(0, 212, 255, 0.3), 0 0 50px rgba(0, 212, 255, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(0, 212, 255, 0.5), 0 0 70px rgba(0, 212, 255, 0.2);
          }
        }

        .timeline-connector {
          background: linear-gradient(to bottom, transparent, rgba(0, 212, 255, 0.3), transparent);
          animation: dataFlow 3s ease-in-out infinite;
        }

        @keyframes dataFlow {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.8; }
        }

        .memory-node {
          position: relative;
        }

        .memory-node::before {
          content: '';
          position: absolute;
          left: -12px;
          top: 50%;
          transform: translateY(-50%);
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: var(--orbital-blue);
          box-shadow: 0 0 10px var(--orbital-blue);
          animation: nodePulse 2s ease-in-out infinite;
        }

        @keyframes nodePulse {
          0%, 100% { transform: translateY(-50%) scale(1); }
          50% { transform: translateY(-50%) scale(1.3); }
        }
      `}</style>

      {/* Header */}
      <Card className="chrome-surface memory-glow mb-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between" style={{ color: 'var(--orbital-text)' }}>
            <div className="flex items-center gap-2">
              <Clock className="w-6 h-6" style={{ color: 'var(--orbital-blue)' }} />
              ETERNAL MEMORY TIMELINE
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                className="font-bold px-3 py-1"
                style={{ background: 'linear-gradient(45deg, var(--orbital-blue), #8b5cf6)', color: '#000' }}
              >
                <Brain className="w-4 h-4 mr-1" />
                INFINITE RECALL: {memoryIntelligence}%
              </Badge>
            </div>
          </CardTitle>
          <div className="mt-2">
            <p style={{ color: 'var(--orbital-text-dim)' }}>
              Neural archive for: {avatar?.name} • {filteredMemories.length} memories indexed
            </p>
          </div>
        </CardHeader>
      </Card>

      {/* Filters */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4" style={{ color: 'var(--orbital-blue)' }} />
          <span className="font-semibold">Memory Filter:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {['all', ...Object.keys(eventTypeColors)].map(filter => (
            <Button
              key={filter}
              variant={selectedFilter === filter ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedFilter(filter)}
              className={`text-xs ${selectedFilter === filter ? 'memory-glow' : 'chrome-surface'}`}
              style={selectedFilter === filter ? 
                { background: 'var(--orbital-blue)', color: 'var(--orbital-black)' } : 
                {}
              }
            >
              {filter === 'all' ? 'All Memories' : getEventTypeLabel(filter)}
            </Button>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <Card className="chrome-surface memory-glow">
        <CardContent className="p-6">
          <ScrollArea className="h-96 pr-4">
            <div className="relative">
              {/* Timeline Connector */}
              <div 
                className="absolute left-0 top-0 bottom-0 w-0.5 timeline-connector"
                style={{ left: '12px' }}
              />
              
              <div className="space-y-6 ml-8">
                <AnimatePresence>
                  {filteredMemories.map((memory, index) => {
                    const EventIcon = eventTypeIcons[memory.event_type] || Brain;
                    const eventColor = eventTypeColors[memory.event_type] || 'var(--orbital-blue)';
                    
                    return (
                      <motion.div
                        key={`${memory.timestamp}-${index}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ delay: index * 0.1 }}
                        className="memory-node p-4 rounded-xl transition-all duration-300"
                        style={{ 
                          background: `${eventColor}10`,
                          border: `1px solid ${eventColor}30`
                        }}
                        whileHover={{ 
                          scale: 1.02, 
                          boxShadow: `0 0 20px ${eventColor}40` 
                        }}
                      >
                        <div className="flex items-start gap-3">
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center"
                            style={{ background: `${eventColor}20`, border: `2px solid ${eventColor}` }}
                          >
                            <EventIcon className="w-5 h-5" style={{ color: eventColor }} />
                          </div>
                          
                          <div className="flex-grow">
                            <div className="flex items-center justify-between mb-2">
                              <Badge 
                                className="text-xs font-bold"
                                style={{ 
                                  background: eventColor, 
                                  color: '#fff'
                                }}
                              >
                                {getEventTypeLabel(memory.event_type)}
                              </Badge>
                              <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                                {new Date(memory.timestamp).toLocaleString()}
                              </span>
                            </div>
                            
                            <p className="text-sm mb-2" style={{ color: 'var(--orbital-text)' }}>
                              {memory.description}
                            </p>
                            
                            {memory.impact_score && (
                              <div className="flex items-center gap-2">
                                <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                                  Neural Impact:
                                </span>
                                <div className="flex items-center gap-1">
                                  {Array.from({ length: Math.min(5, Math.ceil(memory.impact_score / 20)) }).map((_, i) => (
                                    <Star key={i} className="w-3 h-3" style={{ color: eventColor }} fill={eventColor} />
                                  ))}
                                  <span className="text-xs font-semibold ml-1" style={{ color: eventColor }}>
                                    {memory.impact_score}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
                
                {filteredMemories.length === 0 && (
                  <div className="text-center py-12">
                    <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" style={{ color: 'var(--orbital-text-dim)' }} />
                    <p style={{ color: 'var(--orbital-text-dim)' }}>
                      No memories found for the selected filter.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};