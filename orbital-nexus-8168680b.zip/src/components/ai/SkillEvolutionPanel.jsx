import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Zap, TrendingUp, Star, Target, GitBranch, Award, Cpu } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

export const SkillEvolutionPanel = ({ avatar, onSkillUpdate }) => {
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [evolutionInProgress, setEvolutionInProgress] = useState(false);
  const [quantumEnhancement, setQuantumEnhancement] = useState(false);

  const skillCategories = [
    {
      name: 'Quantum Engineering',
      description: 'Advanced construction and reality manipulation',
      level: avatar?.skills?.find(s => s.name === 'quantum_engineering')?.level || 0,
      maxLevel: 100,
      evolutionRate: 0.8,
      icon: Cpu,
      color: '#8b5cf6'
    },
    {
      name: 'Tactical Analysis',
      description: 'Strategic planning and battlefield coordination', 
      level: avatar?.skills?.find(s => s.name === 'tactical_analysis')?.level || 0,
      maxLevel: 100,
      evolutionRate: 0.6,
      icon: Target,
      color: '#3b82f6'
    },
    {
      name: 'Resource Optimization',
      description: 'Economic efficiency and supply chain mastery',
      level: avatar?.skills?.find(s => s.name === 'resource_optimization')?.level || 0,
      maxLevel: 100,
      evolutionRate: 0.7,
      icon: TrendingUp,
      color: '#22c55e'
    },
    {
      name: 'Diplomatic Relations',
      description: 'Cross-faction negotiation and alliance building',
      level: avatar?.skills?.find(s => s.name === 'diplomatic_relations')?.level || 0,
      maxLevel: 100,
      evolutionRate: 0.5,
      icon: GitBranch,
      color: '#f59e0b'
    },
    {
      name: 'Threat Assessment',
      description: 'Security analysis and risk mitigation',
      level: avatar?.skills?.find(s => s.name === 'threat_assessment')?.level || 0,
      maxLevel: 100,
      evolutionRate: 0.9,
      icon: Award,
      color: '#ef4444'
    }
  ];

  const handleSkillEvolution = async (skill) => {
    setEvolutionInProgress(true);
    setQuantumEnhancement(Math.random() > 0.7); // 30% chance for quantum enhancement
    
    // Simulate AI evolution process
    setTimeout(() => {
      const baseImprovement = Math.floor(Math.random() * 5) + 1;
      const quantumBonus = quantumEnhancement ? Math.floor(Math.random() * 10) + 5 : 0;
      const totalImprovement = baseImprovement + quantumBonus;
      
      if (onSkillUpdate) {
        onSkillUpdate(skill.name.toLowerCase().replace(/\s+/g, '_'), totalImprovement);
      }
      
      setEvolutionInProgress(false);
      setQuantumEnhancement(false);
    }, 2000);
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .evolution-glow {
          box-shadow: 0 0 25px rgba(139, 92, 246, 0.3), 0 0 50px rgba(139, 92, 246, 0.1);
          animation: evolutionPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes evolutionPulse {
          0% { 
            box-shadow: 0 0 25px rgba(139, 92, 246, 0.3), 0 0 50px rgba(139, 92, 246, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(139, 92, 246, 0.5), 0 0 70px rgba(139, 92, 246, 0.2);
          }
        }

        .quantum-enhancement {
          background: linear-gradient(45deg, #8b5cf6, #00d4ff, #22c55e, #f59e0b);
          background-size: 400% 400%;
          animation: quantumFlow 2s ease infinite;
        }

        @keyframes quantumFlow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .skill-evolution-active {
          animation: skillPulse 1s ease-in-out infinite;
        }

        @keyframes skillPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
      `}</style>

      {/* Header */}
      <Card className="chrome-surface evolution-glow mb-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between" style={{ color: 'var(--orbital-text)' }}>
            <div className="flex items-center gap-2">
              <Brain className="w-6 h-6" style={{ color: '#8b5cf6' }} />
              SKILL EVOLUTION MATRIX
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                className="font-bold px-3 py-1"
                style={{ background: 'linear-gradient(45deg, #8b5cf6, #00d4ff)', color: '#000' }}
              >
                <Zap className="w-4 h-4 mr-1" />
                AI EVOLUTION ACTIVE
              </Badge>
              {quantumEnhancement && (
                <Badge className="quantum-enhancement font-bold px-3 py-1 text-black">
                  🌌 QUANTUM BOOST
                </Badge>
              )}
            </div>
          </CardTitle>
          <p style={{ color: 'var(--orbital-text-dim)' }}>
            Neural pathways expanding for: {avatar?.name}. Intelligence Level: {avatar?.intelligence_level}%
          </p>
        </CardHeader>
      </Card>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {skillCategories.map((skill, index) => (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`chrome-surface rounded-2xl p-6 transition-all duration-300 ${
              evolutionInProgress && selectedSkill?.name === skill.name ? 'skill-evolution-active' : ''
            }`}
            whileHover={{ y: -3, boxShadow: `0 0 20px ${skill.color}40` }}
            style={{ borderLeft: `4px solid ${skill.color}` }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <skill.icon className="w-6 h-6" style={{ color: skill.color }} />
                <div>
                  <h4 className="font-bold" style={{ color: 'var(--orbital-text)' }}>
                    {skill.name}
                  </h4>
                  <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
                    {skill.description}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold" style={{ color: skill.color }}>
                  {skill.level}%
                </div>
                <div className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                  Level
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <Progress 
                value={skill.level} 
                className="h-3"
                style={{ backgroundColor: `${skill.color}20` }}
              />
              <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--orbital-text-dim)' }}>
                <span>Novice</span>
                <span>Master</span>
              </div>
            </div>

            {/* Evolution Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div>
                <span style={{ color: 'var(--orbital-text-dim)' }}>Evolution Rate:</span>
                <span className="ml-2 font-semibold" style={{ color: skill.color }}>
                  {(skill.evolutionRate * 100).toFixed(0)}%
                </span>
              </div>
              <div>
                <span style={{ color: 'var(--orbital-text-dim)' }}>Next Upgrade:</span>
                <span className="ml-2 font-semibold" style={{ color: 'var(--orbital-text)' }}>
                  {Math.max(0, 100 - skill.level)}pts
                </span>
              </div>
            </div>

            {/* Evolution Button */}
            <Button 
              className="w-full font-bold"
              style={{ background: skill.color, color: '#000' }}
              disabled={evolutionInProgress || skill.level >= 100}
              onClick={() => {
                setSelectedSkill(skill);
                handleSkillEvolution(skill);
              }}
            >
              {evolutionInProgress && selectedSkill?.name === skill.name ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  <Cpu className="w-4 h-4 mr-2" />
                </motion.div>
              ) : (
                <Star className="w-4 h-4 mr-2" />
              )}
              {skill.level >= 100 ? 'MASTERED' : 
               evolutionInProgress && selectedSkill?.name === skill.name ? 'EVOLVING...' : 'EVOLVE SKILL'}
            </Button>
          </motion.div>
        ))}
      </div>

      {/* Evolution History */}
      {avatar?.memory_timeline && (
        <Card className="chrome-surface mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
              <GitBranch className="w-5 h-5" style={{ color: '#8b5cf6' }} />
              RECENT EVOLUTION EVENTS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-48 overflow-y-auto">
              {avatar.memory_timeline
                .filter(event => event.event_type === 'superman_evolution' || event.event_type === 'skill_evolution')
                .slice(0, 5)
                .map((event, index) => (
                  <div key={index} className="flex items-center gap-3 p-2 rounded-lg" style={{ background: 'rgba(139, 92, 246, 0.05)' }}>
                    <Zap className="w-4 h-4" style={{ color: '#8b5cf6' }} />
                    <div className="flex-grow">
                      <p className="text-sm" style={{ color: 'var(--orbital-text)' }}>{event.description}</p>
                      <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                        {new Date(event.timestamp).toLocaleString()} • Impact: {event.impact_score}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};