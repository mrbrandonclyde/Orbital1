import React from 'react';
import { motion } from 'framer-motion';
import { ImageIcon, Zap, Eye } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export const NFTCard = ({ nft, onSelect, isSelected }) => {
  const cardVariants = {
    initial: { opacity: 0, y: 20, scale: 0.95 },
    animate: { opacity: 1, y: 0, scale: 1 },
    exit: { opacity: 0, y: -20, scale: 0.95 },
  };

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -8, boxShadow: '0 0 40px rgba(0, 212, 255, 0.5)', scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      className={`chrome-surface rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer relative ${
        isSelected ? 'border-2 border-blue-400 glow-blue' : 'border border-transparent'
      }`}
      onClick={onSelect ? () => onSelect(nft.id) : undefined}
    >
      <div className="relative h-48 bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center overflow-hidden">
        {nft.thumbnail_url ? (
           <img src={nft.thumbnail_url} alt={nft.name} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
        ) : (
          <ImageIcon className="w-16 h-16" style={{color: 'var(--orbital-blue)'}} />
        )}
        <div className="absolute top-2 right-2">
          <Badge className="chrome-surface text-xs" style={{color: 'var(--orbital-blue)', background: 'rgba(0, 212, 255, 0.1)'}}>
            {nft.asset_type?.toUpperCase()}
          </Badge>
        </div>
        {onSelect && (
          <div className={`absolute top-2 left-2 w-5 h-5 rounded-full flex items-center justify-center transition-all ${isSelected ? 'bg-blue-500 border-2 border-white' : 'bg-black/50 border-2 border-gray-500'}`}>
            {isSelected && <Zap className="w-3 h-3 text-white" />}
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold mb-2 truncate" style={{color: 'var(--orbital-text)'}}>{nft.name}</h3>
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm font-mono" style={{color: 'var(--orbital-text-dim)'}}>#{nft.token_id?.slice(0, 8)}...</span>
          <div className="text-lg font-bold" style={{color: 'var(--orbital-blue)'}}>
            {Math.floor(Math.random() * 5000 + 500)} ORB
          </div>
        </div>
        <Button className="w-full font-bold" style={{background: 'var(--orbital-blue)', color: '#000'}}>
          <Eye className="w-4 h-4 mr-2" /> View Details
        </Button>
      </div>
    </motion.div>
  );
};