import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, Grid, List, TrendingUp, Eye, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const AssetCard = ({ asset, viewMode = 'grid', onView, onBuy }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className={`chrome-surface rounded-xl overflow-hidden transition-all duration-300 ${
      viewMode === 'list' ? 'flex items-center' : ''
    }`}
  >
    <div className={`${viewMode === 'grid' ? 'h-48' : 'w-32 h-32'} bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center flex-shrink-0`}>
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center" style={{background: 'rgba(0, 212, 255, 0.2)'}}>
          <ShoppingCart className="w-8 h-8" style={{color: 'var(--orbital-blue)'}} />
        </div>
        {viewMode === 'grid' && (
          <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Asset Preview</p>
        )}
      </div>
    </div>
    
    <div className={`p-4 ${viewMode === 'list' ? 'flex-grow flex items-center justify-between' : ''}`}>
      <div className={viewMode === 'list' ? 'flex items-center gap-4' : ''}>
        <div>
          <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>{asset.name}</h3>
          <div className="flex items-center gap-2 mb-2">
            <Badge className="chrome-surface" style={{color: 'var(--orbital-blue)'}}>
              {asset.asset_type.toUpperCase()}
            </Badge>
            {asset.rarity && (
              <Badge variant="outline" style={{borderColor: asset.rarity === 'legendary' ? '#f59e0b' : '#22c55e', color: asset.rarity === 'legendary' ? '#f59e0b' : '#22c55e'}}>
                {asset.rarity}
              </Badge>
            )}
          </div>
          <p className="text-sm mb-2" style={{color: 'var(--orbital-text-dim)'}}>
            Owner: {asset.owner_wallet?.slice(0, 8)}...
          </p>
        </div>
        
        {viewMode === 'list' && (
          <div className="text-right">
            <div className="text-xl font-bold mb-2" style={{color: 'var(--orbital-blue)'}}>
              {asset.price} ORB
            </div>
          </div>
        )}
      </div>
      
      {viewMode === 'grid' && (
        <>
          <div className="flex justify-between items-center mb-3">
            <div className="text-lg font-bold" style={{color: 'var(--orbital-blue)'}}>
              {asset.price} ORB
            </div>
            <div className="flex items-center gap-1 text-xs" style={{color: 'var(--orbital-text-dim)'}}>
              <TrendingUp className="w-3 h-3" />
              +{asset.priceChange}%
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 chrome-surface text-xs"
              onClick={() => onView?.(asset)}
            >
              <Eye className="w-3 h-3 mr-1" />
              View
            </Button>
            <Button 
              size="sm" 
              className="flex-1 glow-blue text-xs"
              style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
              onClick={() => onBuy?.(asset)}
            >
              <ShoppingCart className="w-3 h-3 mr-1" />
              Buy
            </Button>
          </div>
        </>
      )}
      
      {viewMode === 'list' && (
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="chrome-surface"
            onClick={() => onView?.(asset)}
          >
            <Eye className="w-4 h-4 mr-1" />
            View
          </Button>
          <Button 
            size="sm" 
            className="glow-blue"
            style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
            onClick={() => onBuy?.(asset)}
          >
            <ShoppingCart className="w-4 h-4 mr-1" />
            Buy Now - {asset.price} ORB
          </Button>
        </div>
      )}
    </div>
  </motion.div>
);

export const AssetBrowser = ({ assets = [], onAssetAction }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  // Mock assets if none provided
  const mockAssets = [
    {
      id: 1,
      name: "Quantum Blade",
      asset_type: "weapon",
      price: 1200,
      priceChange: 15.2,
      owner_wallet: "0x742d35Cc6635C0532925a3b8D0C9a6bFc8b4C44a",
      rarity: "legendary"
    },
    {
      id: 2,
      name: "Orbital Armor Set",
      asset_type: "armor",
      price: 3500,
      priceChange: -2.1,
      owner_wallet: "0x8ba1f109551bD432803012645Hac136c60B4F045c",
      rarity: "epic"
    },
    {
      id: 3,
      name: "Nova Prime Parcel",
      asset_type: "parcel",
      price: 15000,
      priceChange: 8.7,
      owner_wallet: "0x4E6B6E7729Cc5d4c33e3b8dF7c6d8e9FaB1C2d3E",
      rarity: "rare"
    }
  ];

  const displayAssets = assets.length > 0 ? assets : mockAssets;

  const filteredAssets = displayAssets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || asset.asset_type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="w-full">
      {/* Search and Controls */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{color: 'var(--orbital-text-dim)'}} />
          <Input
            placeholder="Search assets..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 chrome-surface"
            style={{color: 'var(--orbital-text)', borderColor: 'rgba(0, 212, 255, 0.3)'}}
          />
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="chrome-surface"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            onClick={() => setViewMode('grid')}
            className={viewMode === 'grid' ? 'glow-blue' : 'chrome-surface'}
            style={viewMode === 'grid' ? {background: 'var(--orbital-blue)', color: 'var(--orbital-black)'} : {}}
          >
            <Grid className="w-4 h-4" />
          </Button>
          
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            onClick={() => setViewMode('list')}
            className={viewMode === 'list' ? 'glow-blue' : 'chrome-surface'}
            style={viewMode === 'list' ? {background: 'var(--orbital-blue)', color: 'var(--orbital-black)'} : {}}
          >
            <List className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Assets Grid/List */}
      <div className={
        viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
          : 'space-y-4'
      }>
        <AnimatePresence>
          {filteredAssets.map((asset) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              viewMode={viewMode}
              onView={(asset) => onAssetAction?.('view', asset)}
              onBuy={(asset) => onAssetAction?.('buy', asset)}
            />
          ))}
        </AnimatePresence>
      </div>

      {/* Empty State */}
      {filteredAssets.length === 0 && (
        <div className="text-center py-12">
          <ShoppingCart className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Assets Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
};