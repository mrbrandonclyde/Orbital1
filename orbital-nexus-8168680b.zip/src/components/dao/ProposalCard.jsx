import React from 'react';
import { motion } from 'framer-motion';
import { Vote, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

export const ProposalCard = ({ proposal, onVote, onView }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'Active':
        return { color: 'var(--orbital-blue)', icon: Clock };
      case 'Passed':
        return { color: '#22c55e', icon: CheckCircle };
      case 'Failed':
        return { color: '#ef4444', icon: XCircle };
      default:
        return { color: 'var(--orbital-text-dim)', icon: Clock };
    }
  };

  const statusInfo = getStatusInfo(proposal.status);
  const StatusIcon = statusInfo.icon;

  const votesFor = proposal.votes_for || 0;
  const votesAgainst = proposal.votes_against || 0;
  const totalVotes = votesFor + votesAgainst;
  const forPercentage = totalVotes > 0 ? (votesFor / totalVotes) * 100 : 0;

  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300"
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>{proposal.id}</p>
          <h3 className="font-bold text-lg" style={{ color: 'var(--orbital-text)' }}>{proposal.title}</h3>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full text-sm" style={{ background: `${statusInfo.color}20`, color: statusInfo.color }}>
          <StatusIcon className="w-4 h-4" />
          <span>{proposal.status}</span>
        </div>
      </div>

      <p className="text-sm mb-4" style={{ color: 'var(--orbital-text-dim)' }}>{proposal.summary}</p>
      
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-1">
          <span style={{ color: '#22c55e' }}>FOR: {votesFor.toLocaleString()}</span>
          <span style={{ color: '#ef4444' }}>AGAINST: {votesAgainst.toLocaleString()}</span>
        </div>
        <Progress value={forPercentage} className="h-2" />
      </div>

      <div className="flex gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 chrome-surface text-xs"
          onClick={() => onView?.(proposal)}
        >
          View Details
        </Button>
        <Button 
          size="sm" 
          className="flex-1 glow-blue text-xs"
          style={{ background: 'var(--orbital-blue)', color: 'var(--orbital-black)' }}
          onClick={() => onVote?.(proposal, 'for')}
          disabled={proposal.status !== 'Active'}
        >
          <Vote className="w-4 h-4 mr-2" />
          Vote Now
        </Button>
      </div>
    </motion.div>
  );
};