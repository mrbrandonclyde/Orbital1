import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, TrendingDown, DollarSign, Activity, Zap, Brain, Target, BarChart3 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export const TradingInterface = () => {
  const [selectedPair, setSelectedPair] = useState('ORB/USDC');
  const [orderType, setOrderType] = useState('market');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [aiTradingEnabled, setAiTradingEnabled] = useState(false);
  const [marketData, setMarketData] = useState({
    price: 13.47,
    change24h: 8.7,
    volume24h: 2847293,
    high24h: 14.12,
    low24h: 12.89
  });

  const tradingPairs = [
    { symbol: 'ORB/USDC', price: 13.47, change: 8.7, volume: 2847293 },
    { symbol: 'ORB/ETH', price: 0.0043, change: -2.1, volume: 1293847 },
    { symbol: 'ORB/BTC', price: 0.000087, change: 12.4, volume: 847293 },
    { symbol: 'LAND/ORB', price: 2500, change: 15.6, volume: 293847 },
    { symbol: 'AVATAR/ORB', price: 150, change: -3.2, volume: 184729 }
  ];

  const recentTrades = [
    { price: 13.47, amount: 1250, time: '14:23:15', type: 'buy' },
    { price: 13.45, amount: 890, time: '14:23:12', type: 'sell' },
    { price: 13.48, amount: 2100, time: '14:23:08', type: 'buy' },
    { price: 13.44, amount: 567, time: '14:23:05', type: 'sell' },
    { price: 13.49, amount: 1890, time: '14:23:01', type: 'buy' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData(prev => ({
        ...prev,
        price: parseFloat((prev.price + (Math.random() - 0.5) * 0.1).toFixed(2)),
        volume24h: prev.volume24h + Math.floor(Math.random() * 1000)
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleTrade = (side) => {
    // Simulate trade execution
    const tradeData = {
      pair: selectedPair,
      side,
      type: orderType,
      quantity: parseFloat(quantity),
      price: orderType === 'market' ? marketData.price : parseFloat(price),
      timestamp: new Date().toISOString()
    };
    
    console.log('Trade executed:', tradeData);
    setQuantity('');
    setPrice('');
  };

  const getPriceColor = (change) => {
    return change >= 0 ? '#22c55e' : '#ef4444';
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .trading-glow {
          box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          animation: tradingPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes tradingPulse {
          0% { 
            box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(34, 197, 94, 0.5), 0 0 70px rgba(34, 197, 94, 0.2);
          }
        }

        .ai-trading-active {
          background: linear-gradient(45deg, #8b5cf6, #00d4ff, #22c55e);
          background-size: 200% 200%;
          animation: aiTradingFlow 4s ease infinite;
        }

        @keyframes aiTradingFlow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .price-up {
          color: #22c55e;
          animation: priceFlash 0.5s ease;
        }

        .price-down {
          color: #ef4444;
          animation: priceFlash 0.5s ease;
        }

        @keyframes priceFlash {
          0% { opacity: 1; }
          50% { opacity: 0.6; }
          100% { opacity: 1; }
        }
      `}</style>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trading Pairs */}
        <Card className="chrome-surface trading-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
              <BarChart3 className="w-5 h-5" style={{ color: '#22c55e' }} />
              TRADING PAIRS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {tradingPairs.map((pair) => (
                <motion.div
                  key={pair.symbol}
                  whileHover={{ scale: 1.02 }}
                  onClick={() => setSelectedPair(pair.symbol)}
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    selectedPair === pair.symbol ? 'ai-trading-active' : ''
                  }`}
                  style={{
                    background: selectedPair === pair.symbol ? '' : 'rgba(0, 212, 255, 0.05)',
                    border: `1px solid ${selectedPair === pair.symbol ? 'transparent' : 'rgba(0, 212, 255, 0.2)'}`
                  }}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-bold" style={{ color: selectedPair === pair.symbol ? '#000' : 'var(--orbital-text)' }}>
                        {pair.symbol}
                      </p>
                      <p className="text-sm" style={{ color: selectedPair === pair.symbol ? '#000' : 'var(--orbital-text-dim)' }}>
                        Vol: {(pair.volume / 1000).toFixed(0)}K
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold" style={{ color: selectedPair === pair.symbol ? '#000' : getPriceColor(pair.change) }}>
                        ${pair.price.toFixed(pair.price < 1 ? 6 : 2)}
                      </p>
                      <p className={`text-sm ${pair.change >= 0 ? 'price-up' : 'price-down'}`}>
                        {pair.change >= 0 ? '+' : ''}{pair.change}%
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Trading Panel */}
        <Card className="chrome-surface trading-glow">
          <CardHeader>
            <CardTitle className="flex items-center justify-between" style={{ color: 'var(--orbital-text)' }}>
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5" style={{ color: '#22c55e' }} />
                TRADE: {selectedPair}
              </div>
              <Button
                size="sm"
                onClick={() => setAiTradingEnabled(!aiTradingEnabled)}
                className={aiTradingEnabled ? 'ai-trading-active text-black font-bold' : 'chrome-surface'}
              >
                <Brain className="w-4 h-4 mr-2" />
                AI {aiTradingEnabled ? 'ON' : 'OFF'}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Order Type Selection */}
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant={orderType === 'market' ? 'default' : 'outline'}
                  onClick={() => setOrderType('market')}
                  className={orderType === 'market' ? 'trading-glow' : 'chrome-surface'}
                  style={orderType === 'market' ? { background: '#22c55e', color: '#000' } : {}}
                >
                  Market
                </Button>
                <Button
                  size="sm"
                  variant={orderType === 'limit' ? 'default' : 'outline'}
                  onClick={() => setOrderType('limit')}
                  className={orderType === 'limit' ? 'trading-glow' : 'chrome-surface'}
                  style={orderType === 'limit' ? { background: '#22c55e', color: '#000' } : {}}
                >
                  Limit
                </Button>
              </div>

              {/* Current Price Display */}
              <div className="p-4 rounded-lg chrome-surface text-center">
                <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Current Price</p>
                <p className="text-2xl font-bold" style={{ color: '#22c55e' }}>
                  ${marketData.price.toFixed(2)}
                </p>
                <p className={`text-sm ${marketData.change24h >= 0 ? 'price-up' : 'price-down'}`}>
                  {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h}% (24h)
                </p>
              </div>

              {/* Order Inputs */}
              <div className="space-y-3">
                <Input
                  type="number"
                  placeholder="Quantity"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="chrome-surface"
                  style={{ color: 'var(--orbital-text)', borderColor: 'rgba(34, 197, 94, 0.3)' }}
                />
                
                {orderType === 'limit' && (
                  <Input
                    type="number"
                    placeholder="Price"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="chrome-surface"
                    style={{ color: 'var(--orbital-text)', borderColor: 'rgba(34, 197, 94, 0.3)' }}
                  />
                )}
              </div>

              {/* Trading Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => handleTrade('buy')}
                  disabled={!quantity}
                  className="trading-glow font-bold"
                  style={{ background: '#22c55e', color: '#000' }}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  BUY
                </Button>
                <Button
                  onClick={() => handleTrade('sell')}
                  disabled={!quantity}
                  className="font-bold"
                  style={{ background: '#ef4444', color: '#fff' }}
                >
                  <TrendingDown className="w-4 h-4 mr-2" />
                  SELL
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Trades */}
        <Card className="chrome-surface trading-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
              <Activity className="w-5 h-5" style={{ color: '#22c55e' }} />
              RECENT TRADES
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {recentTrades.map((trade, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex justify-between items-center p-2 rounded"
                  style={{ background: 'rgba(0, 212, 255, 0.05)' }}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ background: trade.type === 'buy' ? '#22c55e' : '#ef4444' }}
                    />
                    <span className="text-sm font-mono" style={{ color: getPriceColor(trade.type === 'buy' ? 1 : -1) }}>
                      ${trade.price.toFixed(2)}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm" style={{ color: 'var(--orbital-text)' }}>
                      {trade.amount.toLocaleString()}
                    </p>
                    <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                      {trade.time}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Trading Alert */}
      {aiTradingEnabled && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 p-4 rounded-xl ai-trading-active"
        >
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-black" />
            <div>
              <h3 className="font-bold text-black">AI TRADING ASSISTANT ACTIVE</h3>
              <p className="text-sm text-black opacity-80">
                Monitoring market conditions and executing optimal trades based on real-time analysis
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};