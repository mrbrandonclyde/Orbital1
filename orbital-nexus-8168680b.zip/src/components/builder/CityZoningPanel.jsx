import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Layers, Zap, Brain, Settings, Eye, MapPin, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';

export const CityZoningPanel = ({ worldId, onZoningChange }) => {
  const [activeZone, setActiveZone] = useState(null);
  const [aiOptimizationEnabled, setAiOptimizationEnabled] = useState(true);
  const [zoningParameters, setZoningParameters] = useState({
    density: [0.7],
    height_limit: [150],
    green_space_ratio: [0.25],
    transport_accessibility: [0.8]
  });

  const zoningTypes = [
    {
      type: 'residential',
      name: 'Residential Zone',
      color: '#22c55e',
      description: 'Housing and community spaces',
      ai_score: 94,
      conflicts: 0
    },
    {
      type: 'commercial',
      name: 'Commercial District',
      color: '#3b82f6',
      description: 'Retail and business centers',
      ai_score: 87,
      conflicts: 1
    },
    {
      type: 'industrial',
      name: 'Industrial Zone',
      color: '#f59e0b',
      description: 'Manufacturing and logistics',
      ai_score: 91,
      conflicts: 2
    },
    {
      type: 'mixed_use',
      name: 'Mixed Use Hub',
      color: '#06b6d4',
      description: 'Integrated live-work-play',
      ai_score: 96,
      conflicts: 0
    },
    {
      type: 'recreational',
      name: 'Recreation Area',
      color: '#8b5cf6',
      description: 'Parks and entertainment',
      ai_score: 98,
      conflicts: 0
    },
    {
      type: 'transportation',
      name: 'Transit Hub',
      color: '#22c55e',
      description: 'Transportation infrastructure',
      ai_score: 89,
      conflicts: 1
    }
  ];

  const handleZoningUpdate = (zoneType, parameters) => {
    if (onZoningChange) {
      onZoningChange({
        worldId,
        zoneType,
        parameters,
        aiOptimized: aiOptimizationEnabled,
        timestamp: new Date().toISOString()
      });
    }
  };

  const getConflictSeverity = (conflictCount) => {
    if (conflictCount === 0) return 'success';
    if (conflictCount <= 2) return 'warning';
    return 'danger';
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .zoning-panel-glow {
          box-shadow: 0 0 25px rgba(6, 182, 212, 0.3), 0 0 50px rgba(6, 182, 212, 0.1);
          animation: zoningPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes zoningPulse {
          0% { 
            box-shadow: 0 0 25px rgba(6, 182, 212, 0.3), 0 0 50px rgba(6, 182, 212, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(6, 182, 212, 0.5), 0 0 70px rgba(6, 182, 212, 0.2);
          }
        }

        .zone-active {
          background: linear-gradient(45deg, rgba(6, 182, 212, 0.15), rgba(6, 182, 212, 0.05));
          border: 2px solid rgba(6, 182, 212, 0.6);
        }

        .ai-optimization-active {
          background: linear-gradient(45deg, #8b5cf6, #00d4ff, #22c55e);
          background-size: 200% 200%;
          animation: aiFlow 4s ease infinite;
        }

        @keyframes aiFlow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

      {/* Header */}
      <Card className="chrome-surface zoning-panel-glow">
        <CardHeader>
          <CardTitle className="flex items-center justify-between" style={{ color: 'var(--orbital-text)' }}>
            <div className="flex items-center gap-2">
              <Layers className="w-6 h-6" style={{ color: '#06b6d4' }} />
              QUANTUM CITY ZONING
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                className={`font-bold px-3 py-1 ${aiOptimizationEnabled ? 'ai-optimization-active text-black' : 'chrome-surface'}`}
              >
                <Brain className="w-4 h-4 mr-1" />
                AI {aiOptimizationEnabled ? 'ACTIVE' : 'DISABLED'}
              </Badge>
              <Button
                size="sm"
                variant={aiOptimizationEnabled ? 'default' : 'outline'}
                onClick={() => setAiOptimizationEnabled(!aiOptimizationEnabled)}
                className={aiOptimizationEnabled ? 'ai-optimization-active text-black border-0' : 'chrome-surface'}
              >
                <Zap className="w-4 h-4 mr-1" />
                Toggle AI
              </Button>
            </div>
          </CardTitle>
          <p style={{ color: 'var(--orbital-text-dim)' }}>
            Intelligent zoning system with conflict detection and blockchain anchoring for World: {worldId}
          </p>
        </CardHeader>
        <CardContent>
          {/* Zone Types Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {zoningTypes.map((zone, index) => (
              <motion.div
                key={zone.type}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-xl cursor-pointer transition-all ${
                  activeZone?.type === zone.type ? 'zone-active' : ''
                }`}
                style={{ 
                  background: activeZone?.type === zone.type ? '' : `${zone.color}15`,
                  border: `2px solid ${zone.color}40`
                }}
                onClick={() => setActiveZone(zone)}
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-bold" style={{ color: 'var(--orbital-text)' }}>
                      {zone.name}
                    </h4>
                    <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                      {zone.description}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold" style={{ color: zone.color }}>
                      {zone.ai_score}%
                    </div>
                    <div className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                      AI Score
                    </div>
                  </div>
                </div>
                
                {/* Conflict Indicator */}
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    {zone.conflicts > 0 ? (
                      <AlertTriangle className="w-4 h-4" style={{ color: '#f59e0b' }} />
                    ) : (
                      <div className="w-4 h-4 rounded-full" style={{ background: '#22c55e' }} />
                    )}
                    <span className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                      {zone.conflicts} conflicts
                    </span>
                  </div>
                  <Badge 
                    variant="outline"
                    style={{ 
                      borderColor: zone.color, 
                      color: zone.color,
                      background: `${zone.color}10`
                    }}
                    className="text-xs"
                  >
                    {zone.type.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Active Zone Configuration */}
          <AnimatePresence>
            {activeZone && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-6 rounded-xl"
                style={{ 
                  background: `${activeZone.color}10`,
                  border: `2px solid ${activeZone.color}30`
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold" style={{ color: 'var(--orbital-text)' }}>
                    Configure {activeZone.name}
                  </h3>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="chrome-surface">
                      <Eye className="w-4 h-4 mr-1" />
                      3D Preview
                    </Button>
                    <Button 
                      size="sm" 
                      className="ai-optimization-active text-black border-0"
                      onClick={() => handleZoningUpdate(activeZone.type, zoningParameters)}
                    >
                      <Settings className="w-4 h-4 mr-1" />
                      Apply Changes
                    </Button>
                  </div>
                </div>

                {/* Parameter Controls */}
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
                      Building Density: {zoningParameters.density[0]}
                    </label>
                    <Slider
                      value={zoningParameters.density}
                      onValueChange={(value) => setZoningParameters({...zoningParameters, density: value})}
                      max={1}
                      min={0.1}
                      step={0.1}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
                      Height Limit: {zoningParameters.height_limit[0]}m
                    </label>
                    <Slider
                      value={zoningParameters.height_limit}
                      onValueChange={(value) => setZoningParameters({...zoningParameters, height_limit: value})}
                      max={300}
                      min={10}
                      step={10}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
                      Green Space Ratio: {(zoningParameters.green_space_ratio[0] * 100).toFixed(0)}%
                    </label>
                    <Slider
                      value={zoningParameters.green_space_ratio}
                      onValueChange={(value) => setZoningParameters({...zoningParameters, green_space_ratio: value})}
                      max={0.5}
                      min={0.1}
                      step={0.05}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--orbital-text-dim)' }}>
                      Transport Accessibility: {(zoningParameters.transport_accessibility[0] * 100).toFixed(0)}%
                    </label>
                    <Slider
                      value={zoningParameters.transport_accessibility}
                      onValueChange={(value) => setZoningParameters({...zoningParameters, transport_accessibility: value})}
                      max={1}
                      min={0.2}
                      step={0.1}
                      className="w-full"
                    />
                  </div>
                </div>

                {/* AI Recommendations */}
                {aiOptimizationEnabled && (
                  <div className="mt-6 p-4 rounded-lg" style={{ background: 'rgba(139, 92, 246, 0.1)' }}>
                    <h4 className="font-bold mb-2 flex items-center gap-2" style={{ color: '#8b5cf6' }}>
                      <Brain className="w-4 h-4" />
                      AI RECOMMENDATIONS
                    </h4>
                    <div className="space-y-2 text-sm">
                      <p style={{ color: 'var(--orbital-text-dim)' }}>
                        • Increase transport accessibility to 90% for optimal traffic flow
                      </p>
                      <p style={{ color: 'var(--orbital-text-dim)' }}>
                        • Consider adding 5% more green space for environmental balance
                      </p>
                      <p style={{ color: 'var(--orbital-text-dim)' }}>
                        • Current configuration achieves {activeZone.ai_score}% efficiency score
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  );
};