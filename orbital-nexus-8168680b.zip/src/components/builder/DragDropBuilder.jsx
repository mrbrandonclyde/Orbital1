
import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Building2, Home, Factory, Store, TreePine, Route, Save, Eye, Undo, Redo } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const DragDropBuilder = ({ onSave, worldId }) => {
  const [buildingElements, setBuildingElements] = useState([]);
  const [selectedTool, setSelectedTool] = useState(null);
  const [draggedItem, setDraggedItem] = useState(null);
  const [buildingHistory, setBuildingHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  const buildingTools = [
    {
      id: 'residential',
      name: 'Residential',
      icon: Home,
      color: '#22c55e',
      description: 'Houses and apartments'
    },
    {
      id: 'commercial',
      name: 'Commercial',
      icon: Store,
      color: '#3b82f6',
      description: 'Shops and offices'
    },
    {
      id: 'industrial',
      name: 'Industrial',
      icon: Factory,
      color: '#f59e0b',
      description: 'Factories and warehouses'
    },
    {
      id: 'infrastructure',
      name: 'Infrastructure',
      icon: Route,
      color: '#6b7280',
      description: 'Roads and utilities'
    },
    {
      id: 'recreational',
      name: 'Recreational',
      icon: TreePine,
      color: '#8b5cf6',
      description: 'Parks and entertainment'
    },
    {
      id: 'mixed_use',
      name: 'Mixed Use',
      icon: Building2,
      color: '#06b6d4',
      description: 'Multi-purpose buildings'
    }
  ];

  const handleDragStart = (e, tool) => {
    setDraggedItem(tool);
    setSelectedTool(tool);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    if (!draggedItem) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newElement = {
      id: Date.now(),
      type: draggedItem.id,
      x: x,
      y: y,
      width: 80,
      height: 80,
      color: draggedItem.color,
      name: draggedItem.name
    };

    const newElements = [...buildingElements, newElement];
    setBuildingElements(newElements);
    
    // Save to history
    const newHistory = buildingHistory.slice(0, historyIndex + 1);
    newHistory.push(newElements);
    setBuildingHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    setDraggedItem(null);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setBuildingElements(buildingHistory[historyIndex - 1] || []);
    }
  };

  const handleRedo = () => {
    if (historyIndex < buildingHistory.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setBuildingElements(buildingHistory[historyIndex + 1]);
    }
  };

  const handleSave = () => {
    const blueprintData = {
      name: `Generated Blueprint ${Date.now()}`,
      type: 'mixed_use',
      world_id: worldId,
      blueprint_data: {
        layout: buildingElements,
        modules: buildingElements.map(el => ({
          type: el.type,
          position: { x: el.x, y: el.y },
          dimensions: { width: el.width, height: el.height }
        })),
        dependencies: []
      },
      construction_status: 'draft',
      ai_suggestions: [
        'Consider adding more green space for sustainability',
        'Optimize building placement for traffic flow',
        'Add utility connections between structures'
      ],
      estimated_cost: buildingElements.length * 1000 + Math.floor(Math.random() * 5000)
    };

    if (onSave) {
      onSave(blueprintData);
    }
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .builder-glow {
          box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          animation: builderPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes builderPulse {
          0% { 
            box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(34, 197, 94, 0.5), 0 0 70px rgba(34, 197, 94, 0.2);
          }
        }

        .builder-canvas {
          background-image: 
            linear-gradient(rgba(0, 212, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 212, 255, 0.1) 1px, transparent 1px);
          background-size: 20px 20px;
        }

        .tool-active {
          background: linear-gradient(45deg, rgba(34, 197, 94, 0.2), rgba(34, 197, 94, 0.1));
          border: 2px solid rgba(34, 197, 94, 0.6);
        }
      `}</style>

      <Card className="chrome-surface builder-glow">
        <CardHeader>
          <CardTitle className="flex items-center justify-between" style={{ color: 'var(--orbital-text)' }}>
            <div className="flex items-center gap-2">
              <Building2 className="w-6 h-6" style={{ color: '#22c55e' }} />
              DRAG & DROP BUILDER
            </div>
            <div className="flex items-center gap-2">
              <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000' }}>
                🏗️ LIVE BUILDER
              </Badge>
              <Button size="sm" onClick={handleUndo} disabled={historyIndex <= 0} className="chrome-surface">
                <Undo className="w-4 h-4" />
              </Button>
              <Button size="sm" onClick={handleRedo} disabled={historyIndex >= buildingHistory.length - 1} className="chrome-surface">
                <Redo className="w-4 h-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Tool Palette */}
            <div className="space-y-3">
              <h3 className="font-bold" style={{ color: 'var(--orbital-text)' }}>BUILDING TOOLS</h3>
              {buildingTools.map((tool) => (
                <motion.div
                  key={tool.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, tool)}
                  className={`p-4 rounded-xl cursor-grab active:cursor-grabbing transition-all ${
                    selectedTool?.id === tool.id ? 'tool-active' : ''
                  }`}
                  style={{ 
                    background: selectedTool?.id === tool.id ? '' : `${tool.color}15`,
                    border: `2px solid ${tool.color}40`
                  }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <tool.icon className="w-5 h-5" style={{ color: tool.color }} />
                    <div>
                      <h4 className="font-semibold text-sm" style={{ color: 'var(--orbital-text)' }}>
                        {tool.name}
                      </h4>
                      <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
                        {tool.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
              
              <div className="pt-4 space-y-2">
                <Button 
                  onClick={handleSave} 
                  disabled={buildingElements.length === 0}
                  className="w-full builder-glow font-bold"
                  style={{ background: '#22c55e', color: '#000' }}
                >
                  <Save className="w-4 h-4 mr-2" />
                  SAVE BLUEPRINT
                </Button>
                <Button variant="outline" className="w-full chrome-surface">
                  <Eye className="w-4 h-4 mr-2" />
                  3D Preview
                </Button>
              </div>
            </div>

            {/* Building Canvas */}
            <div className="lg:col-span-3">
              <div 
                className="relative w-full h-96 rounded-xl builder-canvas chrome-surface"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                <div className="absolute inset-4 text-center text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
                  {buildingElements.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <div>
                        <Building2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>Drag building tools here to start creating</p>
                        <p className="text-xs mt-1">Your blueprint will appear on this canvas</p>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute top-2 left-2 bg-black bg-opacity-70 px-2 py-1 rounded text-xs">
                      {buildingElements.length} elements • World: {worldId}
                    </div>
                  )}
                </div>

                {/* Rendered Building Elements */}
                <AnimatePresence>
                  {buildingElements.map((element) => (
                    <motion.div
                      key={element.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="absolute rounded-lg flex items-center justify-center text-xs font-bold cursor-pointer"
                      style={{
                        left: `${element.x}px`,
                        top: `${element.y}px`,
                        width: `${element.width}px`,
                        height: `${element.height}px`,
                        backgroundColor: `${element.color}40`,
                        border: `2px solid ${element.color}`,
                        color: element.color
                      }}
                      whileHover={{ scale: 1.1, zIndex: 10 }}
                      onClick={() => {
                        // Element selection logic could go here
                        console.log('Selected element:', element);
                      }}
                    >
                      {element.name}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Building Stats */}
              {buildingElements.length > 0 && (
                <div className="mt-4 p-4 rounded-xl" style={{ background: 'rgba(34, 197, 94, 0.1)' }}>
                  <h4 className="font-bold mb-2" style={{ color: '#22c55e' }}>BLUEPRINT STATISTICS</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                        {buildingElements.length}
                      </div>
                      <div style={{ color: 'var(--orbital-text-dim)' }}>Total Elements</div>
                    </div>
                    <div>
                      <div className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                        {buildingElements.filter(el => el.type === 'residential').length}
                      </div>
                      <div style={{ color: 'var(--orbital-text-dim)' }}>Residential</div>
                    </div>
                    <div>
                      <div className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                        {buildingElements.filter(el => el.type === 'commercial').length}
                      </div>
                      <div style={{ color: 'var(--orbital-text-dim)' }}>Commercial</div>
                    </div>
                    <div>
                      <div className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                        {(buildingElements.length * 1000 + Math.floor(Math.random() * 5000)).toLocaleString()}
                      </div>
                      <div style={{ color: 'var(--orbital-text-dim)' }}>Est. Cost (ORB)</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
