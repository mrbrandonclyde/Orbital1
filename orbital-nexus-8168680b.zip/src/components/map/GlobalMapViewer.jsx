import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Globe, Layers, Zap, Building, TreePine, Droplets, Landmark, Satellite, Navigation, Eye } from 'lucide-react';
import * as THREE from 'three';
import { Button } from '@/components/ui/button';

export const GlobalMapViewer = ({ zoningRules, currentView = 'Planet' }) => {
  const mountRef = useRef(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const mountNode = mountRef.current;

    // THREE.js Scene Setup with Enhanced Graphics
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, mountNode.clientWidth / mountNode.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    
    renderer.setSize(mountNode.clientWidth, mountNode.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mountNode.appendChild(renderer.domElement);

    // Enhanced Planet with Dynamic Views
    const geometry = new THREE.SphereGeometry(2, 64, 64);
    const material = new THREE.MeshPhongMaterial({
      map: new THREE.TextureLoader().load('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=800'),
      specularMap: new THREE.TextureLoader().load('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=800'),
      shininess: 20
    });
    const planet = new THREE.Mesh(geometry, material);
    planet.castShadow = true;
    planet.receiveShadow = true;
    scene.add(planet);

    // Enhanced Atmosphere with View-Based Effects
    const atmosphereGeometry = new THREE.SphereGeometry(2.1, 64, 64);
    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize( normalMatrix * normal );
          gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        uniform float viewIntensity;
        void main() {
          float intensity = pow( 0.7 - dot( vNormal, vec3( 0, 0, 1.0 ) ), 4.0 ) * viewIntensity; 
          gl_FragColor = vec4( 0.5, 0.8, 1.0, 1.0 ) * intensity;
        }
      `,
      uniforms: {
        viewIntensity: { value: 1.0 }
      },
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true
    });
    const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    scene.add(atmosphere);

    // Enhanced Lighting System
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.5);
    directionalLight.position.set(5, 3, 5);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    // View-Based Camera Positioning
    const setCameraForView = (view) => {
      switch (view) {
        case 'Planet':
          camera.position.set(0, 0, 5);
          atmosphereMaterial.uniforms.viewIntensity.value = 1.0;
          break;
        case 'City':
          camera.position.set(2, 1, 3);
          atmosphereMaterial.uniforms.viewIntensity.value = 0.7;
          break;
        case 'Parcel':
          camera.position.set(1.5, 0.5, 2.5);
          atmosphereMaterial.uniforms.viewIntensity.value = 0.5;
          break;
        case 'Satellite':
          camera.position.set(0, 8, 0);
          camera.lookAt(0, 0, 0);
          atmosphereMaterial.uniforms.viewIntensity.value = 1.2;
          break;
        default:
          camera.position.set(0, 0, 5);
      }
    };

    setCameraForView(currentView);

    // Enhanced Zoning Rules Visualization
    const zoningMeshes = [];
    if (zoningRules) {
      zoningRules.forEach((rule, index) => {
        const { x, y, width, height } = rule.area_geometry;
        const planeGeo = new THREE.PlaneGeometry(width * 0.01, height * 0.01);
        
        // Color coding based on rule type
        let color = 0x00d4ff;
        switch (rule.rule_type) {
          case 'HEIGHT_LIMIT': color = 0x00d4ff; break;
          case 'SETBACK': color = 0x22c55e; break;
          case 'FAR': color = 0xf59e0b; break;
          case 'USE_RESTRICTION': color = 0x8b5cf6; break;
          case 'DENSITY': color = 0xef4444; break;
        }
        
        const planeMat = new THREE.MeshBasicMaterial({ 
          color: color, 
          transparent: true, 
          opacity: rule.status === 'ACTIVE' ? 0.7 : 0.3, 
          side: THREE.DoubleSide 
        });
        const plane = new THREE.Mesh(planeGeo, planeMat);
        
        // Position on sphere surface with enhanced calculations
        const phi = (90 - y) * (Math.PI / 180);
        const theta = (x + 180) * (Math.PI / 180);
        const radius = 2.05;

        plane.position.x = -radius * Math.sin(phi) * Math.cos(theta);
        plane.position.y = radius * Math.cos(phi);
        plane.position.z = radius * Math.sin(phi) * Math.sin(theta);
        plane.lookAt(planet.position);
        
        scene.add(plane);
        zoningMeshes.push(plane);
      });
    }

    // Enhanced Animation Loop
    let animationSpeed = 0.001;
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Adjust rotation speed based on view
      switch (currentView) {
        case 'Planet': animationSpeed = 0.001; break;
        case 'City': animationSpeed = 0.0005; break;
        case 'Parcel': animationSpeed = 0.0002; break;
        case 'Satellite': animationSpeed = 0.002; break;
      }
      
      planet.rotation.y += animationSpeed;
      
      // Animate zoning rules
      zoningMeshes.forEach((mesh, index) => {
        mesh.material.opacity = 0.5 + 0.3 * Math.sin(Date.now() * 0.002 + index);
      });
      
      renderer.render(scene, camera);
    };
    animate();

    // Enhanced Resize Handler
    const handleResize = () => {
      if (mountRef.current) {
        const width = mountRef.current.clientWidth;
        const height = mountRef.current.clientHeight;
        
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      }
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountNode && renderer.domElement) {
        mountNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [zoningRules, currentView]);

  const getViewInfo = () => {
    switch (currentView) {
      case 'Planet': return { icon: Globe, label: 'Planet View', color: '#00d4ff' };
      case 'City': return { icon: Building, label: 'City View', color: '#22c55e' };
      case 'Parcel': return { icon: Navigation, label: 'Parcel View', color: '#f59e0b' };
      case 'Satellite': return { icon: Satellite, label: 'Satellite View', color: '#8b5cf6' };
      default: return { icon: Globe, label: 'Planet View', color: '#00d4ff' };
    }
  };

  const viewInfo = getViewInfo();
  const ViewIcon = viewInfo.icon;

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden chrome-surface p-2">
      <style jsx>{`
        .map-glow {
          box-shadow: 0 0 40px rgba(0, 212, 255, 0.4), inset 0 0 30px rgba(0, 212, 255, 0.2);
          animation: mapPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes mapPulse {
          0% { box-shadow: 0 0 40px rgba(0, 212, 255, 0.4), inset 0 0 30px rgba(0, 212, 255, 0.2); }
          100% { box-shadow: 0 0 60px rgba(0, 212, 255, 0.6), inset 0 0 50px rgba(0, 212, 255, 0.3); }
        }

        .view-indicator {
          background: linear-gradient(135deg, rgba(0, 0, 0, 0.8) 0%, rgba(0, 0, 0, 0.6) 100%);
          backdrop-filter: blur(12px);
          border: 1px solid ${viewInfo.color}50;
          box-shadow: 0 0 20px ${viewInfo.color}30;
        }
      `}</style>

      <div ref={mountRef} className="w-full h-full rounded-lg map-glow" />
      
      {/* Enhanced View Indicators */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="absolute top-4 left-4 flex gap-2"
      >
        <div className="view-indicator p-3 rounded-xl flex items-center gap-2">
          <ViewIcon className="w-5 h-5" style={{color: viewInfo.color}} />
          <span className="font-bold text-sm">{viewInfo.label}</span>
        </div>
        
        {zoningRules && zoningRules.length > 0 && (
          <div className="view-indicator p-3 rounded-xl flex items-center gap-2">
            <Layers className="w-5 h-5 text-green-400" />
            <span className="font-bold text-sm">{zoningRules.length} Zoning Layers</span>
          </div>
        )}
      </motion.div>
      
      {/* Enhanced Layer Legend */}
      <div className="absolute bottom-4 left-4 grid grid-cols-2 gap-2">
        {[
          { icon: Building, label: 'Cities', color: '#facc15' },
          { icon: TreePine, label: 'Biomes', color: '#4ade80' },
          { icon: Droplets, label: 'Water', color: '#60a5fa' },
          { icon: Landmark, label: 'Landmarks', color: '#f472b6' },
        ].map(item => (
          <motion.div 
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="view-indicator px-3 py-2 rounded-lg flex items-center gap-2 text-xs"
          >
            <item.icon className="w-4 h-4" style={{color: item.color}} />
            <span>{item.label}</span>
          </motion.div>
        ))}
      </div>

      {/* Enhanced Control Buttons */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <Button variant="outline" size="icon" className="chrome-surface bg-black/30 hover:glow-blue">
          <Zap className="w-4 h-4 text-yellow-400" />
        </Button>
        <Button variant="outline" size="icon" className="chrome-surface bg-black/30 hover:glow-blue">
          <Eye className="w-4 h-4" style={{color: viewInfo.color}} />
        </Button>
      </div>

      {/* Enhanced Status Bar */}
      <div className="absolute bottom-4 right-4 view-indicator px-4 py-2 rounded-lg">
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span>LIVE TRACKING • {currentView.toUpperCase()}</span>
        </div>
      </div>
    </div>
  );
};