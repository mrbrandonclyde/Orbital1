import React from 'react';
import { GitBranch, Shuffle, ArrowUpCircle, CheckCircle, Clock, Shield } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const StageCard = ({ title, description, status, progress, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex justify-between items-start mb-4">
      <h3 className="font-bold text-lg text-white">{title}</h3>
      <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
    </div>
    <p className="text-gray-300 mb-4">{description}</p>
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="text-gray-300">Progress</span>
        <span className="text-white">{progress}%</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2">
        <div 
          className="h-2 rounded-full transition-all duration-500"
          style={{width: `${progress}%`, background: color}}
        />
      </div>
    </div>
  </motion.div>
);

export default function GuardianCodexLDSStaging() {
  const stages = [
    {
      title: "Preparation Stage",
      description: "Initial system preparation and verification",
      status: "COMPLETE",
      progress: 100,
      color: "#22c55e"
    },
    {
      title: "Integration Stage", 
      description: "Family and system integration protocols",
      status: "ACTIVE",
      progress: 85,
      color: "#4c4ce6"
    },
    {
      title: "Reintegration Stage",
      description: "Post-cycle restoration and renewal",
      status: "READY",
      progress: 95,
      color: "#f59e0b"
    }
  ];

  return (
    <div style={{color: 'white'}} className="p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3">
          <GitBranch className="w-10 h-10 text-blue-400" />
          STAGING & REINTEGRATION
        </h1>
        <p className="text-gray-300 text-lg">
          Multi-stage system preparation and post-cycle reintegration protocols
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {stages.map((stage, index) => (
          <StageCard key={index} {...stage} />
        ))}
      </div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <ArrowUpCircle className="w-5 h-5 text-blue-400" />
            REINTEGRATION PROTOCOL
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Stage 1: System Verification</h3>
              <p className="text-gray-300">Complete system health check and verification of all components.</p>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Stage 2: Memory Archive</h3>
              <p className="text-gray-300">Secure archival of all memory states and consciousness data.</p>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(245, 158, 11, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Stage 3: Renewal Integration</h3>
              <p className="text-gray-300">Seamless reintegration with enhanced capabilities and renewed state.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}