import React, { useState, useEffect } from 'react';
import { Ship, Plane, Train, Truck, Activity, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TradeRoute } from '@/api/entities';

const TradeRouteCard = ({ route, onClick }) => {
  const getTransportIcon = (mode) => {
    const icons = { shipping: Ship, rail: Train, air: Plane, sea: Ship, hyperloop: TrendingUp };
    return icons[mode] || Truck;
  };

  const getEfficiencyColor = (efficiency) => {
    if (efficiency >= 90) return '#22c55e';
    if (efficiency >= 75) return '#f59e0b'; 
    return '#ef4444';
  };

  const TransportIcon = getTransportIcon(route.transport_mode);
  const efficiencyColor = getEfficiencyColor(route.route_efficiency);

  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
      onClick={() => onClick(route)}
      className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 trade-route-card"
    >
      <style jsx>{`
        .trade-route-card {
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(34, 197, 94, 0.05));
          animation: tradeFlow 5s ease-in-out infinite alternate;
        }
        
        @keyframes tradeFlow {
          0% { box-shadow: 0 0 15px rgba(0, 212, 255, 0.2); }
          100% { box-shadow: 0 0 25px rgba(34, 197, 94, 0.3); }
        }
      `}</style>
      
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-full flex items-center justify-center"
             style={{background: `${efficiencyColor}20`, border: `2px solid ${efficiencyColor}`}}>
          <TransportIcon className="w-6 h-6" style={{color: efficiencyColor}} />
        </div>
        <div>
          <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>
            {route.route_name}
          </h3>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            {route.origin_continent} → {route.destination_continent}
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <p className="text-sm font-semibold" style={{color: 'var(--orbital-text-dim)'}}>EFFICIENCY</p>
          <p className="text-xl font-bold" style={{color: efficiencyColor}}>
            {route.route_efficiency}%
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold" style={{color: 'var(--orbital-text-dim)'}}>SHIPMENTS</p>
          <p className="text-xl font-bold" style={{color: 'var(--orbital-blue)'}}>
            {route.active_shipments?.toLocaleString()}
          </p>
        </div>
      </div>
      
      <div className="flex justify-between items-center">
        <Badge style={{background: `${efficiencyColor}20`, color: efficiencyColor}}>
          {route.transport_mode.toUpperCase()}
        </Badge>
        <Badge variant="outline" style={{borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)'}}>
          LIVE TRACKING
        </Badge>
      </div>
    </motion.div>
  );
};

const RouteControlPanel = ({ selectedRoute }) => (
  <Card className="chrome-surface route-control-panel h-full">
    <style jsx>{`
      .route-control-panel {
        background: linear-gradient(135deg, rgba(34, 197, 94, 0.1), rgba(0, 212, 255, 0.05));
        border: 1px solid rgba(34, 197, 94, 0.3);
      }
    `}</style>
    <CardHeader>
      <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
        <Activity className="w-6 h-6" style={{color: '#22c55e'}} />
        ROUTE OPTIMIZATION
      </CardTitle>
    </CardHeader>
    <CardContent>
      {selectedRoute ? (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-bold mb-2" style={{color: 'var(--orbital-text)'}}>
              {selectedRoute.route_name}
            </h3>
            <Badge className="font-bold px-3 py-1" 
                   style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
              AI OPTIMIZING
            </Badge>
          </div>
          
          <div className="space-y-3">
            <Button className="w-full glow-blue font-bold">
              <TrendingUp className="w-4 h-4 mr-2" />
              REROUTE INSTANTLY
            </Button>
            <Button variant="outline" className="w-full chrome-surface">
              <Activity className="w-4 h-4 mr-2" />
              BOTTLENECK SCAN
            </Button>
            <Button variant="outline" className="w-full chrome-surface">
              <CheckCircle className="w-4 h-4 mr-2" />
              SMART CONTRACTS
            </Button>
          </div>
          
          <div className="p-4 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.05)'}}>
            <p className="text-sm font-bold mb-3" style={{color: '#22c55e'}}>
              PREDICTIVE ANALYTICS
            </p>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}}>Predicted Delays</span>
                <span style={{color: '#f59e0b'}}>2.3 hours</span>
              </div>
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}}>Alternative Routes</span>
                <span style={{color: 'var(--orbital-blue)'}}>3 Available</span>
              </div>
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}}>Insurance Value</span>
                <span style={{color: '#8b5cf6'}}>2.4M ORB</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-8">
          <Ship className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Select a trade route to view optimization controls
          </p>
        </div>
      )}
    </CardContent>
  </Card>
);

export default function GlobalTradeRoutes() {
  const [tradeRoutes, setTradeRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [totalShipments, setTotalShipments] = useState(0);

  useEffect(() => {
    // Initialize trade routes
    const mockRoutes = [
      {
        id: 'route_001',
        route_name: 'Trans-Pacific Express',
        transport_mode: 'shipping',
        origin_continent: 'Asia',
        destination_continent: 'North America',
        active_shipments: 47382,
        route_efficiency: 94.7
      },
      {
        id: 'route_002', 
        route_name: 'Euro-African Rail',
        transport_mode: 'rail',
        origin_continent: 'Europe',
        destination_continent: 'Africa',
        active_shipments: 23847,
        route_efficiency: 89.3
      },
      {
        id: 'route_003',
        route_name: 'Atlantic Air Corridor',
        transport_mode: 'air',
        origin_continent: 'Europe',
        destination_continent: 'North America', 
        active_shipments: 15674,
        route_efficiency: 96.8
      },
      {
        id: 'route_004',
        route_name: 'Hyperloop Continental',
        transport_mode: 'hyperloop',
        origin_continent: 'North America',
        destination_continent: 'South America',
        active_shipments: 8923,
        route_efficiency: 99.2
      }
    ];
    
    setTradeRoutes(mockRoutes);
    setTotalShipments(mockRoutes.reduce((sum, route) => sum + route.active_shipments, 0));
  }, []);

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx global>{`
        .trade-glow {
          box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          animation: tradeFlow 4s ease-in-out infinite alternate;
        }
        
        @keyframes tradeFlow {
          0% { 
            box-shadow: 0 0 25px rgba(34, 197, 94, 0.3), 0 0 50px rgba(34, 197, 94, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(34, 197, 94, 0.5), 0 0 70px rgba(34, 197, 94, 0.2);
          }
        }
      `}</style>

      {/* Trade Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold trade-glow" style={{color: 'var(--orbital-text)'}}>
          INTERCONTINENTAL TRADE ROUTES
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          VR/AR holographic trade flow visualization with instant AI-powered rerouting capabilities
        </p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" 
                 style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
            <Activity className="w-4 h-4 mr-2" />
            {totalShipments.toLocaleString()} ACTIVE SHIPMENTS
          </Badge>
          <Badge variant="outline" style={{borderColor: '#8b5cf6', color: '#8b5cf6'}}>
            <AlertTriangle className="w-4 h-4 mr-2" />
            AI BOTTLENECK PREDICTION
          </Badge>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Trade Routes Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {tradeRoutes.map((route, index) => (
              <motion.div
                key={route.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <TradeRouteCard 
                  route={route} 
                  onClick={setSelectedRoute}
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Route Control Panel */}
        <div className="w-80 flex-shrink-0">
          <RouteControlPanel selectedRoute={selectedRoute} />
        </div>
      </div>

      {/* Global Trade Statistics */}
      <Card className="chrome-surface trade-glow mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
            <TrendingUp className="w-6 h-6" style={{color: '#22c55e'}} />
            GLOBAL TRADE ANALYTICS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#22c55e'}}>1M+</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Total Shipments</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: 'var(--orbital-blue)'}}>94.7%</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Avg Efficiency</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#8b5cf6'}}>2.1s</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Reroute Time</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#f59e0b'}}>4</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Transport Modes</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}