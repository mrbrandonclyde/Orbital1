
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mountain, Droplets, Wind, Sun, Bot, Save, Globe } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const ControlCard = ({ title, icon: Icon, children }) => (
  <Card className="chrome-surface">
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-base">
        <Icon className="w-5 h-5 text-orbital-blue" />
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

export default function TerrainGenerator() {
  const [seed, setSeed] = useState(Math.floor(Math.random() * 100000));
  const [terrainType, setTerrainType] = useState('continental');
  const [waterLevel, setWaterLevel] = useState([40]);
  const [mountainousness, setMountainousness] = useState([60]);
  const [climate, setClimate] = useState('temperate');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => setIsGenerating(false), 2500);
  };
  
  const handleRandomizeSeed = () => {
    setSeed(Math.floor(Math.random() * 100000));
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">TERRAIN GENERATOR</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Sculpt new worlds with divine, procedural algorithms.</p>
        </div>
        <Button onClick={handleGenerate} disabled={isGenerating} className="glow-blue font-bold" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
          <Globe className="w-5 h-5 mr-2" />
          {isGenerating ? 'GENERATING...' : 'GENERATE WORLD'}
        </Button>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Column */}
        <div className="lg:col-span-1 space-y-6">
          <ControlCard title="Procedural Seed" icon={Bot}>
            <div className="flex gap-2">
              <input value={seed} onChange={e => setSeed(e.target.value)} className="w-full bg-transparent border border-gray-600 rounded-md px-3 py-2" />
              <Button variant="outline" onClick={handleRandomizeSeed}>Randomize</Button>
            </div>
          </ControlCard>

          <ControlCard title="Landmass" icon={Mountain}>
            <div className="space-y-4">
              <Select value={terrainType} onValueChange={setTerrainType}>
                <SelectTrigger className="chrome-surface"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="continental">Continental</SelectItem>
                  <SelectItem value="archipelago">Archipelago</SelectItem>
                  <SelectItem value="pangea">Pangea</SelectItem>
                </SelectContent>
              </Select>
              <div>
                <label className="text-sm mb-2 block">Mountainousness: {mountainousness[0]}%</label>
                <Slider value={mountainousness} onValueChange={setMountainousness} />
              </div>
            </div>
          </ControlCard>

          <ControlCard title="Hydrosphere" icon={Droplets}>
             <div>
                <label className="text-sm mb-2 block">Water Level: {waterLevel[0]}%</label>
                <Slider value={waterLevel} onValueChange={setWaterLevel} />
              </div>
          </ControlCard>

          <ControlCard title="Climate" icon={Sun}>
            <Select value={climate} onValueChange={setClimate}>
              <SelectTrigger className="chrome-surface"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="arid">Arid</SelectItem>
                <SelectItem value="temperate">Temperate</SelectItem>
                <SelectItem value="tropical">Tropical</SelectItem>
                <SelectItem value="frozen">Frozen</SelectItem>
              </SelectContent>
            </Select>
          </ControlCard>
           <Button variant="outline" className="w-full"><Save className="w-4 h-4 mr-2" /> Save Terrain Profile</Button>
        </div>

        {/* Preview Column */}
        <motion.div 
          className="lg:col-span-2"
          initial={{opacity:0, scale:0.9}} 
          animate={{opacity:1, scale:1}} 
          transition={{delay: 0.2}}
        >
          <Card className="chrome-surface h-full min-h-[600px] flex items-center justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={isGenerating ? 'loading' : seed}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.5 }}
                className="w-full h-full"
              >
                {isGenerating ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <motion.div animate={{rotate: 360}} transition={{duration: 1, repeat: Infinity, ease: 'linear'}}>
                      <Globe className="w-24 h-24 text-orbital-blue animate-pulse" />
                    </motion.div>
                    <p className="mt-4 text-lg">Forging Reality...</p>
                  </div>
                ) : (
                  <div className="w-full h-full bg-gray-900 rounded-lg overflow-hidden relative">
                    {/* This would be a 3D canvas, using an image as a placeholder */}
                    <img 
                      src={`https://source.unsplash.com/1600x900/?nature,landscape&seed=${seed}`}
                      className="w-full h-full object-cover opacity-70"
                      alt="Generated Terrain"
                    />
                    <div className="absolute inset-0 bg-black/30"></div>
                     <div className="absolute bottom-4 left-4 p-2 rounded-lg chrome-surface text-xs">
                        Seed: {seed} | Climate: {climate}
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
