import React, { useState, useEffect } from 'react';
import { Store, ShoppingCart, TrendingUp, Filter, Tag, Search, Sparkles, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { NFT } from '@/api/entities';

const AssetItem = ({ nft }) => (
  <motion.div
    layout
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.8 }}
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl overflow-hidden transition-all duration-300"
  >
    <div className="h-48 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center p-4">
      <img src={`https://picsum.photos/seed/${nft.token_id}/300/200`} alt={nft.name} className="w-full h-full object-cover rounded-lg"/>
    </div>
    <div className="p-4">
      <h3 className="font-bold mb-1 truncate" style={{color: 'var(--orbital-text)'}}>{nft.name}</h3>
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs px-2 py-1 rounded-full chrome-surface" style={{color: 'var(--orbital-blue)'}}>
          {nft.asset_type?.toUpperCase()}
        </span>
        <div className="text-lg font-bold" style={{color: 'var(--orbital-blue)'}}>
          {Math.floor(Math.random() * 5000 + 500)} ORB
        </div>
      </div>
      <Button className="w-full" style={{background: 'var(--orbital-blue)', color: '#000'}}>Buy Now</Button>
    </div>
  </motion.div>
);

export default function Marketplace() {
  const [nfts, setNfts] = useState([]);
  const [filteredNfts, setFilteredNfts] = useState([]);
  const [filters, setFilters] = useState({ search: '', type: 'all', sort: 'newest' });

  useEffect(() => {
    const loadNfts = async () => {
      const data = await NFT.list();
      setNfts(data);
      setFilteredNfts(data);
    };
    loadNfts();
  }, []);

  useEffect(() => {
    let result = nfts;
    if (filters.search) {
      result = result.filter(nft => nft.name.toLowerCase().includes(filters.search.toLowerCase()));
    }
    if (filters.type !== 'all') {
      result = result.filter(nft => nft.asset_type === filters.type);
    }
    // Add sorting logic here later
    setFilteredNfts(result);
  }, [filters, nfts]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">GALACTIC MARKETPLACE</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Trade assets across the Orbital galaxy with AI-driven insights</p>
        </div>
      </div>

      <Card className="chrome-surface p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input 
              placeholder="Search assets..." 
              className="pl-9 chrome-surface"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
            />
          </div>
          <Select value={filters.type} onValueChange={(v) => handleFilterChange('type', v)}>
            <SelectTrigger className="chrome-surface"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="avatar">Avatar</SelectItem>
              <SelectItem value="parcel">Parcel</SelectItem>
              <SelectItem value="wearable">Wearable</SelectItem>
              <SelectItem value="art">Art</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.sort} onValueChange={(v) => handleFilterChange('sort', v)}>
            <SelectTrigger className="chrome-surface"><SelectValue placeholder="Sort By" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price_asc">Price: Low to High</SelectItem>
              <SelectItem value="price_desc">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline"
            className="chrome-surface"
            onClick={() => setFilters({ search: '', type: 'all', sort: 'newest' })}
          >
            <X className="w-4 h-4 mr-2" /> Reset Filters
          </Button>
        </div>
      </Card>

      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Sparkles className="w-6 h-6" style={{color: '#8b5cf6'}}/>
          AI Hot Picks
        </h2>
        {/* Placeholder for AI picks */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {nfts.slice(0, 4).map(nft => <AssetItem key={nft.id + "-hot"} nft={nft} />)}
        </div>
      </div>
      
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <ShoppingCart className="w-6 h-6" style={{color: 'var(--orbital-blue)'}}/>
        Browse All Assets
      </h2>
      <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {filteredNfts.map(nft => (
            <AssetItem key={nft.id} nft={nft} />
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}