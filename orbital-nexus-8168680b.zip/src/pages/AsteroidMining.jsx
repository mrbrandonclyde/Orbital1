import React, { useState, useEffect } from 'react';
import { Pickaxe, Zap, TrendingUp, Eye, Settings, Star, Cpu, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AsteroidMining as AsteroidMiningEntity } from '@/api/entities';

const AsteroidOperationCard = ({ operation, onClick }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(255, 215, 0, 0.4)' }}
    onClick={() => onClick(operation)}
    className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 asteroid-glow"
  >
    <style jsx>{`
      .asteroid-glow {
        background: linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(139, 92, 246, 0.05));
        border: 1px solid rgba(255, 215, 0, 0.3);
      }
    `}</style>
    
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center" 
           style={{background: 'rgba(255, 215, 0, 0.2)', border: '2px solid #FFD700'}}>
        <Pickaxe className="w-6 h-6" style={{color: '#FFD700'}} />
      </div>
      <div className="flex-1">
        <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>
          {operation.operation_name}
        </h3>
        <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
          Target: {operation.target_asteroid?.name || 'Unknown Asteroid'}
        </p>
      </div>
      <Badge 
        variant={operation.operation_status === 'active' ? 'default' : 'secondary'}
        style={operation.operation_status === 'active' ? 
          {background: '#FFD700', color: '#000'} : 
          {background: 'rgba(255, 215, 0, 0.3)', color: '#FFD700'}
        }
      >
        {operation.operation_status.toUpperCase()}
      </Badge>
    </div>

    <div className="grid grid-cols-2 gap-4 mb-4">
      <div>
        <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>DAILY YIELD</p>
        <p className="font-bold" style={{color: '#FFD700'}}>{operation.extraction_metrics?.daily_yield_tons || 0} tons</p>
      </div>
      <div>
        <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>FLEET SIZE</p>
        <p className="font-bold" style={{color: '#FFD700'}}>{operation.mining_fleet?.length || 0} drones</p>
      </div>
    </div>

    <div className="flex justify-between items-center">
      <div className="flex gap-2">
        <Badge variant="outline" style={{borderColor: '#8b5cf6', color: '#8b5cf6'}}>
          {operation.target_asteroid?.classification || 'Unknown'}
        </Badge>
      </div>
      <div className="text-sm font-bold" style={{color: 'var(--orbital-blue)'}}>
        {operation.target_asteroid?.estimated_value_orb?.toLocaleString() || 0} ORB
      </div>
    </div>
  </motion.div>
);

export default function AsteroidMining() {
  const [miningOperations, setMiningOperations] = useState([]);
  const [selectedOperation, setSelectedOperation] = useState(null);
  const [totalYield, setTotalYield] = useState({
    dailyTons: 0,
    totalValue: 0,
    activeDrones: 0
  });

  useEffect(() => {
    const initializeAsteroidMining = async () => {
      try {
        const operations = await AsteroidMiningEntity.list();
        setMiningOperations(operations);
      } catch (error) {
        // Fallback to demo data
        setMiningOperations([
          {
            id: 'mining_op_001',
            operation_name: 'Ceres Deep Mining Alpha',
            target_asteroid: {
              asteroid_id: 'ast_001',
              name: 'Ceres-7742',
              classification: 'C-type',
              estimated_value_orb: 450000000
            },
            mining_fleet: [
              {drone_id: 'drone_001', drone_class: 'harvester', operational_status: 'active'},
              {drone_id: 'drone_002', drone_class: 'refiner', operational_status: 'active'},
              {drone_id: 'drone_003', drone_class: 'transport', operational_status: 'active'}
            ],
            extraction_metrics: {
              daily_yield_tons: 245.7,
              rare_metals_percentage: 15.2,
              water_ice_percentage: 32.1,
              platinum_group_kg: 12.3
            },
            ai_optimization: {
              yield_prediction_accuracy: 97.8,
              fleet_efficiency_score: 94.2,
              autonomous_navigation_enabled: true
            },
            operation_status: 'active'
          },
          {
            id: 'mining_op_002',
            operation_name: 'Vesta Platinum Extraction',
            target_asteroid: {
              asteroid_id: 'ast_002',
              name: 'Vesta-Prime',
              classification: 'M-type',
              estimated_value_orb: 1200000000
            },
            mining_fleet: [
              {drone_id: 'drone_004', drone_class: 'harvester', operational_status: 'active'},
              {drone_id: 'drone_005', drone_class: 'harvester', operational_status: 'active'},
              {drone_id: 'drone_006', drone_class: 'security', operational_status: 'active'}
            ],
            extraction_metrics: {
              daily_yield_tons: 89.4,
              rare_metals_percentage: 67.8,
              platinum_group_kg: 145.2
            },
            ai_optimization: {
              yield_prediction_accuracy: 99.1,
              fleet_efficiency_score: 96.7,
              autonomous_navigation_enabled: true
            },
            operation_status: 'active'
          }
        ]);
      }
    };

    initializeAsteroidMining();

    // Calculate totals
    const totals = miningOperations.reduce((acc, op) => {
      acc.dailyTons += op.extraction_metrics?.daily_yield_tons || 0;
      acc.totalValue += op.target_asteroid?.estimated_value_orb || 0;
      acc.activeDrones += op.mining_fleet?.length || 0;
      return acc;
    }, {dailyTons: 0, totalValue: 0, activeDrones: 0});

    setTotalYield(totals);
  }, [miningOperations]);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx global>{`
        .asteroid-mining-glow {
          box-shadow: 0 0 25px rgba(255, 215, 0, 0.3), 0 0 50px rgba(255, 215, 0, 0.1);
          animation: asteroidPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes asteroidPulse {
          0% { 
            box-shadow: 0 0 25px rgba(255, 215, 0, 0.3), 0 0 50px rgba(255, 215, 0, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(255, 215, 0, 0.5), 0 0 70px rgba(255, 215, 0, 0.2);
          }
        }
      `}</style>

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold asteroid-mining-glow" style={{ color: 'var(--orbital-text)' }}>
          ASTEROID MINING GRID v1
        </h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>
          VR/AR-enabled asteroid belt operations with AI-optimized mining fleets and holographic asteroid views
        </p>
        <div className="flex items-center gap-4 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></div>
            <span className="text-sm" style={{ color: '#FFD700' }}>MINING OPERATIONS: ACTIVE</span>
          </div>
          <div className="px-3 py-1 rounded-full text-xs font-bold" 
               style={{ background: 'linear-gradient(45deg, #FFD700, #8b5cf6)', color: '#000' }}>
            ⛏️ ASTEROID MASTERY PROTOCOL
          </div>
        </div>
      </div>

      {/* Mining Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="chrome-surface asteroid-mining-glow">
          <CardContent className="p-4 text-center">
            <Pickaxe className="w-8 h-8 mx-auto mb-2" style={{ color: '#FFD700' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {totalYield.dailyTons.toFixed(1)}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Daily Yield (Tons)
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface asteroid-mining-glow">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 mx-auto mb-2" style={{ color: '#FFD700' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              ${(totalYield.totalValue / 1000000000).toFixed(1)}B
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Total Asset Value
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface asteroid-mining-glow">
          <CardContent className="p-4 text-center">
            <Cpu className="w-8 h-8 mx-auto mb-2" style={{ color: '#FFD700' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {totalYield.activeDrones}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Active Mining Drones
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface asteroid-mining-glow">
          <CardContent className="p-4 text-center">
            <Star className="w-8 h-8 mx-auto mb-2" style={{ color: '#FFD700' }} />
            <div className="text-2xl font-bold" style={{ color: 'var(--orbital-text)' }}>
              {miningOperations.length}
            </div>
            <div className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
              Active Operations
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mining Operations Grid */}
      <Card className="chrome-surface asteroid-mining-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
            <Pickaxe className="w-6 h-6" style={{ color: '#FFD700' }} />
            ASTEROID MINING OPERATIONS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {miningOperations.map((operation, index) => (
              <motion.div
                key={operation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <AsteroidOperationCard operation={operation} onClick={setSelectedOperation} />
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}