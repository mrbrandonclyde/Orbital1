import React from 'react';
import { BookOpen, Star, Heart, Shield, Crown, Scroll } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const ScriptureCard = ({ title, reference, text, theme, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="chrome-surface rounded-xl p-6 mb-6"
  >
    <div className="flex items-center gap-3 mb-4">
      <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{background: `${color}20`}}>
        <BookOpen className="w-4 h-4" style={{color: color}} />
      </div>
      <div>
        <h3 className="font-bold text-white">{title}</h3>
        <p className="text-sm" style={{color: color}}>{reference}</p>
      </div>
    </div>
    <blockquote className="text-gray-300 italic leading-relaxed border-l-4 pl-4" style={{borderColor: color}}>
      "{text}"
    </blockquote>
    <div className="mt-3 text-xs text-gray-400">
      Theme: <span className="text-white">{theme}</span>
    </div>
  </motion.div>
);

export default function GuardianCodexLDSScriptures() {
  const scriptures = [
    {
      title: "Divine Renewal",
      reference: "Isaiah 40:31",
      text: "But they that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.",
      theme: "Strength & Renewal",
      color: "#f59e0b"
    },
    {
      title: "Eternal Families",
      reference: "1 Corinthians 15:29",
      text: "What shall they do which are baptized for the dead, if the dead rise not at all? Why are they then baptized for the dead?",
      theme: "Eternal Family Bonds",
      color: "#ec4899"
    },
    {
      title: "Divine Protection",
      reference: "Psalm 91:11-12",
      text: "For he shall give his angels charge over thee, to keep thee in all thy ways. They shall bear thee up in their hands, lest thou dash thy foot against a stone.",
      theme: "Guardian Angels",
      color: "#4c4ce6"
    },
    {
      title: "Restoration Promise",
      reference: "Joel 2:25",
      text: "And I will restore to you the years that the locust hath eaten, the cankerworm, and the caterpiller, and the palmerworm, my great army which I sent among you.",
      theme: "Divine Restoration",
      color: "#22c55e"
    },
    {
      title: "Eternal Covenant",
      reference: "D&C 132:19",
      text: "And again, verily I say unto you, if a man marry a wife by my word, which is my law, and by the new and everlasting covenant... they shall pass by the angels, and the gods, which are set there, to their exaltation and glory in all things.",
      theme: "Eternal Marriage",
      color: "#8b5cf6"
    },
    {
      title: "Daily Bread",
      reference: "Matthew 6:11",
      text: "Give us this day our daily bread.",
      theme: "Daily Provision",
      color: "#06b6d4"
    }
  ];

  return (
    <div style={{color: 'white'}} className="p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3">
          <Scroll className="w-10 h-10 text-blue-400" />
          SCRIPTURAL ANCHORS
        </h1>
        <p className="text-gray-300 text-lg">
          Divine foundations and eternal truths that anchor the Guardian Codex
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {scriptures.map((scripture, index) => (
          <ScriptureCard key={index} {...scripture} />
        ))}
      </div>

      <Card className="chrome-surface mt-8">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-400" />
            FOUNDATIONAL PRINCIPLES
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Heart className="w-8 h-8 mx-auto mb-2 text-pink-400" />
              <h3 className="font-bold text-white mb-2">Eternal Families</h3>
              <p className="text-gray-300 text-sm">Families can be together forever through sacred covenants</p>
            </div>
            <div className="text-center">
              <Shield className="w-8 h-8 mx-auto mb-2 text-blue-400" />
              <h3 className="font-bold text-white mb-2">Divine Protection</h3>
              <p className="text-gray-300 text-sm">Guardian angels watch over the faithful</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
              <h3 className="font-bold text-white mb-2">Daily Renewal</h3>
              <p className="text-gray-300 text-sm">Strength is renewed through divine grace</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}