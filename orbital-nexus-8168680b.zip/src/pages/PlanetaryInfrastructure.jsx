
import React, { useState, useEffect } from 'react';
import { Globe, Zap, Wifi, Droplets, Shield, Activity, Map, Eye, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PlanetaryInfrastructure as PlanetaryInfrastructureEntity } from '@/api/entities';

const InfrastructureGridCard = ({ grid, onClick }) => {
  const getInfraIcon = (type) => {
    const icons = { energy: Zap, transport: Map, water: Droplets, communications: Wifi, defense: Shield };
    return icons[type] || Activity;
  };

  const getStatusColor = (coverage) => {
    if (coverage >= 90) return '#22c55e';
    if (coverage >= 75) return '#f59e0b';
    return '#ef4444';
  };

  const InfraIcon = getInfraIcon(grid.infrastructure_type);
  const statusColor = getStatusColor(grid.global_coverage);

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02, boxShadow: `0 0 40px ${statusColor}50` }}
      onClick={() => onClick(grid)}
      className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 planetary-grid-card"
    >
      <style jsx>{`
        .planetary-grid-card {
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(139, 92, 246, 0.05));
          animation: planetaryPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes planetaryPulse {
          0% { box-shadow: 0 0 20px rgba(0, 212, 255, 0.3); }
          100% { box-shadow: 0 0 35px rgba(0, 212, 255, 0.5); }
        }
      `}</style>
      
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 rounded-full flex items-center justify-center"
             style={{background: `${statusColor}20`, border: `2px solid ${statusColor}`}}>
          <InfraIcon className="w-8 h-8" style={{color: statusColor}} />
        </div>
        <div>
          <h3 className="text-xl font-bold" style={{color: 'var(--orbital-text)'}}>
            {grid.infrastructure_type.toUpperCase()} GRID
          </h3>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            Global Infrastructure Network
          </p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span style={{color: 'var(--orbital-text-dim)'}}>Global Coverage</span>
          <Badge style={{background: `${statusColor}20`, color: statusColor, border: `1px solid ${statusColor}`}}>
            {grid.global_coverage}%
          </Badge>
        </div>
        
        <div className="w-full bg-gray-800 rounded-full h-3">
          <div 
            className="h-3 rounded-full transition-all duration-500"
            style={{width: `${grid.global_coverage}%`, background: statusColor}}
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 rounded-lg chrome-surface">
            <div className="text-2xl font-bold" style={{color: statusColor}}>
              {grid.continental_nodes?.length || 7}
            </div>
            <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Continents</div>
          </div>
          <div className="text-center p-3 rounded-lg chrome-surface">
            <div className="text-2xl font-bold" style={{color: 'var(--orbital-blue)'}}>
              {grid.ai_optimization_score || 98}%
            </div>
            <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>AI Optimized</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const PlanetaryControlPanel = ({ selectedGrid }) => (
  <Card className="chrome-surface planetary-control-panel h-full">
    <style jsx>{`
      .planetary-control-panel {
        background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(34, 197, 94, 0.05));
        border: 1px solid rgba(0, 212, 255, 0.3);
      }
    `}</style>
    <CardHeader>
      <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
        <Globe className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
        PLANETARY CONTROL MATRIX
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      {selectedGrid ? (
        <>
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>
              {selectedGrid.infrastructure_type.toUpperCase()} NETWORK
            </h3>
            <Badge className="mt-2 font-bold px-3 py-1" 
                   style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
              PLANETARY SCALE ACTIVE
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            <Button className="w-full glow-blue font-bold">
              <Eye className="w-4 h-4 mr-2" />
              VR/AR DASHBOARD
            </Button>
            <Button variant="outline" className="w-full chrome-surface">
              <Settings className="w-4 h-4 mr-2" />
              OPTIMIZE GRID
            </Button>
            <Button variant="outline" className="w-full chrome-surface">
              <Activity className="w-4 h-4 mr-2" />
              FAILOVER TEST
            </Button>
          </div>
          
          <div className="mt-6 p-4 rounded-lg" style={{background: 'rgba(0, 212, 255, 0.05)'}}>
            <p className="text-sm font-bold mb-2" style={{color: 'var(--orbital-blue)'}}>
              REAL-TIME STATUS
            </p>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}}>Failover Time</span>
                <span style={{color: '#22c55e'}}>&lt;200ms</span>
              </div>
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}>Active Nodes</span>
                <span style={{color: 'var(--orbital-blue)'}}>1,000,000+</span>
              </div>
              <div className="flex justify-between">
                <span style={{color: 'var(--orbital-text-dim)'}}>AI Predictions</span>
                <span style={{color: '#8b5cf6'}}>ACTIVE</span>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-8">
          <Globe className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Select an infrastructure grid to view planetary controls
          </p>
        </div>
      )}
    </CardContent>
  </Card>
);

export default function PlanetaryInfrastructure() {
  const [infrastructureGrids, setInfrastructureGrids] = useState([]);
  const [selectedGrid, setSelectedGrid] = useState(null);
  const [globalStatus, setGlobalStatus] = useState('OPERATIONAL');

  useEffect(() => {
    // Initialize planetary infrastructure grids
    const initializeGrids = async () => {
      try {
        const grids = await PlanetaryInfrastructureEntity.list();
        setInfrastructureGrids(grids);
      } catch (error) {
        // Fallback to mock data for demonstration
        setInfrastructureGrids([
          {
            id: 'grid_energy_001',
            infrastructure_type: 'energy',
            global_coverage: 94.7,
            ai_optimization_score: 98.2,
            continental_nodes: [
              {continent: 'North America', node_count: 150000, operational_status: 'online'},
              {continent: 'Europe', node_count: 120000, operational_status: 'online'},
              {continent: 'Asia', node_count: 200000, operational_status: 'online'},
              {continent: 'Africa', node_count: 80000, operational_status: 'online'},
              {continent: 'South America', node_count: 70000, operational_status: 'online'},
              {continent: 'Australia', node_count: 25000, operational_status: 'online'},
              {continent: 'Antarctica', node_count: 5000, operational_status: 'maintenance'}
            ]
          },
          {
            id: 'grid_transport_001', 
            infrastructure_type: 'transport',
            global_coverage: 89.3,
            ai_optimization_score: 96.8
          },
          {
            id: 'grid_water_001',
            infrastructure_type: 'water', 
            global_coverage: 91.5,
            ai_optimization_score: 97.1
          },
          {
            id: 'grid_comms_001',
            infrastructure_type: 'communications',
            global_coverage: 96.2,
            ai_optimization_score: 99.1
          },
          {
            id: 'grid_defense_001',
            infrastructure_type: 'defense',
            global_coverage: 100.0,
            ai_optimization_score: 99.9
          }
        ]);
      }
    };

    initializeGrids();

    // Global status monitoring
    const statusInterval = setInterval(() => {
      setGlobalStatus(prev => {
        const statuses = ['OPERATIONAL', 'OPTIMIZING', 'EXPANDING'];
        const randomIndex = Math.floor(Math.random() * statuses.length);
        return statuses[randomIndex];
      });
    }, 5000);

    return () => clearInterval(statusInterval);
  }, []);

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx global>{`
        .planetary-glow {
          box-shadow: 0 0 30px rgba(0, 212, 255, 0.4), 0 0 60px rgba(0, 212, 255, 0.2);
          animation: planetaryBreath 4s ease-in-out infinite alternate;
        }
        
        @keyframes planetaryBreath {
          0% { 
            box-shadow: 0 0 30px rgba(0, 212, 255, 0.4), 0 0 60px rgba(0, 212, 255, 0.2);
            transform: scale(1); 
          }
          100% { 
            box-shadow: 0 0 50px rgba(0, 212, 255, 0.6), 0 0 100px rgba(0, 212, 255, 0.3);
            transform: scale(1.01); 
          }
        }
      `}</style>

      {/* Planetary Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold planetary-glow" style={{color: 'var(--orbital-text)'}}>
          PLANETARY INFRASTRUCTURE GRID
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Global backbone infrastructure with VR/AR holographic monitoring across all continents
        </p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" 
                 style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
            <Shield className="w-4 h-4 mr-2" />
            STATUS: {globalStatus}
          </Badge>
          <Badge variant="outline" style={{borderColor: '#8b5cf6', color: '#8b5cf6'}}>
            <Globe className="w-4 h-4 mr-2" />
            PLANETARY SCALE ACTIVE
          </Badge>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Infrastructure Grids */}
        <div className="flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {infrastructureGrids.map((grid, index) => (
              <motion.div
                key={grid.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <InfrastructureGridCard 
                  grid={grid} 
                  onClick={setSelectedGrid}
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Planetary Control Panel */}
        <div className="w-80 flex-shrink-0">
          <PlanetaryControlPanel selectedGrid={selectedGrid} />
        </div>
      </div>

      {/* Global Statistics */}
      <Card className="chrome-surface planetary-glow mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
            <Activity className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
            PLANETARY INFRASTRUCTURE STATISTICS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#22c55e'}}>7</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Continents Online</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: 'var(--orbital-blue)'}}>1M+</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Active Nodes</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#8b5cf6'}}>98.3%</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>AI Optimization</div>
            </div>
            <div className="text-center p-4 rounded-lg chrome-surface">
              <div className="text-3xl font-bold" style={{color: '#f59e0b'}}>&lt;200ms</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Failover Time</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
