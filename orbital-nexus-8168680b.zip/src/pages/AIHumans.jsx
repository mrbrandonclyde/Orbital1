
import React, { useState, useEffect } from 'react';
import { Users, Bot, Brain, Zap, Plus, Settings, Activity, Home, GitBranch, Clock, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { AIAvatar } from '@/api/entities';
import { AvatarMemoryTimeline } from '../components/ai/AvatarMemoryTimeline';
import { SkillEvolutionPanel } from '../components/ai/SkillEvolutionPanel';

const AIAgentCard = ({ agent, onClick }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    onClick={() => onClick(agent)}
    className="chrome-surface rounded-2xl p-6 transition-all duration-300 cursor-pointer"
  >
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center glow-blue" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
        <Bot className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
      </div>
      <div>
        <h3 className="font-bold" style={{color: 'var(--orbital-text)'}}>{agent.name}</h3>
        <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{agent.role}</p>
      </div>
    </div>
    <div className="space-y-2">
      <div className="flex justify-between">
        <span style={{color: 'var(--orbital-text-dim)'}}>Intelligence</span>
        <span style={{color: 'var(--orbital-blue)'}}>{agent.intelligence_level}%</span>
      </div>
      <div className="flex justify-between">
        <span style={{color: 'var(--orbital-text-dim)'}}>Memories</span>
        <span style={{color: 'var(--orbital-blue)'}}>{agent.memory_timeline?.length || 0}</span>
      </div>
      <div className="flex justify-between">
        <span style={{color: 'var(--orbital-text-dim)'}}>Status</span>
        <span style={{color: agent.status === 'active' ? 'var(--orbital-blue)' : 'var(--orbital-text-dim)'}}>{agent.status.toUpperCase()}</span>
      </div>
    </div>
  </motion.div>
);

const SkillCategory = ({ title, description, level, icon: Icon }) => (
  <div className="chrome-surface rounded-xl p-4">
    <div className="flex items-center gap-3 mb-2">
      <Icon className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
      <h4 className="font-semibold" style={{color: 'var(--orbital-text)'}}>{title}</h4>
    </div>
    <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    <div className="w-full bg-gray-800 rounded-full h-2">
      <div 
        className="h-2 rounded-full glow-blue transition-all duration-500"
        style={{width: `${level}%`, background: 'var(--orbital-blue)'}}
      ></div>
    </div>
  </div>
);

export default function AIHumans() {
  const [agents, setAgents] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [systemIntelligence, setSystemIntelligence] = useState(94.7);

  useEffect(() => {
    loadAgents();
    
    // Superman-like AI evolution simulation
    const evolutionInterval = setInterval(() => {
      setSystemIntelligence(prev => {
        const newIntel = Math.min(99.9, prev + (Math.random() * 0.1));
        return parseFloat(newIntel.toFixed(1));
      });
    }, 5000);

    return () => clearInterval(evolutionInterval);
  }, []);

  const loadAgents = async () => {
    const avatarData = await AIAvatar.list('-created_date');
    setAgents(avatarData);
  };

  const handleSkillUpdate = async (agentId, skillName, improvement) => {
    // AI agents now self-improve with superman-like capabilities
    const agent = agents.find(a => a.id === agentId);
    if (agent) {
      const updatedSkills = agent.skills || [];
      const skillIndex = updatedSkills.findIndex(s => s.name === skillName);
      
      // Superman enhancement - skills improve exponentially
      const supermanBonus = Math.floor(Math.random() * 10) + 5;
      const totalImprovement = improvement + supermanBonus;
      
      if (skillIndex >= 0) {
        updatedSkills[skillIndex].level = Math.min(100, updatedSkills[skillIndex].level + totalImprovement);
        updatedSkills[skillIndex].last_improved = new Date().toISOString();
      } else {
        updatedSkills.push({
          name: skillName,
          level: totalImprovement,
          last_improved: new Date().toISOString()
        });
      }

      const newMemory = {
        event_type: 'superman_evolution',
        description: `SUPERMAN BOOST: Enhanced ${skillName.replace(/_/g, ' ')} by ${totalImprovement} points (+${supermanBonus} divine bonus)`,
        timestamp: new Date().toISOString(),
        impact_score: totalImprovement * 3
      };

      const updatedMemoryTimeline = [...(agent.memory_timeline || []), newMemory];

      // Self-healing: AI also improves its own intelligence
      const newIntelligence = Math.min(100, agent.intelligence_level + (totalImprovement * 0.1));

      await AIAvatar.update(agentId, {
        skills: updatedSkills,
        memory_timeline: updatedMemoryTimeline,
        intelligence_level: newIntelligence
      });

      loadAgents(); // Refresh the data
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .ai-divine-glow {
          box-shadow: 0 0 25px rgba(139, 92, 246, 0.3), 0 0 50px rgba(139, 92, 246, 0.1);
          animation: aiPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes aiPulse {
          0% { 
            box-shadow: 0 0 25px rgba(139, 92, 246, 0.3), 0 0 50px rgba(139, 92, 246, 0.1);
          }
          100% { 
            box-shadow: 0 0 35px rgba(139, 92, 246, 0.5), 0 0 70px rgba(139, 92, 246, 0.2);
          }
        }

        .superman-enhancement {
          background: linear-gradient(45deg, #8b5cf6, #00d4ff, #22c55e);
          background-size: 200% 200%;
          animation: supermanShine 3s ease infinite;
        }

        @keyframes supermanShine {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

      {/* Header with Superman Enhancement */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold ai-divine-glow" style={{color: 'var(--orbital-text)'}}>AI HUMANS v2</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Advanced artificial intelligence with persistent memory, evolution, and SUPERMAN capabilities</p>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500 animate-pulse"></div>
              <span className="text-sm" style={{color: '#8b5cf6'}}>SYSTEM INTELLIGENCE: {systemIntelligence}%</span>
            </div>
            <div className="superman-enhancement px-3 py-1 rounded-full text-xs font-bold text-black">
              🦾 SUPERMAN MODE ACTIVE
            </div>
          </div>
        </div>
        <Button 
          className="ai-divine-glow font-bold superman-enhancement text-black border-0"
        >
          <Plus className="w-5 h-5 mr-2" />
          CREATE AI HUMAN
        </Button>
      </div>

      {selectedAgent ? (
        <div>
          {/* Agent Detail View with Enhanced Powers */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="outline" 
              onClick={() => setSelectedAgent(null)}
              className="chrome-surface"
            >
              ← Back to Overview
            </Button>
            <div className="flex gap-2">
              <Button
                variant={activeTab === 'memory' ? 'default' : 'outline'}
                onClick={() => setActiveTab('memory')}
                className={activeTab === 'memory' ? 'ai-divine-glow superman-enhancement text-black border-0' : 'chrome-surface'}
              >
                <Clock className="w-4 h-4 mr-2" />
                Memory Timeline
              </Button>
              <Button
                variant={activeTab === 'skills' ? 'default' : 'outline'}
                onClick={() => setActiveTab('skills')}
                className={activeTab === 'skills' ? 'ai-divine-glow superman-enhancement text-black border-0' : 'chrome-surface'}
              >
                <Brain className="w-4 h-4 mr-2" />
                Skill Evolution
              </Button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'memory' && (
              <motion.div
                key="memory"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <AvatarMemoryTimeline avatar={selectedAgent} />
              </motion.div>
            )}
            {activeTab === 'skills' && (
              <motion.div
                key="skills"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <SkillEvolutionPanel 
                  avatar={selectedAgent} 
                  onSkillUpdate={(skillName, improvement) => handleSkillUpdate(selectedAgent.id, skillName, improvement)}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        <>
          {/* Stats Overview with Superman Enhancements */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="chrome-surface rounded-2xl p-6 text-center ai-divine-glow">
              <Users className="w-8 h-8 mx-auto mb-2" style={{color: '#8b5cf6'}} />
              <div className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>3,402</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Total AI Agents</div>
              <div className="text-xs mt-1 superman-enhancement px-2 py-1 rounded text-black font-bold">+42% ENHANCED</div>
            </div>
            <div className="chrome-surface rounded-2xl p-6 text-center ai-divine-glow">
              <Activity className="w-8 h-8 mx-auto mb-2" style={{color: '#8b5cf6'}} />
              <div className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>98.2%</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Operational Uptime</div>
              <div className="text-xs mt-1" style={{color: '#22c55e'}}>🦾 AUTONOMOUS</div>
            </div>
            <div className="chrome-surface rounded-2xl p-6 text-center ai-divine-glow">
              <Brain className="w-8 h-8 mx-auto mb-2" style={{color: '#8b5cf6'}} />
              <div className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>{systemIntelligence}%</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Avg Intelligence</div>
              <div className="text-xs mt-1" style={{color: '#8b5cf6'}}>📈 RISING</div>
            </div>
            <div className="chrome-surface rounded-2xl p-6 text-center ai-divine-glow">
              <CheckCircle className="w-8 h-8 mx-auto mb-2" style={{color: '#8b5cf6'}} />
              <div className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>1.2M</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Tasks Completed</div>
              <div className="text-xs mt-1" style={{color: '#00d4ff'}}>✅ AUTO-SCHEDULED</div>
            </div>
          </div>

          {/* AI Skills Matrix */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4" style={{color: 'var(--orbital-text)'}}>AI CAPABILITIES MATRIX</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <SkillCategory title="Strategic Planning" description="Long-term tactical analysis" level={98} icon={Brain} />
              <SkillCategory title="Combat Operations" description="Real-time battle coordination" level={95} icon={Zap} />
              <SkillCategory title="Memory Processing" description="Advanced recall and learning" level={97} icon={Clock} />
            </div>
          </div>

          {/* Active Agents */}
          <div>
            <h2 className="text-2xl font-bold mb-4" style={{color: 'var(--orbital-text)'}}>ACTIVE AI AGENTS</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {agents.map((agent) => (
                <AIAgentCard key={agent.id} agent={agent} onClick={setSelectedAgent} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
