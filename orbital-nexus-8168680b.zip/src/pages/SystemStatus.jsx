import React, { useState, useEffect } from 'react';
import { Activity, Cpu, Database, Globe, Zap, CheckCircle, Wifi, HardDrive, MemoryStick } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis, Tooltip, Legend } from 'recharts';

const MetricGauge = ({ value, name, unit, color }) => (
  <div className="chrome-surface rounded-2xl p-4 text-center divine-glow flex flex-col justify-between">
    <div className="flex-grow flex items-center justify-center">
      <ResponsiveContainer width="100%" height={150}>
        <RadialBarChart
          innerRadius="70%"
          outerRadius="90%"
          data={[{ name, value, fill: color }]}
          startAngle={180}
          endAngle={0}
        >
          <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
          <RadialBar background dataKey="value" cornerRadius={10} angleAxisId={0} />
          <Tooltip 
            contentStyle={{
              background: "rgba(0,0,0,0.8)",
              borderColor: color,
              borderRadius: "8px",
            }}
          />
        </RadialBarChart>
      </ResponsiveContainer>
    </div>
    <div className="mt-[-40px]">
      <div className="text-3xl font-bold" style={{ color }}>{value.toFixed(1)}{unit}</div>
      <p className="text-sm font-medium" style={{ color: 'var(--orbital-text-dim)' }}>{name}</p>
    </div>
  </div>
);

export default function SystemStatus() {
  const [systemMetrics, setSystemMetrics] = useState({
    cpuUsage: 23.4,
    memoryUsage: 67.2,
    diskUsage: 45.8,
    networkLatency: 142,
    activeNodes: 847,
    uptime: 99.97,
    transactionsPerSecond: 9876,
    healingEvents: 0,
    strengthening: true
  });
  
  const systemComponents = [
    { name: 'Orbital Kernel', status: 'operational', uptime: 99.99, icon: Cpu, healing: true },
    { name: 'Quantum Database', status: 'operational', uptime: 99.95, icon: Database, healing: false },
    { name: 'Neural Network', status: 'operational', uptime: 99.87, icon: Globe, healing: true },
    { name: 'AI Processing', status: 'operational', uptime: 99.92, icon: Zap, healing: false },
    { name: 'Self-Healing Engine', status: 'operational', uptime: 100.00, icon: Activity, healing: true },
    { name: 'Memory Matrix', status: 'strengthening', uptime: 99.94, icon: MemoryStick, healing: true },
  ];

  const getStatusColor = (status) => {
    switch(status) {
      case 'operational': return '#00d4ff';
      case 'strengthening': return '#22c55e';
      case 'healing': return '#8b5cf6';
      default: return 'var(--orbital-text-dim)';
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setSystemMetrics(prev => {
        const newMetrics = {
          ...prev,
          cpuUsage: Math.max(15, Math.min(40, prev.cpuUsage + (Math.random() - 0.5) * 3)),
          memoryUsage: Math.max(50, Math.min(80, prev.memoryUsage + (Math.random() - 0.5) * 2)),
          diskUsage: Math.max(40, Math.min(60, prev.diskUsage + (Math.random() - 0.5) * 1)),
          healingEvents: prev.cpuUsage > 35 ? prev.healingEvents + 1 : prev.healingEvents,
          strengthening: Math.random() > 0.3
        };

        if (newMetrics.cpuUsage > 35) {
          newMetrics.cpuUsage = Math.max(20, newMetrics.cpuUsage - 5);
        }

        return newMetrics;
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .divine-glow {
          box-shadow: 0 0 20px rgba(0, 212, 255, 0.2);
          animation: divineHearbeat 3s ease-in-out infinite alternate;
        }
        @keyframes divineHearbeat {
          from { box-shadow: 0 0 20px rgba(0, 212, 255, 0.2); }
          to { box-shadow: 0 0 30px rgba(0, 212, 255, 0.4); }
        }
        .healing-pulse {
          animation: healingPulse 2s ease-in-out infinite;
        }
        @keyframes healingPulse {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 1; }
        }
        .operational-pulse {
          animation: opPulse 1.5s infinite;
        }
        @keyframes opPulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(0, 212, 255, 0.4); }
          50% { box-shadow: 0 0 0 8px rgba(0, 212, 255, 0); }
        }
      `}</style>

      <div className="mb-8">
        <h1 className="text-4xl font-bold" style={{ color: 'var(--orbital-text)' }}>SYSTEM STATUS</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Real-time monitoring of all Orbital infrastructure</p>
      </div>

      <Card className="chrome-surface mb-8 divine-glow">
        <CardContent className="p-8">
          <div className="flex items-center justify-around text-center">
            <div className="flex flex-col items-center">
              <CheckCircle className="w-16 h-16 mb-2" style={{ color: '#00d4ff' }} />
              <h2 className="text-2xl font-bold" style={{ color: '#00d4ff' }}>ALL SYSTEMS OPERATIONAL</h2>
            </div>
             <div className="h-24 w-px bg-blue-500/30"></div>
            <div>
              <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Overall Uptime</p>
              <p className="text-3xl font-bold" style={{ color: 'var(--orbital-blue)' }}>{systemMetrics.uptime}%</p>
            </div>
             <div className="h-24 w-px bg-blue-500/30"></div>
            <div>
              <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>Healing Events</p>
              <p className="text-3xl font-bold" style={{ color: '#8b5cf6' }}>{systemMetrics.healingEvents}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <MetricGauge value={systemMetrics.cpuUsage} name="CPU Usage" unit="%" color="var(--orbital-blue)" />
        <MetricGauge value={systemMetrics.memoryUsage} name="Memory Load" unit="%" color="#8b5cf6" />
        <MetricGauge value={systemMetrics.diskUsage} name="Storage Capacity" unit="%" color="#22c55e" />
      </div>

      <Card className="chrome-surface divine-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{ color: 'var(--orbital-text)' }}>
            <Activity className="w-5 h-5" style={{ color: 'var(--orbital-blue)' }} />
            SYSTEM COMPONENTS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemComponents.map((component, index) => (
              <motion.div
                key={component.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-4 rounded-lg"
                style={{ 
                  background: 'rgba(0, 212, 255, 0.05)', 
                  border: `1px solid ${getStatusColor(component.status)}40`,
                }}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${component.status === 'operational' ? 'operational-pulse' : ''}`} style={{background: `${getStatusColor(component.status)}20`}}>
                    <component.icon className="w-5 h-5" style={{ color: getStatusColor(component.status) }} />
                  </div>
                  <div>
                    <p className="font-semibold" style={{ color: 'var(--orbital-text)' }}>
                      {component.name}
                      {component.healing && <span className="ml-2 text-xs" style={{color: '#8b5cf6'}}>🔮 HEALING</span>}
                    </p>
                    <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
                      Uptime: {component.uptime}%
                    </p>
                  </div>
                </div>
                <div className="px-3 py-1 rounded-full text-sm font-semibold" 
                     style={{ 
                       background: `${getStatusColor(component.status)}20`, 
                       color: getStatusColor(component.status),
                     }}>
                  {component.status.toUpperCase()}
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}