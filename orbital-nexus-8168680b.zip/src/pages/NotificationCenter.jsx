import React from 'react';
import { Bell, AlertTriangle, History } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function NotificationCenter() {
  return (
    <div className="p-6 text-white">
      <h1 className="text-4xl font-bold mb-4">Notification Center</h1>
      <p className="text-lg text-gray-300 mb-8">Manage all system alerts and historical logs.</p>
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white"><Bell className="text-blue-400" />Alerts & History</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Push Notifications (routine), Amber Alerts (God-chosen critical), History Log.</p>
        </CardContent>
      </Card>
    </div>
  );
}