import React, { useState } from 'react';
import { Gavel, AlertTriangle, Search, Filter, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const ViolationCard = ({ violation, onInvestigate }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="chrome-surface rounded-xl p-4 mb-4"
  >
    <div className="flex justify-between items-start mb-3">
      <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>{violation.title}</h4>
      <Badge style={{
        background: violation.status === 'open' ? '#ef4444' : 
                   violation.status === 'investigating' ? '#f59e0b' : '#22c55e',
        color: '#000'
      }}>
        {violation.status.toUpperCase()}
      </Badge>
    </div>
    <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>{violation.description}</p>
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
        Reported: {new Date(violation.reported).toLocaleDateString()}
      </span>
      <Button size="sm" onClick={() => onInvestigate(violation)} className="chrome-surface">
        <Eye className="w-4 h-4 mr-1" /> Investigate
      </Button>
    </div>
  </motion.div>
);

export default function ViolationReports() {
  const [violations] = useState([
    { id: 1, title: 'Unauthorized Data Access', description: 'Suspicious access patterns detected in sector 7G', status: 'open', reported: Date.now() - 86400000 },
    { id: 2, title: 'Truth Protocol Violation', description: 'False information detected in marketplace listing', status: 'investigating', reported: Date.now() - 172800000 },
    { id: 3, title: 'Environmental Damage', description: 'Unauthorized mining operation on protected world', status: 'resolved', reported: Date.now() - 259200000 },
  ]);

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">🚨 VIOLATION REPORTS</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Monitor and investigate rule violations across the system</p>
        </div>
      </motion.div>

      <Card className="chrome-surface mb-6">
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}}/>
              <Input placeholder="Search violations..." className="w-full pl-12 chrome-surface" />
            </div>
            <Button variant="outline" className="chrome-surface"><Filter className="w-4 h-4 mr-2" /> Filter</Button>
          </div>
        </CardContent>
      </Card>

      <div>
        {violations.map((violation) => (
          <ViolationCard key={violation.id} violation={violation} onInvestigate={() => {}} />
        ))}
      </div>
    </div>
  );
}