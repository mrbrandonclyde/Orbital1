import React, { useState, useEffect } from 'react';
import { Cpu, Shield, Zap, AlertTriangle, CheckCircle, Settings, Play, Pause } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function GuardianCodexLDSSimulation() {
  const [mode, setMode] = useState("Simulation");
  const [showModal, setShowModal] = useState(false);
  const [systemStatus, setSystemStatus] = useState("SAFE");
  const [simulationData, setSimulationData] = useState({
    cycles: 1247,
    livesUsed: 0,
    memoryStreams: "ACTIVE",
    safeguards: "ENABLED"
  });

  // Load saved mode
  useEffect(() => {
    const savedMode = localStorage.getItem("guardianCodexMode");
    if (savedMode) {
      setMode(savedMode);
      setSystemStatus(savedMode === "Live" ? "LIVE" : "SAFE");
    }
  }, []);

  // Save mode when changed
  useEffect(() => {
    localStorage.setItem("guardianCodexMode", mode);
    // Simulate backend API call
    fetch("/api/guardian-codex/mode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode, timestamp: new Date().toISOString() })
    }).catch(() => {
      // Handle API error gracefully in simulation
      console.log("Simulation mode - API call simulated");
    });
  }, [mode]);

  const toggleMode = () => {
    if (mode === "Simulation") {
      setShowModal(true); // confirm before Live
    } else {
      setMode("Simulation");
      setSystemStatus("SAFE");
    }
  };

  const confirmLive = () => {
    setMode("Live");
    setSystemStatus("LIVE");
    setShowModal(false);
  };

  const StatusIndicator = ({ status }) => {
    const getStatusConfig = () => {
      switch(status) {
        case "LIVE": return { color: "#22c55e", icon: Play, bg: "rgba(34, 197, 94, 0.1)" };
        case "SAFE": return { color: "#4c4ce6", icon: Shield, bg: "rgba(76, 76, 230, 0.1)" };
        default: return { color: "#f59e0b", icon: AlertTriangle, bg: "rgba(245, 158, 11, 0.1)" };
      }
    };

    const config = getStatusConfig();
    const StatusIcon = config.icon;

    return (
      <div className="flex items-center gap-3 p-4 rounded-xl" style={{background: config.bg}}>
        <StatusIcon className="w-6 h-6" style={{color: config.color}} />
        <div>
          <p className="font-bold" style={{color: config.color}}>{status} MODE</p>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            {status === "LIVE" ? "Full Guardian functions active" : "Safe testing environment"}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <style jsx>{`
        .simulation-glow {
          box-shadow: 0 0 30px rgba(76, 76, 230, 0.3);
          animation: simulationPulse 3s ease-in-out infinite alternate;
        }
        
        @keyframes simulationPulse {
          0% { box-shadow: 0 0 30px rgba(76, 76, 230, 0.3); }
          100% { box-shadow: 0 0 50px rgba(76, 76, 230, 0.5); }
        }

        .live-glow {
          box-shadow: 0 0 30px rgba(34, 197, 94, 0.4);
          animation: liveAlert 2s ease-in-out infinite alternate;
        }
        
        @keyframes liveAlert {
          0% { box-shadow: 0 0 30px rgba(34, 197, 94, 0.4); }
          100% { box-shadow: 0 0 50px rgba(34, 197, 94, 0.7); }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className={`text-4xl font-bold mb-4 flex items-center gap-3 ${mode === "Live" ? "live-glow" : "simulation-glow"}`}>
          <Cpu className="w-10 h-10" style={{color: mode === "Live" ? '#22c55e' : '#4c4ce6'}} />
          🎮 SIMULATION CENTER
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Safe testing environment with persistent state management and backend integration.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Settings className="w-5 h-5" style={{color: '#4c4ce6'}}/>
                MODE CONTROL
              </span>
              <Badge style={{
                background: mode === "Live" ? 'rgba(34, 197, 94, 0.2)' : 'rgba(76, 76, 230, 0.2)',
                color: mode === "Live" ? '#22c55e' : '#4c4ce6'
              }}>
                {mode.toUpperCase()}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <StatusIndicator status={systemStatus} />
            
            <div className="mt-6">
              <Button
                onClick={toggleMode}
                className={`w-full font-bold transition-all duration-300 ${
                  mode === "Live" 
                    ? "bg-blue-600 hover:bg-blue-700" 
                    : "bg-green-600 hover:bg-green-700"
                }`}
              >
                {mode === "Simulation" ? (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    ACTIVATE LIVE MODE
                  </>
                ) : (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    RETURN TO SIMULATION
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" style={{color: '#4c4ce6'}}/>
              SIMULATION DATA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span style={{color: 'var(--orbital-text-dim)'}}>Cycles Completed</span>
                <span className="font-bold" style={{color: '#4c4ce6'}}>{simulationData.cycles.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span style={{color: 'var(--orbital-text-dim)'}}>Lives Used (Test)</span>
                <span className="font-bold" style={{color: '#22c55e'}}>{simulationData.livesUsed}</span>
              </div>
              <div className="flex justify-between items-center">
                <span style={{color: 'var(--orbital-text-dim)'}}>Memory Streams</span>
                <span className="font-bold" style={{color: '#4c4ce6'}}>{simulationData.memoryStreams}</span>
              </div>
              <div className="flex justify-between items-center">
                <span style={{color: 'var(--orbital-text-dim)'}}>Safety Protocols</span>
                <span className="font-bold" style={{color: '#22c55e'}}>{simulationData.safeguards}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" style={{color: '#4c4ce6'}}/>
            SAFETY PROTOCOLS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.05)'}}>
              <h4 className="font-bold mb-2" style={{color: '#4c4ce6'}}>Simulation Mode</h4>
              <ul className="text-sm space-y-1" style={{color: 'var(--orbital-text-dim)'}}>
                <li>• Safe testing environment</li>
                <li>• No permanent effects</li>
                <li>• Full feature simulation</li>
                <li>• Data persistence enabled</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.05)'}}>
              <h4 className="font-bold mb-2" style={{color: '#22c55e'}}>Live Mode</h4>
              <ul className="text-sm space-y-1" style={{color: 'var(--orbital-text-dim)'}}>
                <li>• Full Guardian functions</li>
                <li>• Real-world effects</li>
                <li>• Immutable logging</li>
                <li>• Divine protection active</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center bg-black/80 z-50"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="chrome-surface rounded-2xl p-8 max-w-lg mx-4"
            >
              <div className="text-center mb-6">
                <AlertTriangle className="w-16 h-16 mx-auto mb-4" style={{color: '#f59e0b'}} />
                <h2 className="text-2xl font-bold mb-2" style={{color: 'var(--orbital-text)'}}>
                  CONFIRM LIVE MODE ACTIVATION
                </h2>
                <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
                  Switching to Live Mode will execute full Guardian Codex functions with real-world effects. 
                  This action will be logged immutably. Are you sure you want to proceed?
                </p>
              </div>
              
              <div className="flex gap-4">
                <Button
                  onClick={confirmLive}
                  className="flex-1 bg-green-600 hover:bg-green-700 font-bold"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  YES, ACTIVATE LIVE
                </Button>
                <Button
                  onClick={() => setShowModal(false)}
                  variant="outline"
                  className="flex-1 chrome-surface"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  CANCEL
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}