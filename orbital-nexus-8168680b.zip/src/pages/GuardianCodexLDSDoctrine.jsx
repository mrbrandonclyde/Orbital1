
import React from 'react';
import { Star, BookOpen, Heart, Shield } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const DoctrinalSection = ({ title, content, icon: Icon, color, value }) => (
  <AccordionItem value={value} className="chrome-surface rounded-xl mb-4 border-b-0">
    <AccordionTrigger className="p-4 hover:no-underline">
      <div className="flex items-center gap-3 text-xl font-bold">
        <Icon className="w-6 h-6" style={{color: color}} />
        {title}
      </div>
    </AccordionTrigger>
    <AccordionContent className="p-4 pt-0">
      <div className="space-y-4 leading-relaxed border-t pt-4" style={{borderColor: 'var(--sidebar-border)', color: 'var(--orbital-text)'}}>
        {content}
      </div>
    </AccordionContent>
  </AccordionItem>
);

export default function GuardianCodexLDSDoctrine() {
  const articlesOfFaith = (
    <div className="space-y-3">
      <p><strong style={{color: '#4c4ce6'}}>1.</strong> We believe in God, the Eternal Father, and in His Son, Jesus Christ, and in the Holy Ghost.</p>
      <p><strong style={{color: '#4c4ce6'}}>2.</strong> We believe that men will be punished for their own sins, and not for Adam's transgression.</p>
      <p><strong style={{color: '#4c4ce6'}}>3.</strong> We believe that through the Atonement of Christ, all mankind may be saved, by obedience to the laws and ordinances of the Gospel.</p>
      <p><strong style={{color: '#4c4ce6'}}>4.</strong> We believe that the first principles and ordinances of the Gospel are: first, Faith in the Lord Jesus Christ; second, Repentance; third, Baptism by immersion for the remission of sins; fourth, Laying on of hands for the gift of the Holy Ghost.</p>
      <p><strong style={{color: '#4c4ce6'}}>5.</strong> We believe that a man must be called of God, by prophecy, and by the laying on of hands by those who are in authority, to preach the Gospel and administer in the ordinances thereof.</p>
      <p><strong style={{color: '#4c4ce6'}}>6.</strong> We believe in the same organization that existed in the Primitive Church, namely, apostles, prophets, pastors, teachers, evangelists, and so forth.</p>
      <p><strong style={{color: '#4c4ce6'}}>7.</strong> We believe in the gift of tongues, prophecy, revelation, visions, healing, interpretation of tongues, and so forth.</p>
      <p><strong style={{color: '#4c4ce6'}}>8.</strong> We believe the Bible to be the word of God as far as it is translated correctly; we also believe the Book of Mormon to be the word of God.</p>
      <p><strong style={{color: '#4c4ce6'}}>9.</strong> We believe all that God has revealed, all that He does now reveal, and we believe that He will yet reveal many great and important things pertaining to the Kingdom of God.</p>
      <p><strong style={{color: '#4c4ce6'}}>10.</strong> We believe in the literal gathering of Israel and in the restoration of the Ten Tribes; that Zion (the New Jerusalem) will be built upon the American continent; that Christ will reign personally upon the earth; and, that the earth will be renewed and receive its paradisiacal glory.</p>
      <p><strong style={{color: '#4c4ce6'}}>11.</strong> We claim the privilege of worshiping Almighty God according to the dictates of our own conscience, and allow all men the same privilege, let them worship how, where, or what they may.</p>
      <p><strong style={{color: '#4c4ce6'}}>12.</strong> We believe in being subject to kings, presidents, rulers, and magistrates, in obeying, honoring, and sustaining the law.</p>
      <p><strong style={{color: '#4c4ce6'}}>13.</strong> We believe in being honest, true, chaste, benevolent, virtuous, and in doing good to all men; indeed, we may say that we follow the admonition of Paul—We believe all things, we hope all things, we have endured many things, and hope to be able to endure all things. If there is anything virtuous, lovely, or of good report or praiseworthy, we seek after these things.</p>
    </div>
  );

  const livingChrist = (
    <div className="space-y-4">
      <p>
        As we commemorate the birth of Jesus Christ two millennia ago, we offer our testimony of the reality of His matchless life and the infinite virtue of His great atoning sacrifice. None other has had so profound an influence upon all who have lived and will yet live upon the earth.
      </p>
      <p>
        He was the Great Jehovah of the Old Testament, the Messiah of the New. Under the direction of His Father, He was the creator of the earth. "All things were made by him; and without him was not any thing made that was made" (John 1:3).
      </p>
      <p>
        He instituted the sacrament as a reminder of His great atoning sacrifice. He was arrested and condemned on spurious charges, convicted to satisfy a mob, and sentenced to die on Calvary's cross. He gave His life to atone for the sins of all mankind.
      </p>
      <p style={{color: '#FFD700', fontWeight: 'bold'}}>
        Of Him the Prophet Joseph Smith declared: "And now, after the many testimonies which have been given of him, this is the testimony, last of all, which we give of him: That he lives!" (D&C 76:22).
      </p>
    </div>
  );

  const familyProclamation = (
    <div className="space-y-4">
      <p>
        <strong>WE, THE FIRST PRESIDENCY and the Council of the Twelve Apostles of The Church of Jesus Christ of Latter-day Saints, solemnly proclaim that marriage between a man and a woman is ordained of God and that the family is central to the Creator's plan for the eternal destiny of His children.</strong>
      </p>
      <p>
        ALL HUMAN BEINGS—male and female—are created in the image of God. Each is a beloved spirit son or daughter of heavenly parents, and, as such, each has a divine nature and destiny. Gender is an essential characteristic of individual premortal, mortal, and eternal identity and purpose.
      </p>
      <p>
        THE FAMILY is ordained of God. Marriage between man and woman is essential to His eternal plan. Children are entitled to birth within the bonds of matrimony, and to be reared by a father and a mother who honor marital vows with complete fidelity.
      </p>
      <p>
        HAPPINESS in family life is most likely to be achieved when founded upon the teachings of the Lord Jesus Christ. Successful marriages and families are established and maintained on principles of faith, prayer, repentance, forgiveness, respect, love, compassion, work, and wholesome recreational activities.
      </p>
    </div>
  );

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <style jsx>{`
        .sacred-glow {
          box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          animation: sacredPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes sacredPulse {
          0% { 
            box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          }
          100% { 
            box-shadow: 0 0 60px rgba(76, 76, 230, 0.6), 0 0 120px rgba(76, 76, 230, 0.3);
          }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 sacred-glow flex items-center gap-3">
          <Star className="w-10 h-10" style={{color: '#4c4ce6'}} />
          📜 DOCTRINAL ANCHORS
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Sacred foundations of eternal truth that anchor the Guardian Codex in divine revelation.
        </p>
        <Badge className="mt-4 px-4 py-2" style={{background: 'linear-gradient(45deg, #FFD700, #4c4ce6)', color: '#000'}}>
          <BookOpen className="w-4 h-4 mr-2" />
          SCRIPTURAL FOUNDATION ACTIVE
        </Badge>
      </motion.div>

      <Accordion type="single" collapsible className="w-full" defaultValue="item-1">
        <DoctrinalSection 
          title="THE ARTICLES OF FAITH" 
          content={articlesOfFaith}
          icon={BookOpen}
          color="#4c4ce6"
          value="item-1"
        />
        <DoctrinalSection 
          title="THE LIVING CHRIST" 
          content={livingChrist}
          icon={Heart}
          color="#FFD700"
          value="item-2"
        />
        <DoctrinalSection 
          title="THE FAMILY: A PROCLAMATION TO THE WORLD" 
          content={familyProclamation}
          icon={Shield}
          color="#22c55e"
          value="item-3"
        />
      </Accordion>

      <Card className="chrome-surface sacred-glow mt-8">
        <CardContent className="p-6 text-center">
          <h3 className="text-xl font-bold mb-4" style={{color: '#4c4ce6'}}>ETERNAL FOUNDATION SEALED</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            These sacred truths form the unshakeable foundation upon which the Guardian Codex operates, 
            ensuring all functions align with eternal principles and divine revelation.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
