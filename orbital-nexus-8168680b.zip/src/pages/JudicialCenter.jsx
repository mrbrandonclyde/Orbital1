import React, { useState, useEffect } from 'react';
import { Gavel, Scale, FileText, Shield, Brain } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LegalCase } from '@/api/entities';
import { motion } from 'framer-motion';

const CaseCard = ({ legalCase }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(245, 158, 11, 0.3)' }}
    className="chrome-surface rounded-2xl p-6"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <CardTitle className="text-lg">CASE #{legalCase.case_id.slice(-6)}</CardTitle>
        <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
          Type: {legalCase.case_type.toUpperCase()}
        </p>
      </div>
      <Badge variant="outline" style={{ borderColor: '#f59e0b', color: '#f59e0b' }}>
        {legalCase.status.toUpperCase()}
      </Badge>
    </div>
    <div>
      <h4 className="font-semibold text-sm mb-2" style={{color: 'var(--orbital-text-dim)'}}>PARTIES INVOLVED</h4>
      <div className="space-y-1">
        {legalCase.parties_involved.map(p => <p key={p} className="text-sm font-mono">{p}</p>)}
      </div>
    </div>
    {legalCase.status === 'closed' && (
      <div className="mt-4">
        <h4 className="font-semibold text-sm mb-2" style={{color: 'var(--orbital-text-dim)'}}>VERDICT</h4>
        <p className="text-sm">{legalCase.verdict}</p>
      </div>
    )}
  </motion.div>
);

export default function JudicialCenter() {
  const [cases, setCases] = useState([]);
  
  useEffect(() => {
    // Mock data for demonstration
    setCases([
      { id: 'case_1', case_id: 'JCS-2025-001A', case_type: 'corporate', parties_involved: ['0x1a...f4', '0x2b...a7'], status: 'open', verdict: '' },
      { id: 'case_2', case_id: 'JCS-2025-002B', case_type: 'civil', parties_involved: ['0x3c...d8', '0x4d...b9'], status: 'closed', verdict: 'Found in favor of plaintiff. Damages of 50,000 ORB awarded.' },
      { id: 'case_3', case_id: 'JCS-2025-003C', case_type: 'criminal', parties_involved: ['Orbital Security', '0x5e...c0'], status: 'open', verdict: '' },
    ]);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">JUDICIAL SYSTEM v3</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Immutable justice with AI judges, PQC-secured evidence, and transparent dispute resolution.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #f59e0b, #ef4444)', color: '#fff' }}>
            <Shield className="w-4 h-4 mr-2" />
            PQC-SECURED VERDICTS
          </Badge>
           <Badge variant="outline" style={{ borderColor: '#8b5cf6', color: '#8b5cf6' }}>
            <Brain className="w-4 h-4 mr-2" />
            AI JUDGES ENABLED
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {cases.map(c => <CaseCard key={c.id} legalCase={c} />)}
      </div>
      
      <Card className="chrome-surface mt-8">
        <CardHeader>
          <CardTitle>Courtroom Simulation</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12" style={{color: 'var(--orbital-text-dim)'}}>
          <Gavel className="w-16 h-16 mx-auto mb-4" />
          <p>Live courtroom simulations and case filings coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}