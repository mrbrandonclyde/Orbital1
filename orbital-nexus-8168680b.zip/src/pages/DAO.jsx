import React from 'react';
import { Group, Vote, Landmark, TrendingUp, ShieldCheck, PieChart, GitBranch, Banknote, BrainCircuit } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const ProposalCard = ({ title, status, votesFor, votesAgainst, aiAnalysis }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl p-6 transition-all duration-300"
  >
    <CardHeader className="p-0 mb-4">
      <div className="flex justify-between items-start">
        <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>{title}</h3>
        <Badge style={{background: status === 'Active' ? 'var(--orbital-blue-dim)' : '#4b5563', color: status === 'Active' ? 'var(--orbital-blue)' : 'var(--orbital-text)'}}>
          {status}
        </Badge>
      </div>
    </CardHeader>
    <CardContent className="p-0">
      <div className="flex justify-between mb-4">
        <div className="text-center">
          <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>VOTES FOR</p>
          <p className="text-xl font-bold" style={{color: '#22c55e'}}>{votesFor}</p>
        </div>
        <div className="text-center">
          <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>VOTES AGAINST</p>
          <p className="text-xl font-bold" style={{color: '#ef4444'}}>{votesAgainst}</p>
        </div>
      </div>
      <div className="p-3 rounded-lg" style={{background: 'rgba(139, 92, 246, 0.1)'}}>
        <p className="text-sm font-bold flex items-center gap-2" style={{color: '#a78bfa'}}>
          <BrainCircuit className="w-4 h-4"/>
          AI Impact Analysis
        </p>
        <p className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>{aiAnalysis}</p>
      </div>
      <Button className="w-full mt-4" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>View & Vote</Button>
    </CardContent>
  </motion.div>
);

const TreasuryMetric = ({ title, value, color, icon: Icon }) => (
  <motion.div
    whileHover={{ y: -5, scale: 1.02 }}
    className="chrome-surface rounded-xl p-4 text-center transition-all"
    style={{ borderBottom: `3px solid ${color}` }}
  >
    <Icon className="w-6 h-6 mx-auto mb-2" style={{color: color}} />
    <div className="text-xl font-bold" style={{color: 'var(--orbital-text)'}}>{value}</div>
    <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{title}</div>
  </motion.div>
);

export default function DAO() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">ORBITAL DAO</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Decentralized Autonomous Governance with AI-Enhanced Treasury</p>
        </div>
        <Button className="font-bold" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
          <Vote className="w-5 h-5 mr-2" />
          Create Proposal
        </Button>
      </div>
      
      <Card className="chrome-surface mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Landmark className="w-6 h-6" style={{color: 'var(--orbital-blue)'}}/> DAO TREASURY v2
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <TreasuryMetric title="Total Value Locked" value="$4.8B" color="#00d4ff" icon={Landmark} />
            <TreasuryMetric title="Diversified Assets" value="127" color="#8b5cf6" icon={PieChart} />
            <TreasuryMetric title="Risk-Adjusted Yield" value="14.2%" color="#22c55e" icon={TrendingUp} />
            <TreasuryMetric title="Operational Budget" value="$50M" color="#f59e0b" icon={Banknote} />
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><Vote className="w-6 h-6" style={{color: 'var(--orbital-blue)'}}/> ACTIVE PROPOSALS</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ProposalCard 
            title="OIP-007: Allocate funds for new world discovery" 
            status="Active" 
            votesFor="1.2M" 
            votesAgainst="12K" 
            aiAnalysis="High ROI potential with moderate risk. Aligns with expansion goals."
          />
          <ProposalCard 
            title="OIP-006: Increase staking rewards by 2%" 
            status="Passed" 
            votesFor="2.1M" 
            votesAgainst="50K"
            aiAnalysis="Positive impact on network security. Minor inflationary pressure."
          />
          <ProposalCard 
            title="OIP-008: Fund PQC Encryption Upgrade" 
            status="Active" 
            votesFor="875K" 
            votesAgainst="2K"
            aiAnalysis="Critical for long-term security. Low financial ROI, high systemic value."
          />
        </div>
      </div>
    </div>
  );
}