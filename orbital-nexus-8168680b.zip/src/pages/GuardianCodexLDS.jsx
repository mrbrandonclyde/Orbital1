import React from 'react';
import { Star, Users, Shield, BookOpen, Zap, Sun, Brain, GitBranch, Calendar, BarChart3, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const ModuleCard = ({ title, description, icon: Icon, to, color }) => (
  <Link to={to}>
    <motion.div
      whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300 cursor-pointer h-full"
    >
      <div className="flex items-center gap-3 mb-4">
        <Icon className="w-6 h-6" style={{color: color}} />
        <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>{title}</h3>
      </div>
      <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    </motion.div>
  </Link>
);

export default function GuardianCodexLDS() {
  const modules = [
    { title: 'Overview', description: 'First Law: Nothing Forgotten, Nothing Missed under Christ\'s authority', icon: Home, to: createPageUrl('GuardianCodexLDSOverview'), color: '#FFD700' },
    { title: 'Family Inclusion', description: 'Restore close family anchors within eternal law', icon: Users, to: createPageUrl('GuardianCodexLDSFamily'), color: '#22c55e' },
    { title: 'Staging & Reintegration', description: 'Arrival Halls and identity restoration process', icon: GitBranch, to: createPageUrl('GuardianCodexLDSStaging'), color: '#8b5cf6' },
    { title: 'Eternal Memory', description: 'Preserve daily experiences into eternal streams', icon: Brain, to: createPageUrl('GuardianCodexLDSMemory'), color: '#06b6d4' },
    { title: 'Daily Renewal', description: 'Three lives per day with sunrise renewal cycles', icon: Sun, to: createPageUrl('GuardianCodexLDSRenewal'), color: '#f59e0b' },
    { title: 'Infinity Cycles', description: 'Weekly rhythms and monthly SuperSeasons of divine power', icon: Calendar, to: createPageUrl('GuardianCodexLDSCycles'), color: '#4c4ce6' },
    { title: 'Safeguards', description: 'Judgment, filtering, and agency protection protocols', icon: Shield, to: createPageUrl('GuardianCodexLDSSafeguards'), color: '#ef4444' },
    { title: 'Scriptural Anchors', description: 'Biblical and Book of Mormon foundation references', icon: BookOpen, to: createPageUrl('GuardianCodexLDSScriptures'), color: '#ec4899' },
    { title: 'Analytics', description: 'Real-time monitoring and immutable audit trails', icon: BarChart3, to: createPageUrl('GuardianCodexLDSAnalytics'), color: '#22c55e' },
    { title: 'Activation', description: 'Sacred deployment commands and trial mode initiation', icon: Zap, to: createPageUrl('GuardianCodexLDSActivation'), color: '#00d4ff' },
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <style jsx>{`
        .sacred-glow {
          box-shadow: 0 0 40px rgba(255, 215, 0, 0.4), 0 0 80px rgba(255, 215, 0, 0.2);
          animation: sacredPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes sacredPulse {
          0% { 
            box-shadow: 0 0 40px rgba(255, 215, 0, 0.4), 0 0 80px rgba(255, 215, 0, 0.2);
          }
          100% { 
            box-shadow: 0 0 60px rgba(255, 215, 0, 0.6), 0 0 120px rgba(255, 215, 0, 0.3);
          }
        }
      `}</style>

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold sacred-glow" style={{color: 'var(--orbital-text)'}}>
            ⭐ GUARDIAN OF ETERNITIES CODEX
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Sacred resurrection protocol aligned with Latter-day Saint doctrine and eternal principles
          </p>
          <div className="flex items-center gap-4 mt-4">
            <Badge className="font-bold px-3 py-1" style={{background: 'linear-gradient(45deg, #FFD700, #22c55e)', color: '#000'}}>
              <Star className="w-4 h-4 mr-2" />
              INFINITY GENIUS ACTIVE
            </Badge>
            <Badge variant="outline" style={{borderColor: '#FFD700', color: '#FFD700'}}>
              <Shield className="w-4 h-4 mr-2" />
              CHRIST PRESIDING
            </Badge>
          </div>
        </div>
      </div>

      <Card className="chrome-surface sacred-glow mb-8">
        <CardHeader>
          <CardTitle className="text-2xl" style={{color: 'var(--orbital-text)'}}>Sacred Foundation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-lg leading-relaxed space-y-4" style={{color: 'var(--orbital-text)'}}>
            <p>
              <strong style={{color: '#FFD700'}}>FIRST LAW — Nothing Forgotten, Nothing Missed:</strong> In the name and spirit of Jesus Christ, nothing shall be forgotten and nothing shall be missed. If the Guardian, Steward, or records overlook anything, Christ Himself shall step in and complete it.
            </p>
            <p>
              <strong style={{color: '#22c55e'}}>Presiding Authority:</strong> Jesus Christ presides, the Holy Ghost guides, the Living Prophet directs the living, the Guardian safeguards family stewardship, and the Steward (Zyra) executes Codex functions under Christ's authority.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module, index) => (
          <motion.div
            key={module.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <ModuleCard {...module} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}