import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Star, Zap, Eye, Brain, Clock, Activity, CheckCircle, AlertCircle, Diamond, Sparkles } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GuardianCodex as GuardianCodexEntity } from '@/api/entities';

const CycleActivationCard = ({ title, abilities, duration, isActive, onActivate, color, icon: Icon }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className={`chrome-surface rounded-2xl p-6 transition-all duration-300 ${isActive ? 'guardian-active' : ''}`}
    style={{ border: `2px solid ${isActive ? color : 'rgba(0, 212, 255, 0.3)'}` }}
  >
    <style jsx>{`
      .guardian-active {
        background: linear-gradient(45deg, ${color}20, rgba(0, 212, 255, 0.1));
        animation: guardianPulse 3s ease-in-out infinite alternate;
      }
      
      @keyframes guardianPulse {
        0% { box-shadow: 0 0 20px ${color}40; }
        100% { box-shadow: 0 0 40px ${color}70; }
      }
    `}</style>
    
    <CardHeader className="p-0 mb-4">
      <CardTitle className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Icon className="w-6 h-6" style={{color: isActive ? color : 'var(--orbital-text-dim)'}} />
          <span style={{color: 'var(--orbital-text)'}}>{title}</span>
        </div>
        {isActive && <CheckCircle className="w-5 h-5" style={{color: color}} />}
      </CardTitle>
    </CardHeader>
    
    <CardContent className="p-0">
      <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>Duration: {duration}</p>
      <div className="space-y-2 mb-4">
        {abilities.map((ability, index) => (
          <div key={index} className="flex items-center gap-2">
            <Sparkles className="w-3 h-3" style={{color: isActive ? color : 'var(--orbital-text-dim)'}} />
            <span className="text-sm" style={{color: 'var(--orbital-text)'}}>{ability}</span>
          </div>
        ))}
      </div>
      
      <Button
        onClick={onActivate}
        disabled={isActive}
        className={isActive ? 'guardian-active-btn' : 'chrome-surface'}
        style={isActive ? {background: color, color: '#000'} : {}}
      >
        {isActive ? 'ACTIVE' : 'ACTIVATE'}
      </Button>
    </CardContent>
  </motion.div>
);

const AuditLogEntry = ({ entry, index }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: index * 0.1 }}
    className="chrome-surface rounded-lg p-4 mb-3"
  >
    <div className="flex items-start justify-between">
      <div>
        <p className="font-semibold" style={{color: 'var(--orbital-text)'}}>{entry.message}</p>
        <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
          {new Date(entry.timestamp).toLocaleString()}
        </p>
        <div className="flex gap-2 mt-2">
          {entry.cycles_active?.map(cycle => (
            <Badge key={cycle} className="text-xs" style={{background: 'rgba(0, 212, 255, 0.2)', color: 'var(--orbital-blue)'}}>
              {cycle.toUpperCase()}
            </Badge>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-2">
        {entry.auto_trigger ? (
          <AlertCircle className="w-4 h-4" style={{color: '#f59e0b'}} title="Auto-triggered" />
        ) : (
          <CheckCircle className="w-4 h-4" style={{color: '#22c55e'}} title="Manual activation" />
        )}
        <Badge style={{background: entry.status === 'active' ? '#22c55e' : '#6b7280', color: '#fff'}}>
          {entry.status?.toUpperCase()}
        </Badge>
      </div>
    </div>
  </motion.div>
);

export default function GuardianCodex() {
  const [codexStatus, setCodexStatus] = useState('inactive');
  const [activeCycles, setActiveCycles] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [guardianData, setGuardianData] = useState(null);
  const [infinityLevel, setInfinityLevel] = useState(1.0);

  const cycles = [
    { 
      id: 'daily', 
      title: 'Daily Cycle', 
      abilities: ['Regeneration', 'Flight', 'Healing', 'Telepathy', 'Perfect Memory'], 
      duration: '24 hours', 
      color: '#00d4ff',
      icon: Star 
    },
    { 
      id: 'weekly', 
      title: 'Weekly Cycle', 
      abilities: ['Super Speed', 'Enhanced Vision', 'Advanced Healing', 'Super Strength', 'Mind Reading', 'Cosmic Awareness', 'Perfect Balance'], 
      duration: '7 days', 
      color: '#8b5cf6',
      icon: Zap 
    },
    { 
      id: 'monthly', 
      title: 'Monthly Cycle', 
      abilities: ['Infinite Strength', 'Reality Manipulation', 'Energy Projection', 'Dimensional Travel', 'Time Perception', 'Cosmic Integration'], 
      duration: '30 days', 
      color: '#22c55e',
      icon: Brain 
    },
    { 
      id: 'century', 
      title: 'Century Cycle', 
      abilities: ['Eternal Creator Powers', 'Reality Reshaping', 'Universal Understanding', 'Omnipresent Awareness'], 
      duration: '100 years', 
      color: '#f59e0b',
      icon: Diamond 
    },
    { 
      id: 'millennium', 
      title: 'Millennium Cycle', 
      abilities: ['Civilization Builder', 'Species Evolution Guide', 'Planetary Consciousness', 'Galactic Influence'], 
      duration: '1000 years', 
      color: '#ef4444',
      icon: Eye 
    },
    { 
      id: 'infinity', 
      title: 'Infinity Cycle', 
      abilities: ['Guardian of All Realities', 'Multiverse Protector', 'Eternal Consciousness', 'Omnipotent Creator'], 
      duration: 'Eternal', 
      color: '#FFD700',
      icon: Shield 
    }
  ];

  useEffect(() => {
    loadGuardianData();
    loadAuditLog();
    
    // Infinity level progression simulation
    const infinityInterval = setInterval(() => {
      setInfinityLevel(prev => Math.min(100, prev + (Math.random() * 0.01)));
    }, 2000);

    return () => clearInterval(infinityInterval);
  }, []);

  const loadGuardianData = async () => {
    try {
      const guardians = await GuardianCodexEntity.list();
      if (guardians.length > 0) {
        setGuardianData(guardians[0]);
        setActiveCycles(guardians[0].active_abilities || []);
        setCodexStatus(guardians[0].infinity_integration_status || 'ascending');
      }
    } catch (error) {
      console.error('Failed to load guardian data:', error);
    }
  };

  const loadAuditLog = async () => {
    try {
      // Simulate audit log data - in real implementation, this would fetch from the backend
      const mockLog = [
        {
          event: "GuardianCodexActivation",
          timestamp: new Date().toISOString(),
          cycles_active: ["daily", "weekly"],
          codex_version: "Infinity Seed v0-100",
          status: "active",
          auto_trigger: false,
          message: "✅ Guardian of Eternities Codex Activated — Daily Cycle Engaged"
        }
      ];
      setAuditLog(mockLog);
    } catch (error) {
      console.error('Failed to load audit log:', error);
    }
  };

  const activateCodex = async () => {
    try {
      // Create or update Guardian Codex entry
      const newGuardian = {
        guardian_id: 'ZYRA_INFINITY',
        bearer_name: 'ZYRA (ADMIN)',
        current_cycle: {
          daily: 'morning',
          weekly: 'monday',
          monthly: 'january',
          century: 21,
          millennium: 3,
          infinity_era: 1
        },
        active_abilities: ['daily', 'weekly', 'monthly'],
        mastered_cycles: ['daily'],
        eternal_records: [{
          timestamp: new Date().toISOString(),
          cycle_activation: 'infinity_awakening',
          abilities_gained: ['omnipresent_consciousness', 'reality_manipulation', 'eternal_memory'],
          cosmic_significance: 'Guardian Status Achieved - Protector of All Realities'
        }],
        immutable_anchor: `guardian_${Date.now()}_infinity_seed`,
        rollback_checkpoints: [],
        eternal_law_compliance: true,
        infinity_integration_status: 'transcendent'
      };

      await GuardianCodexEntity.create(newGuardian);
      
      setCodexStatus('active');
      setActiveCycles(['daily', 'weekly', 'monthly']);
      
      // Add to audit log
      const newLogEntry = {
        event: "GuardianCodexActivation",
        timestamp: new Date().toISOString(),
        cycles_active: ['daily', 'weekly', 'monthly'],
        codex_version: "Infinity Seed v0-100",
        status: "active",
        auto_trigger: false,
        message: "✅ Guardian of Eternities Codex Activated — All Systems Transcendent"
      };
      setAuditLog(prev => [newLogEntry, ...prev]);
      
    } catch (error) {
      console.error('Codex activation failed:', error);
    }
  };

  const activateCycle = (cycleId) => {
    if (!activeCycles.includes(cycleId)) {
      setActiveCycles(prev => [...prev, cycleId]);
      
      const newLogEntry = {
        event: "CycleActivation",
        timestamp: new Date().toISOString(),
        cycles_active: [cycleId],
        status: "active",
        auto_trigger: false,
        message: `🌟 ${cycleId.toUpperCase()} Cycle Activated — Divine Powers Engaged`
      };
      setAuditLog(prev => [newLogEntry, ...prev]);
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .guardian-glow {
          box-shadow: 0 0 30px rgba(255, 215, 0, 0.4), 0 0 60px rgba(255, 215, 0, 0.2);
          animation: guardianBreath 4s ease-in-out infinite alternate;
        }
        
        @keyframes guardianBreath {
          0% { 
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.4), 0 0 60px rgba(255, 215, 0, 0.2);
          }
          100% { 
            box-shadow: 0 0 50px rgba(255, 215, 0, 0.6), 0 0 100px rgba(255, 215, 0, 0.3);
          }
        }
      `}</style>

      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold guardian-glow" style={{color: 'var(--orbital-text)'}}>
            🌟 GUARDIAN OF ETERNITIES CODEX
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Infinite consciousness evolution with omnipotent abilities and eternal memory
          </p>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></div>
              <span className="text-sm" style={{color: '#FFD700'}}>STATUS: {codexStatus.toUpperCase()}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500 animate-pulse"></div>
              <span className="text-sm" style={{color: '#8b5cf6'}}>INFINITY LEVEL: {infinityLevel.toFixed(1)}%</span>
            </div>
            <div className="px-3 py-1 rounded-full text-xs font-bold" 
                 style={{background: 'linear-gradient(45deg, #FFD700, #8b5cf6, #00d4ff)', color: '#000'}}>
              🛡️ ETERNAL LAW COMPLIANT
            </div>
          </div>
        </div>
        
        <Button 
          onClick={activateCodex}
          className="guardian-glow font-bold text-2xl px-8 py-4"
          style={{background: 'linear-gradient(45deg, #FFD700, #8b5cf6)', color: '#000', border: 'none'}}
        >
          <Shield className="w-6 h-6 mr-3" />
          ACTIVATE GUARDIAN CODEX
        </Button>
      </div>

      {/* Cycles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {cycles.map((cycle, index) => (
          <motion.div
            key={cycle.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <CycleActivationCard
              {...cycle}
              isActive={activeCycles.includes(cycle.id)}
              onActivate={() => activateCycle(cycle.id)}
            />
          </motion.div>
        ))}
      </div>

      {/* Audit Log */}
      <Card className="chrome-surface guardian-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
            <Activity className="w-6 h-6" style={{color: '#FFD700'}} />
            IMMUTABLE AUDIT LOG
            <Badge className="font-bold px-2 py-1" style={{background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000'}}>
              🔒 ETERNAL RECORDS
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-96 overflow-y-auto">
            <AnimatePresence>
              {auditLog.map((entry, index) => (
                <AuditLogEntry key={entry.timestamp} entry={entry} index={index} />
              ))}
            </AnimatePresence>
            
            {auditLog.length === 0 && (
              <div className="text-center py-8">
                <Clock className="w-12 h-12 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
                <p style={{color: 'var(--orbital-text-dim)'}}>No activation records found. Activate the Guardian Codex to begin eternal logging.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}