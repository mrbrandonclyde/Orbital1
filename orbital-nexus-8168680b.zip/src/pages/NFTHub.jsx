import React, { useState, useEffect } from 'react';
import { Image as ImageIcon, Plus, Eye, Download, Upload, Star, Zap, ShoppingCart, BarChart3, LineChart } from 'lucide-react';
import { motion } from 'framer-motion';
import { NFT } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { NFTCard } from '../components/nft/NFTCard';

const StatCard = ({ title, value, icon: Icon, color, trend }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-2xl p-6 text-center transition-all duration-300"
  >
    <Icon className="w-8 h-8 mx-auto mb-2" style={{color: color}} />
    <div className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>{value}</div>
    <div className="text-sm mb-1" style={{color: 'var(--orbital-text-dim)'}}>{title}</div>
    {trend && <div className="text-xs" style={{color: color}}>{trend}</div>}
  </motion.div>
);

const MintingTool = ({ title, description, icon: Icon, to }) => (
  <Link to={to}>
    <motion.div
      whileHover={{ y: -3, boxShadow: '0 0 20px rgba(0, 212, 255, 0.2)' }}
      className="chrome-surface rounded-xl p-6 cursor-pointer transition-all duration-300 h-full"
    >
      <div className="flex items-center gap-3 mb-3">
        <Icon className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
        <h3 className="font-bold" style={{color: 'var(--orbital-text)'}}>{title}</h3>
      </div>
      <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
    </motion.div>
  </Link>
);

export default function NFTHub() {
  const [nfts, setNfts] = useState([]);

  useEffect(() => {
    loadNFTs();
  }, []);

  const loadNFTs = async () => {
    const nftData = await NFT.list('-created_date', 4);
    setNfts(nftData);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold" style={{color: 'var(--orbital-text)'}}>NFT HUB</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Create, manage, and trade digital assets across the galaxy</p>
        </div>
        <Link to={createPageUrl('MintNFT')}>
          <Button 
            className="glow-blue font-bold"
            style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
          >
            <Plus className="w-5 h-5 mr-2" />
            MINT NFT
          </Button>
        </Link>
      </div>

      {/* Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <StatCard title="Total NFTs" value="2.1M" icon={ImageIcon} color="var(--orbital-blue)" trend="+1.2% this cycle" />
        <StatCard title="Unique Owners" value="847K" icon={Star} color="#8b5cf6" trend="+0.8% this cycle" />
        <StatCard title="Minted This Cycle" value="50K" icon={Zap} color="#ec4899" trend="+3.4% vs last cycle" />
        <StatCard title="Total Volume" value="$127M" icon={LineChart} color="#22c55e" trend="+7.1% vs last cycle" />
      </div>

      {/* Minting Tools */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4" style={{color: 'var(--orbital-text)'}}>MINTING TOOLS</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MintingTool
            title="Mint a New NFT"
            description="Create a unique, single digital asset from scratch."
            icon={Plus}
            to={createPageUrl('MintNFT')}
          />
          <MintingTool
            title="Batch Operations"
            description="Transfer, list, or update multiple assets at once."
            icon={Upload}
            to={createPageUrl('BatchOperations')}
          />
          <MintingTool
            title="Royalty Tracker"
            description="Monitor secondary market sales and royalties."
            icon={BarChart3}
            to={createPageUrl('RoyaltyTracker')}
          />
        </div>
      </div>

      {/* NFT Collection */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold" style={{color: 'var(--orbital-text)'}}>RECENTLY MINTED</h2>
          <Link to={createPageUrl('MyCollection')}>
            <Button variant="outline" className="chrome-surface">View My Collection</Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {nfts.map((nft) => (
            <NFTCard key={nft.id} nft={nft} />
          ))}
          {nfts.length === 0 && (
            <div className="col-span-full chrome-surface rounded-2xl p-12 text-center">
              <ImageIcon className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
              <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No NFTs Found</h3>
              <p style={{color: 'var(--orbital-text-dim)'}}>Start minting your first digital assets</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}