import React, { useState, useEffect } from 'react';
import { Landmark, DollarSign, Zap, Users, Shield, ArrowRightLeft, Plus } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BankAccount } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';

const AccountCard = ({ account }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl p-6"
  >
    <div className="flex justify-between items-start mb-4">
      <div>
        <CardTitle className="text-lg">{account.account_type.toUpperCase()} ACCOUNT</CardTitle>
        <p className="text-sm font-mono" style={{ color: 'var(--orbital-text-dim)' }}>
          {`ACCT...${account.id.slice(-8)}`}
        </p>
      </div>
      <Badge variant="outline" style={{ borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)' }}>
        {account.currency}
      </Badge>
    </div>
    <div className="text-4xl font-bold" style={{ color: 'var(--orbital-text)' }}>
      {account.balance_orb.toLocaleString()} <span className="text-2xl">{account.currency}</span>
    </div>
  </motion.div>
);

const TransactionRow = ({ tx, index }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: index * 0.05 }}
    className="flex items-center justify-between p-3 rounded-lg hover:bg-blue-500/10"
  >
    <div className="flex items-center gap-3">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.amount > 0 ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
        <ArrowRightLeft className="w-4 h-4" style={{color: tx.amount > 0 ? '#22c55e' : '#ef4444'}}/>
      </div>
      <div>
        <p className="font-semibold">{tx.amount > 0 ? 'Deposit from' : 'Transfer to'} {`...${tx.to_account_id.slice(-6)}`}</p>
        <p className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>{new Date().toLocaleString()}</p>
      </div>
    </div>
    <div className={`font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
      {tx.amount.toLocaleString()} {tx.currency}
    </div>
  </motion.div>
);

export default function Banking() {
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  
  useEffect(() => {
    // Mock data for demonstration
    setAccounts([
      { id: 'acc_1a2b3c4d5e6f', account_type: 'checking', balance_orb: 125830.50, currency: 'ORB' },
      { id: 'acc_7g8h9i0j1k2l', account_type: 'savings', balance_orb: 572345.00, currency: 'ORB' },
      { id: 'acc_3m4n5o6p7q8r', account_type: 'investment', balance_orb: 1250000.00, currency: 'USD' },
    ]);
    setTransactions([
      { id: 'tx_abc', from_account_id: '...', to_account_id: '...d5e6f', amount: 5000, currency: 'ORB' },
      { id: 'tx_def', from_account_id: '...d5e6f', to_account_id: '...ext', amount: -1200, currency: 'ORB' },
    ]);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">CITY BANKING SYSTEM v1</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Manage multi-currency vaults, FX transfers, and PQC-secured contracts.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #22c55e, #00d4ff)', color: '#000' }}>
            <Shield className="w-4 h-4 mr-2" />
            PCI-DSS & SOC2 COMPLIANT
          </Badge>
          <Badge variant="outline" style={{ borderColor: '#8b5cf6', color: '#8b5cf6' }}>
            <Zap className="w-4 h-4 mr-2" />
            AI FRAUD DETECTION ACTIVE
          </Badge>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {accounts.map(acc => <AccountCard key={acc.id} account={acc} />)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <Card className="chrome-surface h-full">
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {transactions.map((tx, i) => <TransactionRow key={tx.id} tx={tx} index={i} />)}
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Card className="chrome-surface h-full">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button size="lg" className="w-full glow-blue"><ArrowRightLeft className="w-4 h-4 mr-2" />New Transfer</Button>
              <Button size="lg" className="w-full glow-blue" variant="outline"><Plus className="w-4 h-4 mr-2" />Open New Account</Button>
              <Button size="lg" className="w-full glow-blue" variant="outline"><DollarSign className="w-4 h-4 mr-2" />Currency Exchange</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}