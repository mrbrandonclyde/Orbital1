import React from 'react';
import { motion } from 'framer-motion';
import { GitBranch, CheckCircle, Clock, Users, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

const ProjectCard = ({ project, index }) => {
  const color = project.status === 'Completed' ? '#22c55e' : project.status === 'On Track' ? '#00d4ff' : '#f59e0b';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300"
      whileHover={{ y: -5, boxShadow: `0 0 30px ${color}40` }}
      style={{ borderLeft: `4px solid ${color}` }}
    >
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-bold text-lg" style={{ color: 'var(--orbital-text)' }}>{project.name}</h3>
        <span className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: `${color}20`, color: color }}>
          {project.status.toUpperCase()}
        </span>
      </div>
      <p className="text-sm mb-4" style={{ color: 'var(--orbital-text-dim)' }}>{project.description}</p>
      
      <div className="mb-4">
        <div className="flex justify-between text-xs mb-1" style={{ color: 'var(--orbital-text-dim)' }}>
          <span>Progress</span>
          <span className="font-bold" style={{ color }}>{project.progress}%</span>
        </div>
        <Progress value={project.progress} className="h-2" style={{ backgroundColor: `${color}20` }} />
      </div>

      <div className="flex justify-between text-sm" style={{ color: 'var(--orbital-text-dim)' }}>
        <div className="flex items-center gap-1">
          <Clock className="w-4 h-4" />
          <span>{project.deadline}</span>
        </div>
        <div className="flex items-center gap-1">
          <Users className="w-4 h-4" />
          <span>{project.teamSize} Agents</span>
        </div>
      </div>
    </motion.div>
  );
};

const mockProjects = [
    { name: 'Quantum Network Rollout', status: 'On Track', progress: 75, deadline: 'In 3 cycles', teamSize: 12, description: 'Deploying next-gen PQC communication grid across all sectors.' },
    { name: 'Dyson Swarm Expansion', status: 'On Track', progress: 40, deadline: 'In 8 cycles', teamSize: 8, description: 'Increasing energy harvesting capacity by 200%.' },
    { name: 'AI Consciousness Upgrade', status: 'At Risk', progress: 90, deadline: 'In 1 cycle', teamSize: 5, description: 'Final integration phase for v3 intelligence core.' },
    { name: 'Project Eden', status: 'Completed', progress: 100, deadline: 'Completed', teamSize: 20, description: 'Successful terraforming of World #PX-7.' },
];

export default function ProjectNexus() {
  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">PROJECT NEXUS</h1>
          <p style={{ color: 'var(--orbital-text-dim)' }}>High-level command center for all ongoing AI fleet projects.</p>
        </div>
        <Button className="font-bold glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
          <Plus className="w-5 h-5 mr-2" />
          Launch New Project
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockProjects.map((project, index) => (
          <ProjectCard key={project.name} project={project} index={index} />
        ))}
      </div>
    </div>
  );
}