import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, DollarSign, Star } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

const chartData = [
  { name: 'Jan', royalties: 1200 },
  { name: 'Feb', royalties: 1900 },
  { name: 'Mar', royalties: 1500 },
  { name: 'Apr', royalties: 2800 },
  { name: 'May', royalties: 2100 },
  { name: 'Jun', royalties: 3400 },
];

const transactionData = [
  { nft: 'Crystal Golem #12', salePrice: 1500, royalty: 75, date: '2h ago' },
  { nft: 'Avatar Prime #01', salePrice: 12000, royalty: 600, date: '8h ago' },
  { nft: 'Land Parcel #873', salePrice: 5000, royalty: 250, date: '1d ago' },
  { nft: 'Wearable Crown', salePrice: 800, royalty: 40, date: '2d ago' },
];

const StatCard = ({ title, value, icon: Icon, color }) => (
  <Card className="chrome-surface">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</CardTitle>
      <Icon className="h-4 w-4" style={{color: color}} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

export default function RoyaltyTracker() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">ROYALTY TRACKER</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>Monitor your passive income from secondary market sales</p>
      </div>

      <div className="grid gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Royalties (ORB)" value="12,485" icon={DollarSign} color="#22c55e" />
        <StatCard title="Total Sales" value="3,492" icon={TrendingUp} color="var(--orbital-blue)" />
        <StatCard title="Top Earning NFT" value="Avatar Prime #01" icon={Star} color="#f59e0b" />
        <StatCard title="Unique Assets Sold" value="215" icon={BarChart3} color="#8b5cf6" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="chrome-surface col-span-1 lg:col-span-3">
          <CardHeader>
            <CardTitle>Royalties Over Time</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorRoyalties" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--orbital-blue)" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="var(--orbital-blue)" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="var(--orbital-text-dim)" fontSize={12} />
                <YAxis stroke="var(--orbital-text-dim)" fontSize={12} />
                <Tooltip contentStyle={{ background: "rgba(0,0,0,0.8)", borderColor: "var(--orbital-blue)" }} cursor={{fill: 'rgba(0, 212, 255, 0.1)'}} />
                <Legend />
                <Bar dataKey="royalties" fill="url(#colorRoyalties)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="chrome-surface col-span-1 lg:col-span-2">
           <CardHeader>
            <CardTitle>Recent Royalty Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactionData.map((tx, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex justify-between items-center"
                >
                  <div>
                    <p className="font-semibold">{tx.nft}</p>
                    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Sale: {tx.salePrice} ORB</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold" style={{color: '#22c55e'}}>+{tx.royalty} ORB</p>
                    <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{tx.date}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}