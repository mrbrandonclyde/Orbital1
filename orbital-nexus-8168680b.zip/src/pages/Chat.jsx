import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, Bot, User, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { InvokeLLM } from '@/api/integrations';

const Message = ({ message, isUser }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className={`flex gap-3 mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}
  >
    {!isUser && (
      <div className="w-8 h-8 rounded-full flex items-center justify-center chrome-surface">
        <Bot className="w-4 h-4" style={{color: 'var(--orbital-blue)'}} />
      </div>
    )}
    <div 
      className={`max-w-md p-3 rounded-xl ${
        isUser 
          ? 'chrome-surface ml-auto' 
          : 'bg-blue-500/20 border border-blue-500/30'
      }`}
    >
      <p style={{color: 'var(--orbital-text)'}}>{message}</p>
    </div>
    {isUser && (
      <div className="w-8 h-8 rounded-full flex items-center justify-center" 
           style={{background: 'var(--orbital-blue)'}}>
        <User className="w-4 h-4" style={{color: 'var(--orbital-black)'}} />
      </div>
    )}
  </motion.div>
);

export default function Chat() {
  const [messages, setMessages] = useState([
    { text: "Hello! I'm your Orbital AI assistant. How can I help you navigate the universe today?", isUser: false }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { text: userMessage, isUser: true }]);
    setIsLoading(true);

    try {
      const response = await InvokeLLM({
        prompt: `You are an AI assistant for the Orbital universe platform. Respond helpfully to: ${userMessage}`,
      });
      
      setMessages(prev => [...prev, { text: response, isUser: false }]);
    } catch (error) {
      setMessages(prev => [...prev, { text: "I apologize, but I'm experiencing technical difficulties. Please try again.", isUser: false }]);
    }
    
    setIsLoading(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}} className="h-full flex flex-col">
      {/* Header */}
      <div className="mb-6 flex-shrink-0">
        <h1 className="text-4xl font-bold" style={{color: 'var(--orbital-text)'}}>
          AI COMMAND CHAT
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          Direct communication with Orbital AI consciousness
        </p>
      </div>

      {/* Chat Container */}
      <Card className="flex-1 chrome-surface flex flex-col">
        <CardContent className="flex-1 flex flex-col p-6">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto mb-4 pr-2">
            <AnimatePresence>
              {messages.map((message, index) => (
                <Message key={index} message={message.text} isUser={message.isUser} />
              ))}
            </AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3 mb-4"
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center chrome-surface">
                  <Bot className="w-4 h-4" style={{color: 'var(--orbital-blue)'}} />
                </div>
                <div className="bg-blue-500/20 border border-blue-500/30 p-3 rounded-xl">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce"></div>
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="flex gap-4">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about the Orbital universe..."
              className="flex-1 chrome-surface"
              style={{color: 'var(--orbital-text)', borderColor: 'rgba(0, 212, 255, 0.3)'}}
              disabled={isLoading}
            />
            <Button 
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              className="glow-blue"
              style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}