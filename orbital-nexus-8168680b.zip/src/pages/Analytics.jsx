import React from 'react';
import { BarChart, Users, Activity, TrendingUp, Cpu, PieChart } from 'lucide-react';
import { PredictiveChart } from '../components/analytics/PredictiveChart';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { ResponsiveContainer, AreaChart, Area, Tooltip, Legend } from 'recharts';

const data = [
  { name: 'Jan', users: 4000, revenue: 2400 },
  { name: 'Feb', users: 3000, revenue: 1398 },
  { name: 'Mar', users: 2000, revenue: 9800 },
  { name: 'Apr', users: 2780, revenue: 3908 },
  { name: 'May', users: 1890, revenue: 4800 },
  { name: 'Jun', users: 2390, revenue: 3800 },
  { name: 'Jul', users: 3490, revenue: 4300 },
];

const StatCard = ({title, value, icon: Icon, color}) => (
  <Card className="chrome-surface">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</CardTitle>
      <Icon className="h-4 w-4" style={{color: color}} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

export default function Analytics() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">ANALYTICS & PREDICTIONS</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Real-time data pipelines with AI-powered predictive insights</p>
        </div>
      </div>

      <div className="grid gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Daily Active Users" value="12,485" icon={Users} color="var(--orbital-blue)" />
        <StatCard title="Transaction Volume" value="$1.2M" icon={TrendingUp} color="#22c55e" />
        <StatCard title="System Load" value="34%" icon={Cpu} color="#f59e0b" />
        <StatCard title="Network Latency" value="42ms" icon={Activity} color="#8b5cf6" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="chrome-surface col-span-1 lg:col-span-3">
          <CardHeader>
            <CardTitle>User Growth & Revenue</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
             <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--orbital-blue)" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="var(--orbital-blue)" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip contentStyle={{ background: "rgba(0,0,0,0.8)", borderColor: "var(--orbital-blue)" }} />
                <Legend />
                <Area type="monotone" dataKey="users" stroke="var(--orbital-blue)" fillOpacity={1} fill="url(#colorUsers)" />
                <Area type="monotone" dataKey="revenue" stroke="#22c55e" fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="chrome-surface col-span-1 lg:col-span-2">
           <CardHeader>
            <CardTitle>AI Economic Forecast</CardTitle>
            <p className="text-xs pt-1" style={{color: 'var(--orbital-text-dim)'}}>Predictive model for ORB token price</p>
          </CardHeader>
          <CardContent className="h-80">
            <PredictiveChart />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}