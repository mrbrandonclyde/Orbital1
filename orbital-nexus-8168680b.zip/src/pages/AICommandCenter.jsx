import React, { useState } from 'react';
import { Brain, Zap, Terminal } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { InvokeLLM } from '@/api/integrations';

export default function AICommandCenter() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setResponse('');
    try {
      const res = await InvokeLLM({ prompt: `As the core AI of the Orbital platform, respond to the following user query: "${prompt}"` });
      setResponse(res);
    } catch (error) {
      setResponse('An error occurred while communicating with the AI core.');
    }
    setIsLoading(false);
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold" style={{ color: 'var(--orbital-text)' }}>AI COMMAND CENTER</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Direct interface with the platform's core intelligence</p>
      </div>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
            QUERY THE ORACLE
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Textarea
              placeholder="Enter your command or query for the AI..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="h-32 chrome-surface"
              style={{color: 'var(--orbital-text)'}}
            />
            <Button onClick={handleSubmit} disabled={isLoading} className="glow-blue">
              <Zap className="w-4 h-4 mr-2" />
              {isLoading ? 'Processing...' : 'Execute Command'}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {response && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8"
        >
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
                AI RESPONSE
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="whitespace-pre-wrap text-sm" style={{fontFamily: 'monospace'}}>{response}</pre>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}