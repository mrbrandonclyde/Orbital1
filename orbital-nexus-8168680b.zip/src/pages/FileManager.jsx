import React, { useState } from 'react';
import { Upload, File, HardDrive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { UploadFile as UploadFileIntegration } from '@/api/integrations';

export default function FileManager() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadUrl, setUploadUrl] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    try {
      const result = await UploadFileIntegration({ file });
      setUploadUrl(result.file_url);
    } catch (error) {
      console.error("Upload failed", error);
    }
    setUploading(false);
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">FILE MANAGER</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Securely upload and manage your files</p>
      </div>
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
            UPLOAD FILE
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input type="file" onChange={handleFileChange} className="chrome-surface" />
          <Button onClick={handleUpload} disabled={uploading || !file} className="glow-blue">
            {uploading ? 'Uploading...' : 'Upload'}
          </Button>
          {uploadUrl && (
            <p className="text-sm text-green-400">Upload successful! URL: {uploadUrl}</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}