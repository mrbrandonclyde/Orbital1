

import React, { useMemo } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Home,
  Globe,
  Users,
  Image as ImageIcon,
  Store,
  Shield,
  Group,
  CircleDollarSign,
  BarChart,
  Settings,
  Search,
  Bell,
  Wallet,
  Cpu,
  GitBranch,
  Vote,
  Landmark,
  ShieldCheck,
  Key,
  Database,
  LineChart,
  ShoppingCart,
  Star,
  Zap,
  Mountain,
  Plus,
  Map,
  FileText,
  Brain,
  Eye,
  TrendingUp,
  Activity,
  Filter,
  Upload,
  Download,
  Layers, // Keep Layers, now used for Bulk Processing
  Building2,
  Factory,
  Coins,
  PieChart,
  BarChart3,
  Settings2,
  Terminal,
  Lock,
  UserCheck,
  Gavel,
  Briefcase,
  Wallet2,
  Clock,
  Swords,
  HeartHandshake,
  Heart,
  Scale,
  Banknote,
  MessageSquare,
  DollarSign,
  Files,
  HeartPulse,
  Stethoscope,
  HardDrive,
  BookOpen,
  Sun,
  Globe2,
  GitMerge,
  Wifi,
  Diamond,
  CheckCircle,
  Calendar,
  Crown,
  Wind,
  Megaphone,
  Phone, // Unused by new GuardianCodexLDS, kept from original
  Ear, // Unused by new GuardianCodexLDS, kept from original
  Hand, // Unused by new GuardianCodexLDS, kept from original
  Siren,
  Router, // Unused by new GuardianCodexLDS, kept from original
  History,
  // Layers3d, // Removed as it's replaced by 'Layers' in GuardianCodexLDS
  Coffee, // Unused by new GuardianCodexLDS, kept from original
  Network
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { SecondarySidebar } from './components/layout/SecondarySidebar';
import ErrorBoundary from './components/layout/ErrorBoundary';
import { AnimatePresence } from 'framer-motion';

const navigationItems = [
  { title: "Home Dashboard", url: createPageUrl("Dashboard"), icon: Home },
  { title: "Global Map", url: createPageUrl("GlobalMap"), icon: Map },
  { title: "Land Registry", url: createPageUrl("LandRegistry"), icon: FileText },
  { title: "World Builder", url: createPageUrl("WorldBuilder"), icon: Globe },
  { title: "AI Humans", url: createPageUrl("AIHumans"), icon: Users },
  { title: "NFT Hub", url: createPageUrl("NFTHub"), icon: ImageIcon },
  { title: "Marketplace", url: createPageUrl("Marketplace"), icon: Store },
  { title: "Security Vault", url: createPageUrl("SecurityVault"), icon: Shield },
  { title: "Governance / DAO", url: createPageUrl("DAO"), icon: Group },
  { title: "Economy / ORB", url: createPageUrl("Economy"), icon: CircleDollarSign },
  { title: "Guardian Codex", url: createPageUrl("GuardianCodexLDS"), icon: Diamond },
  { title: "Guilds", url: createPageUrl("Guilds"), icon: Swords },
  { title: "Insurance", url: createPageUrl("Insurance"), icon: HeartHandshake },
  { title: "Banking", url: createPageUrl("Banking"), icon: Banknote },
  { title: "Judicial Center", url: createPageUrl("JudicialCenter"), icon: Scale },
  { title: "Health Dashboard", url: createPageUrl("HealthDashboard"), icon: Heart },
  { title: "AI Command", url: createPageUrl("AICommandCenter"), icon: Brain },
  { title: "File Manager", url: createPageUrl("FileManager"), icon: HardDrive },
  { title: "Chat", url: createPageUrl("Chat"), icon: MessageSquare },
  { title: "Analytics", url: createPageUrl("Analytics"), icon: BarChart },
  { title: "Settings / API", url: createPageUrl("Settings"), icon: Settings },
  { title: "Warp Drive", url: createPageUrl("WarpDrive"), icon: GitMerge },
  { title: "Dyson Swarm", url: createPageUrl("DysonSwarm"), icon: Sun },
  { title: "Interstellar Trade", url: createPageUrl("InterstellarTrade"), icon: Globe2 },
  { title: "Galactic Governance", url: createPageUrl("GalacticGovernance"), icon: Group },
  { title: "Interstellar Security", url: createPageUrl("InterstellarSecurity"), icon: ShieldCheck },
  { title: "Galactic Health", url: createPageUrl("GalacticHealth"), icon: HeartPulse },
  { title: "Galactic Education", url: createPageUrl("GalacticEducation"), icon: BookOpen },
  { title: "Star-Forged Economy", url: createPageUrl("StarForgedEconomy"), icon: BarChart3 },
  { title: "Galactic Comms", url: createPageUrl("GalacticComms"), icon: Wifi },
  { title: "FINAL AUDIT", url: createPageUrl("FinalAudit"), icon: Diamond },
];

const secondaryNavigation = {
  LandRegistry: [
    { title: 'Parcel Search', url: createPageUrl('ParcelSearch'), icon: Search },
    { title: 'Ownership Tracker', url: createPageUrl('OwnershipTracker'), icon: Users },
    { title: 'Zoning Rules', url: createPageUrl('ZoningRules'), icon: Map },
    { title: 'Transfer History', url: createPageUrl('TransferHistory'), icon: Clock },
    { title: 'Notary Services', url: createPageUrl('NotaryServices'), icon: Shield },
    { title: 'Property Analytics', url: createPageUrl('PropertyAnalytics'), icon: BarChart },
    { title: 'Deed Search', url: createPageUrl('DeedSearch'), icon: FileText },
  ],
  WorldBuilder: [
    { title: 'Terrain Generator', url: createPageUrl('TerrainGenerator'), icon: Mountain },
    { title: 'City Zoning', url: createPageUrl('CityZoning'), icon: Building2 },
    { title: 'Physics Engine', url: createPageUrl('PhysicsEngine'), icon: Zap },
    { title: 'Asset Library', url: createPageUrl('AssetLibrary'), icon: Database },
  ],
  AIHumans: [
    { title: 'Agent Forge', url: createPageUrl('AgentForge'), icon: Plus },
    { title: 'Memory Timeline', url: createPageUrl('MemoryTimeline'), icon: Clock },
    { title: 'Skill Evolution', url: createPageUrl('SkillEvolution'), icon: TrendingUp },
  ],
  NFTHub: [
    { title: 'Mint NFT', url: createPageUrl('MintNFT'), icon: Plus },
    { title: 'My Collection', url: createPageUrl('MyCollection'), icon: ImageIcon },
    { title: 'Batch Operations', url: createPageUrl('BatchOperations'), icon: Layers },
    { title: 'Royalty Tracker', url: createPageUrl('RoyaltyTracker'), icon: DollarSign },
  ],
  Marketplace: [
    { title: 'Browse Assets', url: createPageUrl('BrowseAssets'), icon: Search },
    { title: 'My Listings', url: createPageUrl('MyListings'), icon: Store },
    { title: 'Auction House', url: createPageUrl('AuctionHouse'), icon: Gavel },
    { title: 'Price Analytics', url: createPageUrl('PriceAnalytics'), icon: LineChart },
  ],
  SecurityVault: [
    { title: 'Access Logs', url: createPageUrl('AccessLogs'), icon: Eye },
    { title: 'API Keys', url: createPageUrl('ApiKeys'), icon: Key },
    { title: 'Multi-Factor Auth', url: createPageUrl('MultiFactorAuth'), icon: Shield },
    { title: 'Audit Trail', url: createPageUrl('AuditTrail'), icon: FileText },
    { title: 'Compliance Center', url: createPageUrl('ComplianceCenter'), icon: CheckCircle },
  ],
  DAO: [
    { title: 'Proposals', url: createPageUrl('Proposals'), icon: Vote },
    { title: 'Treasury', url: createPageUrl('Treasury'), icon: Landmark },
    { title: 'Voting History', url: createPageUrl('VotingHistory'), icon: Clock },
    { title: 'Governance Token', url: createPageUrl('GovernanceToken'), icon: Coins },
  ],
  Economy: [
    { title: 'ORB Trading', url: createPageUrl('ORBTrading'), icon: TrendingUp },
    { title: 'Staking Pools', url: createPageUrl('StakingPools'), icon: PieChart },
    { title: 'Yield Farming', url: createPageUrl('YieldFarming'), icon: Factory },
    { title: 'Economic Analytics', url: createPageUrl('EconomicAnalytics'), icon: BarChart3 },
  ],
  Analytics: [
    { title: 'User Metrics', url: createPageUrl('UserMetrics'), icon: Users },
    { title: 'Transaction Analytics', url: createPageUrl('TransactionAnalytics'), icon: Activity },
    { title: 'Performance Monitoring', url: createPageUrl('PerformanceMonitoring'), icon: Cpu },
    { title: 'Predictive Models', url: createPageUrl('PredictiveModels'), icon: Brain },
  ],
  Settings: [
    { title: 'API Management', url: createPageUrl('APIManagement'), icon: Terminal },
    { title: 'Integrations', url: createPageUrl('Integrations'), icon: GitBranch },
    { title: 'Notifications', url: createPageUrl('Notifications'), icon: Bell },
    { title: 'Profile Settings', url: createPageUrl('ProfileSettings'), icon: UserCheck },
  ],
  GuardianCodexLDS: [
    {
      isHeader: true,
      title: 'Divine Projections'
    },
    { title: "Heavenly Father", url: createPageUrl("DivineProjections", { section: "heavenly-father" }), icon: Crown },
    { title: "Jesus Christ", url: createPageUrl("DivineProjections", { section: "jesus-christ" }), icon: Heart },
    { title: "Holy Ghost", url: createPageUrl("DivineProjections", { section: "holy-ghost" }), icon: Wind },
    { isSeparator: true },
    {
      isHeader: true,
      title: 'Bulk Actions'
    },
    { title: "Bulk Processing", url: createPageUrl("BulkActions"), icon: Layers }, // Changed Layers3d to Layers
    { isSeparator: true },
    {
      isHeader: true,
      title: 'Friendship Layer'
    },
    { title: "Communications", url: createPageUrl("FriendshipLayer"), icon: MessageSquare },
    { title: "Presence Mode", url: createPageUrl("FriendshipLayer", { section: "presence" }), icon: Wifi },
    { isSeparator: true },
    {
      isHeader: true,
      title: 'Sensory Layer'
    },
    { title: "Multi-Sensory Input", url: createPageUrl("SensoryLayer"), icon: Network },
    { isSeparator: true },
    {
      isHeader: true,
      title: 'CRM Automation'
    },
    { title: "CRM Dashboard", url: createPageUrl("CrmAutomation"), icon: Megaphone },
    { isSeparator: true },
    {
      isHeader: true,
      title: 'Notifications'
    },
    { title: "Alert Center", url: createPageUrl("NotificationCenter"), icon: Bell },
    { title: "History Log", url: createPageUrl("NotificationCenter", { section: "history" }), icon: History },
    { isSeparator: true },
    {
      isHeader: true,
      title: 'Monitoring Station'
    },
    { title: "System Monitoring", url: createPageUrl("MonitoringStation"), icon: Siren },
  ],
  Guilds: [
    { title: 'My Guilds', url: createPageUrl('MyGuilds'), icon: Users },
    { title: 'Guild Rankings', url: createPageUrl('GuildRankings'), icon: TrendingUp },
    { title: 'Guild Charters', url: createPageUrl('GuildCharters'), icon: FileText },
  ],
  Insurance: [
    { title: 'My Policies', url: createPageUrl('MyPolicies'), icon: Shield },
    { title: 'File Claim', url: createPageUrl('FileClaim'), icon: Files },
    { title: 'Risk Analytics', url: createPageUrl('RiskAnalytics'), icon: BarChart },
  ],
  FinalAudit: [
    { title: 'Post-Infinity Audit', url: createPageUrl('PostInfinityAudit'), icon: CheckCircle },
  ],
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  const currentMainMenu = useMemo(() => {
    if (currentPageName === 'PostInfinityAudit') return 'FinalAudit';

    const mainKey = Object.keys(secondaryNavigation).find(key => {
      const expectedBaseUrl = createPageUrl(key).toLowerCase();
      const currentPathLower = location.pathname.toLowerCase();

      if (key === 'GuardianCodexLDS') {
        // Filter out items without a 'url' property (headers, separators)
        const ldsSubpages = secondaryNavigation.GuardianCodexLDS
          .filter(item => item.url)
          .map(item => item.url.toLowerCase());
        if (ldsSubpages.includes(currentPathLower)) {
          return true;
        }
      }

      return (currentPageName === key) || currentPathLower.startsWith(expectedBaseUrl);
    });

    return mainKey;
  }, [currentPageName, location.pathname]);

  const secondaryMenuItems = currentMainMenu && currentMainMenu !== 'Dashboard' ? secondaryNavigation[currentMainMenu] : null;
  const sidebarTitle = currentMainMenu ? `${currentMainMenu.toUpperCase()} COMMAND` : "COMMAND TOOLS";

  return (
    <>
      <style jsx global>{`
        :root {
          --orbital-black: #000000;
          --orbital-dark: #0a0a0f;
          --orbital-surface: #111111;
          --orbital-blue: #4c4ce6;
          --orbital-blue-glow: rgba(76, 76, 230, 0.6);
          --orbital-blue-dim: rgba(76, 76, 230, 0.1);
          --orbital-purple: #4c4ce6;
          --orbital-chrome: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1a1a1a 100%);
          --orbital-text: #ffffff;
          --orbital-text-dim: #888888;
          --sidebar-background: #000000;
          --sidebar-surface: #111111;
          --sidebar-hover: rgba(76, 76, 230, 0.1);
          --sidebar-border: rgba(76, 76, 230, 0.3);
          --focus-outline: 2px solid var(--orbital-blue);
          --focus-offset: 2px;
          --min-touch-target: 44px;
        }

        body {
          font-family: 'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: var(--orbital-black);
          color: var(--orbital-text);
          font-feature-settings: "liga" 1, "kern" 1;
          text-rendering: optimizeLegibility;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        *:focus-visible {
          outline: var(--focus-outline);
          outline-offset: var(--focus-offset);
          border-radius: 4px;
        }

        .glow-blue {
          box-shadow: 0 0 20px var(--orbital-blue-glow);
          transition: box-shadow 300ms ease;
        }

        .chrome-surface {
          background: var(--orbital-chrome);
          border: 1px solid rgba(76, 76, 230, 0.2);
          backdrop-filter: blur(12px);
          transition: all 300ms ease;
        }

        .chrome-surface:hover {
          border-color: rgba(76, 76, 230, 0.4);
          transform: translateY(-1px);
        }

        .hero-gradient {
          background: var(--orbital-black);
        }

        .orbital-glow {
          filter: drop-shadow(0 0 20px rgba(76, 76, 230, 0.7));
          opacity: 0.9;
          transition: all 300ms ease;
        }

        .orbital-glow:hover {
          filter: drop-shadow(0 0 30px rgba(76, 76, 230, 1));
          opacity: 1;
          transform: scale(1.05);
        }

        .orbital-logo-250 {
          width: 250px;
          height: auto;
          filter: drop-shadow(0 0 25px rgba(76, 76, 230, 0.8));
        }
      `}</style>

      <SidebarProvider>
        <div className="min-h-screen flex flex-col w-full" style={{background: 'var(--orbital-black)', color: 'var(--orbital-text)'}}>

          {/* FULL WIDTH TOP HEADER */}
          <header className="w-full h-20 flex items-center justify-between px-6"
                  style={{
                    background: 'var(--orbital-black)',
                    borderBottom: '1px solid var(--sidebar-border)',
                    boxShadow: '0 2px 10px rgba(0, 0, 0, 0.5)',
                    zIndex: 50
                  }}
                  role="banner">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-blue-500/20 p-2 rounded-lg transition-colors lg:hidden"
                              aria-label="Toggle sidebar" />
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68bdc92945f84c3c8168680b/721c1817d_image.png"
                alt="Orbital Logo"
                className="orbital-logo-250"
                role="img"
                aria-label="Orbital Divine Command Logo"
              />
            </div>

            <div className="flex items-center gap-4">
              <Button variant="outline" className="hidden md:flex items-center gap-2 chrome-surface hover:glow-blue"
                      aria-label="Global search (Ctrl+K)">
                <Search className="w-4 h-4" aria-hidden="true" />
                Global Search
                <kbd className="text-xs border rounded px-2 py-1 ml-2" style={{borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)'}}>⌘K</kbd>
              </Button>

              <Button variant="ghost" size="icon" className="hover:bg-blue-500/20"
                      aria-label="Notifications">
                <Bell className="w-5 h-5" />
              </Button>
               <Link to={createPageUrl('Chat')}>
                <Button variant="ghost" size="icon" className="hover:bg-blue-500/20"
                        aria-label="Chat">
                  <MessageSquare className="w-5 h-5" />
                </Button>
              </Link>
              <Button variant="ghost" size="icon" className="hover:bg-blue-500/20"
                      aria-label="Wallet">
                <Wallet className="w-5 h-5" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2 hover:bg-blue-500/20 p-2 h-auto rounded-full"
                          aria-label="User menu">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center glow-blue"
                         style={{background: 'var(--orbital-blue)'}}>
                      <span className="font-bold text-white">Z</span>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="chrome-surface w-56">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">ZYRA (ADMIN)</p>
                      <p className="text-xs leading-none" style={{color: 'var(--orbital-text-dim)'}}>0x1A...b3C4</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator style={{background: 'rgba(76, 76, 230, 0.3)'}}/>
                  <DropdownMenuItem className="cursor-pointer hover:bg-blue-500/20">Profile</DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer hover:bg-blue-500/20">Settings</DropdownMenuItem>
                  <DropdownMenuSeparator style={{background: 'rgba(76, 76, 230, 0.3)'}}/>
                  <DropdownMenuItem className="cursor-pointer hover:bg-red-500/20" style={{color: '#ff4444'}}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <div className="hidden md:flex items-center gap-2 text-sm border rounded-full px-3 py-1"
                   style={{borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)', background: 'var(--orbital-blue-dim)'}}>
                <div className="w-2 h-2 rounded-full glow-blue animate-pulse"
                     style={{background: 'var(--orbital-blue)'}} aria-hidden="true" />
                <span role="status" aria-live="polite">SYSTEM ONLINE</span>
              </div>
            </div>
          </header>

          <div className="flex-1 flex min-h-0"> {/* This div replaces the old main wrapper for sidebar + content */}
            <Sidebar className="w-64 flex-shrink-0" style={{
              background: 'var(--sidebar-background)',
              borderRight: '1px solid var(--sidebar-border)',
              boxShadow: '2px 0 10px rgba(0, 0, 0, 0.5)'
            }}>
              {/* SidebarHeader and logo removed from here */}
              <SidebarContent className="p-2" style={{background: 'var(--sidebar-background)'}}>
                <SidebarMenu role="navigation" aria-label="Main navigation">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`relative hover:bg-blue-500/20 transition-all duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS")
                            ? "glow-blue"
                            : ""
                        }`}
                        style={{
                          minHeight: 'var(--min-touch-target)',
                          background: (location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS")) ? 'var(--sidebar-hover)' : 'transparent'
                        }}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-3"
                              aria-current={location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS") ? 'page' : undefined}>
                          {(location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS")) && (
                            <div className="absolute left-0 top-1/2 -translate-y-1/2 h-8 w-1 rounded-r-full glow-blue"
                                 style={{background: 'var(--orbital-blue)'}}
                                 aria-hidden="true" />
                          )}
                          <item.icon className="w-5 h-5" style={{color: (location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS")) ? 'var(--orbital-blue)' : 'var(--orbital-text-dim)'}}
                                     aria-hidden="true" />
                          <span className="font-medium text-sm" style={{color: (location.pathname === item.url || (item.url === createPageUrl("GuardianCodexLDS") && currentMainMenu === "GuardianCodexLDS")) ? 'var(--orbital-text)' : 'var(--orbital-text-dim)'}}>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarContent>
            </Sidebar>

            <AnimatePresence>
              {secondaryMenuItems && (
                <SecondarySidebar
                  menuItems={secondaryMenuItems}
                  title={sidebarTitle}
                />
              )}
            </AnimatePresence>

            <div className="flex-1 flex flex-col min-w-0">
              <main className="flex-1 overflow-auto" style={{background: 'var(--orbital-dark)'}}
                    role="main" aria-live="polite">
                <ErrorBoundary>
                  {children}
                </ErrorBoundary>
              </main>

              <footer className="h-8 flex items-center justify-between px-4 text-xs chrome-surface flex-shrink-0"
                      role="contentinfo">
                <div>
                  <span>Orbital Kernel: <span style={{color: 'var(--orbital-blue)'}}>ACTIVE</span> (v1.0, upgradeable)</span>
                </div>
                <div>
                  <span>Infinity Spine: <span style={{color: 'var(--orbital-blue)'}}>READY</span></span> • <span>Compliance: <span style={{color: 'var(--orbital-blue)'}}>ENABLED</span></span>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </SidebarProvider>
    </>
  );
}

