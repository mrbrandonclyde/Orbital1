import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Activity, Zap, Users, Globe, ShoppingCart, Shield, TrendingUp, Cpu, Filter, Pause, Play } from 'lucide-react';
import { SystemEvent } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const simulatedActivities = [
  { id: 'act_001', type: 'success', category: 'world_created', title: 'New World Created', message: 'ARIA successfully generated "Nebula Gardens".', user: 'ARIA (AI Agent)', created_date: new Date().toISOString() },
  { id: 'act_002', type: 'info', category: 'ai_deployed', title: 'AI Agent Deployed', message: 'NEXUS upgraded tactical analysis by 15%.', user: 'System', created_date: new Date(Date.now() - 300000).toISOString() },
  { id: 'act_003', type: 'success', category: 'market_trade', title: 'High-Value Trade', message: 'Parcel P001 sold for 2.4M ORB.', user: '0x742d35Cc...', created_date: new Date(Date.now() - 720000).toISOString() },
  { id: 'act_004', type: 'warning', category: 'security_scan', title: 'Security Alert', message: 'Unusual network activity mitigated.', user: 'Security System', created_date: new Date(Date.now() - 1080000).toISOString() },
  { id: 'act_005', type: 'info', category: 'nft_minted', title: 'NFT Collection Minted', message: '50 unique avatars minted.', user: 'Batch Processor', created_date: new Date(Date.now() - 1500000).toISOString() }
];

const activityTypes = {
  'world_created': { icon: Globe, color: '#00d4ff' },
  'ai_deployed': { icon: Users, color: '#8b5cf6' },
  'nft_minted': { icon: ShoppingCart, color: '#ec4899' },
  'security_scan': { icon: Shield, color: '#f59e0b' },
  'market_trade': { icon: TrendingUp, color: '#22c55e' },
  'system_upgrade': { icon: Cpu, color: '#06b6d4' },
  'user_login': { icon: Activity, color: '#a8a29e' },
};

const ActivityTimelineItem = ({ activity, isLast }) => {
  const { icon: ActivityIcon, color } = activityTypes[activity.category] || { icon: Activity, color: 'var(--orbital-text-dim)' };

  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: `${color}20`, border: `1px solid ${color}80` }}>
          <ActivityIcon className="w-4 h-4" style={{ color }} />
        </div>
        {!isLast && <div className="w-px flex-grow" style={{ background: `linear-gradient(to bottom, ${color}80, ${color}20)` }}></div>}
      </div>
      <div className="pb-8 flex-grow">
        <p className="text-sm font-semibold" style={{ color }}>{activity.title}</p>
        <p className="text-sm mb-2" style={{ color: 'var(--orbital-text)' }}>{activity.message}</p>
        <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
          <Clock className="w-3 h-3" />
          <span>{new Date(activity.created_date).toLocaleString()}</span>
          <span>• by {activity.user}</span>
        </div>
      </div>
    </div>
  );
};

export default function RecentActivity() {
  const [activities, setActivities] = useState([]);
  const [filter, setFilter] = useState('all');
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    const loadActivities = async () => {
      try {
        const systemEvents = await SystemEvent.list('-created_date', 10);
        const eventActivities = systemEvents.map(e => ({...e, category: 'system_upgrade', title: e.message, user: 'System'}));
        const combined = [...simulatedActivities, ...eventActivities];
        setActivities(combined.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
      } catch (error) {
        setActivities(simulatedActivities.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
      }
    };
    loadActivities();
  }, []);
  
  useEffect(() => {
    if (!isLive) return;
    const interval = setInterval(() => {
        if (Math.random() > 0.7) {
          const newActivity = { id: `act_${Date.now()}`, type: 'success', category: 'system_upgrade', title: 'System Enhancement', message: 'AI subsystem self-optimized.', user: 'Self-Healing Engine', created_date: new Date().toISOString() };
          setActivities(prev => [newActivity, ...prev].slice(0, 20));
        }
    }, 3000);
    return () => clearInterval(interval);
  }, [isLive]);

  const filteredActivities = activities.filter(a => filter === 'all' || a.category === filter);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">RECENT ACTIVITY</h1>
          <p style={{ color: 'var(--orbital-text-dim)' }}>Real-time activity stream with AI event classification</p>
        </div>
        <Button onClick={() => setIsLive(!isLive)} variant="outline" className="chrome-surface">
          {isLive ? <><Pause className="w-4 h-4 mr-2" /> Pause Stream</> : <><Play className="w-4 h-4 mr-2" /> Resume Stream</>}
        </Button>
      </div>

      <Card className="chrome-surface">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" style={{ color: 'var(--orbital-blue)' }} />
              Filter by Category
            </CardTitle>
             <Badge className={isLive ? 'bg-green-500' : 'bg-yellow-500'}>
              {isLive ? '🔴 LIVE' : '⏸ PAUSED'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant={filter === 'all' ? 'default' : 'outline'} onClick={() => setFilter('all')} className={filter==='all' ? 'glow-blue' : ''}>All</Button>
            {Object.entries(activityTypes).map(([key, {color}]) => (
              <Button key={key} size="sm" variant={filter === key ? 'default' : 'outline'} onClick={() => setFilter(key)} className={filter===key ? 'glow-blue' : ''}>
                {key.replace('_', ' ').toUpperCase()}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <AnimatePresence>
          {filteredActivities.map((activity, index) => (
            <motion.div
              key={activity.id}
              layout
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -50 }}
            >
              <ActivityTimelineItem activity={activity} isLast={index === filteredActivities.length - 1} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}