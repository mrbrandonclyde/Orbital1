
import React, { useState, useEffect } from 'react';
import { Eye, User, Coins, TrendingUp, BarChart3, PieChart, Filter, Download, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart as RechartsPieChart, Cell } from 'recharts';
import { Parcel } from '@/api/entities';

const COLORS = ['#00d4ff', '#8b5cf6', '#22c55e', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];

const OwnershipCard = ({ owner, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.1 }}
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl p-6 transition-all duration-300"
  >
    <div className="flex items-start justify-between mb-4">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold"
             style={{background: COLORS[index % COLORS.length] + '20', color: COLORS[index % COLORS.length]}}>
          #{index + 1}
        </div>
        <div>
          <h3 className="font-bold text-lg font-mono" style={{color: 'var(--orbital-text)'}}>
            {owner.wallet}
          </h3>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            Joined {owner.joinedDate}
          </p>
        </div>
      </div>
      <Badge style={{background: COLORS[index % COLORS.length] + '20', color: COLORS[index % COLORS.length]}}>
        Rank #{index + 1}
      </Badge>
    </div>

    <div className="grid grid-cols-3 gap-4 mb-4">
      <div className="text-center">
        <div className="text-2xl font-bold" style={{color: 'var(--orbital-blue)'}}>{owner.parcels}</div>
        <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Parcels</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold" style={{color: '#22c55e'}}>{owner.value}</div>
        <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Portfolio</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold" style={{color: '#f59e0b'}}>{owner.avgSize}</div>
        <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Avg Size</div>
      </div>
    </div>

    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Market Share</span>
        <span className="font-semibold" style={{color: 'var(--orbital-text)'}}>{owner.marketShare}%</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2">
        <div 
          className="h-2 rounded-full transition-all duration-1000"
          style={{
            width: `${owner.marketShare}%`,
            background: `linear-gradient(90deg, ${COLORS[index % COLORS.length]}, ${COLORS[(index + 1) % COLORS.length]})`
          }}
        />
      </div>
    </div>

    <div className="flex gap-2 mt-4 flex-wrap">
      {owner.zones?.map(zone => (
        <Badge key={zone} variant="outline" className="text-xs" 
               style={{borderColor: 'rgba(0, 212, 255, 0.3)', color: 'var(--orbital-blue)'}}>
          {zone}
        </Badge>
      ))}
    </div>
  </motion.div>
);

const StatsCard = ({ title, value, change, icon: Icon, color }) => (
  <Card className="chrome-surface">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</p>
          <p className="text-3xl font-bold" style={{color: 'var(--orbital-text)'}}>{value}</p>
          {change && (
            <p className="text-sm mt-1" style={{color: change.startsWith('+') ? '#22c55e' : '#ef4444'}}>
              {change} from last week
            </p>
          )}
        </div>
        <Icon className="w-8 h-8" style={{color: color}} />
      </div>
    </CardContent>
  </Card>
);

const DistributionChart = ({ data }) => (
  <Card className="chrome-surface">
    <CardHeader>
      <CardTitle className="flex items-center gap-2">
        <PieChart className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
        OWNERSHIP DISTRIBUTION
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <RechartsPieChart data={data} cx="50%" cy="50%" outerRadius={80}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
            <Tooltip 
              contentStyle={{
                background: "rgba(0,0,0,0.8)",
                borderColor: "var(--orbital-blue)",
                color: "var(--orbital-text)"
              }}
            />
          </RechartsPieChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-2 gap-2 mt-4">
        {data.slice(0, 6).map((entry, index) => (
          <div key={index} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{background: COLORS[index % COLORS.length]}} />
            <span className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>{entry.name}</span>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const ActivityChart = ({ data }) => (
  <Card className="chrome-surface">
    <CardHeader>
      <CardTitle className="flex items-center gap-2">
        <BarChart3 className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
        OWNERSHIP ACTIVITY
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="name" axisLine={false} tickLine={false} 
                   tick={{ fill: 'var(--orbital-text-dim)', fontSize: 12 }} />
            <YAxis axisLine={false} tickLine={false} 
                   tick={{ fill: 'var(--orbital-text-dim)', fontSize: 12 }} />
            <Tooltip 
              contentStyle={{
                background: "rgba(0,0,0,0.8)",
                borderColor: "var(--orbital-blue)",
                color: "var(--orbital-text)"
              }}
            />
            <Bar dataKey="transfers" fill="var(--orbital-blue)" radius={[4, 4, 0, 0]} />
            <Bar dataKey="acquisitions" fill="#22c55e" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </CardContent>
  </Card>
);

export default function OwnershipTracker() {
  const [owners, setOwners] = useState([]);
  const [sortBy, setSortBy] = useState('parcels');
  const [filterBy, setFilterBy] = useState('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const mockOwners = [
    { 
      wallet: '0xABC...123', 
      parcels: 47, 
      value: '2.4M ORB', 
      marketShare: 12.5,
      avgSize: '2.1K',
      joinedDate: '2024-01-15',
      zones: ['residential', 'commercial']
    },
    { 
      wallet: '0xDEF...456', 
      parcels: 23, 
      value: '1.2M ORB', 
      marketShare: 8.3,
      avgSize: '1.8K',
      joinedDate: '2024-02-20',
      zones: ['industrial', 'mixed_use']
    },
    { 
      wallet: '0xGHI...789', 
      parcels: 15, 
      value: '890K ORB', 
      marketShare: 5.7,
      avgSize: '2.5K',
      joinedDate: '2024-03-10',
      zones: ['recreational', 'protected']
    },
    { 
      wallet: '0xJKL...012', 
      parcels: 8, 
      value: '450K ORB', 
      marketShare: 3.2,
      avgSize: '1.9K',
      joinedDate: '2024-04-05',
      zones: ['residential']
    },
    { 
      wallet: '0xMNO...345', 
      parcels: 3, 
      value: '180K ORB', 
      marketShare: 1.8,
      avgSize: '2.2K',
      joinedDate: '2024-04-25',
      zones: ['commercial']
    },
  ];

  const distributionData = [
    { name: 'Top 1%', value: 45 },
    { name: 'Top 5%', value: 25 },
    { name: 'Top 10%', value: 15 },
    { name: 'Others', value: 15 }
  ];

  const activityData = [
    { name: 'Jan', transfers: 12, acquisitions: 8 },
    { name: 'Feb', transfers: 19, acquisitions: 15 },
    { name: 'Mar', transfers: 15, acquisitions: 12 },
    { name: 'Apr', transfers: 25, acquisitions: 18 },
    { name: 'May', transfers: 22, acquisitions: 16 },
    { name: 'Jun', transfers: 30, acquisitions: 24 }
  ];

  useEffect(() => {
    setOwners(mockOwners);
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setOwners([...mockOwners]);
      setIsRefreshing(false);
    }, 1000);
  };

  const sortedOwners = [...owners].sort((a, b) => {
    switch (sortBy) {
      case 'parcels': return b.parcels - a.parcels;
      case 'value': return parseFloat(b.value.replace(/[^\d.]/g, '')) - parseFloat(a.value.replace(/[^\d.]/g, ''));
      case 'marketShare': return b.marketShare - a.marketShare;
      default: return 0;
    }
  });

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-8"
      >
        <div>
          <h1 className="text-4xl font-bold">OWNERSHIP TRACKER</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Real-time parcel ownership analytics and wealth distribution</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="chrome-surface"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button className="glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatsCard title="Total Owners" value="2,847" change="+12%" icon={User} color="var(--orbital-blue)" />
        <StatsCard title="Total Parcels" value="15,432" change="+8%" icon={BarChart3} color="#22c55e" />
        <StatsCard title="Total Value" value="42.7M ORB" change="+15%" icon={Coins} color="#f59e0b" />
        <StatsCard title="Avg Portfolio" value="5.4 Parcels" change="+3%" icon={TrendingUp} color="#8b5cf6" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <DistributionChart data={distributionData} />
        <ActivityChart data={activityData} />
      </div>

      {/* Filters and Sort */}
      <Card className="chrome-surface mb-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" style={{color: 'var(--orbital-text-dim)'}} />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40 chrome-surface">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parcels">Sort by Parcels</SelectItem>
                    <SelectItem value="value">Sort by Value</SelectItem>
                    <SelectItem value="marketShare">Sort by Market Share</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Select value={filterBy} onValueChange={setFilterBy}>
                <SelectTrigger className="w-40 chrome-surface">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Owners</SelectItem>
                  <SelectItem value="whales">Whales (10+ parcels)</SelectItem>
                  <SelectItem value="dolphins">Dolphins (3-9 parcels)</SelectItem>
                  <SelectItem value="minnows">Minnows (1-2 parcels)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Badge className="chrome-surface" style={{color: 'var(--orbital-blue)'}}>
              {sortedOwners.length} Owners Tracked
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Owners Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        <AnimatePresence>
          {sortedOwners.map((owner, index) => (
            <OwnershipCard key={owner.wallet} owner={owner} index={index} />
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
