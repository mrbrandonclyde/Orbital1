import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Globe, Users, Shield, TrendingUp, Cpu, Brain, CheckCircle, Loader2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const QuickActionCard = ({ title, description, icon: Icon, color, onClick }) => {
  const [status, setStatus] = useState('idle'); // idle, executing, success, error

  const handleClick = () => {
    if (status !== 'idle') return;
    setStatus('executing');
    onClick()
      .then(() => {
        setStatus('success');
        setTimeout(() => setStatus('idle'), 2000);
      })
      .catch(() => {
        setStatus('error');
        setTimeout(() => setStatus('idle'), 2000);
      });
  };

  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02, boxShadow: `0 0 30px ${color}50` }}
      onClick={handleClick}
      className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 relative overflow-hidden"
    >
      <AnimatePresence>
        {status !== 'idle' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center z-10"
            style={{ background: 'rgba(10, 10, 10, 0.8)' }}
          >
            {status === 'executing' && <Loader2 className="w-10 h-10 animate-spin" style={{ color }} />}
            {status === 'success' && <CheckCircle className="w-12 h-12" style={{ color: '#22c55e' }} />}
            {status === 'error' && <XCircle className="w-12 h-12" style={{ color: '#ef4444' }} />}
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${color}20`, border: `2px solid ${color}50` }}>
          <Icon className="w-6 h-6" style={{ color }} />
        </div>
        <Zap className="w-5 h-5" style={{ color: 'var(--orbital-blue)' }} />
      </div>
      
      <h3 className="font-bold text-lg mb-2" style={{ color: 'var(--orbital-text)' }}>{title}</h3>
      <p className="text-sm" style={{ color: 'var(--orbital-text-dim)' }}>{description}</p>
    </motion.div>
  );
};

export default function QuickActions() {
  const simulateAction = (success = true) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (success) resolve();
        else reject();
      }, 2000);
    });
  };
  
  const actionCategories = {
    "CREATION & DEPLOYMENT": [
      { id: 'create_world', title: 'Create New World', description: 'Generate a quantum-seeded world', icon: Globe, color: '#00d4ff', action: () => simulateAction() },
      { id: 'deploy_ai', title: 'Deploy AI Agent', description: 'Launch a new AI avatar', icon: Users, color: '#8b5cf6', action: () => simulateAction() },
    ],
    "SYSTEM & SECURITY": [
      { id: 'security_scan', title: 'Full Security Scan', description: 'Quantum-grade security analysis', icon: Shield, color: '#22c55e', action: () => simulateAction() },
      { id: 'system_optimize', title: 'System Optimization', description: 'Auto-optimize all subsystems', icon: Cpu, color: '#06b6d4', action: () => simulateAction() },
    ],
    "AI & ANALYSIS": [
      { id: 'market_analysis', title: 'Market Analysis', description: 'AI-powered market predictions', icon: TrendingUp, color: '#f59e0b', action: () => simulateAction() },
      { id: 'memory_defrag', title: 'Memory Defragmentation', description: 'Reorganize AI memory matrices', icon: Brain, color: '#ec4899', action: () => simulateAction(false) },
    ]
  };

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold" style={{ color: 'var(--orbital-text)' }}>QUICK ACTIONS</h1>
          <p style={{ color: 'var(--orbital-text-dim)' }}>Light-speed platform operations with AI-enhanced capabilities</p>
        </div>
        <Button className="glow-blue" style={{ background: 'var(--orbital-blue)', color: '#000' }}>
          <Zap className="w-5 h-5 mr-2" />
          EXECUTION MODE
        </Button>
      </div>

      <div className="space-y-12">
        {Object.entries(actionCategories).map(([category, actions]) => (
          <div key={category}>
            <h2 className="text-2xl font-bold mb-4" style={{borderBottom: '2px solid var(--orbital-blue-dim)', paddingBottom: '0.5rem'}}>
              {category}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {actions.map((action, index) => (
                <motion.div
                  key={action.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <QuickActionCard {...action} />
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}