import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Filter, Search, X } from 'lucide-react';
import { NFT } from '@/api/entities';
import { NFTCard } from '../components/nft/NFTCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function MyCollection() {
  const [nfts, setNfts] = useState([]);
  const [filteredNfts, setFilteredNfts] = useState([]);
  const [filters, setFilters] = useState({ search: '', type: 'all', sort: 'newest' });

  useEffect(() => {
    const loadNfts = async () => {
      const data = await NFT.list();
      setNfts(data);
      setFilteredNfts(data);
    };
    loadNfts();
  }, []);

  useEffect(() => {
    let result = nfts;
    if (filters.search) {
      result = result.filter(nft => nft.name.toLowerCase().includes(filters.search.toLowerCase()));
    }
    if (filters.type !== 'all') {
      result = result.filter(nft => nft.asset_type === filters.type);
    }
    // Add sorting logic here
    setFilteredNfts(result);
  }, [filters, nfts]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">MY COLLECTION</h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>Browse, manage, and admire your owned digital assets</p>
      </div>

      <Card className="chrome-surface p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input 
              placeholder="Search my assets..." 
              className="pl-9 chrome-surface"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
            />
          </div>
          <Select value={filters.type} onValueChange={(v) => handleFilterChange('type', v)}>
            <SelectTrigger className="chrome-surface"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="avatar">Avatar</SelectItem>
              <SelectItem value="parcel">Parcel</SelectItem>
              <SelectItem value="wearable">Wearable</SelectItem>
              <SelectItem value="art">Art</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.sort} onValueChange={(v) => handleFilterChange('sort', v)}>
            <SelectTrigger className="chrome-surface"><SelectValue placeholder="Sort By" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
              <SelectItem value="name_asc">Name (A-Z)</SelectItem>
              <SelectItem value="name_desc">Name (Z-A)</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline"
            className="chrome-surface"
            onClick={() => setFilters({ search: '', type: 'all', sort: 'newest' })}
          >
            <X className="w-4 h-4 mr-2" /> Reset Filters
          </Button>
        </div>
      </Card>

      <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {filteredNfts.map(nft => (
            <NFTCard key={nft.id} nft={nft} />
          ))}
        </AnimatePresence>
      </motion.div>
      {filteredNfts.length === 0 && (
        <div className="col-span-full chrome-surface rounded-2xl p-12 text-center mt-8">
            <Star className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
            <h3 className="font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Assets Found</h3>
            <p style={{color: 'var(--orbital-text-dim)'}}>Your collection is empty or your filters returned no results.</p>
        </div>
      )}
    </div>
  );
}