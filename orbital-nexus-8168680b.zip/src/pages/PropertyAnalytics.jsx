import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, BarChart3, MapPin, DollarSign, PieChart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, AreaChart, Area, Bar, ComposedChart, Tooltip, Legend, XAxis, YAxis, CartesianGrid, Pie, Cell } from 'recharts';

const data = [
  { name: 'Cycle 1', value: 1200 },
  { name: 'Cycle 2', value: 1500 },
  { name: 'Cycle 3', value: 1400 },
  { name: 'Cycle 4', value: 1800 },
  { name: 'Cycle 5', value: 2100 },
  { name: 'Cycle 6', value: 2500 },
];

const pieData = [
    { name: 'Residential', value: 400 },
    { name: 'Commercial', value: 300 },
    { name: 'Industrial', value: 200 },
    { name: 'Recreational', value: 100 },
];
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function PropertyAnalytics() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">PROPERTY ANALYTICS</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>AI-driven market insights and valuation trends.</p>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card className="chrome-surface"><CardHeader><CardTitle>Avg. Parcel Value</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-green-400">1,850 ORB</p></CardContent></Card>
          <Card className="chrome-surface"><CardHeader><CardTitle>Total Market Cap</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-green-400">24.7B ORB</p></CardContent></Card>
          <Card className="chrome-surface"><CardHeader><CardTitle>Hotspot Growth</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-green-400">+12%</p></CardContent></Card>
          <Card className="chrome-surface"><CardHeader><CardTitle>Avg. ROI</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold text-green-400">8.2% / cycle</p></CardContent></Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="chrome-surface">
            <CardHeader><CardTitle>Overall Market Value Trend</CardTitle></CardHeader>
            <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                        <defs>
                            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <XAxis dataKey="name" stroke="var(--orbital-text-dim)" />
                        <YAxis stroke="var(--orbital-text-dim)" />
                        <Tooltip contentStyle={{ background: "rgba(0,0,0,0.8)", borderColor: "var(--orbital-blue)" }}/>
                        <Area type="monotone" dataKey="value" stroke="#22c55e" fill="url(#colorValue)" />
                    </AreaChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
        <Card className="chrome-surface">
            <CardHeader><CardTitle>Zoning Distribution</CardTitle></CardHeader>
            <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie data={pieData} cx="50%" cy="50%" labelLine={false} outerRadius={100} fill="#8884d8" dataKey="value" nameKey="name" label>
                            {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                        </Pie>
                         <Tooltip contentStyle={{ background: "rgba(0,0,0,0.8)", borderColor: "var(--orbital-blue)" }}/>
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}