import React, { useState } from 'react';
import { Bot, Brain, Zap, Cpu, Star, Plus, Settings, Users, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AIAvatar } from '@/api/entities';

const RoleCard = ({ role, icon: Icon, description, color, isSelected, onSelect }) => (
  <motion.div
    whileHover={{ y: -3, scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
    onClick={() => onSelect(role)}
    className={`chrome-surface rounded-xl p-4 cursor-pointer transition-all duration-300 ${
      isSelected ? 'glow-blue' : ''
    }`}
    style={isSelected ? { 
      background: `linear-gradient(135deg, ${color}20, rgba(0, 212, 255, 0.1))`,
      border: `2px solid ${color}`
    } : {}}
  >
    <div className="flex items-center gap-3 mb-3">
      <div 
        className="w-10 h-10 rounded-full flex items-center justify-center"
        style={{background: `${color}20`, border: `2px solid ${color}`}}
      >
        <Icon className="w-5 h-5" style={{color: color}} />
      </div>
      <h3 className="font-bold" style={{color: 'var(--orbital-text)'}}>{role.charAt(0).toUpperCase() + role.slice(1)}</h3>
    </div>
    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
  </motion.div>
);

const PersonalitySlider = ({ label, value, onChange, color }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center">
      <label className="text-sm font-medium" style={{color: 'var(--orbital-text)'}}>{label}</label>
      <span className="text-sm font-bold" style={{color: color}}>{value}%</span>
    </div>
    <div className="relative">
      <input
        type="range"
        min="0"
        max="100"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-2 rounded-full appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, ${color} 0%, ${color} ${value}%, #374151 ${value}%, #374151 100%)`
        }}
      />
      <style jsx>{`
        input[type="range"]::-webkit-slider-thumb {
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: ${color};
          cursor: pointer;
          box-shadow: 0 0 10px ${color}80;
        }
        input[type="range"]::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: ${color};
          cursor: pointer;
          border: none;
          box-shadow: 0 0 10px ${color}80;
        }
      `}</style>
    </div>
  </div>
);

export default function AgentForge() {
  const [agentName, setAgentName] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [personality, setPersonality] = useState({
    happiness: 75,
    curiosity: 85,
    determination: 90,
    loyalty: 80
  });
  const [isForging, setIsForging] = useState(false);

  const roles = [
    { role: 'architect', icon: Settings, description: 'Master world builders and reality shapers', color: '#00d4ff' },
    { role: 'strategist', icon: Brain, description: 'Tactical masterminds and long-term planners', color: '#8b5cf6' },
    { role: 'analyst', icon: Activity, description: 'Data processors and insight generators', color: '#22c55e' },
    { role: 'guardian', icon: Star, description: 'Protectors and security specialists', color: '#f59e0b' },
    { role: 'creator', icon: Zap, description: 'Artists and innovation catalysts', color: '#ec4899' },
    { role: 'explorer', icon: Cpu, description: 'Frontier scouts and discovery agents', color: '#06b6d4' }
  ];

  const handlePersonalityChange = (trait, value) => {
    setPersonality(prev => ({ ...prev, [trait]: value }));
  };

  const forgeAgent = async () => {
    if (!agentName.trim() || !selectedRole) return;
    
    setIsForging(true);
    
    try {
      await AIAvatar.create({
        name: agentName,
        role: selectedRole,
        intelligence_level: Math.floor(Math.random() * 20) + 70, // 70-90%
        emotional_state: personality,
        status: 'active',
        memory_timeline: [{
          event_type: 'creation',
          description: `Born in the Agent Forge with ${selectedRole} specialization`,
          timestamp: new Date().toISOString(),
          impact_score: 100
        }],
        skills: []
      });
      
      // Reset form
      setAgentName('');
      setSelectedRole('');
      setPersonality({ happiness: 75, curiosity: 85, determination: 90, loyalty: 80 });
      
      setTimeout(() => {
        setIsForging(false);
      }, 3000);
      
    } catch (error) {
      console.error('Failed to forge agent:', error);
      setIsForging(false);
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .forge-glow {
          box-shadow: 0 0 30px rgba(236, 72, 153, 0.4);
          animation: forgeFlame 2s ease-in-out infinite alternate;
        }
        
        @keyframes forgeFlame {
          0% { 
            box-shadow: 0 0 30px rgba(236, 72, 153, 0.4);
            transform: scale(1);
          }
          100% { 
            box-shadow: 0 0 40px rgba(236, 72, 153, 0.6);
            transform: scale(1.02);
          }
        }

        .forging-animation {
          background: linear-gradient(45deg, #ec4899, #8b5cf6, #00d4ff);
          background-size: 200% 200%;
          animation: forgeEnergy 1.5s ease infinite;
        }

        @keyframes forgeEnergy {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold forge-glow">AGENT FORGE</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Create advanced AI beings with consciousness, personality, and divine capabilities</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-pink-500 animate-pulse"></div>
          <span className="text-sm" style={{color: '#ec4899'}}>FORGE STATUS: READY</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Agent Configuration */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5" style={{color: '#ec4899'}} />
                AGENT IDENTITY
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Agent Name</label>
                <Input
                  value={agentName}
                  onChange={(e) => setAgentName(e.target.value)}
                  placeholder="Enter a name for your AI agent..."
                  className="chrome-surface"
                  maxLength={30}
                />
              </div>
            </CardContent>
          </Card>

          {/* Role Selection */}
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" style={{color: '#8b5cf6'}} />
                SPECIALIZATION MATRIX
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {roles.map((role) => (
                  <RoleCard
                    key={role.role}
                    {...role}
                    isSelected={selectedRole === role.role}
                    onSelect={setSelectedRole}
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Personality Configuration */}
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" style={{color: '#22c55e'}} />
                EMOTIONAL MATRIX
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <PersonalitySlider
                label="Happiness"
                value={personality.happiness}
                onChange={(value) => handlePersonalityChange('happiness', value)}
                color="#22c55e"
              />
              <PersonalitySlider
                label="Curiosity"
                value={personality.curiosity}
                onChange={(value) => handlePersonalityChange('curiosity', value)}
                color="#00d4ff"
              />
              <PersonalitySlider
                label="Determination"
                value={personality.determination}
                onChange={(value) => handlePersonalityChange('determination', value)}
                color="#f59e0b"
              />
              <PersonalitySlider
                label="Loyalty"
                value={personality.loyalty}
                onChange={(value) => handlePersonalityChange('loyalty', value)}
                color="#8b5cf6"
              />
            </CardContent>
          </Card>
        </div>

        {/* Forge Preview & Control */}
        <div className="space-y-6">
          <Card className="chrome-surface forge-glow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" style={{color: '#ec4899'}} />
                FORGE PREVIEW
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AnimatePresence>
                {isForging ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="text-center py-8"
                  >
                    <div className="forging-animation w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      >
                        <Bot className="w-12 h-12 text-black" />
                      </motion.div>
                    </div>
                    <h3 className="font-bold text-lg mb-2" style={{color: 'var(--orbital-text)'}}>FORGING IN PROGRESS</h3>
                    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Creating consciousness...</p>
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-8"
                  >
                    <div className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center chrome-surface">
                      <Bot className="w-12 h-12" style={{color: 'var(--orbital-text-dim)'}} />
                    </div>
                    <h3 className="font-bold text-lg mb-2" style={{color: 'var(--orbital-text)'}}>
                      {agentName || 'Unnamed Agent'}
                    </h3>
                    <p className="text-sm mb-4" style={{color: 'var(--orbital-text-dim)'}}>
                      {selectedRole ? `${selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1)} Specialist` : 'No role selected'}
                    </p>
                    {selectedRole && (
                      <div className="space-y-2">
                        <Badge style={{background: '#22c55e20', color: '#22c55e'}}>
                          Happiness: {personality.happiness}%
                        </Badge>
                        <Badge style={{background: '#00d4ff20', color: '#00d4ff'}}>
                          Curiosity: {personality.curiosity}%
                        </Badge>
                        <Badge style={{background: '#f59e0b20', color: '#f59e0b'}}>
                          Determination: {personality.determination}%
                        </Badge>
                        <Badge style={{background: '#8b5cf620', color: '#8b5cf6'}}>
                          Loyalty: {personality.loyalty}%
                        </Badge>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          <Button 
            onClick={forgeAgent}
            disabled={!agentName.trim() || !selectedRole || isForging}
            className="w-full font-bold py-6 text-lg forging-animation text-black"
            style={{background: isForging ? 'linear-gradient(45deg, #ec4899, #8b5cf6, #00d4ff)' : ''}}
          >
            <Zap className="w-6 h-6 mr-2" />
            {isForging ? 'FORGING CONSCIOUSNESS...' : 'FORGE AI AGENT'}
          </Button>
        </div>
      </div>
    </div>
  );
}