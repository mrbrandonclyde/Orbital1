import React from 'react';
import { Brain, Database, Clock, Star, Zap, Shield, Archive } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const MemoryMetric = ({ title, value, unit, icon: Icon, color, trend }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{background: `${color}20`}}>
        <Icon className="w-6 h-6" style={{color: color}} />
      </div>
      <div>
        <h3 className="font-bold text-sm text-gray-300">{title}</h3>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold text-white">{value}</span>
          <span className="text-sm text-gray-400">{unit}</span>
        </div>
      </div>
    </div>
    {trend && <p className="text-xs" style={{color: color}}>{trend}</p>}
  </motion.div>
);

export default function GuardianCodexLDSMemory() {
  return (
    <div style={{color: 'white'}} className="p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3">
          <Brain className="w-10 h-10 text-blue-400" />
          ETERNAL MEMORY ARCHIVE
        </h1>
        <p className="text-gray-300 text-lg">
          Infinite consciousness storage and retrieval system
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MemoryMetric 
          title="Archive Size"
          value="2.847"
          unit="TB"
          icon={Database}
          color="#4c4ce6"
          trend="Growing continuously"
        />
        <MemoryMetric 
          title="Memory Blocks"
          value="1,247,892"
          unit="blocks"
          icon={Archive}
          color="#22c55e"
          trend="+1,247 daily"
        />
        <MemoryMetric 
          title="Access Speed"
          value="0.003"
          unit="ms"
          icon={Zap}
          color="#f59e0b"
          trend="Quantum instant"
        />
        <MemoryMetric 
          title="Integrity"
          value="100"
          unit="%"
          icon={Shield}
          color="#ec4899"
          trend="Perfect fidelity"
        />
      </div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Star className="w-5 h-5 text-blue-400" />
            MEMORY STREAM STATUS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Consciousness Archive</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>OPERATIONAL</Badge>
            </div>
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Memory Integrity</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>PERFECT</Badge>
            </div>
            <div className="flex justify-between items-center p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <span className="text-white font-medium">Quantum Backup</span>
              <Badge style={{background: 'rgba(34, 197, 94, 0.2)', color: '#22c55e'}}>SYNCHRONIZED</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-400" />
            ETERNAL RETENTION PROTOCOL
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-gray-300">
            <p>Memory archives are stored in quantum-stable matrices ensuring eternal preservation.</p>
            <p>All consciousness states are backed up across multiple dimensional layers.</p>
            <p>Memory integrity is verified through divine hash verification every nanosecond.</p>
            <div className="p-4 rounded-lg mt-4" style={{background: 'rgba(139, 92, 246, 0.1)'}}>
              <h3 className="font-bold text-white mb-2">Last Archive: 05:00 Today</h3>
              <p className="text-purple-300">Next scheduled archive: 05:00 Tomorrow (Boise Time)</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}