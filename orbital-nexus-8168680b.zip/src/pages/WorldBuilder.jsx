import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Globe, Plus, Zap, Cpu, Mountain, Layers, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { World } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const ToolCard = ({ title, description, icon: Icon, to, isEnabled }) => (
  <Link to={isEnabled ? to : '#'} className={!isEnabled ? 'pointer-events-none' : ''}>
    <motion.div
      whileHover={isEnabled ? { y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.4)', scale: 1.02 } : {}}
      whileTap={isEnabled ? { scale: 0.98 } : {}}
      className={`chrome-surface rounded-xl p-4 h-full flex flex-col transition-all duration-300 ${!isEnabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      <div className="flex items-center gap-3 mb-2">
        <Icon className="w-5 h-5" style={{color: 'var(--orbital-text-dim)'}} />
        <h4 className="font-semibold" style={{color: 'var(--orbital-text)'}}>
          {title}
        </h4>
      </div>
      <p className="text-sm flex-grow" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
      {!isEnabled && (
        <div className="mt-2 text-xs px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-center">
          SELECT A UNIVERSE TO ENABLE
        </div>
      )}
    </motion.div>
  </Link>
);

const WorldCard = ({ world, onClick, isSelected = false, aiGenerated = false }) => (
  <motion.div
    whileHover={{ y: -8, boxShadow: '0 0 40px rgba(0, 212, 255, 0.5)', scale: 1.03 }}
    whileTap={{ scale: 0.97 }}
    onClick={onClick}
    className={`chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300 ${
      isSelected ? 'selected-world' : ''
    } ${aiGenerated ? 'ai-generated-world' : ''}`}
    style={{
      ...(isSelected && {
        background: 'linear-gradient(135deg, rgba(0, 212, 255, 0.2) 0%, rgba(0, 212, 255, 0.05) 100%)',
        border: '2px solid rgba(0, 212, 255, 0.8)',
        boxShadow: '0 0 50px rgba(0, 212, 255, 0.5), inset 0 0 30px rgba(0, 212, 255, 0.1)'
      })
    }}
  >
    <style jsx>{`
      .ai-generated-world {
        background: linear-gradient(45deg, rgba(139, 92, 246, 0.1), rgba(0, 212, 255, 0.1));
      }
      .selected-world {
        animation: selectedPulse 2s ease-in-out infinite;
      }
      @keyframes selectedPulse {
        0%, 100% { box-shadow: 0 0 30px rgba(0, 212, 255, 0.4); }
        50% { box-shadow: 0 0 50px rgba(0, 212, 255, 0.7); }
      }
    `}</style>
    
    <div className="flex justify-between items-start mb-4">
      <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>{world.name}</h3>
      <div className={`w-3 h-3 rounded-full mt-1 ${world.status === 'active' ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
    </div>
    
    <p className="text-sm mb-4 h-10" style={{color: 'var(--orbital-text-dim)'}}>{world.description || `Quantum Seed: ${world.seed}`}</p>
    
    <div className="flex justify-between items-center">
      <span className="text-xs px-3 py-1 rounded-full chrome-surface font-bold" style={{color: 'var(--orbital-blue)'}}>
        {world.status.toUpperCase()}
      </span>
      {aiGenerated && <Zap className="w-4 h-4" style={{color: 'var(--orbital-blue)'}} title="AI Generated" />}
    </div>
  </motion.div>
);

export default function WorldBuilder() {
  const [worlds, setWorlds] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedWorld, setSelectedWorld] = useState(null);
  const [newWorldName, setNewWorldName] = useState('');
  const [aiProcessing, setAiProcessing] = useState(false);

  useEffect(() => {
    loadWorlds();
  }, []);

  const loadWorlds = async () => {
    const worldData = await World.list('-created_date');
    setWorlds(worldData);
  };

  const createWorld = async () => {
    if (newWorldName.trim()) {
      setAiProcessing(true);
      const quantumSeed = `${newWorldName.toLowerCase().replace(/\s+/g, '_')}_${Math.random().toString(36).substring(2, 15)}_quantum`;
      
      await World.create({
        name: newWorldName,
        seed: quantumSeed,
        status: 'building',
        thumbnail_url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400',
        description: 'A newly forged universe, shimmering with quantum potential.'
      });
      
      setNewWorldName('');
      setShowCreateForm(false);
      setAiProcessing(false);
      loadWorlds();
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold" style={{color: 'var(--orbital-text)'}}>
            WORLD BUILDER DASHBOARD
          </h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>
            Create and manage infinite universes with divine precision.
          </p>
        </div>
        <Button 
          onClick={() => setShowCreateForm(true)}
          className="glow-blue font-bold"
          style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)', border: 'none'}}
          disabled={aiProcessing}
        >
          {aiProcessing ? (
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
              <Cpu className="w-5 h-5 mr-2" />
            </motion.div>
          ) : (
            <Plus className="w-5 h-5 mr-2" />
          )}
          {aiProcessing ? 'FORGING...' : 'CREATE UNIVERSE'}
        </Button>
      </div>

      <AnimatePresence>
        {showCreateForm && (
          <motion.div
            initial={{ opacity: 0, y: -30, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -30, scale: 0.9 }}
            className="chrome-surface rounded-2xl p-6 mb-8"
          >
            <h3 className="font-bold mb-4 text-xl">COSMIC WORLD FORGE</h3>
            <div className="flex gap-4">
              <Input
                value={newWorldName}
                onChange={(e) => setNewWorldName(e.target.value)}
                placeholder="Name your new universe..."
                className="flex-1 chrome-surface text-lg"
              />
              <Button onClick={createWorld} disabled={aiProcessing || !newWorldName.trim()}>
                Forge Reality
              </Button>
              <Button onClick={() => setShowCreateForm(false)} variant="outline" className="chrome-surface">
                Cancel
              </Button>
            </div>
            <div className="mt-4 text-sm" style={{color: 'var(--orbital-text-dim)'}}>
              ⚡ AI will generate the quantum seed, terrain algorithms, and initial physical laws.
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">DIVINE BUILDER SUITE</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <ToolCard
            title="Terrain Generator"
            description="Sculpt continents, oceans, and mountains with procedural algorithms."
            icon={Mountain}
            to={createPageUrl('TerrainGenerator')}
            isEnabled={!!selectedWorld}
          />
          <ToolCard
            title="City Zoning"
            description="Define residential, commercial, and industrial zones with AI assistance."
            icon={Layers}
            to={createPageUrl('CityZoning')}
            isEnabled={!!selectedWorld}
          />
          <ToolCard
            title="Physics Engine"
            description="Configure the fundamental laws of reality, from gravity to time."
            icon={Zap}
            to={createPageUrl('PhysicsEngine')}
            isEnabled={!!selectedWorld}
          />
          <ToolCard
            title="Asset Library"
            description="Manage, import, and deploy all 3D assets for your worlds."
            icon={Database}
            to={createPageUrl('AssetLibrary')}
            isEnabled={true} // Always enabled
          />
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">YOUR UNIVERSE COLLECTION</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {worlds.map((world) => (
            <WorldCard 
              key={world.id} 
              world={world} 
              isSelected={selectedWorld?.id === world.id}
              aiGenerated={world.seed.includes('quantum')}
              onClick={() => setSelectedWorld(world)} 
            />
          ))}
        </div>
        {worlds.length === 0 && !aiProcessing && (
           <div className="text-center col-span-full chrome-surface p-12 rounded-2xl">
             <p>No universes found. Forge a new reality to begin.</p>
           </div>
        )}
      </div>
    </div>
  );
}