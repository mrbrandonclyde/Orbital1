
import React, { useState, useEffect } from 'react';
import { Search, Filter, Map, Navigation, Eye, MapPin, Layers, Hash, Calendar, User, Coins } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Parcel } from '@/api/entities';

const SearchFilters = ({ filters, onFilterChange }) => (
  <Card className="chrome-surface mb-6">
    <CardHeader>
      <CardTitle className="flex items-center gap-2">
        <Filter className="w-5 h-5" style={{color: 'var(--orbital-blue)'}} />
        ADVANCED SEARCH FILTERS
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="text-sm font-medium mb-2 block" style={{color: 'var(--orbital-text-dim)'}}>
            Zoning Type
          </label>
          <Select value={filters.zoning} onValueChange={(value) => onFilterChange('zoning', value)}>
            <SelectTrigger className="chrome-surface">
              <SelectValue placeholder="All Zones" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Zones</SelectItem>
              <SelectItem value="residential">Residential</SelectItem>
              <SelectItem value="commercial">Commercial</SelectItem>
              <SelectItem value="industrial">Industrial</SelectItem>
              <SelectItem value="recreational">Recreational</SelectItem>
              <SelectItem value="protected">Protected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="text-sm font-medium mb-2 block" style={{color: 'var(--orbital-text-dim)'}}>
            Size Range
          </label>
          <Select value={filters.size} onValueChange={(value) => onFilterChange('size', value)}>
            <SelectTrigger className="chrome-surface">
              <SelectValue placeholder="Any Size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any Size</SelectItem>
              <SelectItem value="small">Small (&lt; 1000 units)</SelectItem>
              <SelectItem value="medium">Medium (1000-5000)</SelectItem>
              <SelectItem value="large">Large (&gt; 5000 units)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="text-sm font-medium mb-2 block" style={{color: 'var(--orbital-text-dim)'}}>
            Deed Status
          </label>
          <Select value={filters.status} onValueChange={(value) => onFilterChange('status', value)}>
            <SelectTrigger className="chrome-surface">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="REGISTERED">Registered</SelectItem>
              <SelectItem value="PENDING_TRANSFER">Pending Transfer</SelectItem>
              <SelectItem value="ARCHIVED">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="text-sm font-medium mb-2 block" style={{color: 'var(--orbital-text-dim)'}}>
            World
          </label>
          <Select value={filters.world} onValueChange={(value) => onFilterChange('world', value)}>
            <SelectTrigger className="chrome-surface">
              <SelectValue placeholder="All Worlds" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Worlds</SelectItem>
              <SelectItem value="world_1">Nebula Gardens</SelectItem>
              <SelectItem value="world_2">Crystal Peaks</SelectItem>
              <SelectItem value="world_3">Azure Valleys</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </CardContent>
  </Card>
);

const ParcelCard = ({ parcel, onClick }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)' }}
    className="chrome-surface rounded-2xl p-6 cursor-pointer transition-all duration-300"
    onClick={onClick}
  >
    <div className="flex justify-between items-start mb-4">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{background: 'rgba(0, 212, 255, 0.1)'}}>
          <MapPin className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
        </div>
        <div>
          <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>
            Parcel #{parcel.nft_token_id || 'P001'}
          </h3>
          <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
            {parcel.coordinates?.x || 0}, {parcel.coordinates?.y || 0}
          </p>
        </div>
      </div>
      <Badge style={{
        background: parcel.deed_status === 'REGISTERED' ? 'rgba(34, 197, 94, 0.2)' : 
                   parcel.deed_status === 'PENDING_TRANSFER' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(156, 163, 175, 0.2)',
        color: parcel.deed_status === 'REGISTERED' ? '#22c55e' : 
               parcel.deed_status === 'PENDING_TRANSFER' ? '#f59e0b' : '#9ca3af'
      }}>
        {parcel.deed_status || 'REGISTERED'}
      </Badge>
    </div>
    
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Zoning</span>
        <Badge className="chrome-surface" style={{color: 'var(--orbital-blue)'}}>
          {parcel.zoning_type?.toUpperCase() || 'RESIDENTIAL'}
        </Badge>
      </div>
      
      <div className="flex justify-between items-center">
        <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Size</span>
        <span className="font-semibold" style={{color: 'var(--orbital-text)'}}>
          {parcel.size || 2500} units²
        </span>
      </div>
      
      <div className="flex justify-between items-center">
        <span className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Owner</span>
        <span className="font-mono text-sm" style={{color: 'var(--orbital-blue)'}}>
          {parcel.owner_wallet?.slice(0, 8) || '0xABC...123'}...
        </span>
      </div>
      
      {parcel.hotspot_tags && parcel.hotspot_tags.length > 0 && (
        <div className="flex flex-wrap gap-2 pt-2">
          {parcel.hotspot_tags.slice(0, 3).map(tag => (
            <Badge key={tag} variant="outline" className="text-xs" style={{borderColor: 'rgba(0, 212, 255, 0.3)', color: 'var(--orbital-blue)'}}>
              {tag}
            </Badge>
          ))}
        </div>
      )}
    </div>
  </motion.div>
);

const SearchStats = ({ totalResults, searchTime, filters }) => (
  <Card className="chrome-surface mb-6">
    <CardContent className="py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold" style={{color: 'var(--orbital-blue)'}}>{totalResults}</div>
            <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Parcels Found</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold" style={{color: '#22c55e'}}>{searchTime}ms</div>
            <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Search Time</div>
          </div>
        </div>
        <div className="flex gap-2">
          {Object.entries(filters).filter(([key, value]) => value !== 'all' && value !== '').map(([key, value]) => (
            <Badge key={key} className="chrome-surface" style={{color: 'var(--orbital-blue)'}}>
              {key}: {value}
            </Badge>
          ))}
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function ParcelSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    zoning: 'all',
    size: 'all',
    status: 'all',
    world: 'all'
  });
  const [parcels, setParcels] = useState([]);
  const [filteredParcels, setFilteredParcels] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchTime, setSearchTime] = useState(0);

  useEffect(() => {
    loadParcels();
  }, []);

  useEffect(() => {
    performSearch();
  }, [searchQuery, filters, parcels]); // `parcels` is included as it's directly filtered

  const loadParcels = async () => {
    try {
      setIsSearching(true);
      const parcelData = await Parcel.list('-created_date');
      setParcels(parcelData);
    } catch (error) {
      console.error('Failed to load parcels:', error);
      // Mock data fallback
      setParcels([
        {
          id: '1',
          nft_token_id: 'P001',
          coordinates: { x: 150, y: 200 },
          zoning_type: 'residential',
          size: 2500,
          owner_wallet: '0xABC123...',
          deed_status: 'REGISTERED',
          hotspot_tags: ['prime-location', 'high-traffic']
        },
        {
          id: '2',
          nft_token_id: 'P002',
          coordinates: { x: 300, y: 450 },
          zoning_type: 'commercial',
          size: 6000,
          owner_wallet: '0xDEF456...',
          deed_status: 'PENDING_TRANSFER',
          hotspot_tags: ['city-center', 'commercial-hub']
        },
        {
          id: '3',
          nft_token_id: 'P003',
          coordinates: { x: 50, y: 80 },
          zoning_type: 'industrial',
          size: 800,
          owner_wallet: '0xGHI789...',
          deed_status: 'REGISTERED',
          hotspot_tags: ['industrial-zone']
        },
        {
          id: '4',
          nft_token_id: 'P004',
          coordinates: { x: 700, y: 120 },
          zoning_type: 'recreational',
          size: 3000,
          owner_wallet: '0xJKL012...',
          deed_status: 'ARCHIVED',
          hotspot_tags: ['park-adjacent', 'leisure']
        },
        {
          id: '5',
          nft_token_id: 'P005',
          coordinates: { x: 250, y: 300 },
          zoning_type: 'residential',
          size: 1500,
          owner_wallet: '0xMNO345...',
          deed_status: 'REGISTERED',
          hotspot_tags: ['suburban', 'family-friendly']
        },
        {
          id: '6',
          nft_token_id: 'P006',
          coordinates: { x: 100, y: 100 },
          zoning_type: 'commercial',
          size: 10000,
          owner_wallet: '0xPQR678...',
          deed_status: 'REGISTERED',
          hotspot_tags: ['retail-front', 'high-visibility']
        }
      ]);
    } finally {
      setIsSearching(false);
    }
  };

  const performSearch = () => {
    const startTime = Date.now();
    
    let results = parcels;

    // Apply search query
    if (searchQuery) {
      results = results.filter(parcel =>
        parcel.nft_token_id?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        parcel.owner_wallet?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        `${parcel.coordinates?.x || 0},${parcel.coordinates?.y || 0}`.includes(searchQuery)
      );
    }

    // Apply filters
    if (filters.zoning !== 'all') {
      results = results.filter(parcel => parcel.zoning_type === filters.zoning);
    }
    if (filters.status !== 'all') {
      results = results.filter(parcel => parcel.deed_status === filters.status);
    }
    if (filters.size !== 'all') {
      results = results.filter(parcel => {
        const size = parcel.size || 0;
        switch (filters.size) {
          case 'small': return size < 1000;
          case 'medium': return size >= 1000 && size <= 5000;
          case 'large': return size > 5000;
          default: return true;
        }
      });
    }

    setFilteredParcels(results);
    setSearchTime(Date.now() - startTime);
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleParcelClick = (parcel) => {
    console.log('Selected parcel:', parcel);
    // Navigate to parcel details or open modal
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-8"
      >
        <div>
          <h1 className="text-4xl font-bold">PARCEL SEARCH ENGINE</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Advanced search and discovery for orbital land parcels</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="chrome-surface">
            <Map className="w-4 h-4 mr-2" />
            View on Map
          </Button>
          <Button className="glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
            <Eye className="w-4 h-4 mr-2" />
            Bulk Export
          </Button>
        </div>
      </motion.div>

      {/* Main Search */}
      <Card className="chrome-surface mb-6">
        <CardContent className="p-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}} />
              <Input
                placeholder="Search by parcel ID, coordinates, or owner wallet..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 chrome-surface h-12 text-lg"
                style={{color: 'var(--orbital-text)', borderColor: 'rgba(0, 212, 255, 0.3)'}}
              />
            </div>
            <Button 
              className="glow-blue h-12 px-8" 
              style={{background: 'var(--orbital-blue)', color: '#000'}}
              disabled={isSearching}
            >
              {isSearching ? 'Searching...' : 'Search'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <SearchFilters filters={filters} onFilterChange={handleFilterChange} />

      {/* Search Stats */}
      <SearchStats 
        totalResults={filteredParcels.length} 
        searchTime={searchTime}
        filters={filters}
      />

      {/* Results Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        <AnimatePresence>
          {filteredParcels.map((parcel, index) => (
            <ParcelCard 
              key={parcel.id} 
              parcel={parcel} 
              onClick={() => handleParcelClick(parcel)}
            />
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Empty State */}
      {filteredParcels.length === 0 && !isSearching && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <Search className="w-16 h-16 mx-auto mb-4 opacity-50" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="text-xl font-bold mb-2" style={{color: 'var(--orbital-text)'}}>No Parcels Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>Try adjusting your search criteria or filters</p>
        </motion.div>
      )}
    </div>
  );
}
