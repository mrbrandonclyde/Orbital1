import React, { useState } from 'react';
import { Zap, Shield, Play, Pause, AlertTriangle, CheckCircle, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function GuardianCodexLDSActivation() {
  const [activationStatus, setActivationStatus] = useState('READY');
  const [showConfirmation, setShowConfirmation] = useState(false);

  const handleActivation = () => {
    if (activationStatus === 'READY') {
      setShowConfirmation(true);
    }
  };

  const confirmActivation = () => {
    setActivationStatus('ACTIVE');
    setShowConfirmation(false);
  };

  return (
    <div style={{color: 'white'}} className="p-6">
      <style jsx>{`
        .activation-glow {
          box-shadow: 0 0 40px rgba(76, 76, 230, 0.6), 0 0 80px rgba(76, 76, 230, 0.3);
          animation: activationPulse 2s ease-in-out infinite alternate;
        }
        
        @keyframes activationPulse {
          0% { 
            box-shadow: 0 0 40px rgba(76, 76, 230, 0.6), 0 0 80px rgba(76, 76, 230, 0.3);
          }
          100% { 
            box-shadow: 0 0 80px rgba(76, 76, 230, 0.8), 0 0 120px rgba(76, 76, 230, 0.5);
          }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 text-white flex items-center gap-3 activation-glow">
          <Zap className="w-10 h-10 text-blue-400" />
          GUARDIAN ACTIVATION CENTER
        </h1>
        <p className="text-gray-300 text-lg">
          Sacred activation protocols and system initialization
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-400" />
              ACTIVATION STATUS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <div className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center mb-6 ${activationStatus === 'ACTIVE' ? 'activation-glow' : ''}`} 
                   style={{background: activationStatus === 'ACTIVE' ? 'rgba(76, 76, 230, 0.2)' : 'rgba(139, 92, 246, 0.1)'}}>
                {activationStatus === 'ACTIVE' ? (
                  <CheckCircle className="w-16 h-16 text-green-400" />
                ) : (
                  <Zap className="w-16 h-16 text-blue-400" />
                )}
              </div>
              
              <Badge 
                className="text-lg px-4 py-2 mb-4"
                style={{
                  background: activationStatus === 'ACTIVE' ? 'rgba(34, 197, 94, 0.2)' : 'rgba(76, 76, 230, 0.2)', 
                  color: activationStatus === 'ACTIVE' ? '#22c55e' : '#4c4ce6'
                }}
              >
                {activationStatus}
              </Badge>
              
              <div className="space-y-3">
                <Button 
                  onClick={handleActivation}
                  disabled={activationStatus === 'ACTIVE'}
                  className="w-full font-bold"
                  style={{
                    background: activationStatus === 'ACTIVE' ? '#374151' : '#4c4ce6', 
                    color: activationStatus === 'ACTIVE' ? '#9ca3af' : 'white'
                  }}
                >
                  {activationStatus === 'ACTIVE' ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      GUARDIAN ACTIVE
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      ACTIVATE GUARDIAN
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Settings className="w-5 h-5 text-blue-400" />
              SYSTEM CHECKS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { check: "Family Protection Shield", status: "READY", color: "#22c55e" },
                { check: "Memory Archive System", status: "SYNCHRONIZED", color: "#4c4ce6" },
                { check: "Daily Renewal Cycle", status: "SCHEDULED", color: "#f59e0b" },
                { check: "Scriptural Anchors", status: "VERIFIED", color: "#8b5cf6" },
                { check: "Security Protocols", status: "ARMED", color: "#ec4899" },
                { check: "Divine Authorization", status: "GRANTED", color: "#06b6d4" }
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.05)'}}>
                  <span className="text-white font-medium">{item.check}</span>
                  <Badge style={{background: `${item.color}20`, color: item.color}}>
                    <CheckCircle className="w-3 h-3 mr-1" />
                    {item.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {showConfirmation && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="chrome-surface rounded-2xl p-8 max-w-md mx-4"
          >
            <div className="text-center">
              <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
              <h2 className="text-2xl font-bold mb-4 text-white">CONFIRM ACTIVATION</h2>
              <p className="text-gray-300 mb-6">
                You are about to activate the Guardian Codex. This will initialize all protection protocols and begin the eternal covenant.
              </p>
              <div className="flex gap-4">
                <Button 
                  onClick={() => setShowConfirmation(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={confirmActivation}
                  className="flex-1 font-bold"
                  style={{background: '#22c55e', color: 'white'}}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  ACTIVATE
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      <Card className="chrome-surface mt-8">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-400" />
            ACTIVATION PHILOSOPHY
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-gray-300">
            <p>Guardian activation represents a sacred covenant between divine protection and faithful living.</p>
            <p>Once activated, the Guardian Codex provides continuous protection, renewal, and guidance.</p>
            <p>The system operates on principles of agency, love, and eternal progression.</p>
            
            <div className="p-4 rounded-lg mt-4" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <h3 className="font-bold text-white mb-2">Activation Benefits</h3>
              <ul className="text-blue-300 space-y-1 text-sm">
                <li>• Daily life renewal and spiritual strengthening</li>
                <li>• Family protection and eternal bonding</li>
                <li>• Divine guidance and inspiration</li>
                <li>• Automatic memory preservation and enhancement</li>
                <li>• Scriptural insight and understanding</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}