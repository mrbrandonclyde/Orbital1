
import React from 'react';
import { Shield, Key, Lock, Activity, Bot, ShieldCheck, UserCheck, Gavel, Cpu, Database, Fingerprint, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const SecurityMetric = ({ title, status, icon: Icon, color, description }) => (
  <motion.div 
    className="chrome-surface rounded-2xl p-6 text-center flex flex-col justify-between"
    whileHover={{ y: -5, boxShadow: `0 0 40px ${color}50` }}
  >
    <div>
      <Icon className="w-12 h-12 mx-auto mb-3" style={{color: color}} />
      <h3 className="font-bold text-lg" style={{color: 'var(--orbital-text)'}}>{title}</h3>
      <p className="font-semibold text-2xl" style={{color: color}}>{status}</p>
    </div>
    <p className="text-xs mt-2" style={{color: 'var(--orbital-text-dim)'}}>{description}</p>
  </motion.div>
);

const AuditLogEntry = ({ log, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 15 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.05 }}
    className="flex items-center justify-between p-3 rounded-lg"
    style={{background: 'rgba(0, 212, 255, 0.05)'}}
  >
    <div className="flex items-center gap-3">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-opacity-20`} style={{background: log.color + '20'}}>
        <log.icon className="w-4 h-4" style={{color: log.color}}/>
      </div>
      <div>
        <p className="font-medium text-sm">{log.action}</p>
        <p className="text-xs font-mono" style={{color: 'var(--orbital-text-dim)'}}>{log.actor} @ {new Date(log.timestamp).toLocaleString()}</p>
      </div>
    </div>
    <Badge variant="outline" className="text-xs" style={{borderColor: log.color, color: log.color}}>{log.status}</Badge>
  </motion.div>
);

export default function SecurityVault() {
  const auditLogs = [
    { action: "PQC Key Rotation", actor: "System", timestamp: Date.now(), status: "Success", icon: Key, color: '#00d4ff' },
    { action: "Admin Login", actor: "ZYRA", timestamp: Date.now() - 3e5, status: "Success", icon: UserCheck, color: '#22c55e' },
    { action: "Firewall Rule Update", actor: "AI Sentry", timestamp: Date.now() - 6e5, status: "Automated", icon: Bot, color: '#8b5cf6' },
    { action: "Failed Login Attempt", actor: "Unknown (IP: 123.45.67.89)", timestamp: Date.now() - 9e5, status: "Blocked", icon: ShieldCheck, color: '#ef4444' },
    { action: "Data Access", actor: "Analytics Engine", timestamp: Date.now() - 12e5, status: "Granted", icon: Database, color: '#a855f7' },
  ];

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <style jsx>{`
        .pqc-glow {
          box-shadow: 0 0 30px #22c55e60;
          animation: pqc-pulse 3s ease-in-out infinite alternate;
        }
        @keyframes pqc-pulse {
          from { box-shadow: 0 0 30px #22c55e60; }
          to { box-shadow: 0 0 50px #22c55e90; }
        }
      `}</style>
      
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">SECURITY VAULT v3</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Post-Quantum Cryptography & AI-Powered Threat Mitigation</p>
        </div>
        <Button className="font-bold pqc-glow" style={{background: '#22c55e', color: '#000'}}>
          <ShieldCheck className="w-5 h-5 mr-2" />
          Initiate Full System Audit
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <SecurityMetric title="THREAT LEVEL" status="NOMINAL" icon={Shield} color="var(--orbital-blue)" description="Zero active threats detected."/>
        <SecurityMetric title="AI SENTRY" status="ACTIVE" icon={Bot} color="#8b5cf6" description="24/7 predictive threat modeling." />
        <SecurityMetric title="PQC ENCRYPTION" status="VALIDATED" icon={Lock} color="#22c55e" description="Kyber, Dilithium, Falcon layers active." />
        <SecurityMetric title="AUDIT TRAIL" status="IMMUTABLE" icon={Gavel} color="#f59e0b" description="PQC-anchored transaction logs." />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="chrome-surface pqc-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Key className="w-6 h-6" style={{color: '#22c55e'}}/>
              Post-Quantum Cryptography Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { name: "CRYSTALS-Kyber", use: "Key-Encapsulation", status: "Active" },
              { name: "CRYSTALS-Dilithium", use: "Digital Signatures", status: "Active" },
              { name: "Falcon", use: "Digital Signatures", status: "Active" }
            ].map(algo => (
              <div key={algo.name} className="flex justify-between items-center p-3 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.1)'}}>
                <div>
                  <p className="font-bold">{algo.name}</p>
                  <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{algo.use}</p>
                </div>
                <Badge style={{background: '#22c55e30', color: '#22c55e'}}>
                  <CheckCircle className="w-3 h-3 mr-1.5" />
                  {algo.status}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Activity className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
              Immutable Audit Log
            </CardTitle>
          </CardHeader>
          <CardContent className="max-h-80 overflow-y-auto pr-2">
            <div className="space-y-2">
              {auditLogs.map((log, i) => (
                <AuditLogEntry key={i} log={log} index={i} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
