import React, { useState, useEffect } from 'react';
import { Settings2, Plus, Edit, Trash2, Save, X, Shield, Gavel, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

const RuleCard = ({ rule, onEdit, onDelete }) => (
  <motion.div
    layout
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    className="chrome-surface rounded-xl p-4"
  >
    <div className="flex justify-between items-start mb-3">
      <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>{rule.title}</h4>
      <div className="flex gap-2">
        <Badge style={{
          background: rule.severity === 'critical' ? '#ef4444' : 
                     rule.severity === 'high' ? '#f59e0b' : 
                     rule.severity === 'medium' ? '#8b5cf6' : '#22c55e',
          color: '#000'
        }}>
          {rule.severity.toUpperCase()}
        </Badge>
      </div>
    </div>
    <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>{rule.description}</p>
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
        Category: {rule.category}
      </span>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={() => onEdit(rule)} className="chrome-surface">
          <Edit className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="outline" onClick={() => onDelete(rule.id)} className="chrome-surface hover:bg-red-500/20">
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  </motion.div>
);

export default function RuleSetManagement() {
  const [rules, setRules] = useState([
    { id: 1, title: 'No Harm to Innocents', description: 'Absolute protection of innocent life and wellbeing', category: 'protection', severity: 'critical' },
    { id: 2, title: 'Truth in All Dealings', description: 'Complete honesty in all interactions and transactions', category: 'integrity', severity: 'high' },
    { id: 3, title: 'Respect for Free Agency', description: 'Honor individual choice and self-determination', category: 'freedom', severity: 'critical' },
    { id: 4, title: 'Environmental Stewardship', description: 'Protect and preserve natural resources', category: 'stewardship', severity: 'medium' },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    severity: 'medium'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingRule) {
      setRules(prev => prev.map(rule => rule.id === editingRule.id ? { ...editingRule, ...formData } : rule));
    } else {
      setRules(prev => [...prev, { ...formData, id: Date.now() }]);
    }
    resetForm();
  };

  const handleEdit = (rule) => {
    setEditingRule(rule);
    setFormData({ title: rule.title, description: rule.description, category: rule.category, severity: rule.severity });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    setRules(prev => prev.filter(rule => rule.id !== id));
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', category: '', severity: 'medium' });
    setEditingRule(null);
    setShowForm(false);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">⚖️ RULE SET MANAGEMENT</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Define and manage the fundamental laws of the Guardian Codex</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="font-bold" style={{background: 'var(--orbital-blue)', color: '#000'}}>
          <Plus className="w-5 h-5 mr-2" />
          Create New Rule
        </Button>
      </motion.div>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
          >
            <Card className="chrome-surface mb-8">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Settings2 className="w-6 h-6" style={{color: 'var(--orbital-blue)'}} />
                    {editingRule ? 'Edit Rule' : 'Create New Rule'}
                  </div>
                  <Button variant="outline" size="sm" onClick={resetForm} className="chrome-surface">
                    <X className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    placeholder="Rule Title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({...prev, title: e.target.value}))}
                    className="chrome-surface"
                    required
                  />
                  <Textarea
                    placeholder="Rule Description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
                    className="chrome-surface h-24"
                    required
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <Select value={formData.category} onValueChange={(v) => setFormData(prev => ({...prev, category: v}))}>
                      <SelectTrigger className="chrome-surface"><SelectValue placeholder="Category" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="protection">Protection</SelectItem>
                        <SelectItem value="integrity">Integrity</SelectItem>
                        <SelectItem value="freedom">Freedom</SelectItem>
                        <SelectItem value="stewardship">Stewardship</SelectItem>
                        <SelectItem value="justice">Justice</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={formData.severity} onValueChange={(v) => setFormData(prev => ({...prev, severity: v}))}>
                      <SelectTrigger className="chrome-surface"><SelectValue placeholder="Severity" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-3 justify-end">
                    <Button type="button" variant="outline" onClick={resetForm} className="chrome-surface">Cancel</Button>
                    <Button type="submit" className="font-bold" style={{background: 'var(--orbital-blue)', color: '#000'}}>
                      <Save className="w-4 h-4 mr-2" />
                      {editingRule ? 'Update Rule' : 'Create Rule'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {rules.map((rule) => (
            <RuleCard key={rule.id} rule={rule} onEdit={handleEdit} onDelete={handleDelete} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}