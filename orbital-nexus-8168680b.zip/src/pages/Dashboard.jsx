
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Globe, Users, Activity, Bot, Zap, TrendingUp, AlertTriangle, Shield, CheckCircle, XCircle, BarChart3, Brain, Heart, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { World } from '@/api/entities';
import { AIAvatar } from '@/api/entities';
import { NFT } from '@/api/entities';
import { SystemEvent } from '@/api/entities';
import { ResponsiveContainer, AreaChart, Area, Tooltip } from 'recharts';
import { Card } from '@/components/ui/card';
import { InteractiveGlobe } from '../components/dashboard/InteractiveGlobe';

const MetricCard = ({ title, value, icon: Icon, trend, status = 'normal', to }) => {
  const getStatusColor = () => {
    switch(status) {
      case 'success': return '#22c55e';
      case 'warning': return '#f59e0b';
      case 'danger': return '#ef4444';
      default: return '#4c4ce6'; // Sacred Globe Blue
    }
  };

  const cardContent = (
    <motion.div
      whileHover={{ y: -5, boxShadow: '0 0 30px rgba(76, 76, 230, 0.3)' }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300 h-full flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start">
          <p className="text-sm font-medium" style={{color: 'var(--orbital-text-dim)'}}>{title}</p>
          <Icon className="w-5 h-5" style={{color: getStatusColor()}} />
        </div>
        <p className="text-3xl font-bold mt-2" style={{color: 'var(--orbital-text)'}}>{value}</p>
      </div>
      {trend && <p className="text-xs mt-2" style={{color: getStatusColor()}}>{trend}</p>}
    </motion.div>
  );

  return to ? <Link to={to}>{cardContent}</Link> : cardContent;
};

const CommandWidget = ({ title, icon: Icon, children, className = '', actions = [] }) => (
  <Card className={`chrome-surface rounded-2xl p-6 ${className}`}>
    <div className="flex justify-between items-center mb-4">
      <h3 className="font-bold flex items-center gap-2" style={{color: 'var(--orbital-text)'}}>
        <Icon className="w-5 h-5" style={{color: '#4c4ce6'}} />
        {title}
      </h3>
      {actions.length > 0 && (
        <div className="flex gap-2">
          {actions.map((action, index) => (
            <button 
              key={index}
              onClick={action.onClick}
              className="px-3 py-1 rounded-lg text-xs font-medium transition-all hover:glow-blue"
              style={{background: '#4c4ce6', color: 'var(--orbital-black)'}}
            >
              {action.label}
            </button>
          ))}
        </div>
      )}
    </div>
    {children}
  </Card>
);

const AlertFeed = ({ alerts }) => {
  const getAlertInfo = (type) => {
    switch (type) {
      case 'success': return { icon: CheckCircle, color: '#22c55e' };
      case 'warning': return { icon: AlertTriangle, color: '#f59e0b' };
      case 'error': return { icon: XCircle, color: '#ef4444' };
      default: return { icon: Zap, color: '#4c4ce6' }; // Sacred Globe Blue
    }
  };

  return (
    <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
      {alerts.map((alert, index) => {
        const AlertIcon = getAlertInfo(alert.type).icon;
        const alertColor = getAlertInfo(alert.type).color;
        
        const content = (
          <motion.div 
            key={alert.id || index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center gap-3 p-2 rounded-lg transition-all" style={{background: 'rgba(76, 76, 230, 0.05)'}}
          >
            <AlertIcon className="w-4 h-4 flex-shrink-0" style={{color: alertColor}} />
            <div className="flex-grow">
              <p className="text-sm" style={{color: 'var(--orbital-text)'}}>{alert.message}</p>
              <p className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>
                {new Date(alert.created_date).toLocaleTimeString()}
              </p>
            </div>
          </motion.div>
        );

        return alert.target_url ? (
          <Link to={createPageUrl(alert.target_url)} className="hover:glow-blue rounded-lg block">{content}</Link>
        ) : (
          content
        );
      })}
    </div>
  );
};

const QuickActions = () => (
  <div className="grid grid-cols-2 gap-3">
    {[
      { icon: Globe, label: 'Create World', action: () => {}, to: createPageUrl('WorldBuilder') },
      { icon: Users, label: 'Deploy AI', action: () => {}, to: createPageUrl('AIHumans') },
      { icon: Shield, label: 'Security Scan', action: () => {}, to: createPageUrl('SecurityVault') },
      { icon: TrendingUp, label: 'Market Analysis', action: () => {}, to: createPageUrl('Marketplace') },
    ].map((item, index) => (
      <Link key={index} to={item.to}>
        <motion.button
          onClick={item.action}
          whileHover={{ y: -3, scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex flex-col items-center justify-center gap-2 p-4 rounded-lg transition-all w-full h-full text-center"
          style={{background: 'rgba(76, 76, 230, 0.1)', border: '1px solid rgba(76, 76, 230, 0.2)'}}
        >
          <item.icon className="w-6 h-6" style={{color: '#4c4ce6'}} />
          <span className="text-xs font-medium" style={{color: 'var(--orbital-text)'}}>{item.label}</span>
        </motion.button>
      </Link>
    ))}
  </div>
);

const SparklineChart = ({ data, dataKey, stroke, fill }) => (
  <ResponsiveContainer width="100%" height={60}>
    <AreaChart data={data} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
      <Tooltip
        contentStyle={{
          background: "rgba(0,0,0,0.8)",
          borderColor: "#4c4ce6",
          color: "var(--orbital-text)",
          fontSize: "12px",
          borderRadius: "8px",
        }}
        itemStyle={{ color: "#4c4ce6" }}
      />
      <Area type="monotone" dataKey={dataKey} stroke={stroke} fill={fill} strokeWidth={2} />
    </AreaChart>
  </ResponsiveContainer>
);

export default function Dashboard() {
  const [stats, setStats] = useState({
    worlds: 0,
    users: 0, 
    aiAgents: 0,
    tps: 0,
    worldsBuilding: 0,
    nftsMinted: 0,
  });
  const [alerts, setAlerts] = useState([]);
  const [orbPriceHistory, setOrbPriceHistory] = useState([]);
  const [tpsHistory, setTpsHistory] = useState([]);
  const [guardianStats, setGuardianStats] = useState({
    livesRemaining: 3,
    memoryStreamStatus: "OPERATIONAL",
    lastArchive: "05:00 Today",
    renewalCount: 1247
  });

  const loadGuardianData = async () => {
    // Simulate Guardian Codex data loading
    setGuardianStats({
      livesRemaining: 3,
      memoryStreamStatus: "OPERATIONAL", 
      lastArchive: "05:00 Today",
      renewalCount: 1247
    });
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [worldData, aiData, nftData, eventData] = await Promise.all([
          World.list(),
          AIAvatar.list(),
          NFT.list(),
          SystemEvent.list('-created_date', 5)
        ]);

        const newTps = Math.floor(Math.random() * (12000 - 9000 + 1)) + 9000;
        setStats({
          worlds: worldData.length,
          users: 8192,
          aiAgents: aiData.length,
          tps: newTps,
          worldsBuilding: worldData.filter(w => w.status === 'building').length,
          nftsMinted: nftData.length,
        });

        setTpsHistory(prev => [...prev.slice(-29), { name: new Date().toLocaleTimeString(), value: newTps }]);
        setAlerts(eventData);

      } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
      }
    };

    const priceInterval = setInterval(() => {
      setOrbPriceHistory(prev => {
        const lastPrice = prev.length > 0 ? prev[prev.length - 1].value : 13.37;
        const newPrice = parseFloat((lastPrice + (Math.random() - 0.49) * 0.1).toFixed(2));
        return [...prev.slice(-29), { name: new Date().toLocaleTimeString(), value: newPrice }];
      });
    }, 3000);
    
    fetchData();
    const dataInterval = setInterval(fetchData, 10000);
    loadGuardianData();

    return () => {
      clearInterval(dataInterval);
      clearInterval(priceInterval);
    };
  }, []);

  const lastOrbPrice = orbPriceHistory.length > 0 ? orbPriceHistory[orbPriceHistory.length - 1].value : 0;
  const firstOrbPrice = orbPriceHistory.length > 0 ? orbPriceHistory[0].value : 1;
  const orbPriceChange = ((lastOrbPrice - firstOrbPrice) / firstOrbPrice) * 100;

  const sentence = "Connect your world with precision.".split(" ");

  const sentenceVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delay: 0.5,
        staggerChildren: 0.1,
      },
    },
  };

  const letterVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
    },
  };

  return (
    <div style={{color: 'var(--orbital-text)'}} className="min-h-screen">
      {/* 🌟 DIVINE HERO SECTION 🌟 */}
      <div className="relative hero-gradient overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black"></div>
        
        <div className="container mx-auto px-6 relative z-10 min-h-[70vh] flex items-center justify-center">
          <div className="flex items-center justify-between w-full max-w-6xl">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={sentenceVariants}
              className="flex-1"
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-blue-300 to-blue-400 bg-clip-text text-transparent leading-tight">
                {sentence.map((word, index) => (
                  <motion.span key={word + "-" + index} variants={letterVariants} className="inline-block mr-4">
                    {word}
                  </motion.span>
                ))}
              </h1>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 }}
              className="flex-shrink-0 ml-8"
            >
              <InteractiveGlobe />
            </motion.div>
          </div>
        </div>
      </div>

      {/* Main Dashboard Content */}
      <div className="px-6 pb-6 -mt-24 container mx-auto relative z-20">
        {/* Guardian Codex Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <MetricCard title="DAILY LIVES REMAINING" value={guardianStats.livesRemaining} icon={Heart} trend="Renewed at sunrise" status="success" to={createPageUrl('GuardianCodexLDSRenewal')} />
          <MetricCard title="MEMORY STREAM" value={guardianStats.memoryStreamStatus} icon={Brain} trend={`Last: ${guardianStats.lastArchive}`} status="success" to={createPageUrl('GuardianCodexLDSMemory')} />
          <MetricCard title="RENEWAL COUNT" value={`#${guardianStats.renewalCount.toLocaleString()}`} icon={Clock} trend="Since activation" status="normal" />
          <MetricCard title="GUARDIAN STATUS" value="ACTIVE" icon={Shield} trend="Divine protection enabled" status="success" to={createPageUrl('GuardianCodexLDS')} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          <MetricCard title="ACTIVE WORLDS" value={stats.worlds.toLocaleString()} icon={Globe} trend={`+${Math.floor(Math.random()*5)} this cycle`} status="success" to={createPageUrl('WorldBuilder')} />
          <MetricCard title="ONLINE USERS" value={stats.users.toLocaleString()} icon={Users} trend="+5.2% today" status="success" />
          <MetricCard title="AI AGENTS ONLINE" value={stats.aiAgents.toLocaleString()} icon={Bot} trend="Fleet Operational" status="normal" to={createPageUrl('AIHumans')} />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
          <CommandWidget 
            title="ORB ECONOMY" 
            icon={TrendingUp}
            actions={[{label: 'Trade', onClick: () => {}}]}
          >
            <div className="text-center">
              <div className="text-4xl font-bold mb-2" style={{color: '#4c4ce6'}}>${lastOrbPrice.toFixed(2)}</div>
              <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Current ORB Price</div>
              <div className="text-xs mt-1" style={{color: orbPriceChange >= 0 ? '#22c55e' : '#ef4444'}}>
                {orbPriceChange.toFixed(2)}% (24h)
              </div>
              <SparklineChart data={orbPriceHistory} dataKey="value" stroke="#4c4ce6" fill="rgba(76, 76, 230, 0.2)" />
            </div>
          </CommandWidget>
          
          <CommandWidget 
            title="NETWORK THROUGHPUT" 
            icon={Activity}
            actions={[{label: 'Status', onClick: () => {}}]}
          >
              <div className="text-center">
                <div className="text-4xl font-bold mb-2" style={{color: '#4c4ce6'}}>{(stats.tps / 1000).toFixed(1)}k</div>
                <div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Transactions / Sec</div>
                <div className="text-xs mt-1" style={{color: 'var(--orbital-text-dim)'}}>
                  Peak: {Math.floor(stats.tps * 1.2).toLocaleString()}
                </div>
              <SparklineChart data={tpsHistory} dataKey="value" stroke="#4c4ce6" fill="rgba(76, 76, 230, 0.2)" />
            </div>
          </CommandWidget>
          
          <CommandWidget 
            title="SECURITY STATUS" 
            icon={Shield}
            actions={[{label: 'Audit', onClick: () => {}}]}
          >
            <div className="text-center py-4">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center glow-blue" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
                <Shield className="w-8 h-8" style={{color: '#4c4ce6'}} />
              </div>
              <p className="font-bold" style={{color: '#4c4ce6'}}>ALL SYSTEMS NOMINAL</p>
              <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Zero threats detected</p>
            </div>
          </CommandWidget>

          <CommandWidget 
            title="QUICK ACTIONS" 
            icon={Zap}
          >
            <QuickActions />
          </CommandWidget>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <CommandWidget 
            title="SYSTEM ALERTS" 
            icon={AlertTriangle}
            actions={[{label: 'View All', onClick: () => {}}]}
          >
            <AlertFeed alerts={alerts} />
          </CommandWidget>

          <CommandWidget 
            title="CORE PERFORMANCE" 
            icon={BarChart3}
            actions={[{label: 'Analytics', onClick: () => {}}]}
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>99.9%</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Uptime</div>
              </div>
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>142ms</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Avg Response</div>
              </div>
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>2.1M</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Transactions</div>
              </div>
              <div className="text-center p-3 rounded-lg chrome-surface">
                <div className="text-2xl font-bold" style={{color: '#4c4ce6'}}>847</div>
                <div className="text-xs" style={{color: 'var(--orbital-text-dim)'}}>Active Nodes</div>
              </div>
            </div>
          </CommandWidget>
        </div>
      </div>
    </div>
  );
}
