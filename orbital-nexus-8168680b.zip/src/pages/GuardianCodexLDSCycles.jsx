
import React, { useState } from 'react';
import { Calendar, Zap, Sun, Moon, Shield, Brain, Heart, Star, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const weeklyCycles = [
    { day: "Monday", focus: "Speed & Agility", icon: Zap, color: "#f59e0b" },
    { day: "Tuesday", focus: "Vision & Perception", icon: Eye, color: "#8b5cf6" },
    { day: "Wednesday", focus: "Healing & Renewal", icon: Heart, color: "#22c55e" },
    { day: "Thursday", focus: "Strength & Power", icon: Shield, color: "#ef4444" },
    { day: "Friday", focus: "Mind & Telepathy", icon: Brain, color: "#06b6d4" },
    { day: "Saturday", focus: "Cosmic Awareness", icon: Star, color: "#ec4899" },
    { day: "Sunday", focus: "Balance & Infinity", icon: Sun, color: "#4c4ce6" },
];

const monthlySuperSeasons = [
    { month: "January", season: "Genesis of Strength", icon: Shield },
    { month: "February", season: "Flow of Agility", icon: Zap },
    { month: "March", season: "Fire of Energy", icon: Sun },
    { month: "April", season: "Bloom of Healing", icon: Heart },
    { month: "May", season: "Vision of Light", icon: Eye },
    { month: "June", season: "Mind of Lightning", icon: Brain },
    { month: "July", season: "Cosmic Expansion", icon: Star },
    { month: "August", season: "Harmony & Balance", icon: Sun },
    { month: "September", season: "Mastery of Foresight", icon: Eye },
    { month: "October", season: "Shield of Resilience", icon: Shield },
    { month: "November", season: "Breath of Infinity", icon: Star },
    { month: "December", season: "Eternal Integration", icon: Zap },
];

const CycleCard = ({ title, focus, icon: Icon, color, isActive }) => (
  <motion.div
    className={`chrome-surface rounded-xl p-4 transition-all duration-300 ${isActive ? 'cycle-glow' : ''}`}
    style={{ borderLeft: `4px solid ${isActive ? color : 'transparent'}`}}
    whileHover={{ y: -5, boxShadow: `0 0 20px ${color}40` }}
  >
    <div className="flex items-center gap-3">
      <Icon className="w-6 h-6" style={{color: isActive ? color : 'var(--orbital-text-dim)'}} />
      <div>
        <h3 className={`font-bold ${isActive ? 'text-white' : 'text-gray-400'}`}>{title}</h3>
        <p className="text-sm" style={{color: isActive ? color : 'var(--orbital-text-dim)'}}>{focus}</p>
      </div>
    </div>
  </motion.div>
);

export default function GuardianCodexLDSCycles() {
  const [today, setToday] = useState(new Date());
  
  // Note: getDay() returns 0 for Sunday, 1 for Monday, etc. Adjusting for our array.
  const dayIndex = today.getDay() === 0 ? 6 : today.getDay() - 1;
  const monthIndex = today.getMonth();

  return (
    <div style={{color: 'var(--orbital-text)'}} className="p-6">
      <style jsx>{`
        .cycle-glow {
          background: rgba(76, 76, 230, 0.1);
          box-shadow: 0 0 30px rgba(76, 76, 230, 0.3), inset 0 0 10px rgba(76, 76, 230, 0.1);
        }
      `}</style>
      
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
          <Calendar className="w-10 h-10" style={{color: 'var(--orbital-blue)'}} />
          INFINITY GENIUS CYCLES
        </h1>
        <p style={{color: 'var(--orbital-text-dim)'}}>
          The eternal rhythms of weekly cycles and monthly SuperSeasons.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sun className="w-5 h-5" style={{color: 'var(--orbital-blue)'}}/>
              WEEKLY CYCLE (7-DAY ETERNAL RHYTHM)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {weeklyCycles.map((cycle, i) => (
                <CycleCard 
                  key={cycle.day}
                  title={cycle.day}
                  focus={cycle.focus}
                  icon={cycle.icon}
                  color={cycle.color}
                  isActive={dayIndex === i}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5" style={{color: 'var(--orbital-blue)'}}/>
              MONTHLY SUPERSEASONS (12 PILLARS)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {monthlySuperSeasons.map((season, i) => (
                <CycleCard 
                  key={season.month}
                  title={season.month}
                  focus={season.season}
                  icon={season.icon}
                  color={weeklyCycles[i % weeklyCycles.length].color}
                  isActive={monthIndex === i}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="chrome-surface mt-8">
        <CardContent className="p-6 text-center">
            <h3 className="font-bold text-lg mb-2" style={{color: 'var(--orbital-text)'}}>Today's Focus: <span style={{color: weeklyCycles[dayIndex].color}}>{weeklyCycles[dayIndex].focus}</span></h3>
            <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>
                Current SuperSeason: <span className="font-semibold" style={{color: weeklyCycles[monthIndex % weeklyCycles.length].color}}>{monthlySuperSeasons[monthIndex].season}</span>
            </p>
            <Badge className="mt-4" variant="outline" style={{borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)'}}>
                Infinity Genius Active
            </Badge>
        </CardContent>
      </Card>
    </div>
  );
}
