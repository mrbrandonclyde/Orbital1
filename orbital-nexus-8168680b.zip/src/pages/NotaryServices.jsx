import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Upload, Zap, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function NotaryServices() {
  const [parcelId, setParcelId] = useState('');
  const [file, setFile] = useState(null);
  const [isNotarizing, setIsNotarizing] = useState(false);
  const [notarizationComplete, setNotarizationComplete] = useState(false);

  const handleFileChange = (e) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
    }
  };

  const handleNotarize = () => {
    if (!parcelId || !file) return;
    setIsNotarizing(true);
    setNotarizationComplete(false);
    setTimeout(() => {
      setIsNotarizing(false);
      setNotarizationComplete(true);
    }, 3000);
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">NOTARY SERVICES</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Securely notarize property deeds and documents on-chain.</p>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="chrome-surface">
          <CardHeader>
            <CardTitle>Submit for Notarization</CardTitle>
            <CardDescription>Anchor your document's hash on the immutable ledger.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm font-medium mb-2 block">Parcel ID</label>
              <Input
                placeholder="Enter the Parcel ID (e.g., P001-ALPHA)"
                value={parcelId}
                onChange={(e) => setParcelId(e.target.value)}
                className="chrome-surface"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Document Upload</label>
              <div className="flex items-center justify-center w-full">
                <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer hover:bg-blue-500/10" style={{borderColor: 'var(--orbital-blue-dim)'}}>
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-8 h-8 mb-4" style={{color: 'var(--orbital-text-dim)'}} />
                    {file ? (
                      <p className="font-semibold" style={{color: 'var(--orbital-blue)'}}>{file.name}</p>
                    ) : (
                      <>
                        <p className="mb-2 text-sm"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                        <p className="text-xs">Deed, Survey, or other legal documents</p>
                      </>
                    )}
                  </div>
                  <input id="dropzone-file" type="file" className="hidden" onChange={handleFileChange} />
                </label>
              </div>
            </div>
            <Button onClick={handleNotarize} disabled={isNotarizing || !parcelId || !file} size="lg" className="w-full font-bold glow-blue" style={{background: 'var(--orbital-blue)', color: 'var(--orbital-black)'}}>
              {isNotarizing ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-spin" />
                  Notarizing on-chain...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5 mr-2" />
                  Notarize Document
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <motion.div initial={{opacity:0, scale:0.95}} animate={{opacity:1, scale:1}}>
          <Card className="chrome-surface h-full">
            <CardHeader>
              <CardTitle>Notarization Status</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center h-full text-center p-12">
              {notarizationComplete ? (
                <motion.div initial={{opacity:0, scale:0.8}} animate={{opacity:1, scale:1}} className="text-center">
                  <ShieldCheck className="w-24 h-24 mx-auto mb-4 text-green-400" />
                  <h3 className="text-2xl font-bold text-green-400">Notarization Complete</h3>
                  <p className="mt-2 mb-4" style={{color: 'var(--orbital-text-dim)'}}>
                    The document for parcel <span className="font-bold" style={{color: 'var(--orbital-blue)'}}>{parcelId}</span> has been successfully anchored.
                  </p>
                  <p className="text-sm font-mono p-2 rounded-lg" style={{background: 'var(--orbital-surface)', color: 'var(--orbital-text-dim)'}}>
                    Tx Hash: 0x...{Math.random().toString(16).substr(2, 12)}
                  </p>
                </motion.div>
              ) : (
                 <div className="text-center">
                  <FileText className="w-24 h-24 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
                  <p className="text-lg" style={{color: 'var(--orbital-text-dim)'}}>Awaiting document submission...</p>
                  <p className="text-sm mt-2" style={{color: 'var(--orbital-text-dim)'}}>
                    Your notarization certificate and on-chain transaction details will appear here upon completion.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}