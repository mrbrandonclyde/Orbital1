import React from 'react';
import { Megaphone, PhoneCall, Send } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function CrmAutomation() {
  return (
    <div className="p-6 text-white">
      <h1 className="text-4xl font-bold mb-4">CRM Automation</h1>
      <p className="text-lg text-gray-300 mb-8">Automate outreach and management at scale.</p>
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white"><Megaphone className="text-blue-400" />Automation Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Bulk Message, Bulk Call, Bulk Update, Bulk Approvals.</p>
        </CardContent>
      </Card>
    </div>
  );
}