import React, { useState, useEffect } from 'react';
import { Landmark, DollarSign, Image, BarChart, TrendingUp, Shield, Zap } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';

const TreasuryAssetCard = ({ asset }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${asset.color}33` }}
    className="chrome-surface rounded-2xl p-6"
    style={{ borderBottom: `4px solid ${asset.color}` }}
  >
    <div className="flex justify-between items-start mb-4">
      <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{background: `${asset.color}20`}}>
        <asset.icon className="w-6 h-6" style={{color: asset.color}} />
      </div>
      <Badge variant="outline" style={{borderColor: asset.color, color: asset.color}}>{asset.type}</Badge>
    </div>
    <p className="text-lg font-semibold">{asset.name}</p>
    <p className="text-3xl font-bold mt-2">{asset.value}</p>
    <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{asset.quantity}</p>
  </motion.div>
);

export default function Treasury() {
  const [assets, setAssets] = useState([]);
  const [totalValue, setTotalValue] = useState('2.4B');
  
  useEffect(() => {
    setAssets([
      { name: 'ORB Token', value: '1.8B ORB', quantity: '120M Tokens', type: 'Native Token', icon: DollarSign, color: 'var(--orbital-blue)' },
      { name: 'Stablecoin Reserves', value: '500M USD', quantity: 'USDC/USDT', type: 'Fiat-Backed', icon: Landmark, color: '#22c55e' },
      { name: 'Strategic NFTs', value: '100M ORB', quantity: '5,280 Assets', type: 'Digital Assets', icon: Image, color: '#8b5cf6' },
      { name: 'Ecosystem Grants', value: '50M ORB', quantity: 'Active Grants', type: 'Investments', icon: TrendingUp, color: '#f59e0b' },
    ]);
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <div className="mb-8">
        <h1 className="text-4xl font-bold">ORB TOKEN TREASURY v2</h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>Manage multi-asset reserves with DAO governance and AI-optimized allocations.</p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #00d4ff, #8b5cf6)', color: '#000' }}>
            <Shield className="w-4 h-4 mr-2" />
            PQC-SECURED MULTI-ASSET VAULT
          </Badge>
           <Badge variant="outline" style={{ borderColor: '#22c55e', color: '#22c55e' }}>
            <Zap className="w-4 h-4 mr-2" />
            AI ALLOCATION OPTIMIZER ACTIVE
          </Badge>
        </div>
      </div>
      
      <Card className="chrome-surface mb-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Treasury Overview</CardTitle>
            <div className="text-right">
              <p className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Total Value</p>
              <p className="text-3xl font-bold glow-blue">{totalValue} ORB</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {assets.map(a => <TreasuryAssetCard key={a.name} asset={a} />)}
           </div>
        </CardContent>
      </Card>
      
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle>DAO Governance & Proposals</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12" style={{color: 'var(--orbital-text-dim)'}}>
          <BarChart className="w-16 h-16 mx-auto mb-4" />
          <p>Live voting on treasury allocations and proposals coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}