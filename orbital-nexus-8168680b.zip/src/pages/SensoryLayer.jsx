
import React from 'react';
import { Eye, Headphones, Hand, Wind, Coffee } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function SensoryLayer() {
  return (
    <div className="p-6 text-white">
      <h1 className="text-4xl font-bold mb-4">Sensory Layer</h1>
      <p className="text-lg text-gray-300 mb-8">Interface with all five senses for a complete experience.</p>
      <Card className="chrome-surface">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white"><Eye className="text-blue-400" />Sensory Inputs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Sight, Hearing, Touch, Smell, Taste.</p>
        </CardContent>
      </Card>
    </div>
  );
}
