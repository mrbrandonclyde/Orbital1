import React from 'react';
import { Home, Shield, Star, Brain, Heart, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const StatusCard = ({ title, status, description, icon: Icon, color }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: `0 0 30px ${color}50` }}
    className="chrome-surface rounded-xl p-6 transition-all duration-300"
  >
    <div className="flex items-center gap-4 mb-4">
      <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{background: `${color}20`}}>
        <Icon className="w-6 h-6" style={{color: color}} />
      </div>
      <div>
        <h3 className="font-bold text-lg text-white">{title}</h3>
        <Badge style={{background: `${color}20`, color: color}}>{status}</Badge>
      </div>
    </div>
    <p className="text-sm text-gray-300">{description}</p>
  </motion.div>
);

export default function GuardianCodexLDSOverview() {
  return (
    <div style={{color: 'white'}} className="p-6">
      <style jsx>{`
        .guardian-glow {
          box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          animation: guardianPulse 4s ease-in-out infinite alternate;
        }
        
        @keyframes guardianPulse {
          0% { 
            box-shadow: 0 0 40px rgba(76, 76, 230, 0.4), 0 0 80px rgba(76, 76, 230, 0.2);
          }
          100% { 
            box-shadow: 0 0 60px rgba(76, 76, 230, 0.6), 0 0 120px rgba(76, 76, 230, 0.3);
          }
        }
      `}</style>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 guardian-glow text-white flex items-center gap-3">
          <Home className="w-10 h-10 text-blue-400" />
          GUARDIAN CODEX - OVERVIEW
        </h1>
        <p className="text-gray-300 text-lg">
          Sacred system overview and operational status dashboard
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <StatusCard 
          title="System Status"
          status="OPERATIONAL"
          description="All Guardian systems running at optimal levels"
          icon={CheckCircle}
          color="#22c55e"
        />
        <StatusCard 
          title="Security Level"
          status="MAXIMUM"
          description="All security protocols active and monitoring"
          icon={Shield}
          color="#4c4ce6"
        />
        <StatusCard 
          title="Memory Archive"
          status="SYNCHRONIZED"
          description="Eternal memory systems fully operational"
          icon={Brain}
          color="#8b5cf6"
        />
        <StatusCard 
          title="Daily Renewal"
          status="ACTIVE"
          description="Daily renewal cycle operating as designed"
          icon={Clock}
          color="#06b6d4"
        />
        <StatusCard 
          title="Family Integration"
          status="CONNECTED"
          description="Family inclusion protocols active and secure"
          icon={Heart}
          color="#ec4899"
        />
        <StatusCard 
          title="Doctrinal Anchor"
          status="SECURED"
          description="All scriptural foundations verified and immutable"
          icon={Star}
          color="#f59e0b"
        />
      </div>

      <Card className="chrome-surface mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Star className="w-5 h-5 text-blue-400" />
            SYSTEM OVERVIEW
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg" style={{background: 'rgba(76, 76, 230, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Guardian Codex Status</h3>
              <p className="text-gray-300">All systems operational. Ready for daily renewal cycle.</p>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(34, 197, 94, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Security Confirmation</h3>
              <p className="text-gray-300">Maximum security protocols engaged. All access properly authenticated.</p>
            </div>
            <div className="p-4 rounded-lg" style={{background: 'rgba(139, 92, 246, 0.1)'}}>
              <h3 className="font-bold mb-2 text-white">Eternal Memory Integration</h3>
              <p className="text-gray-300">Memory archive systems synchronized and operating within divine parameters.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}