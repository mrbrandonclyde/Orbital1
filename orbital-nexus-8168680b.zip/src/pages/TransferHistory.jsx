import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Landmark, ArrowRightLeft, Search, Filter, Calendar, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Parcel } from '@/api/entities';

// Table components (using div-based table for better control)
const TableContainer = ({ children }) => (
  <div className="chrome-surface rounded-xl overflow-hidden">
    <div className="overflow-x-auto">
      <table className="w-full">{children}</table>
    </div>
  </div>
);

const TableHeader = ({ children }) => (
  <thead className="border-b border-blue-500/20">
    <tr className="text-left">
      {children}
    </tr>
  </thead>
);

const TableHeaderCell = ({ children }) => (
  <th className="px-6 py-4 font-semibold text-sm" style={{color: 'var(--orbital-text-dim)'}}>
    {children}
  </th>
);

const TableBody = ({ children }) => <tbody>{children}</tbody>;

const TableRow = ({ children }) => (
  <tr className="border-b border-gray-800 hover:bg-blue-500/5 transition-colors">
    {children}
  </tr>
);

const TableCell = ({ children, className = "" }) => (
  <td className={`px-6 py-4 ${className}`} style={{color: 'var(--orbital-text)'}}>
    {children}
  </td>
);

export default function TransferHistory() {
  const [transfers, setTransfers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [dateRange, setDateRange] = useState('all');

  useEffect(() => {
    const mockTransfers = [
      { id: 'tx_001', parcelId: 'P001-ALPHA', from: '0x1A2B...b3C4', to: '0x2B4C...d4E5', date: new Date(Date.now() - 86400000).toISOString(), type: 'SALE', value: '1,500 ORB', gas: '0.25 ORB' },
      { id: 'tx_002', parcelId: 'P007-GAMMA', from: '0x3C5D...e5F6', to: '0x4D6E...f6G7', date: new Date(Date.now() - 172800000).toISOString(), type: 'TRANSFER', value: 'N/A', gas: '0.15 ORB' },
      { id: 'tx_003', parcelId: 'P012-BETA', from: '0x5E7F...g7H8', to: '0x6F8G...h8I9', date: new Date(Date.now() - 259200000).toISOString(), type: 'SALE', value: '3,200 ORB', gas: '0.42 ORB' },
      { id: 'tx_004', parcelId: 'P001-ALPHA', from: '0x0000...0000', to: '0x1A2B...b3C4', date: new Date(Date.now() - 345600000).toISOString(), type: 'MINT', value: 'N/A', gas: '0.18 ORB' },
      { id: 'tx_005', parcelId: 'P018-DELTA', from: '0x7G9H...i9J0', to: '0x8H0I...j0K1', date: new Date(Date.now() - 432000000).toISOString(), type: 'AUCTION', value: '2,750 ORB', gas: '0.35 ORB' },
    ];
    setTransfers(mockTransfers);
  }, []);

  const filteredTransfers = transfers.filter(t => {
    const matchesSearch = !searchTerm || 
      t.parcelId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === 'all' || t.type === filterType;
    
    return matchesSearch && matchesType;
  });

  const getBadgeColor = (type) => {
    switch(type) {
      case 'SALE': return {background: '#22c55e', color: '#000'};
      case 'AUCTION': return {background: '#f59e0b', color: '#000'};
      case 'TRANSFER': return {background: 'var(--orbital-blue)', color: '#000'};
      case 'MINT': return {background: '#8b5cf6', color: '#fff'};
      default: return {background: '#6b7280', color: '#fff'};
    }
  };

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">TRANSFER HISTORY</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Complete on-chain property transfer audit trail</p>
        </div>
        <Button className="glow-blue" style={{background: 'var(--orbital-blue)', color: '#000'}}>
          <Download className="w-4 h-4 mr-2" />
          Export CSV
        </Button>
      </motion.div>

      {/* Filters */}
      <Card className="chrome-surface mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}}/>
              <Input
                placeholder="Search transfers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 chrome-surface"
              />
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="chrome-surface">
                <SelectValue placeholder="Transaction Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="SALE">Sales</SelectItem>
                <SelectItem value="TRANSFER">Transfers</SelectItem>
                <SelectItem value="MINT">Mints</SelectItem>
                <SelectItem value="AUCTION">Auctions</SelectItem>
              </SelectContent>
            </Select>

            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="chrome-surface">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="24h">Last 24 Hours</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" className="chrome-surface">
              <Filter className="w-4 h-4 mr-2" />
              Advanced
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="chrome-surface"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-green-400">{filteredTransfers.length}</div><div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Total Transfers</div></CardContent></Card>
        <Card className="chrome-surface"><CardContent className="p-4 text-center"><div className="text-2xl font-bold" style={{color: 'var(--orbital-blue)'}}>{filteredTransfers.filter(t => t.type === 'SALE').length}</div><div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Sales</div></CardContent></Card>
        <Card className="chrome-surface"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-yellow-400">{filteredTransfers.reduce((sum, t) => sum + (parseFloat(t.value.replace(/[^\d.]/g, '')) || 0), 0).toLocaleString()} ORB</div><div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Total Volume</div></CardContent></Card>
        <Card className="chrome-surface"><CardContent className="p-4 text-center"><div className="text-2xl font-bold text-purple-400">{(filteredTransfers.reduce((sum, t) => sum + parseFloat(t.gas.replace(/[^\d.]/g, '')), 0)).toFixed(2)} ORB</div><div className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>Gas Fees</div></CardContent></Card>
      </div>

      {/* Transfer Table */}
      <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay: 0.2}}>
        <TableContainer>
          <TableHeader>
            <TableHeaderCell>Transaction Hash</TableHeaderCell>
            <TableHeaderCell>Parcel ID</TableHeaderCell>
            <TableHeaderCell>Type</TableHeaderCell>
            <TableHeaderCell>From</TableHeaderCell>
            <TableHeaderCell>To</TableHeaderCell>
            <TableHeaderCell>Date</TableHeaderCell>
            <TableHeaderCell>Value</TableHeaderCell>
            <TableHeaderCell>Gas Fee</TableHeaderCell>
          </TableHeader>
          <TableBody>
            {filteredTransfers.map((transfer) => (
              <TableRow key={transfer.id}>
                <TableCell className="font-mono text-sm">{transfer.id}</TableCell>
                <TableCell className="font-semibold">{transfer.parcelId}</TableCell>
                <TableCell>
                  <Badge style={getBadgeColor(transfer.type)} className="text-xs font-bold">
                    {transfer.type}
                  </Badge>
                </TableCell>
                <TableCell className="font-mono text-sm">{transfer.from}</TableCell>
                <TableCell className="font-mono text-sm">{transfer.to}</TableCell>
                <TableCell className="text-sm">{new Date(transfer.date).toLocaleString()}</TableCell>
                <TableCell className="font-semibold" style={{color: transfer.value !== 'N/A' ? '#22c55e' : 'var(--orbital-text-dim)'}}>{transfer.value}</TableCell>
                <TableCell className="text-sm" style={{color: 'var(--orbital-text-dim)'}}>{transfer.gas}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TableContainer>
      </motion.div>

      {filteredTransfers.length === 0 && (
        <div className="chrome-surface rounded-2xl p-12 text-center">
          <ArrowRightLeft className="w-16 h-16 mx-auto mb-4" style={{color: 'var(--orbital-text-dim)'}} />
          <h3 className="font-bold mb-2">No Transfers Found</h3>
          <p style={{color: 'var(--orbital-text-dim)'}}>No transfers match your current search criteria.</p>
        </div>
      )}
    </div>
  );
}