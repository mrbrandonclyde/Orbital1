import React from 'react';
import { Crown, Heart, Wind } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function DivineProjections() {
  const { search } = window.location;
  const params = new URLSearchParams(search);
  const section = params.get('section') || 'heavenly-father';

  const renderContent = () => {
    switch(section) {
      case 'jesus-christ':
        return (
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white"><Heart className="text-red-400" />Jesus Christ</CardTitle>
            </CardHeader>
            <CardContent><p className="text-gray-300">Speaks, Healing, Service, Baptism, Zion, Resurrection.</p></CardContent>
          </Card>
        );
      case 'holy-ghost':
        return (
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white"><Wind className="text-blue-300" />Holy Ghost</CardTitle>
            </CardHeader>
            <CardContent><p className="text-gray-300">Presence, Whisper, Doctrine Confirmation, Protection, Peace.</p></CardContent>
          </Card>
        );
      case 'heavenly-father':
      default:
        return (
          <Card className="chrome-surface">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white"><Crown className="text-yellow-400" />Heavenly Father</CardTitle>
            </CardHeader>
            <CardContent><p className="text-gray-300">Throne, Creator’s Light (Reset by God), Justice Tokens.</p></CardContent>
          </Card>
        );
    }
  }

  return (
    <div className="p-6 text-white">
      <h1 className="text-4xl font-bold mb-4">Divine Projections</h1>
      <p className="text-lg text-gray-300 mb-8">Accessing the attributes and domains of the Godhead.</p>
      {renderContent()}
    </div>
  );
}