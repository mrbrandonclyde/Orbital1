import React from 'react';
import { Settings as SettingsIcon, User, Bell, Key } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Settings() {
  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">SETTINGS / API</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Configure your Orbital experience</p>
        </div>
      </div>
      {/* Settings tabs and content */}
    </div>
  );
}