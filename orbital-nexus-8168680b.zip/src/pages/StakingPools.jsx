import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Wallet2, TrendingUp, Cpu, Lock, Users, Zap, Shield, GitBranch } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StakingPool } from '@/api/entities';
import { Progress } from '@/components/ui/progress';

const StakingPoolCard = ({ pool, index }) => {
  const getPoolColor = (type) => {
    const colors = {
      governance: '#8b5cf6',
      infrastructure: '#3b82f6',
      research: '#06b6d4',
      expansion: '#f59e0b',
      stability: '#22c55e',
    };
    return colors[type] || 'var(--orbital-blue)';
  };

  const color = getPoolColor(pool.pool_type);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="chrome-surface rounded-2xl p-6 transition-all duration-300"
      whileHover={{ y: -5, boxShadow: `0 0 30px ${color}40` }}
      style={{ borderLeft: `4px solid ${color}` }}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-bold text-lg" style={{ color: 'var(--orbital-text)' }}>
            {pool.pool_name}
          </h3>
          <Badge
            className="text-xs mt-1"
            style={{
              background: `${color}20`,
              color: color,
              border: `1px solid ${color}50`
            }}
          >
            {pool.pool_type?.toUpperCase()}
          </Badge>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold" style={{ color: color }}>
            {pool.apy_rate}% APY
          </div>
          <div className="text-xs" style={{ color: 'var(--orbital-text-dim)' }}>
            AI Yield Forecast: {pool.ai_optimization?.yield_forecast}%
          </div>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        <div className="flex justify-between">
          <span style={{ color: 'var(--orbital-text-dim)' }}>Total Staked</span>
          <span style={{ color: 'var(--orbital-text)' }}>{pool.total_staked?.toLocaleString()} ORB</span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: 'var(--orbital-text-dim)' }}>Lock Period</span>
          <span style={{ color: 'var(--orbital-text)' }}>{pool.lock_period_days} Days</span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: 'var(--orbital-text-dim)' }}>Risk Score</span>
          <span style={{ color: getPoolColor(pool.pool_type === 'stability' ? 'stability' : 'expansion') }}>{pool.ai_optimization?.risk_score}/100</span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: 'var(--orbital-text-dim)' }}>Stakers</span>
          <span style={{ color: 'var(--orbital-text)' }}>{pool.staker_count?.toLocaleString()}</span>
        </div>
      </div>

      <div className="flex gap-3">
        <Button 
          className="flex-1 font-bold"
          style={{ background: color, color: '#000' }}
        >
          Stake
        </Button>
        <Button variant="outline" className="flex-1 chrome-surface">
          Manage
        </Button>
      </div>
    </motion.div>
  );
};

export default function StakingPools() {
  const [pools, setPools] = useState([]);

  useEffect(() => {
    const fetchPools = async () => {
      try {
        const poolData = await StakingPool.list();
        setPools(poolData);
      } catch (e) {
        // Fallback for demonstration
        setPools([
          { id: '1', pool_name: 'ORB Governance', pool_type: 'governance', apy_rate: 12.5, total_staked: 125000000, lock_period_days: 365, staker_count: 12345, ai_optimization: { yield_forecast: 15.2, risk_score: 35 } },
          { id: '2', pool_name: 'Infrastructure Fund', pool_type: 'infrastructure', apy_rate: 8.2, total_staked: 75000000, lock_period_days: 180, staker_count: 8765, ai_optimization: { yield_forecast: 9.1, risk_score: 20 } },
          { id: '3', pool_name: 'Quantum Research Grant', pool_type: 'research', apy_rate: 18.9, total_staked: 50000000, lock_period_days: 730, staker_count: 4321, ai_optimization: { yield_forecast: 22.5, risk_score: 65 } },
          { id: '4', pool_name: 'Interstellar Expansion', pool_type: 'expansion', apy_rate: 25.0, total_staked: 25000000, lock_period_days: 1460, staker_count: 1234, ai_optimization: { yield_forecast: 30.1, risk_score: 85 } },
          { id: '5', pool_name: 'Economic Stability Fund', pool_type: 'stability', apy_rate: 5.5, total_staked: 250000000, lock_period_days: 90, staker_count: 23456, ai_optimization: { yield_forecast: 6.0, risk_score: 10 } },
        ]);
      }
    };
    fetchPools();
  }, []);

  return (
    <div style={{ color: 'var(--orbital-text)' }}>
      <style jsx>{`
        .staking-glow {
          box-shadow: 0 0 25px rgba(139, 92, 246, 0.3), 0 0 50px rgba(139, 92, 246, 0.1);
          animation: stakingPulse 4s ease-in-out infinite alternate;
        }
        @keyframes stakingPulse {
          0% { box-shadow: 0 0 25px rgba(139, 92, 246, 0.3); }
          100% { box-shadow: 0 0 40px rgba(139, 92, 246, 0.5); }
        }
      `}</style>
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold staking-glow" style={{ color: 'var(--orbital-text)' }}>
          ORB TOKEN STAKING
        </h1>
        <p style={{ color: 'var(--orbital-text-dim)' }}>
          Secure the network, earn rewards, and participate in the future of the Orbital ecosystem.
        </p>
        <div className="flex items-center gap-4 mt-4">
          <Badge className="font-bold px-3 py-1" style={{ background: 'linear-gradient(45deg, #8b5cf6, #00d4ff)', color: '#000' }}>
            <Zap className="w-4 h-4 mr-2" />
            AI-OPTIMIZED YIELDS
          </Badge>
          <Badge variant="outline" style={{ borderColor: 'var(--orbital-blue)', color: 'var(--orbital-blue)' }}>
            <Shield className="w-4 h-4 mr-2" />
            SECURED BY SMART CONTRACT
          </Badge>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {pools.map((pool, index) => (
          <StakingPoolCard key={pool.id} pool={pool} index={index} />
        ))}
      </div>
    </div>
  );
}