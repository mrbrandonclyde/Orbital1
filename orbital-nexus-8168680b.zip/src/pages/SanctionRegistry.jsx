import React, { useState } from 'react';
import { Files, Search, Filter, Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const SanctionEntry = ({ sanction }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="chrome-surface rounded-xl p-4 mb-4"
  >
    <div className="flex justify-between items-start mb-3">
      <h4 className="font-bold" style={{color: 'var(--orbital-text)'}}>{sanction.violation}</h4>
      <Badge style={{
        background: sanction.severity === 'major' ? '#ef4444' : 
                   sanction.severity === 'moderate' ? '#f59e0b' : '#22c55e',
        color: '#000'
      }}>
        {sanction.severity.toUpperCase()}
      </Badge>
    </div>
    <p className="text-sm mb-3" style={{color: 'var(--orbital-text-dim)'}}>{sanction.action}</p>
    <div className="flex justify-between items-center text-xs" style={{color: 'var(--orbital-text-dim)'}}>
      <span>Entity: {sanction.entity}</span>
      <span>Date: {new Date(sanction.date).toLocaleDateString()}</span>
      <span>Duration: {sanction.duration}</span>
    </div>
  </motion.div>
);

export default function SanctionRegistry() {
  const [sanctions] = useState([
    { id: 1, violation: 'Truth Protocol Breach', action: 'Warning issued, mandatory ethics training', entity: 'Merchant Guild 7', severity: 'minor', date: Date.now() - 86400000, duration: '30 days' },
    { id: 2, violation: 'Environmental Damage', action: 'Restoration required, mining license suspended', entity: 'Asteroid Corp', severity: 'major', date: Date.now() - 172800000, duration: '6 months' },
    { id: 3, violation: 'Unauthorized Access', action: 'Access revoked, security audit mandated', entity: 'Data Analysis Ltd', severity: 'moderate', date: Date.now() - 259200000, duration: '90 days' },
  ]);

  return (
    <div style={{color: 'var(--orbital-text)'}}>
      <motion.div initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">📋 SANCTION REGISTRY</h1>
          <p style={{color: 'var(--orbital-text-dim)'}}>Complete record of enforcement actions and sanctions</p>
        </div>
      </motion.div>

      <Card className="chrome-surface mb-6">
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{color: 'var(--orbital-text-dim)'}}/>
              <Input placeholder="Search sanctions..." className="w-full pl-12 chrome-surface" />
            </div>
            <Button variant="outline" className="chrome-surface"><Calendar className="w-4 h-4 mr-2" /> Date Range</Button>
            <Button variant="outline" className="chrome-surface"><Filter className="w-4 h-4 mr-2" /> Filter</Button>
          </div>
        </CardContent>
      </Card>

      <div>
        {sanctions.map((sanction) => (
          <SanctionEntry key={sanction.id} sanction={sanction} />
        ))}
      </div>
    </div>
  );
}